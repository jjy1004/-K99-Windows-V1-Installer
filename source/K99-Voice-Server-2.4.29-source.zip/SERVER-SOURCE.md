이 파일은 Windows 소스 ZIP과 함께 보관하는 서버 소스입니다.
Windows 설치본에는 서버 SDK나 API 키를 넣지 않습니다.
서버 게시는 별도이며 기본 음성 연결에는 접근 코드 입력이 필요 없습니다.
운영자가 K99_DIARY_VOICE_ACCESS_TOKEN을 설정한 경우에만 접근 코드 인증을 사용합니다.
