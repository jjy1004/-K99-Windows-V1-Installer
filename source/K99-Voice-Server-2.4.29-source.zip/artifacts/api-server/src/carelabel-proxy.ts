// Production-only entry: no desktop routes, SQLite startup, customer/order APIs or photo serving.
import express from 'express';
import pinoHttp from 'pino-http';
import {logger} from './lib/logger';
import carelabelRouter from './routes/carelabel';
import releaseDownloads from './routes/release-downloads';
import diaryVoiceRouter from './routes/diary-voice';

const app=express();
app.disable('x-powered-by');
app.use(pinoHttp({logger,serializers:{
  req(req){return {id:req.id,method:req.method,url:req.url?.split('?')[0]};},
  res(res){return {statusCode:res.statusCode};},
}}));
app.get(['/','/api','/api/healthz'],(_req,res)=>res.json({
  status:'ok',service:'k99-carelabel-proxy',contract:'raw-text-ocr-v3',ocrTimeoutMs:3000,
  analyzerConfigured:Boolean(process.env.GEMINI_API_KEY),
}));
app.use('/api/carelabel',carelabelRouter);
app.use('/api/openai/diary-voice',diaryVoiceRouter);
app.use('/api/dev-downloads',releaseDownloads());
app.use((_req,res)=>res.status(404).json({error:'Not found'}));
const port=Number(process.env.PORT);
if(!Number.isInteger(port)||port<1||port>65535)throw Error('Valid PORT is required');
const server=app.listen(port,'0.0.0.0',()=>logger.info({port},'CareLabel proxy listening'));
server.on('error',error=>{logger.error({err:error},'Proxy startup failed');process.exitCode=1;});
for(const signal of ['SIGINT','SIGTERM'] as const)process.once(signal,()=>{
  server.close(()=>process.exit(0));
  setTimeout(()=>process.exit(1),25000).unref();
});
