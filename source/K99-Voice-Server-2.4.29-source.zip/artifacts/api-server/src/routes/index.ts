import { Router, type IRouter } from "express";
import healthRouter from "./health";
import desktopRouter from "./desktop";

const router: IRouter = Router();

router.use(healthRouter);
router.use(desktopRouter);

export default router;
