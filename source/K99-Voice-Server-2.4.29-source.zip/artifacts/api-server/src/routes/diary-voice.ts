import express, { Router, type ErrorRequestHandler } from 'express';
import { TranscribeDiaryVoiceBody, OrganizeDiaryVoiceBody, TranscribeDiaryVoiceResponse, OrganizeDiaryVoiceResponse } from '@workspace/api-zod';
import { voiceAuthorized, validateDiaryWav, createVoiceAdmission } from '../lib/diary-voice';
import { transcribeDiaryAudio, organizeDiaryText } from '../lib/diary-voice-ai';

const router = Router();
const enter = createVoiceAdmission();
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || !process.env.AI_INTEGRATIONS_OPENAI_API_KEY ||
      (process.env.K99_DIARY_VOICE_ACCESS_TOKEN && process.env.K99_DIARY_VOICE_ACCESS_TOKEN.length < 24)) {
    res.status(503).json({ error: '음성 서버 연결 설정이 필요합니다. 본사에 서버 게시·접근 코드 설정을 요청해 주세요.' }); return;
  }
  // 기본은 입력 없는 제한형 공개 서비스. 운영자가 코드를 설정하면 기존 인증 모드를 유지한다.
  if (process.env.K99_DIARY_VOICE_ACCESS_TOKEN &&
      !voiceAuthorized(req.headers.authorization, process.env.K99_DIARY_VOICE_ACCESS_TOKEN)) {
    res.status(401).json({ error: '매장 음성 서비스 접근 코드를 확인해 주세요.' }); return;
  }
  if (!req.is('application/json')) { res.status(400).json({ error: 'JSON 녹음 요청이 필요합니다.' }); return; }
  try {
    const release = enter(req.ip || 'unknown');
    // 클라이언트가 연결을 닫아도 AI 처리가 끝날 때까지 동시 처리 자리를 유지한다.
    res.locals.releaseVoice = release;
    res.once('finish', release);
    next();
  } catch {
    res.set('Retry-After', '60').status(429).json({ error: '요청이 많습니다. 잠시 후 다시 시도하세요.' });
  }
});
router.use(express.json({ limit: '16mb', strict: true }));
router.post('/transcribe', async (req, res): Promise<void> => {
  const input = TranscribeDiaryVoiceBody.safeParse(req.body);
  if (!input.success || Object.keys(req.body).some(k => !['audio_base64', 'context'].includes(k))) {
    res.status(400).json({ error: '녹음과 매장 교정 사전 형식을 확인해 주세요.' }); return;
  }
  let bytes: Buffer;
  try { bytes = validateDiaryWav(input.data.audio_base64); }
  catch { res.status(400).json({ error: '녹음은 0.5초~5분 WAV 형식이어야 합니다.' }); return; }
  try {
    const { openai } = await import('@workspace/integrations-openai-ai-server');
    const text = await transcribeDiaryAudio(openai, bytes, input.data.context);
    res.json(TranscribeDiaryVoiceResponse.parse({ text }));
  } catch {
    req.log.warn({ code: 'DIARY_TRANSCRIPTION_FAILED' }, '음성 전사 실패');
    res.status(502).json({ error: '음성을 전사하지 못했습니다. 녹음은 화면에 보관되어 있으니 다시 정리해 주세요.' });
  } finally { res.locals.releaseVoice?.(); }
});
router.post('/organize', async (req, res): Promise<void> => {
  const input = OrganizeDiaryVoiceBody.safeParse(req.body);
  if (!input.success || !input.data.raw_text.trim() || Object.keys(req.body).some(k => !['raw_text', 'context'].includes(k))) {
    res.status(400).json({ error: '원문과 매장 교정 사전 형식을 확인해 주세요.' }); return;
  }
  try {
    const { openai } = await import('@workspace/integrations-openai-ai-server');
    const text = await organizeDiaryText(openai, input.data.raw_text, input.data.context);
    res.json(OrganizeDiaryVoiceResponse.parse({ text }));
  } catch {
    req.log.warn({ code: 'DIARY_ORGANIZATION_FAILED' }, '일기 문장 정리 실패');
    res.status(502).json({ error: '문장을 정리하지 못했습니다. 전사 원문은 보존됩니다. 다시 시도하거나 직접 수정해 저장하세요.' });
  } finally { res.locals.releaseVoice?.(); }
});
const bodyError: ErrorRequestHandler = (error, _req, res, _next) => {
  res.locals.releaseVoice?.();
  res.status(error.type === 'entity.too.large' ? 413 : 400).json({ error: '녹음 용량 또는 JSON 형식을 확인해 주세요.' });
};
router.use(bodyError);
export default router;
