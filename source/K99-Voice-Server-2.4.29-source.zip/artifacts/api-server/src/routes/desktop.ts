import { Router } from 'express';
import { localStore, equipmentApi, desktopManager } from '../local-store';

const router = Router();
// Browser-only development transport. No CORS and no cross-site mutation.
router.use(async (req, res) => {
  const origin = req.headers.origin;
  const originHost = (() => {try {return origin ? new URL(origin).host : null;} catch {return 'invalid';}})();
  const hosts = [req.headers.host, req.headers['x-forwarded-host']].flatMap(h => typeof h === 'string' ? h.split(',').map(s => s.trim()) : []);
  if (req.headers['sec-fetch-site'] === 'cross-site' || (originHost && !hosts.includes(originHost))) {
    res.status(403).json({error:'개발용 로컬 연결만 허용합니다.'}); return;
  }
  if (req.method !== 'GET' && req.headers['x-k99-local'] !== '1') {
    res.status(403).json({error:'로컬 요청 확인 헤더가 필요합니다.'}); return;
  }
  try {
    // Real customer spreadsheets are private local desktop data, not a public
    // preview API. Electron uses its trusted native IPC directly.
    if(req.path.startsWith('/customers/')||req.path.startsWith('/diaries/')) {
      res.status(403).json({error:'고객 DB는 Windows 앱의 로컬 연결에서만 사용합니다.'});return;
    }
    if(req.path.startsWith('/maintenance/')) {
      res.set('Cache-Control','no-store');
      res.json(await desktopManager.api(req.method,`/api${req.path}`,req.body));return;
    }
    if(req.method==='GET'&&req.path.startsWith('/equipment/photos/')) {
      const file=localStore.equipment.photoFile(req.path.slice('/equipment/photos/'.length));
      res.set('Cache-Control','no-store').type(file.contentType).send(file.bytes);return;
    }
    if(req.path.startsWith('/equipment/')) {
      res.json(await equipmentApi.api(req.method,`/api${req.path}`,req.body));return;
    }
    if (req.path === '/local/storage' && req.method === 'POST') {
      res.json({result:localStore.storage(req.body)}); return;
    }
    const query=req.path.startsWith('/notices/')?new URL(req.originalUrl,'http://local').search:'';
    res.json(localStore.api(req.method, `/api${req.path}${query}`, req.body));
  } catch (err) {
    const error = err as Error & {status?:number};
    if (!error.status) req.log.error({err}, 'Local SQLite request failed');
    res.status(error.status || 500).json({error: error.status ? error.message : 'SQLite 저장에 실패했습니다. 저장 공간과 권한을 확인하세요.'});
  }
});
export default router;
