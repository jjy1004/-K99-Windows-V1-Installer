// Temporary development-only delivery of fixed build outputs, not a general file server.
import {Router} from 'express';
import {fileURLToPath} from 'node:url';
import {stat} from 'node:fs/promises';
import {open} from 'node:fs/promises';
import {pipeline} from 'node:stream/promises';

export default function developmentDownloads(directory:URL){
const router=Router();
// A versioned preview-only link must not return the previous published EXE
// from release-downloads.ts. It always downloads under the requested name.
if(process.env.NODE_ENV==='development'){
  for(const version of ['2.4.4','2.4.5']){
  router.get(`/windows-10-11-${version}/K99-Smart-Laundry-V2-Setup.exe`,async(req,res):Promise<void>=>{
    let handle:Awaited<ReturnType<typeof open>>|undefined;
    try{
      handle=await open(fileURLToPath(new URL(`releases/${version}/K99-Smart-Laundry-V2-Setup.exe`,directory)),'r');
      const info=await handle.stat();
      if(!info.isFile())throw Error('Not a release file');
      res.set({'Content-Type':'application/octet-stream',
        'Content-Disposition':'attachment; filename="K99-Smart-Laundry-V2-Setup.exe"',
        'Cache-Control':'no-store, no-transform','X-Content-Type-Options':'nosniff',
        'X-File-Size':String(info.size),'X-Accel-Buffering':'no','Accept-Ranges':'none'});
      if(req.method==='HEAD'){res.setHeader('Content-Length',String(info.size));res.end();return;}
      const stream=handle.createReadStream({autoClose:true});
      const closed=()=>{if(!res.writableFinished)stream.destroy();};
      res.once('close',closed);
      try{await pipeline(stream,res);}finally{res.off('close',closed);}
    }catch(error){
      req.log.warn({code:(error as NodeJS.ErrnoException).code},'Versioned Windows installer download interrupted');
      if(!res.headersSent&&!res.destroyed)res.status(503).end();
    }finally{await handle?.close().catch(()=>{});}
  });
  }
}
router.get('/install-guide',async(_req,res):Promise<void>=>{
  const file=fileURLToPath(new URL('K99-Laundry-V2-2.4.1-download.html',directory));
  res.set({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.sendFile(file,error=>{if(error&&!res.headersSent)res.sendStatus(404);});
});
for(const filename of ['K99-Smart-Laundry-V2-Setup.exe','K99-Laundry-V2-2.4.1-win-unpacked.zip','K99-Laundry-V2-2.4.0-win-unpacked.zip','K99-Windows-V1-0.3.0-win-unpacked.zip','K99-Windows-V1-0.3.1-win-unpacked.zip',
  'K99-Windows-V1-0.3.1-banner-removed-win-unpacked.zip','K99-Laundry-V2-win-unpacked.zip',
  'K99-Laundry-V2-2.1.0-win-unpacked.zip','K99-Laundry-V2-2.2.0-win-unpacked.zip','K99-Laundry-V2-2.3.0-win-unpacked.zip','K99-Laundry-V2-2.3.1-win-unpacked.zip','K99-Laundry-V2-2.3.2-win-unpacked.zip','K99-Laundry-V2-2.3.3-win-unpacked.zip','K99-Laundry-V2-2.3.4-win-unpacked.zip','K99-Laundry-V2-2.3.5-win-unpacked.zip','K99-Laundry-V2-2.3.6-win-unpacked.zip','K99-Laundry-V2-2.3.7-win-unpacked.zip'])
for(const suffix of ['', '.sha256']){
  router.get('/'+filename+suffix,async(req,res):Promise<void>=>{
    const file=fileURLToPath(new URL(filename+suffix,directory));
    try{
      const info=await stat(file);
      if(!info.isFile()){res.sendStatus(404);return;}
      res.set({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      res.download(file,filename+suffix,{acceptRanges:true,cacheControl:false,lastModified:false},error=>{
        if(error){
          req.log.warn({code:(error as NodeJS.ErrnoException).code},'Development build download interrupted');
          if(!res.headersSent)res.sendStatus(404);
        }
      });
    }catch{res.status(404).json({error:'Build file is not available in this development workspace'});}
  });
}
return router;
}
