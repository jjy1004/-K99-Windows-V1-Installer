import express, { Router, type ErrorRequestHandler } from 'express';
import { createRequire } from 'node:module';
import { AnalyzeCareLabelBody } from '@workspace/api-zod';

const require=createRequire(import.meta.url);
const {analyzeCareLabel,createAdmission,textResult}=require('@workspace/k99-local/carelabel-analysis.cjs');
const gate=createAdmission();
const router=Router();

// Electron Main -> central server. No client key, Google credential, order or customer fields.
router.use((_req,res,next)=>{res.set('Cache-Control','no-store');next();});
router.post('/analyze',(req,res,next)=>{
  if(!req.is('application/json')){res.status(415).json({code:'CONTENT_TYPE',error:'JSON 요청이 필요합니다.'});return;}
  try{
    const release=gate.enter();
    res.once('finish',release);res.once('close',release);next();
  }catch{res.json(textResult('','busy'));}
},express.json({limit:'12mb',strict:true}),async(req,res)=>{
  try{
    if(!req.body||Object.keys(req.body).some(k=>!['dataBase64','mimeType'].includes(k))){
      res.status(400).json({code:'INVALID_IMAGE',error:'사진 Base64와 mimeType만 전송하세요.'});return;
    }
    const parsed=AnalyzeCareLabelBody.safeParse(req.body);
    if(!parsed.success){res.status(400).json({code:'INVALID_IMAGE',error:'사진 Base64와 mimeType을 확인하세요.'});return;}
    const result=await analyzeCareLabel(parsed.data,{apiKey:process.env.GEMINI_API_KEY});
    res.json(result);
  }catch(cause){
    const error=cause as Error & {code?:string;httpStatus?:number};
    // Same detailed terminal diagnostic as "CareLabel AI Error:", without request images or headers.
    req.log.error({err:{name:error.name,message:error.message,stack:error.stack,code:error.code}},'CareLabel AI Error:');
    if(error.httpStatus===503)res.set('Retry-After','5');
    res.status(error.httpStatus||502).json({code:error.code||'ANALYSIS_ERROR',retryable:error.httpStatus===503,error:
      error.httpStatus===503?(error.code==='SERVER_NOT_READY'?'중앙 분석 서버 준비 중입니다.':
        'AI 공급자가 일시적으로 응답하지 않습니다. 잠시 후 재분석하세요.'):error.code==='MODEL_UNAVAILABLE'
        ?'중앙 분석 모델 설정을 확인하세요.':error.code==='INVALID_IMAGE'?error.message:'중앙 분석 요청에 실패했습니다.'});
  }
});
const bodyError:ErrorRequestHandler=(error,req,res,_next)=>{
  req.log.warn({code:error.type},'CareLabel request rejected');
  res.status(error.type==='entity.too.large'?413:400).json({code:'INVALID_IMAGE',error:'사진 JSON 형식 또는 용량 오류'});
};
router.use(bodyError);
export default router;
