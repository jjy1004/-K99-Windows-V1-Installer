import { createRequire } from 'node:module';
import path from 'node:path';
const require = createRequire(import.meta.url);
const {createDesktopManager}=require('@workspace/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('@workspace/k99-local/equipment-api.cjs');
// A new SQLite file in THIS independent development project only.
export const desktopManager=createDesktopManager(path.resolve(process.cwd(),'../../generated-artifacts/preview-maintenance'),{
  dataDir:path.resolve(process.cwd(),'../../local-data'),dbName:'preview.sqlite',
});
export const localStore=desktopManager.store;
export const equipmentApi=createEquipmentApi(localStore);
const backupTimer=setInterval(()=>{
  try{desktopManager.automatic();}catch{/* Failure is visible in maintenance status, never silently reported as a success. */}
},60000);
backupTimer.unref();
