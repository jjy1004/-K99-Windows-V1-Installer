import express, { type Express } from "express";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import carelabelRouter from "./routes/carelabel";
import developmentDownloads from "./routes/development-downloads";
import releaseDownloads from "./routes/release-downloads";
import diaryVoiceRouter from "./routes/diary-voice";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
// Mounted before the broad local API parser/auth gate, with its own bounded image contract.
app.use('/api/carelabel',carelabelRouter);
app.use('/api/openai/diary-voice',diaryVoiceRouter);
if(process.env.NODE_ENV==='development')
  app.use('/api/dev-downloads',releaseDownloads());
  app.use('/api/dev-downloads',developmentDownloads(new URL('../../../generated-artifacts/',import.meta.url)));
app.use(express.json({limit:'34mb'}));
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
