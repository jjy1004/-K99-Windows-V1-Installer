# Windows 정식 고객 안내 영상

업로드된 원본 MP4 4종(H.264/AAC, 1920×1080)을 바이트 변경 없이 사용합니다.
`value.mp4`, `process.mp4`, `water.mp4`, `sneakers.mp4` 및 해시 목록 `media-manifest.json`을 배치합니다.

Git에는 대용량 원본을 직접 넣지 않습니다. 최종 업로드 ZIP의
`source/customer-videos.zip.part001` ~ `part007`과 `customer-videos.upload.json`을 Actions가 검증·조합·해제합니다.
해제 위치는 `artifacts/k99-windows/media/videos/`, EXE 패키징 위치는 `resources/videos/`입니다.

더미 영상 생성·자동 대체 로직은 없습니다. 원본 누락·해시 불일치 시 빌드는 실패합니다.
현재 업로드 및 현장 검증 절차는 `docs/windows-field-operations.md`를 기준으로 합니다.
