; Per-user install. The official StartApp macro uses ExecShellAsUser.
; Shop data and the legacy K99WindowsV1 userData live OUTSIDE $INSTDIR.
; No custom pages, credential changes, data moves or deletion are allowed here.
!include "WinVer.nsh"
!include "x64.nsh"
; Reserved K99 name + exact old OBS command only. Personal OBS entries survive.
!macro K99RemoveOwnedObsRun ROOT NAME
  Push $R0
  ReadRegStr $R0 ${ROOT} "Software\Microsoft\Windows\CurrentVersion\Run" "${NAME}"
  StrCmp $R0 '$\"$PROGRAMFILES64\obs-studio\bin\64bit\obs64.exe$\" --startvirtualcam --minimize-to-tray' 0 +2
    DeleteRegValue ${ROOT} "Software\Microsoft\Windows\CurrentVersion\Run" "${NAME}"
  StrCmp $R0 '$\"$PROGRAMFILES32\obs-studio\bin\32bit\obs32.exe$\" --startvirtualcam --minimize-to-tray' 0 +2
    DeleteRegValue ${ROOT} "Software\Microsoft\Windows\CurrentVersion\Run" "${NAME}"
  Pop $R0
  ClearErrors
!macroend
!macro customInit
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_OK|MB_ICONSTOP "Windows 10 또는 Windows 11의 64비트 PC가 필요합니다." /SD IDOK
    Quit
  ${EndIf}
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "이 설치 파일은 Windows 64비트(x64)용입니다." /SD IDOK
    Quit
  ${EndIf}
!macroend

!macro customInstall
  SetShellVarContext current
  ; Repair shortcuts even if an earlier version recorded KeepShortcuts=true.
  ; $DESKTOP respects Windows/OneDrive desktop redirection.
  SetOutPath "$INSTDIR"
  CreateDirectory "$DESKTOP"
  ClearErrors
  CreateShortCut "$DESKTOP\${SHORTCUT_NAME}.lnk" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" "" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" 0
  IfErrors k99DesktopShortcutFailed k99DesktopShortcutReady
  k99DesktopShortcutFailed:
    WriteRegDWORD HKCU "Software\K99WindowsV1\Installer" "DesktopShortcutError" 1
    MessageBox MB_OK|MB_ICONEXCLAMATION "바탕화면 바로가기를 만들지 못했습니다. 보안 프로그램의 바탕화면 쓰기 허용을 확인하세요. 시작 메뉴의 K99 스마트 접수 시스템으로 실행할 수 있습니다." /SD IDOK
    Goto k99DesktopShortcutEnd
  k99DesktopShortcutReady:
    WriteRegDWORD HKCU "Software\K99WindowsV1\Installer" "DesktopShortcutError" 0
  k99DesktopShortcutEnd:
  CreateDirectory "$SMPROGRAMS"
  CreateShortCut "$SMPROGRAMS\${SHORTCUT_NAME}.lnk" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" "" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" 0
  WriteRegStr HKCU "Software\K99WindowsV1\Installer" "V2InstallLocation" "$INSTDIR"
  ; Direct USB webcam mode: remove only the K99-created legacy OBS shortcut.
  ; Existing OBS installations, other shortcuts and running processes survive.
  Delete "$SMSTARTUP\OBS Studio - K99 자동 실행.lnk"
  SetShellVarContext all
  Delete "$SMSTARTUP\OBS Studio - K99 자동 실행.lnk"
  SetShellVarContext current
  !insertmacro K99RemoveOwnedObsRun HKCU "OBS Studio - K99 자동 실행"
  !insertmacro K99RemoveOwnedObsRun HKCU "K99ObsAutoStart"
  !insertmacro K99RemoveOwnedObsRun HKLM "OBS Studio - K99 자동 실행"
  !insertmacro K99RemoveOwnedObsRun HKLM "K99ObsAutoStart"
  ClearErrors
!macroend

!macro customUnInstall
  ; Only installation metadata is removed. Never remove shop photos, backups,
  ; SQLite databases, persisted browser tokens or customer display videos.
  DeleteRegValue HKCU "Software\K99WindowsV1\Installer" "V2InstallLocation"
!macroend
