; Never delete shop files or $LOCALAPPDATA\K99WindowsV1.
!include LogicLib.nsh
!include nsDialogs.nsh
Var k99DesktopChoice
Var k99MenuChoice
Var k99DesktopBox
Var k99MenuBox
Var k99Dialog
Var k99Conflict

!macro customInit
  StrCpy $k99DesktopChoice ${BST_CHECKED}
  StrCpy $k99MenuChoice ${BST_CHECKED}
!macroend

!macro customPageAfterChangeDir
  Page custom k99ShortcutPage k99ShortcutLeave
!macroend

Function k99ShortcutPage
  !insertmacro MUI_HEADER_TEXT "K99 스마트 접수 시스템" "만들 바로가기를 선택하세요."
  nsDialogs::Create 1018
  Pop $k99Dialog
  ${If} $k99Dialog == error
    Abort
  ${EndIf}
  ${NSD_CreateLabel} 0 0 100% 30u "Windows V1 전용 프로그램입니다. 기존 K99 접수 시스템과 명품 세탁비 프로그램을 변경하지 않습니다."
  Pop $0
  ${NSD_CreateCheckbox} 0 42u 100% 16u "바탕화면에 K99 스마트 접수 시스템 바로가기 만들기"
  Pop $k99DesktopBox
  ${NSD_SetState} $k99DesktopBox $k99DesktopChoice
  ${NSD_CreateCheckbox} 0 68u 100% 16u "시작 메뉴에 K99 스마트 접수 시스템 바로가기 만들기"
  Pop $k99MenuBox
  ${NSD_SetState} $k99MenuBox $k99MenuChoice
  ${NSD_CreateLabel} 0 104u 100% 34u "같은 이름의 기존 바로가기는 덮어쓰지 않습니다. 실행에 PowerShell이나 브라우저 접속이 필요하지 않습니다."
  Pop $0
  nsDialogs::Show
FunctionEnd

Function k99ShortcutLeave
  ${NSD_GetState} $k99DesktopBox $k99DesktopChoice
  ${NSD_GetState} $k99MenuBox $k99MenuChoice
FunctionEnd

!macro customInstall
  ; Default builder shortcuts are disabled; this page owns only these new links.
  StrCpy $k99Conflict ""
  ${If} $k99DesktopChoice == ${BST_CHECKED}
    ${If} ${FileExists} "$DESKTOP\${SHORTCUT_NAME}.lnk"
      StrCpy $k99Conflict "1"
    ${Else}
      CreateShortCut "$DESKTOP\${SHORTCUT_NAME}.lnk" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" "" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" 0
      WinShell::SetLnkAUMI "$DESKTOP\${SHORTCUT_NAME}.lnk" "${APP_ID}"
      WriteRegStr HKCU "Software\K99WindowsV1\Installer" "DesktopShortcut" "$DESKTOP\${SHORTCUT_NAME}.lnk"
    ${EndIf}
  ${EndIf}
  ${If} $k99MenuChoice == ${BST_CHECKED}
    CreateDirectory "$SMPROGRAMS\K99-Windows-V1"
    ${If} ${FileExists} "$SMPROGRAMS\K99-Windows-V1\${SHORTCUT_NAME}.lnk"
      StrCpy $k99Conflict "1"
    ${Else}
      CreateShortCut "$SMPROGRAMS\K99-Windows-V1\${SHORTCUT_NAME}.lnk" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" "" "$INSTDIR\${APP_EXECUTABLE_FILENAME}" 0
      WinShell::SetLnkAUMI "$SMPROGRAMS\K99-Windows-V1\${SHORTCUT_NAME}.lnk" "${APP_ID}"
      WriteRegStr HKCU "Software\K99WindowsV1\Installer" "MenuShortcut" "$SMPROGRAMS\K99-Windows-V1\${SHORTCUT_NAME}.lnk"
    ${EndIf}
  ${EndIf}
  ; Finish-page launch works even when both shortcuts were unchecked.
  StrCpy $launchLink "$INSTDIR\${APP_EXECUTABLE_FILENAME}"
  ${If} $k99Conflict == "1"
    ${IfNot} ${Silent}
      MessageBox MB_OK|MB_ICONINFORMATION "같은 이름의 기존 바로가기를 보존했습니다. 기존 바로가기를 덮어쓰지 않았습니다. Windows V1 설치 위치에서 K99-Windows-V1.exe를 실행할 수 있습니다."
    ${EndIf}
  ${EndIf}
!macroend

!macro customUnInstall
  ; Remove only paths this installer recorded as newly created.
  ReadRegStr $R1 HKCU "Software\K99WindowsV1\Installer" "DesktopShortcut"
  ${If} $R1 == "$DESKTOP\${SHORTCUT_NAME}.lnk"
    Delete "$R1"
  ${EndIf}
  ReadRegStr $R1 HKCU "Software\K99WindowsV1\Installer" "MenuShortcut"
  ${If} $R1 == "$SMPROGRAMS\K99-Windows-V1\${SHORTCUT_NAME}.lnk"
    Delete "$R1"
    RMDir "$SMPROGRAMS\K99-Windows-V1"
  ${EndIf}
  DeleteRegKey HKCU "Software\K99WindowsV1\Installer"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "K99-Windows-V1"
!macroend
