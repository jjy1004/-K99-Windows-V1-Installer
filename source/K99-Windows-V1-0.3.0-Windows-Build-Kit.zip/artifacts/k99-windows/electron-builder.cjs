'use strict';
const path=require('node:path'),fs=require('node:fs');
module.exports={
  appId:'com.k99.windows.v1',
  productName:'K99-Laundry-V2',
  executableName:'K99-Laundry-V2',
  artifactName:'K99-Smart-Laundry-V2-Setup.${ext}',
  directories:{output:path.resolve(__dirname,'../../generated-artifacts/windows-installer')},
  files:['package.json','electron/**/*.cjs','electron/services/**/*','electron/assets/*.ico','electron/core/*.json','dist/desktop/**/*'],
  extraResources:[{from:path.resolve(__dirname,'../../generated-artifacts/windows-app/videos'),
    to:'videos',filter:['*.mp4','media-manifest.json']},
    ...(fs.existsSync(path.join(__dirname,'resources/luxury-calculator'))?
      [{from:path.join(__dirname,'resources/luxury-calculator'),to:'luxury-calculator',filter:['**/*']}]:[])],
  asar:true,asarUnpack:['**/*.node'],
  npmRebuild:true,buildDependenciesFromSource:true,
  win:{target:[{target:'nsis',arch:['x64']}],icon:path.join(__dirname,'installer/k99-reception.ico'),
    signAndEditExecutable:true,requestedExecutionLevel:'asInvoker'},
  nsis:{
    oneClick:true,perMachine:false,allowElevation:false,deleteAppDataOnUninstall:false,
    allowToChangeInstallationDirectory:false,
    createDesktopShortcut:'always',createStartMenuShortcut:true,shortcutName:'K99 스마트 접수 시스템',
    installerLanguages:['ko_KR'],language:'1042',
    installerIcon:path.join(__dirname,'installer/k99-reception.ico'),
    uninstallerIcon:path.join(__dirname,'installer/k99-reception.ico'),
    runAfterFinish:true,include:path.join(__dirname,'installer/data-preservation.nsh'),
  },
  publish:null,
};
