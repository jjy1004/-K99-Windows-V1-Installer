'use strict';
const path=require('node:path');
module.exports={
  appId:'com.k99.windows.v1',
  productName:'K99-Windows-V1',
  executableName:'K99-Windows-V1',
  artifactName:'K99-Windows-V1-Setup-${version}-${arch}.${ext}',
  directories:{output:path.resolve(__dirname,'../../generated-artifacts/windows-installer')},
  files:['package.json','electron/**/*.cjs','electron/assets/*.ico','electron/core/catalog.json','dist/desktop/**/*'],
  extraResources:[{from:path.resolve(__dirname,'../../generated-artifacts/windows-app/videos'),
    to:'videos',filter:['*.mp4','media-manifest.json']}],
  asar:true,asarUnpack:['**/*.node'],
  npmRebuild:true,buildDependenciesFromSource:true,
  win:{target:[{target:'nsis',arch:['x64']}],icon:path.join(__dirname,'installer/k99-reception.ico'),
    signAndEditExecutable:true},
  nsis:{
    oneClick:false,perMachine:false,allowElevation:false,deleteAppDataOnUninstall:false,
    allowToChangeInstallationDirectory:false,
    createDesktopShortcut:false,createStartMenuShortcut:false,shortcutName:'K99 스마트 접수 시스템',
    installerLanguages:['ko_KR'],language:'1042',
    installerIcon:path.join(__dirname,'installer/k99-reception.ico'),
    uninstallerIcon:path.join(__dirname,'installer/k99-reception.ico'),
    runAfterFinish:true,include:path.join(__dirname,'installer/data-preservation.nsh'),
  },
  publish:null,
};
