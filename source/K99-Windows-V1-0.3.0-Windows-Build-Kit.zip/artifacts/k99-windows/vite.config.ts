import path from 'path';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const rawPort = process.env.PORT;

if (!rawPort) {
  throw new Error(
    'PORT environment variable is required but was not provided.',
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH;

if (!basePath) {
  throw new Error(
    'BASE_PATH environment variable is required but was not provided.',
  );
}

export default defineConfig({
  base: basePath,
  plugins: [
    {
      name: 'k99-independent-local-videos',
      configureServer(server) {
        const { videoResponse } = createRequire(import.meta.url)('./electron/customer-video.cjs');
        server.middlewares.use(async (req, res, next) => {
          const pathname = new URL(req.url || '/', 'http://k99.local').pathname;
          const relative = pathname.startsWith(basePath!) ? pathname.slice(basePath!.length) : pathname.slice(1);
          if (!relative.startsWith('videos/')) return next();
          const roots = [
            path.resolve(import.meta.dirname, 'media/videos'),
            path.resolve(import.meta.dirname, '../../generated-artifacts/windows-app/videos'),
          ];
          const name = relative.slice('videos/'.length);
          const root = roots.find(dir => fs.existsSync(path.join(dir, name))) || roots[0];
          try {
            const response = await videoResponse(new Request(`http://k99.local/${relative}`, {
              method: req.method, headers: req.headers.range ? { range: req.headers.range } : {},
            }), root);
            res.statusCode = response.status;
            response.headers.forEach((value: string, key: string) => res.setHeader(key, value));
            res.end(Buffer.from(await response.arrayBuffer()));
          } catch { res.statusCode = 500; res.end('Local video read failed'); }
        });
      },
    },
    react(),
    tailwindcss(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== 'production' &&
    process.env.REPL_ID !== undefined
      ? [
          await import('@replit/vite-plugin-cartographer').then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, '..'),
            }),
          ),
          await import('@replit/vite-plugin-dev-banner').then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, 'src'),
      '@assets': path.resolve(
        import.meta.dirname,
        '..',
        '..',
        'attached_assets',
      ),
    },
    dedupe: ['react', 'react-dom'],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, 'dist/public'),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: '0.0.0.0',
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  preview: {
    port,
    host: '0.0.0.0',
    allowedHosts: true,
  },
});
