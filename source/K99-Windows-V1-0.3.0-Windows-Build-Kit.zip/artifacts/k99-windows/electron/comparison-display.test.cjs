'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createCustomerDisplay}=require('./customer-display.cjs');
function fixture(single=false){
  const sent=[],revoked=[],windows=[],screen=new EventEmitter();let controller;
  const displays=[{id:1,label:'직원',bounds:{x:0,y:0,width:1920,height:1080}},
    {id:2,label:'LG FULL HD',bounds:{x:1920,y:0,width:1920,height:1080}}];
  screen.getPrimaryDisplay=()=>displays[0];screen.getAllDisplays=()=>single?displays.slice(0,1):displays;
  class Window extends EventEmitter{
    constructor(options){super();this.options=options;this.calls=[];this.destroyed=false;
      this.webContents=new EventEmitter();this.webContents.send=(channel,data)=>this.calls.push({channel,data});
      this.webContents.setWindowOpenHandler=()=>{};windows.push(this);}
    async loadURL(){process.nextTick(()=>controller.customerEvent(this.webContents,{type:'CUSTOMER_READY'}));}
    isDestroyed(){return this.destroyed;}isMinimized(){return true;}setBounds(v){this.bounds=v;}
    restore(){this.restored=true;}show(){this.shown=true;}focus(){this.focused=true;}
    setAlwaysOnTop(value){this.top=value;}setFullScreen(value){this.full=value;}
    close(){this.emit('close');this.destroyed=true;this.emit('closed');}
  }
  controller=createCustomerDisplay({BrowserWindow:Window,screen,getMain:()=>({webContents:{send:(channel,data)=>sent.push({channel,data})}}),
    preload:'test',changed:()=>{},onComparisonClosed:id=>revoked.push(id)});
  return {controller,sent,revoked,windows};
}
const gallery=()=>({id:'gallery-session',orderId:'A',customerName:'검증 고객',index:0,photos:[
  {id:'photo1',name:'전후1',url:'k99://app/comparison-photos/11111111-1111-1111-1111-111111111111'},
  {id:'photo2',name:'전후2',url:'k99://app/comparison-photos/22222222-2222-2222-2222-222222222222'}]});
test('secondary display is opened in native fullscreen and real image ACK is separate from ready',async()=>{
  const f=fixture(),result=await f.controller.showComparison(gallery()),win=f.windows[0];
  assert.equal(result.shown,true);assert.equal(win.options.x,1920);assert.equal(win.full,true);
  assert.equal(win.top,true);assert.equal(win.restored,true);assert.equal(win.focused,true);
  assert.equal(f.sent.some(v=>v.data.type==='COMPARISON_STATUS'),false);
  f.controller.customerEvent({}, {type:'COMPARISON_ACK',sessionId:'gallery-session',photoId:'photo1',loaded:true});
  assert.equal(f.sent.some(v=>v.data.type==='COMPARISON_STATUS'),false);
  f.controller.customerEvent(win.webContents,{type:'COMPARISON_ACK',sessionId:'gallery-session',photoId:'photo1',loaded:true});
  assert.equal(f.sent.at(-1).data.loaded,true);
  f.controller.action({type:'snapshot',payload:{sourceId:'another-tab',rows:[]}});
  assert.equal(win.top,true);assert.equal(f.revoked.length,0);
});
test('staff and customer arrows share one index; close releases topmost and returns idle loop',async()=>{
  const f=fixture();await f.controller.showComparison(gallery());const win=f.windows[0];
  assert.equal(f.controller.controlComparison('gallery-session','next').gallery.index,1);
  f.controller.customerEvent(win.webContents,{type:'COMPARISON_CONTROL',sessionId:'gallery-session',direction:'previous'});
  assert.equal(win.calls.at(-1).data.gallery.index,0);
  f.controller.customerEvent(win.webContents,{type:'COMPARISON_CONTROL',sessionId:'gallery-session',direction:'close'});
  assert.equal(win.calls.at(-1).data.command.video,'idle');assert.equal(win.top,false);
  assert.equal(win.full,true);assert.equal(win.destroyed,false);assert.deepEqual(f.revoked,['gallery-session']);
  assert.equal(f.controller.controlComparison('gallery-session','next'),null);
});
test('single monitor does not create or move any customer window',async()=>{
  const f=fixture(true),result=await f.controller.showComparison(gallery());
  assert.equal(result.shown,false);assert.equal(f.windows.length,0);
});
test('manual video and reload close image state without replaying stale commands',async()=>{
  const f=fixture();await f.controller.showComparison(gallery());const win=f.windows[0];
  f.controller.action({type:'video',command:{id:'guide-new',issuedAt:Date.now(),video:'process'}});
  assert.equal(win.calls.at(-1).data.command.video,'process');assert.deepEqual(f.revoked,['gallery-session']);
  await f.controller.showComparison({...gallery(),id:'second-session'});
  win.webContents.emit('did-start-loading');assert.equal(f.revoked.at(-1),'second-session');assert.equal(win.top,false);
  f.controller.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  assert.equal(f.controller.controlComparison('second-session','close'),null);
});
test('invalid image URLs cannot become a native gallery command',async()=>{
  const f=fixture(),g=gallery();g.photos[0].url='file:///C:/private.jpg';
  await assert.rejects(()=>f.controller.showComparison(g),/잘못된/);assert.equal(f.windows.length,0);
});
