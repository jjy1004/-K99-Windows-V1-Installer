'use strict';
const {classifyCareLabel}=require('./services/labelService.cjs');
async function optionalLabel(photoId,{readPhoto,classify=classifyCareLabel,allowLoopback=false,timeoutMs=3000}){
  let timer;
  try{
    const photo=readPhoto(photoId);
    const result=await Promise.race([
      classify(photo.bytes,{mimeType:photo.contentType,allowLoopback,timeoutMs:Math.min(3000,timeoutMs)}).catch(()=>null),
      new Promise(resolve=>{timer=setTimeout(()=>resolve(null),Math.min(3000,timeoutMs));}),
    ]);
    return typeof result?.raw_material==='string'&&result.raw_material.length<=1000?{raw_material:result.raw_material}:null;
  }catch{return null;}finally{clearTimeout(timer);}
}
module.exports={optionalLabel};
