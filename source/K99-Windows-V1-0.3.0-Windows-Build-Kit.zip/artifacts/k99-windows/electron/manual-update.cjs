'use strict';
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const REPO='jjy1004/-K99-Windows-V1-Installer',FILENAME='K99-Smart-Laundry-V2-Setup.exe';
function newer(a,b){
  const parse=s=>{if(!/^\d+\.\d+\.\d+$/.test(s))throw Error('정식 업데이트 버전을 확인하지 못했습니다.');return s.split('.').map(Number);};
  const aa=parse(a),bb=parse(b);for(let i=0;i<3;i++){if(aa[i]!==bb[i])return aa[i]>bb[i];}return false;
}
function createManualUpdate({version,fetch:request=globalThis.fetch,temp=os.tmpdir(),canInstall,prepare,quit,onInstalling=()=>()=>{},
  spawn=require('node:child_process').spawn,pid=process.pid,onState=()=>{}}){
  let state={phase:'idle',percent:0},running=false,ready=false,file='',directory='',controller,waiter,launched=false,releaseLock=()=>{};
  const publish=next=>{state={...next};onState({...state});};
  async function json(url){const r=await request(url,{headers:{'User-Agent':'K99-Manual-Update'},signal:controller.signal});
    if(!r.ok)throw Error('최신 설치본 정보를 내려받지 못했습니다.');return r.json();}
  async function run(){
    if(running||ready)return;
    running=true;controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),15*60*1000);timeout.unref?.();
    try{
      publish({phase:'checking',percent:0});
      const release=await json(`https://api.github.com/repos/${REPO}/releases/latest`);
      const next=String(release.tag_name||'').replace(/^v/,'');
      if(release.draft||release.prerelease)throw Error('정식 릴리스가 아닙니다.');
      if(!newer(next,version)){publish({phase:'current',version:next,percent:100});return;}
      const asset=name=>release.assets?.find(a=>a.name===name&&a.state==='uploaded');
      const exe=asset(FILENAME),meta=asset('installer-release.json');
      const valid=a=>a&&typeof a.browser_download_url==='string'&&a.browser_download_url.startsWith(`https://github.com/${REPO}/releases/download/`);
      if(!valid(exe)||!valid(meta)||!Number.isSafeInteger(exe.size)||exe.size<1024||exe.size>1024**3)throw Error('검증 가능한 설치 파일이 없습니다.');
      const manifest=await json(meta.browser_download_url);
      if(manifest.version!==next||manifest.filename!==FILENAME||manifest.bytes!==exe.size||!/^[a-f0-9]{64}$/i.test(manifest.sha256))
        throw Error('설치 파일의 버전·크기·체크섬 정보가 일치하지 않습니다.');
      directory=await fsp.mkdtemp(path.join(temp,'K99-Update-'));
      file=path.join(directory,FILENAME);const partial=file+'.partial',hash=crypto.createHash('sha256');
      const response=await request(exe.browser_download_url,{signal:controller.signal});
      if(!response.ok||!response.body)throw Error('설치 파일 다운로드를 시작하지 못했습니다.');
      let bytes=0;const handle=await fsp.open(partial,'wx',0o600);
      publish({phase:'downloading',percent:0,version:next});
      try{for await(const chunk of response.body){const b=Buffer.from(chunk);bytes+=b.length;
        if(bytes>exe.size)throw Error('설치 파일 크기가 예상보다 큽니다.');
        hash.update(b);let offset=0;while(offset<b.length){const written=await handle.write(b,offset,b.length-offset);if(!written.bytesWritten)throw Error('임시 파일 저장 실패');offset+=written.bytesWritten;}
        publish({phase:'downloading',version:next,percent:Math.min(99,Math.floor(bytes/exe.size*100))});
      }await handle.sync();}finally{await handle.close();}
      if(bytes!==exe.size||hash.digest('hex')!==manifest.sha256.toLowerCase())throw Error('설치 파일 검증에 실패했습니다. 기존 버전을 유지합니다.');
      await fsp.rename(partial,file);
      publish({phase:'verifying',version:next,percent:100});
      if(!canInstall())throw Error('진행 중인 접수를 완료하거나 초안을 정리하고 저장·촬영·발송이 끝난 뒤 업데이트를 다시 눌러 주세요.');
      const snapshot=await prepare();
      if(snapshot?.verified!==true||!canInstall())throw Error('안전 백업 또는 작업 저장을 확인하지 못했습니다. 기존 버전을 유지합니다.');
      // Verify again after preparation. A failed or modified executable is never run.
      const diskHash=crypto.createHash('sha256');
      for await(const chunk of fs.createReadStream(file))diskHash.update(chunk);
      if(diskHash.digest('hex')!==manifest.sha256.toLowerCase())throw Error('설치 파일이 변경되었습니다.');
      if(!canInstall())throw Error('새 접수·저장 작업이 시작되어 업데이트를 멈췄습니다. 업무를 마친 뒤 다시 눌러 주세요.');
      releaseLock=onInstalling();
      ready=true;await launchAfterExit();
      publish({phase:'installing',version:next,percent:100});quit();
      const quitDeadline=setTimeout(()=>{
        if(ready){ready=false;launched=false;try{waiter?.kill();}catch{}releaseLock();publish({phase:'error',error:'프로그램 종료가 취소되었습니다. 업무를 마친 뒤 업데이트를 다시 눌러 주세요.'});}
      },5000);quitDeadline.unref?.();
    }catch(error){
      ready=false;launched=false;try{waiter?.kill();}catch{}releaseLock();
      publish({phase:'error',percent:0,error:error?.message||'업데이트에 실패했습니다. 기존 버전을 유지합니다.'});
      if(directory)await fsp.rm(directory,{recursive:true,force:true}).catch(()=>{});
    }finally{clearTimeout(timeout);running=false;}
  }
  async function launchAfterExit(){
    if(!ready)return false;if(launched)return true;
    const quote=s=>"'"+s.replace(/'/g,"''")+"'";
    const script=`$ErrorActionPreference='Stop'; try { Wait-Process -Id ${Number(pid)} -Timeout 120 -ErrorAction SilentlyContinue } catch {}; if(Get-Process -Id ${Number(pid)} -ErrorAction SilentlyContinue){exit 1}; Start-Process -FilePath ${quote(file)}`;
    await new Promise((resolve,reject)=>{
      waiter=spawn('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],
        {detached:true,windowsHide:true,stdio:'ignore'});
      waiter.once('error',reject);waiter.once('spawn',()=>{launched=true;waiter.unref();resolve();});
    });return true;
  }
  return {check(){void run();return {...state};},status:()=>({...state}),isInstalling:()=>ready,launchAfterExit};
}
module.exports={createManualUpdate,newer,FILENAME};
