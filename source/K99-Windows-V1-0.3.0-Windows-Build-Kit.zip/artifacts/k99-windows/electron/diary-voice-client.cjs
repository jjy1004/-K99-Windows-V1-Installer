'use strict';
const fs=require('node:fs'),path=require('node:path');
const DEFAULT_VOICE_SERVER='https://k-99-windows-v-1.replit.app';
function serverUrl(value){
  const u=new URL(String(value||DEFAULT_VOICE_SERVER));
  if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/'||
    /^(localhost|127\.|0\.|169\.254\.|10\.|192\.168\.|\[|::)/i.test(u.hostname))
    throw Error('게시된 HTTPS 음성 서버의 기본 주소를 입력해 주세요.');
  return u.origin;
}
function createDiaryVoiceClient({file,safeStorage,store,fetchImpl=globalThis.fetch,env=process.env}){
  let active=false;
  function config(){
    let data={};
    if(fs.existsSync(file))data=JSON.parse(fs.readFileSync(file,'utf8'));
    let token=env.K99_DIARY_VOICE_ACCESS_TOKEN||'';
    if(!token&&data.encryptedToken){
      if(!safeStorage.isEncryptionAvailable())throw Error('Windows 보안 저장소를 사용할 수 없습니다.');
      token=safeStorage.decryptString(Buffer.from(data.encryptedToken,'base64'));
    }
    return {url:serverUrl(env.K99_DIARY_VOICE_SERVER_URL||data.url),token};
  }
  function state(){const c=config();return {url:c.url,tokenConfigured:Boolean(c.token),
    urlOverridden:Boolean(env.K99_DIARY_VOICE_SERVER_URL),tokenOverridden:Boolean(env.K99_DIARY_VOICE_ACCESS_TOKEN)};}
  function configure(input){
    const url=serverUrl(input.url);
    if(input.token!==undefined&&(typeof input.token!=='string'||!/^[\x21-\x7e]{24,512}$/.test(input.token)))
      throw Error('본사에서 발급받은 음성 서비스 접근 코드를 입력하세요. AI 공급자 API 키는 입력하지 않습니다.');
    let data={};if(fs.existsSync(file))data=JSON.parse(fs.readFileSync(file,'utf8'));
    if(input.token!==undefined){
      if(!safeStorage.isEncryptionAvailable())throw Error('보안 저장을 사용할 수 없어 접근 코드를 저장하지 않았습니다.');
      data.encryptedToken=safeStorage.encryptString(input.token).toString('base64');
    }
    data.url=url;fs.mkdirSync(path.dirname(file),{recursive:true});
    const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(data),{mode:0o600});
    fs.renameSync(tmp,file);return state();
  }
  async function request(action,input={}){
    if(action==='status')return state();
    if(action==='configure')return configure(input);
    if(!['transcribe','organize'].includes(action))throw Error('지원하지 않는 음성 요청입니다.');
    if(active)throw Error('음성을 처리 중입니다. 잠시 기다려 주세요.');
    if(action==='transcribe'&&(typeof input.audio_base64!=='string'||input.audio_base64.length>14000000||input.audio_base64.length<60))
      throw Error('녹음 용량을 확인해 주세요.');
    if(action==='organize'&&(typeof input.raw_text!=='string'||!input.raw_text.trim()||input.raw_text.length>20000))
      throw Error('전사 원문은 2만 자 이내여야 합니다.');
    const {url,token}=config();
    active=true;
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),200000);
    try{
      const context=store().api('POST','/api/diaries/voice/context',{});
      const body=action==='transcribe'?{audio_base64:input.audio_base64,context}:{raw_text:input.raw_text,context};
      const response=await fetchImpl(`${url}/api/openai/diary-voice/${action}`,{
        method:'POST',redirect:'error',signal:controller.signal,
        headers:{'Content-Type':'application/json',...(token?{'Authorization':`Bearer ${token}`}:{})},body:JSON.stringify(body)});
      if(!String(response.headers.get('content-type')||'').includes('application/json'))
        throw Error('음성 서버가 아직 게시되지 않았거나 접속이 제한되어 있습니다.');
      const length=Number(response.headers.get('content-length')||0);
      if(length>200000)throw Error('음성 서버 응답이 너무 큽니다.');
      const reader=response.body?.getReader();if(!reader)throw Error('음성 서버 응답이 없습니다.');
      const chunks=[];let total=0;
      for(;;){const {done,value}=await reader.read();if(done)break;total+=value.byteLength;
        if(total>200000){await reader.cancel();throw Error('음성 서버 응답이 너무 큽니다.');}chunks.push(Buffer.from(value));}
      const result=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if(!response.ok)throw Error(typeof result.error==='string'?result.error.slice(0,300):'음성 서버 처리 실패');
      if(typeof result.text!=='string'||!result.text.trim()||result.text.length>20000)throw Error('음성 서버 문장 형식이 올바르지 않습니다.');
      return {text:result.text.trim()};
    }catch(error){
      if(error.name==='AbortError')throw Error('음성 서버 응답이 지연됩니다. 녹음은 보관되어 있으니 다시 시도하세요.');
      if(error instanceof TypeError)throw Error('음성 서버에 연결하지 못했습니다. 인터넷 연결과 서버 게시 상태를 확인하세요.');
      throw error;
    }finally{active=false;clearTimeout(timer);}
  }
  return {request};
}
function installDiaryVoice({ipcMain,trusted,isStaff,client}){
  ipcMain.handle('k99:diary-voice',async(event,input)=>{
    try{
      trusted(event);if(!isStaff(event.sender))throw Error('직원 화면에서만 사용할 수 있습니다.');
      if(!input||typeof input.action!=='string')throw Error('잘못된 음성 요청입니다.');
      return {ok:true,result:await client.request(input.action,input)};
    }catch(error){return {ok:false,error:error.message};}
  });
}
module.exports={createDiaryVoiceClient,installDiaryVoice,serverUrl,DEFAULT_VOICE_SERVER};
