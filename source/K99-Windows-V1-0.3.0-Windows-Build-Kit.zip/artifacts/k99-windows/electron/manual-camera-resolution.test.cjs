'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createRequire}=require('node:module'),ts=createRequire(path.join(__dirname,'../package.json'))('typescript');
const api={};
new Function('exports',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/manual-camera-resolution.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(api);
function stream(w=1920,h=1080,id='su'){
  const track={readyState:'live',getSettings:()=>({deviceId:id,width:w,height:h}),stop(){this.readyState='ended';}};
  return {w,h,getTracks:()=>[track],getVideoTracks:()=>[track]};
}
function video(initial,fail){
  let current=initial;
  return {muted:true,playsInline:true,get srcObject(){return current;},set srcObject(v){current=v;},
    get videoWidth(){return current?.w||0;},get videoHeight(){return current?.h||0;},
    get readyState(){return current?2:0;},
    async play(){if(fail&&current!==initial)throw Error('visible decoder failed');},pause(){}};
}
function options(old,candidate){
  const v=video(old),calls=[],state={stream:old,freeze:0};
  return {video:v,oldStream:old,deviceId:'su',width:2560,height:1440,timeoutMs:40,
    media:{getUserMedia:async c=>{calls.push(c);return candidate;}},
    current:()=>state.stream===old&&old.getTracks()[0].readyState==='live',
    createVideo:()=>video(null),commit:s=>{state.stream=s;},
    freeze:()=>{state.freeze++;return()=>{state.freeze--;};},calls,state};
}
for(const [name,w,h] of [['HD',1280,720],['FHD',1920,1080],['2K',2560,1440]]){
  test(`${name}: first frame is verified before releasing the previous working stream`,async()=>{
    const old=stream(640,480),candidate=stream(w,h),o=options(old,candidate);
    o.width=w;o.height=h;
    const commit=o.commit;
    o.commit=s=>{assert.equal(old.getTracks()[0].readyState,'live');assert.equal(o.video.srcObject,candidate);commit(s);};
    await api.changeCameraResolution(o);
    assert.equal(o.state.stream,candidate);assert.equal(old.getTracks()[0].readyState,'ended');
    assert.equal(candidate.getTracks()[0].readyState,'live');assert.equal(o.state.freeze,0);
    assert.deepEqual(o.calls[0],{audio:false,video:{deviceId:'su',width:{ideal:w},height:{ideal:h}}});
  });
}
test('unsupported dimensions keep the original preview and stream alive',async()=>{
  const old=stream(),candidate=stream(1280,720),o=options(old,candidate);
  await assert.rejects(api.changeCameraResolution(o),/지원하지/);
  assert.equal(o.video.srcObject,old);assert.equal(o.state.stream,old);
  assert.equal(old.getTracks()[0].readyState,'live');assert.equal(candidate.getTracks()[0].readyState,'ended');
});
test('busy single-stream UVC driver preserves the old picture without retrying another camera',async()=>{
  const old=stream(),o=options(old);
  o.media.getUserMedia=async()=>{throw Object.assign(Error('device busy'),{name:'NotReadableError'});};
  await assert.rejects(api.changeCameraResolution(o),/device busy/);
  assert.equal(o.video.srcObject,old);assert.equal(old.getTracks()[0].readyState,'live');
});
test('a browser returning another device cannot replace the selected UVC camera',async()=>{
  const old=stream(),candidate=stream(2560,1440,'obs'),o=options(old,candidate);
  await assert.rejects(api.changeCameraResolution(o),/다른 카메라/);
  assert.equal(o.video.srcObject,old);assert.equal(candidate.getTracks()[0].readyState,'ended');
});
test('a candidate with no decoded frames is rejected without clearing the original picture',async()=>{
  const old=stream(),candidate=stream(0,0),o=options(old,candidate);
  await assert.rejects(api.changeCameraResolution(o),/영상이 준비되지/);
  assert.equal(o.video.srcObject,old);assert.equal(old.getTracks()[0].readyState,'live');
});
test('visible decoder failure restores the never-stopped old stream and releases frozen overlay',async()=>{
  const old=stream(),candidate=stream(2560,1440),o=options(old,candidate);
  o.video=video(old,true);
  await assert.rejects(api.changeCameraResolution(o),/decoder failed/);
  assert.equal(o.video.srcObject,old);assert.equal(o.state.stream,old);assert.equal(o.state.freeze,0);
  assert.equal(old.getTracks()[0].readyState,'live');assert.equal(candidate.getTracks()[0].readyState,'ended');
});
test('a timed-out getUserMedia result is eventually stopped, never committed',async()=>{
  const old=stream(),candidate=stream(2560,1440),o=options(old,candidate);
  let deliver;o.media.getUserMedia=()=>new Promise(resolve=>{deliver=resolve;});
  await assert.rejects(api.changeCameraResolution(o),/응답이 없어/);
  deliver(candidate);await new Promise(setImmediate);
  assert.equal(candidate.getTracks()[0].readyState,'ended');assert.equal(o.video.srcObject,old);
});
test('closing or switching cameras cancels a provisional stream without resurrecting the old screen',async()=>{
  const old=stream(),candidate=stream(2560,1440),o=options(old,candidate);
  let deliver,live=true;o.current=()=>live;
  o.media.getUserMedia=()=>new Promise(resolve=>{deliver=resolve;});
  const pending=api.changeCameraResolution(o);live=false;o.video.srcObject=null;old.getTracks()[0].stop();deliver(candidate);
  await assert.rejects(pending,/취소/);assert.equal(o.video.srcObject,null);
  assert.equal(candidate.getTracks()[0].readyState,'ended');
});
test('request failures never invoke the visible-window commit callback',async()=>{
  const old=stream(),o=options(old);let commits=0;o.commit=()=>{commits++;};
  o.media.getUserMedia=async()=>{throw Error('permission denied');};
  await assert.rejects(api.changeCameraResolution(o),/permission denied/);
  assert.equal(commits,0);assert.equal(old.getTracks()[0].readyState,'live');
});
