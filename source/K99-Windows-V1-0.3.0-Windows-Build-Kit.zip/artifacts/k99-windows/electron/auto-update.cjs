'use strict';

// No database paths or migrations belong here. The existing manager owns backups
// and shutdown; the updater replaces only the installed application.
const RELEASE_FEED=Object.freeze({
  provider:'github',owner:'jjy1004',repo:'-K99-Windows-V1-Installer',private:false,
});

function createAutoUpdate({updater,enabled,canInstall,backup,onError=()=>{},onState=()=>{},beforeInstall=async()=>{},
  setTimeout:later=setTimeout,clearTimeout:cancel=clearTimeout,
  setInterval:repeat=setInterval,clearInterval:stopRepeat=clearInterval}) {
  let started=false,disposed=false,checking=false,downloaded=false;
  let used=false,installing=false,preparing=false,skipQuit=false;
  let startupTimer,retryTimer,installTimer;
  const listeners=[];
  const listen=(name,fn)=>{updater.on(name,fn);listeners.push([name,fn]);};
  const publish=state=>{try{onState(state);}catch{}};
  const report=()=>{publish({phase:'error'});try{onError('자동 업데이트를 완료하지 못했습니다. 기존 버전으로 계속 사용할 수 있습니다.');}catch{}};
  const unref=timer=>{timer?.unref?.();return timer;};
  async function install({quitting=false}={}) {
    if(disposed||!downloaded||installing||preparing||(!quitting&&used)||!canInstall())return false;
    preparing=true;
    try {
      publish({phase:'installing'});
      await beforeInstall();
      if(disposed||(!quitting&&used)||!canInstall()){
        publish({phase:'ready',deferred:true});return false;
      }
      const snapshot=await backup();
      if(snapshot?.verified!==true)throw Error('검증된 업데이트 전 백업이 필요합니다.');
      // Input or local writes may have arrived while the backup was running.
      if(disposed||(!quitting&&used)||!canInstall()){
        publish({phase:'ready',deferred:true});return false;
      }
      installing=true;
      updater.quitAndInstall(true,true);
      return true;
    } catch {
      installing=false;
      report();
      return false;
    } finally {preparing=false;}
  }
  async function check() {
    if(!started||disposed||checking||downloaded)return;
    checking=true;
    try{await updater.checkForUpdates();}catch{report();}
    finally{checking=false;}
  }
  function start() {
    if(started||!enabled)return;
    started=true;
    updater.autoDownload=true;
    // Use our verified backup + existing session flush rather than the
    // updater's unconditional quit hook.
    updater.autoInstallOnAppQuit=false;
    updater.autoRunAppAfterInstall=true;
    updater.allowDowngrade=false;
    updater.allowPrerelease=false;
    updater.setFeedURL({...RELEASE_FEED});
    listen('error',report);
    listen('update-available',info=>publish({phase:'downloading',version:info?.version}));
    listen('download-progress',progress=>publish({phase:'downloading',
      percent:Number.isFinite(progress?.percent)?Math.min(100,Math.max(0,progress.percent)):0}));
    listen('update-downloaded',()=>{
      downloaded=true;
      publish({phase:'ready',deferred:used});
      if(!used&&!installTimer)installTimer=unref(later(()=>{installTimer=null;void install();},60000));
    });
    startupTimer=unref(later(()=>void check(),15000));
    retryTimer=unref(repeat(()=>void check(),6*60*60*1000));
  }
  function noteUserActivity() {
    used=true;
    if(installTimer){cancel(installTimer);installTimer=null;}
    if(downloaded&&!installing)publish({phase:'ready',deferred:true});
  }
  // Called only after the existing AI/browser session shutdown has completed.
  // If backup fails, close normally WITHOUT installing this update.
  function beforeQuit(event,quitWithoutUpdate) {
    if(!downloaded||installing||skipQuit||disposed)return false;
    if(preparing){event.preventDefault();return true;}
    event.preventDefault();
    void install({quitting:true}).then(ok=>{
      if(!ok){skipQuit=true;quitWithoutUpdate();}
    });
    return true;
  }
  function dispose() {
    disposed=true;cancel(startupTimer);cancel(installTimer);stopRepeat(retryTimer);
    for(const [event,handler] of listeners)updater.removeListener(event,handler);
  }
  return {start,check,noteUserActivity,beforeQuit,dispose,
    status:()=>({enabled:!!enabled,started,downloaded,used,installing})};
}
module.exports={createAutoUpdate,RELEASE_FEED};
