'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createRequire}=require('node:module'),runtime=createRequire(path.join(__dirname,'../package.json'));
const ts=runtime('typescript'),mod={exports:{}};
new Function('exports',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/camera-viewport.ts'),'utf8'),
  {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(mod.exports);
const {cameraCrop,panCamera,drawCameraView,createZoomHold,clampZoom,INITIAL_CAMERA_VIEW}=mod.exports;
const view=zoom=>({...INITIAL_CAMERA_VIEW,zoom});
test('zoom is limited to 1.0–3.5',()=>{assert.equal(clampZoom(-1),1);assert.equal(clampZoom(7),3.5);});
test('1x shows centered cover, including a 4:3 camera in a 16:9 viewport',()=>{
  const c=cameraCrop(1600,1200,1600,900,view(1));
  assert.deepEqual(c,{x:0,y:150,width:1600,height:900,baseWidth:1600,baseHeight:900});
});
test('3.5x uses the corresponding centered source rectangle without distorting aspect',()=>{
  const c=cameraCrop(1920,1080,960,540,view(3.5));
  assert.ok(Math.abs(c.width-1920/3.5)<1e-8);assert.ok(Math.abs(c.height-1080/3.5)<1e-8);
  assert.equal(c.x+c.width/2,960);assert.equal(c.y+c.height/2,540);
});
test('pan follows the drag and cannot expose black edges',()=>{
  let state=panCamera(view(2),100,50,1920,1080,960,540);
  assert.ok(state.cx<0.5&&state.cy<0.5);
  state=panCamera(state,1e6,-1e6,1920,1080,960,540);
  const c=cameraCrop(1920,1080,960,540,state);assert.equal(c.x,0);assert.equal(c.y+c.height,1080);
  assert.deepEqual(panCamera(view(1),300,300,1920,1080,960,540),INITIAL_CAMERA_VIEW);
});
test('portrait source cover crop and pan stay inside actual source bounds',()=>{
  const state=panCamera(view(3.5),-99999,99999,1080,1920,960,540);
  const c=cameraCrop(1080,1920,960,540,state);
  assert.ok(c.x>=0&&c.y>=0&&c.x+c.width<=1080.00001&&c.y+c.height<=1920.00001);
  assert.ok(Math.abs(c.width/c.height-16/9)<1e-8);
});
test('saved canvas uses the same crop and native-resolution output as live cover preview',()=>{
  let args;const context={canvas:{},drawImage(...input){args=input;}};
  const video={videoWidth:1920,videoHeight:1080},state={zoom:2.2,cx:0.65,cy:0.4};
  drawCameraView(context,video,960,540,state);const crop=cameraCrop(1920,1080,960,540,state);
  assert.deepEqual(args,[video,crop.x,crop.y,crop.width,crop.height,0,0,1920,1080]);
  assert.equal(context.imageSmoothingQuality,'high');
});
test('unready image dimensions fail before saving an empty canvas',()=>{
  assert.throws(()=>cameraCrop(0,1080,960,540,view(2)),/크기가 준비/);
});
function clock(){
  let now=0,id=0,zoom=2,calls=0;const frames=new Map();
  const hold=createZoomHold({now:()=>now,request:callback=>{frames.set(++id,callback);return id;},cancel:id=>frames.delete(id),
    increase:delta=>{zoom=clampZoom(zoom+delta);calls++;},tap:()=>{zoom=1;}});
  return {hold,step(ms){now+=ms;const batch=[...frames.values()];frames.clear();batch.forEach(cb=>cb(now));},
    get zoom(){return zoom;},get calls(){return calls;},get frames(){return frames.size;}};
}
test('F8 ignores OS repeat and begins continuous zoom only after 200ms',()=>{
  const c=clock();c.hold.start('F8');c.step(199);assert.equal(c.zoom,2);
  c.hold.start('F8');assert.equal(c.frames,1);
  c.step(101);assert.equal(c.zoom,2.1);
  c.step(100);assert.ok(Math.abs(c.zoom-2.2)<1e-8);
  c.hold.end('F8');const fixed=c.zoom;c.step(500);assert.equal(c.zoom,fixed);assert.equal(c.frames,0);
});
test('short F8 tap returns to 1x without waiting for a frame',()=>{
  const c=clock();c.hold.start('F8');c.step(80);c.hold.end('F8');assert.equal(c.zoom,1);assert.equal(c.frames,0);
});
test('mouse and pedal share a single hold stream, not doubled zoom rates',()=>{
  const c=clock();c.hold.start('mouse');c.hold.start('F8');c.step(500);assert.equal(c.zoom,2.3);
  c.hold.end('mouse');assert.equal(c.frames,1);c.step(100);assert.equal(c.calls,2);
  c.hold.end('F8');assert.equal(c.frames,0);
});
test('cancel on blur, next garment or close stops movement without an unintended tap reset',()=>{
  const c=clock();c.hold.start('F8');c.step(700);c.hold.cancel();const zoom=c.zoom;
  c.hold.end('F8');c.step(1000);assert.equal(c.zoom,zoom);assert.equal(c.frames,0);
});
test('long press clamps at 3.5x',()=>{
  const c=clock();c.hold.start('F8');c.step(10000);assert.equal(c.zoom,3.5);c.hold.end('F8');
});
test('F9 cannot finalize reception; capture uses the shared viewport crop',()=>{
  const src=fs.readFileSync(path.join(__dirname,'../src/NativeDraftCamera.tsx'),'utf8');
  assert.match(src,/const key=captureShortcut\(event\)/);
  assert.match(src,/key==='F9'\)keysRef.current.nextGarment\(\)/);
  assert.doesNotMatch(src,/key==='F9'\).*finalConfirm/);
  assert.match(src,/viewport.capture\(g, v\)/);
  assert.match(src,/onClick=\{finalConfirm\} data-testid="button-camera-final"/);
});
