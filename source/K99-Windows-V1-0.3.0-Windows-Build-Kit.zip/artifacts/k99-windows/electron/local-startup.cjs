'use strict';
// Only the local renderer is a startup prerequisite. Device discovery and
// secondary windows can be slow and must not hold the staff screen hostage.
async function startLocalDesktop({loadMain,configurePrinter,restoreCustomer,onPrinterError,onCustomerError}){
  await loadMain();
  const background=(work,onError)=>Promise.resolve().then(work).catch(error=>{
    try{onError(error);}catch{/* Diagnostics must not create unhandled rejections. */}
  });
  void background(configurePrinter,onPrinterError);
  void background(restoreCustomer,onCustomerError);
}
module.exports={startLocalDesktop};
