'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {deployBundledCalculator}=require('./bundled-calculator.cjs');
test('optional calculator bundle copies dependencies without replacing existing installation',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-calculator-'));
  try{
    const source=path.join(root,'bundle'),target=path.join(root,'shop');
    assert.equal(deployBundledCalculator(source,target).available,false);
    fs.mkdirSync(path.join(source,'resources'),{recursive:true});
    fs.writeFileSync(path.join(source,'K99-Laundry-Calculator.exe'),'test fixture, not executable');
    fs.writeFileSync(path.join(source,'resources','app.asar'),'test');
    assert.equal(deployBundledCalculator(source,target).copied,2);
    fs.writeFileSync(path.join(source,'resources','app.asar'),'updated');
    assert.equal(deployBundledCalculator(source,target).preserved,true);
    assert.equal(fs.readFileSync(path.join(target,'resources','app.asar'),'utf8'),'test');
  }finally{fs.rmSync(root,{recursive:true,force:true});}
});
