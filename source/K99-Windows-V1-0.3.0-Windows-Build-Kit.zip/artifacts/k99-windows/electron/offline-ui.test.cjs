'use strict';
require('node:test').test('portable packaging compiles the latest React before staging the renderer',()=>{
  const assert=require('node:assert/strict'),path=require('node:path');
  const text=require('node:fs').readFileSync(path.resolve(__dirname,'../../../scripts/build-windows-portable.cjs'),'utf8');
  const compile=text.indexOf("run('pnpm',['--filter','@workspace/k99-windows','run','desktop:build'],root)");
  const stage=text.indexOf("require('./stage-windows-app.cjs').stage()");
  assert.ok(compile>=0&&stage>compile,'A fresh desktop build must precede every staging operation.');
});
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const runtime=createRequire(path.join(__dirname,'../package.json')),ts=runtime('typescript');
function load(name){
const source=fs.readFileSync(path.join(__dirname,`../src/${name}.tsx`),'utf8'),moduleForTest={exports:{}};
const localRequire=id=>id.endsWith('.css')?{}:id==='./manual-label'?load('manual-label'):runtime(id);
new Function('require','module','exports',ts.transpileModule(source,{compilerOptions:{
  module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,
}}).outputText)(localRequire,moduleForTest,moduleForTest.exports);
return moduleForTest.exports;
}
const {normalizeLabelSelection}=load('manual-label'),{ReceptionSidebar}=load('ReceptionSidebar');
function buttons(element){
  if(!element||typeof element!=='object')return [];
  if(element.type==='button')return [element];
  return [element.props?.children].flat(Infinity).flatMap(buttons);
}
test('all six one-click controls stay active and bind controlled selections without any AI state',()=>{
  let value=normalizeLabelSelection();
  assert.deepEqual(value,{manualMaterial:'폴리에스테르',manualColor:'유색'});
  const render=()=>buttons(ReceptionSidebar({labelSelection:value,onLabelSelection:next=>{value=next;},
    mobilePanel:null,onOpenCamera:()=>{},onFinalConfirm:()=>{}})).filter(b=>b.props['data-label-choice']);
  const controls=render();assert.equal(controls.length,6);
  for(const b of controls){assert.equal(b.props.disabled,undefined);assert.equal(b.props.type,'button');}
  render().find(b=>b.props.children==='울/실크').props.onClick();
  render().find(b=>b.props.children==='흰색').props.onClick();
  assert.deepEqual(value,{manualMaterial:'울/실크',manualColor:'흰색'});
  assert.equal(render().find(b=>b.props.children==='울/실크').props['aria-pressed'],true);
  assert.equal(render().find(b=>b.props.children==='흰색').props['aria-pressed'],true);
});
test('sidebar replaces the in-form box and camera capture cannot launch an external helper URL',()=>{
  const read=name=>fs.readFileSync(path.join(__dirname,'../src',name),'utf8');
  assert.doesNotMatch(read('App.tsx'),/OfflineLabelControls/);
  const camera=read('NativeDraftCamera.tsx');
  assert.match(camera,/createPortal/);assert.match(camera,/dialog-intake-camera/);
  assert.doesNotMatch(camera,/window\.open|location\.(assign|href)|shell\.openExternal/);
  assert.doesNotMatch(read('photo-bridge-session.ts'),/window\.location\.assign/);
  assert.match(read('MobileDraftCapture.tsx'),/width:130,height:130/);
  assert.match(read('reception-sidebar.css'),/#eab308/);
  assert.match(read('reception-sidebar.css'),/#16a34a/);
});
test('optional AI failure and a hung provider quietly resolve without changing manual fields',async()=>{
  const {optionalLabel}=require('./optional-label.cjs');
  const readPhoto=()=>({bytes:Buffer.alloc(100),contentType:'image/jpeg'});
  assert.equal(await optionalLabel('photo',{readPhoto,classify:async()=>{throw Error('offline');}}),null);
  const start=performance.now();
  assert.equal(await optionalLabel('photo',{readPhoto,timeoutMs:20,classify:()=>new Promise(()=>{})}),null);
  assert.ok(performance.now()-start<1000);
  assert.deepEqual(await optionalLabel('photo',{readPhoto,classify:async()=>({raw_material:'모 100%'})}),{raw_material:'모 100%'});
  assert.equal(await optionalLabel('bad',{readPhoto:()=>{throw Error('unknown photo');},
    classify:async()=>assert.fail('unregistered photo must not leave PC')}),null);
});
