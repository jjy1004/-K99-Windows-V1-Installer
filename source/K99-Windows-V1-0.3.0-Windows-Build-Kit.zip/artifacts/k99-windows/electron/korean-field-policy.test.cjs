'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const runtime=createRequire(path.join(__dirname,'../package.json')),ts=runtime('typescript'),m={exports:{}};
new Function('exports',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/korean-field-policy.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(m.exports);
const policy=m.exports.koreanFieldPolicy;
test('all human Korean fields include address, custom garment, notes, process and search',()=>{
  for(const label of ['고객 주소','세탁물 품목명','고객 메모','세탁 과정 설명','직원 참고 메모','재세탁 사유']){
    assert.equal(policy({tag:'INPUT',type:'text',label}),'text');
    assert.equal(policy({tag:'TEXTAREA',label}),'text');
  }
  assert.equal(policy({tag:'INPUT',type:'search',label:'고객명 또는 전화번호 끝자리 검색'}),'search');
  assert.equal(policy({tag:'INPUT',label:'고객명·주문번호·전화번호 찾기'}),'search');
});
test('phone, prices, URL, paths, printer configuration, key codes and scanner IDs stay literal',()=>{
  for(const type of ['tel','number','email','url','password','date','file','checkbox','radio'])
    assert.equal(policy({tag:'INPUT',type,label:'입력'}),null,type);
  for(const mode of ['numeric','decimal','tel','url','email'])
    assert.equal(policy({tag:'INPUT',mode}),null,mode);
  for(const label of ['전화번호','세탁비','실행 파일 경로','AI 처방 URL','TSC 프린터 이름','카메라 모델','풋스위치 키 코드','태그 바코드','태그에서 읽은 전체 원문','현재 품목 롤태그 번호','백업 복구 키']){
    assert.equal(policy({tag:'INPUT',label}),null,label);
  }
});
test('legacy Latin mode is repairable while explicit literal and readonly fields remain untouched',()=>{
  assert.equal(policy({tag:'INPUT',type:'text',mode:'latin',label:'고객 주소'}),'text');
  assert.equal(policy({tag:'INPUT',type:'text',label:'상품',preference:'off'}),null);
  assert.equal(policy({tag:'TEXTAREA',label:'메모',readOnly:true}),null);
});
