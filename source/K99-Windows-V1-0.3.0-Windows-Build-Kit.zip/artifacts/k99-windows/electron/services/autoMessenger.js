'use strict';
// Async, opt-in Windows UI Automation. Never runs during application startup.
const {spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path');
const digits=v=>String(v||'').replace(/\D/g,'');
const KAKAO_DOWNLOAD='https://www.kakaocorp.com/page/service/service/KakaoTalk';
const STORE='ms-windows-store://pdp/?ProductId=9NMPJ99VJBWV';
const SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::InputEncoding=New-Object System.Text.UTF8Encoding
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding
$p=[Console]::In.ReadToEnd()|ConvertFrom-Json
function Reply($status,$detail) { @{status=$status;detail=$detail;channel=$p.channel}|ConvertTo-Json -Compress; exit }
try {
  Add-Type -AssemblyName UIAutomationClient
  Add-Type -AssemblyName UIAutomationTypes
  Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class K99Window {
 [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h, int n);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
'@
  $processName=if($p.channel -eq 'kakao'){'KakaoTalk'}else{'PhoneExperienceHost'}
  $processes=@(Get-Process -Name $processName -ErrorAction SilentlyContinue|Where-Object {$_.MainWindowHandle -ne 0})
  if($processes.Count -ne 1){Reply 'unsupported' '대상 앱 창을 하나로 확인할 수 없습니다. 앱에서 직접 확인해 주세요.'}
  $root=[System.Windows.Automation.AutomationElement]::FromHandle($processes[0].MainWindowHandle)
  $handle=$processes[0].MainWindowHandle
  [K99Window]::ShowWindowAsync($handle,9)|Out-Null
  [K99Window]::SetForegroundWindow($handle)|Out-Null
  $ws=New-Object -ComObject WScript.Shell
  $ws.AppActivate($processes[0].Id)|Out-Null
  Start-Sleep -Milliseconds 250
  if([K99Window]::GetForegroundWindow() -ne $handle){Reply 'unsupported' 'Windows에서 창 활성화를 허용하지 않았습니다. 작업 표시줄의 카카오톡을 확인해 주세요. 자동 발송하지 않았습니다.'}
  if($p.mode -eq 'focus-only'){Reply 'prepared' '카카오톡 창을 앞에 열었습니다. 아직 발송하지 않았습니다.'}
  function AllElements { $root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition) }
  function Edits { @(AllElements|Where-Object {$_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Edit -and $_.Current.IsEnabled}) }
  if($p.channel -eq 'kakao'){
    $ws.SendKeys('^f')
    Start-Sleep -Milliseconds 300
    if($p.mode -eq 'search-open'){Reply 'prepared' '카카오톡을 앞에 열고 고객 검색창 열기를 요청했습니다. 고객 이름이나 전화번호를 입력해 주세요.'}
    $search=@(Edits|Where-Object {!$_.Current.IsOffscreen -and ($_.Current.Name -match '검색|Search|친구 찾기|대화상대 찾기' -or $_.Current.AutomationId -match '(?i)search')})
    $focused=@($search|Where-Object {$_.Current.HasKeyboardFocus})
    if($focused.Count -eq 1){$search=$focused}
    if($search.Count -ne 1){Reply 'unsupported' '카카오톡 창 활성화와 검색창 열기를 요청했습니다. 이 버전은 검색창 자동 입력을 지원하지 않아 화면에서 고객을 확인해 주세요. 자동 발송하지 않았습니다.'}
    $search[0].SetFocus()
    $value=$search[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
    $query=$p.phone.Substring($p.phone.Length-4);$value.SetValue($query)
    Start-Sleep -Milliseconds 450
    if($value.Current.Value -ne $query){Reply 'unconfirmed' '카카오톡 검색어 확인 실패. 자동 발송하지 않았습니다.'}
    if($p.mode -eq 'search-only'){Reply 'prepared' '카카오톡을 앞에 열고 고객 뒷번호 검색을 입력했습니다. 검색 결과에서 고객을 확인한 후 붙여넣기(Ctrl+V) 하세요. 아직 발송하지 않았습니다.'}
    $none=@(AllElements|Where-Object {$_.Current.Name -match '^검색\s*결과가?\s*없습니다[.!]?$|^검색된\s*친구가\s*없습니다[.!]?$'})
    if($none.Count -gt 0){
      Start-Sleep -Milliseconds 350
      $none2=@(AllElements|Where-Object {$_.Current.Name -match '^검색\s*결과가?\s*없습니다[.!]?$|^검색된\s*친구가\s*없습니다[.!]?$'})
      if($none2.Count -gt 0 -and $value.Current.Value -eq $query){Reply 'not_found' '확인된 검색 결과에 친구가 없습니다.'}
    }
    # Never pick a same-name/last4-only contact. Require exact full telephone.
    $matches=@(AllElements|Where-Object {
      ($_.Current.Name -replace '\D','') -eq $p.phone -and
      ($_.Current.ControlType -eq [System.Windows.Automation.ControlType]::ListItem -or $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button)
    })
    if($matches.Count -ne 1){Reply 'unsupported' '이름·뒷번호만으로 수신자를 확정하지 않습니다. 전체 번호가 확인되지 않아 자동 발송하지 않았습니다.'}
    $invoke=$matches[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    $invoke.Invoke();Start-Sleep -Milliseconds 350
  }
  function RecipientVisible {
    $numbers=@(AllElements|Where-Object {
      $_.Current.ControlType -ne [System.Windows.Automation.ControlType]::Edit -and
      $_.Current.AutomationId -match '(?i)(recipient|conversation.?header|chat.?title|thread.?header|contact.?header)' -and
      ($_.Current.Name -replace '\D','') -eq $p.phone
    })
    return $numbers.Count -eq 1
  }
  if(!(RecipientVisible)){Reply 'unsupported' '대화방의 수신자 전체 번호를 확인할 수 없습니다. 자동 입력·발송을 중지했습니다.'}
  $messages=@(Edits|Where-Object {$_.Current.Name -match '메시지|Message' -and $_.Current.Name -notmatch '검색|Search'})
  if($messages.Count -ne 1){Reply 'unsupported' '메시지 입력란을 안전하게 확인하지 못했습니다.'}
  $messageValue=$messages[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
  $messageValue.SetValue($p.body)
  if($messageValue.Current.Value -ne $p.body){Reply 'unconfirmed' '본문 자동 입력을 확인하지 못했습니다. 외부 앱에서 확인해 주세요.'}
  if($p.mode -eq 'confirm'){Reply 'prepared' '본문이 입력되었습니다. 수신자와 내용을 확인한 뒤 외부 앱에서 직접 보내 주세요.'}
  if(!(RecipientVisible)){Reply 'unconfirmed' '발송 직전 수신자 정보가 바뀌었습니다. 자동 발송하지 않았습니다.'}
  $send=@(AllElements|Where-Object {
    $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button -and $_.Current.IsEnabled -and
    $_.Current.Name -match '^(보내기|전송|Send)$'
  })
  if($send.Count -ne 1){Reply 'unconfirmed' '보내기 버튼을 확인할 수 없어 자동 발송하지 않았습니다.'}
  $send[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
  Reply 'send_requested' '앱에 전송을 요청했습니다. 수신·도착은 확인하지 않았습니다.'
} catch { Reply 'unconfirmed' 'Windows 앱의 자동화 지원·잠금 상태를 확인해 주세요. 발송 여부는 외부 앱에서 직접 확인해 주세요.' }
`;
// Phone Link exposes no supported connection-status API. Only a positively
// identified status label in its own UIA tree can close our helper; processes,
// launch success, generic Bluetooth labels and missing UIA are not "connected".
const PHONE_STATUS_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding
try {
 Add-Type -AssemblyName UIAutomationClient
 $apps=@(Get-Process -Name PhoneExperienceHost -ErrorAction SilentlyContinue|Where-Object {$_.MainWindowHandle -ne 0})
 $connected=$false
 foreach($app in $apps){
  $root=[System.Windows.Automation.AutomationElement]::FromHandle($app.MainWindowHandle)
  $labels=@($root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)|Where-Object {
   !$_.Current.IsOffscreen -and
   $_.Current.AutomationId -match '(?i)(phone|device).*(connect|status)|(connect|status).*(phone|device)' -and
   $_.Current.Name -match '^(연결됨|휴대폰 연결됨|Connected|Phone connected)$'
  })
  if($labels.Count -eq 1){$connected=$true}
 }
 @{connected=$connected;verified=$connected}|ConvertTo-Json -Compress
}catch{ '{"connected":false,"verified":false}' }
`;
function createAutoMessenger({shell,clipboard,platform=process.platform,spawnProcess=spawn,
  exists=fs.existsSync,environment=process.env,timeoutMs=12000}){
  let busy=false;
  function windows(){if(platform!=='win32')throw Error('휴대폰·카톡 연결은 Windows 설치형 프로그램에서 사용할 수 있습니다.');}
  function run(command,args,input='',timeout=timeoutMs){
    return new Promise(resolve=>{
      let child,done=false,out='',timer;
      const finish=result=>{if(done)return;done=true;clearTimeout(timer);resolve(result);};
      try{
        child=spawnProcess(command,args,{windowsHide:true,stdio:['pipe','pipe','pipe'],shell:false});
        timer=setTimeout(()=>{child.kill();finish({timeout:true});},timeout);
        child.on('error',()=>finish({error:true}));
        child.stdout.setEncoding('utf8');
        child.stdout.on('data',b=>{out+=b;if(out.length>32000){child.kill();finish({error:true});}});
        child.stderr.on('data',()=>{}); // Never log message bodies or telephone numbers.
        child.on('close',code=>finish({code,out}));
        child.stdin.on('error',()=>{});child.stdin.end(input,'utf8');
      }catch{finish({error:true});}
    });
  }
  async function phone(){
    windows();
    const registered=await run('reg.exe',['query','HKCR\\ms-phone'],'',1000);
    if(registered.code===1){await shell.openExternal(STORE);return {success:true,status:'opened',channel:'store',detail:'휴대폰과 연결 설치 페이지를 열었습니다. 설치·연결 완료는 아직 확인하지 않았습니다.'};}
    try{
      const direct=await run('explorer.exe',['shell:AppsFolder\\Microsoft.YourPhone_8wekyb3d8bbwe!App'],'',2000);
      if(direct.code!==0||direct.error||direct.timeout)await shell.openExternal('ms-phone:');
      return {success:true,status:'opened',channel:'phone',detail:'휴대폰 연결 열기 → 스마트폰 빠른 설정에서 Windows와 연결 켜기 → PC의 연결됨 표시를 확인하세요.'};
    }
    catch{await shell.openExternal(STORE);return {success:true,status:'opened',channel:'store',detail:'앱을 열지 못해 Microsoft Store를 열었습니다.'};}
  }
  function kakaoPath(){
    return [environment.ProgramFiles,environment['ProgramFiles(x86)'],environment.LOCALAPPDATA]
      .filter(Boolean).map(p=>path.win32.join(p,'Kakao','KakaoTalk','KakaoTalk.exe')).find(exists);
  }
  function launchKakao(exe){
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('카카오톡 실행 확인 시간이 지났습니다.')),Math.min(timeoutMs,3000));
      let child;
      try{child=spawnProcess(exe,[],{detached:true,windowsHide:false,stdio:'ignore',shell:false});}
      catch(error){clearTimeout(timer);reject(error);return;}
      child.once('error',e=>{clearTimeout(timer);reject(e);});
      child.once('spawn',()=>{clearTimeout(timer);child.unref();resolve();});
    });
  }
  async function kakao(){
    windows();const exe=kakaoPath();
    if(!exe){await shell.openExternal(KAKAO_DOWNLOAD);return {success:true,status:'opened',channel:'kakao-download',detail:'카카오톡 공식 다운로드 안내를 열었습니다.'};}
    await launchKakao(exe);
    return {success:true,status:'opened',channel:'kakao',detail:'PC 카카오톡을 열었습니다. 최초 로그인은 앱에서 직접 완료해 주세요.'};
  }
  async function ensureKakao(){
    try{
      if(platform!=='win32')return {status:'skipped'};
      const exe=kakaoPath();if(!exe)return {status:'not-installed'};
      const result=await run('tasklist.exe',['/FI','IMAGENAME eq KakaoTalk.exe','/FO','CSV','/NH'],'',1500);
      if(result.timeout||result.error||result.code!==0)return {status:'unknown'};
      if(/"KakaoTalk\.exe"\s*,/i.test(result.out))return {status:'already-running'};
      await launchKakao(exe);return {status:'started'};
    }catch{return {status:'skipped'};}
  }
  async function sms(phoneNumber,body){
    const n=digits(phoneNumber);if(!/^\d{9,11}$/.test(n))throw Error('전체 휴대폰 번호를 확인해 주세요.');
    clipboard.writeText(body);
    const uri=`sms:${n}?body=${encodeURIComponent(body)}`;
    await shell.openExternal(uri.length<25000?uri:`sms:${n}`);
    return n;
  }
  async function automate(channel,phoneNumber,body,mode){
    const result=await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(SCRIPT,'utf16le').toString('base64')],
      JSON.stringify({channel,phone:phoneNumber,body,mode}));
    if(result.timeout||result.error)return {status:'unconfirmed',channel,detail:'자동 입력 확인 시간이 지났습니다. 중복 발송하지 말고 외부 앱에서 확인해 주세요.'};
    try{
      const parsed=JSON.parse(result.out.replace(/^\uFEFF/,'').trim());
      if(!['prepared','send_requested','unconfirmed','unsupported','not_found'].includes(parsed.status))throw Error();
      return {...parsed,channel};
    }catch{return {status:'unconfirmed',channel,detail:'외부 앱 결과를 해석하지 못했습니다. 발송 여부를 직접 확인해 주세요.'};}
  }
  async function dispatch(notice,mode,preferred='auto'){
    windows();if(busy)throw Error('다른 안내 입력을 처리 중입니다. 완료 후 다시 시도해 주세요.');
    const n=digits(notice.customerPhone),body=String(notice.body||'');
    if(!/^\d{9,11}$/.test(n)||!body||body.length>12000)throw Error('수신자 전체 번호와 안내문을 확인해 주세요.');
    busy=true;
    try{
      clipboard.writeText(body);
      let r;
      if(kakaoPath()){
        await kakao();r=await automate('kakao',n,body,mode);
        if(r.status!=='not_found')return {...r,success:['prepared','send_requested'].includes(r.status),manualRequired:!['prepared','send_requested'].includes(r.status)};
      }
      if(preferred==='kakao'){
        await kakao();
        return {success:false,status:'unconfirmed',channel:'kakao',manualRequired:true,detail:'테스트 번호의 카카오톡 대화 상대를 확인하지 못했습니다. 열린 카카오톡/설치 화면에서 직접 확인해 주세요. 실제 발송하지 않았습니다.'};
      }
      await sms(n,body);
      r=await automate('sms',n,body,mode);
      return {...r,success:['prepared','send_requested'].includes(r.status),manualRequired:!['prepared','send_requested'].includes(r.status)};
    }finally{busy=false;}
  }
  async function command(input){
    if(input?.action==='phone-status'){
      windows();
      const r=await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(PHONE_STATUS_SCRIPT,'utf16le').toString('base64')],'',4000);
      try{
        const status=JSON.parse(r.out||'{}'),connected=r.code===0&&status.connected===true&&status.verified===true;
        return {success:true,status:'opened',channel:'phone',connected,verified:connected};
      }catch{return {success:true,status:'opened',channel:'phone',connected:false,verified:false};}
    }
    if(input?.action==='phone')return phone();
    if(input?.action==='kakao'){
      const r=await kakao();
      if(r.channel==='kakao')await automate('kakao','','','search-open');
      return r;
    }
    if(input?.action==='kakao-compose'){
      windows();
      const body=input.body;
      if(typeof body!=='string'||!body.trim()||body.length>12000||body.includes('\0'))
        throw Error('복사할 안내 문구를 확인해 주세요.');
      clipboard.writeText(body);
      if(typeof clipboard.readText==='function'&&clipboard.readText().replace(/\r\n/g,'\n')!==body.replace(/\r\n/g,'\n'))
        throw Error('클립보드에 문구가 정확히 복사되지 않았습니다. 다시 시도해 주세요.');
      const result=await kakao();
      const n=digits(input.recipient);
      const search=result.channel==='kakao'&&/^\d{9,11}$/.test(n)
        ?await automate('kakao',n,body,'search-only'):null;
      return {...result,status:'prepared',manualRequired:true,
        detail:result.channel==='kakao-download'
          ?'문구를 복사하고 카카오톡 공식 설치 안내를 열었습니다. 설치·로그인 후 고객을 검색해 붙여넣어 주세요.'
          :search?.detail||'문구가 복사되었습니다. 카카오톡에서 고객 이름(전화번호) 검색 후 붙여넣기(Ctrl+V) 하세요. 아직 발송하지 않았습니다.'};
    }
    if(input?.action==='test'){
      if(input.channel==='kakao')return dispatch({customerPhone:input.phone,body:'K99 카카오톡 연결 확인용 문안입니다. 직원 확인 후 직접 보내 주세요.'},'confirm','kakao');
      windows();await sms(input.phone,'K99 매장 휴대폰 연결 확인용 문안입니다. 실제 발송은 직원 확인 후 진행해 주세요.');
      return {success:true,status:'opened',channel:'sms',detail:'본인 번호의 문자 입력창 열기를 요청하고 테스트 문안을 복사했습니다. 자동 발송하지 않았습니다. 연결·본문 입력 상태는 창에서 확인해 주세요.'};
    }
    throw Error('허용되지 않은 연결 요청입니다.');
  }
  return {command,dispatch,ensureKakao};
}
module.exports={createAutoMessenger,SCRIPT,PHONE_STATUS_SCRIPT,KAKAO_DOWNLOAD,STORE};
