'use strict';
// Async, opt-in Windows UI Automation. Never runs during application startup.
const {spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path');
const digits=v=>String(v||'').replace(/\D/g,'');
const KAKAO_DOWNLOAD='https://www.kakaocorp.com/page/service/service/KakaoTalk';
const STORE='ms-windows-store://pdp/?ProductId=9NMPJ99VJBWV';
const SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::InputEncoding=New-Object System.Text.UTF8Encoding
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding
$p=[Console]::In.ReadToEnd()|ConvertFrom-Json
function Reply($status,$detail) { @{status=$status;detail=$detail;channel=$p.channel}|ConvertTo-Json -Compress; exit }
try {
  Add-Type -AssemblyName UIAutomationClient
  Add-Type -AssemblyName UIAutomationTypes
  $processName=if($p.channel -eq 'kakao'){'KakaoTalk'}else{'PhoneExperienceHost'}
  $processes=@(Get-Process -Name $processName -ErrorAction SilentlyContinue|Where-Object {$_.MainWindowHandle -ne 0})
  if($processes.Count -ne 1){Reply 'unsupported' '대상 앱 창을 하나로 확인할 수 없습니다. 앱에서 직접 확인해 주세요.'}
  $root=[System.Windows.Automation.AutomationElement]::FromHandle($processes[0].MainWindowHandle)
  function AllElements { $root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition) }
  function Edits { @(AllElements|Where-Object {$_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Edit -and $_.Current.IsEnabled}) }
  if($p.channel -eq 'kakao'){
    $search=@(Edits|Where-Object {$_.Current.Name -match '검색|Search'})
    if($search.Count -ne 1){Reply 'unsupported' '카카오톡 검색 입력란을 안전하게 확인하지 못했습니다.'}
    $value=$search[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
    $query=$p.phone.Substring($p.phone.Length-4);$value.SetValue($query)
    Start-Sleep -Milliseconds 450
    if($value.Current.Value -ne $query){Reply 'unconfirmed' '카카오톡 검색어 확인 실패. 자동 발송하지 않았습니다.'}
    $none=@(AllElements|Where-Object {$_.Current.Name -match '^검색\s*결과가?\s*없습니다[.!]?$|^검색된\s*친구가\s*없습니다[.!]?$'})
    if($none.Count -gt 0){
      Start-Sleep -Milliseconds 350
      $none2=@(AllElements|Where-Object {$_.Current.Name -match '^검색\s*결과가?\s*없습니다[.!]?$|^검색된\s*친구가\s*없습니다[.!]?$'})
      if($none2.Count -gt 0 -and $value.Current.Value -eq $query){Reply 'not_found' '확인된 검색 결과에 친구가 없습니다.'}
    }
    # Never pick a same-name/last4-only contact. Require exact full telephone.
    $matches=@(AllElements|Where-Object {
      ($_.Current.Name -replace '\D','') -eq $p.phone -and
      ($_.Current.ControlType -eq [System.Windows.Automation.ControlType]::ListItem -or $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button)
    })
    if($matches.Count -ne 1){Reply 'unsupported' '이름·뒷번호만으로 수신자를 확정하지 않습니다. 전체 번호가 확인되지 않아 자동 발송하지 않았습니다.'}
    $invoke=$matches[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    $invoke.Invoke();Start-Sleep -Milliseconds 350
  }
  function RecipientVisible {
    $numbers=@(AllElements|Where-Object {
      $_.Current.ControlType -ne [System.Windows.Automation.ControlType]::Edit -and
      $_.Current.AutomationId -match '(?i)(recipient|conversation.?header|chat.?title|thread.?header|contact.?header)' -and
      ($_.Current.Name -replace '\D','') -eq $p.phone
    })
    return $numbers.Count -eq 1
  }
  if(!(RecipientVisible)){Reply 'unsupported' '대화방의 수신자 전체 번호를 확인할 수 없습니다. 자동 입력·발송을 중지했습니다.'}
  $messages=@(Edits|Where-Object {$_.Current.Name -match '메시지|Message' -and $_.Current.Name -notmatch '검색|Search'})
  if($messages.Count -ne 1){Reply 'unsupported' '메시지 입력란을 안전하게 확인하지 못했습니다.'}
  $messageValue=$messages[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
  $messageValue.SetValue($p.body)
  if($messageValue.Current.Value -ne $p.body){Reply 'unconfirmed' '본문 자동 입력을 확인하지 못했습니다. 외부 앱에서 확인해 주세요.'}
  if($p.mode -eq 'confirm'){Reply 'prepared' '본문이 입력되었습니다. 수신자와 내용을 확인한 뒤 외부 앱에서 직접 보내 주세요.'}
  if(!(RecipientVisible)){Reply 'unconfirmed' '발송 직전 수신자 정보가 바뀌었습니다. 자동 발송하지 않았습니다.'}
  $send=@(AllElements|Where-Object {
    $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button -and $_.Current.IsEnabled -and
    $_.Current.Name -match '^(보내기|전송|Send)$'
  })
  if($send.Count -ne 1){Reply 'unconfirmed' '보내기 버튼을 확인할 수 없어 자동 발송하지 않았습니다.'}
  $send[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
  Reply 'send_requested' '앱에 전송을 요청했습니다. 수신·도착은 확인하지 않았습니다.'
} catch { Reply 'unconfirmed' 'Windows 앱의 자동화 지원·잠금 상태를 확인해 주세요. 발송 여부는 외부 앱에서 직접 확인해 주세요.' }
`;
function createAutoMessenger({shell,clipboard,platform=process.platform,spawnProcess=spawn,
  exists=fs.existsSync,environment=process.env,timeoutMs=12000}){
  let busy=false;
  function windows(){if(platform!=='win32')throw Error('휴대폰·카톡 연결은 Windows 설치형 프로그램에서 사용할 수 있습니다.');}
  function run(command,args,input='',timeout=timeoutMs){
    return new Promise(resolve=>{
      let child,done=false,out='',timer;
      const finish=result=>{if(done)return;done=true;clearTimeout(timer);resolve(result);};
      try{
        child=spawnProcess(command,args,{windowsHide:true,stdio:['pipe','pipe','pipe'],shell:false});
        timer=setTimeout(()=>{child.kill();finish({timeout:true});},timeout);
        child.on('error',()=>finish({error:true}));
        child.stdout.setEncoding('utf8');
        child.stdout.on('data',b=>{out+=b;if(out.length>32000){child.kill();finish({error:true});}});
        child.stderr.on('data',()=>{}); // Never log message bodies or telephone numbers.
        child.on('close',code=>finish({code,out}));
        child.stdin.on('error',()=>{});child.stdin.end(input,'utf8');
      }catch{finish({error:true});}
    });
  }
  async function phone(){
    windows();
    const registered=await run('reg.exe',['query','HKCR\\ms-phone'],'',1000);
    if(registered.code===1){await shell.openExternal(STORE);return {success:true,status:'opened',channel:'store',detail:'휴대폰과 연결 설치 페이지를 열었습니다. 설치·연결 완료는 아직 확인하지 않았습니다.'};}
    try{await shell.openExternal('ms-phone:');return {success:true,status:'opened',channel:'phone',detail:'휴대폰과 연결 앱 열기를 요청했습니다. QR 연결을 진행해 주세요.'};}
    catch{await shell.openExternal(STORE);return {success:true,status:'opened',channel:'store',detail:'앱을 열지 못해 Microsoft Store를 열었습니다.'};}
  }
  function kakaoPath(){
    return [environment.ProgramFiles,environment['ProgramFiles(x86)'],environment.LOCALAPPDATA]
      .filter(Boolean).map(p=>path.win32.join(p,'Kakao','KakaoTalk','KakaoTalk.exe')).find(exists);
  }
  async function kakao(){
    windows();const exe=kakaoPath();
    if(!exe){await shell.openExternal(KAKAO_DOWNLOAD);return {success:true,status:'opened',channel:'kakao-download',detail:'카카오톡 공식 다운로드 안내를 열었습니다.'};}
    await new Promise((resolve,reject)=>{
      const child=spawnProcess(exe,[],{detached:true,windowsHide:false,stdio:'ignore',shell:false});
      child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});
    });
    return {success:true,status:'opened',channel:'kakao',detail:'PC 카카오톡을 열었습니다. 최초 로그인은 앱에서 직접 완료해 주세요.'};
  }
  async function sms(phoneNumber,body){
    const n=digits(phoneNumber);if(!/^\d{9,11}$/.test(n))throw Error('전체 휴대폰 번호를 확인해 주세요.');
    clipboard.writeText(body);
    const uri=`sms:${n}?body=${encodeURIComponent(body)}`;
    await shell.openExternal(uri.length<25000?uri:`sms:${n}`);
    return n;
  }
  async function automate(channel,phoneNumber,body,mode){
    const result=await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(SCRIPT,'utf16le').toString('base64')],
      JSON.stringify({channel,phone:phoneNumber,body,mode}));
    if(result.timeout||result.error)return {status:'unconfirmed',channel,detail:'자동 입력 확인 시간이 지났습니다. 중복 발송하지 말고 외부 앱에서 확인해 주세요.'};
    try{
      const parsed=JSON.parse(result.out.replace(/^\uFEFF/,'').trim());
      if(!['prepared','send_requested','unconfirmed','unsupported','not_found'].includes(parsed.status))throw Error();
      return {...parsed,channel};
    }catch{return {status:'unconfirmed',channel,detail:'외부 앱 결과를 해석하지 못했습니다. 발송 여부를 직접 확인해 주세요.'};}
  }
  async function dispatch(notice,mode,preferred='auto'){
    windows();if(busy)throw Error('다른 안내 입력을 처리 중입니다. 완료 후 다시 시도해 주세요.');
    const n=digits(notice.customerPhone),body=String(notice.body||'');
    if(!/^\d{9,11}$/.test(n)||!body||body.length>12000)throw Error('수신자 전체 번호와 안내문을 확인해 주세요.');
    busy=true;
    try{
      clipboard.writeText(body);
      let r;
      if(kakaoPath()){
        await kakao();r=await automate('kakao',n,body,mode);
        if(r.status!=='not_found')return {...r,success:['prepared','send_requested'].includes(r.status),manualRequired:!['prepared','send_requested'].includes(r.status)};
      }
      if(preferred==='kakao'){
        await kakao();
        return {success:false,status:'unconfirmed',channel:'kakao',manualRequired:true,detail:'테스트 번호의 카카오톡 대화 상대를 확인하지 못했습니다. 열린 카카오톡/설치 화면에서 직접 확인해 주세요. 실제 발송하지 않았습니다.'};
      }
      await sms(n,body);
      r=await automate('sms',n,body,mode);
      return {...r,success:['prepared','send_requested'].includes(r.status),manualRequired:!['prepared','send_requested'].includes(r.status)};
    }finally{busy=false;}
  }
  async function command(input){
    if(input?.action==='phone')return phone();
    if(input?.action==='kakao')return kakao();
    if(input?.action==='test'){
      if(input.channel==='kakao')return dispatch({customerPhone:input.phone,body:'K99 카카오톡 연결 확인용 문안입니다. 직원 확인 후 직접 보내 주세요.'},'confirm','kakao');
      windows();await sms(input.phone,'K99 매장 휴대폰 연결 확인용 문안입니다. 실제 발송은 직원 확인 후 진행해 주세요.');
      return {success:true,status:'opened',channel:'sms',detail:'본인 번호의 문자 입력창 열기를 요청하고 테스트 문안을 복사했습니다. 자동 발송하지 않았습니다. 연결·본문 입력 상태는 창에서 확인해 주세요.'};
    }
    throw Error('허용되지 않은 연결 요청입니다.');
  }
  return {command,dispatch};
}
module.exports={createAutoMessenger,SCRIPT,KAKAO_DOWNLOAD,STORE};
