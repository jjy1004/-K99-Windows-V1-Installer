'use strict';
// A port open/close probes transport availability, NEVER a card approval.
const {spawn}=require('node:child_process');
const PROBE_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
$port=$null
try {
  $p=[Console]::In.ReadToEnd()|ConvertFrom-Json
  if($p.port -cnotmatch '^COM[1-9][0-9]{0,3}$' -or @(9600,19200,38400,115200) -notcontains [int]$p.baud){throw 'invalid'}
  $port=New-Object System.IO.Ports.SerialPort
  $port.PortName=$p.port
  $port.BaudRate=[int]$p.baud
  $port.DtrEnable=$false
  $port.RtsEnable=$false
  $port.Open()
  [Console]::Out.Write('K99_PORT_AVAILABLE')
} catch { exit 1 }
finally {if($null -ne $port){if($port.IsOpen){$port.Close()};$port.Dispose()}}
`;
function createTerminalProbe({spawnProcess=spawn,platform=process.platform,timeoutMs=3000}={}){
  return ({port,baud})=>new Promise(resolve=>{
    if(platform!=='win32'||!/^COM[1-9]\d{0,3}$/.test(port)||![9600,19200,38400,115200].includes(baud))return resolve(false);
    let child,timer,done=false,out='',failed=false;
    const finish=ok=>{if(done)return;done=true;clearTimeout(timer);resolve(ok);};
    try{
      child=spawnProcess('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',
        Buffer.from(PROBE_SCRIPT,'utf16le').toString('base64')],{windowsHide:true,stdio:['pipe','pipe','pipe']});
      child.once('error',()=>finish(false));
      child.stdout.on('data',b=>{out+=b.toString();if(out.length>1024){failed=true;child.kill();}});
      child.stderr.on('data',()=>{failed=true;});
      child.stdin.on('error',()=>{failed=true;});
      child.once('close',code=>finish(!failed&&code===0&&out==='K99_PORT_AVAILABLE'));
      timer=setTimeout(()=>{finish(false);child.kill();},timeoutMs);
      child.stdin.end(JSON.stringify({port,baud}));
    }catch{child?.kill();finish(false);}
  });
}
module.exports={createTerminalProbe,PROBE_SCRIPT};
