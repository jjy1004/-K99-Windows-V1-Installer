'use strict';
const path=require('node:path');
// Fixed, read-only discovery. Only candidate executable paths leave the child.
const DISCOVERY_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$found=New-Object 'System.Collections.Generic.List[string]'
try {
 $ws=New-Object -ComObject WScript.Shell
 $desktops=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'))
 foreach($folder in $desktops) {
  if(!$folder){continue}
  Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -File -ErrorAction SilentlyContinue | ForEach-Object {
   try {$target=$ws.CreateShortcut($_.FullName).TargetPath
    if([IO.Path]::GetFileName($target) -ieq 'KakaoTalk.exe'){$found.Add($target)}
   }catch{}
  }
 }
}catch{}
foreach($root in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
 'HKCU:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
 Get-ItemProperty "$root\*" -ErrorAction SilentlyContinue | Where-Object {$_.DisplayName -match 'KakaoTalk|카카오톡'} | ForEach-Object {
  if($_.InstallLocation){$found.Add((Join-Path $_.InstallLocation 'KakaoTalk.exe'));$found.Add((Join-Path $_.InstallLocation 'KakaoTalk\KakaoTalk.exe'))}
  if($_.DisplayIcon){$icon=[Environment]::ExpandEnvironmentVariables($_.DisplayIcon) -replace ',\s*-?\d+$','';$found.Add($icon.Trim('"'))}
  if($_.UninstallString -match '^"?(.+\\)[^\\"]+\.exe"?'){$found.Add((Join-Path $Matches[1] 'KakaoTalk.exe'))}
 }
}
Get-Process -Name KakaoTalk -ErrorAction SilentlyContinue | ForEach-Object {try{if($_.Path){$found.Add($_.Path)}}catch{}}
@($found | Select-Object -Unique) | ConvertTo-Json -Compress
`;
const BACKGROUND_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::InputEncoding=New-Object System.Text.UTF8Encoding($false)
$p=[Console]::In.ReadToEnd()|ConvertFrom-Json
if([IO.Path]::GetFileName($p.path) -ine 'KakaoTalk.exe' -or !(Test-Path -LiteralPath $p.path -PathType Leaf)){exit 1}
Start-Process -FilePath $p.path -WindowStyle Minimized -ErrorAction Stop | Out-Null
[Console]::Out.Write('K99_KAKAO_STARTED')
`;
const psArgs=script=>['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')];
function createKakaoLauncher({run,spawnProcess,exists,environment,timeoutMs}){
  let starting=null,launchedAt=0;
  function valid(value){
    if(typeof value!=='string')return null;
    const file=value.trim().replace(/^"([^"]+)"$/,'$1').replace(/%([^%]+)%/g,(_,key)=>
      Object.entries(environment).find(([name])=>name.toLowerCase()===key.toLowerCase())?.[1]||`%${key}%`);
    return path.win32.isAbsolute(file)&&!file.includes('\0')&&
      path.win32.basename(file).toLowerCase()==='kakaotalk.exe'&&exists(file)?file:null;
  }
  function standardPath(){
    const roots=[environment['ProgramFiles(x86)'],environment.ProgramFiles,
      'C:\\Program Files (x86)','C:\\Program Files'];
    const candidates=roots.filter(Boolean).map(p=>path.win32.join(p,'Kakao','KakaoTalk','KakaoTalk.exe'));
    if(environment.LOCALAPPDATA)candidates.push(
      path.win32.join(environment.LOCALAPPDATA,'Programs','Kakao','KakaoTalk','KakaoTalk.exe'),
      path.win32.join(environment.LOCALAPPDATA,'Kakao','KakaoTalk','KakaoTalk.exe'));
    return candidates.map(valid).find(Boolean)||null;
  }
  async function resolvePath(){
    const standard=standardPath();if(standard)return standard;
    for(const hive of ['HKCU','HKLM'])for(const view of ['64','32']){
      const r=await run('reg.exe',['query',`${hive}\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\KakaoTalk.exe`,'/ve',`/reg:${view}`],'',1000);
      if(r.code===0){const file=valid(r.out?.match(/REG_(?:EXPAND_)?SZ\s+(.+)\s*$/mi)?.[1]);if(file)return file;}
    }
    const result=await run('powershell.exe',psArgs(DISCOVERY_SCRIPT),'',3000);
    try{
      if(result.code!==0)return null;
      const values=JSON.parse((result.out||'').replace(/^\uFEFF/,'').trim());
      for(const entry of Array.isArray(values)?values:[values]){const file=valid(entry);if(file)return file;}
    }catch{}
    return null;
  }
  function launch(exe){
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('카카오톡 실행 확인 시간이 지났습니다.')),Math.min(timeoutMs,3000));
      try{
        const child=spawnProcess(exe,[],{detached:true,windowsHide:false,stdio:'ignore',shell:false});
        child.once('error',e=>{clearTimeout(timer);reject(e);});
        child.once('spawn',()=>{clearTimeout(timer);child.unref();resolve();});
      }catch(error){clearTimeout(timer);reject(error);}
    });
  }
  async function ensure(background=false){
    if(starting)return starting;
    starting=(async()=>{
      const state=await run('tasklist.exe',['/FI','IMAGENAME eq KakaoTalk.exe','/FO','CSV','/NH'],'',1500);
      if(state.timeout||state.error||state.code!==0)return {status:'unknown'};
      if(/"KakaoTalk\.exe"\s*,/i.test(state.out))return {status:'already-running'};
      // Process enumeration can lag just after Start-Process/spawn completes.
      if(launchedAt&&Date.now()-launchedAt<5000)return {status:'started'};
      const exe=await resolvePath();if(!exe)return {status:'not-installed'};
      if(background){
        const r=await run('powershell.exe',psArgs(BACKGROUND_SCRIPT),JSON.stringify({path:exe}),3000);
        if(r.code!==0||r.out!=='K99_KAKAO_STARTED')return {status:'unknown'};
      }else await launch(exe);
      launchedAt=Date.now();
      return {status:'started'};
    })();
    try{return await starting;}finally{starting=null;}
  }
  return {ensure,standardPath,resolvePath};
}
module.exports={createKakaoLauncher,DISCOVERY_SCRIPT,BACKGROUND_SCRIPT};
