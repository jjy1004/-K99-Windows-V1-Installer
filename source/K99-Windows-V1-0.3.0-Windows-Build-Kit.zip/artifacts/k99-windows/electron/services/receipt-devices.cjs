'use strict';
// Company defaults are driver-output defaults, NOT approval/ESC-POS protocols.
const PROFILES=Object.freeze(Object.fromEntries(['easycheck','kis','nice'].map(v=>[v,Object.freeze({
  receiptVendor:v,receiptType:v==='easycheck'?'easycheck':'windows',receiptTransport:'windows',
  receiptBaudRate:9600,receiptEncoding:'euc-kr',receiptWidth:80,
  receiptPort:'',receiptPrinterName:'',
  receiptEscPosVerified:false,receiptCut:false,
})])));
const VENDORS={
  easycheck:/easy[\s_-]*check|kicc|이지체크|한국정보통신/i,
  kis:/(?:^|[^a-z])kis(?:[^a-z]|$)|케이아이에스|kis정보통신/i,
  nice:/nice|smartro|나이스|스마트로/i,
};
const description=p=>[p.name,p.displayName,p.description,p.manufacturer,p.driverName,p.pnpDeviceId].filter(Boolean).join(' ');
function identify(p){
  const matches=Object.keys(VENDORS).filter(v=>VENDORS[v].test(description(p)));
  return matches.length===1?matches[0]:'';
}
function deviceProfile(vendor,device={},ports=[]){
  const next={...PROFILES[vendor]};
  if(!PROFILES[vendor])throw Error('단말기 회사를 확인해 주세요.');
  const text=description(device);
  if(/58\s*mm|2\s*inch|2인치/i.test(text))next.receiptWidth=58;
  if(/TS[\s-]*167\b|80\s*mm|3\s*inch|3인치/i.test(text))next.receiptWidth=80;
  const port=String(device.port||device.name||'').toUpperCase();
  if(/^COM[1-9]\d{0,3}$/.test(port))next.receiptPort=port;
  else{
    const candidates=ports.filter(p=>identify(p)===vendor);
    if(candidates.length===1)next.receiptPort=candidates[0].name;
  }
  // A serial port can identify a device, but does not prove its command language.
  return next;
}
// Fixed read-only query: no customer data, user paths or shell interpolation.
const PORT_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$drivers=@{}
Get-CimInstance Win32_PnPSignedDriver | Where-Object {$_.DeviceClass -eq 'PORTS'} | ForEach-Object {$drivers[$_.DeviceID]=$_.DriverName}
$rows=@(Get-CimInstance Win32_SerialPort | ForEach-Object {
  [pscustomobject]@{name=$_.DeviceID;displayName=$_.Name;description=$_.Description;manufacturer=$_.Manufacturer;pnpDeviceId=$_.PNPDeviceID;driverName=$drivers[$_.PNPDeviceID]}
})
ConvertTo-Json -InputObject $rows -Compress
`;
async function serialPorts({platform=process.platform,execFile=require('node:child_process').execFile}={}){
  if(platform!=='win32')return [];
  const run=(exe,args)=>new Promise(resolve=>execFile(exe,args,
    {windowsHide:true,timeout:1800,maxBuffer:262144,encoding:'utf8'},(error,stdout)=>resolve(error?'':String(stdout))));
  const ps=await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(PORT_SCRIPT,'utf16le').toString('base64')]);
  let detailed=[];
  try{const rows=JSON.parse(ps.replace(/^\uFEFF/,''));detailed=(Array.isArray(rows)?rows:[rows]).filter(p=>/^COM[1-9]\d{0,3}$/i.test(p?.name));}catch{}
  const reg=await run('reg.exe',['query','HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM']);
  const result=new Map(detailed.map(p=>[p.name.toUpperCase(),{...p,name:p.name.toUpperCase()}]));
  for(const name of reg.match(/\bCOM[1-9]\d{0,3}\b/gi)||[])if(!result.has(name.toUpperCase()))result.set(name.toUpperCase(),{name:name.toUpperCase()});
  return [...result.values()];
}
module.exports={PROFILES,VENDORS,identify,deviceProfile,serialPorts,PORT_SCRIPT};
