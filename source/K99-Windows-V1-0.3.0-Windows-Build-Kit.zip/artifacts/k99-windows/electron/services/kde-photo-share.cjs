'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function image(bytes){
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'jpg';
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'png';
  if(bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return 'webp';
  if(/^GIF8[79]a$/.test(bytes.toString('ascii',0,6)))return 'gif';
  if(bytes.toString('ascii',0,2)==='BM')return 'bmp';
  throw Error('실제 사진 파일만 전송할 수 있습니다.');
}
function createKdePhotoSelection({cacheRoot,pick,getOrderPhotos}){
  function checked(filename){
    if(!path.isAbsolute(filename))throw Error('선택한 사진 경로를 확인해 주세요.');
    let part=path.parse(filename).root;
    for(const name of filename.slice(part.length).split(path.sep).filter(Boolean)){
      part=path.join(part,name);if(fs.lstatSync(part).isSymbolicLink())throw Error('링크·정션 파일은 전송하지 않습니다.');
    }
    const stat=fs.statSync(filename);
    if(!stat.isFile()||stat.size<12||stat.size>40*1024*1024)throw Error('사진은 한 장당 40MB 이하여야 합니다.');
    const bytes=fs.readFileSync(filename);image(bytes);return bytes;
  }
  return async input=>{
    // Only our own aged transfer copies are removed, never customer originals.
    fs.mkdirSync(cacheRoot,{recursive:true});
    for(const name of fs.readdirSync(cacheRoot)){
      if(!/^[a-f0-9-]{36}$/.test(name))continue;
      const file=path.join(cacheRoot,name),stat=fs.lstatSync(file);
      if(stat.isDirectory()&&!stat.isSymbolicLink()&&Date.now()-stat.mtimeMs>86400000)fs.rmSync(file,{recursive:true,force:true});
    }
    const folder=path.join(cacheRoot,crypto.randomUUID());fs.mkdirSync(folder);
    const own=[];
    if(input.source==='order'){
      if(typeof input.orderId!=='string'||!input.orderId||input.orderId.length>180)throw Error('저장된 고객 접수를 선택해 주세요.');
      const photos=await getOrderPhotos(input.orderId);
      if(!photos.length)throw Error('이 접수에 연결된 사진이 없습니다. 사진 파일 선택을 이용해 주세요.');
      if(photos.length>40)throw Error('접수 사진이 40장을 넘습니다. 사진 파일 선택으로 필요한 사진을 골라 주세요.');
      let size=0;
      for(const [index,bytes] of photos.entries()){
        size+=bytes.length;if(size>200*1024*1024)throw Error('한 번에 준비할 접수 사진은 200MB 이하여야 합니다.');
        const file=path.join(folder,`${String(index+1).padStart(2,'0')}_접수사진.${image(bytes)}`);
        fs.writeFileSync(file,bytes,{flag:'wx'});own.push(file);
      }
    }else if(input.source!=='file')throw Error('사진 선택 방법을 확인해 주세요.');
    const selected=await pick({title:input.source==='order'?'이 접수의 사진 선택':'스마트폰으로 보낼 사진 선택',
      ...(own.length?{defaultPath:folder}:{}),properties:['openFile','multiSelections'],
      filters:[{name:'사진',extensions:['jpg','jpeg','png','webp','gif','bmp']}]});
    if(selected.canceled||!selected.filePaths.length)return [];
    if(selected.filePaths.length>20)throw Error('한 번에 사진을 최대 20장 선택해 주세요.');
    if(input.source==='order'&&selected.filePaths.some(file=>!own.includes(file)))throw Error('해당 접수의 사진만 선택해 주세요.');
    let total=0;
    return selected.filePaths.map((file,index)=>{
      const bytes=checked(file);total+=bytes.length;if(total>200*1024*1024)throw Error('선택한 사진의 합계는 200MB 이하여야 합니다.');
      // Share immutable copies, retained until a later operation after 24 hours.
      const copy=path.join(folder,`전송_${index+1}.${image(bytes)}`);fs.writeFileSync(copy,bytes,{flag:'wx'});return copy;
    });
  };
}
module.exports={createKdePhotoSelection,image};
