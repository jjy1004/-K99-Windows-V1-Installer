'use strict';
// Installed PCs send only a saved garment image to the publisher's central API.
// No Google SDK, Google credential or client environment-variable lookup.
const packaged=require('../../package.json');
function endpointURL(endpoint,{allowLoopback=false}={}){
  let u;try{u=new URL(endpoint);}catch{throw Error('중앙 분석 서버 주소가 빌드에 포함되지 않았습니다. 배포자에게 업데이트를 요청하세요.');}
  const local=['localhost','127.0.0.1','::1','[::1]'].includes(u.hostname);
  if((u.protocol!=='https:'&&!(allowLoopback&&local&&u.protocol==='http:'))||u.username||u.password||u.search||u.hash||
    u.pathname!=='/api/carelabel/analyze'||/(^|\.)googleapis\.com$/i.test(u.hostname)||
    (local&&!allowLoopback))
    throw Error('중앙 분석 서버 HTTPS 주소 설정 오류');
  return u.href;
}
async function classifyCareLabel(bytes,{mimeType='image/jpeg',endpoint=packaged.k99CareLabelProxyUrl,allowLoopback=false,fetchImpl=fetch,timeoutMs=25000}={}){
  if(!Buffer.isBuffer(bytes)||bytes.length<32||bytes.length>8*1024*1024)throw Error('케어라벨 사진 크기 오류');
  if(!['image/jpeg','image/png'].includes(mimeType))throw Error('케어라벨 사진 형식 오류');
  const response=await fetchImpl(endpointURL(endpoint,{allowLoopback}),{
    method:'POST',redirect:'error',signal:AbortSignal.timeout(timeoutMs),
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({dataBase64:bytes.toString('base64'),mimeType}),
  });
  if(!response.ok){
    const codes={400:'사진 인코딩 오류',413:'사진 용량 초과',429:'중앙 서버 분석 한도 초과',503:'중앙 분석 서버 준비 중'};
    throw Error(codes[response.status]||`중앙 분석 서버 응답 오류 (HTTP ${response.status})`);
  }
  const r=await response.json();
  const valid=r&&['success','review'].includes(r.status)&&typeof r.materialTag==='string'&&r.materialTag.length<=80&&
    typeof r.error==='string'&&r.error.length<=500&&
    (r.status!=='success'||(['폴리에스테르','식물성 혼방','울/실크','나일론'].includes(r.material_group)&&
      ['물세탁','드라이세탁'].includes(r.wash_method)&&typeof r.color==='string'&&r.color.length<=40));
  if(!valid)throw Error('중앙 분석 서버 JSON 규격 오류');
  if(r.basket!==null&&(!r.basket||!/^#[a-f\d]{6}$/i.test(r.basket.color)||
    typeof r.basket.no!=='string'||r.basket.no.length>30||typeof r.basket.name!=='string'||r.basket.name.length>80))
    throw Error('중앙 분석 서버 바구니 응답 오류');
  return r;
}
module.exports={classifyCareLabel,endpointURL};
