'use strict';
const path=require('node:path');
// Only discovery may try alternatives. A send is executed exactly once.
function createKdeSms({run,exists,environment}){
  async function executable(){
    const roots=[environment.ProgramFiles,environment['ProgramFiles(x86)'],environment.LOCALAPPDATA&&path.win32.join(environment.LOCALAPPDATA,'Programs')].filter(Boolean);
    const candidates=roots.flatMap(root=>[
      path.win32.join(root,'KDE Connect','bin','kdeconnect-cli.exe'),
      path.win32.join(root,'KDE Connect','kdeconnect-cli.exe')]);
    if(environment.LOCALAPPDATA)candidates.push(path.win32.join(environment.LOCALAPPDATA,'Microsoft','WindowsApps','kdeconnect-cli.exe'));
    for(const file of candidates)if(exists(file))return file;
    const located=await run('where.exe',['kdeconnect-cli.exe'],'',2000);
    if(located.code===0){
      for(const file of located.out.split(/\r?\n/).map(v=>v.trim())){
        if(path.win32.isAbsolute(file)&&path.win32.basename(file).toLowerCase()==='kdeconnect-cli.exe'&&exists(file))return file;
      }
    }
    return null;
  }
  async function target(){
    const cli=await executable();
    if(!cli)throw Error('KDE 실행 파일을 찾지 못했습니다. PC의 KDE 설치 상태를 확인해 주세요.');
    const listed=await run(cli,['--list-available','--id-only'],'',4000);
    const ids=[...new Set((listed.out||'').split(/\r?\n/).map(v=>v.trim()).filter(v=>/^[a-zA-Z0-9_-]{1,200}$/.test(v)))];
    if(listed.code!==0||ids.length!==1)throw Error(ids.length>1?'KDE 기기가 여러 대입니다. 발송할 휴대폰 한 대만 연결해 주세요.':'KDE 기기가 연결되어 있지 않습니다. 휴대폰 연결 상태를 확인해 주세요.');
    return {cli,id:ids[0]};
  }
  async function send(recipient,body){
    let device;
    try{device=await target();}catch(error){return {success:false,status:'unconfirmed',channel:'sms',copied:true,error:error.message};}
    const {cli,id}=device;
    const sent=await run(cli,['-d',id,'--destination',recipient,'--send-sms',body]);
    if(sent.code===0)return {success:true,status:'send_requested',channel:'sms',copied:true,detail:'KDE 문자 전송 요청을 실행했습니다.'};
    return {success:false,status:'unconfirmed',channel:'sms',copied:true,
      error:sent.timeout?'KDE 발송 결과를 확인하지 못했습니다. 중복 발송 방지를 위해 자동 재시도하지 않았습니다.':
        'KDE 문자 전송 요청에 실패했습니다. 자동 재시도하지 않았습니다.'};
  }
  send.share=async files=>{
    if(!Array.isArray(files)||!files.length||files.some(file=>typeof file!=='string'||!path.isAbsolute(file)||file.includes('\0')))
      throw Error('전송할 사진 파일을 확인해 주세요.');
    const {cli,id}=await target();let requested=0;
    for(const file of files){
      const result=await run(cli,['-d',id,'--share',file]);
      if(result.code!==0)return {success:false,status:'unconfirmed',channel:'sms',
        error:`사진 ${requested}개 전송 요청 후 중단했습니다. 현재 파일의 전송 결과는 미확인이며 자동 재시도하지 않았습니다.`};
      requested++;
    }
    return {success:true,status:'send_requested',channel:'sms',detail:`사진 ${requested}개를 연결된 스마트폰으로 전송 요청했습니다.`};
  };
  return send;
}
module.exports={createKdeSms};
