'use strict';
const path=require('node:path');
const fs=require('node:fs'),crypto=require('node:crypto');
function createKdePathCache(directory,{io=fs}={}){
  const file=path.join(directory,'k99-kde-cli-path.json');
  const read=()=>{try{const value=JSON.parse(io.readFileSync(file,'utf8'));return typeof value.path==='string'?value.path:'';}catch{return '';}};
  const save=value=>{
    if(read()===value)return;
    const temp=file+'.'+crypto.randomUUID()+'.tmp';let fd;
    try{
      io.mkdirSync(directory,{recursive:true});
      fd=io.openSync(temp,'wx',0o600);io.writeFileSync(fd,JSON.stringify({version:1,path:value}));io.fsyncSync(fd);io.closeSync(fd);fd=undefined;
      io.renameSync(temp,file);
    }catch{
      if(fd!==undefined)try{io.closeSync(fd);}catch{}
      try{io.unlinkSync(temp);}catch{}
      throw Error('KDE 실행 경로를 저장하지 못했습니다. 매장 설정 폴더의 쓰기 권한을 확인해 주세요.');
    }
  };
  return {read,save};
}
function createKdeCliPath({run,exists=fs.existsSync,environment=process.env,readSaved=()=>'',saveFound=()=>{},
  listDirectory=directory=>fs.readdirSync(directory,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>e.name)}){
  const valid=file=>{
    try{return typeof file==='string'&&!file.includes('\0')&&path.win32.isAbsolute(file)&&
      path.win32.basename(file).toLowerCase()==='kdeconnect-cli.exe'&&exists(file);}catch{return false;}
  };
  const take=file=>{if(!valid(file))return null;saveFound(file);return file;};
  return async function discover(){
    const saved=readSaved();
    if(valid(saved))return saved;
    const pf=environment.ProgramFiles||'C:\\Program Files',x86=environment['ProgramFiles(x86)']||'C:\\Program Files (x86)';
    const local=environment.LOCALAPPDATA;
    const standard=[
      path.win32.join(pf,'KDE Connect','bin','kdeconnect-cli.exe'),
      path.win32.join(x86,'KDE Connect','bin','kdeconnect-cli.exe'),
      ...(local?[path.win32.join(local,'Programs','KDE Connect','bin','kdeconnect-cli.exe')]:[]),
    ];
    for(const file of standard){const found=take(file);if(found)return found;}
    const apps=path.win32.join(pf,'WindowsApps');let packages=[];
    try{packages=listDirectory(apps).filter(name=>/^KDEe\.V\.KDEConnect_[^\\/:*?"<>|\0]+$/i.test(name))
      .sort((a,b)=>b.localeCompare(a,'en',{numeric:true}));}catch{/* 보호 폴더 접근이 거부되면 사용자 실행 별칭을 계속 탐색한다. */}
    for(const name of packages){const found=take(path.win32.join(apps,name,'bin','kdeconnect-cli.exe'));if(found)return found;}
    if(local){const found=take(path.win32.join(local,'Microsoft','WindowsApps','kdeconnect-cli.exe'));if(found)return found;}
    let located;
    try{located=await run('where.exe',['kdeconnect-cli.exe'],'',2000);}catch{located=null;}
    if(located?.code===0)for(const line of located.out.split(/\r?\n/)){const found=take(line.trim());if(found)return found;}
    // 요청한 탐색 순서를 모두 거친 뒤 구형 bin 없는 설치 경로도 지원한다.
    for(const root of [pf,x86,...(local?[path.win32.join(local,'Programs')]:[])]){
      const found=take(path.win32.join(root,'KDE Connect','kdeconnect-cli.exe'));if(found)return found;
    }
    return null;
  };
}
// Only discovery may try alternatives. A send is executed exactly once.
function createKdeSms({run,exists,environment,readSaved,saveFound,listDirectory}){
  const executable=createKdeCliPath({run,exists,environment,readSaved,saveFound,listDirectory});
  async function target(){
    const cli=await executable();
    if(!cli)throw Error('KDE 실행 파일을 찾지 못했습니다. PC의 KDE 설치 상태를 확인해 주세요.');
    const listed=await run(cli,['--list-available','--id-only'],'',4000);
    const ids=[...new Set((listed.out||'').split(/\r?\n/).map(v=>v.trim()).filter(v=>/^[a-zA-Z0-9_-]{1,200}$/.test(v)))];
    if(listed.code!==0||ids.length!==1)throw Error(ids.length>1?'KDE 기기가 여러 대입니다. 발송할 휴대폰 한 대만 연결해 주세요.':'KDE 기기가 연결되어 있지 않습니다. 휴대폰 연결 상태를 확인해 주세요.');
    return {cli,id:ids[0]};
  }
  async function send(recipient,body){
    let device;
    try{device=await target();}catch(error){return {success:false,status:'unconfirmed',channel:'sms',copied:true,error:error.message};}
    const {cli,id}=device;
    const sent=await run(cli,['-d',id,'--destination',recipient,'--send-sms',body]);
    if(sent.code===0)return {success:true,status:'send_requested',channel:'sms',copied:true,detail:'KDE 문자 전송 요청을 실행했습니다.'};
    return {success:false,status:'unconfirmed',channel:'sms',copied:true,
      error:sent.timeout?'KDE 발송 결과를 확인하지 못했습니다. 중복 발송 방지를 위해 자동 재시도하지 않았습니다.':
        'KDE 문자 전송 요청에 실패했습니다. 자동 재시도하지 않았습니다.'};
  }
  send.share=async files=>{
    if(!Array.isArray(files)||!files.length||files.some(file=>typeof file!=='string'||!path.isAbsolute(file)||file.includes('\0')))
      throw Error('전송할 사진 파일을 확인해 주세요.');
    const {cli,id}=await target();let requested=0;
    for(const file of files){
      const result=await run(cli,['-d',id,'--share',file]);
      if(result.code!==0)return {success:false,status:'unconfirmed',channel:'sms',
        error:`사진 ${requested}개 전송 요청 후 중단했습니다. 현재 파일의 전송 결과는 미확인이며 자동 재시도하지 않았습니다.`};
      requested++;
    }
    return {success:true,status:'send_requested',channel:'sms',detail:`사진 ${requested}개를 연결된 스마트폰으로 전송 요청했습니다.`};
  };
  send.discover=executable;
  return send;
}
module.exports={createKdeSms,createKdeCliPath,createKdePathCache};
