'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const runtime=createRequire(path.join(__dirname,'../package.json')),ts=runtime('typescript'),m={exports:{}};
new Function('exports',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/ba-geometry.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(m.exports);
const geo=m.exports;
test('mark normalization respects contain letterboxing in editor and final JPEG',()=>{
  const editor=geo.containRect(1000,500,{x:0,y:0,w:400,h:400});
  assert.deepEqual(editor,{x:0,y:100,w:400,h:200});
  assert.deepEqual(geo.toNormalized({x:100,y:150},editor),{x:.25,y:.25});
  const final=geo.containRect(1000,500,{x:40,y:340,w:740,h:740});
  assert.deepEqual(geo.toAreaRect({x:.25,y:.25,w:.5,h:.5},final),{x:225,y:617.5,w:370,h:185});
});
test('marks can move and resize in either direction without crossing image bounds',()=>{
  const m={x:.2,y:.3,w:.4,h:.2};
  assert.deepEqual(geo.moveMark(m,2,-2),{x:.6,y:0,w:.4,h:.2});
  const resized=geo.resizeMark(m,'se',{x:.1,y:.1});
  assert.ok(Math.abs(resized.w-.1)<1e-9);assert.ok(Math.abs(resized.h-.2)<1e-9);
  assert.equal(geo.isUsableMark({w:.001,h:.2}),false);
  assert.equal(geo.strokeFor({w:740,h:740}),4);
});
test('exported circle and rectangle use strokes only, with matching normalized coordinates',()=>{
  const calls=[];
  const g=new Proxy({},{set:(o,k,v)=>(o[k]=v,true),get:(o,k)=>k in o?o[k]:(...args)=>calls.push([k,...args])});
  geo.drawMarks(g,[{id:'r',kind:'rect',color:'blue',x:.1,y:.2,w:.3,h:.4},
    {id:'c',kind:'circle',color:'red',x:.1,y:.2,w:.3,h:.4}],{x:40,y:50,w:200,h:100});
  assert.ok(calls.some(([k,x,y,w,h])=>k==='rect'&&x===60&&y===70&&w===60&&h===40));
  assert.ok(calls.some(([k])=>k==='ellipse'));
  assert.equal(calls.filter(([k])=>k==='stroke').length,2);
  assert.equal(calls.some(([k])=>k==='fill'||k==='fillRect'),false);
});
