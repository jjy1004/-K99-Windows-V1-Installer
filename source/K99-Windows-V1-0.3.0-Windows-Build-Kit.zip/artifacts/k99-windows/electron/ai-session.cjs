'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {AI_ORIGIN}=require('./ai-account-vault.cjs');
const AI_PARTITION='persist:k99-ai';
function migrateAiPartition(sessionData){
  const parent=path.join(sessionData,'Partitions'),target=path.join(parent,'k99-ai');
  const old=path.join(parent,'k99-washcare-ai');
  if(fs.existsSync(target)||!fs.existsSync(old))return false;
  fs.mkdirSync(parent,{recursive:true,mode:0o700});
  const temp=path.join(parent,'.k99-ai-'+crypto.randomUUID());
  try{
    fs.cpSync(old,temp,{recursive:true,force:false,errorOnExist:true,filter:source=>{
      if(fs.lstatSync(source).isSymbolicLink())throw Error('세션 저장소의 외부 연결 파일은 복사하지 않습니다.');
      return true;
    }});
    fs.renameSync(temp,target);return true;
  }catch{throw Error('기존 AI 처방 로그인 저장소를 안전하게 승계하지 못했습니다. 기존 저장소는 보존했습니다.');}
  finally{fs.rmSync(temp,{recursive:true,force:true});}
}
const FINGERPRINT_SCRIPT=`(async()=>{
  let installation=localStorage.getItem('k99.device.installation.v1');
  if(!installation){installation=crypto.randomUUID();localStorage.setItem('k99.device.installation.v1',installation);}
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(installation+'|'+navigator.platform));
  return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
})()`;
// Same public browser contract as the official app. No password enters a page script.
const AUTH_CACHE_SCRIPT=`(()=>{
  let phone=localStorage.getItem('k99_saved_phone')||'';
  if(!phone){
    const entry=document.cookie.split('; ').find(v=>v.startsWith('k99_saved_phone=')||v.startsWith('k99_registered_phone='));
    try{phone=entry?decodeURIComponent(entry.slice(entry.indexOf('=')+1)):'';}catch{}
  }
  const token=localStorage.getItem('k99_device_token')||'';
  return {phone:/^\\d{10,11}$/.test(phone)?phone:'',deviceToken:/^[A-Za-z0-9_-]{32,128}$/.test(token)?token:''};
})()`;
function createAiSession({sessionData,vault}){
  let prepared=false;
  const attached=new Map();
  function prepare(){
    if(!prepared){migrateAiPartition(sessionData);prepared=true;}
  }
  async function attach(webSession){
    if(attached.has(webSession))return attached.get(webSession).ready;
    const entry={timer:null};attached.set(webSession,entry);
    entry.ready=(async()=>{
    if(!vault.status().available)return;
    // Recover session cookies without extending a server-specified expiration.
    // Chromium itself keeps localStorage (including k99_device_token if present).
    const live=await webSession.cookies.get({url:AI_ORIGIN});
    for(const cookie of vault.cookies()){
      if(live.some(c=>c.name===cookie.name&&c.domain===cookie.domain&&c.path===cookie.path))continue;
      const cookiePath=typeof cookie.path==='string'&&cookie.path.startsWith('/')?cookie.path:'/';
      const value={url:AI_ORIGIN+cookiePath,name:cookie.name,value:cookie.value,path:cookiePath,
        secure:cookie.secure,httpOnly:cookie.httpOnly,sameSite:cookie.sameSite};
      if(!cookie.hostOnly)value.domain=cookie.domain;
      if(cookie.expirationDate)value.expirationDate=cookie.expirationDate;
      await webSession.cookies.set(value);
    }
    entry.listener=(_event,cookie)=>{
      if(cookie?.domain?.replace(/^\./,'')!==new URL(AI_ORIGIN).hostname)return;
      clearTimeout(entry.timer);
      entry.timer=setTimeout(()=>void snapshot(webSession).catch(()=>{}),120);entry.timer.unref?.();
    };
    webSession.cookies.on('changed',entry.listener);
    })();
    try{await entry.ready;}catch(error){attached.delete(webSession);throw error;}
  }
  async function snapshot(webSession){
    webSession.flushStorageData?.();
    await webSession.cookies.flushStore();
    if(vault.status().available)vault.saveCookies(await webSession.cookies.get({url:AI_ORIGIN}));
  }
  async function connect(win,target){
    const url=new URL(target);
    if(url.origin!==AI_ORIGIN)return {};
    try{
      const account=vault.status().available?vault.account():null;
      if(!account)return {}; // Browser token/cookie authentication remains authoritative.
      if(new URL(win.webContents.getURL()).origin!==AI_ORIGIN)throw Error();
      const fingerprint=await win.webContents.executeJavaScript(FINGERPRINT_SCRIPT);
      if(!/^[a-f0-9]{64}$/.test(fingerprint)||new URL(win.webContents.getURL()).origin!==AI_ORIGIN)throw Error();
      const cache=await win.webContents.executeJavaScript(AUTH_CACHE_SCRIPT);
      if(new URL(win.webContents.getURL()).origin!==AI_ORIGIN)throw Error();
      const deviceToken=cache?.phone===account.phone&&/^[A-Za-z0-9_-]{32,128}$/.test(cache?.deviceToken||'')?cache.deviceToken:null;
      const response=await win.webContents.session.fetch(AI_ORIGIN+'/api/washcare/member/login',{
        method:'POST',credentials:'include',redirect:'error',signal:AbortSignal.timeout(8000),
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({phone:account.phone,password:account.password,fingerprint,...deviceToken?{deviceToken}:{}}),
      });
      if(!response.ok)throw Error();
      const result=await response.json();
      if(result.authenticated!==true||!['operator','admin'].includes(result.role))throw Error();
      if(new URL(win.webContents.getURL()).origin!==AI_ORIGIN)throw Error();
      const phone=result.registeredPhone??account.phone;
      if(phone!==account.phone)throw Error();
      const token=typeof result.deviceToken==='string'&&/^[A-Za-z0-9_-]{32,128}$/.test(result.deviceToken)?result.deviceToken:null;
      await win.webContents.executeJavaScript(`(cache=>{
        if(localStorage.getItem('k99_saved_phone')!==cache.phone&&!cache.token)localStorage.removeItem('k99_device_token');
        localStorage.setItem('k99_saved_phone',cache.phone);
        if(cache.token)localStorage.setItem('k99_device_token',cache.token);
        document.cookie='k99_saved_phone='+encodeURIComponent(cache.phone)+'; Path=/; Max-Age=31536000; SameSite=Strict; Secure';
      })(${JSON.stringify({phone,token})})`);
      if(new URL(win.webContents.getURL()).origin!==AI_ORIGIN)throw Error();
      if(result.role==='admin'&&typeof result.adminEntryKey==='string'&&result.adminEntryKey.length<=2048){
        await win.webContents.executeJavaScript(`sessionStorage.setItem('k99.admin.entry',${JSON.stringify(result.adminEntryKey)})`);
      }
      if(['/', '/login'].includes(url.pathname))url.pathname='/search';
      await win.loadURL(url.href);
      await snapshot(win.webContents.session);
      return {authenticated:true};
    }catch{
      // No raw server/error text, credentials or token is returned to staff UI/logs.
      return {warning:'AI 처방 자동 로그인을 완료하지 못했습니다. 휴대폰·비밀번호, 인터넷 연결 또는 본사 기기 승인을 확인하세요. 열린 처방 창에서 직접 로그인할 수 있습니다.'};
    }
  }
  async function flush(){
    for(const [webSession,entry]of attached){await entry.ready;clearTimeout(entry.timer);await snapshot(webSession);}
  }
  return {prepare,attach,connect,flush};
}
module.exports={AI_PARTITION,FINGERPRINT_SCRIPT,AUTH_CACHE_SCRIPT,migrateAiPartition,createAiSession};
