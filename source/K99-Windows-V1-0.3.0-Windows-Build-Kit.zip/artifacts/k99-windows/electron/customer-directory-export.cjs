'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const MAX_CSV_BYTES=32*1024*1024;
/** Native save only: no browser download permission, DB write or network access. */
function createCustomerDirectoryExport({pickFile,authorize}){
  return async input=>{
    if(typeof input?.csv!=='string'||!input.csv.startsWith('\uFEFF')||
      !/^K99_고객명부_접수이력_\d{8}\.csv$/.test(input.fileName||''))
      throw Error('고객 명부 CSV 형식을 확인할 수 없습니다.');
    const bytes=Buffer.from(input.csv,'utf8');
    if(bytes.length>MAX_CSV_BYTES)throw Error('고객 CSV가 32MB를 초과합니다. 고객 검색으로 범위를 줄여 다시 저장하세요.');
    if(typeof authorize!=='function')throw Error('고객 명부 내보내기 보안 검증이 연결되지 않았습니다.');
    // Main-process verification precedes both the save dialog and any disk write.
    await authorize(input.password);
    const target=await pickFile(input.fileName);
    if(!target)return {saved:false,cancelled:true};
    if(typeof target!=='string'||target.includes('\0')||path.extname(target).toLowerCase()!=='.csv')
      throw Error('고객 명부는 .csv 파일로만 저장할 수 있습니다.');
    let original;
    try{original=await fs.lstat(target);}catch(error){if(error.code!=='ENOENT')throw error;}
    if(original&&(!original.isFile()||original.isSymbolicLink()))throw Error('일반 CSV 파일만 저장 대상으로 선택하세요.');
    const temp=path.join(path.dirname(target),`.k99-csv-${crypto.randomUUID()}.tmp`);
    let handle;
    try{
      handle=await fs.open(temp,'wx',0o600);
      await handle.writeFile(bytes);await handle.sync();await handle.close();handle=null;
      let latest;
      try{latest=await fs.lstat(target);}catch(error){if(error.code!=='ENOENT')throw error;}
      if(original?(!latest||latest.ino!==original.ino||latest.size!==original.size||latest.mtimeMs!==original.mtimeMs):!!latest)
        throw Error('저장 중 대상 파일이 변경되었습니다. 다른 파일명으로 다시 저장하세요.');
      await fs.rename(temp,target);
      return {saved:true,cancelled:false,filePath:target,bytes:bytes.length};
    }catch(error){
      throw Error(`고객 명부 CSV 저장 실패: ${error.message}`);
    }finally{
      if(handle)await handle.close().catch(()=>{});
      await fs.unlink(temp).catch(()=>{});
    }
  };
}
module.exports={createCustomerDirectoryExport,MAX_CSV_BYTES};
