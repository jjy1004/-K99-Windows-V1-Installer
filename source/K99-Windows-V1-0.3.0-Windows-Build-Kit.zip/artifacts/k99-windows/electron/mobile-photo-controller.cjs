'use strict';
const {createMobilePhotoBridge}=require('./mobile-photo-bridge.cjs');
const {imageBytes}=require('./photo-archive.cjs');
const {AsyncLocalStorage}=require('node:async_hooks');
const clean=value=>String(value||'미입력').normalize('NFC').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_')
  .replace(/^[ .]+|[ .]+$/g,'').slice(0,80)||'미입력';
const digits=value=>String(value||'').replace(/\D/g,'');
const fail=message=>Object.assign(Error(message),{status:409});
function createMobilePhotoController({store,equipmentApi,archivePhoto,nativeImage,changed,native=process.platform==='win32',...network}){
  // Async context isolates the mobile filename from concurrent PC shots.
  // Neither the original capture queue, DB logic nor printer code is changed.
  const captureContext=new AsyncLocalStorage();
  function validateTarget(input){
    if(!native||store.equipment.getConfig().mode!=='real')throw fail('휴대폰 사진 저장은 실제 장비 모드의 Windows 앱에서 사용합니다.');
    if(!input||typeof input.unitKey!=='string')throw fail('촬영할 고객과 품목을 선택하세요.');
    const draft=JSON.parse(store.storage({op:'get',key:'k99-active-staff-intake-v1'})||'null');
    const [rowId,unitIndex]=input.unitKey.split(':').map(Number);
    const row=draft?.data?.rows?.find(r=>r.id===rowId);
    if(draft?.draftId!==input.orderId||!row||row.itemId!==input.itemId||
      !Number.isSafeInteger(unitIndex)||unitIndex<1||unitIndex>row.quantity||
      String(draft.data.customerName||'').trim()!==String(input.customerName||'').trim()||
      digits(draft.data.customerPhone)!==digits(input.customerPhone)||digits(input.customerPhone).length<4)
      throw fail('고객 또는 접수 품목이 변경되었습니다. 현재 접수창에서 새 QR을 열어 주세요.');
    const plan=store.equipment.drafts.plan({...input,expectedMode:'real'});
    const order=plan.order;
    const date=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'})
      .format(new Date(order.createdAt)).replace(/-/g,'');
    return {orderId:input.orderId,customerName:order.customerName,phoneLast4:digits(order.customerPhone).slice(-4),
      itemName:input.itemName,folderIdentifier:order.archiveFolderKey||`${date}_${clean(order.customerName)}_${digits(order.customerPhone).slice(-4)||'번호없음'}`};
  }
  const bridge=createMobilePhotoBridge({...network,validateTarget,notify:changed,capture:async input=>{
    validateTarget(input);
    const {bytes}=imageBytes(input.imageDataUrl);
    const image=nativeImage.createFromBuffer(bytes);
    if(image.isEmpty())throw Error('손상되었거나 지원하지 않는 사진입니다.');
    const size=image.getSize();
    if(size.width<1||size.height<1||size.width>8192||size.height>8192)throw Error('사진 해상도는 가로·세로 8192픽셀 이하로 선택해 주세요.');
    // This joins the SAME serialized capture queue as OBS/foot-switch photos.
    if(!/^MOBILE_\d{8}_\d{6}_\d{3}_[a-f0-9]{8}\.jpg$/.test(input.mobileFileName||''))throw fail('휴대폰 사진 파일명 오류');
    return captureContext.run(input.mobileFileName,()=>equipmentApi.api('POST','/api/equipment/command',{
      ...input,action:'capture-draft',expectedMode:'real',photo_type:'intake'}));
  }});
  return {...bridge,archivePhoto:plan=>{
    const mobileFileName=captureContext.getStore();
    return archivePhoto(mobileFileName&&!plan.existingFileName?{...plan,existingFileName:mobileFileName}:plan);
  },api:(method,pathname,input)=>{
    const url=new URL(pathname,'http://local');
    if(method==='GET'&&url.pathname==='/api/mobile-photo/draft'){
      const orderId=url.searchParams.get('orderId');
      if(!/^[A-Za-z0-9_-]{8,100}$/.test(orderId||''))throw Error('접수 초안 식별자 오류');
      return store.equipment.drafts.state(orderId);
    }
    return bridge.api(method,pathname,input);
  }};
}
module.exports={createMobilePhotoController};
