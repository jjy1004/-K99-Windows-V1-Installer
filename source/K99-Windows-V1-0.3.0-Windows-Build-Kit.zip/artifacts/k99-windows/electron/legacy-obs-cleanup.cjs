'use strict';
// Cleanup only. Never launch OBS, stop its process, uninstall it or change
// generic/user-created OBS startup entries.
const fs=require('node:fs/promises'),path=require('node:path');
const {execFile}=require('node:child_process');
const SHORTCUT='OBS Studio - K99 자동 실행.lnk';
const VALUES=Object.freeze(['OBS Studio - K99 자동 실행','K99ObsAutoStart']);
const RUN='Software\\Microsoft\\Windows\\CurrentVersion\\Run';
function ownedCommand(name,command){
  if(!VALUES.includes(name)||typeof command!=='string'||command.length>8192||/[\r\n\0]/.test(command))return false;
  // An exact reserved K99 name AND a direct OBS executable AND the legacy
  // virtual-camera flag are all required. Never remove cmd/PowerShell wrappers.
  const match=/^\s*(?:"([^"]+)"|([^\s"]+))\s+(.*)$/.exec(command);
  return !!match&&/(?:^|\\)obs(?:32|64)\.exe$/i.test(match[1]||match[2])&&
    /(?:^|\s)--startvirtualcam(?:\s|$)/.test(match[3]);
}
function createLegacyObsCleanup({platform=process.platform,env=process.env,stat=fs.lstat,unlink=fs.unlink,
  execute=(file,args)=>new Promise((resolve,reject)=>execFile(file,args,
    {windowsHide:true,timeout:3000,maxBuffer:65536,shell:false},
    (error,stdout)=>error?reject(error):resolve(stdout))),
}={}){
  return async function clean(){
    const result={shortcutsRemoved:0,registryRemoved:0,skipped:0};
    if(platform!=='win32')return result;
    const system=path.win32.join(env.SystemRoot||'C:\\Windows','System32');
    const reg=path.win32.join(system,'reg.exe');
    for(const hive of ['HKCU','HKLM'])for(const view of ['32','64'])for(const name of VALUES){
      const key=`${hive}\\${RUN}`;
      try{
        const text=await execute(reg,['query',key,'/v',name,`/reg:${view}`]);
        const command=/\bREG_(?:EXPAND_)?SZ[ \t]+([^\r\n]+)/.exec(text)?.[1];
        if(!ownedCommand(name,command)){result.skipped++;continue;}
        // Re-read before removal; do not remove a changed entry.
        const again=await execute(reg,['query',key,'/v',name,`/reg:${view}`]);
        if(/\bREG_(?:EXPAND_)?SZ[ \t]+([^\r\n]+)/.exec(again)?.[1]!==command){result.skipped++;continue;}
        await execute(reg,['delete',key,'/v',name,'/f',`/reg:${view}`]);
        result.registryRemoved++;
      }catch{result.skipped++;} // Missing entries, policy/admin denial are benign.
    }
    const folders=[
      env.APPDATA&&path.win32.join(env.APPDATA,'Microsoft','Windows','Start Menu','Programs','Startup'),
      env.ProgramData&&path.win32.join(env.ProgramData,'Microsoft','Windows','Start Menu','Programs','Startup'),
    ].filter(Boolean);
    for(const folder of folders){
      const file=path.win32.join(folder,SHORTCUT);
      try{
        const before=await stat(file);
        if(!before.isFile()||before.isSymbolicLink()){result.skipped++;continue;}
        // Exact path is encoded, not interpolated into PowerShell source.
        const encoded=Buffer.from(file,'utf16le').toString('base64');
        const script=`$p=[Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('${encoded}'));if(Test-Path -LiteralPath $p -PathType Leaf){$s=(New-Object -ComObject WScript.Shell).CreateShortcut($p);@{target=$s.TargetPath;arguments=$s.Arguments}|ConvertTo-Json -Compress}`;
        const output=await execute(path.win32.join(system,'WindowsPowerShell','v1.0','powershell.exe'),
          ['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')]);
        const data=JSON.parse(output);
        if(!ownedCommand(VALUES[0],`"${data.target}" ${data.arguments}`)){result.skipped++;continue;}
        const after=await stat(file);
        if(!after.isFile()||after.isSymbolicLink()||before.size!==after.size||before.mtimeMs!==after.mtimeMs){result.skipped++;continue;}
        await unlink(file);result.shortcutsRemoved++;
      }catch{result.skipped++;}
    }
    return result;
  };
}
module.exports={createLegacyObsCleanup,ownedCommand,SHORTCUT,VALUES};
