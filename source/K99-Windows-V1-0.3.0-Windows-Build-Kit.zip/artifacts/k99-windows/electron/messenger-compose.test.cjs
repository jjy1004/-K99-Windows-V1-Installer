'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');
const {createAutoMessenger,SCRIPT}=require('./services/autoMessenger.js');
const {createKakaoLauncher,DISCOVERY_SCRIPT,BACKGROUND_SCRIPT}=require('./services/kakao-launch.cjs');
const body='고객님 안내 원문\n면책·동의 금액 12,300원 & + ? # %\n줄바꿈도 그대로 보존합니다.';
function nativeFixture(options={}){
  const events=[],jobs=[],clipboard=[];
  const spawnProcess=(exe,args,opts)=>{
    const child=new EventEmitter();child.stdin=new PassThrough();child.stdout=new PassThrough();child.stderr=new PassThrough();
    child.unref=()=>{};child.kill=()=>{events.push('중단');queueMicrotask(()=>child.emit('close',1));};
    const job={exe,args,opts,input:''};jobs.push(job);
    if(exe==='tasklist.exe'){
      queueMicrotask(()=>{child.stdout.end(options.running?'"KakaoTalk.exe","123","Console","1","1 K"':'INFO: no tasks');child.emit('close',0);});
    }else if(exe.toLowerCase().endsWith('kakaotalk.exe'))queueMicrotask(()=>child.emit('spawn'));
    else if(exe==='powershell.exe'){
      child.stdin.on('data',chunk=>{job.input+=chunk;});
      child.stdin.on('finish',()=>{
        const script=Buffer.from(args.at(-1),'base64').toString('utf16le');
        if(options.timeout)return;
        events.push(script===SCRIPT?'화면 확인':'시작');
        queueMicrotask(()=>{child.stdout.end(script===SCRIPT?JSON.stringify(options.result||{status:'prepared',focused:true}):'K99_KAKAO_STARTED');child.emit('close',0);});
      });
    }
    return child;
  };
  const service=createAutoMessenger({platform:'win32',spawnProcess,timeoutMs:25,exists:()=>true,
    environment:{ProgramFiles:'C:\\Program Files'},shell:{openExternal:async uri=>{
      events.push(uri);if(options.openError)throw Error('기본 처리 앱 없음');
    }},clipboard:{writeText:text=>{events.push('복사');if(options.copyError)throw Error('복사 실패');clipboard.push(text);},
      readText:()=>options.copyMismatch?'다른 글':clipboard.at(-1)}});
  return {service,events,jobs,clipboard};
}
test('문자 입력은 전체 원문 복사 → 인코딩 URI → 포커스·고객 번호·본문 확인 순서이며 발송하지 않는다',async()=>{
  const f=nativeFixture(),r=await f.service.command({action:'sms-compose',recipient:'010-0000-0001',body});
  assert.equal(f.events[0],'복사');
  assert.equal(f.events[1],`sms:01000000001?body=${encodeURIComponent(body)}`);
  assert.equal(f.events[2],'화면 확인');
  assert.deepEqual(f.clipboard,[body]);assert.equal(r.bodyVerified,true);assert.equal(r.focused,true);
  assert.equal(r.status,'prepared');assert.equal(r.manualRequired,true);
  const job=f.jobs.find(j=>j.exe==='powershell.exe'),request=JSON.parse(job.input);
  assert.equal(request.mode,'verify-compose');assert.equal(request.phone,'01000000001');assert.equal(request.body,body);
  assert(!JSON.stringify(job.args).includes('01000000001'));assert(!JSON.stringify(job.args).includes(body));
  assert.equal(f.jobs.length,1,'SMS는 카카오·다른 앱을 실행하지 않는다');
  const block=SCRIPT.slice(SCRIPT.indexOf("if($p.mode -eq 'verify-compose')"),SCRIPT.indexOf('$messageValue.SetValue($p.body)'));
  assert.match(block,/Current\.Value/);assert.doesNotMatch(block,/SetValue|Invoke\(\)|SendKeys/);
  assert(SCRIPT.indexOf('GetForegroundWindow() -ne $handle')<SCRIPT.indexOf("if($p.mode -eq 'verify-compose')"));
});
test('길고 한글인 전체 원문도 URI 길이 때문에 본문을 버리거나 요약하지 않는다',async()=>{
  const full='고객 안내 원문 '.repeat(1000),f=nativeFixture({result:{status:'unsupported'}});
  const r=await f.service.command({action:'sms-compose',recipient:'01000000001',body:full});
  assert(f.events[1].length>25000);
  assert.equal(decodeURIComponent(f.events[1].split('?body=')[1]),full);
  assert.equal(f.clipboard[0],full);assert.equal(r.success,false);assert.equal(r.bodyVerified,false);
  assert.match(r.detail,/확인되지 않았/);assert.match(r.detail,/Ctrl\+V/);
});
test('기본 SMS 앱 미설치·긴 URI 거절은 원문 복사를 보존하고 자동 재시도하지 않는다',async()=>{
  const f=nativeFixture({openError:true}),r=await f.service.command({action:'sms-compose',recipient:'01000000001',body});
  assert.equal(r.success,false);assert.equal(r.copied,true);assert.equal(f.clipboard[0],body);
  assert.equal(f.events.filter(x=>x.startsWith('sms:')).length,1);assert.equal(f.jobs.length,0);
  assert.match(r.detail,/기본 SMS 앱/);
});
test('클립보드 실패·읽기 불일치·잘못된 수신자는 외부 앱을 열기 전에 차단한다',async()=>{
  for(const option of [{copyError:true},{copyMismatch:true}]){
    const f=nativeFixture(option);
    await assert.rejects(f.service.command({action:'sms-compose',recipient:'01000000001',body}),/복사/);
    assert.equal(f.jobs.length,0);assert(!f.events.some(x=>x.startsWith('sms:')));
  }
  for(const input of [{recipient:'0001',body},{recipient:'01000000001',body:''},{recipient:'01000000001',body:'글\0'}]){
    const f=nativeFixture();await assert.rejects(f.service.command({action:'sms-compose',...input}),/번호|원문/);
    assert.equal(f.events.length,0);
  }
});
test('포커스 거부·앱 결과 오류·확인 지연은 준비 성공으로 위조하지 않고 원문과 수신자를 유지한다',async()=>{
  for(const option of [{result:{status:'unsupported',focused:false}},{result:{status:'unconfirmed',focused:true}},{timeout:true}]){
    const f=nativeFixture(option),r=await f.service.command({action:'sms-compose',recipient:'01000000001',body});
    assert.equal(r.success,false);assert.equal(r.status,'unconfirmed');assert.equal(r.copied,true);
    assert.equal(f.clipboard[0],body);assert.equal(f.events.filter(x=>x.startsWith('sms:')).length,1);
  }
});
test('문자 처리 중 카카오 재요청은 중복 실행하지 않으며 종료 후 다시 준비할 수 있다',async()=>{
  const f=nativeFixture({timeout:true});
  const pending=f.service.command({action:'sms-compose',recipient:'01000000001',body});
  await assert.rejects(f.service.command({action:'kakao-compose',body}),/잠시/);
  await pending;
  await f.service.command({action:'sms-compose',recipient:'01000000001',body});
  assert.equal(f.events.filter(x=>x.startsWith('sms:')).length,2);
});
test('실행 중 카카오는 재실행하지 않고 원문 복사와 포커스 요청만 한다',async()=>{
  const f=nativeFixture({running:true});
  const r=await f.service.command({action:'kakao-compose',recipient:'01000000001',body});
  assert.equal(r.success,true);assert.equal(r.focused,true);assert.deepEqual(f.clipboard,[body]);
  assert(!f.jobs.some(j=>j.exe.toLowerCase().endsWith('kakaotalk.exe')));
  assert.equal(JSON.parse(f.jobs.find(j=>j.exe==='powershell.exe').input).mode,'focus-only');
  assert(!f.events.some(x=>/^https?:|sms:/.test(x)));
});
function launcherFixture(options={}){
  const calls=[],starts=[],exe=options.exe||'C:\\Custom\\KakaoTalk.exe';
  const run=async(command,args,input)=>{
    const script=command==='powershell.exe'?Buffer.from(args.at(-1),'base64').toString('utf16le'):'';
    calls.push({command,args,input,script});
    if(command==='tasklist.exe'){
      if(options.hold)await options.hold;
      return options.processError?{error:true}: {code:0,out:options.running?'"KakaoTalk.exe","1"':'INFO: no tasks'};
    }
    if(command==='reg.exe')return options.registry&&args.at(-1)==='/reg:32'?{code:0,out:` REG_EXPAND_SZ    ${options.registry}\r\n`}:{code:1};
    if(script===DISCOVERY_SCRIPT)return {code:0,out:JSON.stringify(options.paths||[])};
    if(script===BACKGROUND_SCRIPT)return {code:0,out:'K99_KAKAO_STARTED'};
    throw Error('예상 밖 실행');
  };
  const spawnProcess=(file,args,opts)=>{
    starts.push({file,args,opts});const child=new EventEmitter();child.unref=()=>{};
    queueMicrotask(()=>child.emit('spawn'));return child;
  };
  const client=createKakaoLauncher({run,spawnProcess,timeoutMs:50,exists:p=>p===exe,
    environment:{ProgramFiles:'C:\\Program Files',LOCALAPPDATA:'C:\\Fixture\\Local'}});
  return {client,calls,starts,exe};
}
test('표준·사용자 Programs·레지스트리 32/64·바탕화면·Uninstall·프로세스 후보에서 유효한 실행 파일만 선택한다',async()=>{
  const installed=[
    'C:\\Program Files (x86)\\Kakao\\KakaoTalk\\KakaoTalk.exe',
    'C:\\Program Files\\Kakao\\KakaoTalk\\KakaoTalk.exe',
    'C:\\Fixture\\Local\\Programs\\Kakao\\KakaoTalk\\KakaoTalk.exe',
  ];
  for(const exe of installed)assert.equal(await launcherFixture({exe}).client.resolvePath(),exe);
  const registry=launcherFixture({exe:'C:\\Fixture\\Local\\Custom\\KakaoTalk.exe',registry:'%LOCALAPPDATA%\\Custom\\KakaoTalk.exe'});
  assert.equal(await registry.client.resolvePath(),registry.exe);
  assert(registry.calls.some(c=>c.args.at(-1)==='/reg:64'));assert(registry.calls.some(c=>c.args.at(-1)==='/reg:32'));
  for(const paths of [
    ['C:\\Shortcut Target\\KakaoTalk.exe'],['C:\\Uninstall Location\\KakaoTalk.exe'],['D:\\Running App\\KakaoTalk.exe'],
  ]){
    const f=launcherFixture({exe:paths[0],paths:['https://example.invalid/KakaoTalk.exe','relative\\KakaoTalk.exe','C:\\Wrong.exe',...paths]});
    assert.equal(await f.client.resolvePath(),paths[0]);
  }
  assert.match(DISCOVERY_SCRIPT,/CommonDesktopDirectory/);assert.match(DISCOVERY_SCRIPT,/CreateShortcut/);
  assert.match(DISCOVERY_SCRIPT,/WOW6432Node/);assert.match(DISCOVERY_SCRIPT,/Uninstall/);assert.match(DISCOVERY_SCRIPT,/Get-Process -Name KakaoTalk/);
});
test('시작과 버튼 요청이 겹쳐도 한 번만 최소화 실행하고 시작 때 포커스를 빼앗지 않는다',async()=>{
  let release;
  const hold=new Promise(resolve=>{release=resolve;}),f=launcherFixture({hold,paths:['C:\\Custom\\KakaoTalk.exe']});
  const startup=f.client.ensure(true),button=f.client.ensure(false);
  release();const result=await Promise.all([startup,button]);
  assert(result.every(r=>r.status==='started'));assert.equal(f.starts.length,0);
  const launches=f.calls.filter(c=>c.script===BACKGROUND_SCRIPT);
  assert.equal(launches.length,1);assert.equal(JSON.parse(launches[0].input).path,f.exe);
  assert.match(BACKGROUND_SCRIPT,/-WindowStyle Minimized/);assert.doesNotMatch(BACKGROUND_SCRIPT,/AppActivate|SetForegroundWindow|SendKeys/);
  await f.client.ensure(false);
  assert.equal(f.starts.length,0,'프로세스 목록 반영 지연 때도 재실행하지 않는다');
});
test('실행 상태 확인 실패나 잘못된 설치 후보는 새 실행·외부 페이지로 대체하지 않는다',async()=>{
  const blocked=launcherFixture({processError:true});
  assert.equal((await blocked.client.ensure()).status,'unknown');assert.equal(blocked.starts.length,0);
  const absent=launcherFixture({paths:['C:\\Bad\\Other.exe','https://example.invalid/KakaoTalk.exe']});
  assert.equal((await absent.client.ensure()).status,'not-installed');assert.equal(absent.starts.length,0);
});
