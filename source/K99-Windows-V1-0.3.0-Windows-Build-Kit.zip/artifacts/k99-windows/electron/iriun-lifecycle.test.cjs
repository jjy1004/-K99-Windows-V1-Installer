'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createIriunLifecycle}=require('./smartphone-camera.cjs');
const exe='C:\\Program Files (x86)\\Iriun Webcam\\IriunWebcam.exe';
const defaults={platform:'win32',env:{'ProgramFiles(x86)':'C:\\Program Files (x86)'},
  stat:async p=>({isFile:()=>p===exe}),execute:async()=>'',launch:async()=>123};
test('concurrent startup and camera-open never duplicate the receiver',async()=>{
  let launches=0;const app=createIriunLifecycle({...defaults,launch:async p=>{assert.equal(p,exe);launches++;return 123;}});
  await Promise.all([app.ensureReceiver(),app.ensureReceiver(),app.session({active:true,mode:'wifi'})]);
  assert.equal(launches,1);
});
test('running receiver is not relaunched or its visible settings window hidden',async()=>{
  let launches=0,commands=[];const app=createIriunLifecycle({...defaults,launch:async()=>{launches++;},
    execute:async(f,args)=>{commands.push(f);return '"IriunWebcam.exe","122","Console","1","100 K"';}});
  assert.equal((await app.ensureReceiver()).running,true);assert.equal(launches,0);assert.deepEqual(commands,['tasklist.exe']);
});
test('missing receiver or blocked process checks never installs software, opens pages or throws',async()=>{
  const missing=createIriunLifecycle({...defaults,stat:async()=>{throw Error('absent');}});
  assert.equal((await missing.ensureReceiver()).installed,false);
  const blocked=createIriunLifecycle({...defaults,execute:async()=>{throw Error('timeout');},launch:async()=>{throw Error('must not launch');}});
  assert.equal((await blocked.ensureReceiver()).running,false);
});
test('optional minimization is asynchronous, bounded, encoded and failure tolerant',async()=>{
  let checked=false;
  const app=createIriunLifecycle({...defaults,execute:async(f,args,opts)=>{
    if(f==='tasklist.exe')return '';
    assert.equal(f,'powershell.exe');assert.equal(opts.timeout,3500);assert(args.includes('-EncodedCommand'));
    assert.match(Buffer.from(args.at(-1),'base64').toString('utf16le'),/Get-Process -Id 123/);
    checked=true;throw Error('security product blocked PowerShell');
  }});
  assert.equal((await app.ensureReceiver()).backgroundVerified,false);assert(checked);
});
test('USB without installed ADB is silently skipped; close never sleeps or kills the phone',async()=>{
  const commands=[];const app=createIriunLifecycle({...defaults,execute:async(f,args)=>{commands.push([f,...args]);return '"IriunWebcam.exe","122"';}});
  assert.equal((await app.session({active:true,mode:'usb'})).phoneWakeRequested,false);
  assert.deepEqual(await app.session({active:false,mode:'usb'}),{released:true});
  assert(!commands.some(c=>c.join(' ').includes('SLEEP')));
});
test('USB requests wake only for a single authorized device with Iriun installed',async()=>{
  const commands=[],adb='C:\\platform-tools\\adb.exe';
  const app=createIriunLifecycle({...defaults,stat:async p=>({isFile:()=>p===exe||p===adb}),execute:async(f,args)=>{
    commands.push([f,...args]);
    if(f==='tasklist.exe')return '"IriunWebcam.exe","122"';
    if(args[0]==='devices')return 'List of devices attached\nSHOP123\tdevice\n';
    if(args.includes('packages'))return 'package:com.jacksoftw.webcam\n';
    return '';
  }});
  assert.equal((await app.session({active:true,mode:'usb'})).phoneWakeRequested,true);
  assert(commands.some(c=>c.includes('KEYCODE_WAKEUP')));
  assert(commands.some(c=>c.includes('monkey')));
});
test('close during receiver lookup cancels phone wake and invalid inputs are rejected',async()=>{
  let resolve;const app=createIriunLifecycle({...defaults,execute:()=>new Promise(r=>{resolve=r;})});
  const pending=app.session({active:true,mode:'usb'});
  while(!resolve)await new Promise(r=>setImmediate(r));
  await app.session({active:false,mode:'usb'});resolve('"IriunWebcam.exe","122"');
  assert.equal((await pending).cancelled,true);
  await assert.rejects(app.session({active:true,mode:'other'}),/잘못된/);
});
test('unauthorized, multiple, emulator and wireless ADB targets are never woken automatically',async()=>{
  const adb='C:\\platform-tools\\adb.exe';
  for(const devices of ['PHONE\tunauthorized','ONE\tdevice\nTWO\tdevice','emulator-5554\tdevice','192.168.0.5:5555\tdevice',
    'adb-PHONE-TEST._adb-tls-connect._tcp\tdevice']){
    const calls=[];
    const app=createIriunLifecycle({...defaults,stat:async p=>({isFile:()=>p===exe||p===adb}),execute:async(f,args)=>{
      calls.push(args);return f==='tasklist.exe'?'"IriunWebcam.exe","122"':devices;
    }});
    assert.equal((await app.session({active:true,mode:'usb'})).phoneWakeRequested,false);
    assert(!calls.some(args=>args.includes('shell')));
  }
});
test('사용자 AppData의 Iriun 수신기도 촬영창 진입 시 자동 실행한다',async()=>{
  const file='C:\\Users\\Store\\AppData\\Local\\Programs\\Iriun Webcam\\IriunWebcam.exe',launched=[];
  const app=createIriunLifecycle({...defaults,env:{LOCALAPPDATA:'C:\\Users\\Store\\AppData\\Local'},
    stat:async p=>({isFile:()=>p===file}),launch:async p=>{launched.push(p);return 123;}});
  assert.equal((await app.session({active:true,mode:'wifi'})).running,true);
  assert.deepEqual(launched,[file]);
});
test('검색 경로 밖에서 이미 실행된 Iriun도 중복 실행하지 않는다',async()=>{
  let opens=0;
  const app=createIriunLifecycle({...defaults,stat:async()=>{throw Error('경로 없음');},
    execute:async()=>'"IriunWebcam.exe","456"',launch:async()=>{opens++;}});
  assert.equal((await app.ensureReceiver()).running,true);assert.equal(opens,0);
});
