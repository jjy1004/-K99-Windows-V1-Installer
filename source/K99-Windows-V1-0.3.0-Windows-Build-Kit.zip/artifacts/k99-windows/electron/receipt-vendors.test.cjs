'use strict';
// 실제 제품 API를 호출하되 Windows 창·인쇄기만 대체한다. 운영 DB·장비는 사용하지 않는다.
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY}=require('./hardware-settings.cjs');
const {escPosReceipt}=require('./receipt-serial.cjs');
const vendors=[['easycheck','KICC EasyCheck TS-167'],['kis','KIS정보통신 receipt'],['nice','NICE Smartro receipt']];
const receipt={customerName:'출력 모사 고객',customerPhone:'01000000000',paymentType:'POSTPAID',
  items:[{name:'정장 상의',quantity:2,amount:200000}],totalAmount:170000,
  discountAmount:30000,discountRate:15,tierDiscountAmount:30000};
const evidence=[];
function fixture(t){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-vendor-simulation-'));
  const filename=path.join(dir,'simulation.sqlite');
  let store=createStore(filename,'test',{nativeDesktop:true});
  const state={devices:vendors.map(([,name])=>({name})),mode:'ok',prints:[],html:[],destroyed:0,ports:[{name:'COM3'}],serial:[]};
  const adapters={printers:async()=>state.devices,ports:async()=>state.ports,
    serialReceipt:async input=>{state.serial.push(escPosReceipt(input));return {message:'모사 전송: 실물 출력 아님'};}};
  class FakeWindow{
    constructor(){
      this.closed=false;
      this.webContents={print:(options,done)=>{
        state.prints.push(options);
        if(state.mode==='throw')throw Error('모사 스풀러 예외');
        if(state.mode==='hold'){state.finish=done;return;}
        done(state.mode!=='reject',state.mode==='reject'?'모사 용지 없음':'');
      }};
    }
    async loadURL(url){
      if(state.mode==='load-error')throw Error('모사 접수증 화면 준비 실패');
      state.html.push(decodeURIComponent(url.slice(url.indexOf(',')+1)));
    }
    isDestroyed(){return this.closed;}
    destroy(){this.closed=true;state.destroyed++;}
  }
  const api=()=>createHardwareSettings({store,adapters,BrowserWindow:FakeWindow,native:true,
    shell:{openExternal:async()=>{throw Error('외부 실행 금지');}}});
  t.after(()=>{store.close();fs.rmSync(dir,{recursive:true,force:true});});
  return {state,api,get store(){return store;},reopen(){store.close();store=createStore(filename,'test',{nativeDesktop:true});}};
}
for(const [vendor,name] of vendors){
  test(`${vendor}: 자동 선택·재시작·58/80mm 실제 접수증 API와 출력 호출 모사`,async t=>{
    const f=fixture(t);
    const equipment=JSON.stringify(f.store.equipment.getConfig());
    const orders=f.store.storage({op:'get',key:'k99-confirmed-orders-v1'});
    let api=f.api();
    const selected=await api({action:'select-receipt-vendor',vendor});
    assert.equal(selected.selection.state,'configured');
    assert.equal(selected.config.receiptPrinterName,name);
    assert.equal(f.state.prints.length,0,'회사 선택만으로 인쇄하지 않는다');
    f.reopen();
    api=f.api();
    const restored=await api({action:'status'});
    assert.equal(restored.config.receiptVendor,vendor);
    assert.equal(restored.terminal.connected,false,'출력기 선택을 카드 승인 연결로 위조하지 않는다');
    for(const width of [58,80]){
      await api({action:'save-receipt',config:{receiptWidth:width,receiptPromo:'모사 홍보 첫 줄\n모사 홍보 둘째 줄'}});
      const preview=await api({action:'receipt-preview',receipt});
      assert.match(preview.html,/모사 홍보 첫 줄<br>모사 홍보 둘째 줄/);
      for(const text of ['정장 상의','200,000','30,000','170,000','15%','후불'])
        assert(preview.html.includes(text),text);
      const result=await api({action:'receipt-print',receipt});
      assert.match(result.message,/인쇄 대기열/);
      assert.equal(f.state.html.at(-1),preview.html,'미리보기와 인쇄 HTML 일치');
      assert.equal(f.state.prints.at(-1).deviceName,name);
      assert.equal(f.state.prints.at(-1).pageSize.width,width*1000);
      assert.equal(f.state.prints.at(-1).silent,true);
      evidence.push({vendor,name,width,previewMatchesPrint:true,
        simulatedSpoolerSubmission:true,realCardApproval:false,cardSlipIssued:false,
        html:preview.html});
    }
    assert.equal(f.state.destroyed,2);
    assert.equal(JSON.stringify(f.store.equipment.getConfig()),equipment);
    assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),orders);
    await api({action:'select-receipt-vendor',vendor:'none'});
    await assert.rejects(api({action:'receipt-print',receipt}),/사용하지 않도록/);
    assert.equal(f.state.prints.length,2);
  });
  test(`${vendor}: 미연결·여러 후보·스풀러 실패·재시도·중복 인쇄 방어`,async t=>{
    const f=fixture(t),api=f.api();
    f.state.devices=[];
    const before=f.store.storage({op:'get',key:KEY});
    assert.equal((await api({action:'select-receipt-vendor',vendor})).selection.state,'missing');
    assert.equal(f.store.storage({op:'get',key:KEY}),before);
    f.state.devices=[{name:name+' A'},{name:name+' B'}];
    assert.equal((await api({action:'select-receipt-vendor',vendor})).selection.state,'ambiguous');
    assert.equal(f.store.storage({op:'get',key:KEY}),before);
    f.state.devices=[{name}];
    await api({action:'select-receipt-vendor',vendor});
    const saved=f.store.storage({op:'get',key:KEY});
    f.state.devices=[];
    assert.match((await api({action:'receipt-preview',receipt})).html,/세탁 접수증/);
    await assert.rejects(api({action:'receipt-print',receipt}),/연결된 접수증/);
    assert.equal(f.state.prints.length,0);
    f.state.devices=[{name}];
    for(const mode of ['reject','throw','load-error']){
      f.state.mode=mode;
      await assert.rejects(api({action:'receipt-print',receipt}),/모사/);
      f.state.mode='ok';
      await api({action:'receipt-print',receipt});
    }
    f.state.mode='hold';
    const pending=api({action:'receipt-print',receipt});
    while(!f.state.finish)await new Promise(resolve=>setImmediate(resolve));
    const count=f.state.prints.length;
    await assert.rejects(api({action:'receipt-print',receipt}),/중복/);
    assert.equal(f.state.prints.length,count);
    f.state.finish(true);await pending;
    assert.equal(f.store.storage({op:'get',key:KEY}),saved);
    await assert.rejects(api({action:'card-approved',approvalNumber:'FAKE'}),/지원하지 않는/);
    assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
    evidence.push({vendor,errorAndManualRetry:true,duplicateBlocked:true,deviceMissingSafe:true,
      realCardApproval:false,cardSlipIssued:false});
  });
}
test('TS-167: 기존 COM3·9600·CP949·절단 설정 보존과 실제 ESC/POS 조립 모사',async t=>{
  const f=fixture(t),api=f.api();
  await api({action:'save-receipt',config:{receiptType:'easycheck',receiptVendor:'easycheck',
    receiptTransport:'serial',receiptPort:'COM3',receiptBaudRate:9600,
    receiptEncoding:'cp949',receiptCut:true,receiptEscPosVerified:true,receiptPromo:'기존 홍보 문구'}});
  const before=f.store.storage({op:'get',key:KEY});
  await api({action:'select-receipt-vendor',vendor:'easycheck'});
  await api({action:'receipt-print',receipt});
  const packet=f.state.serial[0];
  assert.equal(packet.preferences.receiptBaudRate,9600);
  assert.equal(packet.preferences.receiptPort,'COM3');
  assert.equal(packet.preferences.receiptEncoding,'cp949');
  assert(packet.data.includes(require('iconv-lite').encode('정장 상의','cp949')));
  assert.deepEqual(packet.cut,Buffer.from([0x1d,0x56,0]));
  f.state.ports=[];
  await assert.rejects(api({action:'receipt-print',receipt}),/COM 포트/);
  assert.equal(f.store.storage({op:'get',key:KEY}),before);
  assert.equal(f.state.serial.length,1);
  evidence.push({vendor:'easycheck',transport:'serial',baud:9600,encoding:'cp949',
    cutHex:packet.cut.toString('hex'),payloadBytes:packet.data.length,realCardApproval:false,cardSlipIssued:false});
});
test.after(()=>{
  if(!process.env.K99_RECEIPT_SIMULATION_DIR)return;
  const dir=path.resolve(process.env.K99_RECEIPT_SIMULATION_DIR);fs.mkdirSync(dir,{recursive:true});
  for(const item of evidence.filter(x=>x.html)){
    fs.writeFileSync(path.join(dir,`${item.vendor}-${item.width}mm.html`),item.html);
  }
  fs.writeFileSync(path.join(dir,'simulation-results.json'),JSON.stringify({
    simulationOnly:true,realDevicesUsed:false,realCardApprovalTested:false,
    cardSlipGeneration:'제조사 승인 규격 미제공으로 검증 제외',
    results:evidence.map(({html,...entry})=>entry)},null,2));
});
