'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ts=require(require.resolve('typescript',{paths:[path.join(__dirname,'..')]}));
function load(name){const result={};new Function('exports',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src',name+'.ts'),'utf8'),
  {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(result);return result;}
const {CameraHardware}=load('camera-hardware'),color=load('camera-color');
function fixture({caps={},reject=false,ignore=false,hang=false}={}){
  const calls=[],s={exposureMode:'manual',whiteBalanceMode:'manual',focusMode:'manual',exposureTime:10,gain:2,iso:100,exposureCompensation:0};
  const capabilities={exposureMode:['manual','continuous'],whiteBalanceMode:['manual','continuous'],focusMode:['manual','continuous'],
    exposureTime:{min:1,max:100,step:1},gain:{min:0,max:20,step:1},iso:{min:100,max:800,step:100},
    exposureCompensation:{min:-2,max:2,step:.5},...caps};
  let stops=0,current=true,resolve;
  const track={readyState:'live',stop(){stops++;},getSettings:()=>({...s}),getCapabilities:()=>capabilities,
    applyConstraints:async c=>{calls.push(c);if(reject)throw Error('driver refused');
      if(hang)await new Promise(r=>{resolve=r;});
      if(!ignore)Object.assign(s,c.advanced[0]);}};
  return {c:new CameraHardware(track,()=>current,20),s,calls,stops:()=>stops,cancel:()=>{current=false;},resolve:()=>resolve?.()};
}
test('supported automatic UVC settings run after open without stopping or renegotiating a stream',async()=>{
  const f=fixture();assert.equal(f.calls.length,0);
  assert.deepEqual(await f.c.automatic(),[]);
  for(const key of ['exposureMode','whiteBalanceMode','focusMode'])assert.equal(f.s[key],'continuous');
  assert.equal(f.stops(),0);assert(f.calls.every(c=>Object.keys(c).join()==='advanced'));
});
test('manual CS focus and unavailable gain are not represented as supported controls',async()=>{
  const f=fixture({caps:{focusMode:undefined,gain:undefined}});
  assert.equal(f.c.read().controls.gain,null);await f.c.automatic();
  assert(!f.calls.some(c=>'focusMode'in c.advanced[0]));
  await assert.rejects(f.c.set('gain',5),/지원/);assert.equal(f.stops(),0);
});
test('actual exposure and gain readback is required, with manual mode and current shutter retained',async()=>{
  const f=fixture();const p=await f.c.set('exposureTime',25);assert.equal(p.exposureTime,25);assert.equal(p.exposureMode,'manual');
  const gain=await f.c.set('gain',7);assert.equal(gain.gain,7);assert.equal(f.s.exposureTime,25);
  assert.equal(f.calls[1].advanced[0].exposureTime,25);
  const ignored=fixture({ignore:true});
  await assert.rejects(ignored.c.set('exposureTime',35),/적용값/);
  assert.equal(ignored.stops(),0);
});
test('driver errors and deadlines leave preview track live and do not race late hardware writes',async()=>{
  const bad=fixture({reject:true});assert((await bad.c.automatic()).length>0);assert.equal(bad.stops(),0);
  const hung=fixture({hang:true});await assert.rejects(hung.c.set('gain',3),/늦습니다/);
  assert.equal(hung.c.busy,true);await assert.rejects(hung.c.set('gain',4),/기다리고/);
  assert.equal(hung.calls.length,1);assert.equal(hung.stops(),0);
  hung.resolve();await new Promise(r=>setTimeout(r,0));assert.equal(hung.c.busy,false);
});
test('saved manual exposure restores after automatic initialization; unsupported values never silently succeed',async()=>{
  const f=fixture();await f.c.automatic();await f.c.restore({exposureMode:'manual',exposureTime:30,gain:8});
  assert.equal(f.s.exposureMode,'manual');assert.equal(f.s.exposureTime,30);assert.equal(f.s.gain,8);
  assert((await f.c.restore({exposureMode:'manual',gain:200})).length>0);
  f.cancel();await assert.rejects(f.c.set('gain',4),/변경/);
});
function frame(background=[150,154,160],garment=[45,100,170]){
  const width=120,height=80,data=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const at=(y*width+x)*4,c=x>30&&x<90&&y>20&&y<60?garment:background;
    data.set([...c,255],at);
  }
  return {width,height,data};
}
test('neutral white edges brighten naturally while blue cloth stays blue and highlights do not clip',()=>{
  const f=frame(),r=color.naturalCameraProfile(f,color.DEFAULT_CAMERA_COLOR);
  assert.equal(color.validColorProfile(r.profile),true);
  color.makeColorTransform(r.profile)(f);
  const white=[...f.data.slice(0,3)],at=(40*120+60)*4,blue=[...f.data.slice(at,at+3)];
  assert(Math.max(...white)-Math.min(...white)<=2);assert(white.every(v=>v>=240&&v<255));
  assert(blue[2]>blue[1]&&blue[1]>blue[0]);assert.equal(f.data[at+3],255);
});
test('blue clothing filling edges, black or clipped backgrounds do not invent a white reference',()=>{
  for(const bg of [[35,85,150],[0,0,0],[255,255,255]]){
    assert.throws(()=>color.naturalCameraProfile(frame(bg,bg),color.DEFAULT_CAMERA_COLOR),/흰 배경/);
  }
});
test('soft sharpening bounds halos and does not amplify low-level sensor noise',()=>{
  const values=[60,60,60,255,200,200,200,255,60,60,60,255],f={width:3,height:1,data:new Uint8ClampedArray(values)};
  color.makeColorTransform({...color.DEFAULT_CAMERA_COLOR,sharpness:100})(f);
  for(let i=0;i<values.length;i++)assert(Math.abs(f.data[i]-values[i])<=8);
  const noise={width:3,height:1,data:new Uint8ClampedArray([100,100,100,255,101,101,101,255,100,100,100,255])};
  const before=[...noise.data];color.makeColorTransform({...color.DEFAULT_CAMERA_COLOR,sharpness:100})(noise);
  assert.deepEqual([...noise.data],before);
});
test('natural reference and confirmed hardware preferences persist per camera without adding a DB table',()=>{
  const values=new Map(),storage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v)};
  const p={...color.naturalCameraProfile(frame(),color.DEFAULT_CAMERA_COLOR).profile,
    hardware:{exposureMode:'manual',exposureTime:25,gain:6}};
  color.saveCameraColor('su200mb',p,storage);
  assert.deepEqual(color.loadCameraColor('su200mb',storage),p);
  assert.deepEqual(color.loadCameraColor('other',storage),color.DEFAULT_CAMERA_COLOR);
});
