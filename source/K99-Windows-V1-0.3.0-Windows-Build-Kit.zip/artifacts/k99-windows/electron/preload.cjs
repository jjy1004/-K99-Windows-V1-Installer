'use strict';
const {contextBridge,ipcRenderer} = require('electron');
// No raw IPC, SQL, filesystem access, paths or secret material exposed.
contextBridge.exposeInMainWorld('k99Desktop',Object.freeze({
  storage:input => ipcRenderer.sendSync('k99:storage',input),
  request:input => ipcRenderer.invoke('k99:request',input),
  onChanged:callback => {
    const handler=()=>callback();
    ipcRenderer.on('k99:changed',handler);
    return ()=>ipcRenderer.removeListener('k99:changed',handler);
  },
}));
