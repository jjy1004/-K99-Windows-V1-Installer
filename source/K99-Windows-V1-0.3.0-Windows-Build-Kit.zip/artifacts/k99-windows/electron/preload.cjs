'use strict';
const {contextBridge,ipcRenderer} = require('electron');
// No raw IPC, SQL, filesystem access, paths or secret material exposed.
contextBridge.exposeInMainWorld('k99Desktop',Object.freeze({
  setFootCaptureActive:input=>ipcRenderer.invoke('k99:foot-active',input),
  onFootCapture:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('k99:foot-capture',handler);
    return ()=>ipcRenderer.removeListener('k99:foot-capture',handler);
  },
  customerAction:data=>ipcRenderer.send('customer-action',data),
  customerEvent:data=>ipcRenderer.send('customer-event',data),
  customerStatus:()=>ipcRenderer.invoke('customer-status'),
  onCustomerUpdate:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('customer-update',handler);
    return ()=>ipcRenderer.removeListener('customer-update',handler);
  },
  onCustomerConnection:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('customer-connection',handler);
    return ()=>ipcRenderer.removeListener('customer-connection',handler);
  },
  storage:input => ipcRenderer.sendSync('k99:storage',input),
  request:input => ipcRenderer.invoke('k99:request',input),
  importCustomerLedger:()=>ipcRenderer.invoke('k99:import-customer-ledger'),
  searchCustomers:keyword=>ipcRenderer.invoke('k99:search-customers',keyword),
  customerPhotos:input=>ipcRenderer.invoke('k99:customer-photos',input),
  onChanged:callback => {
    const handler=()=>callback();
    ipcRenderer.on('k99:changed',handler);
    return ()=>ipcRenderer.removeListener('k99:changed',handler);
  },
}));
