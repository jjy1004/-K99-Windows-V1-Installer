'use strict';
const {contextBridge,ipcRenderer} = require('electron');
// Do not transmit keys, field values or text. A boolean activity signal is
// enough to postpone installation until the operator closes the application.
let updateActivitySent=false;
function noteUpdateActivity(){
  if(updateActivitySent)return;
  updateActivitySent=true;ipcRenderer.send('k99:update-user-active');
}
window.addEventListener('pointerdown',noteUpdateActivity,{capture:true});
window.addEventListener('keydown',noteUpdateActivity,{capture:true});
// No raw IPC, SQL, filesystem access, paths or secret material exposed.
contextBridge.exposeInMainWorld('k99Desktop',Object.freeze({
  cameraConnection:action=>ipcRenderer.invoke('k99:camera-connection',action),
  iriunSession:input=>ipcRenderer.invoke('k99:iriun-session',input),
  messenger:input=>ipcRenderer.invoke('k99:messenger',input),
  openProgram:input=>ipcRenderer.invoke('k99:open-program',input),
  aiAccount:input=>ipcRenderer.invoke('k99:ai-account',input),
  storageLayout:input=>ipcRenderer.invoke('k99:storage-layout',input),
  onLuxuryResult:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('k99:luxury-result',handler);
    return ()=>ipcRenderer.removeListener('k99:luxury-result',handler);
  },
  idleVideos:action=>ipcRenderer.invoke('k99:idle-videos',action),
  onIdleVideosChanged:callback=>{
    const handler=()=>callback();
    ipcRenderer.on('k99:idle-videos-changed',handler);
    return ()=>ipcRenderer.removeListener('k99:idle-videos-changed',handler);
  },
  downloadCustomerTemplate:()=>ipcRenderer.invoke('k99:customer-template'),
  setFootCaptureActive:input=>ipcRenderer.invoke('k99:foot-active',input),
  onFootCapture:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('k99:foot-capture',handler);
    return ()=>ipcRenderer.removeListener('k99:foot-capture',handler);
  },
  customerAction:data=>ipcRenderer.send('customer-action',data),
  customerEvent:data=>ipcRenderer.send('customer-event',data),
  customerStatus:()=>ipcRenderer.invoke('customer-status'),
  onCustomerUpdate:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('customer-update',handler);
    return ()=>ipcRenderer.removeListener('customer-update',handler);
  },
  onCustomerConnection:callback=>{
    const handler=(_event,data)=>callback(data);
    ipcRenderer.on('customer-connection',handler);
    return ()=>ipcRenderer.removeListener('customer-connection',handler);
  },
  storage:input => ipcRenderer.sendSync('k99:storage',input),
  request:input => ipcRenderer.invoke('k99:request',input),
  importCustomerLedger:()=>ipcRenderer.invoke('k99:import-customer-ledger'),
  searchCustomers:keyword=>ipcRenderer.invoke('k99:search-customers',keyword),
  customerPhotos:input=>ipcRenderer.invoke('k99:customer-photos',input),
  photoSource:input=>ipcRenderer.invoke('k99:photo-source',input),
  analyzeCareLabel:(photoId,options)=>ipcRenderer.invoke('analyze-care-label',photoId,{automatic:options?.automatic===true}),
  onChanged:callback => {
    const handler=()=>callback();
    ipcRenderer.on('k99:changed',handler);
    return ()=>ipcRenderer.removeListener('k99:changed',handler);
  },
}));
