'use strict';
const http=require('node:http'),crypto=require('node:crypto');
const {lanAddresses,privateIPv4}=require('./mobile-photo-bridge.cjs');
const {noticeMobilePage}=require('./notice-mobile-page.cjs');
const fail=(m,status=400)=>Object.assign(Error(m),{status});
function createNoticeMobile({getNotices,changed=()=>{},native=process.platform==='win32',
  addresses=lanAddresses,host='0.0.0.0',port=0,now=Date.now}){
  const sessions=new Map(),sockets=new Set();let server,starting,generation=0;
  const clean=()=>{for(const [k,s] of sessions)if(s.expiresAt<=now())sessions.delete(k);};
  async function start(input={}){
    if(!native)throw fail('휴대폰 고지 입력은 Windows 설치형 프로그램의 매장 네트워크에서 사용합니다.',501);
    if(input.orderId)getNotices().context(input.orderId);
    if(input.customerScope&&(!input.customerScope.name||!/^\d{9,11}$/.test(String(input.customerScope.phone||'').replace(/\D/g,''))))
      throw fail('고객명과 전체 연락처를 확인한 뒤 특별 고지 QR을 열어 주세요.');
    const ips=addresses();if(!ips.length)throw fail('PC와 휴대폰을 같은 매장 Wi-Fi에 연결해 주세요.',503);
    clean();if(sessions.size>=20)throw fail('열린 QR이 많습니다. 기존 QR 만료 후 다시 열어 주세요.',429);
    if(!server){
      if(!starting)starting=new Promise((resolve,reject)=>{
        const version=generation;
        const next=http.createServer((req,res)=>void handle(req,res));next.maxConnections=8;
        next.requestTimeout=15000;next.headersTimeout=10000;next.keepAliveTimeout=2000;
        next.on('connection',s=>{sockets.add(s);s.on('close',()=>sockets.delete(s));});
        next.once('error',reject);next.listen(port,host,()=>{
          if(version!==generation){next.close();reject(fail('QR 연결 요청이 취소되었습니다.',409));return;}
          server=next;resolve();
        });
      }).finally(()=>{starting=null;});
      await starting;
    }
    const token=crypto.randomBytes(32).toString('base64url'),expiresAt=now()+10*60*1000;
    sessions.set(token,{expiresAt,ips,orderId:input.orderId||'',customerScope:input.customerScope||null,receipts:new Map()});
    return {url:`http://${ips[0]}:${server.address().port}/mobile-notice?token=${token}`,expiresAt};
  }
  function session(req,url){
    clean();const token=req.headers['x-k99-notice-token']||url.searchParams.get('token'),s=sessions.get(token);
    if(!s)throw fail('QR이 만료되었습니다. 매장 PC에서 다시 연결해 주세요.',410);
    if(!privateIPv4(req.socket.remoteAddress)||!s.ips.some(ip=>req.headers.host===`${ip}:${server.address().port}`))throw fail('QR의 매장 내부 주소로 연결해 주세요.',403);
    if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`)throw fail('다른 사이트의 요청은 허용하지 않습니다.',403);
    return s;
  }
  function allowed(s,orderId){
    if(s.orderId&&s.orderId!==orderId)throw fail('QR에 연결된 고객 주문만 입력할 수 있습니다.',403);
    const c=getNotices().context(orderId);
    if(s.customerScope&&(c.customerName!==s.customerScope.name||
      c.customerPhone.replace(/\D/g,'')!==s.customerScope.phone.replace(/\D/g,'')))throw fail('QR에 연결된 고객만 입력할 수 있습니다.',403);
    return c;
  }
  function send(res,status,result,html=false){
    res.writeHead(status,{'Content-Type':html?'text/html; charset=utf-8':'application/json; charset=utf-8',
      'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"});
    res.end(html?result:JSON.stringify(result));
  }
  async function handle(req,res){
    try{
      const url=new URL(req.url,'http://local'),s=session(req,url);
      if(req.method==='GET'&&url.pathname==='/mobile-notice')return send(res,200,noticeMobilePage,true);
      if(req.method==='GET'&&url.pathname==='/api/mobile-notice/orders'){
        const keyword=url.searchParams.get('keyword')||s.customerScope?.name||'';
        let orders=getNotices().listOrders(keyword,s.orderId,s.customerScope);
        if(s.customerScope)orders=orders.filter(o=>{try{allowed(s,o.orderId);return true;}catch{return false;}});
        return send(res,200,{orders,expiresAt:s.expiresAt});
      }
      if(req.method!=='POST'||url.pathname!=='/api/mobile-notice/save')throw fail('지원하지 않는 요청입니다.',404);
      if(!String(req.headers['content-type']||'').startsWith('application/json')||
        req.headers.origin!==`http://${req.headers.host}`)throw fail('휴대폰 고지 입력 화면에서 전송해 주세요.',403);
      const chunks=[];let size=0;for await(const part of req){size+=part.length;if(size>64000)throw fail('고지 내용이 너무 깁니다.',413);chunks.push(part);}
      const data=Buffer.concat(chunks).toString('utf8');
      session(req,url);
      const input=JSON.parse(data);allowed(s,input.orderId);
      if(!/^[\w-]{8,100}$/.test(input.requestId||''))throw fail('전송 식별자를 확인해 주세요.');
      const hash=crypto.createHash('sha256').update(data).digest('hex'),old=s.receipts.get(input.requestId);
      if(old){if(old.hash!==hash)throw fail('같은 전송 번호의 내용이 다릅니다.',409);return send(res,200,old.result);}
      if(s.receipts.size>=100)throw fail('이 QR의 전송 한도에 도달했습니다. 새 QR을 열어 주세요.',429);
      const result=getNotices().save({orderId:input.orderId,templateId:'after-stain',body:input.body,theme:input.theme||'휴대폰 특별 고지'},'mobile');
      s.receipts.set(input.requestId,{hash,result});changed();send(res,200,result);
    }catch(e){send(res,e.status||400,{error:e.status?e.message:'고지 내용을 확인하고 다시 시도해 주세요.'});}
  }
  function close(){generation++;sessions.clear();server?.close();for(const s of sockets)s.destroy();server=null;sockets.clear();}
  return {start,close};
}
module.exports={createNoticeMobile};
