'use strict';
const {ipcRenderer}=require('electron');
// Remote calculator receives no Node, filesystem, database or general IPC bridge.
window.addEventListener('message',event=>{
  if(event.source!==window||event.origin!==window.location.origin||event.data?.type!=='K99_LUXURY_RESULT')return;
  const {sessionId,itemName,finalPrice}=event.data;
  ipcRenderer.invoke('k99:calculator-result',{sessionId,itemName,finalPrice}).catch(()=>{});
});
