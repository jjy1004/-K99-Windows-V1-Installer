'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createHash}=require('node:crypto'),{createRequire}=require('node:module');
const ts=createRequire(path.join(__dirname,'../package.json'))('typescript');
// Fingerprints of the working pre-automation camera functions, with comments
// and whitespace normalised by TypeScript. No Git history is needed in CI.
const baseline={
  'camera-capture-controls.ts':{
    warmPreferredCamera:'481bac28fad167cc233817b7d9a041373073478c4c3eee421a5579ef53359c3d',
    openPreferredCamera:'230ad0c45c5c4ec87a3c3d50f3fa0744afc472c4b75f53a57cc529900bebf046'},
};
for(const [file,expected] of Object.entries(baseline))test(`${file}: original camera connection functions remain intact`,()=>{
  const original=fs.readFileSync(path.join(__dirname,'../src',file),'utf8');
  const text=original;
  const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX),found={};
  const printer=ts.createPrinter({removeComments:true});
  function visit(node){
    if((ts.isFunctionDeclaration(node)||ts.isVariableDeclaration(node))&&node.name&&Object.hasOwn(expected,node.name.getText(source))){
      found[node.name.getText(source)]=createHash('sha256').update(printer.printNode(ts.EmitHint.Unspecified,node,source)).digest('hex');
    }
    ts.forEachChild(node,visit);
  }
  visit(source);assert.deepEqual(found,expected);
});
test('both capture surfaces delegate stop to a single abort/track/context cleanup owner',()=>{
  for(const file of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const text=fs.readFileSync(path.join(__dirname,'../src',file),'utf8');
    assert.match(text,/useIriunCamera\(videoRef,streamRef,/);assert.match(text,/camera\.stop\(\)/);
    assert.doesNotMatch(text,/openIriunCamera\(/);
  }
  const manager=fs.readFileSync(path.join(__dirname,'../src/iriun-manager.ts'),'utf8');
  assert.match(manager,/s\.abort\.abort\(\)/);
  assert.match(manager,/getTracks\(\)\.forEach\(t => t\.stop\(\)\)/);
  assert.match(manager,/s\.video\.srcObject = null/);
  assert.match(manager,/s\.context\?\.dispose\(\)/);
});
