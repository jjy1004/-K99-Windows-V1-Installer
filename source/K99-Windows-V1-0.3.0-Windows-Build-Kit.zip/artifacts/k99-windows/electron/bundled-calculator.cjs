'use strict';
const fs=require('node:fs'),path=require('node:path');
// Optional complete calculator bundle; never overwrite a shop's installed files.
function deployBundledCalculator(source,target){
  if(!source||!target||!fs.existsSync(source))return {available:false,copied:0};
  const files=[];
  function walk(folder,relative=''){
    if(fs.lstatSync(folder).isSymbolicLink())throw Error('계산기 번들의 링크는 허용하지 않습니다.');
    for(const entry of fs.readdirSync(folder,{withFileTypes:true})){
      const rel=path.join(relative,entry.name),file=path.join(folder,entry.name);
      if(entry.isSymbolicLink())throw Error('계산기 번들의 링크는 허용하지 않습니다.');
      if(entry.isDirectory())walk(file,rel);
      else if(entry.isFile())files.push({rel,file});
    }
  }
  walk(source);
  if(!files.some(x=>/\.exe$/i.test(x.rel)))return {available:false,copied:0};
  fs.mkdirSync(target,{recursive:true});
  // Existing installation remains authoritative; mixing versions is unsafe.
  if(fs.readdirSync(target).length)return {available:true,copied:0,preserved:true};
  let copied=0;
  const created=[];
  try{
    // Dependencies precede executables: interrupted installation never exposes
    // an executable before its companion resources have been copied.
    files.sort((a,b)=>Number(/\.exe$/i.test(a.rel))-Number(/\.exe$/i.test(b.rel)));
    for(const {rel,file} of files){
      const destination=path.join(target,rel);
      fs.mkdirSync(path.dirname(destination),{recursive:true});
      fs.copyFileSync(file,destination,fs.constants.COPYFILE_EXCL);
      created.push(destination);copied++;
    }
  }catch(error){
    for(const file of created.reverse())fs.rmSync(file,{force:true});
    throw error;
  }
  return {available:true,copied};
}
module.exports={deployBundledCalculator};
