'use strict';
require('node:test').test('prescription defaults migrate only legacy blank values and preserve explicit overrides',()=>{
  const assert=require('node:assert/strict'),{settingsWithDefaults,DEFAULT_PRESCRIPTION_URL}=require('./program-integrations.cjs');
  assert.equal(DEFAULT_PRESCRIPTION_URL,'https://k-99-washcare-ai.replit.app');
  assert.equal(settingsWithDefaults(null).prescriptionUrl,DEFAULT_PRESCRIPTION_URL);
  assert.equal(settingsWithDefaults({luxuryTarget:'',prescriptionUrl:''}).prescriptionUrl,DEFAULT_PRESCRIPTION_URL);
  assert.equal(settingsWithDefaults({luxuryTarget:'',prescriptionUrl:'',prescriptionConfigured:true}).prescriptionUrl,'');
  assert.equal(settingsWithDefaults({luxuryTarget:'',prescriptionUrl:'https://custom.example.test'}).prescriptionUrl,'https://custom.example.test');
});
const test=require('node:test'),assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {validateSettings,validateLuxuryResult,prescriptionUrl,createProgramLauncher,SETTINGS_KEY}=require('./program-integrations.cjs');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
test('luxury default fills new/legacy blank settings while preserving shop overrides and matches renderer',()=>{
  const {settingsWithDefaults,DEFAULT_LUXURY_URL}=require('./program-integrations.cjs');
  assert.equal(DEFAULT_LUXURY_URL,'https://k-99-luxury-laundry-pricing.replit.app');
  assert.equal(settingsWithDefaults(null).luxuryTarget,DEFAULT_LUXURY_URL);
  assert.equal(settingsWithDefaults({luxuryTarget:' ',prescriptionUrl:''}).luxuryTarget,DEFAULT_LUXURY_URL);
  for(const target of ['https://custom.example.test/calculator','C:\\Shop\\Luxury.exe'])
    assert.equal(settingsWithDefaults({luxuryTarget:target,prescriptionUrl:''}).luxuryTarget,target);
  const renderer=fs.readFileSync(path.join(__dirname,'../src/program-integrations.ts'),'utf8');
  assert.ok(renderer.includes(`DEFAULT_LUXURY_URL = '${DEFAULT_LUXURY_URL}'`));
  assert.match(renderer,/luxuryTarget: value\.luxuryTarget\.trim\(\) \|\| DEFAULT_LUXURY_URL/);
});
test('integration settings accept HTTPS/Windows exe/blank; reject unsafe protocols, UNC, credentials and shell strings',()=>{
  assert.deepEqual(validateSettings({luxuryTarget:' C:\\K99 럭셔리\\K99.exe ',prescriptionUrl:''}),
    {luxuryTarget:'C:\\K99 럭셔리\\K99.exe',prescriptionUrl:''});
  for(const luxuryTarget of ['javascript:alert(1)','file:///etc/passwd','http://example.test','https://u:p@example.test','\\\\server\\x.exe','C:\\app.exe --argument'])
    assert.throws(()=>validateSettings({luxuryTarget,prescriptionUrl:''}));
  assert.equal(validateSettings({luxuryTarget:'https://example.test/calc',prescriptionUrl:''}).luxuryTarget,'https://example.test/calc');
});
test('prescription query preserves existing arguments and encodes selected Korean values without PII',()=>{
  const url=new URL(prescriptionUrl('https://example.test/?mode=clean&material=old#view',{material:'울/실크',color:'흰색'}));
  assert.equal(url.searchParams.get('material'),'울/실크');assert.equal(url.searchParams.get('color'),'흰색');
  assert.equal(url.searchParams.get('mode'),'clean');assert.equal(url.hash,'#view');assert.equal([...url.searchParams.keys()].length,3);
});
test('luxury result rejects missing, excessive, negative and malformed monetary data',()=>{
  assert.deepEqual(validateLuxuryResult({itemName:' 명품 코트 ',finalPrice:35000}),{itemName:'명품 코트',finalPrice:35000});
  for(const input of [{itemName:'',finalPrice:2},{itemName:'x',finalPrice:'3'},{itemName:'x',finalPrice:-1},
    {itemName:'x',finalPrice:0},{itemName:'x',finalPrice:0.5},{itemName:'x',finalPrice:100000001}])assert.throws(()=>validateLuxuryResult(input));
});
test('unresponsive external web app is closed after a bounded navigation instead of hanging IPC',async()=>{
  let destroyed=false;
  class Window extends EventEmitter{
    constructor(){super();this.webContents={session:{setPermissionRequestHandler(){}},setWindowOpenHandler(){},on(){}};}
    loadURL(){return new Promise(()=>{});}
    destroy(){destroyed=true;this.emit('closed');}
  }
  const launcher=createProgramLauncher({BrowserWindow:Window,owner:()=>null,navigationTimeoutMs:10,
    readSettings:()=>({luxuryTarget:'https://example.test',prescriptionUrl:'https://k-99-washcare-ai.replit.app'})});
  await assert.rejects(launcher.open('prescription',{material:'울/실크',color:'유색'}),/연동 페이지/);
  assert.equal(destroyed,true);launcher.close();
});
test('settings survive actual SQLite close/reopen without adding orders',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-integrations-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  let store=createStore(path.join(dir,'k99.db'));
  const value=JSON.stringify({luxuryTarget:'C:\\K99\\Luxury.exe',prescriptionUrl:'https://example.test/prescribe'});
  store.storage({op:'set',key:SETTINGS_KEY,value,expected:null});store.close();
  store=createStore(path.join(dir,'k99.db'));
  assert.equal(store.storage({op:'get',key:SETTINGS_KEY}),value);store.close();
});
function setup(){
  const windows=[],values=[];
  class Window extends EventEmitter {
    constructor(options){super();this.options=options;this.webContents=new EventEmitter();this.webContents.mainFrame={url:'https://example.test/calc'};
      this.webContents.setWindowOpenHandler=fn=>{this.openHandler=fn;};this.webContents.session={setPermissionRequestHandler:fn=>{this.permissionHandler=fn;}};
      windows.push(this);
    }
    async loadURL(url){this.url=url;}
    destroy(){this.emit('closed');}
  }
  const launcher=createProgramLauncher({readSettings:()=>({luxuryTarget:'https://example.test/calc',prescriptionUrl:'https://example.test/ai'}),
    BrowserWindow:Window,owner:()=>null,onResult:r=>values.push(r),spawn:()=>{throw Error('must not spawn');}});
  return {launcher,windows,values};
}
test('calculator web window isolates Node and restricts navigation; matching result delivered once only',async()=>{
  const {launcher,windows,values}=setup();await launcher.open('luxury',{material:'나일론',color:'유색'});
  const win=windows[0],sessionId=new URL(win.url).searchParams.get('k99_session');
  assert.equal(win.options.webPreferences.nodeIntegration,false);assert.equal(win.options.webPreferences.sandbox,true);
  assert.deepEqual(win.openHandler(),{action:'deny'});
  let denied=false;win.webContents.emit('will-navigate',{preventDefault(){denied=true;}},'file:///C:/secret');assert.ok(denied);
  const input={sessionId,itemName:'코트',finalPrice:88000};
  assert.throws(()=>launcher.receive({sender:{},senderFrame:{}},input));
  const event={sender:win.webContents,senderFrame:win.webContents.mainFrame};
  assert.deepEqual(launcher.receive(event,input),{itemName:'코트',finalPrice:88000});assert.equal(values.length,1);
  assert.throws(()=>launcher.receive(event,input));launcher.close();
});
test('AI window receives material/color but no result IPC preload; empty URL never opens',async()=>{
  const {launcher,windows}=setup();await launcher.open('prescription',{material:'식물성 섬유',color:'유색'});
  assert.equal(new URL(windows[0].url).searchParams.get('material'),'식물성 섬유');
  assert.equal(windows[0].options.webPreferences.partition,'persist:k99-ai');
  await launcher.open('prescription',{material:'울/실크',color:'흰색'});
  assert.equal(windows[1].options.webPreferences.partition,windows[0].options.webPreferences.partition);
  assert.equal(windows[0].options.webPreferences.preload,undefined);launcher.close();
  const empty=createProgramLauncher({readSettings:()=>({luxuryTarget:'',prescriptionUrl:''})});
  await assert.rejects(empty.open('prescription',{}),/추후/);
});
test('exe launch uses argument array without shell; session JSON result accepted exactly once (mock process)',async t=>{
  const cwd=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-exe-contract-'));
  process.chdir(dir);t.after(()=>{process.chdir(cwd);fs.rmSync(dir,{recursive:true,force:true});});
  const target='C:\\K99 계산기\\Luxury.exe';fs.writeFileSync(target,'test executable placeholder; never executed');
  const values=[];let args,options;
  const launcher=createProgramLauncher({platform:'win32',readSettings:()=>({luxuryTarget:target,prescriptionUrl:''}),
    resultFolder:path.join(dir,'results'),onResult:value=>values.push(value),
    spawn:(file,a,o)=>{assert.equal(file,target);args=a;options=o;const child=new EventEmitter();
      queueMicrotask(()=>child.emit('spawn'));return child;}});
  t.after(()=>launcher.close());
  await launcher.open('luxury',{});
  assert.equal(options.shell,false);assert.equal(args[0],'--k99-result-file');assert.equal(args[2],'--k99-session');
  fs.writeFileSync(args[1],JSON.stringify({sessionId:args[3],itemName:'명품 패딩',finalPrice:150000}));
  await new Promise(resolve=>setTimeout(resolve,900));
  assert.deepEqual(values,[{itemName:'명품 패딩',finalPrice:150000}]);assert.equal(fs.existsSync(args[1]),false);
});
