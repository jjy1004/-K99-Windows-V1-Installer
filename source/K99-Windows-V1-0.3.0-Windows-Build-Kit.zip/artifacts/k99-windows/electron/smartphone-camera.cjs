'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),{spawn}=require('node:child_process');
const LINKS=Object.freeze({iriun:'https://iriun.com/',driver:'https://developer.android.com/studio/run/oem-usb?hl=ko',
  guide:'https://developer.android.com/studio/run/device?hl=ko#setting-up'});
function createSmartphoneCamera({shell,env=process.env,platform=process.platform,stat=fs.stat,launch}){
  const run=launch||((file)=>new Promise((resolve,reject)=>{
    const child=spawn(file,[],{cwd:path.win32.dirname(file),detached:true,stdio:'ignore',windowsHide:false,shell:false});
    child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});
  }));
  return async action=>{
    if(typeof action!=='string'||!Object.hasOwn(LINKS,action))throw Error('허용되지 않은 카메라 연결 요청입니다.');
    if(action==='iriun'&&platform==='win32'){
      const roots=[env.ProgramW6432,env.ProgramFiles,env['ProgramFiles(x86)']].filter(Boolean);
      for(const root of [...new Set(roots)])for(const folder of ['Iriun Webcam','Iriun Webcam Driver','Iriun']){
        const file=path.win32.join(root,folder,'IriunWebcam.exe');
        try{if(!(await stat(file)).isFile())continue;}catch{continue;}
        try{await run(file);return {message:'Iriun PC 프로그램을 실행했습니다. 휴대폰에서도 Iriun을 열고 두 기기를 같은 매장 와이파이에 연결해 주세요.'};}
        catch{await shell.openExternal(LINKS.iriun);return {message:'설치된 Iriun 실행에 실패하여 공식 설치 페이지를 열었습니다. 설치 후 다시 시도해 주세요.'};}
      }
    }
    await shell.openExternal(LINKS[action]);
    return {message:action==='iriun'?'Iriun 공식 설치 페이지를 열었습니다. PC용 프로그램과 휴대폰 앱을 직접 설치해 주세요.':
      action==='driver'?'제조사별 공식 USB 드라이버 설치 안내를 열었습니다. 휴대폰 제조사에 맞는 드라이버를 직접 설치해 주세요.':
      '안드로이드 공식 설정 안내를 열었습니다. QR만으로 설정 화면이 자동으로 열리지는 않습니다.'};
  };
}
module.exports={createSmartphoneCamera,LINKS};
