'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),{spawn}=require('node:child_process');
const LINKS=Object.freeze({iriun:'https://iriun.com/',driver:'https://developer.android.com/studio/run/oem-usb?hl=ko',
  guide:'https://developer.android.com/studio/run/device?hl=ko#setting-up'});
function createSmartphoneCamera({shell,env=process.env,platform=process.platform,stat=fs.stat,launch}){
  const run=launch||((file)=>new Promise((resolve,reject)=>{
    const child=spawn(file,[],{cwd:path.win32.dirname(file),detached:true,stdio:'ignore',windowsHide:false,shell:false});
    child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});
  }));
  return async action=>{
    if(typeof action!=='string'||!Object.hasOwn(LINKS,action))throw Error('허용되지 않은 카메라 연결 요청입니다.');
    if(action==='iriun'&&platform==='win32'){
      const roots=[env.ProgramW6432,env.ProgramFiles,env['ProgramFiles(x86)']].filter(Boolean);
      for(const root of [...new Set(roots)])for(const folder of ['Iriun Webcam','Iriun Webcam Driver','Iriun']){
        const file=path.win32.join(root,folder,'IriunWebcam.exe');
        try{if(!(await stat(file)).isFile())continue;}catch{continue;}
        try{await run(file);return {message:'Iriun PC 프로그램을 실행했습니다. 휴대폰에서도 Iriun을 열고 두 기기를 같은 매장 와이파이에 연결해 주세요.'};}
        catch{await shell.openExternal(LINKS.iriun);return {message:'설치된 Iriun 실행에 실패하여 공식 설치 페이지를 열었습니다. 설치 후 다시 시도해 주세요.'};}
      }
    }
    await shell.openExternal(LINKS[action]);
    return {message:action==='iriun'?'Iriun 공식 설치 페이지를 열었습니다. PC용 프로그램과 휴대폰 앱을 직접 설치해 주세요.':
      action==='driver'?'제조사별 공식 USB 드라이버 설치 안내를 열었습니다. 휴대폰 제조사에 맞는 드라이버를 직접 설치해 주세요.':
      '안드로이드 공식 설정 안내를 열었습니다. QR만으로 설정 화면이 자동으로 열리지는 않습니다.'};
  };
}
module.exports={createSmartphoneCamera,LINKS};

// Optional desktop receiver only: never blocks app startup, installs software,
// terminates another application, or changes the phone's power policy.
function createIriunLifecycle({env=process.env,platform=process.platform,stat=fs.stat,
  execute=(file,args,options)=>new Promise((resolve,reject)=>{
    require('node:child_process').execFile(file,args,{windowsHide:true,timeout:2500,maxBuffer:65536,...options},
      (error,stdout)=>error?reject(error):resolve(stdout));
  }),
  launch=file=>new Promise((resolve,reject)=>{
    const child=spawn(file,[],{cwd:path.win32.dirname(file),windowsHide:true,detached:true,stdio:'ignore',shell:false});
    child.once('error',reject);child.once('spawn',()=>{child.unref();resolve(child.pid);});
  }),
}={}){
  let starting=null,epoch=0;
  async function findFile(files){for(const file of files)try{if((await stat(file)).isFile())return file;}catch{}return null;}
  async function receiver(){
    if(platform!=='win32')return {installed:false,running:false};
    const roots=[env['ProgramFiles(x86)'],env.ProgramW6432,env.ProgramFiles,'C:\\Program Files (x86)','C:\\Program Files'].filter(Boolean);
    const file=await findFile([...new Set(roots)].map(root=>path.win32.join(root,'Iriun Webcam','IriunWebcam.exe')));
    if(!file)return {installed:false,running:false};
    // If process detection is blocked, do not risk starting duplicate receivers.
    let list;
    try{list=await execute('tasklist.exe',['/FI','IMAGENAME eq IriunWebcam.exe','/FO','CSV','/NH']);}
    catch{return {installed:true,running:false,warning:'Iriun 실행 상태를 확인하지 못했습니다. PC 수신기를 직접 켜 주세요.'};}
    if(/^"IriunWebcam\.exe","\d+"/im.test(list))return {installed:true,running:true};
    const pid=await launch(file);
    if(!Number.isSafeInteger(pid)||pid<=0)return {installed:true,running:true,backgroundVerified:false};
    // windowsHide hides console windows, not every GUI window. Request native
    // minimization for this exact newly started PID; never minimize other apps.
    const script=`Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class K99IriunWindow{[DllImport("user32.dll")]public static extern bool ShowWindowAsync(IntPtr h,int n);[DllImport("user32.dll")]public static extern bool IsIconic(IntPtr h);}';for($i=0;$i -lt 20;$i++){try{$p=Get-Process -Id ${pid} -ErrorAction Stop;if($p.MainWindowHandle -ne 0){[void][K99IriunWindow]::ShowWindowAsync($p.MainWindowHandle,6);Start-Sleep -Milliseconds 100;if([K99IriunWindow]::IsIconic($p.MainWindowHandle)){Write-Output 'minimized'};break}}catch{break};Start-Sleep -Milliseconds 100}`;
    let backgroundVerified=false;
    try{backgroundVerified=(await execute('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{timeout:3500})).includes('minimized');}catch{}
    return {installed:true,running:true,backgroundVerified,...(!backgroundVerified?
      {warning:'Iriun 수신기는 실행했지만 최소화 상태를 확인하지 못했습니다. 필요하면 작업표시줄에서 최소화하세요.'}:{})};
  }
  function ensureReceiver(){
    if(!starting)starting=receiver().catch(()=>({installed:false,running:false,warning:'Iriun PC 수신기를 직접 확인해 주세요.'})).finally(()=>{starting=null;});
    return starting;
  }
  async function wake(ticket){
    const adb=await findFile([
      env.LOCALAPPDATA&&path.win32.join(env.LOCALAPPDATA,'Android','Sdk','platform-tools','adb.exe'),
      'C:\\platform-tools\\adb.exe',
      ...(env.PATH||env.Path||'').split(';').filter(Boolean).map(p=>path.win32.join(p,'adb.exe')),
    ].filter(Boolean));
    if(!adb||ticket!==epoch)return false;
    try{
      const rows=(await execute(adb,['devices'])).split(/\r?\n/).map(x=>/^([A-Za-z0-9._-]+)\s+device$/.exec(x.trim()))
        .filter(row=>row&&!/^emulator-|_adb.*_tcp/i.test(row[1]));
      // Never select an arbitrary device when several shop phones are attached.
      if(rows.length!==1||ticket!==epoch)return false;
      const args=['-s',rows[0][1],'shell'];
      const packages=await execute(adb,[...args,'pm','list','packages','com.jacksoftw.webcam']);
      if(!/^package:com\.jacksoftw\.webcam$/m.test(packages.trim())||ticket!==epoch)return false;
      await execute(adb,[...args,'input','keyevent','KEYCODE_WAKEUP']);
      if(ticket!==epoch)return false;
      await execute(adb,[...args,'monkey','-p','com.jacksoftw.webcam','-c','android.intent.category.LAUNCHER','1']);
      return ticket===epoch;
    }catch{return false;}
  }
  async function session(input){
    if(!input||typeof input.active!=='boolean'||!['wifi','usb'].includes(input.mode))throw Error('잘못된 촬영 연결 요청입니다.');
    const ticket=++epoch;
    if(!input.active)return {released:true};
    const state=await ensureReceiver();
    if(ticket!==epoch)return {...state,cancelled:true};
    return {...state,phoneWakeRequested:input.mode==='usb'?await wake(ticket):false};
  }
  return {ensureReceiver,session};
}
module.exports.createIriunLifecycle=createIriunLifecycle;
