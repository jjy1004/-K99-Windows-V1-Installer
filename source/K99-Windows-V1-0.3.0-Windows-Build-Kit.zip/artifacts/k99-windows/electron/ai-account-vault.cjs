'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const AI_ORIGIN='https://k-99-washcare-ai.replit.app';
function createAiAccountVault({userData,safeStorage,platform=process.platform}){
  const folder=path.join(userData,'integrations'),file=path.join(folder,'ai-account.dpapi.json');
  const available=()=>platform==='win32'&&safeStorage?.isEncryptionAvailable?.()===true;
  function read(){
    if(!available())throw Error('이 Windows 계정의 암호화 저장소를 사용할 수 없습니다.');
    if(!fs.existsSync(file))return {account:null,cookies:[]};
    try{
      if(fs.statSync(file).size>524288)throw Error();
      const envelope=JSON.parse(fs.readFileSync(file,'utf8'));
      if(envelope.version!==1||typeof envelope.encrypted!=='string')throw Error();
      const value=JSON.parse(safeStorage.decryptString(Buffer.from(envelope.encrypted,'base64')));
      if(!Array.isArray(value.cookies)||!(value.account===null||(value.account&&
        typeof value.account.phone==='string'&&typeof value.account.password==='string')))throw Error();
      return value;
    }catch{throw Error('AI 연결 계정 암호화 파일을 읽지 못했습니다. 같은 Windows 사용자로 실행했는지 확인하세요. 원본은 보존했습니다.');}
  }
  function write(value){
    if(!available())throw Error('Windows 암호화 저장소가 없어 비밀번호를 저장하지 않았습니다.');
    fs.mkdirSync(folder,{recursive:true,mode:0o700});
    const temporary=path.join(folder,crypto.randomUUID()+'.tmp');
    try{
      const text=JSON.stringify(value);
      if(Buffer.byteLength(text)>250000)throw Error('AI 인증 저장소의 허용 크기를 초과했습니다.');
      const encrypted=safeStorage.encryptString(text).toString('base64');
      const fd=fs.openSync(temporary,'wx',0o600);
      try{fs.writeFileSync(fd,JSON.stringify({version:1,encrypted}));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
      fs.renameSync(temporary,file);
    }finally{fs.rmSync(temporary,{force:true});}
  }
  function status(){
    if(!available())return {available:false,configured:false,phone:'',error:'계정 저장은 Windows 설치형 앱에서만 사용할 수 있습니다.'};
    try{const value=read();return {available:true,configured:!!value.account,phone:value.account?.phone||''};}
    catch(error){return {available:true,configured:false,phone:'',error:error.message};}
  }
  function save(input){
    if(!input||typeof input.phone!=='string'||typeof input.password!=='string')throw Error('계정 입력 형식을 확인하세요.');
    const phone=input.phone.replace(/[\s()-]/g,''),password=input.password;
    if(!/^01\d{8,9}$/.test(phone))throw Error('휴대폰 번호 10~11자리를 입력하세요.');
    const value=read();
    if(!password){
      if(!value.account||value.account.phone!==phone)throw Error('새 계정의 비밀번호를 입력하세요.');
    }else{
      // Matches the published member-login API: exactly one letter and four digits.
      if(!/^(?=[A-Za-z0-9]{5}$)(?=[0-9]*[A-Za-z][0-9]*$).*$/.test(password))
        throw Error('AI 처방 비밀번호는 영문 1자와 숫자 4자의 총 5자리입니다.');
      value.account={phone,password};
    }
    write(value);return status();
  }
  function clear(){const value=read();value.account=null;write(value);return status();}
  function cookiesForOrigin(cookies){
    const host=new URL(AI_ORIGIN).hostname;
    return cookies.filter(c=>c&&typeof c.name==='string'&&c.name.length<=256&&typeof c.value==='string'&&c.value.length<=16384&&
      typeof c.domain==='string'&&c.domain.replace(/^\./,'')===host&&
      (!c.expirationDate||c.expirationDate>Date.now()/1000)).slice(0,100);
  }
  return {status,save,clear,
    account:()=>read().account,
    cookies:()=>cookiesForOrigin(read().cookies),
    saveCookies:cookies=>{const value=read();value.cookies=cookiesForOrigin(cookies);write(value);},
  };
}
module.exports={AI_ORIGIN,createAiAccountVault};
