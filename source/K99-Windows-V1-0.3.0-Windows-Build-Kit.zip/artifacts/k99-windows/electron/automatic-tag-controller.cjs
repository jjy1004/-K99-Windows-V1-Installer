'use strict';
const KEY='k99-automatic-tags-v1',ACTIVE='k99-active-staff-intake-v1';
function createAutomaticTags({store,equipmentApi,labels,changed=()=>{}}){
  function registry(){return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}
  function write(update){
    const expected=store.storage({op:'get',key:KEY}),next=JSON.parse(expected||'{}');
    update(next);store.storage({op:'set',key:KEY,expected,value:JSON.stringify(next)});
    try{changed();}catch{}
  }
  const key=(orderId,unitKey)=>`${orderId}:${unitKey}`;
  function currentUnit(orderId,unitKey){return store.equipment.drafts.state(orderId).units.find(u=>u.unitKey===unitKey);}
  function isActiveUnit(orderId,unit){
    const active=JSON.parse(store.storage({op:'get',key:ACTIVE})||'null');
    const row=active?.data?.rows?.find(r=>r.id===unit.rowId);
    return active?.draftId===orderId&&row?.itemId===unit.itemId&&unit.unitIndex<=row.quantity;
  }
  function state(orderId,unitKey){
    const stored=registry()[key(orderId,unitKey)],job=currentUnit(orderId,unitKey)?.job;
    const status=job?.status||stored?.status||'pending';
    return {isTagPrinted:['submitted','printed','simulated'].includes(status),status,
      materialTag:stored?.materialTag,jobId:job?.id||stored?.jobId,error:job?.error||stored?.error||''};
  }
  async function flush(orderId,unitKey,materialTag,trigger,dispatch=equipmentApi.dispatchDraftTag){
    const unit=currentUnit(orderId,unitKey);
    if(!unit||!isActiveUnit(orderId,unit))return state(orderId,unitKey);
    const job=unit.job;
    if(!job)return state(orderId,unitKey);
    // submitted/unknown/failed/submitting are never blindly resubmitted.
    if(job.status!=='pending'){
      write(r=>{r[key(orderId,unitKey)]={...r[key(orderId,unitKey)],jobId:job.id,status:job.status,
        isTagPrinted:['submitted','printed','simulated'].includes(job.status),error:job.error||''};});
      return state(orderId,unitKey);
    }
    // The serial equipment dispatcher claims this existing job at most once.
    const prior=registry()[key(orderId,unitKey)];
    const material=prior?.jobId===job.id&&prior.materialTag!==undefined?prior.materialTag:materialTag;
    write(r=>{r[key(orderId,unitKey)]={jobId:job.id,materialTag:material,trigger,status:'pending',
      isTagPrinted:false,requestedAt:new Date().toISOString()};});
    const printed=await dispatch({orderId,unitKey,materialTag:material});
    write(r=>{r[key(orderId,unitKey)]={...r[key(orderId,unitKey)],status:printed?.status||'unknown',
      isTagPrinted:['submitted','printed','simulated'].includes(printed?.status),error:printed?.error||''};});
    return state(orderId,unitKey);
  }
  function fallback(orderId,unitKey){
    const result=labels.latestForUnit(orderId,unitKey);
    return result?result.status==='success'?result.materialTag:'일반':'불명확';
  }
  async function beforeCapture(input,dispatch){
    if(input.mobileFileName)return; // A phone detail shot must not advance the PC garment sequence.
    const previous=registry().active;
    if(previous&&(previous.orderId!==input.orderId||previous.unitKey!==input.unitKey)&&
      !labels.hasPendingFor(previous.orderId,previous.unitKey))
      await flush(previous.orderId,previous.unitKey,fallback(previous.orderId,previous.unitKey),'next-garment',dispatch);
  }
  function afterCapture(input,unit){
    if(!unit)return;
    write(r=>{
      if(!input.mobileFileName||!r.active)r.active={orderId:input.orderId,unitKey:input.unitKey};
    });
  }
  async function onAnalysis(result){
    return flush(result.orderId,result.unitKey,result.status==='success'?result.materialTag:'일반','label-analysis');
  }
  async function finalize(orderId){
    if(typeof orderId!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(orderId))throw Error('접수 식별자 오류');
    await labels.settleForOrder(orderId);
    const results=[];
    for(const unit of store.equipment.drafts.state(orderId).units)
      if(isActiveUnit(orderId,unit))results.push(await flush(orderId,unit.unitKey,fallback(orderId,unit.unitKey),'intake-finalize'));
    return {units:enrichDraft(labels.enrichDraft(store.equipment.drafts.state(orderId))).units,
      warnings:results.filter(r=>!r.isTagPrinted).map(r=>r.error||`태그 출력 ${r.status} · 실물 확인 필요`)};
  }
  function enrichDraft(value){
    if(!Array.isArray(value?.units))return value;
    return {...value,units:value.units.map(u=>{
      const s=state(u.garment.orderId,u.unitKey);
      return {...u,garment:{...u.garment,isTagPrinted:s.isTagPrinted,autoTagStatus:s.status,
        ...(s.materialTag!==undefined?{materialTag:s.materialTag}:{})}};
    })};
  }
  function assertReadyForOrders(input){
    if(input.op!=='set'||input.key!=='k99-confirmed-orders-v1')return;
    const orders=JSON.parse(input.value);
    for(const order of orders)for(const unit of store.equipment.drafts.state(order.id).units){
      if(!order.garments?.some(g=>g.garmentId===unit.garment.garmentId))continue;
      if(['pending','submitting'].includes(unit.job?.status))
        throw Error('태그 자동 발행 준비가 끝나지 않았습니다. 접수 확정 버튼으로 다시 진행해 주세요.');
    }
  }
  return {beforeCapture,afterCapture,onAnalysis,finalize,state,enrichDraft,assertReadyForOrders};
}
module.exports={createAutomaticTags,KEY};
