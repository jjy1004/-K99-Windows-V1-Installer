'use strict';
const KEY='k99-automatic-tags-v1',ACTIVE='k99-active-staff-intake-v1';
function createAutomaticTags({store,equipmentApi,labels,changed=()=>{},offline=false}){
  function registry(){return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}
  function write(update){
    const expected=store.storage({op:'get',key:KEY}),next=JSON.parse(expected||'{}');
    update(next);store.storage({op:'set',key:KEY,expected,value:JSON.stringify(next)});
    try{changed();}catch{}
  }
  const key=(orderId,unitKey)=>`${orderId}:${unitKey}`;
  function currentUnit(orderId,unitKey){return store.equipment.drafts.state(orderId).units.find(u=>u.unitKey===unitKey);}
  function isActiveUnit(orderId,unit){
    const active=JSON.parse(store.storage({op:'get',key:ACTIVE})||'null');
    const row=active?.data?.rows?.find(r=>r.id===unit.rowId);
    return active?.draftId===orderId&&row?.itemId===unit.itemId&&unit.unitIndex<=row.quantity;
  }
  function state(orderId,unitKey){
    const unit=currentUnit(orderId,unitKey);
    if(unit?.garment.tagMode==='roll')return {isTagPrinted:false,status:'assigned',labelAnalysis:{},error:''};
    const stored=registry()[key(orderId,unitKey)],job=unit?.job;
    const status=job?.status||stored?.status||'pending';
    return {isTagPrinted:['submitted','printed','simulated'].includes(status),status,
      materialTag:stored?.materialTag,labelAnalysis:stored?.labelAnalysis||{},jobId:job?.id||stored?.jobId,error:job?.error||stored?.error||''};
  }
  async function flush(orderId,unitKey,materialTag,trigger,dispatch=equipmentApi.dispatchDraftTag){
    const unit=currentUnit(orderId,unitKey);
    if(!unit||!isActiveUnit(orderId,unit))return state(orderId,unitKey);
    const job=unit.job;
    if(!job)return state(orderId,unitKey);
    // submitted/unknown/failed/submitting are never blindly resubmitted.
    if(job.status!=='pending'){
      write(r=>{r[key(orderId,unitKey)]={...r[key(orderId,unitKey)],jobId:job.id,status:job.status,
        isTagPrinted:['submitted','printed','simulated'].includes(job.status),error:job.error||''};});
      return state(orderId,unitKey);
    }
    // The serial equipment dispatcher claims this existing job at most once.
    const prior=registry()[key(orderId,unitKey)];
    const material=prior?.jobId===job.id&&prior.materialTag!==undefined?prior.materialTag:materialTag;
    const latest=labels.latestForUnit(orderId,unitKey);
    let labelAnalysis=prior?.jobId===job.id&&prior.labelAnalysis?prior.labelAnalysis
      :latest?.status==='success'&&latest.materialTag===material
        ?{material_group:latest.material_group,wash_method:latest.wash_method,color:latest.color}:{};
    if(offline)labelAnalysis={...labelAnalysis,manualMaterial:unit.garment.manualMaterial||'폴리에스테르',
      manualColor:unit.garment.manualColor||'유색'};
    write(r=>{r[key(orderId,unitKey)]={jobId:job.id,materialTag:material,labelAnalysis,trigger,status:'pending',
      isTagPrinted:false,requestedAt:new Date().toISOString()};});
    const printed=await dispatch({orderId,unitKey,materialTag:material,labelAnalysis});
    write(r=>{r[key(orderId,unitKey)]={...r[key(orderId,unitKey)],
      ...(offline?{labelAnalysis:{...labelAnalysis,manualMaterial:printed?.payload?.manualMaterial||labelAnalysis.manualMaterial,
        manualColor:printed?.payload?.manualColor||labelAnalysis.manualColor}}:{}),status:printed?.status||'unknown',
      isTagPrinted:['submitted','printed','simulated'].includes(printed?.status),error:printed?.error||''};});
    return state(orderId,unitKey);
  }
  function fallback(orderId,unitKey){
    const result=labels.latestForUnit(orderId,unitKey);
    return result?result.status==='success'?result.materialTag:'일반':'불명확';
  }
  async function beforeCapture(input,dispatch){
    if(offline)return;
    if(input.mobileFileName)return; // A phone detail shot must not advance the PC garment sequence.
    const previous=registry().active;
    if(previous&&(previous.orderId!==input.orderId||previous.unitKey!==input.unitKey)&&
      !labels.hasPendingFor(previous.orderId,previous.unitKey))
      await flush(previous.orderId,previous.unitKey,fallback(previous.orderId,previous.unitKey),'next-garment',dispatch);
  }
  function afterCapture(input,unit){
    if(!unit)return;
    write(r=>{
      if(!input.mobileFileName||!r.active)r.active={orderId:input.orderId,unitKey:input.unitKey};
    });
  }
  async function onAnalysis(result){
    if(offline)return state(result.orderId,result.unitKey);
    return flush(result.orderId,result.unitKey,result.status==='success'?result.materialTag:'일반','label-analysis');
  }
  async function finalize(orderId){
    if(typeof orderId!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(orderId))throw Error('접수 식별자 오류');
    if(!offline)await labels.settleForOrder(orderId);
    const results=[];
    for(const unit of store.equipment.drafts.state(orderId).units)
      if(isActiveUnit(orderId,unit))results.push(await flush(orderId,unit.unitKey,fallback(orderId,unit.unitKey),'intake-finalize'));
    return {units:enrichDraft(labels.enrichDraft(store.equipment.drafts.state(orderId))).units,
      warnings:results.filter(r=>r.status!=='assigned'&&!r.isTagPrinted).map(r=>r.error||`태그 출력 ${r.status} · 실물 확인 필요`)};
  }
  function enrichDraft(value){
    if(!Array.isArray(value?.units))return value;
    return {...value,units:value.units.map(u=>{
      const s=u.garment.tagMode==='roll'?{isTagPrinted:false,status:'assigned',labelAnalysis:{},materialTag:undefined}:state(u.garment.orderId,u.unitKey);
      return {...u,garment:{...u.garment,...s.labelAnalysis,
        ...(offline?{manualMaterial:u.garment.manualMaterial||'폴리에스테르',manualColor:u.garment.manualColor||'유색'}:{}),
        isTagPrinted:s.isTagPrinted,autoTagStatus:s.status,
        ...(s.materialTag!==undefined?{materialTag:s.materialTag}:{})}};
    })};
  }
  function assertReadyForOrders(input){
    if(input.op!=='set'||input.key!=='k99-confirmed-orders-v1')return;
    const orders=JSON.parse(input.value);
    for(const order of orders)for(const unit of store.equipment.drafts.state(order.id).units){
      if(!order.garments?.some(g=>g.garmentId===unit.garment.garmentId))continue;
      if(['pending','submitting'].includes(unit.job?.status))
        throw Error('태그 자동 발행 준비가 끝나지 않았습니다. 접수 확정 버튼으로 다시 진행해 주세요.');
    }
  }
  return {beforeCapture,afterCapture,onAnalysis,finalize,state,enrichDraft,assertReadyForOrders};
}
module.exports={createAutomaticTags,KEY};
