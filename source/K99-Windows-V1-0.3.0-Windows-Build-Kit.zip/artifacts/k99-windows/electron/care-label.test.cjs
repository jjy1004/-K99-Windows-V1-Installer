'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createMobilePhotoController}=require('./mobile-photo-controller.cjs');
const {createCareLabelController,KEY}=require('./care-label-controller.cjs');
const {formatMaterialSummary,determineBasket,materialCategory,analyzeCareLabel}=require('../../../lib/k99-local/carelabel-analysis.cjs');
const {classifyCareLabel}=require('./services/labelService.cjs');
const JPEG=Buffer.concat([Buffer.from([255,216,255]),Buffer.alloc(100,42),Buffer.from([255,217])]);
const result={status:'success',materialTag:'PT20 면40 N40',raw_composition:'폴리에스터 20% 면 40% 나일론 40%',
  color_type:'유색',wash_type:'물세탁',material_category:'나일론',
  basket:{no:'바구니 4',name:'유색 · 나일론 바구니',color:'#DD6B20'}};

test('care label summaries and six basket routes follow explicit rules without guessing',()=>{
  assert.equal(formatMaterialSummary('폴리에스터 20% 면 40% 나일론 40%'),'PT20 면40 N40');
  assert.equal(formatMaterialSummary('95% COTTON, 5% ELASTANE'),'면95 PU5');
  assert.equal(formatMaterialSummary('양모 80% 캐시미어 10% 실크 10%'),'W80 W10 S10');
  assert.equal(formatMaterialSummary('레이온 60%, 린넨 40%'),'레이60 린40');
  assert.equal(formatMaterialSummary('스판 300% 알수없음 40%'),'');
  assert.equal(materialCategory('폴리에스테르 90% 면 10%'),'폴리에스테르 90% 이상');
  assert.equal(materialCategory('면 60% 나일론 40%'),'나일론');
  assert.equal(materialCategory('폴리에스터 95% 울 5%'),'울 / 실크');
  assert.equal(materialCategory('면 30%'),null);
  assert.equal(determineBasket('드라이세탁',null,null).no,'DRY');
  assert.equal(determineBasket('물세탁','흰색','울 / 실크').no,'바구니 1');
  for(const [i,c] of ['폴리에스테르 90% 이상','식물성 섬유 및 혼방','나일론','울 / 실크'].entries())
    assert.equal(determineBasket('물세탁','유색',c).no,`바구니 ${i+2}`);
  assert.equal(determineBasket('물세탁',null,'나일론'),null);
  assert.equal(determineBasket('금지','흰색','나일론'),null);
});

test('server Gemini contract carries MIME and bytes; missing color does not discard valid material/wash analysis',async()=>{
  let request;
  const response={...result,material_group:'나일론',wash_method:'물세탁',color:'검정',
    water_allowed:true,dry_allowed:true,ambiguous:false};
  const fetchImpl=async(url,input)=>{request={url,...input,body:JSON.parse(input.body)};
    return {ok:true,json:async()=>({candidates:[{content:{parts:[{text:JSON.stringify(response)}]}}]})};};
  const analyze=()=>analyzeCareLabel({dataBase64:JPEG.toString('base64'),mimeType:'image/jpeg'},{apiKey:'test-only',fetchImpl});
  const actual=await analyze();
  assert.equal(actual.status,'success');assert.equal(actual.materialTag,result.materialTag);
  assert.match(request.url,/gemini-3\.1-flash-lite:generateContent$/);
  assert.equal(request.body.generationConfig.thinkingConfig.thinkingBudget,undefined);
  assert.equal(request.body.generationConfig.thinkingConfig.thinkingLevel,'LOW');
  assert.equal(request.body.generationConfig.temperature,undefined);
  assert.deepEqual(Buffer.from(request.body.contents[0].parts[0].inlineData.data,'base64'),JPEG);
  assert.equal(request.body.contents[0].parts[0].inlineData.mimeType,'image/jpeg');
  assert.equal(request.body.generationConfig.responseMimeType,'application/json');
  response.color_type=null;
  response.color='확인 필요';
  const uncertain=await analyze();
  assert.equal(uncertain.status,'success');assert.equal(uncertain.materialTag,result.materialTag);assert.equal(uncertain.basket,null);
  response.color_type='유색';response.ambiguous=true;
  assert.equal((await analyze()).status,'review');
  response.ambiguous=false;response.material_group='울/실크';
  assert.equal((await analyze()).status,'review');
  await assert.rejects(()=>analyzeCareLabel({dataBase64:JPEG.toString('base64'),mimeType:'image/jpeg'},{
    apiKey:'test-only',fetchImpl:async()=>({ok:true,json:async()=>({})})}),/JSON/);
  await assert.rejects(()=>classifyCareLabel(Buffer.from('x')),/크기/);
});

function fixture(t,classify){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-care-label-')),db=path.join(root,'k99.db');
  const store=createStore(db,'test-only',{nativeDesktop:true}),jobs=[];
  store.equipment.configure({mode:'real',printerName:'TSC TE210',labelWidthMm:60,labelHeightMm:40,
    labelVerified:true,cameraDeviceId:'test-camera',hardwareConfirmed:true},true);
  const archive=createPhotoArchive({getRoot:()=>path.join(root,'test-D'),openPath:async()=>'',encodeJpeg:()=>JPEG});
  const adapters={native:true,archivePhoto:archive.photo,print:async job=>jobs.push(job)};
  const equipmentApi=createEquipmentApi(store,adapters);
  const labels=createCareLabelController({store,equipmentApi,classify,native:true});
  adapters.print=async job=>jobs.push({...job,payload:{...job.payload,materialTag:labels.materialForJob(job)}});
  const bridge=createMobilePhotoController({store,equipmentApi,archivePhoto:archive.photo,native:true,
    onMobileSaved:(input,saved)=>labels.onMobileSaved(input,saved),
    nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:1,height:1})})},
    host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1']});
  adapters.archivePhoto=bridge.archivePhoto;
  const target={orderId:'care-label-draft-1',unitKey:'1:1',itemId:'shirt',itemName:'셔츠',customerName:'단위검증',customerPhone:'01000001234'};
  const active='k99-active-staff-intake-v1';
  store.storage({op:'set',key:active,expected:null,value:JSON.stringify({version:1,draftId:target.orderId,
    revision:0,data:{customerName:target.customerName,customerPhone:target.customerPhone,rows:[{id:1,itemId:'shirt',quantity:1}]}})});
  t.after(()=>{labels.close();bridge.close();store.close();fs.rmSync(root,{recursive:true,force:true});});
  async function upload(){
    const s=await bridge.api('POST','/api/mobile-photo/start',target),u=new URL(s.urls[0]);
    const response=await fetch(`${u.origin}/api/upload-mobile-photo`,{method:'POST',headers:{
      'Content-Type':'image/jpeg','X-K99-Session-Token':u.searchParams.get('token'),'X-K99-Upload-Id':'care-mobile-photo-1'},body:JPEG});
    assert.equal(response.status,200);
    await bridge.api('POST','/api/mobile-photo/stop',{id:s.id});
    const draft=store.equipment.drafts.state(target.orderId);
    const photo=draft.units[0].garment.photoHistory.find(p=>p.archiveFile.startsWith('MOBILE_'));
    return {photoId:photo.sourcePhotoId,garment:draft.units[0].garment};
  }
  function confirm(garment){
    const order={id:target.orderId,customerName:target.customerName,customerPhone:target.customerPhone,customerAddress:'',
      createdAt:new Date().toISOString(),items:[{displayNameKo:'셔츠',quantity:1}],estimatedTotal:3000,laundryTotal:3000,
      garments:[{...garment,sequence:1,itemIndex:1,unitIndex:1,totalSequence:1}]};
    store.storage({op:'set',key:'k99-confirmed-orders-v1',expected:store.storage({op:'get',key:'k99-confirmed-orders-v1'}),value:JSON.stringify([order])});
  }
  return {store,root,db,jobs,labels,equipmentApi,target,upload,confirm};
}

test('mobile commit and original first tag do not wait for AI; results persist and explicit confirmed reprint uses material',async t=>{
  let finish;
  const f=fixture(t,()=>new Promise(resolve=>{finish=resolve;}));
  await f.equipmentApi.api('POST','/api/equipment/command',{...f.target,action:'capture-draft',requestId:'initial-pc-photo1',
    expectedMode:'real',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`});
  assert.equal(f.jobs.length,1);assert.equal(f.jobs[0].payload.materialTag,'');
  const mobile=await f.upload();
  assert.equal(f.jobs.length,1);
  assert.equal(f.labels.list()[0].status,'pending');
  assert.equal(f.store.equipment.drafts.state(f.target.orderId).units[0].garment.photoHistory.length,2);
  const work=f.labels.analyze(mobile.photoId);
  assert.throws(()=>f.labels.analyze('../../private-file'),/식별자/);
  await assert.rejects(()=>f.labels.print(mobile.photoId,'request-before-1'),/분석/);
  finish(result);
  await work;
  const enriched=f.labels.enrichDraft(f.store.equipment.drafts.state(f.target.orderId));
  assert.equal(enriched.units[0].garment.materialTag,'PT20 면40 N40');
  assert.equal(f.jobs.length,1,'AI completion never causes an automatic duplicate tag');
  await assert.rejects(()=>f.labels.print(mobile.photoId,'request-before-2'),/접수를 먼저/);
  f.confirm(enriched.units[0].garment);
  assert.equal(f.labels.list()[0].canPrint,true);
  const printed=await f.labels.print(mobile.photoId,'material-print-1');
  assert.equal(printed.job.status,'submitted');assert.equal(f.jobs.length,2);
  assert.equal(f.jobs[1].payload.materialTag,'PT20 면40 N40');
  await f.labels.print(mobile.photoId,'material-print-1');
  assert.equal(f.jobs.length,2,'same print request id is deduplicated by existing core');
  assert.equal(f.store.status().orderCount,1);
  assert.equal(f.store.equipment.state().photos.length,2);
  const persisted=JSON.parse(f.store.storage({op:'get',key:KEY}))[mobile.photoId];
  assert.equal(persisted.garmentId,mobile.garment.garmentId);
  const snapshot=path.join(f.root,'snapshot.sqlite');f.store.snapshot(snapshot);
  const reopened=createStore(snapshot,'test-only',{nativeDesktop:true});
  try{assert.equal(JSON.parse(reopened.storage({op:'get',key:KEY}))[mobile.photoId].materialTag,'PT20 면40 N40');}
  finally{reopened.close();}
});

test('missing/failed AI falls back to general without undoing photo, first tag or order; no fake basket',async t=>{
  const f=fixture(t,async()=>{throw Error('중앙 분석 서버 준비 중');});
  const mobile=await f.upload();
  const failed=await f.labels.analyze(mobile.photoId);
  assert.equal(failed.status,'failed');assert.equal(failed.materialTag,'');assert.equal(failed.basket,null);
  assert.match(failed.error,/중앙 분석 서버/);
  assert.equal(f.jobs.length,1);
  f.confirm(mobile.garment);
  const printed=await f.labels.print(mobile.photoId,'fallback-print-1');
  assert.equal(printed.job.status,'submitted');assert.equal(f.jobs[1].payload.materialTag,'');
  assert.equal(f.store.equipment.state().photos.length,1);
});

test('native HTML adds one escaped footer and preserves Code128/label size/customer/item layout',async()=>{
  const source=fs.readFileSync(path.join(__dirname,'equipment-native.cjs'),'utf8');
  let html,barcode,options;
  const sandbox={module:{exports:{}},require:id=>id==='bwip-js'?{toBuffer:async value=>{barcode=value;return Buffer.from('png');}}:
    id==='./customer-display.cjs'?{createCustomerDisplay:()=>({})}:require(id),
    process:{platform:'win32'},setTimeout,clearTimeout};
  vm.runInNewContext(source,sandbox);
  class Window{
    constructor(){this.webContents={print:(input,cb)=>{options=input;cb(true);}};}
    async loadURL(url){html=decodeURIComponent(url.split(',').slice(1).join(','));}
    isDestroyed(){return false;}destroy(){}
  }
  const adapters=sandbox.module.exports.createNativeAdapters({BrowserWindow:Window,session:{fromPartition:()=>({
    webRequest:{onBeforeRequest(){}},setPermissionRequestHandler(){}})},
    getMain:()=>({webContents:{getPrintersAsync:async()=>[{name:'TSC TE210'}]}})});
  const job={printerName:'TSC TE210',payload:{labelWidthMm:60,labelHeightMm:40,garmentId:'order-1',customerName:'검증',
    itemName:'셔츠',serviceType:'general',materialTag:'PT20 <script> & 면40'}};
  await adapters.print(job);
  assert.equal(barcode.bcid,'code128');assert.equal(barcode.text,'order-1');
  assert.equal(options.pageSize.width,60000);assert.equal(options.pageSize.height,40000);
  assert.equal((html.match(/\[소재\]/g)||[]).length,1);
  assert.ok(html.includes('PT20 &lt;script&gt; &amp; 면40'));
  assert.ok(html.includes('<h1>검증</h1>'));
  assert.ok(html.includes('셔츠 · 일반'));
  assert.equal(barcode.includetext,false);
  assert.doesNotMatch(html,/position:absolute/);
  job.payload.materialTag='';
  await adapters.print(job);assert.ok(html.includes('[소재] 일반 (확인 필요) / [색상] 확인 필요'));
});
