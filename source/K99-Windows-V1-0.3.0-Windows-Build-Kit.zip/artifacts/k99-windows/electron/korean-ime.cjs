'use strict';
const {spawn:defaultSpawn}=require('node:child_process');

// The worker accepts only numeric HWNDs and a boolean. No renderer text is ever
// evaluated as PowerShell. One warm process avoids compiling C# on every focus.
const IME_SCRIPT=String.raw`
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class K99Ime {
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L,T,R,B; }
 [StructLayout(LayoutKind.Sequential)] public struct GUI {
  public int cbSize,flags; public IntPtr active,focus,capture,menu,move,caret; public RECT rect;
 }
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h,uint f);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint t,ref GUI g);
 [DllImport("user32.dll")] static extern int GetKeyboardLayoutList(int n,[Out] IntPtr[] list);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr h,uint m,IntPtr w,IntPtr l,uint f,uint t,out IntPtr r);
 [DllImport("imm32.dll")] static extern IntPtr ImmGetDefaultIMEWnd(IntPtr h);
 public static string Apply(long value,bool korean) {
  IntPtr root=new IntPtr(value), front=GetForegroundWindow();
  if(root==IntPtr.Zero || front==IntPtr.Zero || GetAncestor(front,2)!=root) return "not-foreground";
  var info=new GUI(); info.cbSize=Marshal.SizeOf(typeof(GUI));
  uint thread=GetWindowThreadProcessId(root,IntPtr.Zero);
  IntPtr target=GetGUIThreadInfo(thread,ref info)&&info.focus!=IntPtr.Zero ? info.focus : root;
  IntPtr result;
  if(korean) {
   var layouts=new IntPtr[GetKeyboardLayoutList(0,null)]; GetKeyboardLayoutList(layouts.Length,layouts);
   IntPtr ko=IntPtr.Zero;
   foreach(var layout in layouts) if((layout.ToInt64()&0xffff)==0x0412){ko=layout;break;}
   if(ko==IntPtr.Zero) return "korean-layout-unavailable";
   SendMessageTimeout(target,0x0050,IntPtr.Zero,ko,2,150,out result);
  }
  IntPtr ime=ImmGetDefaultIMEWnd(target);
  if(ime==IntPtr.Zero) return "ime-unavailable";
  IntPtr ok=SendMessageTimeout(ime,0x0283,new IntPtr(6),new IntPtr(korean?1:0),2,150,out result);
  if(ok==IntPtr.Zero) return "ime-timeout";
  ok=SendMessageTimeout(ime,0x0283,new IntPtr(2),new IntPtr(korean?1:0),2,150,out result);
  return ok==IntPtr.Zero ? "ime-timeout" : "requested";
 }
}
'@
[Console]::WriteLine('{"ready":true}')
while ($null -ne ($line = [Console]::ReadLine())) {
 try {
  $request = $line | ConvertFrom-Json
  $state = [K99Ime]::Apply([long]$request.hwnd,[bool]$request.korean)
  [Console]::WriteLine((@{id=$request.id;state=$state} | ConvertTo-Json -Compress))
 } catch { [Console]::WriteLine('{"state":"unavailable"}') }
}
`;

function nativeHandle(win){
  const bytes=win.getNativeWindowHandle();
  return bytes.length>=8?bytes.readBigUInt64LE().toString():String(bytes.readUInt32LE());
}
function createKoreanIme({platform=process.platform,spawn=defaultSpawn}={}){
  let child,disposed=false,sequence=0,output='',ready=false,startTimer;
  const pending=new Map(),queued=new Map();
  const finish=(id,state)=>{const item=pending.get(id);if(item){clearTimeout(item.timer);pending.delete(id);item.resolve({state});}};
  const stop=()=>{
    const old=child;child=null;ready=false;output='';clearTimeout(startTimer);
    for(const id of pending.keys())finish(id,'unavailable');
    queued.clear();old?.kill();
  };
  const send=item=>{try{child.stdin.write(JSON.stringify(item)+'\n');}catch{stop();}};
  const start=()=>{
    if(child||disposed)return;
    try{
      child=spawn('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
        '-EncodedCommand',Buffer.from(IME_SCRIPT,'utf16le').toString('base64')],
      {windowsHide:true,stdio:['pipe','pipe','pipe']});
      const current=child;
      startTimer=setTimeout(stop,12000);startTimer.unref?.();
      child.stdout.on('data',chunk=>{
        if(child!==current)return;
        output+=chunk.toString();if(output.length>32768){stop();return;}
        let end;while((end=output.indexOf('\n'))>=0){
          const line=output.slice(0,end);output=output.slice(end+1);
          try{
            const reply=JSON.parse(line);
            if(reply.ready){ready=true;clearTimeout(startTimer);for(const item of queued.values())send(item);queued.clear();}
            else if(Number.isInteger(reply.id))finish(reply.id,reply.state);
          }catch{/* Non-JSON PowerShell startup output is not an input command. */}
        }
      });
      child.stderr.on('data',()=>{});
      child.on('error',()=>{if(child===current)stop();});
      child.on('exit',()=>{if(child===current)stop();});
      child.stdin.on('error',()=>{if(child===current)stop();});
    }catch{stop();}
  };
  return {
    request(win,korean=true){
      if(disposed||platform!=='win32'||!win||win.isDestroyed()||!win.isFocused())return Promise.resolve({state:'inactive'});
      let hwnd;try{hwnd=nativeHandle(win);}catch{return Promise.resolve({state:'unavailable'});}
      // Coalesce focus storms; never queue unbounded native calls.
      for(const [id,item]of pending)if(item.hwnd===hwnd){finish(id,'superseded');queued.delete(id);}
      const id=++sequence;
      const promise=new Promise(resolve=>{
        const timer=setTimeout(()=>{queued.delete(id);finish(id,'timeout');},ready?1200:13000);timer.unref?.();
        pending.set(id,{resolve,timer,hwnd});
      });
      const item={id,hwnd,korean:korean===true};
      start();if(!child)finish(id,'unavailable');else if(ready)send(item);else queued.set(id,item);
      return promise;
    },
    dispose(){disposed=true;stop();},
  };
}
function installKoreanIme({app,BrowserWindow,ipcMain,trusted,engine=createKoreanIme()}){
  const modes=new WeakMap();
  const handler=(event,input)=>{
    trusted(event);
    const win=BrowserWindow.fromWebContents(event.sender);
    if(input!==undefined && (typeof input!=='object'||input===null||typeof input.korean!=='boolean'))
      return {state:'invalid'};
    const korean=input?.korean!==false;if(win)modes.set(win,korean);
    return engine.request(win,korean);
  };
  const focus=(_event,win)=>{void engine.request(win,modes.get(win)!==false);};
  ipcMain.handle('ime:force-korean',handler);
  app.on('browser-window-focus',focus);
  app.once('will-quit',()=>engine.dispose());
  return ()=>{app.removeListener('browser-window-focus',focus);ipcMain.removeHandler('ime:force-korean');engine.dispose();};
}
module.exports={IME_SCRIPT,nativeHandle,createKoreanIme,installKoreanIme};
