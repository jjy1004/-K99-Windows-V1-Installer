'use strict';
function applyStartupPreference(app,preference,executable){
  const enabled=preference?.enabled!==false;
  app.setLoginItemSettings({openAtLogin:enabled,path:executable,args:['--k99-autostart']});
  if(app.getLoginItemSettings().openAtLogin!==enabled)throw Error('Windows 자동 실행 설정을 확인하지 못했습니다.');
  return {enabled};
}
module.exports={applyStartupPreference};
