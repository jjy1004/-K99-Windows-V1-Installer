'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{createRequire}=require('node:module');
const runtime=createRequire(path.join(__dirname,'../package.json')),ts=runtime('typescript'),cache=new Map();
function load(name){
  const file=path.resolve(__dirname,'../src',name);
  const full=fs.existsSync(file)?file:fs.existsSync(file+'.ts')?file+'.ts':file+'.tsx';
  if(cache.has(full))return cache.get(full).exports;
  if(full.endsWith('.json'))return JSON.parse(fs.readFileSync(full,'utf8'));
  const mod={exports:{}};cache.set(full,mod);
  new Function('require','module','exports',ts.transpileModule(fs.readFileSync(full,'utf8'),{compilerOptions:{
    module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true,
  }}).outputText)(id=>id.startsWith('.')?load(path.relative(path.resolve(__dirname,'../src'),path.resolve(path.dirname(full),id))):runtime(id),mod,mod.exports);
  return mod.exports;
}
const {restoreHandover,latestHandedOrder}=load('handover-recovery.ts');
const {isReadyForHandover,confirmStaffHandover}=load('order-handover.ts');
function order(){
  const result={id:'undo-order',customerFolderName:'20261101_복구시험_1234',customerName:'복구시험',customerPhone:'01000001234',
    customerAddress:'과천시 한글주소',intakeAt:'2026-11-01T01:00:00.000Z',totalQuantity:1,laundryTotal:35000,estimatedTotal:35000,
    status:'전체 세탁 완료 / 반출 대기',payment_type:'POSTPAID',payment_status:'PAID',
    choices:{customerRequests:'기존 메모',deliveryRequested:false},
    items:[{itemId:'coat',displayNameKo:'하프코트',quantity:1,generalPrice:35000,premiumPrice:35000,isSneaker:false}],
    operations:{stage:'매장수령완료',updatedAt:'2026-11-02T01:00:00.000Z',completedAt:'2026-11-02T01:00:00.000Z',
      paymentStatus:'결제완료',paidAmount:35000,paidAt:'2026-11-02T00:00:00.000Z',notifications:[{id:'notice-keep'}]},
    garments:[{garmentId:'garment-keep',itemName:'하프코트',sequence:1,completionStatus:'complete',cleaningStatus:'complete',
      handoverStatus:'complete',processStatus:'반출 완료',barcodeValue:'barcode-keep',tagNumber:'2-101',
      photos:[{id:'photo-keep'}],completedAt:'2026-11-01T03:00:00.000Z',auditEvents:[]}],
    history:[{at:'2026-11-02T01:00:00.000Z',kind:'operations-update',details:{action:'handover-confirmed'}}]};
  const {garmentId,barcodeValue,...preserved}=result.garments[0];
  result.garments=[{...load('garment-record.ts').createGarmentRecords(result)[0],...preserved}];
  return result;
}
test('handover undo restores ready garments while retaining payment, photos, tags, completion proof and all history',()=>{
  const original=order(),before=JSON.stringify(original),updated=restoreHandover(original,'직원',new Date('2026-11-16T00:00:00Z'));
  assert.equal(JSON.stringify(original),before);assert.ok(isReadyForHandover(updated));
  assert.equal(updated.operations.completedAt,undefined);
  assert.equal(updated.payment_status,'PAID');assert.equal(updated.operations.paidAmount,35000);
  assert.deepEqual(updated.operations.notifications,original.operations.notifications);
  assert.deepEqual(updated.garments[0].photos,original.garments[0].photos);
  assert.equal(updated.garments[0].tagNumber,'2-101');assert.equal(updated.garments[0].completedAt,original.garments[0].completedAt);
  assert.equal(updated.history.at(-1).details.action,'handover-restored');
});
test('delivery departure restores delivery waiting without inventing a refund',()=>{
  const original=order();original.choices.deliveryRequested=true;original.operations.stage='배달중';delete original.operations.completedAt;
  const updated=restoreHandover(original);assert.equal(updated.operations.stage,'배달대기');
  assert.ok(isReadyForHandover(updated));assert.equal(updated.payment_status,'PAID');
});
test('cancelled, deleted, unfinished and already-restored orders cannot be restored',()=>{
  for(const mutate of [o=>o.operations.cancelledAt='2026-11-15',o=>o.orderDeletion={deletedAt:'2026-11-15'},
    o=>o.garments[0].completionStatus='pending',o=>o.garments[0].qcHoldReason='추가 확인']){
    const o=order();mutate(o);const before=JSON.stringify(o);assert.throws(()=>restoreHandover(o));assert.equal(JSON.stringify(o),before);
  }
  assert.throws(()=>restoreHandover(restoreHandover(order())));
});
test('latest undo selects the newest remaining departure, excluding deleted and waiting orders',()=>{
  const a=order(),b=order();b.id='newest';b.operations.completedAt='2026-11-15T00:00:00Z';
  assert.equal(latestHandedOrder([a,b]).id,b.id);
  b.orderDeletion={deletedAt:'2026-11-16'};assert.equal(latestHandedOrder([a,b]).id,a.id);
  assert.equal(latestHandedOrder([restoreHandover(a)]),undefined);
});
test('an older delivery schedule edit cannot replace the actual newest departure in Undo',()=>{
  const old=order(),recent=order();old.id='old';old.choices.deliveryRequested=true;
  old.operations.stage='배달중';delete old.operations.completedAt;old.operations.updatedAt='2026-11-16T00:00:00Z';
  recent.id='actual-newest';recent.operations.completedAt='2026-11-15T00:00:00Z';
  assert.equal(latestHandedOrder([old,recent]).id,recent.id);
});
test('re-departure starts a new final departure date rather than reusing the cancelled departure',()=>{
  const updated=confirmStaffHandover(restoreHandover(order()),{at:new Date('2026-11-16T06:00:00Z')});
  assert.equal(updated.operations.completedAt,'2026-11-16T06:00:00.000Z');
  assert.equal(updated.garments[0].handoverStatus,'complete');
});
test('SQLite commit survives reopen and rejects stale restore writes without changing payment or history',t=>{
  const {createStore}=require('../../../lib/k99-local/index.cjs');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-undo-')),filename=path.join(dir,'k99.db');
  let store=createStore(filename);
  t.after(()=>{store.close();fs.rmSync(dir,{recursive:true,force:true});});
  global.window={localStorage:{getItem:key=>store.storage({op:'get',key}),
    setItem:(key,value)=>store.storage({op:'set',key,value,expected:store.storage({op:'get',key})})}};
  const original=order(),key='k99-confirmed-orders-v1';
  window.localStorage.setItem(key,JSON.stringify([original]));
  const {updateSavedOrder,readConfirmedOrders}=load('order-record.ts');
  const updated=restoreHandover(original);updateSavedOrder(updated,original);
  assert.throws(()=>updateSavedOrder(original,original),/변경/);
  store.close();store=createStore(filename);
  const saved=readConfirmedOrders()[0];assert.ok(isReadyForHandover(saved));
  assert.equal(saved.payment_status,'PAID');assert.equal(saved.operations.completedAt,undefined);
  assert.equal(saved.history.at(-1).details.action,'handover-restored');
});
test('actual archive cleanup protects restored orders and counts sixty days from the new departure only',async t=>{
  const {createStore}=require('../../../lib/k99-local/index.cjs');
  const {createPhotoRetention}=require('../../../lib/k99-local/photo-retention.cjs');
  const Database=createRequire(path.resolve(__dirname,'../../../lib/k99-local/package.json'))('better-sqlite3');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-undo-retention-')),filename=path.join(dir,'k99.db');
  const store=createStore(filename),o=order(),intake=path.join(dir,'01_고객세탁사진');
  const folder=path.join(intake,o.customerFolderName),compare=path.join(dir,'02_세탁전후사진');
  fs.mkdirSync(folder,{recursive:true});fs.mkdirSync(compare);fs.writeFileSync(path.join(folder,'photo.jpg'),'intake');
  fs.writeFileSync(path.join(compare,'Before-After_keep.jpg'),'comparison');
  t.after(()=>{store.close();fs.rmSync(dir,{recursive:true,force:true});});
  global.window={localStorage:{getItem:key=>store.storage({op:'get',key}),
    setItem:(key,value)=>store.storage({op:'set',key,value,expected:store.storage({op:'get',key})})}};
  window.localStorage.setItem('k99-confirmed-orders-v1',JSON.stringify([o]));
  const db=new Database(filename);
  db.prepare('INSERT OR REPLACE INTO metadata VALUES (?,?)').run('archive-folder:'+o.id,o.customerFolderName);db.close();
  const {updateSavedOrder}=load('order-record.ts');
  const restored=restoreHandover(o);updateSavedOrder(restored,o);
  let clock=Date.parse('2027-02-01T00:00:00Z');
  const cleanup=createPhotoRetention({store,filename,intakeRoot:intake,now:()=>clock});
  cleanup.configure(60);
  assert.equal((await cleanup.run({confirmed:true})).lastResult.deletedFolders,0);
  assert.ok(fs.existsSync(folder));
  const reissued=confirmStaffHandover(restored,{at:new Date(clock)});updateSavedOrder(reissued,restored);
  assert.equal((await cleanup.run({confirmed:true})).lastResult.deletedFolders,0);
  clock+=61*86400000;
  assert.equal((await cleanup.run({confirmed:true})).lastResult.deletedFolders,1);
  assert.ok(!fs.existsSync(folder));assert.ok(fs.existsSync(path.join(compare,'Before-After_keep.jpg')));
  assert.equal(JSON.parse(window.localStorage.getItem('k99-confirmed-orders-v1'))[0].payment_status,'PAID');
});
