'use strict';
// Static LAN-only phone upload page. No external resources; untrusted text via textContent only.
// NOTE: this template contains no backticks or dollar-brace sequences inside.
const mobileUploadPage = `<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="referrer" content="no-referrer">
<title>K99 휴대폰 사진 전송</title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100dvh;font-family:'Malgun Gothic','Apple SD Gothic Neo','Noto Sans KR',sans-serif;background:#efece2;color:#1d2c35;-webkit-text-size-adjust:100%}
main{max-width:560px;margin:0 auto;padding:18px 16px 40px;display:grid;gap:14px}
h1{margin:0;font-size:22px;letter-spacing:-.03em}
.sub{margin:2px 0 0;font-size:14px;color:#55646c}
.card{background:#fbfaf6;border:1px solid #d8d2c0;border-radius:14px;padding:14px}
dl{display:grid;grid-template-columns:auto 1fr;gap:6px 12px;margin:0;font-size:15px}dt{color:#66747b}dd{margin:0;font-weight:800;word-break:break-all}
.big{display:flex;align-items:center;justify-content:center;width:100%;min-height:76px;border-radius:14px;border:0;background:#235b56;color:#fff;font-size:20px;font-weight:800;position:relative;overflow:hidden}
.alt{display:flex;align-items:center;justify-content:center;width:100%;min-height:52px;border-radius:12px;border:2px solid #235b56;background:#dbece4;color:#123d38;font-size:17px;font-weight:800;position:relative;overflow:hidden}
.big input,.alt input{position:absolute;inset:0;opacity:0;width:100%;height:100%}
.disabled{opacity:.45;pointer-events:none}
ul#list{list-style:none;margin:0;padding:0;display:grid;gap:8px}
ul#list li{display:grid;grid-template-columns:1fr auto;gap:2px 8px;padding:10px 12px;border-radius:10px;background:#fff;border:1px solid #ddd6c4;font-size:14px}
.n{font-weight:800;word-break:break-all}.s{font-weight:800;white-space:nowrap}.m{grid-column:1/-1;color:#5b6a71;font-size:13px}
.pending .s{color:#7a5a00}.saved .s{color:#1b6a4a}.failed .s{color:#a63a2c}.sending .s{color:#075fc4}
.send{width:100%;min-height:60px;border:0;border-radius:12px;background:#075fc4;color:#fff;font-size:19px;font-weight:800}
.send:disabled{opacity:.45}
.msg{margin:0;padding:12px;border-radius:10px;font-weight:800;font-size:15px;line-height:1.5}
.ok{background:#d6f3e5;color:#0c4a33}.err{background:#fbe1dc;color:#7e2418}.info{background:#f4ecd2;color:#4d3800}
.guide{margin:0;padding-left:18px;font-size:13px;line-height:1.65;color:#4c5a61}
</style></head>
<body><main>
<header><h1>K99 휴대폰 정밀 촬영</h1><p class="sub">케어라벨 / 세부 오염 근접 촬영용 · 매장 PC로만 전송됩니다</p></header>
<button type="button" id="notice-tab" class="alt">완성 세탁물 특별 고지 입력</button>
<p id="status" class="msg info">접수 정보를 확인하는 중입니다...</p>
<section class="card" id="meta" hidden><dl>
<dt>고객</dt><dd id="customer"></dd><dt>전화 뒤4자리</dt><dd id="last4"></dd>
<dt>품목</dt><dd id="item"></dd><dt>저장 폴더</dt><dd id="folder"></dd>
<dt>유효 시간</dt><dd id="expiry"></dd><dt>전송 완료</dt><dd id="count"></dd></dl></section>
<label class="big disabled" id="camLabel">카메라로 촬영하기<input id="cam" type="file" accept="image/*" capture="environment" multiple disabled></label>
<label class="alt disabled" id="albumLabel">앨범에서 선택<input id="album" type="file" accept="image/*" multiple disabled></label>
<ul id="list"></ul>
<button class="send" id="send" type="button" disabled>선택한 사진 전송</button>
<p id="result" class="msg" hidden></p>
<ul class="guide">
<li>JPEG 또는 PNG, 사진 1장당 최대 8MB입니다. 원본 그대로 전송하며 크기를 줄이지 않습니다.</li>
<li>아이폰 HEIC 사진은 받을 수 없습니다. 설정 &gt; 카메라 &gt; 포맷에서 "높은 호환성"을 선택한 뒤 다시 촬영해 주세요.</li>
<li>연결이 안 되면 휴대폰이 매장 PC와 같은 WiFi인지 확인하고, PC의 네트워크를 개인(Private)으로, 방화벽 TCP 5050 허용을 확인해 주세요.</li>
</ul>
</main>
<script>
(function(){
'use strict';
var q=new URLSearchParams(location.search);var token=q.get('token')||'';
document.getElementById('notice-tab').onclick=function(){
  var button=this;button.disabled=true;
  fetch('/api/mobile-notice-link?token='+encodeURIComponent(token),{cache:'no-store'})
    .then(function(r){return r.json().then(function(d){if(!r.ok)throw Error(d.error||'연결을 확인해 주세요.');return d;});})
    .then(function(d){var next=new URL(d.url);if(next.protocol!=='http:'||next.hostname!==location.hostname)throw Error('같은 매장 PC 주소만 연결할 수 있습니다.');location.assign(next.href);})
    .catch(function(e){button.disabled=false;alert(e.message);});
};
var $=function(id){return document.getElementById(id);};
var MAX_BYTES=8*1024*1024,MAX_FILES=50,expiresAt=0,ready=false,busy=false,items=[];
function setMsg(el,kind,text){el.hidden=false;el.className='msg '+kind;el.textContent=text;}
function rid(){var b=new Uint8Array(16);crypto.getRandomValues(b);var s='';for(var i=0;i<b.length;i++){s+=(b[i]+256).toString(16).slice(1);}return s;}
function mb(n){return (n/1048576).toFixed(2)+'MB';}
function netErr(){return '매장 PC에 연결하지 못했습니다. 같은 WiFi인지, PC 네트워크가 개인(Private)이고 방화벽 TCP 5050이 허용되어 있는지 확인해 주세요.';}
function expired(){return expiresAt>0&&Date.now()>=expiresAt;}
function enableInputs(on){['cam','album'].forEach(function(id){$(id).disabled=!on;$(id+'Label').classList.toggle('disabled',!on);});}
function render(){
  var list=$('list');while(list.firstChild)list.removeChild(list.firstChild);
  items.forEach(function(it){
    var li=document.createElement('li');li.className=it.state;
    var n=document.createElement('span');n.className='n';n.textContent=it.file.name||'(이름 없음)';
    var s=document.createElement('span');s.className='s';
    s.textContent={pending:'대기',sending:'전송 중',saved:'저장됨',failed:'실패'}[it.state];
    var m=document.createElement('span');m.className='m';
    var d=it.file.lastModified?new Date(it.file.lastModified).toLocaleString('ko-KR'):'촬영시각 없음';
    m.textContent=mb(it.file.size)+' · '+(it.file.type||'형식 미확인(서버 확인)')+' · '+d+(it.error?' · '+it.error:'');
    li.appendChild(n);li.appendChild(s);li.appendChild(m);list.appendChild(li);
  });
  var todo=items.filter(function(i){return i.state==='pending'||i.state==='failed';}).length;
  var send=$('send');send.disabled=!ready||busy||!todo||expired();
  send.textContent=busy?'전송 중...':(items.some(function(i){return i.state==='failed';})?'실패한 사진 다시 전송 ('+todo+'장)':'선택한 사진 전송 ('+todo+'장)');
}
function check(file){
  var t=(file.type||'').toLowerCase(),nm=(file.name||'').toLowerCase();
  if(/heic|heif/.test(t)||/\\.(heic|heif)$/.test(nm))return 'HEIC 형식은 받을 수 없습니다. 설정 > 카메라 > 포맷 > 높은 호환성으로 바꿔 JPEG로 촬영해 주세요.';
  if(t&&t!=='image/jpeg'&&t!=='image/png')return 'JPEG/PNG만 전송할 수 있습니다.';
  if(file.size>MAX_BYTES)return '사진이 '+mb(MAX_BYTES)+'를 넘습니다.';
  if(!file.size)return '빈 파일입니다.';
  return '';
}
function add(input){
  var files=Array.prototype.slice.call(input.files||[]);input.value='';
  files.forEach(function(f){
    if(items.length>=MAX_FILES){setMsg($('result'),'err','한 번에 최대 '+MAX_FILES+'장까지 선택할 수 있습니다.');return;}
    var e=check(f);items.push({file:f,id:rid(),state:e?'failed':'pending',error:e,blocked:!!e});
  });
  render();
}
$('cam').addEventListener('change',function(){add(this);});
$('album').addEventListener('change',function(){add(this);});
function uploadOne(it){
  var t=(it.file.type||'').toLowerCase();
  var ct=(t==='image/jpeg'||t==='image/png')?t:'application/octet-stream';
  return fetch('/api/upload-mobile-photo',{method:'POST',cache:'no-store',headers:{'Content-Type':ct,'X-K99-Session-Token':token,'X-K99-Upload-Id':it.id},body:it.file})
    .then(function(r){return r.json().catch(function(){return {success:false,error:'서버 응답을 읽지 못했습니다 (HTTP '+r.status+').'};});});
}
$('send').addEventListener('click',function(){
  if(busy||!ready)return;
  if(expired()){setMsg($('result'),'err','QR이 만료되었습니다. 매장 PC에서 QR을 다시 열어 주세요.');render();return;}
  busy=true;render();
  var queue=items.filter(function(i){return (i.state==='pending'||i.state==='failed')&&!i.blocked;});
  var ok=0,fail=0;
  (function next(){
    var it=queue.shift();
    if(!it){busy=false;render();
      if(fail)setMsg($('result'),'err',ok+'장 저장, '+fail+'장 실패했습니다. 실패한 사진만 다시 전송할 수 있습니다.');
      else if(ok)setMsg($('result'),'ok',ok+'장이 매장 PC에 저장되었습니다.');
      return;}
    it.state='sending';it.error='';render();
    uploadOne(it).then(function(res){
      if(res&&res.success){it.state='saved';ok++;if(typeof res.uploadedCount==='number')$('count').textContent=res.uploadedCount+'장';
        if(res.fileName)it.error=(res.reused?'이미 저장됨: ':'')+res.fileName;}
      else{it.state='failed';fail++;it.error=(res&&res.error)||'저장하지 못했습니다.';}
    },function(){it.state='failed';fail++;it.error=netErr();}).then(function(){render();next();});
  })();
});
function tick(){
  if(!expiresAt)return;var left=expiresAt-Date.now();
  if(left<=0){$('expiry').textContent='만료됨';ready=false;enableInputs(false);setMsg($('status'),'err','QR이 만료되었습니다. 매장 PC에서 QR을 다시 열어 주세요.');render();return;}
  $('expiry').textContent=Math.floor(left/60000)+'분 '+Math.floor(left%60000/1000)+'초 남음';
}
if(!token){setMsg($('status'),'err','주소에 접속 정보가 없습니다. 매장 PC의 QR을 다시 스캔해 주세요.');return;}
fetch('/api/mobile-upload-status?token='+encodeURIComponent(token),{cache:'no-store'})
  .then(function(r){return r.json();})
  .then(function(d){
    if(!d||!d.success){setMsg($('status'),'err',(d&&d.error)||'유효하지 않거나 만료된 QR입니다. 매장 PC에서 다시 열어 주세요.');return;}
    $('customer').textContent=String(d.customerName||'');$('last4').textContent=String(d.phoneLast4||'');
    $('item').textContent=String(d.itemName||'');$('folder').textContent=String(d.folderIdentifier||'');
    $('count').textContent=(Number(d.uploadedCount)||0)+'장';
    if(Number(d.maxBytes)>0)MAX_BYTES=Number(d.maxBytes);if(Number(d.maxFiles)>0)MAX_FILES=Number(d.maxFiles);
    expiresAt=Number(d.expiresAt)||0;$('meta').hidden=false;
    setMsg($('status'),'info','아래 정보가 맞는지 확인한 뒤 촬영해 주세요.');
    ready=true;enableInputs(true);tick();setInterval(tick,1000);render();
  },function(){setMsg($('status'),'err',netErr());});
})();
</script></body></html>`;
module.exports = { mobileUploadPage };
