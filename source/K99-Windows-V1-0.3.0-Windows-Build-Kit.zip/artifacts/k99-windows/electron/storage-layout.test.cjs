'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const {prepareStorageLayout,prepareStorageLayoutAsync,discoverDrivesAsync}=require('./storage-layout.cjs');
const {applyStartupPreference}=require('./startup-policy.cjs');
test('member release always registers startup and a moved installation refreshes its path',()=>{
  let saved;
  const app={setLoginItemSettings:s=>{saved=s;},getLoginItemSettings:()=>saved};
  assert.equal(applyStartupPreference(app,null,'C:\\K99\\app.exe').enabled,true);
  assert.equal(applyStartupPreference(app,{enabled:false},'D:\\K99\\app.exe').enabled,true);
  assert.equal(saved.path,'D:\\K99\\app.exe');assert.deepEqual(saved.args,['--k99-autostart']);
});
function fake(existing){
  const files=new Map(),dirs=new Set(existing),created=[];
  const io={
    existsSync:p=>dirs.has(p)||files.has(p),
    readFileSync:p=>files.get(p),lstatSync:()=>({isSymbolicLink:()=>false}),
    mkdirSync:p=>{dirs.add(p);created.push(p);},accessSync:()=>{},
    openSync:p=>p,writeFileSync:(p,v)=>files.set(p,v),fsyncSync:()=>{},closeSync:()=>{},
  };
  return {io,created,dirs};
}
test('registered store names create only a new root, while a pinned existing root never changes on a rename',()=>{
  const f=fake(['C:\\','D:\\']);
  const first=prepareStorageLayout('/shop',{io:f.io,drives:[{root:'D:\\',type:3}],storeName:'우리 세탁매장'});
  assert.equal(first.root,'D:\\우리 세탁매장');
  const again=prepareStorageLayout('/shop',{io:f.io,drives:[{root:'D:\\',type:3}],storeName:'바뀐 상호'});
  assert.equal(again.root,first.root);
  const {storeFolderName}=require('./storage-layout.cjs');
  assert.equal(storeFolderName('..'),'K99세탁매장');
  assert.equal(storeFolderName('CON'),'K99세탁매장');
  assert.equal(storeFolderName('상호/이름'),'상호_이름');
});
for(const [name,exists,want] of [
  ['existing Gwacheon',['C:\\','D:\\','D:\\K99과천매장'],'D:\\K99과천매장'],
  ['new D drive',['C:\\','D:\\'],'D:\\K99세탁매장'],
  ['external before D',['C:\\','D:\\','E:\\'],'E:\\K99세탁매장'],
  ['Gwacheon before external',['C:\\','D:\\','E:\\','D:\\K99과천매장'],'D:\\K99과천매장'],
  ['single C drive',['C:\\'],'C:\\K99세탁매장'],
]){
  test(`layout ${name} creates all four directories and pins root`,()=>{
    const f=fake(exists),drives=exists.filter(root=>/^[A-Z]:\\$/.test(root))
      .map(root=>({root,type:3,external:root==='E:\\'}));
    const one=prepareStorageLayout('/test-user',{io:f.io,drives});
    assert.equal(one.root,want);
    for(const sub of ['00_프로그램\\K99_명품세탁비','01_고객세탁사진','02_세탁전후사진','DB_백업','03_고객모니터영상'])assert.ok(f.created.includes(path.win32.join(want,sub)));
    assert.equal(one.videos,path.win32.join(want,'03_고객모니터영상'));
    f.dirs.add('D:\\');assert.equal(prepareStorageLayout('/test-user',{io:f.io}).root,want);
    f.dirs.delete(path.win32.parse(want).root);
    assert.throws(()=>prepareStorageLayout('/test-user',{io:f.io}),/드라이브/);
  });
}
test('saved root and existing store start without invoking PowerShell',async()=>{
  const f=fake(['C:\\','D:\\','D:\\K99과천매장']);
  const execFile=()=>{throw Error('PowerShell must not run');};
  const first=await prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',execFile});
  assert.equal(first.root,'D:\\K99과천매장');
  const next=await prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',execFile});
  assert.equal(next.root,first.root);
  f.dirs.delete('D:\\');
  await assert.rejects(prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',execFile}),/드라이브/);
});
test('single C drive starts without a shell or metadata wait',async()=>{
  const f=fake(['C:\\']);
  const layout=await prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',
    execFile:()=>{assert.fail('shell invoked');}});
  assert.equal(layout.root,'C:\\K99세탁매장');
});
test('successful async metadata keeps external USB priority',async()=>{
  const f=fake(['C:\\','D:\\','E:\\']);
  const execFile=(command,args,options,done)=>{
    assert.equal(command,'powershell.exe');assert.equal(options.windowsHide,true);
    setImmediate(()=>done(null,JSON.stringify([
      {DeviceID:'C:',DriveType:3},{DeviceID:'D:',DriveType:3},{DeviceID:'E:',DriveType:3,External:true},
    ])));
    return {kill(){}};
  };
  const layout=await prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',execFile});
  assert.equal(layout.root,'E:\\K99세탁매장');
});
for(const mode of ['timeout','missing','malformed','empty','throw']){
  test(`optional disk metadata ${mode} falls back without a startup error`,async()=>{
    const f=fake(['C:\\','D:\\']);let killCount=0,late;
    const execFile=(command,args,options,done)=>{
      late=done;
      if(mode==='throw')throw Error('spawn failed');
      if(mode==='missing')setImmediate(()=>done(Object.assign(Error('not found'),{code:'ENOENT'})));
      if(mode==='malformed')setImmediate(()=>done(null,'not JSON'));
      if(mode==='empty')setImmediate(()=>done(null,'[]'));
      return {kill(){killCount++;}};
    };
    let eventLoopAlive=false;
    setImmediate(()=>{eventLoopAlive=true;});
    const layout=await prepareStorageLayoutAsync('/u',{io:f.io,platform:'win32',execFile,timeoutMs:25});
    assert.equal(layout.root,'D:\\K99세탁매장');
    if(mode==='timeout'){
      assert.equal(eventLoopAlive,true);assert.equal(killCount,1);
      late(Object.assign(Error('slow PowerShell'),{code:'ETIMEDOUT'}));
    }
    assert.equal(prepareStorageLayout('/u',{io:f.io}).root,layout.root);
  });
}
test('runtime drive discovery has no synchronous child-process dependency',()=>{
  const source=require('node:fs').readFileSync(require.resolve('./storage-layout.cjs'),'utf8');
  assert.doesNotMatch(source,/\b(?:spawnSync|execFileSync|execSync)\s*\(/);
});
