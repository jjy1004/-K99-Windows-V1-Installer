'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const appRequire=createRequire(path.join(__dirname,'../package.json')),ts=appRequire('typescript');
const source=name=>fs.readFileSync(path.join(__dirname,'../src',name),'utf8');
const compile=name=>ts.transpileModule(source(name),{compilerOptions:{
  module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,
}}).outputText;
const mod={exports:{}};
new Function('exports','require',compile('camera-device.ts'))(mod.exports,appRequire);
const {automaticCamera,initialDirectCamera,isVirtualCamera,acquireCamera,cameraFailure}=mod.exports;
const device=(deviceId,label)=>({deviceId,label,kind:'videoinput'});
const physical=device('usb','usb-webcam (2bc5:0529)'),su=device('su','SU200MB');
const obs=device('obs','OBS Virtual Camera'),insta=device('iv','Insta360 Virtual Camera');
function stream(id){
  const track={readyState:'live',stopped:false,getSettings:()=>({deviceId:id}),stop(){this.stopped=true;this.readyState='ended';}};
  return {getTracks:()=>[track],getVideoTracks:()=>[track]};
}
test('SU200MB / SU200-MB / VID PID identification beats generic external webcams, never virtual',()=>{
  const generic=device('other','Logitech Webcam');
  for(const label of ['SU200MB','SU200-MB','SU200 MB','USB Webcam (VID:2bc5 PID:0529)'])
    assert.equal(automaticCamera([obs,generic,device('su',label)]).deviceId,'su');
  assert.equal(automaticCamera([obs,insta]),undefined);
  assert.equal(isVirtualCamera('Insta360 Link 2C'),false);
  assert.equal(initialDirectCamera([obs,su],'obs'),'su');
  assert.equal(initialDirectCamera([physical,su],'usb'),'usb');
});
test('preferred physical selection uses only ideal 1080p, without frame-rate constraints, exact or minima',async()=>{
  const calls=[],selected=stream('usb');
  const result=await acquireCamera({enumerateDevices:async()=>[su,obs,physical],
    getUserMedia:async c=>{calls.push(c);return selected;}},'usb');
  assert.equal(result,selected);assert.equal(calls.length,1);
  assert.deepEqual(calls[0],{audio:false,video:{deviceId:'usb',width:{ideal:1920},height:{ideal:1080}}});
});
for(const name of ['NotFoundError','NotReadableError','NotAllowedError','AbortError','OverconstrainedError']){
  test(`${name} retries once on the same device with only deviceId, then reports failure`,async()=>{
    const calls=[],error=Object.assign(new Error('device failure'),{name});
    await assert.rejects(acquireCamera({enumerateDevices:async()=>[obs,physical],
      getUserMedia:async c=>{calls.push(c);throw error;}},'usb'),e=>e===error);
    assert.equal(calls.length,2);assert.deepEqual(calls[1],{audio:false,video:{deviceId:'usb'}});
    assert.match(cameraFailure(error),/카메라 연결 실패/);
    assert.match(cameraFailure(error),/자동 전환하지 않았습니다/);
  });
}
test('1080p driver rejection falls back to an unconstrained stream on the same UVC webcam',async()=>{
  const calls=[];
  const result=await acquireCamera({enumerateDevices:async()=>[physical,obs],getUserMedia:async c=>{
    calls.push(c);if(calls.length===1)throw Object.assign(Error('driver busy'),{name:'NotReadableError'});
    return stream('usb');
  }},'usb');
  assert.equal(result.getVideoTracks()[0].getSettings().deviceId,'usb');
  assert.deepEqual(calls[1],{audio:false,video:{deviceId:'usb'}});
});
test('a browser that ignores a preferred device and returns OBS is rejected and every wrong track is stopped',async()=>{
  const wrong=[];
  await assert.rejects(acquireCamera({enumerateDevices:async()=>[physical,obs],getUserMedia:async()=>{
    const s=stream('obs');wrong.push(s);return s;
  }},'usb'),/다른 장치/);
  assert.equal(wrong.length,2);assert.ok(wrong.every(s=>s.getTracks()[0].stopped));
});
test('permission bootstrap reveals labels, releases its probe, and selects the UVC camera on a new PC',async()=>{
  let permitted=false;const calls=[],probe=stream('probe');
  const result=await acquireCamera({enumerateDevices:async()=>permitted?[obs,su]:[device('new','')],
    getUserMedia:async c=>{
      calls.push(c);if(!permitted){permitted=true;return probe;}
      assert.equal(probe.getTracks()[0].stopped,true);return stream('su');
    }});
  assert.equal(result.getVideoTracks()[0].getSettings().deviceId,'su');
  assert.equal(calls[0].video.deviceId,undefined);assert.equal(calls[1].video.deviceId,'su');
});
test('virtual-only auto mode never opens it but explicit manual virtual selection remains compatible',async()=>{
  let calls=0;
  const media={enumerateDevices:async()=>[obs,insta],getUserMedia:async c=>{calls++;return stream(c.video.deviceId);}};
  await assert.rejects(acquireCamera(media),/가상 카메라는 자동 선택하지 않습니다/);assert.equal(calls,0);
  assert.equal((await acquireCamera(media,'obs')).getVideoTracks()[0].getSettings().deviceId,'obs');
});
function controls(media,delays=[]){
  const exports={};
  new Function('exports','require','navigator','window',compile('camera-capture-controls.ts'))(exports,id=>{
    if(id==='./camera-device')return {...mod.exports,cameraDelay:async ms=>{delays.push(ms);}};
    if(id==='react')return {};
    return {};
  },{mediaDevices:media},{addEventListener(){}});
  return exports;
}
test('startup enumeration never holds a hidden stream; each open waits 300ms after releasing all owned tracks',async()=>{
  const streams=[],delays=[];
  const api=controls({enumerateDevices:async()=>[physical,su],getUserMedia:async c=>{
    assert.ok(streams.every(s=>s.getTracks()[0].stopped));
    const s=stream(c.video.deviceId);streams.push(s);return s;
  }},delays);
  await api.warmPreferredCamera();assert.equal(streams.length,0);
  await api.openPreferredCamera('usb');await api.openPreferredCamera('su');
  assert.deepEqual(delays,[300,300]);assert.equal(streams[0].getTracks()[0].stopped,true);
  api.releaseCameraStreams();assert.ok(streams.every(s=>s.getTracks()[0].stopped));
});
test('rapid camera switches cancel pending requests and release any late arriving old stream',async()=>{
  let deliverOld;const old=stream('su');
  const api=controls({enumerateDevices:async()=>[su,physical],getUserMedia:async c=>
    c.video.deviceId==='su'?new Promise(resolve=>{deliverOld=resolve;}):stream('usb')});
  const first=api.openPreferredCamera('su');const cancelled=assert.rejects(first,e=>e.name==='AbortError');
  await new Promise(setImmediate);
  const current=await api.openPreferredCamera('usb');await cancelled;
  deliverOld(old);await new Promise(setImmediate);
  assert.equal(old.getTracks()[0].stopped,true);
  assert.equal(current.getTracks()[0].stopped,false);api.releaseCameraStreams();
});
test('first decoded frame is required; play rejection or missing frames produces an explicit error, not a permanent black preview',async()=>{
  const api=controls({enumerateDevices:async()=>[],getUserMedia:async()=>stream('usb')});
  const v={readyState:2,videoWidth:1920,videoHeight:1080,play:async()=>{}};
  await api.playCameraVideo(v,stream('usb'),20);
  await assert.rejects(api.playCameraVideo({...v,readyState:0},stream('usb'),20),/카메라/);
  await assert.rejects(api.playCameraVideo({...v,readyState:0,play:async()=>{throw Error('decoder error');}},stream('usb'),20),/decoder/);
});
test('missing UVC deviceId metadata is not treated as a refused stream, but a known different label is rejected',async()=>{
  const s=stream(undefined);s.getVideoTracks()[0].label=physical.label;
  assert.equal(await acquireCamera({enumerateDevices:async()=>[physical],getUserMedia:async()=>s},'usb'),s);
  assert.equal(mod.exports.cameraStreamDeviceId(s),'usb','sliders keep their selected-device settings key when UVC metadata omits it');
  const wrong=stream(undefined);wrong.getVideoTracks()[0].label=obs.label;
  await assert.rejects(acquireCamera({enumerateDevices:async()=>[physical,obs],getUserMedia:async()=>wrong},'usb'),/다른 장치/);
  assert.equal(wrong.getTracks()[0].stopped,true);
});
test('the raw video is visible before first-frame checks and a decoded stream does not wait for a pending play promise',async()=>{
  const api=controls({});
  const video={hidden:true,readyState:2,videoWidth:640,videoHeight:480,play:()=>new Promise(()=>{})};
  await api.playCameraVideo(video,stream('usb'),20);
  assert.equal(video.hidden,false);assert.equal(video.autoplay,true);assert.equal(video.muted,true);assert.equal(video.playsInline,true);
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const s=source(name),tag=s.match(/<video ref=\{videoRef\}[^>]+/)[0];
    assert.doesNotMatch(tag,/hidden=\{[^}]*(!previewOn|!cameraOn)|opacity:/);
    assert.match(s,/\.ready&&!.*\.error\?'visible':'hidden'/);
  }
});
test('both camera screens use safe release and never send hardware manual control commands',()=>{
  for(const name of ['camera-device.ts','camera-capture-controls.ts','camera-color.ts','NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const text=source(name);
    assert.doesNotMatch(text,/\.applyConstraints\s*\(|whiteBalanceMode|exposureMode|colorTemperature|deviceId:\s*\{\s*exact/);
  }
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    assert.ok(source(name).includes('releaseCameraStreams();'));
    assert.ok(source(name).includes('playCameraVideo('));
  }
  const src=source('NativeDraftCamera.tsx');
  assert.match(src,/void start\(id\)/);assert.match(src,/data-testid="error-ndc-camera"/);
  assert.match(src,/if\(epoch!==cameraEpoch\.current\)return;\s*stop\(\);setCameraError/);
});
