'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createRequire}=require('node:module'),req=createRequire(path.join(__dirname,'../package.json')),ts=req('typescript');
const source=name=>fs.readFileSync(path.join(__dirname,'../src',name),'utf8');
const compile=name=>ts.transpileModule(source(name),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const loaded={};
function load(name){
  if(loaded[name])return loaded[name];
  const exports={};loaded[name]=exports;
  new Function('exports','require',compile(name+'.ts'))(exports,id=>id.startsWith('./')?load(id.slice(2)):req(id));
  return exports;
}
const api=load('camera-device');
// The existing Windows workflow already runs this entrypoint. Keep the outer
// workflow (including NSIS and release-media steps) byte-for-byte unchanged.
require('./camera-baseline-contract.test.cjs');
require('./manual-camera-resolution.test.cjs');
const device=(deviceId,label)=>({kind:'videoinput',deviceId,label});
const su=device('su','SU200-MB (2bc5:0529)'),obs=device('obs','OBS Virtual Camera');
const physical=device('usb','usb-webcam (2bc5:0529)'),internal=device('internal','Integrated Camera');
function stream(id){
  const track={readyState:'live',getSettings:()=>({deviceId:id}),stop(){this.readyState='ended';}};
  return {getVideoTracks:()=>[track],getTracks:()=>[track]};
}
test('standalone SU200MB and generic UVC are selected without OBS or any helper program',()=>{
  assert.equal(api.automaticCamera([internal,obs,su]),su);
  assert.equal(api.automaticCamera([internal,physical]),physical);
  assert.equal(api.automaticCamera([obs]),undefined);
  assert.equal(api.isVirtualCamera('Insta360 Virtual Camera'),true);
});
test('direct opener requests selected physical UVC with ideal FHD, without exact/min/frame/exposure restrictions',async()=>{
  const calls=[],s=stream('su');
  const result=await api.acquireCamera({enumerateDevices:async()=>[su],getUserMedia:async c=>{calls.push(c);return s;}});
  assert.equal(result,s);
  assert.deepEqual(calls,[{audio:false,video:{deviceId:'su',width:{ideal:1920},height:{ideal:1080}}}]);
  assert.doesNotMatch(JSON.stringify(calls),/frameRate|whiteBalance|exposure|colorTemperature|"min"|"exact"|MJPG|codec/);
});
test('unsupported resolution relaxes only resolution on the same selected camera',async()=>{
  const calls=[];
  const s=await api.acquireCamera({enumerateDevices:async()=>[obs,physical],getUserMedia:async c=>{
    calls.push(c);
    if(calls.length===1)throw Object.assign(Error('unsupported'),{name:'OverconstrainedError',constraint:'width'});
    return stream('usb');
  }},'usb');
  assert.equal(s.getVideoTracks()[0].getSettings().deviceId,'usb');
  assert.deepEqual(calls[1],{audio:false,video:{deviceId:'usb',width:{ideal:1280},height:{ideal:720}}});
});
for(const name of ['NotAllowedError','SecurityError','CameraOpenTimeout']){
  test(`${name} never substitutes OBS or another camera`,async()=>{
    let calls=0;const error=Object.assign(Error('driver/permission failure'),{name});
    await assert.rejects(api.acquireCamera({enumerateDevices:async()=>[obs,physical],
      getUserMedia:async()=>{calls++;throw error;}},'usb'),e=>e===error);
    assert.equal(calls,1);assert.match(api.cameraFailure(error),/자동 전환하지 않았습니다/);
  });
}
test('a missing physical camera is a visible error; QR is still available',async()=>{
  let called=false;
  await assert.rejects(api.acquireCamera({enumerateDevices:async()=>[obs],getUserMedia:async()=>{called=true;}}),/가상 카메라/);
  assert.equal(called,false);assert.match(api.cameraFailure(Error('missing')),/QR 촬영은 계속/);
});
for(const name of ['NotReadableError','NotFoundError','AbortError']){
  test(`${name}: FHD, HD and default retries stay on the same selected USB camera`,async()=>{
    const calls=[],error=Object.assign(Error('driver failure'),{name});
    await assert.rejects(api.acquireCamera({enumerateDevices:async()=>[obs,physical],
      getUserMedia:async c=>{calls.push(c);throw error;}},'usb'),e=>e===error);
    assert.deepEqual(calls.map(c=>c.video),[
      {deviceId:'usb',width:{ideal:1920},height:{ideal:1080}},
      {deviceId:'usb',width:{ideal:1280},height:{ideal:720}},{deviceId:'usb'}]);
  });
}
test('a refused FHD and HD request can still open the same camera at its default resolution',async()=>{
  let count=0;
  const s=await api.acquireCamera({enumerateDevices:async()=>[su],getUserMedia:async c=>{
    count++;if(c.video.width)throw Object.assign(Error('unsupported'),{name:'OverconstrainedError'});return stream('su');
  }});
  assert.equal(count,3);assert.equal(s.getVideoTracks()[0].getSettings().deviceId,'su');
});
test('a preferred device ignored by the browser is stopped and never displayed as OBS',async()=>{
  const wrong=stream('obs');
  await assert.rejects(api.acquireCamera({enumerateDevices:async()=>[physical,obs],getUserMedia:async()=>wrong},'usb'),/다른 장치/);
  assert.equal(wrong.getTracks()[0].readyState,'ended');
});
test('decode failure releases the failed high-resolution stream before the HD retry',async()=>{
  const streams=[];let decoded=0;
  const s=await api.acquireCamera({enumerateDevices:async()=>[su],getUserMedia:async()=>{
    if(streams.length)assert.equal(streams[0].getTracks()[0].readyState,'ended');
    const s=stream('su');streams.push(s);return s;
  }},'su',async()=>{if(decoded++===0)throw Error('no first frame');});
  assert.equal(streams.length,2);assert.equal(s,streams[1]);
});
test('permission labels are bootstrapped without displaying an unvalidated virtual camera',async()=>{
  let permitted=false;const first=stream('su');
  const s=await api.acquireCamera({enumerateDevices:async()=>permitted?[obs,su]:[device('','')],
    getUserMedia:async()=>{permitted=true;return first;}});
  assert.equal(s,first);assert.equal(first.getTracks()[0].readyState,'live');
});
test('missing optional deviceId metadata retains the selected physical camera identity for saved manual settings',async()=>{
  const s=stream(undefined);s.getTracks()[0].label='SU200MB';
  const actual=await api.acquireCamera({enumerateDevices:async()=>[su,obs],getUserMedia:async()=>s},'su');
  assert.equal(actual,s);assert.equal(api.cameraStreamDeviceId(s),'su');
});
test('OBS virtual camera is rejected even when explicitly requested',async()=>{
  let calls=0;
  await assert.rejects(api.acquireCamera({enumerateDevices:async()=>[obs],getUserMedia:async()=>{calls++;return stream('obs');}},'obs'),/가상/);
  assert.equal(calls,0);
});
test('phone drivers remain selectable while OBS, Insta360 virtual and integrated cameras are hidden',async()=>{
  const phone=device('phone','Iriun Virtual Camera'),droid=device('droid','DroidCam Front Camera');
  assert.deepEqual(api.selectableCameras([obs,device('v','Insta360 Virtual Camera'),internal,phone,droid,su]),[phone,droid,su]);
  assert.equal(api.isSmartphoneCamera(phone.label),true);
  assert.equal(api.isSmartphoneCamera('OBS Iriun Virtual Camera'),false);
  const result=await api.acquireCamera({enumerateDevices:async()=>[phone,obs],getUserMedia:async c=>stream(c.video.deviceId)},'phone');
  assert.equal(result.getVideoTracks()[0].getSettings().deviceId,'phone');
});
test('restored warm stream transfers to preview instead of opening a competing stream',async()=>{
  const exports={},streams=[],events={};
  new Function('exports','require','navigator','window',compile('camera-capture-controls.ts'))(exports,id=>{
    if(id==='./camera-device')return api;return {};
  },{mediaDevices:{enumerateDevices:async()=>[su],getUserMedia:async c=>{
    const s=stream(c.video.deviceId);streams.push(s);return s;
  }}},{addEventListener:(name,fn)=>{events[name]=fn;}});
  await exports.warmPreferredCamera();assert.equal(streams.length,1);
  assert.equal(await exports.openPreferredCamera('su'),streams[0]);assert.equal(streams.length,1);
  await exports.warmPreferredCamera();events.pagehide();
  assert.equal(streams[1].getTracks()[0].readyState,'ended');
  assert.equal(streams[0].getTracks()[0].readyState,'live','the screen owns its transferred stream');
  streams[0].getTracks()[0].stop();
});
test('baseline preview and capture remain in-app, while manual controls stay a separate layer',()=>{
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const text=source(name);
    assert.match(text,/openPreferredCamera\(/);assert.match(text,/showCameraVideo\(videoRef.current,/);
    assert.doesNotMatch(text,/releaseCameraStreams|playCameraVideo|initialDirectCamera|calibrateWhiteFrame|calibrateClassic24/);
    assert.doesNotMatch(text,/\.applyConstraints\s*\(|window\.open\([^)]*k99/);
    assert.match(text,/getTracks\(\)\.forEach\(/);
  }
  assert.match(source('NativeDraftCamera.tsx'),/viewport\.capture\(g, v\);\s*correctCameraCanvas\(g,appearance.profile\)/);
  assert.match(source('NativeDraftCamera.tsx'),/data-testid="error-ndc-camera"/);
});
test('first-frame display reveals raw video before decoding and rejects a missing frame',async()=>{
  const {showCameraVideo}=load('camera-video'),s=stream('su');
  const v={hidden:true,readyState:2,videoWidth:1920,videoHeight:1080,play:async()=>{}};
  await showCameraVideo(v,s,20);assert.equal(v.hidden,false);
  await assert.rejects(showCameraVideo({...v,readyState:0},s,20),/프레임/);
  const pending={...v,play:()=>new Promise(()=>{})};
  await showCameraVideo(pending,s,20);
});
