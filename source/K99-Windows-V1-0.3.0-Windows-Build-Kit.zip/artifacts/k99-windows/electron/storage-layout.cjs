'use strict';
const fs=require('node:fs'),path=require('node:path');
const FOLDERS={program:'00_프로그램\\K99_명품세탁비',intake:'01_고객세탁사진',compare:'02_세탁전후사진',backup:'DB_백업',videos:'03_고객모니터영상'};
function storeFolderName(value){
  const name=typeof value==='string'?value.normalize('NFC').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').trim().replace(/[. ]+$/g,'').slice(0,80):'';
  return !name||/^(?:con|prn|aux|nul|com\d|lpt\d)(?:\.|$)/i.test(name)?'K99세탁매장':name;
}
function validRoot(root,paths=path.win32){
  if(typeof root!=='string'||root.length>200||!paths.isAbsolute(root)||!/^[A-Za-z]:\\/.test(root)||
    /[<>"|?*\x00-\x1f]/.test(root)||root.slice(2).includes(':')||root.split(/[\\/]/).includes('..')||
    /\\(?:windows|program files(?: \(x86\))?)(?:\\|$)/i.test(root))throw Error('저장 경로 설정이 잘못되었습니다. 기존 파일을 보존하세요.');
  return paths.normalize(root);
}
function discoverDrives(io=fs){
  return ['D',...'EFGHIJKLMNOPQRSTUVWXYZ', 'C'].filter(x=>{
    try{return io.existsSync(x+':\\');}catch{return false;}
  }).map(x=>({root:x+':\\',type:3}));
}
// Disk metadata is optional: WMI/PowerShell must never gate startup indefinitely.
async function discoverDrivesAsync({io=fs,platform=process.platform,execFile,timeoutMs=1500}={}){
  const fallback=discoverDrives(io);
  if(platform!=='win32'||fallback.length<2)return fallback;
  return new Promise(resolve=>{
    let child,timer,finished=false;
    const finish=value=>{
      if(finished)return;
      finished=true;clearTimeout(timer);resolve(value);
    };
    timer=setTimeout(()=>{
      finish(fallback);
      try{child?.kill();}catch{/* The filesystem result remains usable. */}
    },timeoutMs);
    try{
      child=(execFile||require('node:child_process').execFile)('powershell.exe',['-NoProfile','-NonInteractive','-Command',
    '[Console]::OutputEncoding=[Text.UTF8Encoding]::new(); @(Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -in 2,3 } | ForEach-Object { $external=($_.DriveType -eq 2); try { $disk=Get-Partition -DriveLetter $_.DeviceID.Substring(0,1) -ErrorAction Stop | Get-Disk -ErrorAction Stop; if ($disk.BusType -eq "USB") { $external=$true } } catch {}; [pscustomobject]@{DeviceID=$_.DeviceID;DriveType=$_.DriveType;External=$external} }) | ConvertTo-Json -Compress'],
        {encoding:'utf8',windowsHide:true,timeout:timeoutMs,maxBuffer:65536},(error,text)=>{
          if(finished)return;
          if(error)return finish(fallback);
          try{
            const value=JSON.parse(String(text||'').replace(/^\uFEFF/,'')||'[]');
            const drives=(Array.isArray(value)?value:value?[value]:[]).filter(x=>x&&/^[A-Za-z]:$/.test(x.DeviceID))
              .map(x=>({root:x.DeviceID+'\\',type:Number(x.DriveType),external:x.External===true}));
            finish(eligible(drives,io).length?drives:fallback);
          }catch{finish(fallback);}
        });
    }catch{finish(fallback);}
  });
}
async function prepareStorageLayoutAsync(userData,options={}){
  const io=options.io||fs;
  // Previously selected roots are authoritative, including when disconnected.
  if(readConfig(userData,io)||options.drives)
    return prepareStorageLayout(userData,options);
  const local=discoverDrives(io);
  // Existing store folders need no external-drive metadata.
  if(local.some(d=>['K99과천매장','K99_스마트접수','K99스마트접수']
    .some(name=>io.existsSync(path.win32.join(d.root,name)))))
    return prepareStorageLayout(userData,{...options,drives:local});
  return prepareStorageLayout(userData,{...options,drives:await discoverDrivesAsync(options)});
}
function eligible(drives,io){
  return drives.filter(d=>[2,3].includes(d.type)&&/^[A-Za-z]:\\$/.test(d.root)&&io.existsSync(d.root))
    .sort((a,b)=>{const rank=d=>d.root[0].toUpperCase()==='C'?3:
      d.external===true||d.type===2?0:d.root[0].toUpperCase()==='D'?1:2;
      return rank(a)-rank(b)||a.root.localeCompare(b.root);});
}
function readConfig(userData,io=fs){
  const file=path.join(userData,'storage-layout.json');
  if(!io.existsSync(file))return null;
  const data=JSON.parse(io.readFileSync(file,'utf8'));validRoot(data.root);
  if(data.previousRoots!==undefined&&(!Array.isArray(data.previousRoots)||data.previousRoots.length>64))throw Error('이전 저장 경로 설정 오류');
  for(const root of data.previousRoots||[])validRoot(root);
  return data;
}
function shape(root,previousRoots=[]){
  return {root,...Object.fromEntries(Object.entries(FOLDERS).map(([key,name])=>[key,path.win32.join(root,name)])),previousRoots};
}
function ensure(root,io=fs){
  validRoot(root);
  if(!io.existsSync(path.win32.parse(root).root))throw Error(`저장 드라이브가 연결되지 않았습니다: ${root}`);
  const layout=shape(root);
  for(const folder of [root,...Object.keys(FOLDERS).map(key=>layout[key])]){
    let part=path.win32.parse(folder).root;
    for(const component of folder.slice(part.length).split('\\')){
      part=path.win32.join(part,component);
      if(io.existsSync(part)&&io.lstatSync(part).isSymbolicLink())throw Error('저장 폴더의 링크·정션은 허용하지 않습니다.');
    }
    io.mkdirSync(folder,{recursive:true});io.accessSync(folder,fs.constants.R_OK|fs.constants.W_OK);
  }
  return layout;
}
function writeConfig(userData,data,io=fs,replace=false){
  const file=path.join(userData,'storage-layout.json'),tmp=replace?file+'.'+require('node:crypto').randomUUID()+'.pending':file;
  const fd=io.openSync(tmp,'wx',0o600);
  try{io.writeFileSync(fd,JSON.stringify(data));io.fsyncSync(fd);}finally{io.closeSync(fd);}
  if(replace)io.renameSync(tmp,file);
}
function prepareStorageLayout(userData,{io=fs,drives,storeName}={}){
  const saved=readConfig(userData,io);
  let root=saved?.root;
  if(!root){
    const available=eligible(drives||discoverDrives(io),io);
    // Existing Gwacheon D: data wins even when a new external disk is plugged in.
    const legacy=path.win32.join('D:\\','K99과천매장');
    if(available.some(d=>d.root.toUpperCase()==='D:\\')&&io.existsSync(legacy))root=legacy;
    for(const d of root?[]:available){
      for(const name of [...new Set(['K99과천매장','K99_스마트접수','K99스마트접수',storeFolderName(storeName)])]){
        const candidate=path.win32.join(d.root,name);
        if(io.existsSync(candidate)){root=candidate;break;}
      }
      if(root)break;
    }
    root||=available[0]&&path.win32.join(available[0].root,storeFolderName(storeName));
    if(!root)throw Error('사용 가능한 로컬 저장 드라이브가 없습니다. USB 드라이브 연결과 쓰기 권한을 확인하세요.');
  }
  const layout=ensure(root,io);
  if(!saved)writeConfig(userData,{version:2,root,previousRoots:[]},io);
  return {...layout,previousRoots:saved?.previousRoots||[]};
}
function changeStorageRoot(userData,selection,{io=fs,drives,storeName}={}){
  const old=readConfig(userData,io);if(!old)throw Error('기존 저장 설정을 확인하세요.');
  let root=validRoot(selection);
  const available=eligible(drives||discoverDrives(io),io);
  if(!available.some(d=>d.root.toLowerCase()===path.win32.parse(root).root.toLowerCase()))throw Error('사용 가능한 고정식·이동식 로컬 드라이브를 선택하세요.');
  if(root===path.win32.parse(root).root)root=path.win32.join(root,storeFolderName(storeName));
  const layout=ensure(root,io);
  if(root.toLowerCase()===old.root.toLowerCase())return {...layout,previousRoots:old.previousRoots||[],changed:false};
  const previousRoots=[...new Set([old.root,...old.previousRoots||[]])].filter(x=>x.toLowerCase()!==root.toLowerCase());
  if(previousRoots.length>64)throw Error('저장 경로 이력이 많습니다. 기존 자료를 보존하고 지원을 요청하세요.');
  writeConfig(userData,{version:2,root,previousRoots},io,true);
  return {...layout,previousRoots,changed:true};
}
function layoutStatus(layout,io=fs){
  return {...layout,folders:Object.entries(FOLDERS).map(([key])=>{
    const folder=layout[key];try{io.accessSync(folder,fs.constants.R_OK|fs.constants.W_OK);return {key,path:folder,ready:true};}
    catch{return {key,path:folder,ready:false};}
  })};
}
function assertStorageChangeAllowed({changing,writes,draft}){
  if(changing||writes)throw Error('저장 작업이 끝난 뒤 다시 시도하세요.');
  if(draft?.data?.rows?.length||draft?.data?.customerName||draft?.data?.customerPhone||draft?.data?.customerAddress)
    throw Error('진행 중인 접수를 완료하거나 접수 초안을 정리한 뒤 변경하세요.');
}
module.exports={prepareStorageLayout,prepareStorageLayoutAsync,changeStorageRoot,discoverDrives,discoverDrivesAsync,layoutStatus,FOLDERS,validRoot,assertStorageChangeAllowed,storeFolderName};
