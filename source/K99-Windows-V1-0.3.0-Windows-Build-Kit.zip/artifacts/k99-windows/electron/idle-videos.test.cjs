'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createIdleVideos}=require('./idle-videos.cjs');
function setup(t){
  const folder=fs.mkdtempSync(path.join(os.tmpdir(),'k99-idle-'));
  t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));
  let opened;
  return {folder,api:createIdleVideos({folder,openPath:async f=>{opened=f;return ''}}),opened:()=>opened};
}
test('MP4/WebM scanned in filename order; blank, links, directories and other files excluded',async t=>{
  const {folder,api,opened}=setup(t);
  for(const [name,data] of [['02_b.WEBM','abcdefgh'],['01_a.mp4','12345678'],['blank.mp4',''],['secret.txt','private']])
    fs.writeFileSync(path.join(folder,name),data);
  fs.mkdirSync(path.join(folder,'nested.mp4'));
  fs.symlinkSync(path.join(folder,'secret.txt'),path.join(folder,'link.mp4'));
  const result=api.list();
  assert.deepEqual(result.files.map(f=>f.name),['01_a.mp4','02_b.WEBM']);
  assert.ok(result.files.every(f=>!f.url.includes(folder)&&/^k99:\/\/app\/idle-videos\/[a-f0-9]{64}$/.test(f.url)));
  await api.open();assert.equal(opened(),folder);
});
test('range, HEAD, content type, unknown tokens, refresh additions and removals',async t=>{
  const {folder,api}=setup(t);
  fs.writeFileSync(path.join(folder,'01.webm'),'0123456789');
  const [{url}]=api.list().files;
  let r=await api.response(new Request(url,{headers:{range:'bytes=2-5'}}));
  assert.equal(r.status,206);assert.equal(r.headers.get('content-type'),'video/webm');
  assert.equal(r.headers.get('content-range'),'bytes 2-5/10');assert.equal(await r.text(),'2345');
  r=await api.response(new Request(url,{method:'HEAD'}));
  assert.equal(r.headers.get('content-length'),'10');assert.equal(await r.text(),'');
  assert.equal((await api.response(new Request(url,{headers:{range:'bytes=50-'}}))).status,416);
  assert.equal((await api.response(new Request('k99://app/idle-videos/invalid'))).status,404);
  fs.writeFileSync(path.join(folder,'00.mp4'),'video');
  assert.deepEqual(api.list().files.map(f=>f.name),['00.mp4','01.webm']);
  fs.unlinkSync(path.join(folder,'01.webm'));
  assert.equal((await api.response(new Request(url))).status,404);
  assert.equal(api.list().files.length,1);
});
test('replacing scanned video with symlink is blocked; empty playlist supports packaged fallback',async t=>{
  const {folder,api}=setup(t);
  assert.deepEqual(api.list().files,[]);
  const file=path.join(folder,'01.mp4');
  fs.writeFileSync(file,'video');const [{url}]=api.list().files;
  fs.unlinkSync(file);fs.writeFileSync(path.join(folder,'other.txt'),'private');
  fs.symlinkSync(path.join(folder,'other.txt'),file);
  assert.equal((await api.response(new Request(url))).status,403);
  assert.deepEqual(api.list().files,[]);
});
