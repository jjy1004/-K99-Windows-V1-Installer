'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const fail=message=>Object.assign(Error(message),{status:409});
const segment=value=>String(value||'미입력').normalize('NFC').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_')
  .replace(/^[ .]+|[ .]+$/g,'').slice(0,80)||'미입력';
function imageBytes(data){
  const match=typeof data==='string'&&/^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=\r\n]+)$/.exec(data);
  if(!match||data.length>12*1024*1024)throw fail('8MB 이하 PNG/JPEG 이미지가 필요합니다.');
  const bytes=Buffer.from(match[2],'base64');
  if(bytes.length<32||bytes.length>8*1024*1024)throw fail('사진 크기 오류');
  if(match[1]==='png'){
    if(!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))||
      bytes.toString('ascii',12,16)!=='IHDR'||bytes.readUInt32BE(16)>8192||bytes.readUInt32BE(20)>8192)
      throw fail('PNG 이미지 형식 오류');
  }else if(bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw fail('JPEG 이미지 형식 오류');
  return {bytes,extension:match[1]==='png'?'png':'jpg'};
}
function createPhotoArchive({getRoot,openPath,encodeJpeg}){
  function folder(order,kind){
    if(kind==='compare')kind='comparison';
    if(!['intake','comparison'].includes(kind))throw fail('허용되지 않은 사진 폴더');
    const root=getRoot();if(typeof root!=='string'||!root)throw fail('사진 저장 경로를 설정하세요.');
    // Main selects and pins the available disk once; photo writes never switch disks.
    fs.mkdirSync(root,{recursive:true});
    const stamp=new Date(order.createdAt||order.timestamp||'invalid');
    const date=Number.isNaN(stamp.getTime())?'날짜미상':new Intl.DateTimeFormat('sv-SE',{
      timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(stamp).replace(/-/g,'');
    const name=order.archiveFolderKey||`${date}_${segment(order.customerName)}_${String(order.customerPhone||'').replace(/\D/g,'').slice(-4)||'번호없음'}`;
    if(typeof name!=='string'||name.length>200||/[<>:"/\\|?*\x00-\x1f]/.test(name)||name==='.'||name==='..')
      throw fail('고객 사진 폴더 식별자 오류');
    const bucket=kind==='intake'?'01_고객세탁사진':'02_세탁전후사진';
    const target=path.join(root,bucket,name);
    // Check every existing component before mkdir, then check canonical result.
    let current=path.resolve(root);
    for(const part of [bucket,name]){
      current=path.join(current,part);
      if(fs.existsSync(current)&&fs.lstatSync(current).isSymbolicLink())throw fail('사진 폴더의 연결/정션은 허용하지 않습니다.');
    }
    fs.mkdirSync(target,{recursive:true});
    const realRoot=fs.realpathSync(root),real=fs.realpathSync(target);
    if(!real.startsWith(realRoot+path.sep))throw fail('사진 저장 경로 이탈');
    return real;
  }
  function durableWrite(dir,fileName,bytes){
    const file=path.join(dir,fileName);let fd,created=false;
    try{fd=fs.openSync(file,'wx',0o600);created=true;fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}
    catch(error){if(created)try{fs.unlinkSync(file);}catch{}throw fail(`사진 폴더 저장 실패: ${error.message}`);}
    finally{if(fd!==undefined)fs.closeSync(fd);}
    return {folder:dir,folderKey:path.basename(dir),fileName,rollback:()=>{try{fs.unlinkSync(file);}catch{}}};
  }
  function photo({order,garmentId,sequence,imageDataUrl,role,existingFileName,restoring=false}){
    const dir=folder(order,role==='intake'?'intake':'comparison');
    const image=imageBytes(imageDataUrl),bytes=image.extension==='jpg'?image.bytes:encodeJpeg(image.bytes);
    if(!Buffer.isBuffer(bytes)||bytes.length<4||bytes[0]!==255||bytes[1]!==216)throw fail('JPEG 변환 실패');
    if(existingFileName&&path.basename(existingFileName)===existingFileName&&fs.existsSync(path.join(dir,existingFileName))){
      const file=path.join(dir,existingFileName);
      if(fs.lstatSync(file).isSymbolicLink()||!fs.readFileSync(file).equals(bytes))throw fail('기존 접수 사진이 변경되었습니다. 덮어쓰지 않았습니다.');
      return {folder:dir,folderKey:path.basename(dir),fileName:existingFileName,rollback:()=>{}};
    }
    if(existingFileName&&path.basename(existingFileName)===existingFileName&&/^[A-Za-z0-9._-]+\.jpg$/.test(existingFileName))
      return durableWrite(dir,existingFileName,bytes);
    if(restoring){
      const name=`${segment(order.id)}_${segment(garmentId)}_${String(sequence).padStart(2,'0')}.jpg`,file=path.join(dir,name);
      if(fs.existsSync(file)){
        if(fs.lstatSync(file).isSymbolicLink()||!fs.readFileSync(file).equals(bytes))throw fail('복구 대상 사진과 기존 파일이 다릅니다. 기존 파일을 보존했습니다.');
        return {folder:dir,folderKey:path.basename(dir),fileName:name,rollback:()=>{}};
      }
      return durableWrite(dir,name,bytes);
    }
    let n=sequence,fileName;
    do{fileName=`${segment(order.id)}_${segment(garmentId)}_${String(n++).padStart(2,'0')}.jpg`;}
    while(fs.existsSync(path.join(dir,fileName)));
    return durableWrite(dir,fileName,bytes);
  }
  function comparison({order,imageDataUrl,existingFileName}){
    const image=imageBytes(imageDataUrl),dir=folder(order,'comparison');
    if(existingFileName&&/^Before-After_[0-9]+_[A-Za-z0-9-]+\.(jpg|png)$/.test(existingFileName)){
      const file=path.join(dir,existingFileName);
      if(fs.existsSync(file)){
        if(fs.lstatSync(file).isSymbolicLink()||!fs.readFileSync(file).equals(image.bytes))throw fail('기존 비교 사진과 복구 사진이 다릅니다.');
        return {folder:dir,folderKey:path.basename(dir),fileName:existingFileName,rollback:()=>{}};
      }
      return durableWrite(dir,existingFileName,image.bytes);
    }
    return durableWrite(dir,`Before-After_${Date.now()}_${crypto.randomUUID().slice(0,8)}.${image.extension}`,image.bytes);
  }
  async function open(order,kind){
    const dir=folder(order,kind),error=await openPath(dir);
    if(error)throw fail(`파일 탐색기 열기 실패: ${error}`);
    return {opened:true,folder:dir,kind};
  }
  return {photo,comparison,open};
}
module.exports={createPhotoArchive,imageBytes};
