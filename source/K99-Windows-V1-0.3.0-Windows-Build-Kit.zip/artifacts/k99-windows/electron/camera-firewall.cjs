'use strict';
const path=require('node:path'),fs=require('node:fs/promises'),{execFile}=require('node:child_process');
const {iriunExecutablePaths}=require('./smartphone-camera.cjs');
/** Never disable Windows Firewall, request elevation, open public profiles,
 * expose arbitrary ports or register a caller-supplied executable. */
function createCameraFirewall({platform=process.platform,env=process.env,appExecutable=process.execPath,
  stat=fs.stat,now=Date.now,execute=(file,args)=>new Promise((resolve,reject)=>{
    execFile(file,args,{windowsHide:true,timeout:2500,maxBuffer:65536,shell:false},
      (error,stdout)=>error?reject(error):resolve(stdout));
  })}={}){
  let pending,result,retryAfter=0;
  const valid=file=>typeof file==='string'&&/^[a-z]:\\/i.test(file)&&/\.exe$/i.test(file)&&!/[\"\r\n\0]/.test(file);
  async function apply(){
    if(platform!=='win32')return {applied:false,skipped:true};
    const programs=[];
    if(valid(appExecutable))try{if((await stat(appExecutable)).isFile())programs.push(['K99',appExecutable]);}catch{}
    for(const file of iriunExecutablePaths(env)){
      try{if(valid(file)&&(await stat(file)).isFile()){programs.push(['Iriun',file]);break;}}catch{}
    }
    if(!programs.length)return {applied:false,skipped:true};
    const netsh=path.win32.join(env.SystemRoot||env.WINDIR||'C:\\Windows','System32','netsh.exe');
    let rules=0;
    try{
      for(const [name,file] of programs)for(const direction of ['in','out']){
        const base=['advfirewall','firewall'],rule=`name=K99 Camera ${name} ${direction}`;
        const settings=[`dir=${direction}`,'action=allow',`program=${file}`,'enable=yes','profile=private','remoteip=localsubnet','protocol=any'];
        try{
          // Stable names make upgrades idempotent. Never delete another rule.
          await execute(netsh,[...base,'show','rule',rule]);
        }catch{
          await execute(netsh,[...base,'add','rule',rule,...settings]);rules++;continue;
        }
        await execute(netsh,[...base,'set','rule',rule,`dir=${direction}`,'new',...settings.filter(x=>!x.startsWith('dir='))]);rules++;
      }
      return {applied:true,rules,profile:'private',scope:'localsubnet'};
    }catch{
      return {applied:false,rules,warning:'방화벽 자동 허용 권한이 없습니다. 무선 연결이 안 되면 매장 관리자에게 개인 네트워크에서 Iriun과 K99 통신 허용을 요청해 주세요. 접수 업무는 계속 사용할 수 있습니다.'};
    }
  }
  function ensure(){
    if(result&&now()<retryAfter)return Promise.resolve(result);
    if(!pending)pending=apply().catch(()=>({applied:false,warning:'방화벽 설정은 Windows 관리자에게 확인해 주세요.'}))
      .then(value=>{result=value;retryAfter=now()+(value.applied?300000:60000);return value;})
      .finally(()=>{pending=null;});
    return pending;
  }
  return {ensure};
}
module.exports={createCameraFirewall};
