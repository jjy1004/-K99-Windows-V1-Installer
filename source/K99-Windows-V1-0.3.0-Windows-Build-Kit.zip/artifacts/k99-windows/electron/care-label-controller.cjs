'use strict';
const {classifyCareLabel}=require('./services/labelService.cjs');
const KEY='k99-care-label-analysis-v1', PRINTS='k99-care-label-print-intents-v1', ACTIVE='k99-active-staff-intake-v1';
const safeId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(value);
function createCareLabelController({store,equipmentApi,changed=()=>{},onResult=async()=>{},classify=classifyCareLabel,native=process.platform==='win32'}){
  const pending=new Map();
  let queue=Promise.resolve(),disposed=false,generation=0;
  function read(){return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}
  function save(value){
    const expected=store.storage({op:'get',key:KEY});
    store.storage({op:'set',key:KEY,expected,value:JSON.stringify(value)});
  }
  function put(record){const all=read();all[record.photoId]=record;save(all);try{changed();}catch{}return record;}
  function latestFor(orderId,garmentId){
    return Object.values(read()).filter(r=>r.orderId===orderId&&r.garmentId===garmentId)
      .sort((a,b)=>b.sequence-a.sequence||b.createdAt.localeCompare(a.createdAt))[0];
  }
  function inspect(photoId){
    if(!safeId(photoId))throw Error('케어라벨 사진 식별자 오류');
    // Only canonical mobile photos already linked to a garment can be analysed; never arbitrary paths.
    const active=JSON.parse(store.storage({op:'get',key:ACTIVE})||'null');
    const draft=active?.draftId&&store.equipment.drafts.state(active.draftId);
    for(const u of draft?.units||[]){
      const photo=u.garment.photoHistory?.find(p=>p.sourcePhotoId===photoId);
      if(photo&&/^MOBILE_/.test(photo.archiveFile||''))return {orderId:active.draftId,unitKey:u.unitKey,
        garmentId:u.garment.garmentId,itemName:u.garment.itemName,photoId,sequence:u.garment.photoHistory.indexOf(photo)};
    }
    const existing=read()[photoId];
    if(existing){
      const order=store.equipment.getOrder(existing.orderId);
      if(order.deletedAt||order.status==='cancelled')throw Error('삭제·취소 주문은 분석하지 않습니다.');
      const garment=order.garments?.find(g=>g.garmentId===existing.garmentId);
      if(garment?.photoHistory?.some(p=>p.sourcePhotoId===photoId))return existing;
    }
    throw Error('현재 의류에 저장된 휴대폰 사진만 분석할 수 있습니다.');
  }
  function analyze(photoId){
    if(disposed) return Promise.reject(Error('분석 서비스가 종료되었습니다.'));
    if(!native||store.equipment.getConfig().mode!=='real')return Promise.reject(Error('실제 Windows 사진만 분석합니다.'));
    if(pending.has(photoId))return pending.get(photoId);
    const target=inspect(photoId),prior=read()[photoId];
    if(prior?.status==='success')return Promise.resolve(prior);
    const record={...target,id:photoId,createdAt:new Date().toISOString(),status:'pending',materialTag:'',basket:null,error:''};
    if(pending.size>=20){
      const failed=put({...record,status:'failed',error:'분석 대기량 초과 · 소재: 일반. 나중에 다시 분석해 주세요.'});
      return Promise.resolve(onResult(failed)).then(()=>failed);
    }
    put(record);
    const runGeneration=generation;
    const work=queue.then(async()=>{
      if(disposed||runGeneration!==generation)return record;
      let result;
      try{
        const bytes=store.equipment.photoFile(photoId);
        result=await classify(bytes.bytes,{mimeType:bytes.contentType});
      }
      catch(error){result={status:'failed',materialTag:'',basket:null,error:error.code==='KEY_MISSING'
        ?'Windows GEMINI_API_KEY 미설정 · 소재: 일반'
        :'AI 분석에 실패했습니다. 소재: 일반으로 접수와 출력을 계속할 수 있습니다.'};}
      if(disposed||runGeneration!==generation)return record;
      const completed=put({...record,...result,completedAt:new Date().toISOString()});
      await onResult(completed);
      return completed;
    });
    pending.set(photoId,work);
    queue=work.catch(()=>{});
    void work.finally(()=>pending.delete(photoId)).catch(()=>{});
    return work;
  }
  function onMobileSaved(input,result){
    // Runs after the original image/SQLite/tag transaction. AI errors cannot roll it back.
    const id=result.photo?.id;
    if(id)void analyze(id).catch(()=>{});
  }
  function materialForJob(job){
    const orderId=job.orderId||job.payload?.orderId, garmentId=job.garmentId||job.payload?.garmentId;
    const intent=JSON.parse(store.storage({op:'get',key:PRINTS})||'{}')[job.requestId];
    if(intent?.orderId===orderId&&intent.garmentId===garmentId)return intent.materialTag;
    const r=latestFor(orderId,garmentId);
    return r?.status==='success'?r.materialTag:'';
  }
  function list(){
    return Object.values(read()).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,30).map(r=>{
      let canPrint=false;
      try{const o=store.equipment.getOrder(r.orderId);canPrint=!o.deletedAt&&o.garments?.some(g=>g.garmentId===r.garmentId)===true;}catch{}
      return {...r,status:r.status==='pending'&&!pending.has(r.photoId)?'interrupted':r.status,canPrint};
    });
  }
  function enrichDraft(value){
    if(!Array.isArray(value?.units))return value;
    return {...value,units:value.units.map(u=>{
      const r=latestFor(u.garment.orderId,u.garment.garmentId);
      return r?{...u,garment:{...u.garment,materialTag:r.status==='success'?r.materialTag:''}}:u;
    })};
  }
  async function print(photoId,requestId){
    const r=read()[photoId];
    if(!r||(r.status==='pending'&&pending.has(photoId))||!safeId(requestId))throw Error('분석 결과와 출력 요청을 확인하세요.');
    const entry=list().find(e=>e.photoId===photoId);
    if(!entry?.canPrint)throw Error('접수를 먼저 확정한 뒤 소재 태그를 출력해 주세요.');
    const expected=store.storage({op:'get',key:PRINTS}),intents=JSON.parse(expected||'{}');
    if(intents[requestId]&&intents[requestId].photoId!==photoId)throw Error('출력 요청 식별자가 다른 사진에 사용되었습니다.');
    if(!intents[requestId]){
      intents[requestId]={photoId,orderId:r.orderId,garmentId:r.garmentId,materialTag:r.status==='success'?r.materialTag:'',
        requestedAt:new Date().toISOString()};
      store.storage({op:'set',key:PRINTS,expected,value:JSON.stringify(intents)});
    }
    return equipmentApi.api('POST','/api/equipment/command',{action:'reprint',orderId:r.orderId,garmentId:r.garmentId,
      requestId,reason:'직원 요청: 케어라벨 분석 후 소재 반영 태그 출력'});
  }
  return {analyze,onMobileSaved,materialForJob,list,enrichDraft,print,
    latestForUnit:(orderId,unitKey)=>Object.values(read()).filter(r=>r.orderId===orderId&&r.unitKey===unitKey)
      .sort((a,b)=>b.sequence-a.sequence||b.createdAt.localeCompare(a.createdAt))[0],
    hasPendingFor:(orderId,unitKey)=>Object.values(read()).some(r=>r.orderId===orderId&&r.unitKey===unitKey&&pending.has(r.photoId)),
    settleForOrder:orderId=>Promise.all([...pending].filter(([id])=>read()[id]?.orderId===orderId).map(([,work])=>work)),
    reset(){generation++;pending.clear();},close(){disposed=true;generation++;}};
}
module.exports={createCareLabelController,KEY};
