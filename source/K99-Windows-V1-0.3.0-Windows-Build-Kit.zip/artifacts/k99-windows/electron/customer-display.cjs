'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const VIDEO_KEYS=new Set(['value','process','water','sneakers','idle']);
function createCustomerDisplay({BrowserWindow,screen,getMain,preload,changed,preferencesFile,onComparisonClosed=()=>{}}) {
  let customer=null,ready=false,snapshot=null,presentation='order',active=null;
  let preference={displayId:null,enabled:true},note='고객 창 닫힘';
  let comparison=null;
  if(preferencesFile&&fs.existsSync(preferencesFile)){
    try {const p=JSON.parse(fs.readFileSync(preferencesFile,'utf8'));
      if(typeof p.displayId==='string')preference.displayId=p.displayId;
      preference.enabled=p.enabled!==false;
    }catch{note='고객 모니터 설정 파일을 읽지 못했습니다. 모니터를 다시 선택하세요.';}
  }
  const monitors=()=>screen.getAllDisplays().map(d=>({id:String(d.id),label:d.label||`모니터 ${d.id}`,
    primary:d.id===screen.getPrimaryDisplay().id,bounds:d.bounds||d.workArea}));
  const isCustomer=wc=>!!customer&&!customer.isDestroyed()&&customer.webContents===wc;
  const status=()=>({connected:!!customer&&!customer.isDestroyed()&&ready,
    open:!!customer&&!customer.isDestroyed(),displayId:preference.displayId||undefined,note,monitors:monitors()});
  const send=(channel,data)=>{const main=getMain();if(main&&!main.isDestroyed?.())main.webContents.send(channel,data);};
  const announce=()=>{send('customer-connection',{type:'CONNECTION',...status()});changed();};
  const persist=()=>{
    if(!preferencesFile)return;
    fs.mkdirSync(path.dirname(preferencesFile),{recursive:true});
    fs.writeFileSync(preferencesFile+'.tmp',JSON.stringify(preference));
    fs.renameSync(preferencesFile+'.tmp',preferencesFile);
  };
  function clearComparison(reason='closed'){
    const old=comparison;comparison=null;
    if(!old)return;
    if(ready&&isCustomer(customer?.webContents))customer.webContents.send('customer-update',{type:'comparison-close',sessionId:old.id});
    send('customer-connection',{type:'COMPARISON_CLOSED',sessionId:old.id,reason});
    onComparisonClosed(old.id);
  }
  function publishComparison(){
    if(!comparison||!ready||!isCustomer(customer?.webContents))return;
    customer.webContents.send('customer-update',{type:'comparison',gallery:comparison});
    send('customer-connection',{type:'COMPARISON_UPDATE',gallery:comparison});
  }
  async function showComparison(gallery){
    if(!gallery||typeof gallery.id!=='string'||!Array.isArray(gallery.photos)||!gallery.photos.length||
      gallery.photos.length>1000||gallery.photos.some(p=>!/^k99:\/\/app\/comparison-photos\/[a-f0-9-]{36}$/.test(p.url)))
      throw Error('잘못된 전후 비교 사진 명령');
    const external=screen.getAllDisplays().filter(d=>d.id!==screen.getPrimaryDisplay().id);
    if(!external.length){clearComparison('single-monitor');releaseVideo();return {shown:false,note:'보조 모니터가 없어 직원 화면에 표시합니다.'};}
    const target=external.find(d=>String(d.id)===preference.displayId)||external[0];
    if(!ready||!isCustomer(customer?.webContents)||preference.displayId!==String(target.id))await openCustomer(String(target.id));
    const until=Date.now()+2500;
    while(!ready&&customer&&!customer.isDestroyed()&&Date.now()<until)await new Promise(resolve=>setTimeout(resolve,25));
    if(!ready||!isCustomer(customer?.webContents))return {shown:false,note:'고객 화면 준비를 확인하지 못해 직원 화면에 표시합니다.'};
    clearComparison('replaced');releaseVideo();
    try{foregroundVideo();}catch(error){releaseVideo();throw error;}
    comparison={...gallery,index:0};publishComparison();
    return {shown:true,gallery:comparison};
  }
  function controlComparison(id,direction){
    if(!comparison||comparison.id!==id)return null;
    if(direction==='close'){
      clearComparison();releaseVideo();
      action({type:'video',command:{id:crypto.randomUUID(),video:'idle',issuedAt:Date.now()}});
      return {closed:true};
    }
    if(!['next','previous'].includes(direction))throw Error('지원하지 않는 비교 사진 이동');
    comparison={...comparison,index:(comparison.index+(direction==='next'?1:-1)+comparison.photos.length)%comparison.photos.length};
    publishComparison();return {gallery:comparison};
  }
  // Never leave the receipt above other applications after playback or failure.
  function releaseVideo(win=customer) {
    if(win&&!win.isDestroyed())win.setAlwaysOnTop(false);
    active=null;
  }
  function foregroundVideo() {
    if(customer.isMinimized())customer.restore();
    customer.show();
    customer.setAlwaysOnTop(true,'screen-saver');
    customer.setFullScreen(true);
    customer.focus();
  }
  function closeCustomer(persistChoice=true) {
    if(persistChoice){preference.enabled=false;persist();}
    clearComparison('window-closed');releaseVideo();
    const old=customer;customer=null;ready=false;active=null;
    old?.close();note='고객 창 닫힘';announce();
  }
  async function openCustomer(id) {
    const display=screen.getAllDisplays().find(d=>String(d.id)===String(id));
    if(!display)throw Error('현재 연결된 고객 모니터를 선택하세요.');
    preference={displayId:String(display.id),enabled:true};persist();
    const bounds=display.bounds||display.workArea;
    if(customer&&!customer.isDestroyed()){
      customer.setFullScreen?.(false);customer.setBounds(bounds);customer.setFullScreen?.(true);
      customer.show();announce();return;
    }
    const win=new BrowserWindow({...bounds,fullscreen:true,show:false,title:'K99 고객 안내',
      autoHideMenuBar:true,backgroundColor:'#eeeae3',
      webPreferences:{preload,sandbox:true,contextIsolation:true,nodeIntegration:false,
        webSecurity:true,webviewTag:false,autoplayPolicy:'no-user-gesture-required'}});
    customer=win;ready=false;active=null;note='고객 화면 준비 확인 중';
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,url)=>{if(url!=='k99://app/customer')event.preventDefault();});
    win.webContents.on('did-start-loading',()=>{if(customer===win){clearComparison('reload');releaseVideo(win);ready=false;announce();}});
    win.webContents.on('render-process-gone',()=>{if(customer===win){clearComparison('renderer-gone');releaseVideo(win);ready=false;note='고객 화면 프로세스 응답 없음 · 재연결 필요';announce();}});
    win.on('close',()=>{if(customer===win)releaseVideo(win);});
    win.on('closed',()=>{if(customer===win){clearComparison('window-closed');customer=null;ready=false;active=null;note='고객 창 닫힘';announce();}});
    await win.loadURL('k99://app/customer');
    if(customer===win&&!win.isDestroyed()){win.show();announce();}
  }
  async function restore() {
    if(!preference.enabled)return;
    const list=monitors();
    const selected=list.find(d=>d.label.toUpperCase().includes('LG FULL HD'))||
      (preference.displayId?list.find(d=>d.id===preference.displayId):list.find(d=>!d.primary));
    if(selected)await openCustomer(selected.id);
    else if(preference.displayId){note='저장된 고객 모니터가 없습니다. 연결 후 다시 선택하세요.';announce();}
  }
  screen.on('display-removed',(_e,display)=>{
    if(String(display.id)!==preference.displayId)return;
    closeCustomer(false);note='고객 모니터 연결 해제 · 저장된 선택 유지';announce();
  });
  screen.on('display-added',()=>{void restore().catch(error=>{note=error.message;announce();});});
  screen.on('display-metrics-changed',(_e,display)=>{
    if(String(display.id)===preference.displayId&&customer&&!customer.isDestroyed()){
      customer.setFullScreen?.(false);customer.setBounds(display.bounds||display.workArea);customer.setFullScreen?.(true);
    }announce();
  });
  function action(input) {
    if(!input||typeof input!=='object'||JSON.stringify(input).length>512000)throw Error('잘못된 고객 화면 명령');
    if(input.type==='snapshot'){
      if(!input.payload||typeof input.payload.sourceId!=='string'||!Array.isArray(input.payload.rows))throw Error('잘못된 고객 화면 표시 정보');
      if(snapshot?.sourceId!==input.payload.sourceId){if(!comparison)releaseVideo();presentation='order';}
      snapshot=input.payload;
      if(ready&&isCustomer(customer?.webContents))customer.webContents.send('customer-update',{type:'snapshot',payload:snapshot,screen:presentation});
    }else if(input.type==='SWITCH_TO_RECEIPT'){
      const r=input.request;
      if(!r||typeof r.id!=='string'||!r.id||r.id.length>=200||
          !Number.isFinite(r.issuedAt)||Date.now()-r.issuedAt>4500||r.issuedAt>Date.now()+5000)
        throw Error('잘못되거나 만료된 접수 화면 전환 명령');
      // Not replayed on READY/reload. Do not replace an active guide command.
      clearComparison('new-intake');
      if(ready&&isCustomer(customer?.webContents))
        customer.webContents.send('customer-update',{type:'SWITCH_TO_RECEIPT',request:r});
    }else if(input.type==='screen'&&['order','common','sneaker'].includes(input.screen)){
      clearComparison('screen');
      releaseVideo();
      presentation=input.screen;
      if(ready)customer.webContents.send('customer-update',{type:'screen',screen:presentation});
    }else if(input.type==='video'){
      const c=input.command;
      if(!c||typeof c.id!=='string'||!c.id||c.id.length>200||!VIDEO_KEYS.has(c.video)||
          !Number.isFinite(c.issuedAt)||Date.now()-c.issuedAt>4500||c.issuedAt>Date.now()+5000)throw Error('잘못되거나 만료된 영상 명령');
      if(!ready||!isCustomer(customer?.webContents)){
        send('customer-connection',{type:'COMMAND_ERROR',commandId:c.id,error:'고객 화면이 아직 준비되지 않았습니다.'});return;
      }
      clearComparison('video');
      try{
        foregroundVideo();
        if(c.video==='idle')releaseVideo();
        active=c.id;customer.webContents.send('customer-update',{type:'video',command:c});
      }catch(error){releaseVideo();throw error;}
    }else throw Error('지원하지 않는 고객 화면 명령');
  }
  function customerEvent(wc,input) {
    if(!isCustomer(wc)||!input||JSON.stringify(input).length>16000)return;
    if(input.type==='COMPARISON_CONTROL'&&comparison?.id===input.sessionId){
      if(['next','previous','close'].includes(input.direction))controlComparison(input.sessionId,input.direction);
    }else if(input.type==='COMPARISON_ACK'&&comparison?.id===input.sessionId&&
      comparison.photos[comparison.index]?.id===input.photoId){
      send('customer-connection',{type:'COMPARISON_STATUS',sessionId:comparison.id,index:comparison.index,
        loaded:input.loaded===true,error:input.loaded===true?undefined:'전후 비교 사진을 표시하지 못했습니다.'});
    }else if(input.type==='CUSTOMER_READY'){
      ready=true;note='고객 화면 연결됨';
      if(snapshot)customer.webContents.send('customer-update',{type:'snapshot',payload:snapshot,screen:presentation});
      announce();
    }else if(input.commandId===active&&(input.type==='ACK'||input.type==='STATUS')){
      send('customer-connection',input);
      if(input.type==='STATUS'&&(input.error||input.diagnostic?.event==='ended'))releaseVideo();
    }else if(input.type==='CONFIRM'&&['common','sneaker'].includes(input.screen)){
      send('customer-connection',{type:'CONFIRM',screen:input.screen});
    }
  }
  return {monitors,openCustomer,closeCustomer,displayStatus:status,isCustomer,restore,action,customerEvent,showComparison,controlComparison,
    notify:()=>{if(isCustomer(customer?.webContents))customer.webContents.send('k99:changed');}};
}
module.exports={createCustomerDisplay};
