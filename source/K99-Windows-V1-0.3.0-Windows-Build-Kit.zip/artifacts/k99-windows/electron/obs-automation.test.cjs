'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../../..');
test('startup, IPC and settings do not load or depend on OBS',()=>{
  for(const name of ['artifacts/k99-windows/electron/main.cjs','artifacts/k99-windows/electron/preload.cjs',
    'artifacts/k99-windows/src/desktop-runtime.ts','artifacts/k99-windows/src/MaintenanceWorkspace.tsx',
    'scripts/stage-windows-app.cjs','scripts/verify-windows-portable.cjs']){
    assert.doesNotMatch(fs.readFileSync(path.join(root,name),'utf8'),/obsAutomation|obs-automation|ObsAutomationSettings|--startvirtualcam/);
  }
  assert.equal(fs.existsSync(path.join(__dirname,'obs-automation.cjs')),false);
  assert.equal(fs.existsSync(path.join(root,'artifacts/k99-windows/src/ObsAutomationSettings.tsx')),false);
});
test('camera automation is not hidden behind the manual controls',()=>{
  for(const name of ['camera-color.ts','use-camera-color-preview.ts','manual-camera-resolution.ts',
    'use-manual-camera.ts','NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    assert.doesNotMatch(fs.readFileSync(path.join(root,'artifacts/k99-windows/src',name),'utf8'),
      /\.applyConstraints\s*\(|automaticWhiteProfile|calibrateWhiteFrame|calibrateClassic24|whiteBalanceMode|exposureMode|--startvirtualcam/);
  }
});
