'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createObsAutomation,ARGS}=require('./obs-automation.cjs');
function fixture({installed=true,running=false,timeout=false,writeAllowed=true}={}){
  const files=new Map(),links=new Map();let spawned=0,checked=0;
  const absent=()=>Object.assign(Error('missing'),{code:'ENOENT'});
  const io={
    readFile:async p=>{if(!files.has(p))throw absent();return files.get(p);},
    writeFile:async(p,v)=>files.set(p,v),rename:async(a,b)=>{files.set(b,files.get(a));files.delete(a);},
    mkdir:async()=>{},unlink:async p=>{links.delete(p);},
    stat:async p=>{if(installed&&p==='C:\\Program Files\\obs-studio\\bin\\64bit\\obs64.exe')return {isFile:()=>true};throw absent();},
  };
  const app={getPath:key=>key==='userData'?'/user-k99':'/app-data'};
  const shell={writeShortcutLink:(p,op,options)=>{if(!writeAllowed)return false;links.set(p,options);return true;},
    readShortcutLink:p=>{if(!links.has(p))throw absent();return links.get(p);}};
  const service=createObsAutomation({app,shell,io,platform:'win32',env:{ProgramFiles:'C:\\Program Files'},timeoutMs:20,
    execFile:(command,args,opts,done)=>{
      checked++;assert.equal(command,'tasklist.exe');assert.equal(opts.windowsHide,true);
      if(!timeout)setImmediate(()=>done(null,running?'"obs64.exe","123","Console","1","100 K"':'INFO: no tasks'));
      return {kill(){}};
    },
    spawn:(exe,args,options)=>{
      spawned++;assert.deepEqual(args,ARGS);assert.equal(options.cwd,'C:\\Program Files\\obs-studio\\bin\\64bit');
      assert.equal(options.stdio,'ignore');const child=new EventEmitter();child.unref=()=>{};
      setImmediate(()=>child.emit('spawn'));return child;
    }});
  return {service,files,links,get spawned(){return spawned;},get checked(){return checked;}};
}
test('optional legacy enable registers only the K99 OBS shortcut without shell',async()=>{
  const f=fixture(),r=await f.service.ensure('enable');
  assert.equal(r.success,true);assert.equal(r.launchRequested,true);assert.equal(f.spawned,1);
  const [file,link]=[...f.links][0];
  assert.match(file,/Startup.*OBS Studio - K99 자동 실행\.lnk/);
  assert.equal(link.args,'--startvirtualcam --minimize-to-tray');
});
test('already running OBS is not duplicated and existing scene is not edited',async()=>{
  const f=fixture({running:true}),r=await f.service.ensure('enable');
  assert.equal(f.spawned,0);assert.equal(r.running,true);
});
test('unknown or delayed process status never blocks startup or spawns a duplicate',async()=>{
  const f=fixture({timeout:true}),r=await f.service.ensure('enable');
  assert.equal(r.running,null);assert.equal(f.spawned,0);
});
test('missing OBS and shortcut write denial are reported without running anything',async()=>{
  for(const options of [{installed:false},{writeAllowed:false}]){
    const f=fixture(options),r=await f.service.ensure('enable');
    assert.equal(f.spawned,0);assert.equal(r.shortcutReady,false);
  }
});
test('concurrent repair requests coalesce and an OFF request is preserved after pending startup work',async()=>{
  const f=fixture({running:true});
  await Promise.all([f.service.ensure('enable'),f.service.ensure(),f.service.ensure('disable')]);
  assert.equal(f.checked,1);assert.equal((await f.service.ensure('status')).enabled,false);
  assert.equal(f.links.size,0);
  await f.service.ensure();assert.equal(f.checked,1);
  await f.service.ensure('enable');assert.equal(f.links.size,1);
});
test('direct USB defaults never launch OBS and disable removes only K99 owned startup entry',async()=>{
  const f=fixture();await f.service.ensure();assert.equal(f.spawned,0);assert.equal(f.checked,0);
  f.links.set('/someone-else/OBS.lnk',{target:'obs64.exe'});
  await f.service.ensure('enable');assert.equal(f.spawned,1);
  await f.service.ensure('disable');assert.equal(f.links.size,1);
  assert.ok(f.links.has('/someone-else/OBS.lnk'));
  const fs=require('node:fs'),path=require('node:path');
  const main=fs.readFileSync(path.join(__dirname,'main.cjs'),'utf8');
  assert.match(main,/obsAutomation\.ensure\('disable'\)/);
  assert.doesNotMatch(main,/obsAutomation\.ensure\(\)/);
  const nsis=fs.readFileSync(path.join(__dirname,'../installer/data-preservation.nsh'),'utf8');
  assert.doesNotMatch(nsis,/--startvirtualcam|obs64\.exe/);
});
