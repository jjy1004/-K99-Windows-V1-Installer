'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY}=require('./hardware-settings.cjs');
const {PROFILES,identify,deviceProfile,serialPorts,PORT_SCRIPT}=require('./services/receipt-devices.cjs');
const {escPosReceipt,receiptText,encodeText}=require('./receipt-serial.cjs');
const receipt={customerName:'가상 고객',customerPhone:'01000000000',paymentType:'POSTPAID',
  items:[{name:'길게 적은 가상 의류 품목 '.repeat(8),quantity:1,amount:20000}]};
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-receipt-priority-')),filename=path.join(root,'test.sqlite');
  let store=createStore(filename,'test',{nativeDesktop:true});
  const state={printers:[],ports:[],prints:[],html:[],height:240000,serial:[],failMeasure:false};
  const adapters={printers:async()=>state.printers,ports:async()=>state.ports,
    serialReceipt:async input=>{state.serial.push(escPosReceipt(input));return {message:'모사 완료'};}};
  class FakeWindow{
    constructor(){this.webContents={
      executeJavaScript:async script=>{assert.match(script,/scrollHeight/);if(state.failMeasure)throw Error('가상 측정 실패');return state.height;},
      print:(options,done)=>{state.prints.push(options);done(true);},
    };}
    async loadURL(url){state.html.push(decodeURIComponent(url.slice(url.indexOf(',')+1)));}
    isDestroyed(){return false;}destroy(){}
  }
  const api=()=>createHardwareSettings({store,adapters,BrowserWindow:FakeWindow,native:true});
  t.after(()=>{store.close();fs.rmSync(root,{recursive:true,force:true});});
  return {state,api,adapters,get store(){return store;},reopen(){store.close();store=createStore(filename,'test',{nativeDesktop:true});}};
}
for(const [vendor,label] of [['easycheck','KICC TS-167'],['kis','KIS정보통신 58mm'],['nice','NICE 스마트로 3인치']]){
  test(`${vendor}: 미연결 회사 선택은 기본값을 채우되 저장값·결제는 건드리지 않는다`,async t=>{
    const f=fixture(t),api=f.api();
    const result=await api({action:'select-receipt-vendor',vendor});
    assert.equal(result.config.receiptVendor,vendor);
    assert.equal(result.config.receiptBaudRate,9600);
    assert.equal(result.config.receiptEncoding,'euc-kr');
    assert.equal(result.config.receiptTransport,'windows');
    assert.equal(result.config.receiptEscPosVerified,false);
    assert.equal(result.selection.state,'missing');
    assert.equal(f.store.storage({op:'get',key:KEY}),null);
    await api({action:'save-receipt',config:{...result.config,receiptPort:'COM9',receiptWidth:58,
      receiptBaudRate:38400,receiptEncoding:'cp949',receiptPromo:'직접 저장한 문구'}});
    f.reopen();
    f.state.printers=[{name:label,port:'COM4'}];
    f.state.ports=[{name:'COM4',manufacturer:label}];
    const previous=f.store.storage({op:'get',key:KEY});
    const c=(await f.api()({action:'status'})).config;
    for(const action of ['select-receipt-vendor','status','receipt-preferences']){
      const next=await f.api()({action,vendor});
      for(const key of Object.keys(PROFILES[vendor]).filter(k=>k!=='receiptEscPosVerified'))
        assert.equal(next.config[key],c[key],key);
      for(const key of ['receiptPort','receiptPromo','receiptPrinterName'])assert.equal(next.config[key],c[key]);
    }
    assert.equal(f.store.storage({op:'get',key:KEY}),previous,'같은 회사 재선택도 저장값을 바꾸지 않는다');
    assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  });
  test(`${vendor}: 최초 장치·드라이버 정보에서 회사·COM·용지 폭을 설정하고 재탐지로 덮어쓰지 않는다`,async t=>{
    const f=fixture(t);
    f.state.printers=[{name:label,port:'COM4'}];
    f.state.ports=[{name:'COM4',manufacturer:label,driverName:'가상 드라이버'}];
    const initial=await f.api()({action:'status'});
    assert.equal(initial.config.receiptVendor,vendor);
    assert.equal(initial.config.receiptPort,'COM4');
    assert.equal(initial.config.receiptWidth,vendor==='kis'?58:80);
    assert.equal(initial.config.receiptBaudRate,9600);
    assert.equal(initial.config.receiptTransport,'windows','시리얼 지원을 추정하지 않는다');
    assert.equal(initial.terminal.connected,false);
    f.state.printers=[{name:label+' 교체',port:'COM8'}];f.state.ports=[];
    f.reopen();
    assert.deepEqual((await f.api()({action:'status'})).config,initial.config);
  });
}
test('일반 COM·복수 회사·중복 후보·권한 오류는 자동 설정하지 않는다',async t=>{
  const f=fixture(t);
  for(const [printers,ports] of [
    [[],[{name:'COM3',manufacturer:'USB Serial'}]],
    [[{name:'KIS 하나'},{name:'KIS 둘'}],[]],
    [[{name:'KIS'},{name:'NICE'}],[]],
    [[],[{name:'COM3',manufacturer:'NICE'},{name:'COM4',manufacturer:'NICE'}]],
  ]){
    f.state.printers=printers;f.state.ports=ports;
    await f.api()({action:'status'});
    assert.equal(f.store.storage({op:'get',key:KEY}),null);
  }
  f.adapters.printers=async()=>{throw Error('권한 거부');};
  f.adapters.ports=async()=>{throw Error('권한 거부');};
  const result=await f.api()({action:'status'});
  assert.match(result.printerMessage,/확인하지 못/);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
  assert.equal(identify({name:'NICE KIS'}),'','회사 식별 충돌은 제외');
});
test('COM 정보만 식별된 장치는 포트만 설정하고 직접 출력 지원은 승인하지 않는다',async t=>{
  const f=fixture(t);
  f.state.ports=[{name:'COM7',description:'KICC TS-167'}];
  const result=await f.api()({action:'status'});
  assert.equal(result.config.receiptPort,'COM7');assert.equal(result.config.receiptWidth,80);
  assert.equal(result.config.receiptEscPosVerified,false);assert.equal(result.selection.state,'missing');
  await assert.rejects(f.api()({action:'receipt-print',receipt}),/연결된 접수증/);
});
test('기존 구형 설정과 명시적 미사용은 자동 감지로 초기화하지 않는다',async t=>{
  const f=fixture(t);f.state.printers=[{name:'KICC TS-167'}];
  for(const old of [{receiptType:'none'},{receiptPort:'COM9',receiptBaudRate:19200,receiptEncoding:'cp949'}]){
    f.store.storage({op:'set',key:KEY,value:JSON.stringify(old),expected:f.store.storage({op:'get',key:KEY})});
    f.reopen();
    await f.api()({action:'status'});
    assert.equal(f.store.storage({op:'get',key:KEY}),JSON.stringify(old));
  }
});
test('테스트와 접수 인쇄는 미저장 전달값을 무시하고 동일한 저장 장치·폭·홍보·본문 여백을 쓴다',async t=>{
  const f=fixture(t);f.state.printers=[{name:'저장 프린터'},{name:'미저장 프린터'}];
  for(const width of [58,80]){
    const api=f.api();
    await api({action:'save-receipt',config:{receiptType:'windows',receiptPrinterName:'저장 프린터',
      receiptWidth:width,receiptPromo:'저장된 안내 첫 줄\n마지막 안내 둘째 줄'}});
    const config={receiptPrinterName:'미저장 프린터',receiptWidth:width===58?80:58,receiptPromo:'미저장'};
    for(const action of ['test','receipt-print'])await api({action,kind:'receipt',receipt,config,printerName:'미저장 프린터'});
    const prints=f.state.prints.slice(-2);
    assert.deepEqual(prints[0],prints[1]);
    assert.equal(prints[0].deviceName,'저장 프린터');
    assert.equal(prints[0].pageSize.width,width*1000);
    assert.equal(prints[0].pageSize.height,245000,'실제 줄바꿈 높이 측정 후 종료 여유');
    for(const html of f.state.html.slice(-2)){
      assert.match(html,/padding:10mm;/);assert.match(html,new RegExp(`width:${width}mm;margin:0;`));
      assert.match(html,/white-space:normal;overflow-wrap:anywhere/);assert.match(html,/마지막 안내 둘째 줄/);
      assert.doesNotMatch(html,/미저장/);assert.match(html,/길게 적은 가상 의류/);
    }
    f.state.height=2100000;
    await assert.rejects(api({action:'receipt-print',receipt}),/잘라서 출력하지 않습니다/);
    f.state.height=240000;f.state.failMeasure=true;
    await assert.rejects(api({action:'receipt-print',receipt}),/측정 실패/);
    f.state.failMeasure=false;
  }
});
test('시리얼도 같은 저장 설정 사용·상단 약10mm·끝 피드 및 긴 홍보 자동 줄바꿈을 보존한다',async t=>{
  const f=fixture(t),api=f.api();f.state.ports=[{name:'COM3'}];
  for(const width of [58,80]){
    const config={receiptType:'easycheck',receiptVendor:'easycheck',receiptWidth:width,receiptTransport:'serial',
      receiptPort:'COM3',receiptBaudRate:9600,receiptEncoding:'euc-kr',receiptEscPosVerified:true,
      receiptCut:true,receiptPromo:'소중한 옷을 정성껏 관리해 드립니다'};
    await api({action:'save-receipt',config});
    for(const action of ['test','receipt-print'])await api({action,kind:'receipt',receipt,config:{receiptPort:'COM9',receiptBaudRate:115200}});
    const packets=f.state.serial.slice(-2);
    assert.deepEqual(packets[0],packets[1]);
    assert.equal(packets[0].preferences.receiptPort,'COM3');
    assert.deepEqual([...packets[0].data.subarray(0,13)],[27,64,28,38,27,77,0,28,33,0,27,97,0]);
    assert.deepEqual([...packets[0].data.subarray(13,21)],[29,76,80,0,29,87,width===58?224:160,width===58?0:1]);
    assert.deepEqual([...packets[0].data.subarray(21,27)],[27,51,30,27,74,80]);
    assert.deepEqual([...packets[0].data.subarray(-3)],[27,100,4]);
    const text=receiptText({receipt,preferences:config});
    assert(text.replace(/\n/g,'').includes(config.receiptPromo));
    for(const row of text.split('\n'))assert(encodeText(row,'euc-kr').length<=(width===58?18:34));
  }
});
test('Windows 장치 열거는 드라이버·제조사 정보를 유지하고 실패 시 레지스트리 COM만 반환한다',async()=>{
  const calls=[];
  const ports=await serialPorts({platform:'win32',execFile:(exe,args,options,done)=>{
    calls.push({exe,args,options});
    done(null,exe==='powershell.exe'?JSON.stringify([{name:'COM3',manufacturer:'KICC',driverName:'가상.sys'}]):'COM3 COM4');
  }});
  assert.equal(ports[0].driverName,'가상.sys');assert.deepEqual(ports[1],{name:'COM4'});
  assert.equal(deviceProfile('easycheck',{description:'TS-167',port:'COM3'}).receiptWidth,80);
  assert.match(Buffer.from(calls[0].args.at(-1),'base64').toString('utf16le'),/Win32_PnPSignedDriver/);
  assert.equal(calls[0].options.windowsHide,true);
  assert.match(PORT_SCRIPT,/Win32_SerialPort/);
  assert.deepEqual(await serialPorts({platform:'win32',execFile:(exe,args,options,done)=>exe==='powershell.exe'?done(Error('차단')):done(null,'COM5')}),[{name:'COM5'}]);
  assert.deepEqual(await serialPorts({platform:'linux'}),[]);
});
