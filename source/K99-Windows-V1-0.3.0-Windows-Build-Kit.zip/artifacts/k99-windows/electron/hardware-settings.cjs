'use strict';
const KEY='k99-hardware-preferences-v1';
const {renderReceipt,receiptPreferences}=require('./receipt-template.cjs');
const {createSerialReceiptPrinter,serialOptions}=require('./receipt-serial.cjs');
// Match only identifiable, already installed drivers. A generic COM port is
// not evidence of its manufacturer, and finding a driver is not card approval.
const VENDORS={
  easycheck:/easy[\s_-]*check|kicc|이지체크|한국정보통신/i,
  kis:/(?:^|[^a-z])kis(?:[^a-z]|$)|케이아이에스|kis정보통신/i,
  nice:/nice|smartro|나이스|스마트로/i,
};
function vendorPrinters(vendor,printers){
  if(!Object.hasOwn(VENDORS,vendor))throw Error('단말기 회사를 확인해 주세요.');
  return printers.filter(p=>VENDORS[vendor].test([p.name,p.displayName,p.description,p.manufacturer].filter(Boolean).join(' ')));
}
async function bounded(fn,ms){
  let timer;
  try{return await Promise.race([Promise.resolve().then(fn),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('장치 응답 대기 시간이 지났습니다.')),ms);})]);}
  finally{clearTimeout(timer);}
}
async function serialPorts(){
  if(process.platform!=='win32')return [];
  return new Promise(resolve=>{
    require('node:child_process').execFile('reg.exe',['query','HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM'],
      {windowsHide:true,timeout:2000,maxBuffer:65536},(error,stdout)=>{
        resolve(error?[]:[...new Set(String(stdout).match(/\bCOM\d+\b/gi)||[])].map(name=>({name:name.toUpperCase()})));
      });
  });
}
function createHardwareSettings({store,adapters,BrowserWindow,shell,native=process.platform==='win32'}){
  let printing=false;
  const serialPrint=createSerialReceiptPrinter();
  const read=()=>{try{return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}catch{throw Error('저장된 하드웨어 설정을 읽지 못했습니다. 기존 설정은 보존됩니다.');}};
  const config=()=>{
    const eq=store.equipment.getConfig(),p=read(),tag=store.equipment.drafts.tagPolicy();
    return {labelPrinterName:eq.printerName,...receiptPreferences({receiptType:p.receiptType??(p.receiptPrinterName?'windows':'none'),...p}),
      receiptVendor:Object.hasOwn(VENDORS,p.receiptVendor)?p.receiptVendor:'',
      labelVerified:eq.labelVerified===true,cameraDeviceId:eq.cameraDeviceId,
      tagMode:tag.mode==='roll'?'roll':tag.mode==='none'?'none':tag.printerKind||'tsc',
      manualTagNumbering:tag.numbering||'legacy',manualTagNextCustomer:tag.nextCustomer||1};
  };
  const terminal={connected:false,message:'카드 승인 여부는 단말기에서 직접 확인해 주세요. 접수증 출력과 카드 승인은 서로 다릅니다.'};
  function preview(input){
    const c=config(),preferences=receiptPreferences({...c,...input.config});
    return renderReceipt({receipt:input.receipt,preferences,
      profile:store.api('GET','/api/notices/profile').profile,showManualTags:c.tagMode==='roll'});
  }
  async function printReceipt(input,printers){
    const c=receiptPreferences({...config(),...input.config,
      ...(input.printerName?{receiptPrinterName:input.printerName}:{})});
    if(c.receiptType==='none'&&!input.printerName)throw Error('접수증 출력기를 사용하지 않도록 설정했습니다. 매장 맞춤 설정에서 출력기를 선택해 주세요.');
    if(c.receiptTransport==='serial'){
      serialOptions(c);
      const ports=await bounded(()=>adapters.ports?.()||serialPorts(),2500);
      if(!Array.isArray(ports)||!ports.some(p=>typeof p?.name==='string'&&p.name.toUpperCase()===c.receiptPort))
        throw Error('선택한 COM 포트가 연결되어 있지 않습니다. 케이블·전원·포트 번호를 확인해 주세요. 접수는 계속할 수 있습니다.');
      return (adapters.serialReceipt||serialPrint)({receipt:input.receipt,preferences:c,
        profile:store.api('GET','/api/notices/profile').profile,showManualTags:config().tagMode==='roll'});
    }
    if(!c.receiptPrinterName||!printers.some(p=>p.name===c.receiptPrinterName))
      throw Error('연결된 접수증 출력기가 없습니다. 전원·USB 연결과 Windows 프린터 등록을 확인해 주세요. 접수는 계속할 수 있습니다.');
    const rendered=preview({...input,config:c});
    const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
    let loadTimer;
    try{
      await Promise.race([win.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(rendered.html)),
        new Promise((_,reject)=>{loadTimer=setTimeout(()=>reject(Error('접수증 화면을 준비하지 못했습니다. 접수는 계속할 수 있습니다.')),10000);})]);
      clearTimeout(loadTimer);
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>reject(Error('인쇄 응답을 확인하지 못했습니다. 중복 인쇄 전에 실제 종이를 확인해 주세요.')),15000);
        try{win.webContents.print({silent:true,deviceName:c.receiptPrinterName,printBackground:true,
          margins:{marginType:'none'},pageSize:{width:c.receiptWidth*1000,
            height:Math.max(100000,Math.min(2000000,80000+(input.receipt?.items?.length||0)*11000))}},
          (ok,reason)=>{clearTimeout(timer);ok?resolve():reject(Error(reason||'출력기가 응답하지 않습니다. 전원과 연결을 확인해 주세요.'));});
        }catch(error){clearTimeout(timer);reject(error);}
      });
      return {message:'Windows 인쇄 대기열에 접수증 1장을 전달했습니다. 실제 종이를 확인해 주세요. 카드 결제 상태는 변경하지 않았습니다.'};
    }finally{clearTimeout(loadTimer);if(!win.isDestroyed())win.destroy();}
  }
  async function api(input={}){
    if(!['status','select-receipt-vendor','save','save-receipt','save-camera','save-tag','receipt-preferences','receipt-preview','receipt-print','test','display-settings'].includes(input.action))
      throw Error('지원하지 않는 하드웨어 설정 요청입니다.');
    if(input.action==='display-settings'){
      if(!native)throw Error('디스플레이 설정은 Windows 설치 앱에서 열 수 있습니다.');
      await shell.openExternal('ms-settings:display');return {message:'Windows 디스플레이 설정을 열었습니다.'};
    }
    if(input.action==='receipt-preview')return preview(input);
    if(input.action==='receipt-preferences')return {config:config(),native,terminal};
    let printers=[],printerMessage='';
    try{printers=await bounded(()=>adapters.printers(),3000);if(!Array.isArray(printers))throw Error();}
    catch{printers=[];printerMessage='프린터 목록을 확인하지 못했습니다. 전원과 Windows 장치 등록을 확인해 주세요. 접수는 계속할 수 있습니다.';}
    printers=printers.map(p=>({...p,port:p.port||p.options?.['printer-port-name']||p.options?.portName||''}));
    const status=async()=>{
      let ports=[];try{ports=await bounded(()=>adapters.ports?.()||serialPorts(),2500);}catch{}
      return {config:config(),printers,ports,native,terminal,printerMessage};
    };
    if(input.action==='status')return status();
    if(!native)throw Error('하드웨어 설정은 Windows 설치 앱에서 저장할 수 있습니다.');
    if(input.action==='select-receipt-vendor'){
      const vendor=input.vendor;
      const c=config(),expected=store.storage({op:'get',key:KEY});
      if(vendor==='none'){
        store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),receiptType:'none'}),expected});
        return {...await status(),selection:{state:'disabled',message:'미사용 · 기존 출력 설정은 보관합니다.'}};
      }
      const matches=vendorPrinters(vendor,printers);
      const saved=matches.find(p=>p.name===c.receiptPrinterName);
      const chosen=saved||(matches.length===1?matches[0]:null);
      // Retain a previously verified serial configuration, including baud,
      // encoding and ESC/POS consent. Never infer a device from COM1/COM3.
      if(vendor==='easycheck'&&c.receiptVendor!=='kis'&&c.receiptVendor!=='nice'&&
        c.receiptTransport==='serial'&&c.receiptEscPosVerified&&
        (read().receiptType==='easycheck'||c.receiptVendor==='easycheck')){
        const state=await status();
        if(state.ports.some(p=>p.name?.toUpperCase()===c.receiptPort.toUpperCase())){
          store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),receiptType:'easycheck',receiptVendor:vendor}),expected});
          return {...await status(),selection:{state:'configured',message:'이지체크의 기존 시리얼 출력 설정을 적용했습니다. 실제 출력은 테스트 인쇄로 확인해 주세요.'}};
        }
        return {...state,selection:{state:'missing',message:'저장된 이지체크 포트가 보이지 않습니다. 기존 설정은 그대로 보존했습니다. 전원과 케이블을 확인해 주세요.'}};
      }
      if(!chosen)return {...await status(),selection:{state:matches.length?'ambiguous':'missing',
        message:matches.length?'같은 회사 출력기가 여러 개입니다. 일반 영수증 프린터 상세 설정에서 한 번만 선택해 주세요. 기존 설정은 바꾸지 않았습니다.':
          '이 회사 이름이 확인되는 Windows 출력기를 찾지 못했습니다. 기존 설정은 보존했습니다. 드라이버 설치 또는 상세 설정을 확인해 주세요.'}};
      // A verified serial setup must not silently turn into a different path.
      if(c.receiptTransport==='serial'&&c.receiptEscPosVerified)
        return {...await status(),selection:{state:'ambiguous',message:'기존 시리얼 출력 설정을 보존했습니다. 다른 회사 출력기로 변경하려면 상세 설정에서 확인해 주세요.'}};
      const next=receiptPreferences({...c,receiptType:vendor==='easycheck'?'easycheck':'windows',
        receiptPrinterName:chosen.name,receiptTransport:'windows'});
      store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),...next,receiptVendor:vendor}),expected});
      return {...await status(),selection:{state:'configured',message:`${chosen.displayName||chosen.name} 자동 선택·저장됨. 실제 출력은 테스트 인쇄로 확인해 주세요. 카드 승인은 별도로 확인합니다.`}};
    }
    if(input.action==='save-receipt'){
      const c=receiptPreferences({...config(),...input.config}),old=config();
      if(c.receiptPrinterName&&c.receiptPrinterName!==old.receiptPrinterName&&!printers.some(p=>p.name===c.receiptPrinterName))
        throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const expected=store.storage({op:'get',key:KEY});
      const receiptVendor=input.config?.receiptVendor;
      if(receiptVendor!==undefined&&receiptVendor!==''&&!Object.hasOwn(VENDORS,receiptVendor))
        throw Error('단말기 회사를 확인해 주세요.');
      store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),...c,...(receiptVendor!==undefined?{receiptVendor}:{})}),expected});
      return status();
    }
    if(input.action==='save-camera'){
      store.saveCameraPreference(input.config?.cameraDeviceId);
      return status();
    }
    if(['save','save-camera','save-tag'].includes(input.action)){
      const old=config(),section=input.action,c={...old,...input.config};
      if(!input.config||!['tsc','xprinter','roll','none'].includes(c.tagMode)||
        ['labelPrinterName','receiptPrinterName','cameraDeviceId'].some(k=>typeof c[k]!=='string'||
          c[k].length>(k==='cameraDeviceId'?500:200)||/[\x00-\x1f]/.test(c[k])))
        throw Error('프린터·카메라 설정 형식을 확인해 주세요.');
      const usesPrinter=!['roll','none'].includes(c.tagMode);
      if(section!=='save-camera'&&usesPrinter&&!c.labelPrinterName)
        throw Error('라벨 프린터를 선택하세요. 사용하지 않으면 수기 택 또는 택 미사용을 선택하세요.');
      if(section!=='save-camera'&&usesPrinter&&c.labelPrinterName!==old.labelPrinterName&&c.labelVerified!==true)
        throw Error('새 라벨 프린터의 30mm 테스트 출력을 확인한 뒤 확인란을 선택해 주세요.');
      for(const k of ['labelPrinterName','receiptPrinterName'])
        if(c[k]&&c[k]!==old[k]&&!printers.some(p=>p.name===c[k]))throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const eq=store.equipment,previous=eq.getConfig(),policy=eq.drafts.tagPolicy(),prefs=read();
      const expected=store.storage({op:'get',key:KEY}),verified=c.labelVerified===true;
      store.saveHardwarePreferences({...previous,
        printerName:section==='save-camera'?previous.printerName:c.labelPrinterName,cameraDeviceId:c.cameraDeviceId,
        labelVerified:section==='save-camera'?previous.labelVerified:verified,
        hardwareConfirmed:section==='save-camera'?previous.hardwareConfirmed:true,...(verified?{mode:'real'}:{})},
        c.tagMode==='none'?'none':c.tagMode==='roll'?'roll':'printer',
        ['roll','none'].includes(c.tagMode)?policy.printerKind:c.tagMode,
        {...prefs,...receiptPreferences({...old,...c,
          ...(input.config.receiptType===undefined&&c.receiptPrinterName&&!old.receiptPrinterName?{receiptType:'windows'}:{})})},expected,
        section!=='save-camera'&&c.manualTagNumbering==='customer'?
          {numbering:'customer',...(c.manualTagReset?{nextCustomer:c.manualTagNextCustomer}:{})}:{});
      return status();
    }
    if(printing)throw Error('인쇄 응답을 기다리는 중입니다. 중복 출력하지 않습니다.');
    if(input.action==='receipt-print'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(input.kind==='receipt'&&receiptPreferences({...config(),...input.config}).receiptTransport==='serial'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(!['label','receipt'].includes(input.kind)||typeof input.printerName!=='string'||
      !printers.some(p=>p.name===input.printerName))throw Error('연결된 테스트 프린터를 선택해 주세요.');
    printing=true;
    try{
      if(input.kind==='label'){
        const height=store.equipment.getConfig().labelHeightMm;
        await adapters.print({id:'hardware-test',printerName:input.printerName,payload:{
          customerName:'테스트',itemName:'테스트 인쇄',garmentId:'K99-TEST',orderId:'TEST',
          serviceType:'general',labelWidthMm:30,labelHeightMm:height,labelVerified:true,
          manualMaterial:'폴리에스테르',manualColor:'유색',
        }});
      }else return await printReceipt(input,printers);
      return {message:'Windows 인쇄 대기열에 테스트 1장을 전달했습니다. 실제 종이 출력을 확인해 주세요.'};
    }finally{printing=false;}
  }
  return api;
}
module.exports={createHardwareSettings,KEY,vendorPrinters};
