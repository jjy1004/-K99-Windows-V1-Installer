'use strict';
const KEY='k99-hardware-preferences-v1';
function createHardwareSettings({store,adapters,BrowserWindow,shell,native=process.platform==='win32'}){
  let printing=false;
  const read=()=>{try{return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}catch{throw Error('저장된 하드웨어 설정을 읽지 못했습니다. 기존 설정은 보존됩니다.');}};
  const config=()=>{
    const eq=store.equipment.getConfig(),p=read(),tag=store.equipment.drafts.tagPolicy();
    return {labelPrinterName:eq.printerName,receiptPrinterName:p.receiptPrinterName||'',labelVerified:eq.labelVerified===true,
      cameraDeviceId:eq.cameraDeviceId,tagMode:tag.mode==='roll'?'roll':tag.printerKind||'tsc'};
  };
  async function api(input={}){
    if(!['status','save','test','display-settings'].includes(input.action))throw Error('지원하지 않는 하드웨어 설정 요청입니다.');
    if(input.action==='display-settings'){
      if(!native)throw Error('디스플레이 설정은 Windows 설치 앱에서 열 수 있습니다.');
      await shell.openExternal('ms-settings:display');return {message:'Windows 디스플레이 설정을 열었습니다.'};
    }
    const printers=await adapters.printers();
    if(input.action==='status')return {config:config(),printers,native};
    if(!native)throw Error('하드웨어 설정은 Windows 설치 앱에서 저장할 수 있습니다.');
    if(input.action==='save'){
      const c=input.config;
      if(!c||!['tsc','xprinter','roll'].includes(c.tagMode)||
        ['labelPrinterName','receiptPrinterName','cameraDeviceId'].some(k=>typeof c[k]!=='string'||
          c[k].length>(k==='cameraDeviceId'?500:200)||/[\x00-\x1f]/.test(c[k])))
        throw Error('프린터·카메라 설정 형식을 확인해 주세요.');
      const old=config();
      if(c.tagMode!=='roll'&&!c.labelPrinterName)throw Error('라벨 프린터를 선택하세요. 프린터를 사용하지 않으면 기성 롤태그를 선택하세요.');
      if(c.tagMode!=='roll'&&c.labelPrinterName!==old.labelPrinterName&&c.labelVerified!==true)
        throw Error('새 라벨 프린터의 30mm 테스트 출력을 확인한 뒤 확인란을 선택해 주세요.');
      for(const k of ['labelPrinterName','receiptPrinterName'])
        if(c[k]&&c[k]!==old[k]&&!printers.some(p=>p.name===c[k]))throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const eq=store.equipment,previous=eq.getConfig(),policy=eq.drafts.tagPolicy(),prefs=read();
      const expected=store.storage({op:'get',key:KEY});
      // Existing config and new receipt preference commit or roll back together.
      const verified=c.labelVerified===true;
      store.saveHardwarePreferences({...previous,printerName:c.labelPrinterName,cameraDeviceId:c.cameraDeviceId,
          labelVerified:verified,hardwareConfirmed:true,
          ...(verified?{mode:'real'}:{})},c.tagMode==='roll'?'roll':'printer',
        c.tagMode==='roll'?policy.printerKind:c.tagMode,{...prefs,receiptPrinterName:c.receiptPrinterName},expected);
      return {config:config(),printers,native};
    }
    if(printing)throw Error('테스트 인쇄 응답을 기다리는 중입니다. 중복 출력하지 않습니다.');
    if(!['label','receipt'].includes(input.kind)||typeof input.printerName!=='string'||
      !printers.some(p=>p.name===input.printerName))throw Error('연결된 테스트 프린터를 선택해 주세요.');
    printing=true;
    try{
      if(input.kind==='label'){
        const height=store.equipment.getConfig().labelHeightMm;
        await adapters.print({id:'hardware-test',printerName:input.printerName,payload:{
          customerName:'테스트',itemName:'테스트 인쇄',garmentId:'K99-TEST',orderId:'TEST',
          serviceType:'general',labelWidthMm:30,labelHeightMm:height,labelVerified:true,
          manualMaterial:'폴리에스테르',manualColor:'유색',
        }});
      }else{
        const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
        try{
          await win.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(
            '<!doctype html><html lang="ko"><meta charset="utf-8"><style>body{font:16px sans-serif}h1{font-size:20px}</style><h1>K99 영수증 프린터 테스트</h1><p>고객 자료가 아닌 테스트 출력입니다.</p><p>한글과 숫자 1234567890</p></html>'));
          await new Promise((resolve,reject)=>{
            const timer=setTimeout(()=>reject(Error('인쇄 결과 미확인. 실물을 확인한 후 다시 시도하세요.')),30000);
            win.webContents.print({silent:true,deviceName:input.printerName,printBackground:true},
              (ok,reason)=>{clearTimeout(timer);ok?resolve():reject(Error(reason||'인쇄 결과 미확인'));});
          });
        }finally{if(!win.isDestroyed())win.destroy();}
      }
      return {message:'Windows 인쇄 대기열에 테스트 1장을 전달했습니다. 실제 종이 출력을 확인해 주세요.'};
    }finally{printing=false;}
  }
  return api;
}
module.exports={createHardwareSettings,KEY};
