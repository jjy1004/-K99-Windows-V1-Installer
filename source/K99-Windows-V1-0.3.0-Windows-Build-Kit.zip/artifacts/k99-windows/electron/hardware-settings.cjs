'use strict';
const KEY='k99-hardware-preferences-v1';
const {renderReceipt,receiptPreferences}=require('./receipt-template.cjs');
const {createSerialReceiptPrinter,serialOptions}=require('./receipt-serial.cjs');
const {createTerminalProbe}=require('./services/terminal-connection.cjs');
// Match only identifiable, already installed drivers. A generic COM port is
// not evidence of its manufacturer, and finding a driver is not card approval.
const {VENDORS,identify,deviceProfile,serialPorts}=require('./services/receipt-devices.cjs');
function vendorPrinters(vendor,printers){
  if(!Object.hasOwn(VENDORS,vendor))throw Error('단말기 회사를 확인해 주세요.');
  return printers.filter(p=>identify(p)===vendor);
}
async function bounded(fn,ms){
  let timer;
  try{return await Promise.race([Promise.resolve().then(fn),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('장치 응답 대기 시간이 지났습니다.')),ms);})]);}
  finally{clearTimeout(timer);}
}
function createHardwareSettings({store,adapters,BrowserWindow,shell,printGeneral,native=process.platform==='win32'}){
  let printing=false;
  let checking=null;
  const probe=adapters.terminalProbe||createTerminalProbe();
  const serialPrint=createSerialReceiptPrinter();
  const read=()=>{try{return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}catch{throw Error('저장된 하드웨어 설정을 읽지 못했습니다. 기존 설정은 보존됩니다.');}};
  const config=()=>{
    const eq=store.equipment.getConfig(),p=read(),tag=store.equipment.drafts.tagPolicy();
    return {labelPrinterName:eq.printerName,...receiptPreferences({receiptType:p.receiptType??(p.receiptPrinterName?'windows':'none'),...p}),
      receiptVendor:Object.hasOwn(VENDORS,p.receiptVendor)?p.receiptVendor:'',
      labelVerified:eq.labelVerified===true,cameraDeviceId:eq.cameraDeviceId,
      tagMode:tag.mode==='roll'?'roll':tag.mode==='none'?'none':tag.printerKind||'tsc',
      manualTagNumbering:tag.numbering||'legacy',manualTagNextCustomer:tag.nextCustomer||1};
  };
  const terminal={connected:false,message:'카드 승인 여부는 단말기에서 직접 확인해 주세요. 접수증 출력과 카드 승인은 서로 다릅니다.'};
  function preview(input){
    const c=config(),preferences=receiptPreferences({...c,...input.config});
    return renderReceipt({receipt:input.receipt,preferences,
      profile:store.api('GET','/api/notices/profile').profile,showManualTags:c.tagMode==='roll'});
  }
  async function printReceipt(input,printers){
    // Preview overrides must never redirect a physical print.
    const c=receiptPreferences(config());
    if(c.receiptType==='none')throw Error('접수증 출력기를 사용하지 않도록 설정했습니다. 연결된 접수증 출력기를 매장 맞춤 설정에서 선택·저장해 주세요.');
    if(c.receiptTransport==='serial'){
      serialOptions(c);
      const ports=await bounded(()=>adapters.ports?.()||serialPorts(),4500);
      if(!Array.isArray(ports)||!ports.some(p=>typeof p?.name==='string'&&p.name.toUpperCase()===c.receiptPort))
        throw Error('선택한 COM 포트가 연결되어 있지 않습니다. 케이블·전원·포트 번호를 확인해 주세요. 접수는 계속할 수 있습니다.');
      return (adapters.serialReceipt||serialPrint)({receipt:input.receipt,preferences:c,
        profile:store.api('GET','/api/notices/profile').profile,showManualTags:config().tagMode==='roll'});
    }
    if(!c.receiptPrinterName||!printers.some(p=>p.name===c.receiptPrinterName))
      throw Error('연결된 접수증 출력기가 없습니다. 전원·USB 연결과 Windows 프린터 등록을 확인해 주세요. 접수는 계속할 수 있습니다.');
    const rendered=preview({...input,config:c});
    const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
    let loadTimer;
    try{
      await Promise.race([win.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(rendered.html)),
        new Promise((_,reject)=>{loadTimer=setTimeout(()=>reject(Error('접수증 화면을 준비하지 못했습니다. 접수는 계속할 수 있습니다.')),10000);})]);
      clearTimeout(loadTimer);
      const measured=win.webContents.executeJavaScript?await bounded(()=>win.webContents.executeJavaScript(
        'Math.ceil(Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)*25.4/96*1000)'),3000):
        120000+rendered.html.length*100+(input.receipt?.items?.length||0)*20000;
      const height=Math.max(100000,Math.ceil(measured)+5000);
      if(!Number.isFinite(height)||height>2000000)throw Error('접수증이 한 장의 출력 길이를 초과했습니다. 품목을 나누어 인쇄해 주세요. 잘라서 출력하지 않습니다.');
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>reject(Error('인쇄 응답을 확인하지 못했습니다. 중복 인쇄 전에 실제 종이를 확인해 주세요.')),15000);
        try{win.webContents.print({silent:true,deviceName:c.receiptPrinterName,printBackground:true,
          margins:{marginType:'none'},pageSize:{width:c.receiptWidth*1000,
            height}},
          (ok,reason)=>{clearTimeout(timer);ok?resolve():reject(Error(reason||'출력기가 응답하지 않습니다. 전원과 연결을 확인해 주세요.'));});
        }catch(error){clearTimeout(timer);reject(error);}
      });
      return {message:'Windows 인쇄 대기열에 접수증 1장을 전달했습니다. 실제 종이를 확인해 주세요. 카드 결제 상태는 변경하지 않았습니다.'};
    }finally{clearTimeout(loadTimer);if(!win.isDestroyed())win.destroy();}
  }
  async function api(input={}){
    if(!['status','terminal-check','general-print','select-receipt-vendor','save','save-receipt','save-camera','save-tag','receipt-preferences','receipt-preview','receipt-print','test','display-settings'].includes(input.action))
      throw Error('지원하지 않는 하드웨어 설정 요청입니다.');
    if(input.action==='general-print'){
      if(!native||!printGeneral)throw Error('일반 출력은 Windows 설치 앱에서 사용할 수 있습니다.');
      if(printing||checking)throw Error('출력·장치 확인이 진행 중입니다. 잠시 후 다시 시도하세요.');
      printing=true;try{return await printGeneral();}finally{printing=false;}
    }
    if(input.action==='terminal-check'){
      if(checking)return checking;
      if(printing)return {config:config(),terminal:{connected:false,state:'busy',message:'출력 중에는 포트를 다시 열지 않습니다. 실제 카드 승인은 단말기에서 확인하세요.'}};
      checking=(async()=>{
        const state=await api({action:'status'}),c=config(),revision=store.storage({op:'get',key:KEY});
        let available=false,phase='unverified';
        if(!native)phase='unsupported';
        else if(c.receiptType==='none')phase='disabled';
        else if(c.receiptTransport==='serial'){
          if(!state.ports.some(p=>p.name?.toUpperCase()===c.receiptPort))phase='missing';
          else if(c.receiptEscPosVerified){
            available=await bounded(()=>probe({port:c.receiptPort,baud:c.receiptBaudRate}),3500).catch(()=>false);
            phase=available?'available':'unavailable';
          }
        }else{
          available=state.printers.some(p=>p.name===c.receiptPrinterName);
          phase=available?'available':'missing';
        }
        if(store.storage({op:'get',key:KEY})!==revision){available=false;phase='changed';}
        Object.assign(terminal,{connected:false,transportReady:available,state:phase,
          message:available?'저장된 출력 연결 경로를 확인했습니다. 카드 승인 규격은 미확인이며 실제 결제는 단말기에서 확인하세요.':
            phase==='disabled'?'접수증 미사용 설정을 유지했습니다. 실제 카드 승인은 단말기에서 확인하세요.':
            '단말기 연결 경로를 확인하지 못했거나 전용 규격이 미확인입니다. 저장된 수동 설정은 유지하며 실제 결제는 단말기에서 확인하세요.'});
        return {...state,config:config(),terminal:{...terminal}};
      })();
      try{return await checking;}finally{checking=null;}
    }
    if(input.action==='display-settings'){
      if(!native)throw Error('디스플레이 설정은 Windows 설치 앱에서 열 수 있습니다.');
      await shell.openExternal('ms-settings:display');return {message:'Windows 디스플레이 설정을 열었습니다.'};
    }
    if(input.action==='receipt-preview')return preview(input);
    if(input.action==='receipt-preferences')return {config:config(),native,terminal};
    let printers=[],printerMessage='';
    try{printers=await bounded(()=>adapters.printers(),3000);if(!Array.isArray(printers))throw Error();}
    catch{printers=[];printerMessage='프린터 목록을 확인하지 못했습니다. 전원과 Windows 장치 등록을 확인해 주세요. 접수는 계속할 수 있습니다.';}
    printers=printers.map(p=>({...p,port:p.port||p.options?.['printer-port-name']||p.options?.portName||''}));
    const status=async()=>{
      let ports=[];try{ports=await bounded(()=>adapters.ports?.()||serialPorts(),4500);if(!Array.isArray(ports))ports=[];}catch{}
      return {config:config(),printers,ports,native,terminal,printerMessage};
    };
    if(input.action==='status'){
      const state=await status(),old=read();
      // Any pre-existing receipt preference (including explicit "none") wins.
      // No schema migration, no startup write to a store with saved settings.
      if(native&&!Object.keys(old).some(k=>k.startsWith('receipt'))){
        const devices=[...printers,...state.ports].filter(p=>identify(p));
        const vendors=[...new Set(devices.map(identify))];
        if(vendors.length===1){
          const vendor=vendors[0],matches=vendorPrinters(vendor,printers);
          const ports=state.ports.filter(p=>identify(p)===vendor);
          if(matches.length<=1&&ports.length<=1&&(matches.length||ports.length)){
            const chosen=matches[0]||ports[0],expected=store.storage({op:'get',key:KEY});
            const next={...old,...deviceProfile(vendor,chosen,state.ports),
              ...(matches.length?{receiptPrinterName:chosen.name}:{})};
            store.storage({op:'set',key:KEY,value:JSON.stringify(next),expected});
            return {...state,config:config(),selection:{state:matches.length?'configured':'missing',
              message:matches.length?'장치 정보로 출력기를 선택했습니다. 실제 종이는 테스트 인쇄로 확인해 주세요.':
                '단말기 회사와 COM 포트를 확인했습니다. 전용 출력 규격은 미확인이므로 드라이버 또는 직접 출력 지원 확인이 필요합니다.'}};
          }
        }
      }
      return state;
    }
    if(!native)throw Error('하드웨어 설정은 Windows 설치 앱에서 저장할 수 있습니다.');
    if(input.action==='select-receipt-vendor'){
      const vendor=input.vendor;
      const c=config(),expected=store.storage({op:'get',key:KEY});
      if(vendor==='none'){
        store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),receiptType:'none'}),expected});
        return {...await status(),selection:{state:'disabled',message:'미사용 · 기존 출력 설정은 보관합니다.'}};
      }
      const matches=vendorPrinters(vendor,printers);
      const saved=matches.find(p=>p.name===c.receiptPrinterName);
      const chosen=saved||(matches.length===1?matches[0]:null);
      // Retain a previously verified serial configuration, including baud,
      // encoding and ESC/POS consent. Never infer a device from COM1/COM3.
      if(vendor==='easycheck'&&c.receiptVendor!=='kis'&&c.receiptVendor!=='nice'&&
        c.receiptTransport==='serial'&&c.receiptEscPosVerified&&
        (read().receiptType==='easycheck'||c.receiptVendor==='easycheck')){
        const state=await status();
        if(state.ports.some(p=>p.name?.toUpperCase()===c.receiptPort.toUpperCase())){
          store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),receiptType:'easycheck',receiptVendor:vendor}),expected});
          return {...await status(),selection:{state:'configured',message:'이지체크의 기존 시리얼 출력 설정을 적용했습니다. 실제 출력은 테스트 인쇄로 확인해 주세요.'}};
        }
        return {...state,selection:{state:'missing',message:'저장된 이지체크 포트가 보이지 않습니다. 기존 설정은 그대로 보존했습니다. 전원과 케이블을 확인해 주세요.'}};
      }
      if(c.receiptVendor===vendor&&c.receiptType!=='none'){
        const state=await status();
        return {...state,selection:{state:matches.some(p=>p.name===c.receiptPrinterName)?'configured':'missing',
          message:'선택한 회사의 저장된 세부 설정을 유지했습니다. 연결과 실제 종이는 테스트 인쇄로 확인해 주세요.'}};
      }
      if(!chosen){
        const state=await status();
        return {...state,config:c.receiptVendor===vendor?c:
          {...c,...deviceProfile(vendor,{},state.ports),receiptPrinterName:''},selection:{state:matches.length?'ambiguous':'missing',
          message:matches.length?'같은 회사 출력기가 여러 개입니다. 회사 기본값을 화면에 채웠습니다. 상세 설정을 확인하고 저장하세요. 기존 저장값은 유지합니다.':
            '회사 기본값을 화면에 채웠습니다. 연결된 출력 규격은 미확인입니다. 상세 설정을 확인하고 저장하세요. 기존 저장값은 유지합니다.'}};
      }
      // A verified serial setup must not silently turn into a different path.
      if(c.receiptTransport==='serial'&&c.receiptEscPosVerified){
        const state=await status();
        return {...state,config:{...c,...deviceProfile(vendor,chosen,state.ports),receiptPrinterName:chosen.name},
          selection:{state:'ambiguous',message:'다른 회사 기본값은 화면에만 채웠습니다. 기존 시리얼 저장값은 보존했습니다. 변경하려면 상세 설정 확인 후 저장하세요.'}};
      }
      const state=await status();
      const sameVendor=c.receiptVendor===vendor;
      const next=receiptPreferences({...c,...(sameVendor?{}:deviceProfile(vendor,chosen,state.ports)),
        receiptType:vendor==='easycheck'?'easycheck':'windows',
        receiptPrinterName:sameVendor&&c.receiptPrinterName?c.receiptPrinterName:chosen.name});
      store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),...next,receiptVendor:vendor}),expected});
      return {...await status(),selection:{state:'configured',message:`${chosen.displayName||chosen.name} 자동 선택·저장됨. 실제 출력은 테스트 인쇄로 확인해 주세요. 카드 승인은 별도로 확인합니다.`}};
    }
    if(input.action==='save-receipt'){
      const c=receiptPreferences({...config(),...input.config}),old=config();
      if(c.receiptPrinterName&&c.receiptPrinterName!==old.receiptPrinterName&&!printers.some(p=>p.name===c.receiptPrinterName))
        throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const expected=store.storage({op:'get',key:KEY});
      const receiptVendor=input.config?.receiptVendor;
      if(receiptVendor!==undefined&&receiptVendor!==''&&!Object.hasOwn(VENDORS,receiptVendor))
        throw Error('단말기 회사를 확인해 주세요.');
      store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),...c,...(receiptVendor!==undefined?{receiptVendor}:{})}),expected});
      return status();
    }
    if(input.action==='save-camera'){
      store.saveCameraPreference(input.config?.cameraDeviceId);
      return status();
    }
    if(['save','save-camera','save-tag'].includes(input.action)){
      const old=config(),section=input.action,c={...old,...input.config};
      if(!input.config||!['tsc','xprinter','roll','none'].includes(c.tagMode)||
        ['labelPrinterName','receiptPrinterName','cameraDeviceId'].some(k=>typeof c[k]!=='string'||
          c[k].length>(k==='cameraDeviceId'?500:200)||/[\x00-\x1f]/.test(c[k])))
        throw Error('프린터·카메라 설정 형식을 확인해 주세요.');
      const usesPrinter=!['roll','none'].includes(c.tagMode);
      if(section!=='save-camera'&&usesPrinter&&!c.labelPrinterName)
        throw Error('라벨 프린터를 선택하세요. 사용하지 않으면 수기 택 또는 택 미사용을 선택하세요.');
      if(section!=='save-camera'&&usesPrinter&&c.labelPrinterName!==old.labelPrinterName&&c.labelVerified!==true)
        throw Error('새 라벨 프린터의 30mm 테스트 출력을 확인한 뒤 확인란을 선택해 주세요.');
      for(const k of ['labelPrinterName','receiptPrinterName'])
        if(c[k]&&c[k]!==old[k]&&!printers.some(p=>p.name===c[k]))throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const eq=store.equipment,previous=eq.getConfig(),policy=eq.drafts.tagPolicy(),prefs=read();
      const expected=store.storage({op:'get',key:KEY}),verified=c.labelVerified===true;
      store.saveHardwarePreferences({...previous,
        printerName:section==='save-camera'?previous.printerName:c.labelPrinterName,cameraDeviceId:c.cameraDeviceId,
        labelVerified:section==='save-camera'?previous.labelVerified:verified,
        hardwareConfirmed:section==='save-camera'?previous.hardwareConfirmed:true,...(verified?{mode:'real'}:{})},
        c.tagMode==='none'?'none':c.tagMode==='roll'?'roll':'printer',
        ['roll','none'].includes(c.tagMode)?policy.printerKind:c.tagMode,
        {...prefs,...receiptPreferences({...old,...c,
          ...(input.config.receiptType===undefined&&c.receiptPrinterName&&!old.receiptPrinterName?{receiptType:'windows'}:{})})},expected,
        section!=='save-camera'&&c.manualTagNumbering==='customer'?
          {numbering:'customer',...(c.manualTagReset?{nextCustomer:c.manualTagNextCustomer}:{})}:{});
      return status();
    }
    if(printing||checking)throw Error('인쇄·장치 확인 응답을 기다리는 중입니다. 중복 출력하지 않습니다.');
    if(input.action==='receipt-print'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(input.kind==='receipt'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(!['label','receipt'].includes(input.kind)||typeof input.printerName!=='string'||
      !printers.some(p=>p.name===input.printerName))throw Error('연결된 테스트 프린터를 선택해 주세요.');
    printing=true;
    try{
      if(input.kind==='label'){
        const height=store.equipment.getConfig().labelHeightMm;
        await adapters.print({id:'hardware-test',printerName:input.printerName,payload:{
          customerName:'테스트',itemName:'테스트 인쇄',garmentId:'K99-TEST',orderId:'TEST',
          serviceType:'general',labelWidthMm:30,labelHeightMm:height,labelVerified:true,
          manualMaterial:'폴리에스테르',manualColor:'유색',
        }});
      }else return await printReceipt(input,printers);
      return {message:'Windows 인쇄 대기열에 테스트 1장을 전달했습니다. 실제 종이 출력을 확인해 주세요.'};
    }finally{printing=false;}
  }
  return api;
}
module.exports={createHardwareSettings,KEY,vendorPrinters};
