'use strict';
const KEY='k99-hardware-preferences-v1';
const {renderReceipt,receiptPreferences}=require('./receipt-template.cjs');
const {createSerialReceiptPrinter,serialOptions}=require('./receipt-serial.cjs');
async function bounded(fn,ms){
  let timer;
  try{return await Promise.race([Promise.resolve().then(fn),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('장치 응답 대기 시간이 지났습니다.')),ms);})]);}
  finally{clearTimeout(timer);}
}
async function serialPorts(){
  if(process.platform!=='win32')return [];
  return new Promise(resolve=>{
    require('node:child_process').execFile('reg.exe',['query','HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM'],
      {windowsHide:true,timeout:2000,maxBuffer:65536},(error,stdout)=>{
        resolve(error?[]:[...new Set(String(stdout).match(/\bCOM\d+\b/gi)||[])].map(name=>({name:name.toUpperCase()})));
      });
  });
}
function createHardwareSettings({store,adapters,BrowserWindow,shell,native=process.platform==='win32'}){
  let printing=false;
  const serialPrint=createSerialReceiptPrinter();
  const read=()=>{try{return JSON.parse(store.storage({op:'get',key:KEY})||'{}');}catch{throw Error('저장된 하드웨어 설정을 읽지 못했습니다. 기존 설정은 보존됩니다.');}};
  const config=()=>{
    const eq=store.equipment.getConfig(),p=read(),tag=store.equipment.drafts.tagPolicy();
    return {labelPrinterName:eq.printerName,...receiptPreferences({receiptType:p.receiptType??(p.receiptPrinterName?'windows':'none'),...p}),
      labelVerified:eq.labelVerified===true,cameraDeviceId:eq.cameraDeviceId,
      tagMode:tag.mode==='roll'?'roll':tag.mode==='none'?'none':tag.printerKind||'tsc',
      manualTagNumbering:tag.numbering||'legacy',manualTagNextCustomer:tag.nextCustomer||1};
  };
  const terminal={connected:false,message:'이지체크 카드 승인 연동은 현장 단말기 확인 후 사용할 수 있습니다. 접수증 출력과 카드 승인은 서로 다릅니다.'};
  function preview(input){
    const c=config(),preferences=receiptPreferences({...c,...input.config});
    return renderReceipt({receipt:input.receipt,preferences,
      profile:store.api('GET','/api/notices/profile').profile,showManualTags:c.tagMode==='roll'});
  }
  async function printReceipt(input,printers){
    const c=receiptPreferences({...config(),...input.config,
      ...(input.printerName?{receiptPrinterName:input.printerName}:{})});
    if(c.receiptType==='none'&&!input.printerName)throw Error('접수증 출력기를 사용하지 않도록 설정했습니다. 매장 맞춤 설정에서 출력기를 선택해 주세요.');
    if(c.receiptTransport==='serial'){
      serialOptions(c);
      const ports=await bounded(()=>adapters.ports?.()||serialPorts(),2500);
      if(!Array.isArray(ports)||!ports.some(p=>typeof p?.name==='string'&&p.name.toUpperCase()===c.receiptPort))
        throw Error('선택한 COM 포트가 연결되어 있지 않습니다. 케이블·전원·포트 번호를 확인해 주세요. 접수는 계속할 수 있습니다.');
      return (adapters.serialReceipt||serialPrint)({receipt:input.receipt,preferences:c,
        profile:store.api('GET','/api/notices/profile').profile,showManualTags:config().tagMode==='roll'});
    }
    if(!c.receiptPrinterName||!printers.some(p=>p.name===c.receiptPrinterName))
      throw Error('연결된 접수증 출력기가 없습니다. 전원·USB 연결과 Windows 프린터 등록을 확인해 주세요. 접수는 계속할 수 있습니다.');
    const rendered=preview({...input,config:c});
    const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
    let loadTimer;
    try{
      await Promise.race([win.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(rendered.html)),
        new Promise((_,reject)=>{loadTimer=setTimeout(()=>reject(Error('접수증 화면을 준비하지 못했습니다. 접수는 계속할 수 있습니다.')),10000);})]);
      clearTimeout(loadTimer);
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>reject(Error('인쇄 응답을 확인하지 못했습니다. 중복 인쇄 전에 실제 종이를 확인해 주세요.')),15000);
        try{win.webContents.print({silent:true,deviceName:c.receiptPrinterName,printBackground:true,
          margins:{marginType:'none'},pageSize:{width:c.receiptWidth*1000,
            height:Math.max(100000,Math.min(2000000,80000+(input.receipt?.items?.length||0)*11000))}},
          (ok,reason)=>{clearTimeout(timer);ok?resolve():reject(Error(reason||'출력기가 응답하지 않습니다. 전원과 연결을 확인해 주세요.'));});
        }catch(error){clearTimeout(timer);reject(error);}
      });
      return {message:'Windows 인쇄 대기열에 접수증 1장을 전달했습니다. 실제 종이를 확인해 주세요. 카드 결제 상태는 변경하지 않았습니다.'};
    }finally{clearTimeout(loadTimer);if(!win.isDestroyed())win.destroy();}
  }
  async function api(input={}){
    if(!['status','save','save-receipt','save-camera','save-tag','receipt-preferences','receipt-preview','receipt-print','test','display-settings'].includes(input.action))
      throw Error('지원하지 않는 하드웨어 설정 요청입니다.');
    if(input.action==='display-settings'){
      if(!native)throw Error('디스플레이 설정은 Windows 설치 앱에서 열 수 있습니다.');
      await shell.openExternal('ms-settings:display');return {message:'Windows 디스플레이 설정을 열었습니다.'};
    }
    if(input.action==='receipt-preview')return preview(input);
    if(input.action==='receipt-preferences')return {config:config(),native,terminal};
    let printers=[],printerMessage='';
    try{printers=await bounded(()=>adapters.printers(),3000);if(!Array.isArray(printers))throw Error();}
    catch{printers=[];printerMessage='프린터 목록을 확인하지 못했습니다. 전원과 Windows 장치 등록을 확인해 주세요. 접수는 계속할 수 있습니다.';}
    printers=printers.map(p=>({...p,port:p.port||p.options?.['printer-port-name']||p.options?.portName||''}));
    const status=async()=>{
      let ports=[];try{ports=await bounded(()=>adapters.ports?.()||serialPorts(),2500);}catch{}
      return {config:config(),printers,ports,native,terminal,printerMessage};
    };
    if(input.action==='status')return status();
    if(!native)throw Error('하드웨어 설정은 Windows 설치 앱에서 저장할 수 있습니다.');
    if(input.action==='save-receipt'){
      const c=receiptPreferences({...config(),...input.config}),old=config();
      if(c.receiptPrinterName&&c.receiptPrinterName!==old.receiptPrinterName&&!printers.some(p=>p.name===c.receiptPrinterName))
        throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const expected=store.storage({op:'get',key:KEY});
      store.storage({op:'set',key:KEY,value:JSON.stringify({...read(),...c}),expected});
      return status();
    }
    if(input.action==='save-camera'){
      store.saveCameraPreference(input.config?.cameraDeviceId);
      return status();
    }
    if(['save','save-camera','save-tag'].includes(input.action)){
      const old=config(),section=input.action,c={...old,...input.config};
      if(!input.config||!['tsc','xprinter','roll','none'].includes(c.tagMode)||
        ['labelPrinterName','receiptPrinterName','cameraDeviceId'].some(k=>typeof c[k]!=='string'||
          c[k].length>(k==='cameraDeviceId'?500:200)||/[\x00-\x1f]/.test(c[k])))
        throw Error('프린터·카메라 설정 형식을 확인해 주세요.');
      const usesPrinter=!['roll','none'].includes(c.tagMode);
      if(section!=='save-camera'&&usesPrinter&&!c.labelPrinterName)
        throw Error('라벨 프린터를 선택하세요. 사용하지 않으면 수기 택 또는 택 미사용을 선택하세요.');
      if(section!=='save-camera'&&usesPrinter&&c.labelPrinterName!==old.labelPrinterName&&c.labelVerified!==true)
        throw Error('새 라벨 프린터의 30mm 테스트 출력을 확인한 뒤 확인란을 선택해 주세요.');
      for(const k of ['labelPrinterName','receiptPrinterName'])
        if(c[k]&&c[k]!==old[k]&&!printers.some(p=>p.name===c[k]))throw Error('현재 연결된 프린터 목록에서 선택해 주세요.');
      const eq=store.equipment,previous=eq.getConfig(),policy=eq.drafts.tagPolicy(),prefs=read();
      const expected=store.storage({op:'get',key:KEY}),verified=c.labelVerified===true;
      store.saveHardwarePreferences({...previous,
        printerName:section==='save-camera'?previous.printerName:c.labelPrinterName,cameraDeviceId:c.cameraDeviceId,
        labelVerified:section==='save-camera'?previous.labelVerified:verified,
        hardwareConfirmed:section==='save-camera'?previous.hardwareConfirmed:true,...(verified?{mode:'real'}:{})},
        c.tagMode==='none'?'none':c.tagMode==='roll'?'roll':'printer',
        ['roll','none'].includes(c.tagMode)?policy.printerKind:c.tagMode,
        {...prefs,...receiptPreferences({...old,...c,
          ...(input.config.receiptType===undefined&&c.receiptPrinterName&&!old.receiptPrinterName?{receiptType:'windows'}:{})})},expected,
        section!=='save-camera'&&c.manualTagNumbering==='customer'?
          {numbering:'customer',...(c.manualTagReset?{nextCustomer:c.manualTagNextCustomer}:{})}:{});
      return status();
    }
    if(printing)throw Error('인쇄 응답을 기다리는 중입니다. 중복 출력하지 않습니다.');
    if(input.action==='receipt-print'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(input.kind==='receipt'&&receiptPreferences({...config(),...input.config}).receiptTransport==='serial'){
      printing=true;try{return await printReceipt(input,printers);}finally{printing=false;}
    }
    if(!['label','receipt'].includes(input.kind)||typeof input.printerName!=='string'||
      !printers.some(p=>p.name===input.printerName))throw Error('연결된 테스트 프린터를 선택해 주세요.');
    printing=true;
    try{
      if(input.kind==='label'){
        const height=store.equipment.getConfig().labelHeightMm;
        await adapters.print({id:'hardware-test',printerName:input.printerName,payload:{
          customerName:'테스트',itemName:'테스트 인쇄',garmentId:'K99-TEST',orderId:'TEST',
          serviceType:'general',labelWidthMm:30,labelHeightMm:height,labelVerified:true,
          manualMaterial:'폴리에스테르',manualColor:'유색',
        }});
      }else return await printReceipt(input,printers);
      return {message:'Windows 인쇄 대기열에 테스트 1장을 전달했습니다. 실제 종이 출력을 확인해 주세요.'};
    }finally{printing=false;}
  }
  return api;
}
module.exports={createHardwareSettings,KEY};
