'use strict';
// Apply before ready/BrowserWindow. Prefer software rendering on shop PCs
// with legacy graphics drivers, RDP or endpoint-security GPU restrictions.
function configureWindowsRendering(app,platform=process.platform){
  if(platform!=='win32')return;
  app.disableHardwareAcceleration();
  app.commandLine.appendSwitch('disable-gpu');
  app.commandLine.appendSwitch('disable-gpu-compositing');
}
module.exports={configureWindowsRendering};
