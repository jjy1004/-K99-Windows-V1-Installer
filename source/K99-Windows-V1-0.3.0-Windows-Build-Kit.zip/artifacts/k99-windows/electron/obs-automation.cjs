'use strict';
const fs=require('node:fs/promises'),path=require('node:path');
const ARGS=['--startvirtualcam','--minimize-to-tray'];
function createObsAutomation({app,shell,io=fs,platform=process.platform,env=process.env,
  execFile=require('node:child_process').execFile,spawn=require('node:child_process').spawn,timeoutMs=1500}){
  const config=path.join(app.getPath('userData'),'obs-automation.json');
  const shortcut=path.join(app.getPath('appData'),'Microsoft','Windows','Start Menu','Programs','Startup','OBS Studio - K99 자동 실행.lnk');
  let pending=null;
  async function enabled(){
    try{return JSON.parse(await io.readFile(config,'utf8')).enabled!==false;}
    catch(error){if(error.code==='ENOENT')return false;throw Error('OBS 자동 실행 설정을 읽지 못했습니다.');}
  }
  async function findObs(){
    const roots=[env.ProgramW6432,env.ProgramFiles,'C:\\Program Files',env.LOCALAPPDATA&&path.win32.join(env.LOCALAPPDATA,'Programs')].filter(Boolean);
    for(const root of [...new Set(roots)]){
      const candidate=path.win32.join(root,'obs-studio','bin','64bit','obs64.exe');
      try{if((await io.stat(candidate)).isFile())return candidate;}catch{/* Not installed here. */}
    }
    return null;
  }
  async function running(){
    return new Promise(resolve=>{
      let finished=false,child;
      const done=value=>{if(!finished){finished=true;clearTimeout(timer);resolve(value);}};
      const timer=setTimeout(()=>{done(null);try{child?.kill();}catch{}},timeoutMs);
      try{
        child=execFile('tasklist.exe',['/FI','IMAGENAME eq obs64.exe','/FO','CSV','/NH'],
          {windowsHide:true,encoding:'utf8',timeout:timeoutMs,maxBuffer:1024*1024},
          (error,text)=>done(error?null:/"obs64\.exe"\s*,/i.test(String(text))));
      }catch{done(null);}
    });
  }
  async function status(){
    if(platform!=='win32')return {success:false,enabled:false,note:'Windows 설치 앱에서 OBS 자동 실행을 설정할 수 있습니다.'};
    const on=await enabled(),exe=await findObs();
    let shortcutReady=false;
    if(exe)try{const link=shell.readShortcutLink(shortcut);
      shortcutReady=link.target.toLowerCase()===exe.toLowerCase()&&link.args===ARGS.join(' ');
    }catch{}
    return {success:true,enabled:on,installed:!!exe,shortcutReady,note:!exe?'OBS Studio가 설치되지 않았습니다. 직접 USB 촬영은 사용할 수 있습니다.':
      on?'OBS 자동 실행 사용 중':'OBS 자동 실행 꺼짐'};
  }
  async function work(action){
    if(platform!=='win32')return status();
    if(action==='enable'||action==='disable'){
      await io.mkdir(path.dirname(config),{recursive:true});
      const temporary=config+'.pending';
      await io.writeFile(temporary,JSON.stringify({enabled:action==='enable'}),{mode:0o600});
      await io.rename(temporary,config);
    }
    const on=await enabled();
    if(!on){
      // Only our own shortcut; never remove a shop's separately configured OBS.
      await io.unlink(shortcut).catch(error=>{if(error.code!=='ENOENT')throw error;});
      return status();
    }
    const exe=await findObs();
    if(!exe)return status();
    await io.mkdir(path.dirname(shortcut),{recursive:true});
    if(!shell.writeShortcutLink(shortcut,'create',{target:exe,cwd:path.win32.dirname(exe),
      args:ARGS.join(' '),description:'K99 고객 촬영용 OBS 가상 카메라 자동 실행',icon:exe,iconIndex:0}))
      return {...await status(),success:false,note:'OBS 시작프로그램 바로가기 쓰기가 차단됐습니다. Windows 보안 설정을 확인하세요.'};
    const active=await running();
    if(active===null)return {...await status(),running:null,note:'OBS 실행 여부 확인이 지연되었습니다. 중복 실행을 피하려고 실행 요청을 보류했습니다.'};
    if(!active){
      await new Promise((resolve,reject)=>{
        let child,settled=false;
        const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve();};
        const timer=setTimeout(()=>finish(Error('OBS 실행 요청 확인 시간 초과')),timeoutMs);
        try{
          child=spawn(exe,ARGS,{cwd:path.win32.dirname(exe),detached:true,stdio:'ignore',windowsHide:true});
          child.once('error',finish);child.once('spawn',()=>{child.unref();finish();});
        }catch(error){finish(error);}
      });
    }
    return {...await status(),running:active,launchRequested:!active,
      note:active?'OBS가 이미 실행 중입니다. 기존 OBS 장면·설정은 변경하지 않았습니다.':'OBS 가상 카메라 실행을 요청했습니다. 준비에 잠시 걸릴 수 있습니다.'};
  }
  function ensure(action='ensure'){
    if(!['ensure','enable','disable','status'].includes(action))return Promise.reject(Error('허용되지 않은 OBS 요청'));
    if(action==='status')return status();
    if(pending)return action==='ensure'?pending:pending.catch(()=>{}).then(()=>ensure(action));
    pending=work(action).finally(()=>{pending=null;});
    return pending;
  }
  return {ensure};
}
module.exports={createObsAutomation,ARGS};
