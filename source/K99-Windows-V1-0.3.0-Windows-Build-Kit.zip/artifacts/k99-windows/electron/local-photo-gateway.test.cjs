'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createMobilePhotoController}=require('./mobile-photo-controller.cjs');
const {createCareLabelController}=require('./care-label-controller.cjs');
const {createAutomaticTags}=require('./automatic-tag-controller.cjs');
const {createLocalPhotoGateway}=require('./local-photo-gateway.cjs');
const JPEG=Buffer.concat([Buffer.from([255,216,255]),Buffer.alloc(100,42),Buffer.from([255,217])]);
const ANALYSIS={status:'success',error:'',materialTag:'면60 N40',material_group:'나일론',wash_method:'물세탁',color:'검정',
  basket:{no:'바구니 4',name:'유색 · 나일론 바구니',color:'#DD6B20'}};
function fixture(t,{autoStart=true}={}){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-local-photo-')),store=createStore(path.join(root,'k99.db'),'test-only',{nativeDesktop:true});
  const photosRoot=path.join(root,'01_고객세탁사진'),jobs=[];fs.mkdirSync(photosRoot);
  store.equipment.configure({mode:'real',printerName:'TSC TE210',labelWidthMm:60,labelHeightMm:40,labelVerified:true,
    cameraDeviceId:'test-camera',hardwareConfirmed:true},true);
  const target={orderId:'local-photo-order-1',unitKey:'1:1',itemId:'shirt',itemName:'셔츠',customerName:'사진검사',customerPhone:'01000001234'};
  store.storage({op:'set',key:'k99-active-staff-intake-v1',expected:null,value:JSON.stringify({draftId:target.orderId,
    data:{customerName:target.customerName,customerPhone:target.customerPhone,rows:[{id:1,itemId:'shirt',quantity:1}]}})});
  const archive=createPhotoArchive({getRoot:()=>root,openPath:async()=>'',encodeJpeg:()=>JPEG});
  const adapters={native:true,archivePhoto:archive.photo,print:async job=>{jobs.push(job);}};
  const api=createEquipmentApi(store,adapters),gateway=createLocalPhotoGateway({store,roots:[photosRoot]});
  let auto,calls=0;
  const labels=createCareLabelController({store,equipmentApi:api,photoGateway:gateway,native:true,
    classify:async bytes=>{calls++;assert.deepEqual(bytes,JPEG);return ANALYSIS;},onResult:r=>auto.onAnalysis(r)});
  auto=createAutomaticTags({store,equipmentApi:api,labels});
  Object.assign(adapters,{deferDraftTag:()=>true,beforeDraftCapture:auto.beforeCapture,afterDraftCapture:auto.afterCapture});
  const bridge=createMobilePhotoController({store,equipmentApi:api,archivePhoto:archive.photo,native:true,
    onMobileSaved:(input,result)=>{if(autoStart)labels.onMobileSaved(input,result);},
    nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:1,height:1})})},
    host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1']});
  adapters.archivePhoto=bridge.archivePhoto;
  t.after(()=>{labels.close();bridge.close();store.close();fs.rmSync(root,{recursive:true,force:true});});
  const saveOrder=garments=>{
    const value=[{id:target.orderId,customerName:target.customerName,customerPhone:target.customerPhone,
      createdAt:'2026-11-09T02:00:00.000Z',items:[{displayNameKo:'셔츠',quantity:1}],estimatedTotal:3000,laundryTotal:3000,
      garments:garments.map(g=>({...g,sequence:1,itemIndex:1,unitIndex:1,totalSequence:1}))}];
    store.storage({op:'set',key:'k99-confirmed-orders-v1',expected:store.storage({op:'get',key:'k99-confirmed-orders-v1'}),value:JSON.stringify(value)});
  };
  return {root,photosRoot,store,api,gateway,labels,auto,jobs,target,saveOrder,get calls(){return calls;},
    pc:()=>api.api('POST','/api/equipment/command',{...target,action:'capture-draft',expectedMode:'real',
      requestId:'pc-local-photo-001',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`}),
    async mobile(){
      const s=await bridge.api('POST','/api/mobile-photo/start',target),u=new URL(s.urls[0]);
      const r=await fetch(`${u.origin}/api/upload-mobile-photo`,{method:'POST',headers:{'Content-Type':'image/jpeg',
        'X-K99-Session-Token':u.searchParams.get('token'),'X-K99-Upload-Id':'mobile-local-photo-001'},body:JPEG});
      assert.equal(r.status,200);await r.json();
      const garment=store.equipment.drafts.state(target.orderId).units[0].garment;
      const photo=garment.photoHistory.find(p=>/^MOBILE_/.test(p.archiveFile||''));
      await bridge.api('POST','/api/mobile-photo/stop',{id:s.id});
      return {garment,photoId:photo.sourcePhotoId};
    }};
}
function legacy(t){
  const f=fixture(t,{autoStart:false}),folder=path.join(f.photosRoot,'20261109_사진검사_1234');fs.mkdirSync(folder);
  const filename=path.join(folder,'MOBILE_001.jpg');fs.writeFileSync(filename,JPEG);
  const garment={garmentId:'legacy-garment-001',orderId:f.target.orderId,itemName:'셔츠',photoStatus:'saved',photoPath:filename,
    photoHistory:[{garmentId:'legacy-garment-001',role:'intake',status:'saved',origin:'bridge',
      requestId:'legacy-photo-request',sourcePhotoId:'legacy-photo-source',path:filename,timestamp:'2026-11-09T02:00:00.000Z'}]};
  f.saveOrder([garment]);
  return {...f,filename,garment,input:{orderId:f.target.orderId,garmentId:garment.garmentId,photoId:'legacy-photo-source'}};
}
test('native k99 protocol serves canonical bytes and HEAD without legacy helper or file URLs',async t=>{
  const f=fixture(t),capture=await f.pc(),p=capture.garment.photoHistory[0];
  const source=f.gateway.source({photoId:p.sourcePhotoId,orderId:f.target.orderId,garmentId:p.garmentId});
  assert.match(source.url,/^k99:\/\/app\/api\/equipment\/photos\//);assert.equal(source.careLabelEligible,false);
  const response=await f.gateway.response(new Request(source.url));
  assert.equal(response.status,200);assert.equal(response.headers.get('Content-Type'),'image/jpeg');
  assert.deepEqual(Buffer.from(await response.arrayBuffer()),JPEG);
  const head=await f.gateway.response(new Request(source.url,{method:'HEAD'}));
  assert.equal((await head.arrayBuffer()).byteLength,0);
  assert.throws(()=>f.gateway.analysisTarget(p.sourcePhotoId),/케어라벨/);
});
test('mobile save + image load + tab reopen share one analysis and one tag with bound fields',async t=>{
  const f=fixture(t);await f.pc();const mobile=await f.mobile();
  const source=f.gateway.source({photoId:mobile.photoId,orderId:f.target.orderId,garmentId:mobile.garment.garmentId});
  assert.equal(source.careLabelEligible,true);
  await Promise.all([1,2,3].map(()=>f.labels.analyze(source.photoId,{automatic:true})));
  assert.equal(f.calls,1);assert.equal(f.jobs.length,1);
  assert.equal(f.jobs[0].payload.material_group,'나일론');assert.equal(f.jobs[0].payload.wash_method,'물세탁');
  const final=await f.auto.finalize(f.target.orderId);
  assert.equal(final.units[0].garment.color,'검정');assert.equal(final.units[0].garment.photoHistory.length,2);
  await f.labels.analyze(source.photoId,{automatic:true});assert.equal(f.calls,1);assert.equal(f.jobs.length,1);
});
test('registered historical D-folder reference uses opaque local URL and survives grant reset without file mutation',async t=>{
  const f=legacy(t),before=crypto.createHash('sha256').update(fs.readFileSync(f.filename)).digest('hex');
  const source=f.gateway.source(f.input);
  assert.match(source.url,/^k99:\/\/app\/local-photos\/local-/);assert.ok(!source.url.includes(f.filename));
  assert.equal(source.careLabelEligible,true);
  f.gateway.reset();
  assert.deepEqual(f.gateway.read(source.photoId,f.input),{bytes:JPEG,contentType:'image/jpeg'});
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(f.filename)).digest('hex'),before);
  assert.equal(f.store.status().orderCount,1);
});
test('unregistered paths, wrong garment, tampered path and symlink escapes cannot expose disk files',async t=>{
  const f=legacy(t);
  assert.throws(()=>f.gateway.source({...f.input,garmentId:'another-garment'}),/연결된 사진/);
  assert.throws(()=>f.gateway.source({...f.input,photoId:'missing-photo-id',pathHint:f.filename}),/연결된 사진/);
  assert.throws(()=>f.gateway.source({pathHint:path.join(f.root,'k99.db')}),/연결된 사진/);
  fs.rmSync(f.filename);const outside=path.join(f.root,'private.jpg');fs.writeFileSync(outside,JPEG);
  fs.symlinkSync(outside,f.filename);
  assert.throws(()=>f.gateway.source(f.input),/링크·정션/);
  for(const request of [new Request('k99://other/local-photos/abcdefgh'),
    new Request('k99://app/local-photos/abcdefgh?path=D:/secret'),
    new Request('k99://app/local-photos/abcdefgh',{method:'POST'})])
    assert.equal((await f.gateway.response(request)).status,403);
});
test('canonical hash corruption is not bypassed; legacy hash mismatch fails closed',async t=>{
  const f=fixture(t),capture=await f.pc(),p=capture.garment.photoHistory[0];
  const corrupt=()=>{throw Object.assign(Error('사진 무결성 불일치'),{status:409});};
  const old=f.store.equipment.photoFile;f.store.equipment.photoFile=corrupt;
  assert.throws(()=>f.gateway.source({photoId:p.sourcePhotoId}),e=>e.status===409);
  f.store.equipment.photoFile=old;
  const g=legacy(t),orders=JSON.parse(g.store.storage({op:'get',key:'k99-confirmed-orders-v1'}));
  orders[0].garments[0].photoHistory[0].sha256='0'.repeat(64);
  const expected=g.store.storage({op:'get',key:'k99-confirmed-orders-v1'});
  g.store.storage({op:'set',key:'k99-confirmed-orders-v1',expected,value:JSON.stringify(orders)});
  assert.throws(()=>g.gateway.source(g.input),e=>e.status===409);
});
test('analysis after confirmation commits only garment analysis fields and does not reprint an existing tag',async t=>{
  const f=fixture(t,{autoStart:false}),mobile=await f.mobile(),ready=await f.auto.finalize(f.target.orderId);
  f.saveOrder(ready.units.map(u=>u.garment));
  const result=await f.labels.analyze(mobile.photoId,{automatic:true});
  assert.equal(result.status,'success');
  const order=f.store.equipment.getOrder(f.target.orderId);
  assert.equal(order.garments[0].material_group,'나일론');assert.equal(order.garments[0].wash_method,'물세탁');
  assert.equal(order.estimatedTotal,3000);assert.equal(order.garments[0].photoHistory.length,1);
  assert.equal(f.store.status().orderCount,1);assert.equal(f.jobs.length,1);
});
test('review results are not billed again by automatic image reload; explicit staff retry remains available',async t=>{
  const f=legacy(t);let calls=0;
  const controller=createCareLabelController({store:f.store,equipmentApi:f.api,photoGateway:f.gateway,native:true,
    classify:async()=>{calls++;return {...ANALYSIS,status:'review',materialTag:'',basket:null};}});
  t.after(()=>controller.close());
  const source=f.gateway.source(f.input);
  const key='k99-care-label-analysis-v1';
  f.store.storage({op:'set',key,expected:f.store.storage({op:'get',key}),value:JSON.stringify({
    [source.photoId]:{...f.gateway.analysisTarget(source.photoId),id:source.photoId,status:'failed',
      createdAt:'2026-11-08T00:00:00.000Z',materialTag:'',basket:null,error:'previous photo bridge failed'},
  })});
  await controller.analyze(source.photoId,{automatic:true});
  await controller.analyze(source.photoId,{automatic:true});
  assert.equal(calls,1);
  await controller.analyze(source.photoId);assert.equal(calls,2);
});
