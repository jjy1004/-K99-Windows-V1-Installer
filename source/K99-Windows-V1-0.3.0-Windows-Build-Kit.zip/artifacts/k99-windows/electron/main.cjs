'use strict';
const {app, BrowserWindow, protocol, ipcMain, session, dialog, screen, safeStorage,globalShortcut,shell,nativeImage} = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const fsSync = require('node:fs');
const {createDesktopManager}=require('@workspace/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('@workspace/k99-local/equipment-api.cjs');
const {createNativeAdapters}=require('./equipment-native.cjs');
const {videoResponse}=require('./customer-video.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createCustomerPhotoLibrary}=require('./customer-photo-library.cjs');
const {createFootSwitch}=require('./foot-switch.cjs');
const {createMobilePhotoController}=require('./mobile-photo-controller.cjs');
const {createCustomerDirectoryExport}=require('./customer-directory-export.cjs');

protocol.registerSchemesAsPrivileged([{scheme:'k99', privileges:{
  standard:true, secure:true, supportFetchAPI:true, corsEnabled:true,stream:true,
}}]);
app.commandLine.appendSwitch('autoplay-policy','no-user-gesture-required');
app.setName('K99-Windows-V1');
if(process.platform==='win32')app.setAppUserModelId('com.k99.windows.v1');
// Outside installed application files; never shared with legacy helpers.
const userData = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'K99WindowsV1');
fsSync.mkdirSync(userData,{recursive:true,mode:0o700});
app.setPath('userData', userData);
const locked = app.requestSingleInstanceLock();
if (!locked) app.quit();
let store, manager, mainWindow, adapters, equipmentApi,backupTimer,mobilePhotoBridge;
const customerPhotoLibrary=createCustomerPhotoLibrary({openPath:folder=>shell.openPath(folder)});
const changed=()=>{
  if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('k99:changed');
  adapters?.notify();
};
const trusted = event => {
  const url = new URL(event.senderFrame?.url || 'about:blank');
  if (url.protocol !== 'k99:' || url.host !== 'app' || event.senderFrame !== event.sender.mainFrame)
    throw Object.assign(new Error('허용되지 않은 호출'), {status:403});
  if(event.sender!==mainWindow?.webContents&&!adapters?.isCustomer(event.sender))
    throw Object.assign(new Error('알 수 없는 창'),{status:403});
};
const result = fn => {
  try {return {ok:true,result:fn()};}
  catch(error) {return {ok:false,error:error.message,status:error.status || 500};}
};
app.on('second-instance',() => {mainWindow?.restore(); mainWindow?.focus();});
app.on('window-all-closed',() => app.quit());
app.on('will-quit',() => {mobilePhotoBridge?.close();clearInterval(backupTimer);store?.close();});
if (locked) app.whenReady().then(() => {
  const publicRoot = path.resolve(__dirname, '../dist/desktop');
  const devVideos=path.join(__dirname,'../media/videos');
  const videoRoot=app.isPackaged?path.join(process.resourcesPath,'videos'):
    fsSync.existsSync(devVideos)?devVideos:path.resolve(__dirname,'../../../generated-artifacts/customer-videos');
  if(process.platform==='win32'&&!safeStorage.isEncryptionAvailable())throw Error('Windows 백업 키 보호(DPAPI)를 사용할 수 없습니다. 기존 데이터는 보존됩니다.');
  const installedData=path.join(app.getPath('userData'),'data');
  if(fsSync.existsSync(path.join(installedData,'k99.db'))&&fsSync.existsSync(path.join(installedData,'k99.sqlite')))
    throw Error('기존 DB 두 개를 발견했습니다. 데이터를 보존하고 관리자 확인 후 재시작하세요.');
  manager=createDesktopManager(app.getPath('userData'),{mode:'electron-desktop',
    dbName:fsSync.existsSync(path.join(installedData,'k99.sqlite'))?'k99.sqlite':'k99.db',nativeDesktop:true,
    vault:process.platform==='win32'?{
      encrypt:value=>safeStorage.encryptString(value).toString('base64'),
      decrypt:value=>safeStorage.decryptString(Buffer.from(value,'base64')),
    }:undefined});
  store=manager.store;
  backupTimer=setInterval(()=>{try{manager.automatic();}catch{/* Reported via maintenance status. */}},60000);
  backupTimer.unref();
  const maintenanceAdapters={
    native:process.platform==='win32',packaged:app.isPackaged,
    autostart:()=>({supported:process.platform==='win32'&&app.isPackaged,
      enabled:process.platform==='win32'&&app.isPackaged?app.getLoginItemSettings().openAtLogin:false}),
    setAutostart:enabled=>{
      app.setLoginItemSettings({openAtLogin:enabled,path:process.execPath,args:['--k99-autostart']});
      if(app.getLoginItemSettings().openAtLogin!==enabled)throw Error('Windows 자동 실행 설정을 확인하지 못했습니다.');
    },
    pickImport:async()=>{
      const r=await dialog.showOpenDialog(mainWindow,{title:'K99 통합 백업 선택',
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}],properties:['openFile']});
      return r.canceled?null:r.filePaths[0];
    },
    pickExport:async name=>{
      const r=await dialog.showSaveDialog(mainWindow,{title:'K99 백업 외부 사본 저장',defaultPath:name,
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}]});
      return r.canceled?null:r.filePath;
    },
  };
  const exportCustomerDirectory=createCustomerDirectoryExport({pickFile:async name=>{
    const r=await dialog.showSaveDialog(mainWindow,{title:'고객 명부·접수 이력 CSV 저장',
      defaultPath:path.join(app.getPath('downloads'),name),
      filters:[{name:'Excel 호환 CSV (UTF-8)',extensions:['csv']}],properties:['showOverwriteConfirmation']});
    return r.canceled?null:r.filePath;
  }});
  session.defaultSession.webRequest.onBeforeRequest((details, callback) => {
    // Fail closed: no HTTP(S), old local helpers, remote APIs or websocket.
    callback({cancel:!details.url.startsWith('k99://app/')});
  });
  session.defaultSession.setPermissionRequestHandler((wc,permission,callback,details) =>
    callback(!!(wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'
      &&details.mediaTypes?.includes('video')&&!details.mediaTypes?.includes('audio'))));
  session.defaultSession.setPermissionCheckHandler((wc,permission,_origin,details) =>
    wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'&&details.mediaType==='video');
  session.defaultSession.on('will-download', event => event.preventDefault());
  protocol.handle('k99', async request => {
    const url = new URL(request.url);
    if (url.host !== 'app' || !['GET','HEAD'].includes(request.method)) return new Response('Forbidden',{status:403});
    if(url.pathname.startsWith('/videos/'))
      return videoResponse(request,videoRoot);
    if(url.pathname.startsWith('/api/equipment/photos/')) {
      try {
        const photo=store.equipment.photoFile(url.pathname.slice('/api/equipment/photos/'.length));
        return new Response(photo.bytes,{headers:{'Content-Type':photo.contentType,'Cache-Control':'no-store'}});
      }catch(error){return new Response('사진 읽기 실패',{status:error.status||500});}
    }
    let pathname;
    try {pathname = decodeURIComponent(url.pathname);} catch {return new Response('Bad path',{status:400});}
    if (pathname.includes('\0')) return new Response('Bad path',{status:400});
    const candidate = path.resolve(publicRoot, '.' + pathname);
    if (candidate !== publicRoot && !candidate.startsWith(publicRoot + path.sep)) return new Response('Forbidden',{status:403});
    // BrowserRouter fallback only for extensionless routes.
    const file = path.extname(candidate) ? candidate : path.join(publicRoot,'index.html');
    try {
      const bytes = await fs.readFile(file);
      const mime = {'.html':'text/html; charset=utf-8','.js':'application/javascript',
        '.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg',
        '.woff2':'font/woff2','.mp4':'video/mp4'};
      const headers = new Headers({'Content-Type':mime[path.extname(file)] || 'application/octet-stream'});
      headers.set('Content-Security-Policy',
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'");
      return new Response(bytes,{status:200,headers});
    } catch {return new Response('파일을 찾지 못했습니다.',{status:404});}
  });
  ipcMain.on('k99:storage',(event,input) => {
    event.returnValue = result(() => {
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Object.assign(new Error('고객 창은 읽기 전용입니다.'),{status:403});
      const output=store.storage(input);
      if(input.op==='set'&&['k99-confirmed-orders-v1','k99-laundry-display-state'].includes(input.key))
        queueMicrotask(()=>adapters?.notify());
      return output;
    });
  });
  ipcMain.handle('k99:search-customers',(event,keyword)=>{
    try{
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 고객을 검색할 수 있습니다.');
      if(typeof keyword!=='string'||keyword.length>100)throw Error('고객 검색어 형식 오류');
      return {success:true,...store.api('GET',`/api/customers/search?q=${encodeURIComponent(keyword)}`)};
    }catch(error){return {success:false,error:error.message||'고객 검색 실패',customers:[]};}
  });
  ipcMain.handle('k99:customer-photos',async(event,input)=>{
    try{
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 사진을 조회할 수 있습니다.');
      if(input?.action==='list'&&typeof input.customerId==='string'&&/^[a-f0-9]{64}$/.test(input.customerId)){
        const {customer}=store.api('GET',`/api/customers/${input.customerId}/history`);
        return {success:true,...await customerPhotoLibrary.list(customer)};
      }
      if(input?.action==='open'&&typeof input.token==='string')return {success:true,...await customerPhotoLibrary.open(input.token)};
      throw Error('고객 사진 요청 형식 오류');
    }catch(error){return {success:false,error:error.message||'고객 사진 조회 실패'};}
  });
  ipcMain.handle('k99:import-customer-ledger',async(event)=>{
    try{
      trusted(event);
      if(event.sender!==mainWindow.webContents)
        throw Error('직원 창에서만 고객 장부를 가져올 수 있습니다.');
      const selected=await dialog.showOpenDialog(mainWindow,{title:'고객 장부 엑셀 파일 불러오기',
        properties:['openFile'],filters:[{name:'Excel',extensions:['xlsx','xls','csv']}]});
      if(selected.canceled||selected.filePaths.length!==1)return {success:false,cancelled:true};
      const result=await manager.importLedger(selected.filePaths[0]);
      mainWindow.webContents.send('k99:changed');
      adapters?.notify();
      return result;
    }catch(error){return {success:false,error:error.message||'고객 장부를 저장하지 못했습니다.'};}
  });
  ipcMain.handle('k99:request',async(event,input) => {
    try {
    trusted(event);
    if (!input || !['GET','POST','PUT'].includes(input.method) || typeof input.path !== 'string')
      throw Object.assign(new Error('잘못된 요청'),{status:400});
    if(event.sender!==mainWindow.webContents&&!(input.method==='GET'&&input.path==='/api/equipment/display'))
      throw Object.assign(new Error('고객 창은 안내 정보만 조회할 수 있습니다.'),{status:403});
    const value=input.method==='POST'&&input.path==='/api/customer-directory/export'
      ?await exportCustomerDirectory(input.body)
      :input.path.startsWith('/api/mobile-photo/')
      ?await mobilePhotoBridge.api(input.method,input.path,input.body)
      :input.path.startsWith('/api/maintenance/')
      ?await manager.api(input.method,input.path,input.body,maintenanceAdapters)
      :input.path.startsWith('/api/equipment/')
        ?await equipmentApi.api(input.method,input.path,input.body):await store.api(input.method,input.path,input.body);
    if(value?.restored){
      adapters.closeCustomer();
      // Discard stale renderer order snapshots, drafts and privileged forms.
      setTimeout(()=>{if(!mainWindow.isDestroyed())mainWindow.loadURL('k99://app/');},500);
    }
    if(input.method!=='GET')changed();
    return {ok:true,result:value};
    }catch(error){return {ok:false,error:error.message,status:error.status||500};}
  });
  ipcMain.handle('customer-status',event=>{trusted(event);return adapters.displayStatus();});
  const footSwitch=createFootSwitch({globalShortcut,getMain:()=>mainWindow});
  app.on('will-quit',()=>footSwitch.dispose());
  ipcMain.handle('k99:foot-active',(event,input)=>{
    trusted(event);
    if(event.sender!==mainWindow?.webContents)throw Error('직원 창만 촬영 단축키를 설정할 수 있습니다.');
    return footSwitch.set(input);
  });
  ipcMain.on('customer-action',(event,data)=>{
    try{trusted(event);if(event.sender!==mainWindow?.webContents)throw Error('직원 화면만 명령을 전송할 수 있습니다.');adapters.action(data);}
    catch(error){event.sender.send('customer-connection',{type:'COMMAND_ERROR',commandId:data?.command?.id,error:error.message});}
  });
  ipcMain.on('customer-event',(event,data)=>{
    try{trusted(event);adapters.customerEvent(event.sender,data);}catch{/* Reject untrusted senders. */}
  });
  mainWindow = new BrowserWindow({
    title:'K99 스마트 접수 시스템 — Windows V1',width:1440,height:960,minWidth:1100,minHeight:740,
    icon:app.isPackaged?path.join(__dirname,'assets/k99-reception.ico'):path.join(__dirname,'../installer/k99-reception.ico'),
    autoHideMenuBar:true, backgroundColor:'#eeeae3',
    webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,
      sandbox:true,webSecurity:true,webviewTag:false},
  });
  adapters=createNativeAdapters({BrowserWindow,screen,session,store,getMain:()=>mainWindow,
    preload:path.join(__dirname,'preload.cjs'),changed,
    preferencesFile:path.join(app.getPath('userData'),'customer-display.json')});
  const archive=createPhotoArchive({getRoot:()=> 'D:\\K99과천매장',
    openPath:folder=>shell.openPath(folder),encodeJpeg:bytes=>{
      const image=nativeImage.createFromBuffer(bytes);
      if(image.isEmpty())throw Error('촬영 이미지를 디코딩할 수 없습니다.');
      return image.toJPEG(90);
    }});
  Object.assign(adapters,{archivePhoto:archive.photo,archiveComparison:archive.comparison,openPhotoFolder:archive.open});
  equipmentApi=createEquipmentApi(store,adapters);
  mobilePhotoBridge=createMobilePhotoController({store,equipmentApi,archivePhoto:archive.photo,nativeImage,changed});
  adapters.archivePhoto=mobilePhotoBridge.archivePhoto;
  mainWindow.webContents.setWindowOpenHandler(({url}) => {
    // The original customer's popup is replaced by the explicit monitor picker.
    if(url==='k99://app/customer')mainWindow.webContents.send('k99:changed');
    return {action:'deny'};
  });
  mainWindow.on('closed',()=>{footSwitch.dispose();adapters.closeCustomer(false);});
  mainWindow.webContents.on('render-process-gone',()=>footSwitch.dispose());
  mainWindow.webContents.on('did-start-loading',()=>footSwitch.dispose());
  mainWindow.webContents.on('did-start-loading',()=>mobilePhotoBridge.close());
  mainWindow.webContents.on('render-process-gone',()=>mobilePhotoBridge.close());
  mainWindow.on('closed',()=>mobilePhotoBridge.close());
  mainWindow.webContents.on('will-navigate',(event,url) => {
    if (!url.startsWith('k99://app/')) event.preventDefault();
  });
  return mainWindow.loadURL('k99://app/').then(()=>adapters.restore().catch(error=>{
    mainWindow.webContents.send('customer-connection',{type:'CONNECTION',connected:false,error:error.message});
  }));
}).catch(error => {
  dialog.showErrorBox('K99-Windows-V1 시작 실패',error.message + '\n기존 데이터를 삭제하지 말고 지원을 요청하세요.');
  app.quit();
});
