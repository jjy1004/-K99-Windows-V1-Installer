'use strict';
const {app, BrowserWindow, protocol, ipcMain, session, dialog, screen, safeStorage,globalShortcut,shell,nativeImage,clipboard} = require('electron');
const {createAutoMessenger}=require('./services/autoMessenger.js');
const {createNoticeMobile}=require('./notice-mobile.cjs');
const {createSmartphoneCamera,createIriunLifecycle}=require('./smartphone-camera.cjs');
const path = require('node:path');
const fs = require('node:fs/promises');
const fsSync = require('node:fs');
const {createDesktopManager}=require('@workspace/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('@workspace/k99-local/equipment-api.cjs');
const {createNativeAdapters}=require('./equipment-native.cjs');
const {videoResponse}=require('./customer-video.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createCustomerPhotoLibrary}=require('./customer-photo-library.cjs');
const {createFootSwitch}=require('./foot-switch.cjs');
const {createMobilePhotoController}=require('./mobile-photo-controller.cjs');
const {createComparisonMobilePhotos}=require('./comparison-mobile-photo.cjs');
const {createPhotoRetention}=require('@workspace/k99-local/photo-retention.cjs');
const {createComparisonGallery,createComparisonGalleryApi}=require('@workspace/k99-local/comparison-gallery.cjs');
const {createCustomerDirectoryExport}=require('./customer-directory-export.cjs');
const {createCareLabelController}=require('./care-label-controller.cjs');
const {classifyCareLabel}=require('./services/labelService.cjs');
const {createAutomaticTags}=require('./automatic-tag-controller.cjs');
const {createLocalPhotoGateway}=require('./local-photo-gateway.cjs');
const {prepareStorageLayoutAsync,discoverDrivesAsync,changeStorageRoot,layoutStatus,assertStorageChangeAllowed}=require('./storage-layout.cjs');
const {applyStartupPreference}=require('./startup-policy.cjs');
const {createIdleVideos}=require('./idle-videos.cjs');
const {createProgramLauncher,SETTINGS_KEY,settingsWithDefaults}=require('./program-integrations.cjs');
const {createAiAccountVault}=require('./ai-account-vault.cjs');
const {createAiSession}=require('./ai-session.cjs');
const {startLocalDesktop}=require('./local-startup.cjs');
const {configureWindowsRendering}=require('./windows-compatibility.cjs');
const {createAutoUpdate}=require('./auto-update.cjs');
const {createUpdateNotice}=require('./update-notice.cjs');

configureWindowsRendering(app);

protocol.registerSchemesAsPrivileged([{scheme:'k99', privileges:{
  standard:true, secure:true, supportFetchAPI:true, corsEnabled:true,stream:true,
}}]);
app.commandLine.appendSwitch('autoplay-policy','no-user-gesture-required');
app.setName('K99-Laundry-V2');
if(process.platform==='win32')app.setAppUserModelId('com.k99.windows.v1');
// Outside installed application files; never shared with legacy helpers.
const userData = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'K99WindowsV1');
fsSync.mkdirSync(userData,{recursive:true,mode:0o700});
app.setPath('userData', userData);
const locked = app.requestSingleInstanceLock();
if (!locked) app.quit();
let store, manager, mainWindow, adapters, equipmentApi,backupTimer,mobilePhotoBridge,careLabels,automaticTags,localPhotos,noticeMobile;
let messengerOps=0;
let customerPhotoLibrary,comparisonMobilePhotos,photoRetention,retentionStartTimer,comparisonGallery,comparisonGalleryApi;
let storageChanging=false,activeWrites=0;
let updates,updateNotice,updateSessionUsed=false;
const changed=()=>{
  updateSessionUsed=true;
  updates?.noteUserActivity();
  if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('k99:changed');
  adapters?.notify();
};
const trusted = event => {
  const url = new URL(event.senderFrame?.url || 'about:blank');
  if (url.protocol !== 'k99:' || url.host !== 'app' || event.senderFrame !== event.sender.mainFrame)
    throw Object.assign(new Error('허용되지 않은 호출'), {status:403});
  if(event.sender!==mainWindow?.webContents&&!adapters?.isCustomer(event.sender))
    throw Object.assign(new Error('알 수 없는 창'),{status:403});
};
const result = fn => {
  try {return {ok:true,result:fn()};}
  catch(error) {return {ok:false,error:error.message,status:error.status || 500};}
};
app.on('second-instance',() => {mainWindow?.restore(); mainWindow?.focus();});
app.on('window-all-closed',() => app.quit());
app.on('will-quit',() => {updates?.dispose();updateNotice?.close();noticeMobile?.close();careLabels?.close();mobilePhotoBridge?.close();comparisonMobilePhotos?.close();clearTimeout(retentionStartTimer);clearInterval(backupTimer);store?.close();});
if (locked) app.whenReady().then(async () => {
  const publicRoot = path.resolve(__dirname, '../dist/desktop');
  const devVideos=path.join(__dirname,'../media/videos');
  const videoRoot=app.isPackaged?path.join(process.resourcesPath,'videos'):
    fsSync.existsSync(devVideos)?devVideos:path.resolve(__dirname,'../../../generated-artifacts/customer-videos');
  if(process.platform==='win32'&&!safeStorage.isEncryptionAvailable())throw Error('Windows 백업 키 보호(DPAPI)를 사용할 수 없습니다. 기존 데이터는 보존됩니다.');
  const installedData=path.join(app.getPath('userData'),'data');
  const storageLayout=process.platform==='win32'?await prepareStorageLayoutAsync(userData):null;
  if(storageLayout){
    try{
      require('./bundled-calculator.cjs').deployBundledCalculator(
        path.join(process.resourcesPath,'luxury-calculator'),storageLayout.program);
    }catch(error){console.error('동봉 계산기 배치 보류:',error.message);}
  }
  const previousLayouts=(storageLayout?.previousRoots||[]).map(root=>({
    intake:path.win32.join(root,'01_고객세탁사진'),compare:path.win32.join(root,'02_세탁전후사진')}));
  const idleVideos=createIdleVideos({folder:storageLayout?.videos,openPath:folder=>shell.openPath(folder)});
  customerPhotoLibrary=createCustomerPhotoLibrary({...(storageLayout?{roots:[storageLayout.intake,
    ...previousLayouts.map(x=>x.intake),'D:\\K99과천매장\\01_고객세탁사진','D:\\고객 세탁 사진']}:{}),openPath:folder=>shell.openPath(folder)});
  if(fsSync.existsSync(path.join(installedData,'k99.db'))&&fsSync.existsSync(path.join(installedData,'k99.sqlite')))
    throw Error('기존 DB 두 개를 발견했습니다. 데이터를 보존하고 관리자 확인 후 재시작하세요.');
  const localDbName=fsSync.existsSync(path.join(installedData,'k99.sqlite'))?'k99.sqlite':'k99.db';
  manager=createDesktopManager(app.getPath('userData'),{mode:'electron-desktop',
    dbName:localDbName,nativeDesktop:true,
    ...(storageLayout?{backupDir:storageLayout.backup,archiveRoot:storageLayout.root}:{}),
    vault:process.platform==='win32'?{
      encrypt:value=>safeStorage.encryptString(value).toString('base64'),
      decrypt:value=>safeStorage.decryptString(Buffer.from(value,'base64')),
    }:undefined});
  store=manager.store;
  try{store.ensurePresentationCustomer();}
  catch(error){console.error('시연 고객 초기 등록 실패 (기존 데이터는 보존됩니다):',error.message);}
  const autoMessenger=createAutoMessenger({shell,clipboard});
  // 화면 생성·로컬 접수를 기다리게 하지 않는다. 미설치·보안 프로그램 지연은 조용히 무시한다.
  app.once('browser-window-created',()=>{void autoMessenger.ensureKakao();});
  const smartphoneCamera=createSmartphoneCamera({shell});
  ipcMain.handle('k99:camera-connection',async(event,action)=>{trusted(event);return smartphoneCamera(action);});
  const iriun=createIriunLifecycle();
  void iriun.ensureReceiver();
  ipcMain.handle('k99:iriun-session',async(event,input)=>{trusted(event);return iriun.session(input);});
  noticeMobile=createNoticeMobile({getNotices:()=>store.notices,changed});
  ipcMain.handle('k99:messenger',async(event,input)=>{
    let ticket,writing=false;
    try{
      trusted(event);if(event.sender!==mainWindow.webContents)throw Error('직원 화면에서만 사용할 수 있습니다.');
      if(input?.action!=='dispatch')return await autoMessenger.command(input);
      if(storageChanging||messengerOps)throw Error('다른 저장·발송 작업이 끝난 뒤 다시 시도해 주세요.');
      messengerOps++;activeWrites++;writing=true;
      ticket=store.notices.reserve(input);
      if(ticket.duplicate)return {success:false,attemptId:ticket.attempt.id,status:'unconfirmed',manualRequired:true,
        detail:'이미 처리한 요청입니다. 외부 앱의 입력·발송 상태를 확인해 주세요.'};
      return store.notices.finish(ticket.attempt.id,await autoMessenger.dispatch(ticket.notice,input.mode));
    }catch(e){
      const result={success:false,status:'unconfirmed',manualRequired:true,error:e.message};
      if(ticket&&!ticket.duplicate)try{return store.notices.finish(ticket.attempt.id,result);}catch{}
      return result;
    }finally{if(writing){messengerOps--;activeWrites--;}}
  });
  photoRetention=createPhotoRetention({store,native:process.platform==='win32',
    filename:path.join(manager.status().dataLocation,localDbName),
    intakeRoot:storageLayout?.intake||path.join(userData,'inactive','01_고객세탁사진')});
  const automaticPhotoCleanup=()=>{
    try{
      const previous=photoRetention.status().lastResult?.at;
      void photoRetention.run({automatic:true}).then(r=>{
        if(r.lastResult?.at!==previous)changed();
      }).catch(error=>console.error('접수 사진 자동 정리 실패:',error.message));
    }catch(error){console.error('접수 사진 자동 정리 보류:',error.message);}
  };
  if(process.platform==='win32'){
    retentionStartTimer=setTimeout(automaticPhotoCleanup,10000);retentionStartTimer.unref();
  }
  const aiAccount=createAiAccountVault({userData,safeStorage});
  const aiSession=createAiSession({sessionData:app.getPath('sessionData'),vault:aiAccount});
  const programLauncher=createProgramLauncher({
    readSettings:()=>settingsWithDefaults(JSON.parse(store.storage({op:'get',key:SETTINGS_KEY})||'null')),
    BrowserWindow,spawn:require('node:child_process').spawn,owner:()=>mainWindow,aiSession,
    resultFolder:path.join(userData,'calculator-results'),
    programFolder:storageLayout?.program,openFolder:folder=>shell.openPath(folder),
    onResult:value=>{if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('k99:luxury-result',value);},
  });
  ipcMain.handle('k99:storage-layout',async(event,input)=>{
    try{
      trusted(event);if(event.sender!==mainWindow.webContents)throw Error('직원 설정 화면에서만 사용할 수 있습니다.');
      if(!storageLayout)return {success:false,error:'저장 드라이브 자동 연결은 Windows 앱에서 사용할 수 있습니다.'};
      if(input?.action==='status')return {success:true,...layoutStatus(storageLayout)};
      if(input?.action!=='change')throw Error('허용되지 않은 저장 경로 요청입니다.');
      const check=()=>{
        const draft=JSON.parse(store.storage({op:'get',key:'k99-active-staff-intake-v1'})||'null');
        assertStorageChangeAllowed({changing:storageChanging,writes:activeWrites,draft});
      };
      check();
      const picked=await dialog.showOpenDialog(mainWindow,{title:'저장 드라이브 또는 K99 데이터 폴더 선택 — 기존 파일은 이동하지 않습니다',
        defaultPath:storageLayout.root,properties:['openDirectory','createDirectory']});
      if(picked.canceled||picked.filePaths.length!==1)return {success:false,cancelled:true};
      const confirmation=await dialog.showMessageBox(mainWindow,{type:'warning',title:'저장 드라이브 변경',
        message:'새 촬영·백업의 저장 위치를 변경하고 앱을 다시 시작합니다.',
        detail:'기존 DB와 사진은 이동·삭제하지 않습니다. 이전 사진 경로는 조회용으로 보존합니다.',
        buttons:['취소','변경 후 다시 시작'],defaultId:0,cancelId:0});
      if(confirmation.response!==1)return {success:false,cancelled:true};
      check();storageChanging=true;
      try{
        const drives=await discoverDrivesAsync();
        const next=changeStorageRoot(userData,picked.filePaths[0],{drives});
        if(!next.changed){storageChanging=false;return {success:true,...layoutStatus(storageLayout)};}
        setTimeout(()=>{app.relaunch();app.quit();},800);
        return {success:true,restarting:true,...layoutStatus(next)};
      }catch(error){storageChanging=false;throw error;}
    }catch(error){return {success:false,error:error.message};}
  });
  let authFlushedForQuit=false;
  app.on('before-quit',event=>{
    programLauncher.close();
    if(authFlushedForQuit){
      updates?.beforeQuit(event,()=>app.quit());
      return;
    }
    event.preventDefault();
    Promise.race([aiSession.flush().catch(()=>console.warn('AI 처방 세션의 최종 저장을 확인하지 못했습니다.')),
      new Promise(resolve=>setTimeout(resolve,2000))]).finally(()=>{authFlushedForQuit=true;app.quit();});
  });
  ipcMain.handle('k99:ai-account',(event,input)=>{
    try{
      trusted(event);if(event.sender!==mainWindow.webContents)throw Error('직원 설정 화면에서만 사용할 수 있습니다.');
      if(input?.action==='status')return {success:true,...aiAccount.status()};
      if(input?.action==='save')return {success:true,...aiAccount.save(input)};
      if(input?.action==='clear')return {success:true,...aiAccount.clear()};
      throw Error('허용되지 않은 계정 설정입니다.');
    }catch(error){return {success:false,error:error.message};}
  });
  ipcMain.handle('k99:open-program',async(event,input)=>{
    try{
      trusted(event);if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 프로그램을 열 수 있습니다.');
      const opened=await programLauncher.open(input?.kind,{material:input?.material,color:input?.color});
      return {success:true,...(opened.warning?{warning:opened.warning}:{})};
    }catch(error){return {success:false,error:error.message};}
  });
  ipcMain.handle('k99:calculator-result',(event,input)=>{
    try{return {success:true,result:programLauncher.receive(event,input)};}
    catch(error){return {success:false,error:error.message};}
  });
  comparisonGallery=createComparisonGallery({store,filename:path.join(manager.status().dataLocation,localDbName),
    compareRoot:storageLayout?.compare,compareRoots:previousLayouts.map(x=>x.compare),validateImage:bytes=>!nativeImage.createFromBuffer(bytes).isEmpty()});
  comparisonGalleryApi=createComparisonGalleryApi({gallery:comparisonGallery,getDisplay:()=>adapters});
  localPhotos=createLocalPhotoGateway({store,...(storageLayout?{roots:[storageLayout.intake,storageLayout.compare,
    ...previousLayouts.flatMap(x=>[x.intake,x.compare]),'D:\\K99과천매장\\01_고객세탁사진','D:\\K99과천매장\\02_세탁전후사진']}:{} )});
  // Respect a saved OFF preference on every later launch.
  if(process.platform==='win32'&&app.isPackaged){
    const pref=manager.startupPreference();
    try{applyStartupPreference(app,pref,process.execPath);}
    catch(error){console.error('Windows 자동 실행 등록 실패:',error.message);}
  }
  backupTimer=setInterval(()=>{
    try{manager.automatic();}catch{/* Reported via maintenance status. */}
    if(process.platform==='win32')try{automaticPhotoCleanup();}catch(error){console.error('접수 사진 정리 설정 확인 실패:',error.message);}
  },60000);
  backupTimer.unref();
  const maintenanceAdapters={
    native:process.platform==='win32',packaged:app.isPackaged,
    autostart:()=>({supported:process.platform==='win32'&&app.isPackaged,
      enabled:process.platform==='win32'&&app.isPackaged?app.getLoginItemSettings().openAtLogin:false}),
    setAutostart:enabled=>{
      app.setLoginItemSettings({openAtLogin:enabled,path:process.execPath,args:['--k99-autostart']});
      if(app.getLoginItemSettings().openAtLogin!==enabled)throw Error('Windows 자동 실행 설정을 확인하지 못했습니다.');
    },
    pickImport:async()=>{
      const r=await dialog.showOpenDialog(mainWindow,{title:'K99 통합 백업 선택',
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}],properties:['openFile']});
      return r.canceled?null:r.filePaths[0];
    },
    pickV1:async()=>{
      const answer=await dialog.showMessageBox(mainWindow,{type:'warning',title:'기존 V1 DB 가져오기',
        message:'현재 장부는 안전 백업 후 선택한 V1 장부로 전환됩니다. 합치기가 아닙니다.',
        detail:'기존 프로그램을 종료하고 DB와 같은 폴더의 photos 폴더를 함께 준비하세요. 원본 DB·사진은 변경하지 않습니다.',
        buttons:['취소','V1 DB 선택'],defaultId:0,cancelId:0});
      if(answer.response!==1)return null;
      const r=await dialog.showOpenDialog(mainWindow,{title:'기존 V1 DB 선택',properties:['openFile'],
        filters:[{name:'K99 V1 SQLite',extensions:['db','sqlite']}]});
      return r.canceled?null:r.filePaths[0];
    },
    pickExport:async name=>{
      const r=await dialog.showSaveDialog(mainWindow,{title:'K99 백업 외부 사본 저장',defaultPath:name,
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}]});
      return r.canceled?null:r.filePath;
    },
  };
  const exportCustomerDirectory=createCustomerDirectoryExport({authorize:password=>store.api('POST','/api/admin/password/check',{password}),pickFile:async name=>{
    const r=await dialog.showSaveDialog(mainWindow,{title:'고객 명부·접수 이력 CSV 저장',
      defaultPath:path.join(app.getPath('downloads'),name),
      filters:[{name:'Excel 호환 CSV (UTF-8)',extensions:['csv']}],properties:['showOverwriteConfirmation']});
    return r.canceled?null:r.filePath;
  }});
  session.defaultSession.webRequest.onBeforeRequest((details, callback) => {
    // Fail closed: no HTTP(S), old local helpers, remote APIs or websocket.
    callback({cancel:!details.url.startsWith('k99://app/')});
  });
  session.defaultSession.setPermissionRequestHandler((wc,permission,callback,details) =>
    callback(!!(wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'
      &&details.mediaTypes?.includes('video')&&!details.mediaTypes?.includes('audio'))));
  session.defaultSession.setPermissionCheckHandler((wc,permission,_origin,details) =>
    wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'&&details.mediaType==='video');
  session.defaultSession.on('will-download', event => event.preventDefault());
  protocol.handle('k99', async request => {
    const url = new URL(request.url);
    if (url.host !== 'app' || !['GET','HEAD'].includes(request.method)) return new Response('Forbidden',{status:403});
    if(url.pathname.startsWith('/videos/'))
      return videoResponse(request,videoRoot);
    if(url.pathname.startsWith('/idle-videos/'))
      return idleVideos.response(request);
    if(url.pathname.startsWith('/comparison-photos/'))
      return comparisonGallery.response(request);
    if(url.pathname.startsWith('/api/equipment/photos/')||url.pathname.startsWith('/local-photos/'))
      return localPhotos.response(request);
    let pathname;
    try {pathname = decodeURIComponent(url.pathname);} catch {return new Response('Bad path',{status:400});}
    if (pathname.includes('\0')) return new Response('Bad path',{status:400});
    const candidate = path.resolve(publicRoot, '.' + pathname);
    if (candidate !== publicRoot && !candidate.startsWith(publicRoot + path.sep)) return new Response('Forbidden',{status:403});
    // BrowserRouter fallback only for extensionless routes.
    const file = path.extname(candidate) ? candidate : path.join(publicRoot,'index.html');
    try {
      const bytes = await fs.readFile(file);
      const mime = {'.html':'text/html; charset=utf-8','.js':'application/javascript',
        '.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg',
        '.woff2':'font/woff2','.mp4':'video/mp4'};
      const headers = new Headers({'Content-Type':mime[path.extname(file)] || 'application/octet-stream'});
      headers.set('Content-Security-Policy',
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'");
      return new Response(bytes,{status:200,headers});
    } catch {return new Response('파일을 찾지 못했습니다.',{status:404});}
  });
  ipcMain.on('k99:storage',(event,input) => {
    event.returnValue = result(() => {
      trusted(event);
       if(storageChanging&&!['get','keys'].includes(input?.op))throw Error('저장 드라이브 변경 중입니다. 다시 시작할 때까지 기다려 주세요.');
      if(event.sender!==mainWindow.webContents)throw Object.assign(new Error('고객 창은 읽기 전용입니다.'),{status:403});
      automaticTags?.assertReadyForOrders(input);
      const output=store.storage(input);
      if(input.op==='set'&&['k99-confirmed-orders-v1','k99-laundry-display-state'].includes(input.key))
        queueMicrotask(()=>adapters?.notify());
      return output;
    });
  });
  ipcMain.handle('k99:search-customers',(event,keyword)=>{
    try{
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 고객을 검색할 수 있습니다.');
      if(typeof keyword!=='string'||keyword.length>100)throw Error('고객 검색어 형식 오류');
      return {success:true,...store.api('GET',`/api/customers/search?q=${encodeURIComponent(keyword)}`)};
    }catch(error){return {success:false,error:error.message||'고객 검색 실패',customers:[]};}
  });
  ipcMain.handle('k99:customer-photos',async(event,input)=>{
    try{
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 사진을 조회할 수 있습니다.');
      if(input?.action==='list'&&typeof input.customerId==='string'&&/^[a-f0-9]{64}$/.test(input.customerId)){
        const {customer}=store.api('GET',`/api/customers/${input.customerId}/history`);
        return {success:true,...await customerPhotoLibrary.list(customer)};
      }
      if(input?.action==='open'&&typeof input.token==='string')return {success:true,...await customerPhotoLibrary.open(input.token)};
      throw Error('고객 사진 요청 형식 오류');
    }catch(error){return {success:false,error:error.message||'고객 사진 조회 실패'};}
  });
  ipcMain.handle('k99:import-customer-ledger',async(event)=>{
    let writing=false;
    try{
      trusted(event);
      if(storageChanging)throw Error('저장 드라이브 변경 중입니다.');
      if(event.sender!==mainWindow.webContents)
        throw Error('직원 창에서만 고객 장부를 가져올 수 있습니다.');
      const selected=await dialog.showOpenDialog(mainWindow,{title:'고객 장부 엑셀 파일 불러오기',
        properties:['openFile'],filters:[{name:'Excel',extensions:['xlsx','xls','csv']}]});
      if(selected.canceled||selected.filePaths.length!==1)return {success:false,cancelled:true};
      if(storageChanging)throw Error('저장 드라이브 변경 중입니다.');
      activeWrites++;writing=true;
      const result=await manager.importLedger(selected.filePaths[0]);
      mainWindow.webContents.send('k99:changed');
      adapters?.notify();
      return result;
    }catch(error){return {success:false,error:error.message||'고객 장부를 저장하지 못했습니다.'};}
    finally{if(writing)activeWrites--;}
  });
  ipcMain.handle('k99:idle-videos',async(event,action)=>{
    try{
      trusted(event);
      if(!['list','refresh','open'].includes(action))throw Error('잘못된 영상 요청입니다.');
      if(action!=='list'&&event.sender!==mainWindow.webContents)throw Error('직원 창에서만 관리할 수 있습니다.');
      if(action==='open')return await idleVideos.open();
      const data=idleVideos.list();
      if(action==='refresh')for(const win of BrowserWindow.getAllWindows())
        if(!win.isDestroyed())win.webContents.send('k99:idle-videos-changed');
      return data;
    }catch(e){return {success:false,error:e.message,files:[]};}
  });
  ipcMain.handle('k99:customer-template',async(event)=>{
    try{
      trusted(event);if(event.sender!==mainWindow.webContents)throw Error('직원 창에서만 저장할 수 있습니다.');
      const r=await dialog.showSaveDialog(mainWindow,{title:'고객 엑셀 샘플 양식 저장',
        defaultPath:path.join(app.getPath('downloads'),'K99-고객-업로드-샘플.csv'),
        filters:[{name:'Excel 호환 CSV',extensions:['csv']}]});
      if(r.canceled||!r.filePath)return {success:false,cancelled:true};
      fsSync.writeFileSync(r.filePath,'\uFEFF고객명,휴대폰번호,주소,방문일,방문횟수,누적금액,메모\r\n샘플고객,010-0000-0000,예시 주소,2026-01-01,3,50000,샘플 행 삭제 후 입력\r\n');
      return {success:true};
    }catch(e){return {success:false,error:e.message};}
  });
  ipcMain.handle('k99:request',async(event,input) => {
    let writing=false;
    try {
    trusted(event);
    if(input?.method!=='GET'){
      if(storageChanging)throw Error('저장 드라이브 변경 중입니다.');
      activeWrites++;writing=true;
    }
    if (!input || !['GET','POST','PUT'].includes(input.method) || typeof input.path !== 'string')
      throw Object.assign(new Error('잘못된 요청'),{status:400});
    const scopedPath=new URL(input.path,'k99://app').pathname;
    if((scopedPath.startsWith('/api/notices/')||scopedPath.startsWith('/api/customers/'))&&event.sender!==mainWindow.webContents)
      throw Object.assign(Error('고객 안내와 매장 설정은 직원 화면에서만 사용할 수 있습니다.'),{status:403});
    if(input.method!=='GET'&&input.path.startsWith('/api/maintenance/')&&messengerOps)
      throw Error('고객 안내 입력·발송 확인 중에는 데이터 복구 작업을 시작할 수 없습니다.');
    if(event.sender!==mainWindow.webContents&&!(input.method==='GET'&&input.path==='/api/equipment/display'))
      throw Object.assign(new Error('고객 창은 안내 정보만 조회할 수 있습니다.'),{status:403});
    let value=input.method==='POST'&&input.path==='/api/notices/mobile/start'
      ?await noticeMobile.start({orderId:input.body?.orderId})
      :input.method==='GET'&&input.path==='/api/care-label/results'
      ?careLabels.list().map(r=>({...r,autoTag:automaticTags.state(r.orderId,r.unitKey)}))
      :input.method==='POST'&&input.path==='/api/care-label/finalize'
      ?await automaticTags.finalize(input.body?.orderId)
      :input.method==='POST'&&input.path==='/api/customer-directory/export'
      ?await exportCustomerDirectory(input.body)
      :input.path.startsWith('/api/photo-retention/')
      ?await photoRetention.api(input.method,input.path,input.body)
      :input.path.startsWith('/api/comparison-gallery/')
      ?await comparisonGalleryApi(input.method,input.path,input.body)
      :input.path.startsWith('/api/comparison-mobile/')
      ?await comparisonMobilePhotos.api(input.method,input.path,input.body)
      :input.path.startsWith('/api/mobile-photo/')
      ?await mobilePhotoBridge.api(input.method,input.path,input.body)
      :input.path.startsWith('/api/maintenance/')
      ?await manager.api(input.method,input.path,input.body,maintenanceAdapters)
      :input.path.startsWith('/api/equipment/')
        ?await equipmentApi.api(input.method,input.path,input.body):await store.api(input.method,input.path,input.body);
    if(value?.restored){
      localPhotos.reset();
      careLabels.reset();
      adapters.closeCustomer();
      // Discard stale renderer order snapshots, drafts and privileged forms.
      setTimeout(()=>{if(!mainWindow.isDestroyed())mainWindow.loadURL('k99://app/');},500);
    }
    if(input.method==='GET'&&input.path.startsWith('/api/mobile-photo/draft?'))value=automaticTags.enrichDraft(careLabels.enrichDraft(value));
    if(input.method!=='GET')changed();
    return {ok:true,result:value};
    }catch(error){return {ok:false,error:error.message,status:error.status||500};}
    finally{if(writing)activeWrites--;}
  });
  ipcMain.handle('customer-status',event=>{trusted(event);return adapters.displayStatus();});
  ipcMain.handle('k99:photo-source',(event,input)=>{
    trusted(event);
    if(event.sender!==mainWindow?.webContents)throw Error('직원 창만 사진을 읽을 수 있습니다.');
    return input?.action==='list'?localPhotos.list():localPhotos.source(input);
  });
  ipcMain.handle('analyze-care-label',async(event,photoId,options)=>{
    if(options?.automatic===true)return null;
    trusted(event);
    if(event.sender!==mainWindow?.webContents)throw Error('직원 창만 케어라벨을 분석할 수 있습니다.');
    return adapters.optionalAnalysis(photoId);
  });
  const footSwitch=createFootSwitch({globalShortcut,getMain:()=>mainWindow});
  app.on('will-quit',()=>footSwitch.dispose());
  ipcMain.handle('k99:foot-active',(event,input)=>{
    trusted(event);
    if(event.sender!==mainWindow?.webContents)throw Error('직원 창만 촬영 단축키를 설정할 수 있습니다.');
    return footSwitch.set(input);
  });
  ipcMain.on('customer-action',(event,data)=>{
    try{trusted(event);if(event.sender!==mainWindow?.webContents)throw Error('직원 화면만 명령을 전송할 수 있습니다.');adapters.action(data);}
    catch(error){event.sender.send('customer-connection',{type:'COMMAND_ERROR',commandId:data?.command?.id,error:error.message});}
  });
  ipcMain.on('customer-event',(event,data)=>{
    try{trusted(event);adapters.customerEvent(event.sender,data);}catch{/* Reject untrusted senders. */}
  });
  mainWindow = new BrowserWindow({
    title:'K99 스마트 접수 시스템 버전 2 (K99 Laundry V2)',width:1440,height:960,minWidth:1100,minHeight:740,
    icon:app.isPackaged?path.join(__dirname,'assets/k99-reception.ico'):path.join(__dirname,'../installer/k99-reception.ico'),
    autoHideMenuBar:true, backgroundColor:'#eeeae3',
    webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,
      sandbox:true,webSecurity:true,webviewTag:false,backgroundThrottling:false},
  });
  adapters=createNativeAdapters({BrowserWindow,screen,session,store,getMain:()=>mainWindow,
    onComparisonClosed:id=>comparisonGallery.revoke(id),
    preload:path.join(__dirname,'preload.cjs'),changed,
    preferencesFile:path.join(app.getPath('userData'),'customer-display.json')});
  const archive=createPhotoArchive({getRoot:()=> storageLayout?.root||'D:\\K99과천매장',
    openPath:folder=>shell.openPath(folder),encodeJpeg:bytes=>{
      const image=nativeImage.createFromBuffer(bytes);
      if(image.isEmpty())throw Error('촬영 이미지를 디코딩할 수 없습니다.');
      return image.toJPEG(90);
    }});
  Object.assign(adapters,{archivePhoto:archive.photo,archiveComparison:archive.comparison,openPhotoFolder:archive.open});
  adapters.optionalAnalysis=photoId=>require('./optional-label.cjs').optionalLabel(photoId,{
    readPhoto:id=>store.equipment.photoFile(id),allowLoopback:!app.isPackaged});
  equipmentApi=createEquipmentApi(store,adapters);
  careLabels=createCareLabelController({store,equipmentApi,changed,photoGateway:localPhotos,onResult:r=>automaticTags.onAnalysis(r),
    classify:(bytes,options)=>classifyCareLabel(bytes,{...options,allowLoopback:!app.isPackaged})});
  automaticTags=createAutomaticTags({store,equipmentApi,labels:careLabels,changed,offline:true});
  const automaticMode=()=>adapters.native&&store.equipment.getConfig().mode==='real';
  // capture-draft owns the durable first-shot job. Its claim guard prevents
  // a second print on extra photos, retries, mobile uploads or finalization.
  adapters.deferDraftTag=()=>false;
  adapters.beforeDraftCapture=(input,dispatch)=>automaticMode()?automaticTags.beforeCapture(input,dispatch):undefined;
  adapters.afterDraftCapture=(input,unit)=>{if(automaticMode())automaticTags.afterCapture(input,unit);};
  const originalPrint=adapters.print;
  adapters.print=job=>{
    let materialTag=job.payload.materialTag??'';
    if(job.payload.materialTag===undefined)try{materialTag=careLabels.materialForJob(job);}catch{/* Keep existing printing available. */}
    const defined=Object.fromEntries(Object.entries(job.payload).filter(([,value])=>value!==undefined&&value!==null&&value!==''));
    return originalPrint({...job,payload:{...careLabels.analysisForJob(job),...defined,materialTag}});
  };
  mobilePhotoBridge=createMobilePhotoController({store,equipmentApi,archivePhoto:archive.photo,nativeImage,changed,
    noticeLink:input=>noticeMobile.start({customerScope:{name:input.customerName,phone:input.customerPhone}}),
    onMobileSaved:()=>{}});
  adapters.archivePhoto=mobilePhotoBridge.archivePhoto;
  comparisonMobilePhotos=createComparisonMobilePhotos({store,equipmentApi,nativeImage,changed});
  const closeComparisonPhotos=()=>comparisonMobilePhotos.close();
  mainWindow.webContents.on('did-start-loading',closeComparisonPhotos);
  mainWindow.webContents.on('render-process-gone',closeComparisonPhotos);
  mainWindow.on('closed',closeComparisonPhotos);
  mainWindow.webContents.setWindowOpenHandler(({url}) => {
    // The original customer's popup is replaced by the explicit monitor picker.
    if(url==='k99://app/customer')mainWindow.webContents.send('k99:changed');
    return {action:'deny'};
  });
  mainWindow.on('closed',()=>{footSwitch.dispose();adapters.closeCustomer(false);});
  // A single activity flag, never keystrokes or customer data. Once work begins
  // this session cannot be restarted automatically by a completed download.
  ipcMain.on('k99:update-user-active',event=>{
    try{trusted(event);if(event.sender===mainWindow.webContents){updateSessionUsed=true;updates?.noteUserActivity();}}catch{}
  });
  mainWindow.webContents.on('before-input-event',()=>{updateSessionUsed=true;updates?.noteUserActivity();});
  mainWindow.webContents.on('render-process-gone',()=>footSwitch.dispose());
  mainWindow.webContents.on('did-start-loading',()=>footSwitch.dispose());
  mainWindow.webContents.on('did-start-loading',()=>mobilePhotoBridge.close());
  mainWindow.webContents.on('render-process-gone',()=>mobilePhotoBridge.close());
  mainWindow.on('closed',()=>mobilePhotoBridge.close());
  mainWindow.webContents.on('will-navigate',(event,url) => {
    if (!url.startsWith('k99://app/')) event.preventDefault();
  });
  await startLocalDesktop({
    loadMain:()=>mainWindow.loadURL('k99://app/'),
    configurePrinter:()=>equipmentApi.api('GET','/api/equipment/state').then(state=>{
    const policy=state.tagPolicy;
    if(policy.mode!=='printer')return;
    const matches=state.printers.filter(p=>policy.printerKind==='tsc'?/tsc.*te210|te210/i.test(p.name):/xprinter|xp-/i.test(p.name));
    if(matches.length&&!matches.some(p=>p.name===state.config.printerName))
      return equipmentApi.api('POST','/api/equipment/command',{action:'configure-tag-mode',mode:'printer',printerKind:policy.printerKind});
    }),
    onPrinterError:error=>console.error('초기 프린터 확인:',error.message),
    restoreCustomer:()=>adapters.restore(),
    onCustomerError:error=>{
      if(!mainWindow.isDestroyed())
        mainWindow.webContents.send('customer-connection',{type:'CONNECTION',connected:false,error:error.message});
    },
  });
  // Development and portable folders do not have an NSIS installation to
  // update. Failure to load/check the updater must never prevent local work.
  const nsisInstalled=process.platform==='win32'&&fsSync.existsSync(
    path.join(path.dirname(app.getPath('exe')),'Uninstall K99-Laundry-V2.exe'));
  if(app.isPackaged&&nsisInstalled&&!process.env.PORTABLE_EXECUTABLE_DIR){
    try{
      const {autoUpdater}=require('electron-updater');
      updateNotice=createUpdateNotice({BrowserWindow,parent:()=>mainWindow});
      updates=createAutoUpdate({updater:autoUpdater,enabled:true,
        canInstall:()=>activeWrites===0&&messengerOps===0&&!storageChanging,
        backup:async()=>{await aiSession.flush();return manager.createBackup('before-application-update');},
        onState:state=>updateNotice.show(state),beforeInstall:()=>updateNotice.waitForPaint(),
        onError:message=>console.warn(message)});
      if(updateSessionUsed)updates.noteUserActivity();
      updates.start();
    }catch{console.warn('자동 업데이트 준비를 건너뛰었습니다. 로컬 업무는 계속 사용할 수 있습니다.');}
  }
}).catch(error => {
  dialog.showErrorBox('K99 Laundry V2 시작 실패',error.message + '\n기존 데이터를 삭제하지 말고 지원을 요청하세요.');
  app.quit();
});
