'use strict';
const {app, BrowserWindow, protocol, ipcMain, session, dialog, screen, safeStorage} = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const fsSync = require('node:fs');
const {createDesktopManager}=require('@workspace/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('@workspace/k99-local/equipment-api.cjs');
const {createNativeAdapters}=require('./equipment-native.cjs');

protocol.registerSchemesAsPrivileged([{scheme:'k99', privileges:{
  standard:true, secure:true, supportFetchAPI:true, corsEnabled:true,
}}]);
app.setName('K99-Windows-V1');
if(process.platform==='win32')app.setAppUserModelId('com.k99.windows.v1');
// Outside installed application files; never shared with legacy helpers.
const userData = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'K99WindowsV1');
fsSync.mkdirSync(userData,{recursive:true,mode:0o700});
app.setPath('userData', userData);
const locked = app.requestSingleInstanceLock();
if (!locked) app.quit();
let store, manager, mainWindow, adapters, equipmentApi,backupTimer;
const changed=()=>{
  if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('k99:changed');
  adapters?.notify();
};
const trusted = event => {
  const url = new URL(event.senderFrame?.url || 'about:blank');
  if (url.protocol !== 'k99:' || url.host !== 'app' || event.senderFrame !== event.sender.mainFrame)
    throw Object.assign(new Error('허용되지 않은 호출'), {status:403});
  if(event.sender!==mainWindow?.webContents&&!adapters?.isCustomer(event.sender))
    throw Object.assign(new Error('알 수 없는 창'),{status:403});
};
const result = fn => {
  try {return {ok:true,result:fn()};}
  catch(error) {return {ok:false,error:error.message,status:error.status || 500};}
};
app.on('second-instance',() => {mainWindow?.restore(); mainWindow?.focus();});
app.on('window-all-closed',() => app.quit());
app.on('will-quit',() => {clearInterval(backupTimer);store?.close();});
if (locked) app.whenReady().then(() => {
  const publicRoot = path.resolve(__dirname, '../dist/desktop');
  if(process.platform==='win32'&&!safeStorage.isEncryptionAvailable())throw Error('Windows 백업 키 보호(DPAPI)를 사용할 수 없습니다. 기존 데이터는 보존됩니다.');
  manager=createDesktopManager(app.getPath('userData'),{mode:'electron-desktop',
    vault:process.platform==='win32'?{
      encrypt:value=>safeStorage.encryptString(value).toString('base64'),
      decrypt:value=>safeStorage.decryptString(Buffer.from(value,'base64')),
    }:undefined});
  store=manager.store;
  backupTimer=setInterval(()=>{try{manager.automatic();}catch{/* Reported via maintenance status. */}},60000);
  backupTimer.unref();
  const maintenanceAdapters={
    native:process.platform==='win32',packaged:app.isPackaged,
    autostart:()=>({supported:process.platform==='win32'&&app.isPackaged,
      enabled:process.platform==='win32'&&app.isPackaged?app.getLoginItemSettings().openAtLogin:false}),
    setAutostart:enabled=>{
      app.setLoginItemSettings({openAtLogin:enabled,path:process.execPath,args:['--k99-autostart']});
      if(app.getLoginItemSettings().openAtLogin!==enabled)throw Error('Windows 자동 실행 설정을 확인하지 못했습니다.');
    },
    pickImport:async()=>{
      const r=await dialog.showOpenDialog(mainWindow,{title:'K99 통합 백업 선택',
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}],properties:['openFile']});
      return r.canceled?null:r.filePaths[0];
    },
    pickExport:async name=>{
      const r=await dialog.showSaveDialog(mainWindow,{title:'K99 백업 외부 사본 저장',defaultPath:name,
        filters:[{name:'K99 암호화 통합 백업',extensions:['k99backup']}]});
      return r.canceled?null:r.filePath;
    },
  };
  session.defaultSession.webRequest.onBeforeRequest((details, callback) => {
    // Fail closed: no HTTP(S), old local helpers, remote APIs or websocket.
    callback({cancel:!details.url.startsWith('k99://app/')});
  });
  session.defaultSession.setPermissionRequestHandler((wc,permission,callback,details) =>
    callback(!!(wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'
      &&details.mediaTypes?.includes('video')&&!details.mediaTypes?.includes('audio'))));
  session.defaultSession.setPermissionCheckHandler((wc,permission,_origin,details) =>
    wc===mainWindow?.webContents&&permission==='media'&&store.equipment.getConfig().mode==='real'&&details.mediaType==='video');
  session.defaultSession.on('will-download', event => event.preventDefault());
  protocol.handle('k99', async request => {
    const url = new URL(request.url);
    if (url.host !== 'app' || request.method !== 'GET') return new Response('Forbidden',{status:403});
    if(url.pathname.startsWith('/api/equipment/photos/')) {
      try {
        const photo=store.equipment.photoFile(url.pathname.slice('/api/equipment/photos/'.length));
        return new Response(photo.bytes,{headers:{'Content-Type':photo.contentType,'Cache-Control':'no-store'}});
      }catch(error){return new Response('사진 읽기 실패',{status:error.status||500});}
    }
    let pathname;
    try {pathname = decodeURIComponent(url.pathname);} catch {return new Response('Bad path',{status:400});}
    if (pathname.includes('\0')) return new Response('Bad path',{status:400});
    const candidate = path.resolve(publicRoot, '.' + pathname);
    if (candidate !== publicRoot && !candidate.startsWith(publicRoot + path.sep)) return new Response('Forbidden',{status:403});
    // BrowserRouter fallback only for extensionless routes.
    const file = path.extname(candidate) ? candidate : path.join(publicRoot,'index.html');
    try {
      const bytes = await fs.readFile(file);
      const mime = {'.html':'text/html; charset=utf-8','.js':'application/javascript',
        '.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg',
        '.woff2':'font/woff2','.mp4':'video/mp4'};
      const headers = new Headers({'Content-Type':mime[path.extname(file)] || 'application/octet-stream'});
      headers.set('Content-Security-Policy',
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'");
      return new Response(bytes,{status:200,headers});
    } catch {return new Response('파일을 찾지 못했습니다.',{status:404});}
  });
  ipcMain.on('k99:storage',(event,input) => {
    event.returnValue = result(() => {
      trusted(event);
      if(event.sender!==mainWindow.webContents)throw Object.assign(new Error('고객 창은 읽기 전용입니다.'),{status:403});
      const output=store.storage(input);
      if(input.op==='set'&&['k99-confirmed-orders-v1','k99-laundry-display-state'].includes(input.key))
        queueMicrotask(()=>adapters?.notify());
      return output;
    });
  });
  ipcMain.handle('k99:request',async(event,input) => {
    try {
    trusted(event);
    if (!input || !['GET','POST','PUT'].includes(input.method) || typeof input.path !== 'string')
      throw Object.assign(new Error('잘못된 요청'),{status:400});
    if(event.sender!==mainWindow.webContents&&!(input.method==='GET'&&input.path==='/api/equipment/display'))
      throw Object.assign(new Error('고객 창은 안내 정보만 조회할 수 있습니다.'),{status:403});
    const value=input.path.startsWith('/api/maintenance/')
      ?await manager.api(input.method,input.path,input.body,maintenanceAdapters)
      :input.path.startsWith('/api/equipment/')
        ?await equipmentApi.api(input.method,input.path,input.body):store.api(input.method,input.path,input.body);
    if(value?.restored){
      adapters.closeCustomer();
      // Discard stale renderer order snapshots, drafts and privileged forms.
      setTimeout(()=>{if(!mainWindow.isDestroyed())mainWindow.loadURL('k99://app/');},500);
    }
    if(input.method!=='GET')changed();
    return {ok:true,result:value};
    }catch(error){return {ok:false,error:error.message,status:error.status||500};}
  });
  mainWindow = new BrowserWindow({
    title:'K99 스마트 접수 시스템 — Windows V1',width:1440,height:960,minWidth:1100,minHeight:740,
    icon:app.isPackaged?path.join(__dirname,'assets/k99-reception.ico'):path.join(__dirname,'../installer/k99-reception.ico'),
    autoHideMenuBar:true, backgroundColor:'#eeeae3',
    webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,
      sandbox:true,webSecurity:true,webviewTag:false},
  });
  adapters=createNativeAdapters({BrowserWindow,screen,session,store,getMain:()=>mainWindow,
    preload:path.join(__dirname,'preload.cjs'),changed});
  equipmentApi=createEquipmentApi(store,adapters);
  mainWindow.webContents.setWindowOpenHandler(({url}) => {
    // The original customer's popup is replaced by the explicit monitor picker.
    if(url==='k99://app/customer')mainWindow.webContents.send('k99:changed');
    return {action:'deny'};
  });
  mainWindow.on('closed',()=>adapters.closeCustomer());
  mainWindow.webContents.on('will-navigate',(event,url) => {
    if (!url.startsWith('k99://app/')) event.preventDefault();
  });
  return mainWindow.loadURL('k99://app/');
}).catch(error => {
  dialog.showErrorBox('K99-Windows-V1 시작 실패',error.message + '\n기존 데이터를 삭제하지 말고 지원을 요청하세요.');
  app.quit();
});
