'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY,vendorPrinters}=require('./hardware-settings.cjs');
const {receiptPreferences}=require('./receipt-template.cjs');
const {encodeText,receiptText,escPosReceipt,chunkDelay,chunkLengths,SERIAL_SCRIPT,createSerialReceiptPrinter}=require('./receipt-serial.cjs');
const serialConfig={receiptType:'thermal',receiptTransport:'serial',receiptPort:'COM3',receiptEscPosVerified:true};
const serialReceipt={customerName:'검증고객',customerPhone:'01000000000',paymentType:'POSTPAID',
  items:[{name:'정장 상의',quantity:1,amount:200000}],totalAmount:170000,
  discountAmount:30000,discountRate:15,tierDiscountAmount:30000};
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-hardware-'));
  const filename=path.join(root,'k99.db');
  let store=createStore(filename,'test',{nativeDesktop:true});
  t.after(()=>{store.close();fs.rmSync(root,{recursive:true,force:true});});
  const printed=[],opened=[],loaded=[];
  const adapters={printers:async()=>[{name:'TSC TE210'},{name:'Xprinter'},{name:'Receipt'}],print:async job=>printed.push(job)};
  const api=()=>createHardwareSettings({store,adapters,native:true,shell:{openExternal:async s=>opened.push(s)},
    BrowserWindow:class{constructor(){this.webContents={print:(options,cb)=>{printed.push(options);cb(true);}};}async loadURL(url){loaded.push(url);}isDestroyed(){return false;}destroy(){}}});
  return {get store(){return store;},api,printed,opened,loaded,adapters,reopen(){store.close();store=createStore(filename,'test',{nativeDesktop:true});}};
}
test('회사 자동 선택은 실제 드라이버 이름만 식별하며 일반 COM 포트를 회사로 추측하지 않는다',()=>{
  const rows=[{name:'EasyCheck POS'},{name:'KIS printer'},{name:'Smartro receipt'},{name:'Receipt'},{name:'COM3'},{name:'KISS generic'}];
  assert.deepEqual(vendorPrinters('easycheck',rows),[rows[0]]);
  assert.deepEqual(vendorPrinters('kis',rows),[rows[1]]);
  assert.deepEqual(vendorPrinters('nice',rows),[rows[2]]);
  assert.throws(()=>vendorPrinters('unknown',rows),/회사/);
});
test('회사별 단일 Windows 출력기 자동 선택은 영구 저장되고 미사용 전환에도 상세 설정은 보존된다',async t=>{
  const f=fixture(t);
  f.adapters.printers=async()=>[{name:'KICC EasyCheck',port:'USB001'},{name:'KIS정보통신 receipt'},{name:'NICE POS'}];
  for(const vendor of ['easycheck','kis','nice']){
    const r=await f.api()({action:'select-receipt-vendor',vendor});
    assert.equal(r.selection.state,'configured');assert.equal(r.config.receiptVendor,vendor);
    assert.equal(r.config.receiptTransport,'windows');assert.equal(r.config.receiptBaudRate,9600);
    f.reopen();assert.equal((await f.api()({action:'status'})).config.receiptVendor,vendor);
  }
  const before=(await f.api()({action:'status'})).config;
  const off=await f.api()({action:'select-receipt-vendor',vendor:'none'});
  assert.equal(off.config.receiptType,'none');assert.equal(off.config.receiptPrinterName,before.receiptPrinterName);
  assert.equal(f.printed.length,0);assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('미감지·중복 출력기·장치 조회 실패는 기존 설정을 변경하거나 연결 성공을 위조하지 않는다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{receiptType:'easycheck',receiptPrinterName:'Receipt',receiptPromo:'그대로 보관'}});
  const previous=f.store.storage({op:'get',key:KEY});
  assert.equal((await f.api()({action:'select-receipt-vendor',vendor:'easycheck'})).selection.state,'missing');
  f.adapters.printers=async()=>[{name:'KIS 1'},{name:'KIS 2'}];
  assert.equal((await f.api()({action:'select-receipt-vendor',vendor:'kis'})).selection.state,'ambiguous');
  f.adapters.printers=async()=>{throw Error('driver');};
  assert.equal((await f.api()({action:'select-receipt-vendor',vendor:'nice'})).selection.state,'missing');
  assert.equal(f.store.storage({op:'get',key:KEY}),previous);
});
test('검증된 이지체크 시리얼 설정은 회사 버튼·미사용 왕복에도 9600과 포트·인코딩을 그대로 보존한다',async t=>{
  const f=fixture(t);f.adapters.ports=async()=>[{name:'COM3'}];
  await f.api()({action:'save-receipt',config:{...serialConfig,receiptType:'easycheck',receiptEncoding:'euc-kr',receiptCut:true,receiptPromo:'보존 문구'}});
  const old=(await f.api()({action:'status'})).config;
  const chosen=await f.api()({action:'select-receipt-vendor',vendor:'easycheck'});
  assert.equal(chosen.selection.state,'configured');
  await f.api()({action:'select-receipt-vendor',vendor:'none'});
  const enabled=await f.api()({action:'select-receipt-vendor',vendor:'easycheck'});
  assert.equal(enabled.selection.state,'configured');
  for(const key of ['receiptTransport','receiptPort','receiptBaudRate','receiptEncoding','receiptCut','receiptEscPosVerified','receiptPromo'])
    assert.equal(enabled.config[key],old[key],key);
  const saved=f.store.storage({op:'get',key:KEY});f.adapters.ports=async()=>[];
  assert.equal((await f.api()({action:'select-receipt-vendor',vendor:'easycheck'})).selection.state,'missing');
  assert.equal(f.store.storage({op:'get',key:KEY}),saved);
});
test('시리얼에서 다른 회사로 자동 변경하거나 브라우저에서 하드웨어 저장하지 않는다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{...serialConfig,receiptType:'easycheck'}});
  f.adapters.printers=async()=>[{name:'KIS정보통신'}];
  assert.equal((await f.api()({action:'select-receipt-vendor',vendor:'kis'})).selection.state,'ambiguous');
  const browser=createHardwareSettings({store:f.store,adapters:f.adapters,native:false});
  await assert.rejects(browser({action:'select-receipt-vendor',vendor:'kis'}),/Windows/);
  assert.equal((await f.api()({action:'status'})).config.receiptTransport,'serial');
});
test('hardware settings survive real SQLite reopen without changing archive, foot key, catalog or orders',async t=>{
  const f=fixture(t),old=f.store.equipment.getConfig(),catalog=f.store.api('GET','/api/price-catalog');
  const next={labelPrinterName:'Xprinter',receiptPrinterName:'Receipt',cameraDeviceId:'usb-selected',tagMode:'xprinter',labelVerified:true};
  await f.api()({action:'save',config:next});f.reopen();
  const s=await f.api()({action:'status'});
  assert.deepEqual(Object.fromEntries(Object.keys(next).map(k=>[k,s.config[k]])),next);
  assert.equal(s.config.receiptType,'windows');assert.equal(s.config.receiptWidth,80);
  assert.equal(s.config.receiptPromo,'');assert.equal(f.store.equipment.getConfig().photoArchiveRoot,old.photoArchiveRoot);
  assert.equal(f.store.equipment.getConfig().footSwitchKey,old.footSwitchKey);
  assert.deepEqual(f.store.api('GET','/api/price-catalog'),catalog);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  const roll=await f.api()({action:'save',config:{...next,tagMode:'roll'}});
  assert.equal(roll.config.tagMode,'roll');
});
test('invalid printer or unverified replacement is rejected before changing SQLite settings',async t=>{
  const f=fixture(t),before=await f.api()({action:'status'});
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'Xprinter',labelVerified:false}}),/30mm/);
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'missing',labelVerified:true}}),/목록/);
  assert.deepEqual((await f.api()({action:'status'})).config,before.config);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('stale preference write rolls back printer, camera and policy in the same SQLite transaction',t=>{
  const f=fixture(t),before=f.store.equipment.getConfig(),policy=f.store.equipment.drafts.tagPolicy();
  assert.throws(()=>f.store.saveHardwarePreferences({...before,mode:'real',hardwareConfirmed:true,
    printerName:'Xprinter',cameraDeviceId:'changed'},'printer','xprinter',{receiptPrinterName:'Receipt'},'stale'),/변경/);
  assert.deepEqual(f.store.equipment.getConfig(),before);
  assert.deepEqual(f.store.equipment.drafts.tagPolicy(),policy);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('explicit tests use chosen device, original 30mm tag adapter, and never create customer orders',async t=>{
  const f=fixture(t);
  await f.api()({action:'test',kind:'label',printerName:'Xprinter'});
  assert.equal(f.printed[0].printerName,'Xprinter');assert.equal(f.printed[0].payload.labelWidthMm,30);
  assert.equal(f.printed[0].payload.manualMaterial,'폴리에스테르');
  await f.api()({action:'test',kind:'receipt',printerName:'Receipt'});
  assert.equal(f.printed[1].deviceName,'Receipt');assert.equal(f.printed[1].silent,true);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  await f.api()({action:'display-settings'});assert.deepEqual(f.opened,['ms-settings:display']);
});
test('browser cannot save or print and repeated in-flight test does not duplicate output',async t=>{
  const f=fixture(t);
  const browser=createHardwareSettings({store:f.store,adapters:f.adapters,native:false});
  await assert.rejects(browser({action:'test',kind:'receipt',printerName:'Receipt'}),/Windows/);
  let finish;f.adapters.print=()=>new Promise(resolve=>{finish=resolve;});
  const api=f.api(),first=api({action:'test',kind:'label',printerName:'Xprinter'});
  await new Promise(resolve=>setImmediate(resolve));
  await assert.rejects(api({action:'test',kind:'label',printerName:'Xprinter'}),/중복/);
  finish();await first;
});
test('영수증은 라벨·카메라 미설정이어도 독립 저장·재시작하며 미리보기와 인쇄가 결제를 바꾸지 않는다',async t=>{
  const f=fixture(t),old=f.store.equipment.getConfig(),catalog=f.store.api('GET','/api/price-catalog');
  const config={receiptType:'easycheck',receiptWidth:58,receiptPromo:'홍보 첫 줄\n홍보 둘째 줄',receiptPrinterName:'Receipt',receiptPort:'COM3'};
  await f.api()({action:'save-receipt',config});f.reopen();
  const s=await f.api()({action:'status'});
  for(const [k,v] of Object.entries(config))assert.equal(s.config[k],v);
  assert.deepEqual(f.store.equipment.getConfig(),old);assert.deepEqual(f.store.api('GET','/api/price-catalog'),catalog);
  const receipt={customerName:'임시 출력 검증',customerPhone:'01000000000',paymentType:'POSTPAID',
    items:[{name:'셔츠',quantity:2,amount:10000}]};
  const preview=await f.api()({action:'receipt-preview',receipt});
  assert.match(preview.html,/홍보 첫 줄<br>홍보 둘째 줄/);assert.match(preview.html,/\[ 후불 \]/);
  await f.api()({action:'receipt-print',receipt});
  assert.equal(f.printed.at(-1).deviceName,'Receipt');assert.equal(f.printed.at(-1).pageSize.width,58000);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('프린터·포트 조회 실패와 미연결 출력은 친절하게 실패하고 미리보기는 유지한다',async t=>{
  const f=fixture(t);f.adapters.printers=async()=>{throw Error('spooler unavailable');};
  f.adapters.ports=async()=>{throw Error('access denied');};
  const api=f.api(),s=await api({action:'status'});
  assert.deepEqual(s.printers,[]);assert.deepEqual(s.ports,[]);assert.match(s.printerMessage,/접수는 계속/);
  assert.match((await api({action:'receipt-preview'})).html,/세탁 접수증/);
  await assert.rejects(api({action:'receipt-print',config:{receiptType:'easycheck',receiptPrinterName:'Receipt'}}),/연결된 접수증/);
  assert.equal(f.printed.length,0);
});
test('홍보문구 3줄 저장 거부 시 기존 설정을 보존하고 카메라 단독 저장은 라벨을 요구하지 않는다',async t=>{
  const f=fixture(t),before=await f.api()({action:'status'});
  await assert.rejects(f.api()({action:'save-receipt',config:{receiptPromo:'1\n2\n3'}}),/2줄/);
  assert.deepEqual((await f.api()({action:'status'})).config,before.config);
  const after=await f.api()({action:'save-camera',config:{cameraDeviceId:'direct-camera'}});
  assert.equal(after.config.cameraDeviceId,'direct-camera');
  assert.equal(after.config.labelPrinterName,before.config.labelPrinterName);
});
test('저장된 접수증 폭은 프린터 조회 없이 복원되고 브라우저 미리보기도 같은 설정을 쓴다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{receiptType:'thermal',receiptWidth:58,receiptPromo:'기본 홍보 문구'}});
  f.reopen();let printerCalls=0;
  f.adapters.printers=async()=>{printerCalls++;throw Error('꺼진 프린터');};
  const restored=await f.api()({action:'receipt-preferences'});
  assert.equal(restored.config.receiptWidth,58);assert.equal(printerCalls,0);
  const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
  const api=createEquipmentApi(f.store,{native:false,printers:async()=>[]});
  const p=await api.api('POST','/api/equipment/command',{action:'receipt-preferences'});
  assert.equal(p.config.receiptWidth,58);
  const r=await api.api('POST','/api/equipment/command',{action:'receipt-preview'});
  assert.equal(r.width,58);assert.match(r.html,/기본 홍보 문구/);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('영구 저장한 두 줄 홍보와 할인 내역은 미리보기와 Windows 인쇄 창에 동일하게 전달된다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{receiptType:'thermal',receiptWidth:80,
    receiptPrinterName:'Receipt',receiptPromo:'우리 매장 첫 안내\n정성스러운 세탁 서비스'}});
  f.reopen();
  const receipt={customerName:'출력검증',customerPhone:'01000000000',paymentType:'PREPAID',
    items:[{name:'검증코트',quantity:1,amount:200000}],totalAmount:170000,
    discountAmount:30000,discountRate:15,tierDiscountAmount:30000};
  const preview=await f.api()({action:'receipt-preview',receipt});
  await f.api()({action:'receipt-print',receipt});
  const printHtml=decodeURIComponent(f.loaded.at(-1).split(',').slice(1).join(','));
  for(const html of [preview.html,printHtml]){
    assert.match(html,/우리 매장 첫 안내<br>정성스러운 세탁 서비스/);
    assert.match(html,/할인 전 금액: 200,000원/);
    assert.match(html,/구간 할인 \(15%\): -30,000원/);
    assert.match(html,/최종 할인 합계 금액: 170,000원/);
  }
  assert.equal(f.printed.at(-1).deviceName,'Receipt');
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('영수증 기본값 9600과 네 가지 속도·한글 설정은 SQLite 재시작 후 그대로 복원된다',async t=>{
  const f=fixture(t);
  assert.equal((await f.api()({action:'receipt-preferences'})).config.receiptBaudRate,9600);
  const before=f.store.equipment.getConfig();
  for(const receiptBaudRate of [9600,19200,38400,115200]){
    await f.api()({action:'save-receipt',config:{receiptBaudRate,receiptEncoding:'euc-kr'}});
    f.reopen();
    const c=(await f.api()({action:'receipt-preferences'})).config;
    assert.equal(c.receiptBaudRate,receiptBaudRate);assert.equal(c.receiptEncoding,'euc-kr');
  }
  assert.deepEqual(f.store.equipment.getConfig(),before);
  for(const receiptBaudRate of [0,4800,230400,'9600',null]){
    if(receiptBaudRate===null)assert.equal(receiptPreferences({receiptBaudRate}).receiptBaudRate,9600);
    else await assert.rejects(f.api()({action:'save-receipt',config:{receiptBaudRate}}),/통신 속도/);
  }
  assert.equal((await f.api()({action:'receipt-preferences'})).config.receiptBaudRate,115200);
});
test('옛 설정은 초기화하지 않고 9600을 기본 보충하며 기존 드라이버 출력을 바꾸지 않는다',async t=>{
  const f=fixture(t);
  f.store.storage({op:'set',key:KEY,expected:f.store.storage({op:'get',key:KEY}),value:JSON.stringify({receiptType:'easycheck',receiptPrinterName:'Receipt',receiptPort:'COM3'})});
  const c=(await f.api()({action:'receipt-preferences'})).config;
  assert.equal(c.receiptBaudRate,9600);assert.equal(c.receiptTransport,'windows');
  assert.equal(c.receiptEscPosVerified,false);
  f.adapters.serialReceipt=()=>{throw Error('직접 출력하면 안 됨');};
  await f.api()({action:'receipt-print',receipt:serialReceipt});
  assert.equal(f.printed.at(-1).deviceName,'Receipt');
});
test('CP949·EUC-KR 실제 바이트, 줄바꿈 및 잘못된 문자·인쇄 명령 주입 방어를 검사한다',()=>{
  for(const enc of ['cp949','euc-kr'])assert.equal(encodeText('가나\n',enc).toString('hex'),'b0a1b3aa0d0a');
  assert.ok(encodeText('뷁','cp949').length===2);
  assert.throws(()=>encodeText('뷁','euc-kr'),/EUC-KR/);
  assert.throws(()=>encodeText('옷😀'),/인코딩/);
  assert.throws(()=>encodeText('품목\x1b@'),/제어 문자/);
  assert.equal(encodeText('가\r\n나\r다\n').toString('hex'),'b0a10d0ab3aa0d0ab4d90d0a');
});
test('시리얼 접수증은 홍보 두 줄·고객·할인 합계·택을 보존하고 용지 폭 안에서 줄바꿈한다',()=>{
  const input={receipt:{...serialReceipt,manualTagNumbers:['1-1']},profile:{storeName:'검증매장'},
    preferences:{...serialConfig,receiptWidth:58,receiptPromo:'첫 안내\n둘째 안내'}};
  const text=receiptText(input),packet=escPosReceipt(input);
  assert.ok(text.startsWith('첫 안내\n둘째 안내'));
  for(const row of text.split('\n'))assert.ok(encodeText(row).length<=32);
  assert.match(text,/200,000원/);assert.match(text,/15%/);assert.match(text,/170,000원/);
  assert.match(text,/후불/);assert.match(text,/수기 택: 1-1/);
  assert.doesNotMatch(receiptText({...input,showManualTags:false}),/수기 택/);
  assert.deepEqual(packet.data.subarray(0,4),Buffer.from([27,64,28,38]));
  assert.equal(packet.cut.length,0);
  assert.deepEqual(escPosReceipt({...input,preferences:{...input.preferences,receiptCut:true}}).cut,Buffer.from([29,86,0]));
  assert.doesNotMatch(text,/승인번호/);
});
test('미확인 단말기·비정상 포트는 전송하지 않고 실제 COM 포트일 때만 저장 속도를 전달한다',async t=>{
  const f=fixture(t);let calls=0;
  f.adapters.ports=async()=>[{name:'COM3'}];
  f.adapters.serialReceipt=async input=>{calls++;assert.equal(input.preferences.receiptBaudRate,9600);return {message:'전송 모의 완료'};};
  const api=f.api();
  await api({action:'save-receipt',config:{...serialConfig,receiptEscPosVerified:false}});
  await assert.rejects(api({action:'receipt-print',receipt:serialReceipt}),/확인된 기기/);
  await api({action:'save-receipt',config:serialConfig});
  assert.equal((await api({action:'receipt-print',receipt:serialReceipt})).message,'전송 모의 완료');
  assert.equal(calls,1);assert.equal(f.printed.length,0);
  f.adapters.ports=async()=>[];
  await assert.rejects(api({action:'receipt-print',receipt:serialReceipt}),/COM 포트/);
  assert.equal(calls,1);
  for(const receiptPort of ['COM3;start cmd','LPT1','COM0'])assert.throws(()=>escPosReceipt({receipt:serialReceipt,preferences:{...serialConfig,receiptPort}}),/COM 포트/);
});
function fakeSerialProcess({hold=false,fail=false}={}){
  const {EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');
  const child=new EventEmitter();child.stdin=new PassThrough();child.stdout=new PassThrough();child.stderr=new PassThrough();
  let json='';
  child.stdin.on('data',b=>{json+=b;});
  const finish=()=>{child.stdout.write(fail?'실패':'K99_RECEIPT_DRAINED');child.emit('close',fail?1:0);};
  child.stdin.once('finish',()=>{if(!hold)queueMicrotask(finish);});
  child.kill=()=>{queueMicrotask(()=>child.emit('close',1));return true;};
  return {child,finish,get json(){return JSON.parse(json);}};
}
test('비동기 전송은 9600·8N1·128바이트 간격을 사용하고 고객 데이터는 명령행에 넣지 않는다',async()=>{
  const fake=fakeSerialProcess();let command;
  const print=createSerialReceiptPrinter({platform:'win32',spawnProcess:(...args)=>{command=args;return fake.child;}});
  await print({receipt:serialReceipt,preferences:serialConfig});
  assert.equal(fake.json.baud,9600);assert.equal(fake.json.port,'COM3');
  assert.ok(Buffer.from(fake.json.data,'base64').length>0);
  assert.equal(command[2].windowsHide,true);
  const args=command[1],script=Buffer.from(args.at(-1),'base64').toString('utf16le');
  assert.equal(script,SERIAL_SCRIPT);assert.ok(!args.join(' ').includes(serialReceipt.customerName));
  assert.match(script,/\$port\.BaudRate=\[int\]\$j\.baud/);
  assert.match(script,/\$port\.DataBits=8/);assert.match(script,/\$offset\+=\$count/);
  assert.match(script,/\$port\.WriteTimeout=5000/);assert.match(script,/BytesToWrite/);
  assert.ok(script.indexOf('$port.Write($cut')>script.indexOf('while($port.BytesToWrite'));
  assert.ok(chunkDelay(128,9600)>=154);assert.ok(chunkDelay(128,9600)>chunkDelay(128,115200));
  const data=Buffer.from(fake.json.data,'base64');
  assert.deepEqual(fake.json.lengths,chunkLengths(data));
  const tricky=encodeText('a'.repeat(127)+'뷁'.repeat(200)+'\n');
  let offset=0;
  for(const n of chunkLengths(tricky)){
    assert.ok(n>=1&&n<=128);
    assert.doesNotThrow(()=>encodeText(require('iconv-lite').decode(tricky.subarray(offset,offset+n),'cp949')));
    offset+=n;
  }
  assert.equal(offset,tricky.length);
  assert.equal(chunkLengths(tricky)[0],127);
});
test('동일 포트 중복·전송 실패 자동 재시도 방지 및 실패 후 재출력 가능',async()=>{
  let fake=fakeSerialProcess({hold:true}),calls=0;
  const print=createSerialReceiptPrinter({platform:'win32',spawnProcess:()=>{calls++;return fake.child;}});
  const input={receipt:serialReceipt,preferences:serialConfig},pending=print(input);
  await assert.rejects(print(input),/중복 전송/);
  fake.finish();await pending;
  fake=fakeSerialProcess({fail:true});
  await assert.rejects(print(input),/자동 재전송하지 않습니다/);
  assert.equal(calls,2);
  fake=fakeSerialProcess();await print(input);assert.equal(calls,3);
});
test('Windows PowerShell은 고정 시리얼 스크립트를 구문 분석할 수 있다',async()=>{
  assert.ok(!SERIAL_SCRIPT.includes('Start-Process'));
  if(process.platform==='win32'){
    const {promisify}=require('node:util'),exec=promisify(require('node:child_process').execFile);
    const command=`$null=[scriptblock]::Create([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('${Buffer.from(SERIAL_SCRIPT,'utf16le').toString('base64')}')));[Console]::Out.Write('K99_PARSE_OK')`;
    const r=await exec('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(command,'utf16le').toString('base64')],{windowsHide:true,timeout:20000});
    assert.equal(r.stdout,'K99_PARSE_OK');
  }
});
