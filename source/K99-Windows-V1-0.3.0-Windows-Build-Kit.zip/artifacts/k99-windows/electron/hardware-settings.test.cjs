'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY}=require('./hardware-settings.cjs');
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-hardware-'));
  const filename=path.join(root,'k99.db');
  let store=createStore(filename,'test',{nativeDesktop:true});
  t.after(()=>{store.close();fs.rmSync(root,{recursive:true,force:true});});
  const printed=[],opened=[];
  const adapters={printers:async()=>[{name:'TSC TE210'},{name:'Xprinter'},{name:'Receipt'}],print:async job=>printed.push(job)};
  const api=()=>createHardwareSettings({store,adapters,native:true,shell:{openExternal:async s=>opened.push(s)},
    BrowserWindow:class{constructor(){this.webContents={print:(options,cb)=>{printed.push(options);cb(true);}};}async loadURL(){}isDestroyed(){return false;}destroy(){}}});
  return {get store(){return store;},api,printed,opened,adapters,reopen(){store.close();store=createStore(filename,'test',{nativeDesktop:true});}};
}
test('hardware settings survive real SQLite reopen without changing archive, foot key, catalog or orders',async t=>{
  const f=fixture(t),old=f.store.equipment.getConfig(),catalog=f.store.api('GET','/api/price-catalog');
  const next={labelPrinterName:'Xprinter',receiptPrinterName:'Receipt',cameraDeviceId:'usb-selected',tagMode:'xprinter',labelVerified:true};
  await f.api()({action:'save',config:next});f.reopen();
  const s=await f.api()({action:'status'});
  assert.deepEqual(s.config,next);assert.equal(f.store.equipment.getConfig().photoArchiveRoot,old.photoArchiveRoot);
  assert.equal(f.store.equipment.getConfig().footSwitchKey,old.footSwitchKey);
  assert.deepEqual(f.store.api('GET','/api/price-catalog'),catalog);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  const roll=await f.api()({action:'save',config:{...next,tagMode:'roll'}});
  assert.equal(roll.config.tagMode,'roll');
});
test('invalid printer or unverified replacement is rejected before changing SQLite settings',async t=>{
  const f=fixture(t),before=await f.api()({action:'status'});
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'Xprinter',labelVerified:false}}),/30mm/);
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'missing',labelVerified:true}}),/목록/);
  assert.deepEqual((await f.api()({action:'status'})).config,before.config);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('stale preference write rolls back printer, camera and policy in the same SQLite transaction',t=>{
  const f=fixture(t),before=f.store.equipment.getConfig(),policy=f.store.equipment.drafts.tagPolicy();
  assert.throws(()=>f.store.saveHardwarePreferences({...before,mode:'real',hardwareConfirmed:true,
    printerName:'Xprinter',cameraDeviceId:'changed'},'printer','xprinter',{receiptPrinterName:'Receipt'},'stale'),/변경/);
  assert.deepEqual(f.store.equipment.getConfig(),before);
  assert.deepEqual(f.store.equipment.drafts.tagPolicy(),policy);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('explicit tests use chosen device, original 30mm tag adapter, and never create customer orders',async t=>{
  const f=fixture(t);
  await f.api()({action:'test',kind:'label',printerName:'Xprinter'});
  assert.equal(f.printed[0].printerName,'Xprinter');assert.equal(f.printed[0].payload.labelWidthMm,30);
  assert.equal(f.printed[0].payload.manualMaterial,'폴리에스테르');
  await f.api()({action:'test',kind:'receipt',printerName:'Receipt'});
  assert.equal(f.printed[1].deviceName,'Receipt');assert.equal(f.printed[1].silent,true);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  await f.api()({action:'display-settings'});assert.deepEqual(f.opened,['ms-settings:display']);
});
test('browser cannot save or print and repeated in-flight test does not duplicate output',async t=>{
  const f=fixture(t);
  const browser=createHardwareSettings({store:f.store,adapters:f.adapters,native:false});
  await assert.rejects(browser({action:'test',kind:'receipt',printerName:'Receipt'}),/Windows/);
  let finish;f.adapters.print=()=>new Promise(resolve=>{finish=resolve;});
  const api=f.api(),first=api({action:'test',kind:'label',printerName:'Xprinter'});
  await new Promise(resolve=>setImmediate(resolve));
  await assert.rejects(api({action:'test',kind:'label',printerName:'Xprinter'}),/중복/);
  finish();await first;
});
