'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY}=require('./hardware-settings.cjs');
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-hardware-'));
  const filename=path.join(root,'k99.db');
  let store=createStore(filename,'test',{nativeDesktop:true});
  t.after(()=>{store.close();fs.rmSync(root,{recursive:true,force:true});});
  const printed=[],opened=[],loaded=[];
  const adapters={printers:async()=>[{name:'TSC TE210'},{name:'Xprinter'},{name:'Receipt'}],print:async job=>printed.push(job)};
  const api=()=>createHardwareSettings({store,adapters,native:true,shell:{openExternal:async s=>opened.push(s)},
    BrowserWindow:class{constructor(){this.webContents={print:(options,cb)=>{printed.push(options);cb(true);}};}async loadURL(url){loaded.push(url);}isDestroyed(){return false;}destroy(){}}});
  return {get store(){return store;},api,printed,opened,loaded,adapters,reopen(){store.close();store=createStore(filename,'test',{nativeDesktop:true});}};
}
test('hardware settings survive real SQLite reopen without changing archive, foot key, catalog or orders',async t=>{
  const f=fixture(t),old=f.store.equipment.getConfig(),catalog=f.store.api('GET','/api/price-catalog');
  const next={labelPrinterName:'Xprinter',receiptPrinterName:'Receipt',cameraDeviceId:'usb-selected',tagMode:'xprinter',labelVerified:true};
  await f.api()({action:'save',config:next});f.reopen();
  const s=await f.api()({action:'status'});
  assert.deepEqual(Object.fromEntries(Object.keys(next).map(k=>[k,s.config[k]])),next);
  assert.equal(s.config.receiptType,'windows');assert.equal(s.config.receiptWidth,80);
  assert.equal(s.config.receiptPromo,'');assert.equal(f.store.equipment.getConfig().photoArchiveRoot,old.photoArchiveRoot);
  assert.equal(f.store.equipment.getConfig().footSwitchKey,old.footSwitchKey);
  assert.deepEqual(f.store.api('GET','/api/price-catalog'),catalog);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  const roll=await f.api()({action:'save',config:{...next,tagMode:'roll'}});
  assert.equal(roll.config.tagMode,'roll');
});
test('invalid printer or unverified replacement is rejected before changing SQLite settings',async t=>{
  const f=fixture(t),before=await f.api()({action:'status'});
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'Xprinter',labelVerified:false}}),/30mm/);
  await assert.rejects(f.api()({action:'save',config:{...before.config,labelPrinterName:'missing',labelVerified:true}}),/목록/);
  assert.deepEqual((await f.api()({action:'status'})).config,before.config);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('stale preference write rolls back printer, camera and policy in the same SQLite transaction',t=>{
  const f=fixture(t),before=f.store.equipment.getConfig(),policy=f.store.equipment.drafts.tagPolicy();
  assert.throws(()=>f.store.saveHardwarePreferences({...before,mode:'real',hardwareConfirmed:true,
    printerName:'Xprinter',cameraDeviceId:'changed'},'printer','xprinter',{receiptPrinterName:'Receipt'},'stale'),/변경/);
  assert.deepEqual(f.store.equipment.getConfig(),before);
  assert.deepEqual(f.store.equipment.drafts.tagPolicy(),policy);
  assert.equal(f.store.storage({op:'get',key:KEY}),null);
});
test('explicit tests use chosen device, original 30mm tag adapter, and never create customer orders',async t=>{
  const f=fixture(t);
  await f.api()({action:'test',kind:'label',printerName:'Xprinter'});
  assert.equal(f.printed[0].printerName,'Xprinter');assert.equal(f.printed[0].payload.labelWidthMm,30);
  assert.equal(f.printed[0].payload.manualMaterial,'폴리에스테르');
  await f.api()({action:'test',kind:'receipt',printerName:'Receipt'});
  assert.equal(f.printed[1].deviceName,'Receipt');assert.equal(f.printed[1].silent,true);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
  await f.api()({action:'display-settings'});assert.deepEqual(f.opened,['ms-settings:display']);
});
test('browser cannot save or print and repeated in-flight test does not duplicate output',async t=>{
  const f=fixture(t);
  const browser=createHardwareSettings({store:f.store,adapters:f.adapters,native:false});
  await assert.rejects(browser({action:'test',kind:'receipt',printerName:'Receipt'}),/Windows/);
  let finish;f.adapters.print=()=>new Promise(resolve=>{finish=resolve;});
  const api=f.api(),first=api({action:'test',kind:'label',printerName:'Xprinter'});
  await new Promise(resolve=>setImmediate(resolve));
  await assert.rejects(api({action:'test',kind:'label',printerName:'Xprinter'}),/중복/);
  finish();await first;
});
test('영수증은 라벨·카메라 미설정이어도 독립 저장·재시작하며 미리보기와 인쇄가 결제를 바꾸지 않는다',async t=>{
  const f=fixture(t),old=f.store.equipment.getConfig(),catalog=f.store.api('GET','/api/price-catalog');
  const config={receiptType:'easycheck',receiptWidth:58,receiptPromo:'홍보 첫 줄\n홍보 둘째 줄',receiptPrinterName:'Receipt',receiptPort:'COM3'};
  await f.api()({action:'save-receipt',config});f.reopen();
  const s=await f.api()({action:'status'});
  for(const [k,v] of Object.entries(config))assert.equal(s.config[k],v);
  assert.deepEqual(f.store.equipment.getConfig(),old);assert.deepEqual(f.store.api('GET','/api/price-catalog'),catalog);
  const receipt={customerName:'임시 출력 검증',customerPhone:'01000000000',paymentType:'POSTPAID',
    items:[{name:'셔츠',quantity:2,amount:10000}]};
  const preview=await f.api()({action:'receipt-preview',receipt});
  assert.match(preview.html,/홍보 첫 줄<br>홍보 둘째 줄/);assert.match(preview.html,/\[ 후불 \]/);
  await f.api()({action:'receipt-print',receipt});
  assert.equal(f.printed.at(-1).deviceName,'Receipt');assert.equal(f.printed.at(-1).pageSize.width,58000);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('프린터·포트 조회 실패와 미연결 출력은 친절하게 실패하고 미리보기는 유지한다',async t=>{
  const f=fixture(t);f.adapters.printers=async()=>{throw Error('spooler unavailable');};
  f.adapters.ports=async()=>{throw Error('access denied');};
  const api=f.api(),s=await api({action:'status'});
  assert.deepEqual(s.printers,[]);assert.deepEqual(s.ports,[]);assert.match(s.printerMessage,/접수는 계속/);
  assert.match((await api({action:'receipt-preview'})).html,/세탁 접수증/);
  await assert.rejects(api({action:'receipt-print',config:{receiptType:'easycheck',receiptPrinterName:'Receipt'}}),/연결된 접수증/);
  assert.equal(f.printed.length,0);
});
test('홍보문구 3줄 저장 거부 시 기존 설정을 보존하고 카메라 단독 저장은 라벨을 요구하지 않는다',async t=>{
  const f=fixture(t),before=await f.api()({action:'status'});
  await assert.rejects(f.api()({action:'save-receipt',config:{receiptPromo:'1\n2\n3'}}),/2줄/);
  assert.deepEqual((await f.api()({action:'status'})).config,before.config);
  const after=await f.api()({action:'save-camera',config:{cameraDeviceId:'direct-camera'}});
  assert.equal(after.config.cameraDeviceId,'direct-camera');
  assert.equal(after.config.labelPrinterName,before.config.labelPrinterName);
});
test('저장된 접수증 폭은 프린터 조회 없이 복원되고 브라우저 미리보기도 같은 설정을 쓴다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{receiptType:'thermal',receiptWidth:58,receiptPromo:'기본 홍보 문구'}});
  f.reopen();let printerCalls=0;
  f.adapters.printers=async()=>{printerCalls++;throw Error('꺼진 프린터');};
  const restored=await f.api()({action:'receipt-preferences'});
  assert.equal(restored.config.receiptWidth,58);assert.equal(printerCalls,0);
  const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
  const api=createEquipmentApi(f.store,{native:false,printers:async()=>[]});
  const p=await api.api('POST','/api/equipment/command',{action:'receipt-preferences'});
  assert.equal(p.config.receiptWidth,58);
  const r=await api.api('POST','/api/equipment/command',{action:'receipt-preview'});
  assert.equal(r.width,58);assert.match(r.html,/기본 홍보 문구/);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('영구 저장한 두 줄 홍보와 할인 내역은 미리보기와 Windows 인쇄 창에 동일하게 전달된다',async t=>{
  const f=fixture(t);
  await f.api()({action:'save-receipt',config:{receiptType:'thermal',receiptWidth:80,
    receiptPrinterName:'Receipt',receiptPromo:'우리 매장 첫 안내\n정성스러운 세탁 서비스'}});
  f.reopen();
  const receipt={customerName:'출력검증',customerPhone:'01000000000',paymentType:'PREPAID',
    items:[{name:'검증코트',quantity:1,amount:200000}],totalAmount:170000,
    discountAmount:30000,discountRate:15,tierDiscountAmount:30000};
  const preview=await f.api()({action:'receipt-preview',receipt});
  await f.api()({action:'receipt-print',receipt});
  const printHtml=decodeURIComponent(f.loaded.at(-1).split(',').slice(1).join(','));
  for(const html of [preview.html,printHtml]){
    assert.match(html,/우리 매장 첫 안내<br>정성스러운 세탁 서비스/);
    assert.match(html,/할인 전 금액: 200,000원/);
    assert.match(html,/구간 할인 \(15%\): -30,000원/);
    assert.match(html,/최종 할인 합계 금액: 170,000원/);
  }
  assert.equal(f.printed.at(-1).deviceName,'Receipt');
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
