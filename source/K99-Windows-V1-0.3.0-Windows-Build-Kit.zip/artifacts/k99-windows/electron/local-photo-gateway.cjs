'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {fileURLToPath}=require('node:url');
const ACTIVE='k99-active-staff-intake-v1';
const safeId=id=>typeof id==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(id);
const fail=(message,status=403)=>Object.assign(Error(message),{status});
function createLocalPhotoGateway({store,roots=['D:\\K99과천매장\\01_고객세탁사진','D:\\K99과천매장\\02_세탁전후사진']}){
  const grants=new Map();
  const normalized=value=>{
    try{return path.resolve(String(value).startsWith('file:')?fileURLToPath(value):value);}
    catch{throw fail('사진 경로 형식 오류');}
  };
  const same=(a,b)=>process.platform==='win32'?a.toLowerCase()===b.toLowerCase():a===b;
  const inside=(file,root)=>same(file.slice(0,root.length+1),root+path.sep);
  function members(input={}){
    const all=[];
    const add=(orderId,g,unitKey)=>{
      if(input.garmentId&&input.garmentId!==g.garmentId)return;
      const photos=[...(g.photoHistory||[]),g.beforePhoto,g.completionPhoto].filter(Boolean);
      if(g.photoPath&&!photos.some(p=>p.path===g.photoPath))photos.push({path:g.photoPath,role:'intake',timestamp:g.photoTimestamp});
      for(const p of photos)if(p.status!=='simulated'&&p.mode!=='mock')
        all.push({orderId,garmentId:g.garmentId,itemName:g.itemName,unitKey,metadata:p});
    };
    const active=JSON.parse(store.storage({op:'get',key:ACTIVE})||'null');
    if(active?.draftId&&(!input.orderId||input.orderId===active.draftId))
      for(const unit of store.equipment.drafts.state(active.draftId).units){
        const row=active.data?.rows?.find(r=>r.id===unit.rowId);
        if(row?.itemId===unit.itemId&&unit.unitIndex<=row.quantity)add(active.draftId,unit.garment,unit.unitKey);
      }
    const ids=new Set(input.orderId?[input.orderId]:store.equipment.state().photos.map(p=>p.orderId).filter(Boolean));
    for(const id of ids)try{
      const order=store.equipment.getOrder(id);
      if(!order.deletedAt&&order.status!=='cancelled')for(const g of order.garments||[])add(id,g,`${g.itemIndex||1}:${g.unitIndex||1}`);
    }catch{/* Active drafts do not yet have a confirmed order. */}
    return all;
  }
  const resourceId=m=>'local-'+crypto.createHash('sha256').update(JSON.stringify([
    m.orderId,m.garmentId,m.metadata.path,m.metadata.sourcePhotoId||'',
  ])).digest('hex');
  const eligible=m=>m?.metadata.role==='intake'&&
    (/^MOBILE_/i.test(m.metadata.archiveFile||path.basename(m.metadata.path||''))||m.metadata.purpose==='care-label');
  function linked(input){
    const matches=members(input).filter(m=>input.photoId
      ?m.metadata.sourcePhotoId===input.photoId||resourceId(m)===input.photoId
      :input.pathHint&&m.metadata.path&&same(normalized(m.metadata.path),normalized(input.pathHint)));
    const unique=new Map(matches.map(m=>[resourceId(m),m]));
    if(unique.size>1)throw fail('사진 연결이 여러 건입니다. 주문·의류를 지정해 다시 확인하세요.');
    return unique.values().next().value;
  }
  function legacyBytes(member){
    const filename=normalized(member.metadata.path);
    const root=roots.map(normalized).find(r=>inside(filename,r));
    if(!root||!/\.(jpe?g|png)$/i.test(filename))throw fail('등록된 매장 사진 폴더의 JPEG/PNG만 읽을 수 있습니다.');
    // Reject all symlink/junction components, not only the final filename.
    let part=path.parse(filename).root;
    for(const segment of filename.slice(part.length).split(path.sep).filter(Boolean)){
      part=path.join(part,segment);
      if(fs.lstatSync(part).isSymbolicLink())throw fail('사진 경로의 링크·정션은 읽지 않습니다.');
    }
    if(!inside(fs.realpathSync(filename),fs.realpathSync(root)))throw fail('사진 경로가 매장 폴더를 벗어났습니다.');
    const stat=fs.statSync(filename);
    if(!stat.isFile()||stat.size<24||stat.size>40*1024*1024)throw fail('사진 파일 형식·크기를 확인하세요.',400);
    const bytes=fs.readFileSync(filename),png=bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
    if(!png&&!(bytes[0]===255&&bytes[1]===216&&bytes[2]===255))throw fail('실제 JPEG/PNG 이미지가 아닙니다.',400);
    const hash=crypto.createHash('sha256').update(bytes).digest('hex');
    if(member.metadata.sha256&&member.metadata.sha256!==hash)throw fail('사진 무결성이 일치하지 않습니다.',409);
    return {bytes,contentType:png?'image/png':'image/jpeg'};
  }
  function source(input={}){
    if(input.photoId&&!safeId(input.photoId))throw fail('사진 식별자 오류',400);
    const member=linked(input);
    if((input.orderId||input.garmentId||input.pathHint)&&!member)throw fail('해당 주문·의류에 연결된 사진 기록이 없습니다.',404);
    const id=member?.metadata.sourcePhotoId||input.photoId;
    if(id)try{
      store.equipment.photoFile(id); // Existing canonical hash verification stays intact.
      return {photoId:id,url:`k99://app/api/equipment/photos/${encodeURIComponent(id)}`,careLabelEligible:eligible(member)};
    }catch(error){
      if(error.status===409)throw error; // Never hide a canonical integrity failure using another copy.
      if(!member?.metadata.path||member.metadata.path.startsWith('/api/'))throw error;
    }
    if(!member?.metadata.path)throw fail('등록된 사진 원본을 찾을 수 없습니다.',404);
    legacyBytes(member);
    const token=resourceId(member);
    if(grants.size>=512)grants.delete(grants.keys().next().value);
    grants.set(token,{orderId:member.orderId,garmentId:member.garmentId});
    return {photoId:token,url:`k99://app/local-photos/${token}`,careLabelEligible:eligible(member)};
  }
  function read(id,reference={}){
    if(!safeId(id))throw fail('사진 식별자 오류',400);
    if(!id.startsWith('local-'))return store.equipment.photoFile(id);
    const member=linked({...grants.get(id),...reference,photoId:id});
    if(!member||resourceId(member)!==id)throw fail('사진 연결이 만료되었거나 변경되었습니다.',404);
    return legacyBytes(member);
  }
  function analysisTarget(id,reference={}){
    const member=linked({...grants.get(id),...reference,photoId:id});
    if(!member||!eligible(member))throw fail('현재 의류에 연결된 케어라벨 사진만 분석할 수 있습니다.');
    return {photoId:id,orderId:member.orderId,garmentId:member.garmentId,unitKey:member.unitKey,
      itemName:member.itemName,sequence:members({orderId:member.orderId,garmentId:member.garmentId})
        .findIndex(m=>resourceId(m)===resourceId(member))};
  }
  function list(){
    const indexed=new Map();
    for(const m of members()){
      const id=m.metadata.sourcePhotoId;
      if(id&&m.metadata.timestamp)indexed.set(id,{id,filename:m.metadata.archiveFile||id+'.jpg',
        timestamp:m.metadata.timestamp,sourcePath:m.metadata.path,origin:'bridge'});
    }
    return [...indexed.values()].sort((a,b)=>b.timestamp.localeCompare(a.timestamp)).slice(0,30);
  }
  async function response(request){
    const u=new URL(request.url);
    if(u.protocol!=='k99:'||u.host!=='app'||!['GET','HEAD'].includes(request.method)||u.search||u.hash)
      return new Response('Forbidden',{status:403});
    const prefix=u.pathname.startsWith('/local-photos/')?'/local-photos/':'/api/equipment/photos/';
    try{
      const id=decodeURIComponent(u.pathname.slice(prefix.length));
      const photo=read(id);
      return new Response(request.method==='HEAD'?null:photo.bytes,{headers:{'Content-Type':photo.contentType,
        'Content-Length':String(photo.bytes.length),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
    }catch(error){return new Response('사진 원본·연결·접근 권한을 확인하세요.',{status:error.status||404});}
  }
  return {source,read,analysisTarget,list,response,reset:()=>grants.clear()};
}
module.exports={createLocalPhotoGateway};
