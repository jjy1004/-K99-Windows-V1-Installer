'use strict';
// The staging tool resolves this workspace reference into the bundled local core.
module.exports=require('@workspace/k99-local/receipt-template.cjs');
