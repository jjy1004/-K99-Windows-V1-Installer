'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {EventEmitter}=require('node:events');
const {createAiAccountVault,AI_ORIGIN}=require('./ai-account-vault.cjs');
const {migrateAiPartition,createAiSession,AI_PARTITION,FINGERPRINT_SCRIPT,AUTH_CACHE_SCRIPT}=require('./ai-session.cjs');
function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-ai-account-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  // Authenticated cipher for test isolation; this is NOT a Windows DPAPI test.
  const key=crypto.randomBytes(32);
  const safeStorage={isEncryptionAvailable:()=>true,
    encryptString(value){const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',key,iv);
      const body=Buffer.concat([c.update(value,'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),body]);},
    decryptString(value){const d=crypto.createDecipheriv('aes-256-gcm',key,value.subarray(0,12));d.setAuthTag(value.subarray(12,28));
      return Buffer.concat([d.update(value.subarray(28)),d.final()]).toString('utf8');}};
  const options={userData:root,safeStorage,platform:'win32'};
  return {root,options,vault:createAiAccountVault(options)};
}
const credentials={phone:'01000001234',password:'a1234'};
test('account survives reopening encrypted vault and status never returns password',t=>{
  const {root,options,vault}=fixture(t);
  assert.equal(vault.save(credentials).configured,true);
  const disk=fs.readFileSync(path.join(root,'integrations/ai-account.dpapi.json'),'utf8');
  assert.ok(!disk.includes(credentials.phone)&&!disk.includes(credentials.password));
  const reopened=createAiAccountVault(options);assert.deepEqual(reopened.account(),credentials);
  assert.equal(reopened.status().password,undefined);assert.equal(reopened.status().phone,credentials.phone);
});
test('password validation follows actual member API; blank password only retains same account',t=>{
  const {vault}=fixture(t);
  for(const password of ['12345','aa123','abc','a12345'])assert.throws(()=>vault.save({...credentials,password}),/5자리/);
  vault.save(credentials);vault.save({...credentials,password:''});assert.deepEqual(vault.account(),credentials);
  assert.throws(()=>vault.save({phone:'01000005678',password:''}),/새 계정/);
});
const cookie=()=>({name:'test_auth',value:'fixture-session',domain:new URL(AI_ORIGIN).hostname,path:'/',secure:true,httpOnly:true,hostOnly:true,session:true,sameSite:'lax'});
test('clearing account retains origin-scoped cookie snapshot and never affects orders',t=>{
  const {root,vault}=fixture(t);vault.save(credentials);vault.saveCookies([cookie()]);
  assert.equal(vault.clear().configured,false);assert.equal(vault.cookies().length,1);
  assert.equal(fs.existsSync(path.join(root,'k99.db')),false);
});
test('unavailable encryption refuses plaintext persistence',t=>{
  const {root,options}=fixture(t);
  const vault=createAiAccountVault({...options,safeStorage:{isEncryptionAvailable:()=>false}});
  assert.equal(vault.status().available,false);assert.throws(()=>vault.save(credentials),/암호화/);
  assert.equal(fs.existsSync(path.join(root,'integrations')),false);
});
test('wrong Windows key/corrupt vault is reported without overwriting the original',t=>{
  const {root,options,vault}=fixture(t);vault.save(credentials);
  const file=path.join(root,'integrations/ai-account.dpapi.json'),original=fs.readFileSync(file);
  const broken=createAiAccountVault({...options,safeStorage:{isEncryptionAvailable:()=>true,decryptString(){throw Error('private error');}}});
  assert.match(broken.status().error,/원본은 보존/);assert.throws(()=>broken.save(credentials));
  assert.deepEqual(fs.readFileSync(file),original);
});
test('legacy partition copy retains all origin localStorage including device token and leaves original intact',t=>{
  const {root}=fixture(t),old=path.join(root,'Partitions/k99-washcare-ai/Local Storage/leveldb');
  fs.mkdirSync(old,{recursive:true});fs.writeFileSync(path.join(old,'test.log'),'k99_device_token=fixture-token; k99.device.installation.v1=fixture-id');
  assert.equal(migrateAiPartition(root),true);assert.equal(AI_PARTITION,'persist:k99-ai');
  const migrated=path.join(root,'Partitions/k99-ai/Local Storage/leveldb/test.log');
  assert.equal(fs.readFileSync(migrated,'utf8'),fs.readFileSync(path.join(old,'test.log'),'utf8'));
  fs.writeFileSync(migrated,'new-session');assert.equal(migrateAiPartition(root),false);
  assert.equal(fs.readFileSync(migrated,'utf8'),'new-session');
});
test('migration refuses symlinks and cannot replace an existing new partition',t=>{
  const {root}=fixture(t),old=path.join(root,'Partitions/k99-washcare-ai');
  fs.mkdirSync(old,{recursive:true});fs.symlinkSync(root,path.join(old,'external'));
  assert.throws(()=>migrateAiPartition(root),/원본|기존 저장소/);
  assert.equal(fs.existsSync(path.join(root,'Partitions/k99-ai')),false);
});
function webFixture(t){
  const f=fixture(t),cookies=new EventEmitter();let jar=[],calls=[],scripts=[],loads=[];
  cookies.get=async()=>jar;
  cookies.set=async value=>{jar.push({...value,domain:new URL(value.url).hostname,hostOnly:true});};
  cookies.flushStore=async()=>{};
  const session={cookies,flushStorageData(){},fetch:async(url,options)=>{
    calls.push({url,options});jar=[cookie()];cookies.emit('changed',{},jar[0],null,false);
    return {ok:true,json:async()=>({authenticated:true,role:'operator'})};
  }};
  const win={webContents:{session,getURL:()=>AI_ORIGIN+'/',
    executeJavaScript:async text=>{scripts.push(text);return text===AUTH_CACHE_SCRIPT?{phone:'',deviceToken:''}:'f'.repeat(64);}},
    loadURL:async url=>{loads.push(url);}};
  const auth=createAiSession({sessionData:f.root,vault:f.vault});
  return {...f,auth,win,session,cookies,calls,scripts,loads,setJar:value=>{jar=value;}};
}
test('saved-account login uses pinned HTTPS POST, stable fingerprint and redirects to search with label query',async t=>{
  const f=webFixture(t);f.vault.save(credentials);f.auth.prepare();await f.auth.attach(f.session);
  assert.equal((await f.auth.connect(f.win,AI_ORIGIN+'/?material=x&color=y')).authenticated,true);
  assert.equal(f.calls[0].url,AI_ORIGIN+'/api/washcare/member/login');
  const opts=f.calls[0].options;assert.equal(opts.method,'POST');assert.equal(opts.redirect,'error');
  assert.deepEqual(JSON.parse(opts.body),{...credentials,fingerprint:'f'.repeat(64)});
  assert.ok(!f.calls[0].url.includes(credentials.phone));assert.ok(!f.scripts.join('').includes(credentials.password));
  assert.equal(new URL(f.loads[0]).pathname,'/search');assert.equal(new URL(f.loads[0]).searchParams.get('material'),'x');
  assert.match(FINGERPRINT_SCRIPT,/k99\.device\.installation\.v1/);
  await f.auth.flush();
});
test('native login reuses same-account device token and stores server-issued cache for later PIN-only entry',async t=>{
  const f=webFixture(t);f.vault.save(credentials);await f.auth.attach(f.session);
  const values=new Map([['k99_saved_phone',credentials.phone],['k99_device_token','a'.repeat(40)]]);
  const page={localStorage:{getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)},
    document:{cookie:''},encodeURIComponent,decodeURIComponent};
  const vm=require('node:vm');
  f.win.webContents.executeJavaScript=async script=>{
    f.scripts.push(script);return script===FINGERPRINT_SCRIPT?'f'.repeat(64):vm.runInNewContext(script,page);
  };
  f.session.fetch=async(url,options)=>{
    f.calls.push({url,options});
    return {ok:true,json:async()=>({authenticated:true,role:'operator',registeredPhone:credentials.phone,deviceToken:'b'.repeat(40)})};
  };
  assert.equal((await f.auth.connect(f.win,AI_ORIGIN+'/')).authenticated,true);
  assert.equal(JSON.parse(f.calls[0].options.body).deviceToken,'a'.repeat(40));
  assert.equal(values.get('k99_saved_phone'),credentials.phone);
  assert.equal(values.get('k99_device_token'),'b'.repeat(40));
  assert.match(page.document.cookie,/SameSite=Strict; Secure/);
  assert.ok(!f.scripts.join('\n').includes(credentials.password));
});
test('cached token of a different phone is never attached to saved-account login',async t=>{
  const f=webFixture(t);f.vault.save(credentials);await f.auth.attach(f.session);
  f.win.webContents.executeJavaScript=async script=>script===AUTH_CACHE_SCRIPT?
    {phone:'01000009999',deviceToken:'a'.repeat(40)}:'f'.repeat(64);
  assert.equal((await f.auth.connect(f.win,AI_ORIGIN+'/')).authenticated,true);
  assert.equal(JSON.parse(f.calls[0].options.body).deviceToken,undefined);
});
test('mismatched registered account cannot overwrite the pinned site login cache',async t=>{
  const f=webFixture(t);f.vault.save(credentials);await f.auth.attach(f.session);
  f.session.fetch=async()=>({ok:true,json:async()=>({authenticated:true,role:'operator',registeredPhone:'01000009999'})});
  assert.ok((await f.auth.connect(f.win,AI_ORIGIN+'/')).warning);
  assert.equal(f.loads.length,0);
  assert.ok(!f.scripts.some(script=>script.includes("localStorage.setItem('k99_saved_phone'")));
});
test('blank account is token/cookie-only and custom origins never receive stored credentials',async t=>{
  const f=webFixture(t);await f.auth.attach(f.session);await f.auth.connect(f.win,AI_ORIGIN);assert.equal(f.calls.length,0);
  f.vault.save(credentials);await f.auth.connect(f.win,'https://elsewhere.example.test/');assert.equal(f.calls.length,0);
});
test('server rejection remains manual login and returns no response secrets or fake authentication',async t=>{
  const f=webFixture(t);f.vault.save(credentials);
  f.session.fetch=async()=>({ok:false,json:async()=>({password:credentials.password,authenticated:true})});
  const result=await f.auth.connect(f.win,AI_ORIGIN);
  assert.ok(result.warning);assert.equal(result.authenticated,undefined);
  assert.ok(!JSON.stringify(result).includes(credentials.password));assert.equal(f.loads.length,0);
});
test('session-cookie snapshot survives reopen; logout/removal persists empty state instead of resurrecting it',async t=>{
  const f=webFixture(t);await f.auth.attach(f.session);f.setJar([cookie()]);await f.auth.flush();
  const second=createAiSession({sessionData:f.root,vault:createAiAccountVault(f.options)});
  const restored=[],jar=new EventEmitter();
  jar.get=async()=>restored;jar.set=async value=>{restored.push(value);};jar.flushStore=async()=>{};
  await second.attach({cookies:jar,flushStorageData(){}});
  assert.equal(restored[0].value,'fixture-session');assert.equal(restored[0].expirationDate,undefined);
  f.setJar([]);await f.auth.flush();assert.deepEqual(f.vault.cookies(),[]);
});
test('expired cookies and foreign domains are excluded',t=>{
  const f=fixture(t);f.vault.saveCookies([cookie(),{...cookie(),domain:'evil.test'},
    {...cookie(),expirationDate:1}]);assert.equal(f.vault.cookies().length,1);
});
test('admin privileges come only from authenticated server role and key',async t=>{
  const f=webFixture(t);f.vault.save(credentials);
  f.session.fetch=async()=>({ok:true,json:async()=>({authenticated:true,role:'admin',adminEntryKey:'fixture-admin-entry'})});
  await f.auth.connect(f.win,AI_ORIGIN);
  assert.ok(f.scripts.some(text=>text.includes('k99.admin.entry')));
  assert.ok(!f.scripts.some(text=>text.includes('localStorage.setItem')&&text.includes('fixture-admin-entry')));
  f.session.fetch=async()=>({ok:true,json:async()=>({authenticated:true,role:'guest',adminEntryKey:'invalid'})});
  assert.ok((await f.auth.connect(f.win,AI_ORIGIN)).warning);
});
