'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {createGuideVideos,inspectMp4}=require('./guide-videos.cjs');
const {createIdleVideos}=require('./idle-videos.cjs');
const box=(type,content)=>{const b=Buffer.alloc(8);b.writeUInt32BE(content.length+8);b.write(type,4);return Buffer.concat([b,content]);};
// Structural fixture only. Browser playback uses a real decoded MP4 separately.
const sample=()=>Buffer.concat([box('ftyp',Buffer.from('isom0000')),
  box('moov',box('trak',box('mdia',box('hdlr',Buffer.concat([Buffer.alloc(8),Buffer.from('vide')]))))),
  box('mdat',Buffer.from('sample-video-data'))]);
function fixture(t) {
  const parent=fs.mkdtempSync(path.join(os.tmpdir(),'k99-guide-'));
  t.after(()=>fs.rmSync(parent,{recursive:true,force:true}));
  const opened=[];
  const options={parent,openPath:async folder=>{opened.push(folder);return '';}};
  const api=createGuideVideos(options),folder=path.join(parent,'개별 안내 영상');
  return {parent,folder,api,opened,options,write:(name,bytes=sample())=>fs.writeFileSync(path.join(folder,name),bytes)};
}
const req=(name='value.mp4',headers)=>new Request(`k99://app/videos/${name}`,{headers});

test('빈 폴더는 네 기본 슬롯, 1~4 교체는 대기 목록에 섞이지 않는다',async t=>{
  const f=fixture(t);assert.deepEqual(f.api.list().slots.map(s=>s.source),Array(4).fill('default'));
  f.write('01_새 가격 안내.mp4');
  const result=f.api.list();
  assert.equal(result.success,true);assert.equal(result.slots[0].title,'새 가격 안내');
  assert.deepEqual(result.slots.map(s=>s.source),['custom','default','default','default']);
  assert.deepEqual(createIdleVideos({folder:f.parent}).list().files,[]);
  await f.api.open();assert.deepEqual(f.opened,[f.folder]);
});
test('모든 슬롯 제목·파일과 재실행·교체·삭제 기본 복귀를 확인한다',t=>{
  const f=fixture(t);
  for(let i=1;i<=4;i++)f.write(`0${i}_교체 제목 ${i}.mp4`);
  assert.deepEqual(f.api.list().slots.map(s=>s.title),[1,2,3,4].map(i=>`교체 제목 ${i}`));
  assert.deepEqual(createGuideVideos(f.options).list(),f.api.list());
  fs.unlinkSync(path.join(f.folder,'02_교체 제목 2.mp4'));f.write('02_다른 제목.MP4');
  assert.equal(f.api.list().slots[1].title,'다른 제목');
  fs.unlinkSync(path.join(f.folder,'01_교체 제목 1.mp4'));
  assert.equal(f.api.list().slots[0].title,'세탁 가격 안내');
});
test('사용자 파일 응답은 실제 바이트·Range·HEAD를 유지하며 기본 파일은 넘긴다',async t=>{
  const f=fixture(t);f.write('01_시험.mp4');f.api.list();
  const response=await f.api.response(req());
  assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),sample());
  const range=await f.api.response(req('value.mp4',{range:'bytes=4-7'}));
  assert.equal(range.status,206);assert.equal(await range.text(),'ftyp');
  assert.equal((await f.api.response(req('value.mp4',{range:'bytes=99999-'}))).status,416);
  assert.equal(await f.api.response(req('process.mp4')),null);
  assert.equal(await f.api.response(req('promo.mp4')),null);
  assert.equal(await f.api.response(req('../evil.mp4')),null);
  const head=await f.api.response(new Request('k99://app/videos/value.mp4',{method:'HEAD'}));
  assert.equal(head.status,200);assert.equal(await head.text(),'');
});
for (const [label,data] of [['빈 파일',Buffer.alloc(0)],['가짜 MP4',Buffer.from('not a movie')],
  ['잘린 파일',sample().subarray(0,30)],['영상 트랙 없는 파일',Buffer.concat([box('ftyp',Buffer.from('isom0000')),box('moov',box('free',Buffer.from('abc'))),box('mdat',Buffer.from('abc'))])]]) {
  test(`${label}은 오류와 기본값을 표시한다`,t=>{
    const f=fixture(t);f.write('01_손상.mp4',data);
    const r=f.api.list();assert.equal(r.success,false);assert.equal(r.slots[0].source,'default');assert.ok(r.slots[0].error);
    assert.throws(()=>inspectMp4(path.join(f.folder,'01_손상.mp4')));
  });
}
test('잘못된 이름·중복 번호·빈 제목을 숨기지 않는다',t=>{
  const f=fixture(t);f.write('01_하나.mp4');f.write('01_둘.mp4');f.write('05_안됨.mp4');f.write('02_   .mp4');
  const r=f.api.list();assert.equal(r.success,false);assert.equal(r.slots[0].source,'default');
  assert.ok(r.errors.some(s=>s.includes('중복')));assert.ok(r.errors.some(s=>s.includes('05_')));
  assert.ok(r.slots[1].error.includes('제목'));
});
test('선택 후 삭제·손상은 재생 실패로 명시하며 다른 영상으로 숨기지 않는다',async t=>{
  const f=fixture(t);f.write('01_시험.mp4');f.api.list();f.write('01_시험.mp4',Buffer.alloc(0));
  assert.equal((await f.api.response(req())).status,415);
  fs.unlinkSync(path.join(f.folder,'01_시험.mp4'));
  assert.equal((await f.api.response(req())).status,415);
});
test('폴더·파일 링크와 폴더 접근 실패를 거절한다',async t=>{
  const f=fixture(t),outside=fs.mkdtempSync(path.join(os.tmpdir(),'k99-guide-out-'));
  t.after(()=>fs.rmSync(outside,{recursive:true,force:true}));
  fs.writeFileSync(path.join(outside,'outside.mp4'),sample());
  fs.symlinkSync(path.join(outside,'outside.mp4'),path.join(f.folder,'01_링크.mp4'));
  assert.equal(f.api.list().success,false);
  fs.unlinkSync(path.join(f.folder,'01_링크.mp4'));fs.rmdirSync(f.folder);
  fs.symlinkSync(outside,f.folder,process.platform==='win32'?'junction':'dir');
  assert.throws(()=>f.api.list(),/링크·정션/);
  await assert.rejects(f.api.open(),/링크·정션/);
  assert.throws(()=>createGuideVideos({openPath:async()=>''}).list(),/Windows/);
});
test('기본 설치 영상 누락도 정상으로 표시하지 않는다',t=>{
  const f=fixture(t),api=createGuideVideos({...f.options,defaultRoot:f.parent});
  const r=api.list();assert.equal(r.success,false);assert.equal(r.slots[0].defaultAvailable,false);
  assert.ok(r.errors.length===4);
});
