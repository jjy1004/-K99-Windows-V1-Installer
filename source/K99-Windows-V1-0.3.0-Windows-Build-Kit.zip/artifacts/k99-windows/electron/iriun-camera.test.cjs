'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const req=require('node:module').createRequire(path.join(__dirname,'../package.json')),ts=req('typescript');
const cameraDevice={};new Function('exports','require',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/camera-device.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(cameraDevice,()=>{throw Error('장치 선택 검사는 외부 모듈을 호출하지 않습니다.');});
const api={};new Function('exports','require',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/iriun-camera.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(api,name=>name==='./camera-device'?cameraDevice:{inspectCameraStream:async()=>{}});
const device=(id,label)=>({kind:'videoinput',deviceId:id,label});
const phone=device('phone','Iriun Webcam'),usb=device('usb','SU200MB USB Webcam');
test('desktop boot never keeps a hidden prewarmed camera stream alive outside the modal',()=>{
  const boot=fs.readFileSync(path.join(__dirname,'../src/main.tsx'),'utf8');
  assert.doesNotMatch(boot,/\bwarmPreferredCamera\b|\bgetUserMedia\s*\(/);
});
function stream(id='phone',label='Iriun Webcam'){
  const tracks=[{label,getSettings:()=>({deviceId:id}),stopped:0,stop(){this.stopped++;}}];
  return {getTracks:()=>tracks,getVideoTracks:()=>tracks};
}
const open=(media,signal=new AbortController().signal)=>api.openIriunCamera(media,signal,async()=>{},6000,{wait:async()=>{}});
test('Iriun-only inventory rejects physical USB, OBS and non-Iriun drivers',()=>{
  assert.deepEqual(api.iriunDevices([usb,device('obs','OBS Iriun Virtual'),device('droid','DroidCam'),phone]),[phone]);
  assert.deepEqual(api.iriunDevices([device('compact','IriunWebcam #2')]).map(d=>d.deviceId),['compact']);
  assert.equal(cameraDevice.isSmartphoneCamera('IriunWebcam #2'),true);
});
test('Iriun uses only a current exact device ID, no size, frame or colour constraints',async()=>{
  let constraints;const s=stream();
  assert.equal(await open({enumerateDevices:async()=>[usb,phone],getUserMedia:async c=>{constraints=c;return s;}}),s);
  assert.deepEqual(constraints,{audio:false,video:{deviceId:{exact:'phone'}}});
});
test('a rejected exact device selection retries a plain preference for the same Iriun',async()=>{
  const calls=[];const s=stream();
  await open({enumerateDevices:async()=>[phone],getUserMedia:async c=>{calls.push(c);if(calls.length===1)throw Error('size');return s;}});
  assert.deepEqual(calls[1],{audio:false,video:{deviceId:'phone'}});
});
test('without Iriun no physical or virtual alternative is opened',async()=>{
  const calls=[];
  await assert.rejects(open({enumerateDevices:async()=>[usb],getUserMedia:async c=>{calls.push(c);return stream('usb','USB Webcam');}}),/Iriun Webcam/);
  assert.equal(calls.length,0);
});
test('legacy saved device arguments cannot override Iriun-only discovery',async()=>{
  const s=stream(),calls=[];
  const media={enumerateDevices:async()=>[phone,usb,device('obs','OBS Virtual Camera')],
    getUserMedia:async c=>{calls.push(c);return s;}};
  assert.equal(await api.openIriunCamera(media,new AbortController().signal,async()=>{},6000,'usb'),s);
  assert.deepEqual(calls[0].video.deviceId,{exact:'phone'});
  assert.equal(await api.openIriunCamera(media,new AbortController().signal,async()=>{},6000,'obs'),s);
  assert.deepEqual(calls[1].video.deviceId,{exact:'phone'});
});
test('closing while permission is pending rejects immediately and stops a late stream',async()=>{
  let resolve;const abort=new AbortController(),s=stream();
  const pending=open({enumerateDevices:async()=>[phone],getUserMedia:()=>new Promise(r=>{resolve=r;})},abort.signal);
  await new Promise(r=>setImmediate(r));abort.abort();
  await assert.rejects(pending,{name:'AbortError'});resolve(s);await new Promise(r=>setImmediate(r));
  assert.equal(s.getTracks()[0].stopped,1);
});
test('wrong returned device is released and never shown or stored',async()=>{
  const streams=[];await assert.rejects(open({enumerateDevices:async()=>[phone,usb],getUserMedia:async()=>{
    const s=stream('usb','SU200MB');streams.push(s);return s;}}),/다른 카메라/);
  assert(streams.every(s=>s.getTracks()[0].stopped===1));
});
test('close during first-frame decoding immediately releases the acquired camera',async()=>{
  const s=stream(),abort=new AbortController();
  let decoding=false;
  const pending=api.openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:async()=>s},abort.signal,
    ()=>{decoding=true;return new Promise(()=>{});});
  while(!decoding)await new Promise(r=>setImmediate(r));
  abort.abort();await assert.rejects(pending,{name:'AbortError'});
  assert(s.getTracks()[0].stopped>=1);
});
test('a timed-out permission request does not start overlapping camera opens; late tracks stop',async()=>{
  let resolve,calls=0;const s=stream();
  await assert.rejects(api.openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:()=>{
    calls++;return new Promise(r=>{resolve=r;});}},new AbortController().signal,async()=>{},15),{name:'CameraOpenTimeout'});
  assert.equal(calls,1);resolve(s);await new Promise(r=>setImmediate(r));assert.equal(s.getTracks()[0].stopped,1);
});
test('closing during device enumeration cancels without a generic permission camera probe',async()=>{
  let finish,opens=0;const s=stream(),abort=new AbortController();
  const pending=open({enumerateDevices:()=>new Promise(r=>{finish=r;}),getUserMedia:async()=>{opens++;return s;}},abort.signal);
  while(!finish)await new Promise(r=>setImmediate(r));
  abort.abort();assert.equal(opens,0);
  finish([phone]);await assert.rejects(pending,{name:'AbortError'});
});
test('permission-denied is not retried and UI contains no USB/manual controls',async()=>{
  let calls=0;await assert.rejects(open({enumerateDevices:async()=>[phone],getUserMedia:async()=>{
    calls++;throw Object.assign(Error('denied'),{name:'NotAllowedError'});}}),/denied/);assert.equal(calls,1);
  const text=fs.readFileSync(path.join(__dirname,'../src/NativeDraftCamera.tsx'),'utf8');
  assert.doesNotMatch(text,/CameraColorSliders|correctCameraCanvas|select-ndc-device|SmartphoneCameraHelp/);
  assert.doesNotMatch(text,/Wi-Fi 무선 연결|USB 유선 연결|className="ndc__connection-guide"/);
  for(const value of ['사진 촬영 (A / F7)','확대 (B / F8)','다음 세탁물 (C / F9)','접수 최종 확인'])
    assert(text.includes(value),value);
});
test('첫 Iriun에 영상이 없으면 해제하고 실제 프레임이 들어오는 두 번째 Iriun을 고른다',async()=>{
  const second=device('phone2','Iriun Webcam #2'),opened=[];
  const media={enumerateDevices:async()=>[usb,phone,second],getUserMedia:async c=>{
    const id=c.video.deviceId.exact||c.video.deviceId;
    const s=stream(id,id==='phone2'?second.label:phone.label);opened.push(s);return s;
  }};
  const result=await api.openIriunCamera(media,new AbortController().signal,async s=>{
    if(s.getVideoTracks()[0].getSettings().deviceId==='phone')throw Error('첫 프레임 없음');
  },6000,{wait:async()=>{}});
  assert.equal(result.getVideoTracks()[0].getSettings().deviceId,'phone2');
  assert.equal(opened.length,2);
  assert.equal(opened[0].getTracks()[0].stopped,1);
  assert.equal(result.getTracks()[0].stopped,0);
});
test('최대 15회 새 목록을 읽고 실패 사이에만 1초 재시도 대기를 요청한다',async()=>{
  let enumerations=0,waits=0,opens=0;
  await assert.rejects(api.openIriunCamera({enumerateDevices:async()=>{enumerations++;return [usb];},
    getUserMedia:async()=>{opens++;throw Error('다른 장치를 열면 안 됩니다.');}},new AbortController().signal,async()=>{},6000,
    {wait:async signal=>{assert.equal(signal.aborted,false);waits++;}}),/Iriun Webcam/);
  assert.equal(api.IRIUN_MAX_ATTEMPTS,15);
  assert.equal(enumerations,15);assert.equal(waits,14);assert.equal(opens,0);
  const source=fs.readFileSync(path.join(__dirname,'../src/iriun-camera.ts'),'utf8');
  assert.match(source,/setTimeout\(\(\)=>\{[^}]+\},1000\)/);
});
test('부팅 후 일곱 번째 탐색에서 나타난 새 장치 ID로 자동 연결한다',async()=>{
  let checks=0,waits=0;const s=stream('rebooted','Iriun Webcam #3');
  const result=await api.openIriunCamera({enumerateDevices:async()=>++checks<7?[]:[device('rebooted','Iriun Webcam #3')],
    getUserMedia:async c=>{assert.deepEqual(c.video.deviceId,{exact:'rebooted'});return s;}},new AbortController().signal,async()=>{},6000,
    {wait:async()=>{waits++;}});
  assert.equal(result,s);assert.equal(checks,7);assert.equal(waits,6);
});
test('재시도 대기 중 촬영창을 닫으면 새 장치를 다시 열지 않는다',async()=>{
  const abort=new AbortController();let enumerations=0;
  await assert.rejects(api.openIriunCamera({enumerateDevices:async()=>{enumerations++;return [];},
    getUserMedia:async()=>assert.fail('닫힌 창에서 촬영 금지')},abort.signal,async()=>{},6000,
    {wait:async()=>{abort.abort();}}),{name:'AbortError'});
  assert.equal(enumerations,1);
});
test('권한 요청 취소 후 응답이 늦게 와도 다른 복구 요청과 중복 획득하지 않는다',async()=>{
  const abort=new AbortController(),late=stream();let finish,opens=0;
  const media={enumerateDevices:async()=>[phone],getUserMedia:()=>{
    opens++;return opens===1?new Promise(resolve=>{finish=resolve;}):Promise.resolve(stream());
  }};
  const first=open(media,abort.signal);
  while(!finish)await new Promise(r=>setImmediate(r));
  abort.abort();await assert.rejects(first,{name:'AbortError'});
  await assert.rejects(open(media),{name:'CameraOpenTimeout'});assert.equal(opens,1);
  finish(late);await new Promise(r=>setImmediate(r));
  assert.equal(late.getTracks()[0].stopped,1);
  const fresh=await open(media);assert.equal(opens,2);assert.equal(fresh.getTracks()[0].stopped,0);
});
test('접수창과 공용 촬영창은 종료·장치 변경 자동 복구를 연결하고 저장 ID는 무시한다',()=>{
  const intake=fs.readFileSync(path.join(__dirname,'../src/NativeDraftCamera.tsx'),'utf8');
  assert.match(intake,/addEventListener\('ended',/);
  assert.match(intake,/if\(cameraVisible\.current\)void startRef\.current\(\)/);
  assert.match(intake,/addEventListener\('mute',/);
  assert.match(intake,/openAbort\.current&&!streamRef\.current/);
  assert.match(intake,/disabled=\{connecting\}/);
  const equipment=fs.readFileSync(path.join(__dirname,'../src/EquipmentWorkspace.tsx'),'utf8');
  assert.match(equipment,/addEventListener\('devicechange',reconnect\)/);
  assert.match(equipment,/addEventListener\('ended',/);
  assert.doesNotMatch(equipment,/\[config\?\.mode,\s*config\?\.cameraDeviceId/);
});
