'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const req=require('node:module').createRequire(path.join(__dirname,'../package.json')),ts=req('typescript');
const cameraDevice={};new Function('exports','require',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/camera-device.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(cameraDevice,()=>{throw Error('장치 선택 검사는 외부 모듈을 호출하지 않습니다.');});
const api={};new Function('exports','require',ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/iriun-camera.ts'),'utf8'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(api,name=>name==='./camera-device'?cameraDevice:{inspectCameraStream:async()=>{}});
const device=(id,label)=>({kind:'videoinput',deviceId:id,label});
const phone=device('phone','Iriun Webcam'),usb=device('usb','SU200MB USB Webcam');
test('desktop boot never keeps a hidden prewarmed camera stream alive outside the modal',()=>{
  const boot=fs.readFileSync(path.join(__dirname,'../src/main.tsx'),'utf8');
  assert.doesNotMatch(boot,/\bwarmPreferredCamera\b|\bgetUserMedia\s*\(/);
});
function stream(id='phone',label='Iriun Webcam'){
  const tracks=[{label,getSettings:()=>({deviceId:id}),stopped:0,stop(){this.stopped++;}}];
  return {getTracks:()=>tracks,getVideoTracks:()=>tracks};
}
const open=(media,signal=new AbortController().signal)=>api.openIriunCamera(media,signal,async()=>{});
test('Iriun-only inventory rejects physical USB, OBS and non-Iriun drivers',()=>{
  assert.deepEqual(api.iriunDevices([usb,device('obs','OBS Iriun Virtual'),device('droid','DroidCam'),phone]),[phone]);
});
test('Iriun receives ideal FHD, no hardware or color constraints',async()=>{
  let constraints;const s=stream();
  assert.equal(await open({enumerateDevices:async()=>[usb,phone],getUserMedia:async c=>{constraints=c;return s;}}),s);
  assert.deepEqual(constraints,{audio:false,video:{deviceId:'phone',width:{ideal:1920},height:{ideal:1080}}});
});
test('unsupported FHD retries defaults only on the same Iriun device',async()=>{
  const calls=[];const s=stream();
  await open({enumerateDevices:async()=>[phone],getUserMedia:async c=>{calls.push(c);if(calls.length===1)throw Error('size');return s;}});
  assert.deepEqual(calls[1],{audio:false,video:{deviceId:'phone'}});
});
test('new member PC without phone receiver discovers its actual external camera directly',async()=>{
  const calls=[],s=stream('usb','USB Webcam');
  assert.equal(await open({enumerateDevices:async()=>[usb],getUserMedia:async c=>{calls.push(c);return s;}}),s);
  assert.equal(calls.length,1);assert.equal(calls[0].video.deviceId,'usb');
});
test('only explicit saved USB selection opens that physical camera and never OBS',async()=>{
  const s=stream('usb','SU200MB USB Webcam'),calls=[];
  const media={enumerateDevices:async()=>[phone,usb,device('obs','OBS Virtual Camera')],
    getUserMedia:async c=>{calls.push(c);return s;}};
  assert.equal(await api.openIriunCamera(media,new AbortController().signal,async()=>{},6000,'usb'),s);
  assert.equal(calls[0].video.deviceId,'usb');
  await assert.rejects(api.openIriunCamera(media,new AbortController().signal,async()=>{},6000,'obs'),/설정한 카메라/);
  assert.equal(calls.length,1);
});
test('closing while permission is pending rejects immediately and stops a late stream',async()=>{
  let resolve;const abort=new AbortController(),s=stream();
  const pending=open({enumerateDevices:async()=>[phone],getUserMedia:()=>new Promise(r=>{resolve=r;})},abort.signal);
  await new Promise(r=>setImmediate(r));abort.abort();
  await assert.rejects(pending,{name:'AbortError'});resolve(s);await new Promise(r=>setImmediate(r));
  assert.equal(s.getTracks()[0].stopped,1);
});
test('wrong returned device is released and never shown or stored',async()=>{
  const streams=[];await assert.rejects(open({enumerateDevices:async()=>[phone,usb],getUserMedia:async()=>{
    const s=stream('usb','SU200MB');streams.push(s);return s;}}),/다른 카메라/);
  assert(streams.every(s=>s.getTracks()[0].stopped===1));
});
test('close during first-frame decoding immediately releases the acquired camera',async()=>{
  const s=stream(),abort=new AbortController();
  let decoding=false;
  const pending=api.openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:async()=>s},abort.signal,
    ()=>{decoding=true;return new Promise(()=>{});});
  while(!decoding)await new Promise(r=>setImmediate(r));
  abort.abort();await assert.rejects(pending,{name:'AbortError'});
  assert(s.getTracks()[0].stopped>=1);
});
test('a timed-out permission request does not start overlapping camera opens; late tracks stop',async()=>{
  let resolve,calls=0;const s=stream();
  await assert.rejects(api.openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:()=>{
    calls++;return new Promise(r=>{resolve=r;});}},new AbortController().signal,async()=>{},15),{name:'CameraOpenTimeout'});
  assert.equal(calls,1);resolve(s);await new Promise(r=>setImmediate(r));assert.equal(s.getTracks()[0].stopped,1);
});
test('closing during post-permission enumeration immediately releases the permission probe',async()=>{
  let enumeration=0,finish;const s=stream(),abort=new AbortController();
  const pending=open({enumerateDevices:()=>++enumeration===1?Promise.resolve([device('unlabelled','')]):
    new Promise(r=>{finish=r;}),getUserMedia:async()=>s},abort.signal);
  while(!finish)await new Promise(r=>setImmediate(r));
  abort.abort();assert(s.getTracks()[0].stopped>=1);
  finish([phone]);await assert.rejects(pending,{name:'AbortError'});
});
test('permission-denied is not retried and UI contains no USB/manual controls',async()=>{
  let calls=0;await assert.rejects(open({enumerateDevices:async()=>[phone],getUserMedia:async()=>{
    calls++;throw Object.assign(Error('denied'),{name:'NotAllowedError'});}}),/denied/);assert.equal(calls,1);
  const text=fs.readFileSync(path.join(__dirname,'../src/NativeDraftCamera.tsx'),'utf8');
  assert.doesNotMatch(text,/CameraColorSliders|correctCameraCanvas|select-ndc-device|SmartphoneCameraHelp/);
  for(const value of ['Wi-Fi 무선 연결','USB 유선 연결','사진 촬영 (A / F7)','확대 (B / F8)','다음 세탁물 (C / F9)','접수 최종 확인'])
    assert(text.includes(value),value);
});
