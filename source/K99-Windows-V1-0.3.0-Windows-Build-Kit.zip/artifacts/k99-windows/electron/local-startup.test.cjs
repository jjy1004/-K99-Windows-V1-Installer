'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {startLocalDesktop}=require('./local-startup.cjs');
test('local renderer opens before optional devices; hung devices never gate startup',async()=>{
  const calls=[];
  await startLocalDesktop({
    loadMain:async()=>{calls.push('local');},
    configurePrinter:()=>{calls.push('printer');return new Promise(()=>{});},
    restoreCustomer:()=>{calls.push('customer');return new Promise(()=>{});},
    onPrinterError:()=>assert.fail(),onCustomerError:()=>assert.fail(),
  });
  assert.deepEqual(calls,['local','printer','customer']);
});
test('optional discovery errors are contained and never become startup failures',async()=>{
  const errors=[];
  await startLocalDesktop({
    loadMain:async()=>{},
    configurePrinter:()=>{throw Error('spooler unavailable');},
    restoreCustomer:async()=>{throw Error('monitor unavailable');},
    onPrinterError:e=>{errors.push(e.message);throw Error('logger failed');},
    onCustomerError:e=>{errors.push(e.message);},
  });
  await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(errors,['spooler unavailable','monitor unavailable']);
});
test('local renderer failures remain explicit rather than starting a cloud fallback',async()=>{
  await assert.rejects(startLocalDesktop({
    loadMain:async()=>{throw Error('local bundle missing');},
    configurePrinter:()=>assert.fail(),restoreCustomer:()=>assert.fail(),
  }),/local bundle missing/);
});
test('all shipped Electron runtime files reject synchronous PowerShell execution',()=>{
  const scan=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>{
    const file=path.join(dir,entry.name);
    return entry.isDirectory()?scan(file):file.endsWith('.cjs')&&!file.endsWith('.test.cjs')?[file]:[];
  });
  for(const file of scan(__dirname)){
    const text=fs.readFileSync(file,'utf8');
    assert.doesNotMatch(text,/\b(?:spawnSync|execFileSync|execSync)\s*\(/,file);
  }
});
test('installed local runtime refuses an absent IPC bridge before any HTTP fallback',()=>{
  const text=fs.readFileSync(path.join(__dirname,'../src/desktop-runtime.ts'),'utf8');
  const guard=text.indexOf("window.location.protocol==='k99:'&&!window.k99Desktop");
  const transport=text.indexOf("realOpen.call(xhr, 'POST', '/api/local/storage', false)");
  assert.ok(guard>=0&&transport>guard);
});
