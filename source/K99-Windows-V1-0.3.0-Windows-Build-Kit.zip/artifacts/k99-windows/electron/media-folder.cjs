'use strict';
function createMediaFolderOpener({openPath,execFile=require('node:child_process').execFile,platform=process.platform}){
  return async folder=>{
    const error=await openPath(folder);if(error||platform!=='win32')return error;
    const literal="'"+folder.replace(/'/g,"''")+"'";
    const script=`Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class K99ExplorerFocus { [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h,int c); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr a,int x,int y,int w,int z,uint f); }'; $s=New-Object -ComObject Shell.Application; for($i=0;$i -lt 20;$i++){ $w=@($s.Windows()) | Where-Object {try {$_.Document.Folder.Self.Path -eq ${literal}} catch {$false}} | Select-Object -First 1; if($w){$h=[IntPtr]$w.HWND;[K99ExplorerFocus]::ShowWindowAsync($h,9)|Out-Null;[K99ExplorerFocus]::SetWindowPos($h,[IntPtr](-1),0,0,0,0,3)|Out-Null;[K99ExplorerFocus]::SetForegroundWindow($h)|Out-Null;[K99ExplorerFocus]::SetWindowPos($h,[IntPtr](-2),0,0,0,0,3)|Out-Null;break};Start-Sleep -Milliseconds 75 }`;
    await new Promise(resolve=>{try{execFile('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],
      {windowsHide:true,timeout:3000},()=>resolve());}catch{resolve();}});
    return '';
  };
}
module.exports={createMediaFolderOpener};
