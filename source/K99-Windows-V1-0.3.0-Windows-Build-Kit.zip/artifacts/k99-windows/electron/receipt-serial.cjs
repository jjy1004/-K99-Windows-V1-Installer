'use strict';
// Explicit user-requested receipt printing only. Never used for card approval.
const {spawn}=require('node:child_process');
const path=require('node:path');
const {receiptPreferences,validateReceipt}=require('./receipt-template.cjs');
const iconv=require('iconv-lite');

function serialOptions(input={}){
  const p=receiptPreferences(input);
  if(p.receiptTransport!=='serial'||!p.receiptEscPosVerified)
    throw Error('직접 출력은 ESC/POS·한글 인쇄 모드가 확인된 기기에서만 사용할 수 있습니다. 카드단말기 전용 연동 규격을 먼저 확인해 주세요.');
  if(!/^COM[1-9]\d{0,3}$/.test(p.receiptPort))
    throw Error('현재 연결된 COM 포트를 선택해 주세요.');
  return p;
}
function encodeText(text,encoding='cp949'){
  // Reject control-code injection and unrepresentable characters before opening
  // a port; never silently turn customer names or notices into question marks.
  if(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]/.test(text))
    throw Error('접수증에 인쇄할 수 없는 제어 문자가 있습니다.');
  const normalized=text.replace(/\r\n?|\n/g,'\n').replace(/\t/g,'  ');
  const bytes=iconv.encode(normalized,encoding);
  if(iconv.decode(bytes,encoding)!==normalized)
    throw Error('선택한 한글 인코딩으로 인쇄할 수 없는 문자가 있습니다. 이모지·특수 문자를 빼거나 Windows 드라이버 출력을 사용해 주세요.');
  // iconv-lite aliases EUC-KR to CP949. Enforce KS X 1001 byte ranges so
  // extended CP949 Hangul cannot silently reach an EUC-KR-only printer.
  if(encoding==='euc-kr')for(let i=0;i<bytes.length;i++){
    if(bytes[i]<0x80)continue;
    const lead=bytes[i],trail=bytes[++i];
    if(lead<0xa1||lead>0xfe||trail===undefined||trail<0xa1||trail>0xfe)
      throw Error('EUC-KR에서 지원하지 않는 글자가 있습니다. 기기에서 CP949를 지원하는지 확인하거나 Windows 드라이버 출력을 사용해 주세요.');
  }
  return iconv.encode(normalized.replace(/\n/g,'\r\n'),encoding);
}
function receiptText({receipt,profile={},preferences={},now=new Date(),showManualTags=true}={}){
  const p=receiptPreferences(preferences),r=validateReceipt(receipt??{customerName:'',customerPhone:'',paymentType:'PREPAID',items:[]});
  const date=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',hour12:false}).format(now);
  const columns=Math.floor(((p.receiptWidth===58?384:576)-160)/12);
  const line='-'.repeat(columns),won=n=>n.toLocaleString('ko-KR')+'원';
  const rows=[...(p.receiptPromo?[p.receiptPromo,line]:[]),profile.storeName||'K99세탁매장',
    profile.storePhone||profile.ownerPhone||'','세탁 접수증',`접수일시: ${date}`,
    `고객명: ${r.customerName||'미입력'}`,`연락처: ${r.customerPhone||'미입력'}`];
  if(showManualTags&&r.manualTagNumbers.length)rows.push(`수기 택: ${r.manualTagNumbers.join(', ')}`);
  rows.push(line,'품목명 / 수량 / 금액');
  for(const i of r.items)rows.push(i.name,`  ${i.quantity}벌  ${won(i.amount)}`);
  rows.push(line,`총 수량: ${r.count}벌`);
  if(r.discountAmount){
    rows.push(`할인 전 금액: ${won(r.subtotal)}`);
    if(r.tierDiscountAmount)rows.push(`구간 할인 (${r.discountRate}%): -${won(r.tierDiscountAmount)}`);
    if(r.discountAmount>r.tierDiscountAmount)rows.push(`추가·수동 할인: -${won(r.discountAmount-r.tierDiscountAmount)}`);
  }
  if(r.adjustment)rows.push(`금액 조정: ${won(r.adjustment)}`);
  rows.push(`${r.discountAmount?'최종 할인 합계 금액':'합계 금액'}: ${won(r.total)}`,
    `결제 구분: [ ${r.paymentType==='PREPAID'?'선불':'후불'} ]`,line,
    '세탁 접수 내역입니다.','카드 승인 영수증은 결제 단말기에서 확인해 주세요.','');
  const wrapped=[];
  for(const row of rows)for(const part of String(row).split('\n')){
    let text='',width=0;
    for(const c of part){
      const size=iconv.encode(c,p.receiptEncoding).length;
      if(width+size>columns){wrapped.push(text);text='';width=0;}
      text+=c;width+=size;
    }
    wrapped.push(text);
  }
  return wrapped.join('\n');
}
function escPosReceipt(input){
  const p=serialOptions(input.preferences);
  const text=encodeText(receiptText(input),p.receiptEncoding);
  // ESC J 80 = about 10 mm at the verified ESC/POS 203 dpi feed unit.
  // Set line spacing explicitly; bottom four lines add ~15 mm before cutting.
  // Restore standard 12-dot ASCII/24-dot Hangul before wrapping; reserve
  // 80 dots on EACH side of the printable area (at least 10 mm, 203 dpi).
  const area=(p.receiptWidth===58?384:576)-160;
  const data=Buffer.concat([Buffer.from([0x1b,0x40,0x1c,0x26,0x1b,0x4d,0,0x1c,0x21,0,
    0x1b,0x61,0,0x1d,0x4c,80,0,0x1d,0x57,area&255,area>>8,
    0x1b,0x33,30,0x1b,0x4a,80]),text,Buffer.from([0x1b,0x64,0x04])]);
  if(data.length>256*1024)throw Error('접수증 데이터가 너무 큽니다. 품목을 나눠 인쇄해 주세요.');
  // Cut is sent separately, only AFTER all text has drained from the port.
  return {data,cut:p.receiptCut?Buffer.from([0x1d,0x56,0x00]):Buffer.alloc(0),preferences:p};
}
const chunkDelay=(bytes,baud)=>Math.ceil(bytes*10*1000/baud*1.25)+20; // 8N1 + safety margin
function chunkLengths(data){
  const lengths=[];
  for(let offset=0;offset<data.length;){
    let end=offset;
    while(end<data.length){
      const n=data[end]>=0x81?2:1;
      if(end+n>offset+128)break;
      end+=n;
    }
    lengths.push(end-offset);offset=end;
  }
  return lengths;
}

// Fixed script, data on stdin only. No customer text/port is interpolated into
// PowerShell source or shell arguments. Bounded asynchronous child process.
const SERIAL_SCRIPT=String.raw`
$ErrorActionPreference='Stop'
$port=$null
try {
  $j=[Console]::In.ReadToEnd() | ConvertFrom-Json
  if ($j.port -cnotmatch '^COM[1-9][0-9]{0,3}$' -or @(9600,19200,38400,115200) -notcontains [int]$j.baud) { throw 'invalid serial options' }
  $data=[Convert]::FromBase64String($j.data)
  $cut=[Convert]::FromBase64String($j.cut)
  if ($data.Length -gt 262144 -or $cut.Length -notin @(0,3)) { throw 'invalid payload' }
  $total=0
  if(@($j.lengths).Count -gt 4096) { throw 'invalid chunks' }
  foreach($length in $j.lengths) {
    if([int]$length -lt 1 -or [int]$length -gt 128) { throw 'invalid chunk length' }
    $total+=[int]$length
  }
  if($total -ne $data.Length) { throw 'invalid chunk total' }
  $port=New-Object System.IO.Ports.SerialPort
  $port.PortName=$j.port
  $port.BaudRate=[int]$j.baud
  $port.DataBits=8
  $port.Parity=[System.IO.Ports.Parity]::None
  $port.StopBits=[System.IO.Ports.StopBits]::One
  $port.Handshake=[System.IO.Ports.Handshake]::None
  $port.DtrEnable=$false
  $port.RtsEnable=$false
  $port.WriteTimeout=5000
  $port.Open()
  $offset=0
  foreach($length in $j.lengths) {
    $count=[int]$length
    $port.Write($data,$offset,$count)
    Start-Sleep -Milliseconds ([int][Math]::Ceiling($count*10*1000/[double]$j.baud*1.25)+20)
    $offset+=$count
  }
  $until=[DateTime]::UtcNow.AddSeconds(10)
  while($port.BytesToWrite -gt 0) {
    if([DateTime]::UtcNow -gt $until) { throw 'serial drain timed out' }
    Start-Sleep -Milliseconds 20
  }
  if($cut.Length -gt 0) {
    Start-Sleep -Milliseconds 200
    $port.Write($cut,0,$cut.Length)
    $until=[DateTime]::UtcNow.AddSeconds(5)
    while($port.BytesToWrite -gt 0) {
      if([DateTime]::UtcNow -gt $until) { throw 'cut drain timed out' }
      Start-Sleep -Milliseconds 20
    }
  }
  [Console]::Out.Write('K99_RECEIPT_DRAINED')
} catch {
  [Console]::Error.Write('K99_SERIAL_FAILED')
  exit 1
} finally {
  if($null -ne $port) { if($port.IsOpen) { $port.Close() }; $port.Dispose() }
}
`;
function createSerialReceiptPrinter({spawnProcess=spawn,platform=process.platform,env=process.env}={}){
  const active=new Set();
  return async function print(input){
    const packet=escPosReceipt(input),p=packet.preferences;
    if(platform!=='win32')throw Error('시리얼 직접 출력은 Windows 설치 앱에서 사용할 수 있습니다.');
    if(active.has(p.receiptPort))throw Error('같은 포트의 인쇄가 진행 중입니다. 중복 전송하지 않습니다.');
    const lengths=chunkLengths(packet.data);
    const timeout=Math.max(20000,lengths.length*chunkDelay(128,p.receiptBaudRate)+20000);
    active.add(p.receiptPort);
    try{
      await new Promise((resolve,reject)=>{
        let child,closed=false,output='',failed=false,timedOut=false;
        const fail=()=>{failed=true;};
        const error=()=>Error(timedOut?'출력 응답이 지연되어 중단했습니다. 일부 인쇄됐을 수 있으니 실제 종이를 확인한 후 다시 인쇄해 주세요.':
          '시리얼 출력 완료를 확인하지 못했습니다. 포트·통신 속도·한글 인쇄 모드와 다른 프로그램의 점유를 확인하세요. 일부 인쇄됐을 수 있어 자동 재전송하지 않습니다.');
        let timer;
        const done=(cause)=>{if(closed)return;closed=true;clearTimeout(timer);cause?reject(cause):resolve();};
        try{
          const exe=path.win32.join(env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
          child=spawnProcess(exe,['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',
            Buffer.from(SERIAL_SCRIPT,'utf16le').toString('base64')],{windowsHide:true,stdio:['pipe','pipe','pipe']});
          child.once('error',()=>done(error()));
          child.stdout.on('data',b=>{output+=b.toString();if(output.length>4096){fail();child.kill();}});
          child.stderr.on('data',fail);
          child.stdin.on('error',fail);
          child.once('close',code=>done(!failed&&!timedOut&&code===0&&output==='K99_RECEIPT_DRAINED'?undefined:error()));
          timer=setTimeout(()=>{timedOut=true;child.kill();},timeout);
          child.stdin.end(JSON.stringify({port:p.receiptPort,baud:p.receiptBaudRate,
            data:packet.data.toString('base64'),lengths,cut:packet.cut.toString('base64')}));
        }catch{child?.kill();done(error());}
      });
      return {message:`${p.receiptPort} · ${p.receiptBaudRate} bps로 접수증 데이터를 전송하고 버퍼 비움을 확인했습니다. 실제 종이 출력은 확인해 주세요. 카드 승인·결제 상태는 변경하지 않았습니다.`};
    }finally{active.delete(p.receiptPort);}
  };
}
module.exports={serialOptions,encodeText,receiptText,escPosReceipt,chunkDelay,chunkLengths,SERIAL_SCRIPT,createSerialReceiptPrinter};
