'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const ROOTS=['D:\\K99과천매장\\01_고객세탁사진','D:\\고객 세탁 사진','D:\\고객 세탁 사진\\01_고객세탁사진'];
const clean=s=>String(s||'').normalize('NFC').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/^[ .]+|[ .]+$/g,'').slice(0,80);
function dates(now){
  const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const [y,m,d]=today.split('-').map(Number),base=new Date(Date.UTC(y,m-1-6,1));
  const last=new Date(Date.UTC(base.getUTCFullYear(),base.getUTCMonth()+1,0)).getUTCDate();
  const start=new Date(Date.UTC(base.getUTCFullYear(),base.getUTCMonth(),Math.min(d,last))).toISOString().slice(0,10);
  return {today,start};
}
function createCustomerPhotoLibrary({roots=ROOTS,openPath,now=()=>new Date()}){
  const issued=new Map();
  async function checked(folder,root,allowRoot=false){
    const absolute=path.resolve(folder),base=path.resolve(root);
    if(!(allowRoot&&absolute===base)&&!absolute.startsWith(base+path.sep))throw Error('사진 경로 이탈');
    // Reject junctions/symlinks including intermediate root components.
    let part=path.parse(absolute).root;
    for(const name of absolute.slice(part.length).split(path.sep).filter(Boolean)){
      part=path.join(part,name);
      const info=await fs.lstat(part);
      if(info.isSymbolicLink()||!info.isDirectory())throw Error('사진 연결 폴더/정션은 열 수 없습니다.');
    }
    const real=await fs.realpath(absolute);
    if(real.toLowerCase()!==absolute.toLowerCase())throw Error('사진 실제 경로 불일치');
    return real;
  }
  async function list(customer){
    const name=clean(customer.name),last4=String(customer.phone||'').replace(/\D/g,'').slice(-4);
    if(!name||last4.length!==4)return {folders:[],notes:['고객명과 전화 끝4자리가 모두 있어야 사진을 찾습니다.'],truncated:false};
    const {today,start}=dates(now()),found=[],notes=[];let truncated=false,scanned=0;
    for(const root of roots){
      try{
        await checked(root,root,true);
        const dir=await fs.opendir(root);
        for await(const entry of dir){
          if(++scanned>12000){truncated=true;break;}
          if(!entry.isDirectory()||entry.isSymbolicLink())continue;
          const m=/^(\d{8}|\d{4}-\d{2}-\d{2})_(.+)_(\d{4})$/.exec(entry.name);
          const named=!m&&clean(entry.name)===`${name}_${last4}`;
          if(!named&&(!m||clean(m[2])!==name||m[3]!==last4))continue;
          const date=named?new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'})
            .format((await fs.stat(path.join(root,entry.name))).mtime):
            m[1].length===8?`${m[1].slice(0,4)}-${m[1].slice(4,6)}-${m[1].slice(6)}`:m[1];
          const parsed=new Date(date+'T00:00:00Z');
          if(!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==date||date<start||date>today)continue;
          const folder=await checked(path.join(root,entry.name),root);
          found.push({folder,root,date,name:entry.name});
        }
      }catch(error){notes.push(`${root}: ${error.code==='ENOENT'||error.code==='ENOTDIR'?'폴더 없음':error.code==='EACCES'?'접근 권한 없음':error.message}`);}
      if(truncated)break;
    }
    const current=Date.now();
    for(const [token,v] of issued)if(current-v.at>600000)issued.delete(token);
    const unique=[...new Map(found.map(v=>[v.folder,v])).values()].sort((a,b)=>b.date.localeCompare(a.date));
    if(unique.length>24)truncated=true;
    const folders=unique.slice(0,24).map(v=>{
      const token=crypto.randomUUID();issued.set(token,{...v,at:current});
      return {token,date:v.date,name:v.name};
    });
    while(issued.size>256)issued.delete(issued.keys().next().value);
    return {folders,notes,truncated};
  }
  async function open(token){
    const entry=issued.get(token);
    if(!entry||Date.now()-entry.at>600000)throw Error('사진 폴더 목록이 만료되었습니다. 다시 조회하세요.');
    const folder=await checked(entry.folder,entry.root),error=await openPath(folder);
    if(error)throw Error(`사진 폴더 열기 실패: ${error}`);
    return {opened:true};
  }
  return {list,open};
}
module.exports={createCustomerPhotoLibrary,ROOTS,dates};
