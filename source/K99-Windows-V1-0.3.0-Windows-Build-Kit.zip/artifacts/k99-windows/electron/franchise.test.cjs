'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),crypto=require('node:crypto');
const {prepareStorageLayout,changeStorageRoot,validRoot,layoutStatus,assertStorageChangeAllowed}=require('./storage-layout.cjs');
const {findCalculator,createProgramLauncher}=require('./program-integrations.cjs');
const {createIdleVideos}=require('./idle-videos.cjs');
function disk(existing){
  const dirs=new Set(existing),files=new Map();let link='';
  const io={existsSync:p=>dirs.has(p)||files.has(p),readFileSync:p=>files.get(p),
    lstatSync:p=>({isSymbolicLink:()=>p===link}),mkdirSync:p=>dirs.add(p),accessSync:p=>{if(!dirs.has(p))throw Error('missing');},
    openSync:p=>p,writeFileSync:(p,v)=>files.set(p,v),fsyncSync(){},closeSync(){},renameSync:(a,b)=>{files.set(b,files.get(a));files.delete(a);}};
  return {io,dirs,files,setLink:p=>{link=p;}};
}
test('external data disks precede C; existing folders precede empty D; legacy root stays pinned',()=>{
  for(const [existing,want]of [
    [['C:\\','E:\\'],'E:\\K99_스마트접수'],
    [['C:\\','D:\\','F:\\','F:\\K99과천매장'],'F:\\K99과천매장'],
    [['C:\\','D:\\','D:\\K99스마트접수'],'D:\\K99스마트접수'],
    [['C:\\','D:\\','E:\\','D:\\K99과천매장','E:\\K99과천매장'],'D:\\K99과천매장']]){
    const d=disk(existing);assert.equal(prepareStorageLayout('/u',{io:d.io}).root,want);
  }
});
test('optical/network/unready drives are excluded and old configuration is never silently replaced',()=>{
  const d=disk(['C:\\','D:\\','E:\\']);
  const l=prepareStorageLayout('/u',{io:d.io,drives:[{root:'D:\\',type:5},{root:'E:\\',type:4},{root:'C:\\',type:3}]});
  assert.equal(l.root,'C:\\K99_스마트접수');
  d.dirs.delete('C:\\');const before=d.files.get('/u/storage-layout.json');
  assert.throws(()=>prepareStorageLayout('/u',{io:d.io}),/드라이브/);assert.equal(d.files.get('/u/storage-layout.json'),before);
});
test('removable and fixed USB disks precede internal D; internal D precedes other fixed data disks',()=>{
  for(const [drives,want]of [
    [[{root:'C:\\',type:3},{root:'D:\\',type:3},{root:'E:\\',type:3,external:true}],'E:\\K99_스마트접수'],
    [[{root:'C:\\',type:3},{root:'D:\\',type:3,external:true},{root:'E:\\',type:3}],'D:\\K99_스마트접수'],
    [[{root:'C:\\',type:3},{root:'D:\\',type:3},{root:'E:\\',type:2}],'E:\\K99_스마트접수'],
    [[{root:'C:\\',type:3},{root:'D:\\',type:3},{root:'E:\\',type:3}],'D:\\K99_스마트접수'],
  ]){
    const d=disk(['C:\\','D:\\','E:\\']);
    assert.equal(prepareStorageLayout('/u',{io:d.io,drives}).root,want);
  }
});
test('changing root preserves old locations, refuses unavailable drives, and reports five ready folders',()=>{
  const d=disk(['C:\\','D:\\','E:\\']);
  const first=prepareStorageLayout('/u',{io:d.io});
  const next=changeStorageRoot('/u','E:\\',{io:d.io});
  assert.equal(next.root,'E:\\K99_스마트접수');assert.deepEqual(next.previousRoots,[first.root]);
  assert.ok(d.dirs.has(first.intake));assert.equal(layoutStatus(next,d.io).folders.filter(f=>f.ready).length,5);
  assert.equal(prepareStorageLayout('/u',{io:d.io}).root,next.root);
  const text=d.files.get('/u/storage-layout.json');
  assert.throws(()=>changeStorageRoot('/u','Z:\\',{io:d.io}),/드라이브/);assert.equal(d.files.get('/u/storage-layout.json'),text);
  assert.equal(changeStorageRoot('/u','E:\\',{io:d.io}).changed,false);
});
test('unsafe roots and ancestor junctions fail without replacing a saved configuration',()=>{
  for(const root of ['\\\\server\\share','D:\\..\\data','C:\\Windows\\system32','D:\\photo:ads','D:\\x\\a?b'])assert.throws(()=>validRoot(root));
  const d=disk(['C:\\','E:\\','E:\\linked']);prepareStorageLayout('/u',{io:d.io});
  const before=d.files.get('/u/storage-layout.json');d.setLink('E:\\linked');
  assert.throws(()=>changeStorageRoot('/u','E:\\linked\\data',{io:d.io}),/링크/);assert.equal(d.files.get('/u/storage-layout.json'),before);
});
test('drive changes refuse active writes and all meaningful unsaved intake data',()=>{
  assert.doesNotThrow(()=>assertStorageChangeAllowed({changing:false,writes:0,draft:{data:{rows:[]}}}));
  for(const input of [{changing:true},{writes:1},...['customerName','customerPhone','customerAddress','rows'].map(key=>({draft:{data:{[key]:key==='rows'?[{}]:'입력 중'}}}))])
    assert.throws(()=>assertStorageChangeAllowed(input));
});
function temp(t){const folder=fs.mkdtempSync(path.join(os.tmpdir(),'k99-franchise-'));t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));return folder;}
test('calculator scan prefers deterministic K99 exe, excludes installers/self/junctions, never executes on scan',t=>{
  const dir=temp(t);
  for(const name of ['z.exe','K99-Laundry-Luxury.exe','K99-Laundry-V2.exe','K99-Laundry-Setup.exe','uninstall.exe'])
    fs.writeFileSync(path.join(dir,name),'fixture');
  fs.symlinkSync(path.join(dir,'z.exe'),path.join(dir,'K99-Laundry-A.exe'));
  assert.equal(path.basename(findCalculator(dir)),'K99-Laundry-Luxury.exe');
  assert.equal(findCalculator(path.join(dir,'missing')),null);
});
test('missing calculator opens default web app without folder configuration',async t=>{
  const dir=temp(t);let opened='',loaded='',configured='';
  const {EventEmitter}=require('node:events');
  class Window extends EventEmitter{
    constructor(){super();this.webContents={session:{setPermissionRequestHandler(){}},setWindowOpenHandler(){},on(){}};}
    async loadURL(url){loaded=url;} show(){} focus(){}
  }
  const launcher=createProgramLauncher({platform:'win32',programFolder:dir,openFolder:async f=>{opened=f;return '';},
    BrowserWindow:Window,owner:()=>null,readSettings:()=>({luxuryTarget:configured,prescriptionUrl:''})});
  assert.equal(opened,'');const r=await launcher.open('luxury',{});
  assert.equal(opened,'');assert.equal(new URL(loaded).origin,'https://k-99-luxury-laundry-pricing.replit.app');
  assert.equal(r.opened,true);
  configured='Z:\\missing-calculator.exe';await launcher.open('luxury',{});
  assert.equal(new URL(loaded).origin,'https://k-99-luxury-laundry-pricing.replit.app');
  launcher.close();
});
test('automatic exe precedes configured web URL and is spawned only by user launch without shell',async t=>{
  const dir=temp(t),exe=path.join(dir,'K99-Laundry-Luxury.exe'),{EventEmitter}=require('node:events');fs.writeFileSync(exe,'fixture');
  let invocation;
  const launcher=createProgramLauncher({platform:'win32',programFolder:dir,resultFolder:path.join(dir,'results'),onResult:()=>{},
    readSettings:()=>({luxuryTarget:'https://calculator.example.test',prescriptionUrl:''}),
    spawn:(file,args,options)=>{invocation={file,args,options};const child=new EventEmitter();setImmediate(()=>child.emit('spawn'));return child;}});
  t.after(()=>launcher.close());assert.equal(invocation,undefined);
  await launcher.open('luxury',{});assert.equal(invocation.file,exe);assert.equal(invocation.options.shell,false);
  assert.equal(invocation.args[0],'--k99-result-file');
});
test('without local exe the registered HTTPS calculator opens in isolated result-capable window',async t=>{
  const dir=temp(t),{EventEmitter}=require('node:events');let loaded;
  class Window extends EventEmitter{
    constructor(options){super();this.options=options;this.webContents={session:{setPermissionRequestHandler(){}},setWindowOpenHandler(){},on(){}};}
    async loadURL(url){loaded=url;} show(){} focus(){}
  }
  const launcher=createProgramLauncher({platform:'win32',programFolder:dir,BrowserWindow:Window,owner:()=>null,
    readSettings:()=>({luxuryTarget:'https://calculator.example.test/calc',prescriptionUrl:''})});
  await launcher.open('luxury',{});assert.equal(new URL(loaded).origin,'https://calculator.example.test');
  assert.equal(new URL(loaded).searchParams.get('k99_return'),'postMessage');launcher.close();
});
test('mixed media preserves filenames, validates images and serves correct MIME without filesystem paths',async t=>{
  const dir=temp(t);
  fs.writeFileSync(path.join(dir,'01.png'),Buffer.from('89504e470d0a1a0a00000000','hex'));
  fs.writeFileSync(path.join(dir,'02.mp4'),'fixture');fs.writeFileSync(path.join(dir,'03.jpg'),'<html>bad</html>');
  const api=createIdleVideos({folder:dir,openPath:async()=>''}),files=api.list().files;
  assert.deepEqual(files.map(f=>f.name),['01.png','02.mp4']);assert.equal(files[0].kind,'image');assert.equal(files[0].durationMs,10000);
  const r=await api.response(new Request(files[0].url));assert.equal(r.headers.get('content-type'),'image/png');assert.equal(r.headers.get('x-content-type-options'),'nosniff');
  assert.equal(crypto.createHash('sha256').update(Buffer.from(await r.arrayBuffer())).digest('hex'),
    crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,'01.png'))).digest('hex'));
});
function tsModule(name,globals={}){
  const ts=require('typescript'),filename=path.join(__dirname,'../src',name+'.ts'),module={exports:{}};
  const code=ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  vm.runInNewContext(code,{module,exports:module.exports,console,...globals});return module.exports;
}
test('scanner buffering yields delegated camera pedals but still protects ordinary input by default',()=>{
  const {installKeyboardTagReader}=tsModule('keyboard-tag-reader',{
    require:id=>{assert.equal(id,'./barcode-keys');return {barcodeCharFromKey:()=>''};},
    setTimeout,clearTimeout,Element:class{},HTMLInputElement:class{},HTMLTextAreaElement:class{},
  });
  for(const delegated of [false,true]){
    const listeners=new Map(),host={addEventListener:(name,fn)=>listeners.set(name,fn),removeEventListener:name=>listeners.delete(name)};
    const stop=installKeyboardTagReader(()=>assert.fail('a pedal is not an issued tag'),host,()=>false,()=>{},
      delegated?e=>e.key==='b':undefined);
    let prevented=false;
    listeners.get('keydown')({key:'b',target:null,preventDefault:()=>{prevented=true;},stopImmediatePropagation:()=>{}});
    assert.equal(prevented,!delegated);
    stop();
  }
});
test('letter pedals share F7/F8/F9; IME, editable fields and modifiers retain typing',()=>{
  const {captureShortcut}=tsModule('capture-shortcut');
  const event=(key,extra={})=>({key,code:'',target:null,isComposing:false,ctrlKey:false,altKey:false,metaKey:false,...extra});
  for(const [letter,key]of [['a','F7'],['A','F7'],['b','F8'],['B','F8'],['c','F9'],['C','F9']]){
    assert.equal(captureShortcut(event(letter)),key);assert.equal(captureShortcut(event(letter,{target:{closest:()=>({})}})),null);
    assert.equal(captureShortcut(event(letter,{isComposing:true})),null);
  }
  assert.equal(captureShortcut(event('ㅁ',{code:'KeyA'})),'F7');
  assert.equal(captureShortcut(event('a',{ctrlKey:true})),null);assert.equal(captureShortcut(event('F7',{target:{closest:()=>({})}})),'F7');
});
test('message and store-settings dialogs block capture-phase pedals, then restore them on close',()=>{
  let modal=true;
  const {captureShortcut}=tsModule('capture-shortcut',{document:{querySelector:s=>{
    assert.equal(s,'[data-notice-modal="true"]');return modal?{}:null;
  }}});
  const event=key=>({key,code:'',target:null,isComposing:false,ctrlKey:false,altKey:false,metaKey:false});
  for(const key of ['F7','F8','F9','a','B','c'])assert.equal(captureShortcut(event(key)),null);
  modal=false;
  assert.equal(captureShortcut(event('F7')),'F7');assert.equal(captureShortcut(event('b')),'F8');
});
test('external physical cameras precede integrated devices; virtual-only and internal-only lists have no auto selection',()=>{
  const {automaticCamera}=tsModule('camera-device');
  const d=label=>({kind:'videoinput',label,deviceId:label});
  assert.equal(automaticCamera([d('Integrated Camera'),d('OBS Virtual Camera'),d('USB2.0 UVC Webcam')]).label,'USB2.0 UVC Webcam');
  assert.equal(automaticCamera([d('USB Webcam'),d('SU200-MB')]).label,'SU200-MB');
  assert.equal(automaticCamera([d('Integrated Camera'),d('OBS Virtual Camera')]),undefined);
});
test('centered cover fills both square photo frames and maps marks identically at preview and export scale',()=>{
  const {coverRect,toNormalized,toAreaRect}=tsModule('ba-geometry');
  for(const [w,h]of [[1920,1080],[1080,1920],[900,900]]){
    const small=coverRect(w,h,{x:0,y:0,w:400,h:400}),large=coverRect(w,h,{x:40,y:300,w:740,h:740});
    assert.ok(small.w>=400&&small.h>=400&&small.x<=0&&small.y<=0);
    const p=toNormalized({x:170,y:210},small),m={x:p.x,y:p.y,w:.1,h:.1},a=toAreaRect(m,small),b=toAreaRect(m,large);
    assert.ok(Math.abs((b.x-40)/740-a.x/400)<1e-9);assert.ok(Math.abs((b.y-300)/740-a.y/400)<1e-9);
  }
});
