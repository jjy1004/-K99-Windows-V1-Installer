'use strict';
const bwipjs=require('bwip-js');
const {createCustomerDisplay}=require('./customer-display.cjs');
const {tagHTML,validateRenderedTag}=require('./tag-template.cjs');

function createNativeAdapters({BrowserWindow,screen,session,store,getMain,preload,changed,preferencesFile,onComparisonClosed}) {
  const customerDisplay=createCustomerDisplay({BrowserWindow,screen,getMain,preload,changed,preferencesFile,onComparisonClosed});
  const printers=async()=>((await getMain()?.webContents.getPrintersAsync())||[])
    .map(p=>({name:p.name,displayName:p.displayName||p.name}));
  async function print(job) {
    if(process.platform!=='win32')throw new Error('실제 출력은 Windows에서만 지원합니다.');
    if(!(await printers()).some(p=>p.name===job.printerName))throw new Error('선택한 프린터가 설치 목록에 없습니다.');
    const p=job.payload,w=30,h=p.labelHeightMm;
    // Encoded barcode identity stays unchanged; suppress its long human-readable UUID.
    const barcode=await bwipjs.toBuffer({bcid:'code128',text:p.garmentId,scale:3,height:9,includetext:false});
    const html=tagHTML(job,barcode);
    const partition='k99-label-print';
    const s=session.fromPartition(partition);
    s.webRequest.onBeforeRequest((d,cb)=>cb({cancel:!d.url.startsWith('data:')}));
    s.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));
    const win=new BrowserWindow({show:false,webPreferences:{partition,sandbox:true,contextIsolation:true,nodeIntegration:false}});
    let attempted=false;
    try {
      await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
      const layout=await win.webContents.executeJavaScript(`(${validateRenderedTag.toString()})()`);
      if(layout?.verified!==true||layout.rows!==6)throw new Error('태그 소재·색상 인쇄 영역 검증 실패');
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{
          const e=new Error('인쇄 응답 시간 초과. 실물 확인 후 재출력하세요.');e.submissionUncertain=true;reject(e);
        },30000);
        attempted=true;
        win.webContents.print({silent:true,deviceName:job.printerName,printBackground:true,
          color:false,copies:1,margins:{marginType:'none'},
          pageSize:{width:Math.round(w*1000),height:Math.round(h*1000)}},(ok,reason)=>{
          clearTimeout(timer);
          if(ok)resolve();else{const e=new Error(reason||'Windows 인쇄 결과 미확인');e.submissionUncertain=true;reject(e);}
        });
      });
    } catch(e){if(attempted)e.submissionUncertain=true;throw e;}
    finally{if(!win.isDestroyed())win.destroy();}
  }
  return {native:process.platform==='win32',...customerDisplay,printers,print};
}
module.exports={createNativeAdapters};
