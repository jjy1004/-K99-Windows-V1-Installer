'use strict';
const bwipjs=require('bwip-js');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function createNativeAdapters({BrowserWindow,screen,session,store,getMain,preload,changed}) {
  let customer=null,displayId=null,note='고객 창 닫힘';
  const monitors=()=>screen.getAllDisplays().map(d=>({id:String(d.id),
    label:d.label||`모니터 ${d.id}`,primary:d.id===screen.getPrimaryDisplay().id}));
  const displayStatus=()=>({connected:!!customer&&!customer.isDestroyed(),displayId:displayId||undefined,note});
  const secureWindow=win=>{
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,url)=>{if(url!=='k99://app/equipment/customer')event.preventDefault();});
  };
  async function openCustomer(id) {
    const display=screen.getAllDisplays().find(d=>String(d.id)===String(id));
    if(!display)throw new Error('현재 연결된 모니터를 명시적으로 선택하세요.');
    if(customer&&!customer.isDestroyed()){customer.close();customer=null;}
    displayId=String(display.id);
    const {x,y,width,height}=display.workArea;
    const win=new BrowserWindow({x,y,width,height,title:'K99 고객 안내',autoHideMenuBar:true,
      backgroundColor:'#eeeae3',webPreferences:{preload,sandbox:true,contextIsolation:true,
        nodeIntegration:false,webSecurity:true,webviewTag:false}});
    customer=win;note='선택한 모니터에 고객 창 열림';
    secureWindow(win);
    win.on('closed',()=>{if(customer===win){customer=null;note='고객 창 닫힘';changed();}});
    await win.loadURL('k99://app/equipment/customer');
    win.show();changed();
  }
  const closeCustomer=()=>{customer?.close();customer=null;note='고객 창 닫힘';};
  screen.on('display-removed',(_event,display)=>{
    if(String(display.id)===displayId){closeCustomer();displayId=null;note='고객 모니터 연결 해제 · 재선택 필요';changed();}
  });
  screen.on('display-metrics-changed',(_event,display)=>{
    if(String(display.id)===displayId&&customer&&!customer.isDestroyed())customer.setBounds(display.workArea);
  });
  const printers=async()=>((await getMain()?.webContents.getPrintersAsync())||[])
    .map(p=>({name:p.name,displayName:p.displayName||p.name}));
  async function print(job) {
    if(process.platform!=='win32')throw new Error('실제 출력은 Windows에서만 지원합니다.');
    if(!(await printers()).some(p=>p.name===job.printerName))throw new Error('선택한 프린터가 설치 목록에 없습니다.');
    const p=job.payload,w=p.labelWidthMm,h=p.labelHeightMm;
    const barcode=await bwipjs.toBuffer({bcid:'code128',text:p.garmentId,scale:3,height:9,includetext:true,textsize:8});
    const html=`<!doctype html><html lang="ko"><head><meta charset="utf-8">
      <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
      <style>@page{size:${w}mm ${h}mm;margin:0}*{box-sizing:border-box}body{margin:0;padding:2mm;font:10pt 'Malgun Gothic',sans-serif;width:${w}mm;height:${h}mm;overflow:hidden}
      h1{font-size:12pt;margin:0 0 1mm}p{margin:0 0 1mm}img{width:100%;height:${Math.max(6,h-23)}mm;object-fit:contain}</style>
      </head><body><h1>${escape(p.customerName)}</h1><p>${escape(p.itemName)} · ${escape(p.serviceType.includes('premium')?'프리미엄':'일반')}</p>
      <img src="data:image/png;base64,${barcode.toString('base64')}" alt="${escape(p.garmentId)}">
      <p style="font-size:7pt">${escape(p.garmentId)}</p></body></html>`;
    const partition='k99-label-print';
    const s=session.fromPartition(partition);
    s.webRequest.onBeforeRequest((d,cb)=>cb({cancel:!d.url.startsWith('data:')}));
    s.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));
    const win=new BrowserWindow({show:false,webPreferences:{partition,sandbox:true,contextIsolation:true,nodeIntegration:false}});
    let attempted=false;
    try {
      await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{
          const e=new Error('인쇄 응답 시간 초과. 실물 확인 후 재출력하세요.');e.submissionUncertain=true;reject(e);
        },30000);
        attempted=true;
        win.webContents.print({silent:true,deviceName:job.printerName,printBackground:true,
          color:false,copies:1,margins:{marginType:'none'},
          pageSize:{width:Math.round(w*1000),height:Math.round(h*1000)}},(ok,reason)=>{
          clearTimeout(timer);
          if(ok)resolve();else{const e=new Error(reason||'Windows 인쇄 결과 미확인');e.submissionUncertain=true;reject(e);}
        });
      });
    } catch(e){if(attempted)e.submissionUncertain=true;throw e;}
    finally{if(!win.isDestroyed())win.destroy();}
  }
  return {native:process.platform==='win32',monitors,printers,openCustomer,closeCustomer,displayStatus,print,
    isCustomer:webContents=>!!customer&&!customer.isDestroyed()&&customer.webContents===webContents,
    notify:()=>{if(customer&&!customer.isDestroyed())customer.webContents.send('k99:changed');}};
}
module.exports={createNativeAdapters};
