'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createHardwareSettings,KEY}=require('./hardware-settings.cjs');
const {createTerminalProbe,PROBE_SCRIPT}=require('./services/terminal-connection.cjs');
function fixture(t){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-terminal-check-'));
  const store=createStore(path.join(dir,'test.sqlite'),'test',{nativeDesktop:true});
  const state={ports:[],printers:[],probes:[],available:true,probe:null};
  const adapters={ports:async()=>state.ports,printers:async()=>state.printers,terminalProbe:async p=>{
    state.probes.push(p);return state.probe?state.probe():state.available;}};
  const api=createHardwareSettings({store,adapters,native:true,printGeneral:async()=>({message:'일반 출력 모사'})});
  t.after(()=>{store.close();fs.rmSync(dir,{recursive:true,force:true});});
  return {store,state,api};
}
for(const vendor of ['easycheck','kis','nice'])test(`${vendor}: 요청 때마다 재탐지하되 저장한 COM·속도·폭·문구와 결제는 보존한다`,async t=>{
  const f=fixture(t);
  await f.api({action:'save-receipt',config:{receiptVendor:vendor,receiptType:'easycheck',receiptTransport:'serial',
    receiptPort:'COM9',receiptBaudRate:38400,receiptEncoding:'cp949',receiptWidth:58,receiptEscPosVerified:true,receiptPromo:'수동 원문'}});
  const before=f.store.storage({op:'get',key:KEY});
  f.state.ports=[{name:'COM9'},{name:'COM3',manufacturer:'KICC'}];
  let r=await f.api({action:'terminal-check'});
  assert.equal(r.terminal.transportReady,true);assert.equal(r.terminal.connected,false);
  assert.deepEqual(f.state.probes,[{port:'COM9',baud:38400}]);
  f.state.ports=[{name:'COM3',manufacturer:'KICC'}];
  r=await f.api({action:'terminal-check'});
  assert.equal(r.terminal.state,'missing');assert.equal(f.state.probes.length,1);
  assert.equal(f.store.storage({op:'get',key:KEY}),before);
  assert.equal(f.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),null);
});
test('규격 미확인·미사용은 포트를 열지 않으며 일반 COM에서 회사를 추측하지 않는다',async t=>{
  const f=fixture(t);f.state.ports=[{name:'COM7'}];
  let r=await f.api({action:'terminal-check'});
  assert.equal(r.config.receiptVendor,'');assert.equal(f.store.storage({op:'get',key:KEY}),null);
  await f.api({action:'save-receipt',config:{receiptType:'easycheck',receiptTransport:'serial',receiptPort:'COM7',receiptEscPosVerified:false}});
  r=await f.api({action:'terminal-check'});assert.equal(r.terminal.state,'unverified');
  await f.api({action:'save-receipt',config:{receiptType:'none'}});
  r=await f.api({action:'terminal-check'});assert.equal(r.terminal.state,'disabled');
  assert.equal(f.state.probes.length,0);
});
test('재확인 중복 요청을 합치며 인쇄와 포트 경합을 막고 수동 저장 변경은 즉시 우선한다',async t=>{
  const f=fixture(t);f.state.ports=[{name:'COM4'}];let release,entered;
  const started=new Promise(r=>entered=r);
  f.state.probe=()=>new Promise(r=>{release=r;entered();});
  await f.api({action:'save-receipt',config:{receiptType:'easycheck',receiptTransport:'serial',receiptPort:'COM4',receiptEscPosVerified:true}});
  const a=f.api({action:'terminal-check'}),b=f.api({action:'terminal-check'});await started;
  await assert.rejects(f.api({action:'receipt-print'}),/장치 확인/);
  await f.api({action:'save-receipt',config:{receiptPort:'COM8',receiptBaudRate:115200}});
  release(true);
  const [x,y]=await Promise.all([a,b]);assert.equal(f.state.probes.length,1);
  assert.equal(x.terminal.state,'changed');assert.equal(y.config.receiptPort,'COM8');assert.equal(x.terminal.transportReady,false);
});
test('Windows 드라이버 연결과 일반 출력 경로도 실제 승인으로 표시하지 않는다',async t=>{
  const f=fixture(t);f.state.printers=[{name:'KICC TS-167'}];
  const r=await f.api({action:'terminal-check'});
  assert.equal(r.config.receiptPrinterName,'KICC TS-167');assert.equal(r.terminal.transportReady,true);
  assert.equal(r.terminal.connected,false);assert.equal(f.state.probes.length,0);
  assert.equal((await f.api({action:'general-print'})).message,'일반 출력 모사');
});
test('고정 포트 확인 스크립트는 송신·승인 없이 닫고, 오류·응답 지연은 실패 처리한다',async()=>{
  assert.match(PROBE_SCRIPT,/\$port\.Open\(\)/);assert.match(PROBE_SCRIPT,/finally/);
  assert.doesNotMatch(PROBE_SCRIPT,/\$port\.Write|ReadLine|DtrEnable=\$true|RtsEnable=\$true/);
  for(const mode of ['ok','error','timeout']){
    let stdin='',killed=false;
    const probe=createTerminalProbe({platform:'win32',timeoutMs:20,spawnProcess:(exe,args,opts)=>{
      assert.equal(opts.windowsHide,true);assert(!args.join(' ').includes('COM3'));
      const child=new EventEmitter();child.stdout=new PassThrough();child.stderr=new PassThrough();
      child.stdin=new PassThrough();child.stdin.on('data',b=>stdin+=b);
      child.kill=()=>{killed=true;queueMicrotask(()=>child.emit('close',1));};
      child.stdin.on('finish',()=>{if(mode==='timeout')return;queueMicrotask(()=>{
        child.stdout.write(mode==='ok'?'K99_PORT_AVAILABLE':'');child.emit('close',mode==='ok'?0:1);});});
      return child;
    }});
    assert.equal(await probe({port:'COM3',baud:9600}),mode==='ok');
    assert.deepEqual(JSON.parse(stdin),{port:'COM3',baud:9600});assert.equal(killed,mode==='timeout');
  }
});
