'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createKdeSms}=require('./services/kde-sms.cjs');
const {createKdePhotoSelection}=require('./services/kde-photo-share.cjs');
const {createAutoMessenger}=require('./services/autoMessenger.js');
function transport(list='phone_a',send={code:0,out:''}){
  const calls=[];
  const run=async(command,args)=>{calls.push({command,args});return args.includes('--list-available')?{code:0,out:list}:send;};
  return {calls,client:createKdeSms({run,exists:()=>true,environment:{ProgramFiles:'C:\\Program Files'}})};
}
test('KDE는 전체 원문·번호를 셸 없는 인수 배열로 정확히 한 번 요청한다',async()=>{
  const t=transport(),body='고객 원문 "금액" & $() ;\n마지막 줄';
  const result=await t.client('01000000001',body);
  assert.equal(result.status,'send_requested');
  assert.deepEqual(t.calls[1].args,['-d','phone_a','--destination','01000000001','--send-sms',body]);
  assert.equal(t.calls.length,2);
});
test('저장된 방식과 화면의 경고 기준이 다르면 실제 발송 전에 차단한다',async()=>{
  let effects=0;
  const client=createAutoMessenger({platform:'win32',getSmsMode:()=> 'KDE',
    shell:{openExternal:async()=>effects++},clipboard:{writeText:()=>effects++},spawnProcess:()=>{effects++;throw Error('실행 금지');}});
  await assert.rejects(()=>client.command({action:'sms-compose',recipient:'01000000001',body:'원문',expectedSmsMode:'MS'}),/변경/);
  await assert.rejects(()=>client.command({action:'sms-compose',recipient:'01000000001',body:'원문'}),/변경/);
  assert.equal(effects,0);
  const ms=createAutoMessenger({platform:'win32',getSmsMode:()=> 'MS',shell:{},clipboard:{},selectPhotos:async()=>{effects++;return [];}});
  await assert.rejects(()=>ms.command({action:'kde-share',source:'file',expectedSmsMode:'KDE'}),/KDE를 선택/);
  assert.equal(effects,0);
});
test('KDE 기기 없음·다중 기기·발송 결과 미확인에는 자동 재시도·다른 기기 발송이 없다',async()=>{
  for(const list of ['','phone_a\nphone_b']){
    const t=transport(list),result=await t.client('01000000001','원문');
    assert.equal(result.success,false);assert.equal(t.calls.length,1);assert.match(result.error,/기기/);
  }
  const t=transport('phone_a',{timeout:true}),result=await t.client('01000000001','원문');
  assert.equal(result.success,false);assert.match(result.error,/자동 재시도하지/);assert.equal(t.calls.length,2);
});
test('KDE 사진은 선택한 파일별 share 요청만 하고 SMS 명령과 섞지 않는다',async()=>{
  const t=transport(),files=[path.resolve('가상사진 1.jpg'),path.resolve('가상사진 2.png')];
  const result=await t.client.share(files);
  assert.equal(result.success,true);
  assert.deepEqual(t.calls.slice(1).map(c=>c.args),files.map(file=>['-d','phone_a','--share',file]));
  assert(!t.calls.some(c=>c.args.includes('--send-sms')));
});
test('사진 공유는 실제 이미지 복사본만 사용하고 원본·취소·정션 보호를 유지한다',async()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-kde-test-'));
  try{
    const cache=path.join(root,'cache'),original=path.join(root,'원본.jpg');
    const bytes=Buffer.from([255,216,255,...Array(40).fill(12)]);fs.writeFileSync(original,bytes);
    const select=createKdePhotoSelection({cacheRoot:cache,pick:async()=>({canceled:false,filePaths:[original]}),getOrderPhotos:()=>[bytes]});
    const files=await select({source:'file'});
    assert.equal(files.length,1);assert.notEqual(files[0],original);
    assert.deepEqual(fs.readFileSync(files[0]),bytes);assert.deepEqual(fs.readFileSync(original),bytes);
    const cancel=createKdePhotoSelection({cacheRoot:cache,pick:async()=>({canceled:true,filePaths:[]}),getOrderPhotos:()=>[]});
    assert.deepEqual(await cancel({source:'file'}),[]);
    const bad=path.join(root,'fake.jpg');fs.writeFileSync(bad,'SQLite format 3\0not-a-picture');
    const invalid=createKdePhotoSelection({cacheRoot:cache,pick:async()=>({filePaths:[bad]}),getOrderPhotos:()=>[]});
    await assert.rejects(()=>invalid({source:'file'}),/실제 사진/);
    const foreign=createKdePhotoSelection({cacheRoot:cache,pick:async()=>({filePaths:[original]}),getOrderPhotos:()=>[bytes]});
    await assert.rejects(()=>foreign({source:'order',orderId:'order-test'}),/해당 접수/);
    const order=createKdePhotoSelection({cacheRoot:cache,pick:async options=>({filePaths:[path.join(options.defaultPath,fs.readdirSync(options.defaultPath)[0])]}),getOrderPhotos:()=>[bytes]});
    const chosen=await order({source:'order',orderId:'order-test'});
    assert.deepEqual(fs.readFileSync(chosen[0]),bytes);
  }finally{fs.rmSync(root,{recursive:true,force:true});}
});
