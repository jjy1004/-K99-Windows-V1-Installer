'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createSmartphoneCamera,LINKS}=require('./smartphone-camera.cjs');
test('installed Iriun starts only the fixed executable, never a shell or remote installer',async()=>{
  const opened=[],started=[],expected='C:\\Program Files\\Iriun Webcam\\IriunWebcam.exe';
  const run=createSmartphoneCamera({shell:{openExternal:async u=>opened.push(u)},platform:'win32',
    env:{ProgramFiles:'C:\\Program Files'},stat:async f=>({isFile:()=>f===expected}),launch:async f=>started.push(f)});
  assert.match((await run('iriun')).message,/실행했습니다/);assert.deepEqual(started,[expected]);assert.deepEqual(opened,[]);
});
test('missing client and driver requests open only approved official pages',async()=>{
  const opened=[];const run=createSmartphoneCamera({shell:{openExternal:async u=>opened.push(u)},platform:'win32',
    env:{ProgramFiles:'C:\\Program Files'},stat:async()=>{throw Error('missing');}});
  await run('iriun');await run('driver');await run('guide');
  assert.deepEqual(opened,[LINKS.iriun,LINKS.driver,LINKS.guide]);
  await assert.rejects(run('https://evil.example/installer.exe'),/허용/);
  assert.equal(opened.length,3);
});
test('failed launch falls back to official instructions without claiming that Iriun ran',async()=>{
  const opened=[],run=createSmartphoneCamera({shell:{openExternal:async u=>opened.push(u)},platform:'win32',
    env:{ProgramFiles:'C:\\Program Files'},stat:async()=>({isFile:()=>true}),launch:async()=>{throw Error('blocked');}});
  assert.match((await run('iriun')).message,/실패/);assert.deepEqual(opened,[LINKS.iriun]);
});
test('camera helper is trusted, preloaded and included in the packaged application',()=>{
  const root=path.resolve(__dirname,'../../..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
  assert.match(fs.readFileSync(path.join(__dirname,'main.cjs'),'utf8'),/'k99:camera-connection'.*trusted\(event\)/);
  assert.match(fs.readFileSync(path.join(__dirname,'preload.cjs'),'utf8'),/cameraConnection:.*k99:camera-connection/);
  assert.match(read('scripts/stage-windows-app.cjs'),/'smartphone-camera\.cjs'/);
});
