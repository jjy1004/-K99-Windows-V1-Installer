'use strict';
const http=require('node:http'),os=require('node:os'),crypto=require('node:crypto');
const {mobileUploadPage}=require('./mobile-upload-page.cjs');
const MAX_BYTES=8*1024*1024,MAX_FILES=100,TTL=10*60*1000;
const fail=(message,status=400)=>Object.assign(Error(message),{status});
function privateIPv4(value){
  const a=String(value).replace(/^::ffff:/,'').split('.').map(Number);
  if(a.length!==4||a.some(n=>!Number.isInteger(n)||n<0||n>255))return false;
  return a[0]===10||a[0]===127||(a[0]===172&&a[1]>=16&&a[1]<=31)||(a[0]===192&&a[1]===168);
}
function lanAddresses(){
  return [...new Set(Object.entries(os.networkInterfaces()).flatMap(([name,entries])=>
    (entries||[]).filter(e=>!e.internal&&(e.family==='IPv4'||e.family===4)&&privateIPv4(e.address))
      .map(e=>({address:e.address,virtual:/virtual|vEthernet|docker|vmware|vpn|wsl/i.test(name)})))
    .sort((a,b)=>Number(a.virtual)-Number(b.virtual)).map(e=>e.address))];
}
function filename(at,number,id){
  const parts=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(at);
  const stamp=parts.replace(/\D/g,'');
  return `MOBILE_${stamp.slice(0,8)}_${stamp.slice(8)}_${String(number).padStart(3,'0')}_${crypto.createHash('sha256').update(id).digest('hex').slice(0,8)}.jpg`;
}
function createMobilePhotoBridge({validateTarget,capture,notify=()=>{},addresses=lanAddresses,port=5050,host='0.0.0.0',now=()=>Date.now()}){
  let server=null,current=null,starting=null,timer=null,closed=false;
  const sockets=new Set();
  function revoke(){clearTimeout(timer);timer=null;current=null;}
  function close(){
    revoke();closed=true;
    const old=server;server=null;
    if(old){old.close();for(const socket of sockets)socket.destroy();sockets.clear();}
  }
  function active(token){
    if(!current||current.token!==token||now()>=current.expiresAt)throw fail('QR 연결이 종료되었거나 만료되었습니다. PC에서 새 QR을 열어 주세요.',410);
    return current;
  }
  function publicStatus(s){return {customerName:s.target.customerName,phoneLast4:s.target.phoneLast4,itemName:s.target.itemName,
    folderIdentifier:s.target.folderIdentifier,expiresAt:s.expiresAt,uploadedCount:s.receipts.size,maxBytes:MAX_BYTES,maxFiles:MAX_FILES};}
  function staffStatus(s){return {...publicStatus(s),id:s.id,urls:s.addresses.map(ip=>`http://${ip}:${server.address().port}/mobile-upload?token=${s.token}&orderId=${encodeURIComponent(s.target.orderId)}`),
    lastResult:s.lastResult||null};}
  function send(res,status,data,html=false){
    res.writeHead(status,{'Content-Type':html?'text/html; charset=utf-8':'application/json; charset=utf-8',
      'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
      'X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' blob:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"});
    res.end(html?data:JSON.stringify(data));
  }
  async function readImage(req){
    const size=Number(req.headers['content-length']);
    if(req.headers['content-length']!==undefined&&(!Number.isSafeInteger(size)||size<32||size>MAX_BYTES))
      throw fail('사진은 8MB 이하 JPEG/PNG로 선택해 주세요.',413);
    const chunks=[];let length=0;
    for await(const chunk of req){length+=chunk.length;if(length>MAX_BYTES)throw fail('사진은 8MB 이하로 선택해 주세요.',413);chunks.push(chunk);}
    const bytes=Buffer.concat(chunks);
    const png=bytes.length>=32&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
    const jpeg=bytes.length>=32&&bytes[0]===255&&bytes[1]===216&&bytes.at(-2)===255&&bytes.at(-1)===217;
    if(!png&&!jpeg)throw fail('JPEG/PNG 원본 사진만 지원합니다. HEIC는 JPEG로 촬영·변환 후 선택해 주세요.',415);
    return {bytes,mime:png?'image/png':'image/jpeg'};
  }
  async function handle(req,res){
    let s,entered=false,uploadSequence=0;
    try{
      if(!privateIPv4(req.socket.remoteAddress))throw fail('매장 내부 네트워크에서만 연결할 수 있습니다.',403);
      const hosts=(current?.addresses||[]).map(ip=>`${ip}:${server.address().port}`);
      if(!hosts.includes(req.headers.host))throw fail('QR에 표시된 PC 주소로 연결해 주세요.',403);
      if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`)throw fail('다른 웹사이트의 전송 요청은 허용하지 않습니다.',403);
      const url=new URL(req.url,'http://local');
      if(req.method==='GET'&&url.pathname==='/mobile-upload'){
        s=active(url.searchParams.get('token'));validateTarget(s.input);
        return send(res,200,mobileUploadPage,true);
      }
      if(req.method==='GET'&&url.pathname==='/api/mobile-upload-status'){
        s=active(url.searchParams.get('token'));validateTarget(s.input);
        return send(res,200,{success:true,...publicStatus(s)});
      }
      if(req.method!=='POST'||url.pathname!=='/api/upload-mobile-photo')throw fail('허용되지 않은 요청입니다.',404);
      s=active(req.headers['x-k99-session-token']);
      validateTarget(s.input);
      if(s.pending>=2)throw fail('사진 저장 중입니다. 잠시 후 다시 전송해 주세요.',429);
      const id=req.headers['x-k99-upload-id'];
      if(typeof id!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(id))throw fail('사진 전송 식별자가 필요합니다.');
      if(!['image/jpeg','image/png','application/octet-stream'].includes((req.headers['content-type']||'').split(';')[0]))
        throw fail('JPEG/PNG 사진만 전송할 수 있습니다.',415);
      s.pending++;entered=true;uploadSequence=++s.uploadSequence;
      const {bytes,mime}=await readImage(req);
      active(req.headers['x-k99-session-token']);validateTarget(s.input);
      const sha=crypto.createHash('sha256').update(bytes).digest('hex');
      let receipt=s.receipts.get(id);
      if(receipt){if(receipt.sha!==sha)throw fail('같은 전송 ID에 다른 사진을 넣을 수 없습니다.',409);
        return send(res,200,{success:true,reused:true,uploadedCount:s.receipts.size,fileName:receipt.fileName});}
      // Keep concurrent retries idempotent, including when the HTTP response is lost.
      if(s.inflight.has(id))throw fail('이 사진은 저장 중입니다. 잠시 후 다시 확인해 주세요.',409);
      if(s.receipts.size+s.inflight.size>=MAX_FILES)throw fail('QR 한 번에 100장까지 전송할 수 있습니다. 새 QR을 열어 주세요.',429);
      s.inflight.add(id);
      try{
        const mobileFileName=filename(new Date(now()),s.receipts.size+1,id);
        const result=await capture({...s.input,requestId:id,imageDataUrl:`data:${mime};base64,${bytes.toString('base64')}`,
          mobileFileName});
        if((!result?.garment&&!result?.photo)||!result?.archive)throw fail('사진 저장 결과를 확인하지 못했습니다.',500);
        receipt={sha,fileName:result.archive.fileName};s.receipts.set(id,receipt);
        // An older, slower upload must not replace the newest successful shot.
        if(uploadSequence>s.lastResultSequence){s.lastResult=result;s.lastResultSequence=uploadSequence;}
        try{notify();}catch{/* Disk/SQLite commit has already succeeded; a closed renderer is not a failed save. */}
        return send(res,200,{success:true,uploadedCount:s.receipts.size,fileName:receipt.fileName});
      }finally{s.inflight.delete(id);}
    }catch(error){
      if(!res.headersSent){res.shouldKeepAlive=false;send(res,error.status||500,{success:false,error:error.message||'사진 저장 실패'});}
    }finally{if(entered)s.pending--;}
  }
  async function start(input){
    if(starting)throw fail('QR 서버를 준비 중입니다. 잠시 후 다시 눌러 주세요.',409);
    const ips=addresses().filter(privateIPv4);
    if(!ips.length)throw fail('매장 내부 IPv4 주소가 없습니다. PC를 매장 Wi-Fi 또는 유선 공유기에 연결해 주세요.',409);
    const target=validateTarget(input);
    revoke();closed=false;
    if(!server){
      const next=http.createServer((req,res)=>void handle(req,res));
      next.requestTimeout=60000;next.headersTimeout=10000;next.keepAliveTimeout=3000;next.maxConnections=8;
      next.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));});
      server=next;
      starting=new Promise((resolve,reject)=>{
        next.once('error',reject);next.listen(port,host,()=>{next.removeListener('error',reject);resolve();});
      });
      try{await starting;}catch(error){server=null;next.close();throw fail(`휴대폰 서버 시작 실패 (${error.code||'오류'}): 포트 ${port} 사용 여부를 확인해 주세요.`,409);}
      finally{starting=null;}
      if(closed){next.close();throw fail('QR 연결 요청이 취소되었습니다.',409);}
    }
    const s={id:crypto.randomUUID(),token:crypto.randomBytes(32).toString('base64url'),input:{...input},target,
      addresses:ips,expiresAt:now()+TTL,receipts:new Map(),inflight:new Set(),pending:0,
      uploadSequence:0,lastResultSequence:0};
    current=s;timer=setTimeout(close,TTL);timer.unref();
    return staffStatus(s);
  }
  async function api(method,pathname,input={}){
    const url=new URL(pathname,'http://local');
    if(method==='POST'&&url.pathname==='/api/mobile-photo/start')return start(input);
    if(method==='POST'&&url.pathname==='/api/mobile-photo/stop'){
      if(current?.id===input.id)close();return {closed:true};
    }
    if(method==='GET'&&url.pathname==='/api/mobile-photo/status'){
      if(!current||current.id!==url.searchParams.get('id'))throw fail('휴대폰 QR 연결이 종료되었습니다.',410);
      active(current.token);validateTarget(current.input);return staffStatus(current);
    }
    throw fail('지원하지 않는 휴대폰 촬영 작업입니다.',404);
  }
  return {api,close};
}
module.exports={createMobilePhotoBridge,lanAddresses,privateIPv4,MAX_BYTES,filename};
