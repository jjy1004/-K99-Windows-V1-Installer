'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {createManualUpdate,newer,FILENAME}=require('./manual-update.cjs');
function fixture(t,options={}){
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'k99-manual-update-test-')),bytes=Buffer.alloc(1024,81),states=[];
  t.after(()=>fs.rmSync(temp,{recursive:true,force:true}));
  const base='https://github.com/jjy1004/-K99-Windows-V1-Installer/releases/download/v2.4.37/';
  const assets=[FILENAME,'installer-release.json'].map(name=>({name,state:'uploaded',size:bytes.length,browser_download_url:base+name}));
  let quits=0,backups=0,locked=false;
  const c=createManualUpdate({temp,version:'2.4.36',onState:s=>states.push(s),
    spawn:()=>{const child=new(require('node:events').EventEmitter)();child.unref=()=>{};child.kill=()=>{};queueMicrotask(()=>child.emit(options.spawnFail?'error':'spawn',new Error('설치 실행 준비 실패')));return child;},
    canInstall:()=>options.busy!==true,quit:()=>quits++,prepare:async()=>{backups++;return {verified:options.backup!==false};},
    onInstalling:()=>{locked=true;return()=>{locked=false;};},
    fetch:async url=>url.includes('/releases/latest')?{ok:true,json:async()=>({tag_name:options.current?'v2.4.36':'v2.4.37',assets})}:
      url.endsWith('.json')?{ok:true,json:async()=>({version:'2.4.37',filename:FILENAME,bytes:bytes.length,
        sha256:options.corrupt?'0'.repeat(64):crypto.createHash('sha256').update(bytes).digest('hex')})}:
      {ok:true,body:(async function*(){yield bytes.subarray(0,512);yield bytes.subarray(512);})()}});
  return {c,states,temp,get quits(){return quits;},get backups(){return backups;},get locked(){return locked;}};
}
async function finish(f){
  f.c.check();for(let i=0;i<500;i++){const s=f.c.status();if(['error','installing','current'].includes(s.phase))return s;await new Promise(r=>setTimeout(r,5));}
  throw Error('모사 업데이트 시간 초과');
}
test('공개 최신 설치본을 TEMP에 내려받고 0~100 진행률·SHA·안전 백업 후 정상 종료를 요청한다',async t=>{
  const f=fixture(t),s=await finish(f);assert.equal(s.phase,'installing');assert.equal(f.quits,1);assert.equal(f.backups,1);assert.equal(f.locked,true);
  assert.ok(f.states.some(s=>s.phase==='downloading'&&s.percent===0));assert.ok(f.states.some(s=>s.percent===100));
  assert.equal(fs.statSync(path.join(f.temp,fs.readdirSync(f.temp)[0],FILENAME)).size,1024);
  f.c.check();assert.equal(f.quits,1);
});
test('체크섬이 다르면 종료·설치·백업을 하지 않는다',async t=>{
  const f=fixture(t,{corrupt:true});assert.equal((await finish(f)).phase,'error');assert.equal(f.quits,0);assert.equal(f.backups,0);
});
test('미완료 접수와 백업 검증 실패는 앱 종료를 막는다',async t=>{
  for(const opt of [{busy:true},{backup:false}]){const f=fixture(t,opt);assert.equal((await finish(f)).phase,'error');assert.equal(f.quits,0);}
});
test('이미 최신이면 다운로드·종료 없이 알리고 버전은 숫자별로 비교한다',async t=>{
  const f=fixture(t,{current:true});assert.equal((await finish(f)).phase,'current');assert.equal(fs.readdirSync(f.temp).length,0);
  assert.equal(newer('2.4.100','2.4.99'),true);assert.equal(newer('2.4.36','2.4.37'),false);assert.throws(()=>newer('../bad','2.4.36'));
});
test('설치 대기 실행기를 시작하지 못하면 앱을 종료하지 않는다',async t=>{
  const f=fixture(t,{spawnFail:true});assert.equal((await finish(f)).phase,'error');assert.equal(f.quits,0);assert.equal(f.locked,false);
});
