'use strict';
const {createMobilePhotoBridge}=require('./mobile-photo-bridge.cjs');
const {imageBytes}=require('./photo-archive.cjs');
const fail=message=>Object.assign(Error(message),{status:409});

// Independent, short-lived LAN session: never retarget/revoke the intake QR.
// Completion captures use the original serialized archive + SQLite pipeline.
function createComparisonMobilePhotos({store,equipmentApi,nativeImage,changed,native=process.platform==='win32',...network}){
  function validateTarget(input){
    if(!native||store.equipment.getConfig().mode!=='real')
      throw fail('휴대폰 완성 사진은 Windows 앱의 실제 장비 모드에서 사용합니다.');
    if(!input||typeof input.orderId!=='string'||typeof input.garmentId!=='string')
      throw fail('완성 사진을 연결할 주문과 의류를 선택하세요.');
    const order=store.equipment.getOrder(input.orderId);
    if(!order.garments?.some(g=>g.garmentId===input.garmentId))
      throw fail('선택한 주문에 연결된 의류가 아닙니다.');
    const garment=order.garments.find(g=>g.garmentId===input.garmentId);
    return {orderId:order.id,customerName:order.customerName,
      phoneLast4:String(order.customerPhone||'').replace(/\D/g,'').slice(-4),
      itemName:`${garment.itemName} · 세탁 후 사진`,folderIdentifier:order.archiveFolderKey||'세탁 전후 사진 폴더'};
  }
  const bridge=createMobilePhotoBridge({...network,port:network.port??5051,validateTarget,notify:changed,
    capture:async input=>{
      validateTarget(input);
      const {bytes}=imageBytes(input.imageDataUrl);
      const image=nativeImage.createFromBuffer(bytes);
      if(image.isEmpty())throw fail('손상되었거나 지원하지 않는 사진입니다.');
      const size=image.getSize();
      if(size.width<1||size.height<1||size.width>8192||size.height>8192)
        throw fail('사진은 가로·세로 8192픽셀 이하로 전송해 주세요.');
      return equipmentApi.api('POST','/api/equipment/command',{
        action:'capture',orderId:input.orderId,garmentId:input.garmentId,
        requestId:input.requestId,imageDataUrl:input.imageDataUrl,
        expectedMode:'real',role:'completion',photo_type:'compare'});
    }});
  return {close:bridge.close,api:(method,pathname,input)=>{
    const url=new URL(pathname,'http://local');
    if(!/^\/api\/comparison-mobile\/(start|status|stop)$/.test(url.pathname))
      throw fail('지원하지 않는 완성 사진 QR 요청입니다.');
    url.pathname=url.pathname.replace('/api/comparison-mobile/','/api/mobile-photo/');
    return bridge.api(method,url.pathname+url.search,input);
  }};
}
module.exports={createComparisonMobilePhotos};
