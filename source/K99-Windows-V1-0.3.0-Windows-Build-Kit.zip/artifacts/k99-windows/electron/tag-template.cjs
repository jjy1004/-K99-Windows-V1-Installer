'use strict';
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function tagAnalysisText(p){
  const group=['폴리에스테르','식물성 혼방','울/실크','나일론'].includes(p.material_group)?p.material_group:String(p.materialTag||'일반').slice(0,80);
  const wash=['물세탁','드라이세탁'].includes(p.wash_method)?p.wash_method:'확인 필요';
  return `[소재] ${group} (${wash}) / [색상] ${String(p.color||'확인 필요').slice(0,40)}`;
}
function tagHTML(job,barcode){
  const p=job.payload,w=Number(p.labelWidthMm),h=Number(p.labelHeightMm);
  if(!Number.isFinite(w)||!Number.isFinite(h)||w<10||h<10)throw Error('태그 용지 크기 오류');
  const compact=h<32,short=String(p.orderNumber||p.orderId||job.orderId||p.garmentId).slice(-8);
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
  <style>@page{size:${w}mm ${h}mm;margin:0}*{box-sizing:border-box}
  body{margin:0;padding:${compact?1:2}mm;font:${compact?7:9}pt 'Malgun Gothic',sans-serif;width:${w}mm;height:${h}mm;overflow:hidden;
  display:grid;grid-template-rows:auto auto minmax(3mm,1fr) auto auto;gap:${compact?.2:.5}mm;align-content:stretch}
  h1{font-size:${compact?8:11}pt;line-height:1.1;margin:0;overflow:hidden;white-space:nowrap}
  p{margin:0;line-height:1.15;overflow-wrap:anywhere}
  .item{font-size:${compact?6:8}pt;max-height:6mm;overflow:hidden}
  img{width:100%;height:100%;min-height:0;object-fit:contain}
  .reference{font-size:${compact?5:6}pt}
  .analysis{font-size:${compact?5.5:7}pt;line-height:1.25;white-space:normal;overflow-wrap:anywhere}</style>
  </head><body><h1>${escape(p.customerName)}</h1>
  <p class="item">${escape(p.itemName)} · ${escape(String(p.serviceType||'').includes('premium')?'프리미엄':'일반')}</p>
  <img src="data:image/png;base64,${barcode.toString('base64')}" alt="의류 바코드">
  <p class="reference">접수 ${escape(short)}</p>
  <p class="analysis">${escape(tagAnalysisText(p))}</p></body></html>`;
}
module.exports={tagHTML,tagAnalysisText};
