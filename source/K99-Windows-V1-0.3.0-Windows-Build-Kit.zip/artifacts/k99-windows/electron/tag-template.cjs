'use strict';
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clean=(v,max)=>String(v??'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,max);
function tagFields(p){
  const aliases={'폴리에스테르 90%이상':'폴리에스테르','폴리에스테르 90% 이상':'폴리에스테르',
    '식물성 혼방':'식물성 섬유','울·실크':'울/실크'};
  const raw=clean(p.manualMaterial||p.material_group||p.material||p.materialTag,80);
  const material=aliases[raw]||raw;
  if(p.payment_type!=null&&!['PREPAID','POSTPAID'].includes(p.payment_type))throw Error('태그 결제 구분 오류');
  return {material:['폴리에스테르','식물성 섬유','울/실크','나일론'].includes(material)?material:'폴리에스테르',
    color:(p.manualColor||p.color)==='흰색'?'흰색':'유색',payment_type_kr:p.payment_type==='POSTPAID'?'후불':'선불'};
}
function tagAnalysisText(p){
  const f=tagFields(p);
  return `[소재] ${f.material}\n[색상] ${f.color}`;
}
// Composable TSPL footer only: never clears/replaces the existing header/barcode,
// changes GAP, or submits a job. Raw transport/font encoding require device validation.
function tagTSPLFooter(job){
  const p=job.payload,l=tagLayout(30,Number(p.labelHeightMm)),f=tagFields(p);
  const lines=[`[소재] ${f.material}`,`[색상] ${f.color}`];
  const dotWidth=text=>[...text].reduce((n,c)=>n+(c.charCodeAt(0)>127?16:8),0);
  if(lines.some(text=>dotWidth(text)>224))throw Error('30mm TSPL 하단 문구가 너무 깁니다. 소재·색상 표현을 줄이세요.');
  const quoted=text=>text.replace(/["\\\r\n]/g,' ');
  return `SIZE 30 mm,${l.height} mm\r\n`+lines.map((text,i)=>
    `TEXT 8,${Math.round((i?l.colorY:l.materialY)*8)},"TSS16.BF2",0,1,1,"${quoted(text)}"`).join('\r\n')+'\r\n';
}
function tagLayout(w,h){
  if(w!==30||!Number.isFinite(h)||h<28||h>150)
    throw Error('과천 태그 폭은 30mm 고정입니다. 실제 롤의 높이(28~150mm)를 확인하세요.');
  const dotsPerMm=8,fontDots=16,pitchDots=22,barcodeGapDots=8;
  const compact=h<36,padding=1,gap=.4,line=2.4;
  const rows=[compact?3:4,compact?2.7:3.2,2.7];
  const barcodeY=padding+rows.reduce((a,b)=>a+b,0)+3*gap;
  const materialY=h-padding-line-pitchDots/dotsPerMm;
  const barcodeHeight=materialY-barcodeGapDots/dotsPerMm-barcodeY;
  if(barcodeHeight<6)throw Error('바코드와 소재·색상 여백을 확보할 수 없는 라벨 크기입니다.');
  return {width:w,height:h,padding,gap,line,rows,barcodeY,barcodeHeight,
    materialY,colorY:materialY+pitchDots/dotsPerMm,footerBottom:h-padding,
    dotsPerMm,fontDots,pitchDots,barcodeGapDots};
}
function tagHTML(job,barcode){
  const p=job.payload,w=30,h=Number(p.labelHeightMm);
  const l=tagLayout(w,h),f=tagFields(p),short=String(p.orderNumber||p.orderId||job.orderId||p.garmentId).slice(-8);
  const customerY=l.padding,itemY=customerY+l.rows[0]+l.gap,referenceY=itemY+l.rows[1]+l.gap;
  const block=(top,height)=>`top:${top}mm;height:${height}mm`;
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
  <style>@page{size:${w}mm ${h}mm;margin:0}*{box-sizing:border-box}
  body{margin:0;color:#000;background:#fff;font:8pt 'Malgun Gothic',sans-serif;width:${w}mm;height:${h}mm;position:relative}
  .row{position:absolute;left:${l.padding}mm;width:${w-2*l.padding}mm;margin:0;white-space:nowrap;line-height:1.1}
  h1{font-size:10pt}.item{font-size:8pt}.reference{font-size:6pt}
  img{object-fit:contain}
  .analysis{font-size:2mm;line-height:1.05;font-weight:500}
  .ocr-text{display:inline-block;transform-origin:left center}</style>
  </head><body>
  <h1 class="row fit-text" style="${block(customerY,l.rows[0])}">${escape(p.customerName)}</h1>
  <p class="row item fit-text" style="${block(itemY,l.rows[1])}">${escape(p.itemName)} · ${escape(String(p.serviceType||'').includes('premium')?'프리미엄':'일반')}</p>
  <p class="row reference fit-text" style="${block(referenceY,l.rows[2])}">접수 ${escape(short)} · ${escape(clean(p.shortNumber||p.sequence||'',12))}</p>
  <img class="row" style="${block(l.barcodeY,l.barcodeHeight)}" src="data:image/png;base64,${barcode.toString('base64')}" alt="의류 바코드">
  <p class="row analysis ocr-fixed" data-field="material" style="${block(l.materialY,l.line)}"><span class="ocr-text">${escape(`[소재] ${f.material}`)}</span></p>
  <p class="row analysis ocr-fixed" data-field="color" style="${block(l.colorY,l.line)}"><span class="ocr-text">${escape(`[색상] ${f.color}`)}</span></p></body></html>`;
}
// Runs in the hidden print renderer, after fonts and the actual barcode are ready.
async function validateRenderedTag(){
  await document.fonts.ready;
  await Promise.all([...document.images].map(i=>i.decode()));
  const rows=[...document.querySelectorAll('.row')];
  for(const el of document.querySelectorAll('.ocr-fixed')){
    const text=el.querySelector('.ocr-text'),width=text.getBoundingClientRect().width;
    const scale=Math.min(1,el.clientWidth/width);
    if(scale<.8||el.scrollHeight>el.clientHeight)
      throw Error('30mm 태그 문구가 너무 깁니다. 소재·색상 표현을 확인하세요. 용지 폭은 늘리지 않습니다.');
    text.style.transform=`scaleX(${scale})`;
    if(text.getBoundingClientRect().right>el.getBoundingClientRect().right+.5)
      throw Error('30mm 태그 우측 경계 초과');
  }
  for(const el of document.querySelectorAll('.fit-text')){
    let size=parseFloat(getComputedStyle(el).fontSize);
    while((el.scrollWidth>el.clientWidth||el.scrollHeight>el.clientHeight)&&size>6.67){
      size=Math.max(6.67,size-.25);el.style.fontSize=size+'px';
    }
    if(el.scrollWidth>el.clientWidth||el.scrollHeight>el.clientHeight)throw Error('태그 글자가 용지 영역보다 깁니다. 용지 크기 또는 입력 내용을 확인하세요.');
  }
  const page=document.body.getBoundingClientRect(),boxes=rows.map(e=>e.getBoundingClientRect());
  for(let i=0;i<boxes.length;i++){
    const b=boxes[i];
    if(b.left<page.left-.5||b.right>page.right+.5||b.top<page.top-.5||b.bottom>page.bottom+.5||
      (i&&b.top<boxes[i-1].bottom-.5))throw Error('태그 바코드·소재·색상 영역 겹침을 감지했습니다.');
  }
  return {verified:true,rows:boxes.length};
}
module.exports={tagHTML,tagAnalysisText,tagFields,tagLayout,tagTSPLFooter,validateRenderedTag};
