'use strict';
const noticeMobilePage=`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>완성 세탁물 특별 고지 입력</title><style>
body{margin:0;background:#10252e;color:#fff;font:20px/1.6 system-ui}main{max-width:640px;margin:auto;padding:22px}button,input,select,textarea{box-sizing:border-box;width:100%;font:inherit;border-radius:10px;padding:14px;margin:8px 0}
button{background:#f4cc64;color:#10252e;font-weight:800;border:0;min-height:58px}textarea{min-height:260px}small{color:#c8dadf}#status{white-space:pre-wrap}
</style><main><h1>완성 세탁물<br>특별 고지 입력</h1>
<button id="back">사진 촬영 화면으로 돌아가기</button>
<label>고객명 2글자 또는 연락처 뒷4자리<input id="keyword" lang="ko" autocomplete="off"></label><button id="search">고객 찾기</button>
<label>고객·주문 선택<select id="order"><option value="">고객을 먼저 선택해 주세요</option></select></label>
<label>사례 주제어<input id="theme" lang="ko" placeholder="예: 패딩 잔존 얼룩"></label>
<label>직원 특별 고지<textarea id="body" lang="ko" placeholder="고객에게 안내할 내용을 입력해 주세요."></textarea></label>
<small>음성 입력: 위 입력칸을 누른 뒤 휴대폰 키보드의 마이크를 사용하세요. 키보드가 지원하지 않으면 직접 입력해 주세요.</small>
<button id="send">카운터 PC로 고지 내용 전송</button><p id="status" role="status">이 화면은 고객에게 직접 발송하지 않습니다.</p></main>
<script>
(()=>{const $=id=>document.getElementById(id),token=new URLSearchParams(location.search).get('token');
let busy=false,requestId='',sentBody='';
async function api(path,body){const r=await fetch('/api/mobile-notice/'+path+(path.includes('?')?'&':'?')+'token='+encodeURIComponent(token||''),{
method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-K99-Notice-Token':token||''},...(body?{body:JSON.stringify(body)}:{})});
const result=await r.json();if(!r.ok)throw Error(result.error||'연결을 확인해 주세요.');return result;}
async function search(){try{const result=await api('orders?keyword='+encodeURIComponent($('keyword').value.trim()));
$('order').replaceChildren();if(!result.orders.length){const o=document.createElement('option');o.value='';o.textContent='일치하는 저장 주문이 없습니다. 접수 완료 후 검색해 주세요.';$('order').append(o);}
for(const row of result.orders){const o=document.createElement('option');o.value=row.orderId;o.textContent=row.customerName+' · '+row.phoneLast4+' · '+row.visitDate;$('order').append(o);}
}catch(e){$('status').textContent=e.message;}}
$('search').onclick=search;$('back').onclick=()=>history.back();
$('send').onclick=async()=>{if(busy)return;const orderId=$('order').value,body=$('body').value.trim(),theme=$('theme').value.trim();
if(!orderId||!body){$('status').textContent='고객과 고지 내용을 확인해 주세요.';return;}
const fingerprint=JSON.stringify([orderId,body,theme]);if(sentBody!==fingerprint){requestId='mobile-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);sentBody=fingerprint;}
busy=true;$('send').disabled=true;try{await api('save',{orderId,body,theme,requestId});$('status').textContent='카운터 PC에 저장했습니다. 직원이 문안을 확인한 뒤 고객에게 별도로 발송합니다.';}
catch(e){$('status').textContent=e.message;}finally{busy=false;$('send').disabled=false;}};
void search();})();
</script></html>`;
module.exports={noticeMobilePage};
