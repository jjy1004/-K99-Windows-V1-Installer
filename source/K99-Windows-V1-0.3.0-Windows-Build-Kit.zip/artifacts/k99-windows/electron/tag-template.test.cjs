'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {tagFields,tagHTML,tagLayout,tagTSPLFooter}=require('./tag-template.cjs');
test('manual selections override all AI values and print exactly two lines without wash guesses',()=>{
  for(const material of ['폴리에스테르','식물성 섬유','울/실크','나일론'])for(const color of ['유색','흰색']){
    const p={labelWidthMm:60,labelHeightMm:40,garmentId:'FULL-ENCODED-UUID',customerName:'시험',
      itemName:'상의',manualMaterial:material,manualColor:color,material_group:'나일론',wash_method:'물세탁',color:'네이비',orderNumber:'ORDER-12345678'};
    const html=tagHTML({payload:p},Buffer.from('test'));
    assert.ok(html.includes(`[소재] ${material}</span>`));assert.ok(html.includes(`[색상] ${color}</span>`));
    assert.ok(!html.includes('확인 필요'));assert.ok(!html.includes('(물세탁)'));
    assert.ok(!html.includes('[결제]'));
    assert.ok(html.includes('@page{size:30mm 40mm'));
    const tspl=tagTSPLFooter({payload:p});
    assert.match(tspl,/^SIZE 30 mm,40 mm\r\nTEXT 8,/);
    assert.match(tspl,/"TSS16.BF2",0,1,1/);
    assert.ok(html.includes('접수 12345678'));assert.ok(!html.includes('FULL-ENCODED-UUID'));
  }
  assert.deepEqual(tagFields({material:'울·실크',wash_type:'드라이세탁',color:'흰색',payment_type:'POSTPAID'}),{material:'울/실크',color:'흰색',payment_type_kr:'후불'});
  assert.equal(tagFields({material:'폴리에스테르 90%이상'}).material,'폴리에스테르');
  assert.deepEqual(tagFields({}),{material:'폴리에스테르',color:'유색',payment_type_kr:'선불'});
  assert.throws(()=>tagFields({payment_type:'unknown'}),/결제/);
  assert.ok(!tagHTML({payload:{labelWidthMm:60,labelHeightMm:40,color:'<script>'}},Buffer.from('test')).includes('[색상] <script>'));
});
test('millimetre layout reserves barcode/footer gap and bottom margin at every supported height',()=>{
  for(const width of [30])for(const height of [28,32,35,40,60,150]){
    const l=tagLayout(width,height);
    assert.ok(l.barcodeHeight>=6);
    assert.ok((l.materialY-(l.barcodeY+l.barcodeHeight))*l.dotsPerMm>=7.99);
    assert.ok((l.colorY-l.materialY)*l.dotsPerMm>=21.99);
    assert.equal(l.fontDots,16);
    assert.ok(l.colorY>=l.materialY+l.line);
    assert.ok(l.colorY+l.line<=height-l.padding+.001);
  }
  assert.throws(()=>tagLayout(60,40),/30mm/);
  console.log('30x40mm virtual layout:',JSON.stringify(tagLayout(30,40)));
});
