'use strict';
const TITLES={
  downloading:'새로운 기능이 업데이트되었습니다.\n잠시만 기다려 주세요...',
  ready:'새 버전 다운로드가 끝났습니다.',
  installing:'새로운 기능이 업데이트되었습니다.\n잠시만 기다려 주세요...',
  error:'업데이트는 다음에 다시 시도합니다.',
};
function noticeText(state={}){
  const phase=Object.hasOwn(TITLES,state.phase)?state.phase:'downloading';
  const percent=Number.isFinite(state.percent)?Math.round(Math.min(100,Math.max(0,state.percent))):null;
  const details=phase==='ready'?(state.deferred?
    '지금 하시던 업무를 계속하세요.\n프로그램을 종료하면 안전하게 업데이트 후 다시 실행됩니다.':
    '사용을 시작하지 않으면 잠시 후 자동으로 다시 실행됩니다.\n업무를 시작하면 업데이트 적용을 미룹니다.'):
    phase==='installing'?'고객 장부와 설정을 안전하게 백업하고 있습니다.\n완료되면 최신 버전으로 자동으로 다시 실행됩니다.':
    phase==='error'?'현재 버전으로 접수·촬영·출력을 계속 사용할 수 있습니다.':
    '프로그램을 끄지 않으셔도 됩니다.\n고객 장부·사진·매장 설정은 그대로 유지됩니다.';
  return {title:TITLES[phase],details,progress:phase==='downloading'&&percent!==null?
    `다운로드 ${percent}%`:phase==='installing'?'안전 백업 · 업데이트 준비 중':'',percent};
}
function updateNoticeHtml(){
  return `<!doctype html><html lang="ko"><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<title>K99 업데이트 안내</title><style>
*{box-sizing:border-box}html{color-scheme:dark;background:#0f172a}body{margin:0;background:#0f172a;color:#f8fafc;font-family:"Malgun Gothic",sans-serif;padding:24px}
main{background:#17243b;color:#f8fafc;border:3px solid #4ade80;border-radius:22px;padding:24px;text-align:center}
.symbol{font-size:38px;color:#86efac}h1{color:#fff;font-size:29px;line-height:1.45;margin:12px 0;white-space:pre-line}
p{color:#e2e8f0;font-size:21px;line-height:1.6;white-space:pre-line;margin:16px 0}#progress{font-weight:bold;color:#86efac}
.dismiss{display:block;background:#f8fafc;color:#0f172a;border:3px solid #86efac;border-radius:12px;padding:12px 24px;font-size:23px;font-weight:bold;text-decoration:none;margin-top:18px}
.dismiss:focus-visible{outline:4px solid #fde047;outline-offset:4px}
@media(forced-colors:active){html,body,main{background:Canvas;color:CanvasText}h1,p,.symbol,#progress{color:CanvasText}.dismiss{background:ButtonFace;color:ButtonText;border-color:ButtonText}}
</style><main role="status" aria-live="polite"><div class="symbol">↻</div>
<h1 id="title">새로운 기능이 업데이트되었습니다.\n잠시만 기다려 주세요...</h1>
<p id="details">고객 장부·사진·매장 설정은 그대로 유지됩니다.</p><p id="progress"></p>
<a class="dismiss" role="button" href="k99-update-notice:close">확인 · 닫기 (업데이트는 계속됩니다)</a></main></html>`;
}
function createUpdateNotice({BrowserWindow,dialog,parent,later=setTimeout,cancel=clearTimeout,warn=console.warn}){
  let window,loaded=false,state={phase:'downloading'},lastPercent=-1,lastPhase,dismissedPhase;
  let loadTimer,paintTimer,painting=false,broken=false,nativePending=false,nativePhase,closing=false;
  function clearTimers(){cancel(loadTimer);cancel(paintTimer);loadTimer=paintTimer=undefined;painting=false;}
  function nativeNotice(){
    if(closing||nativePending||nativePhase===state.phase)return;
    const data=noticeText(state),phase=state.phase;
    nativePhase=phase;nativePending=true;
    // No parent window and no synchronous dialog: never disable the reception
    // window or wait for acknowledgement in the update/capture pipeline.
    try{
      Promise.resolve(dialog?.showMessageBox({type:'info',title:'K99 업데이트 안내',
        message:data.title,detail:`${data.details}\n${data.progress}\n안내 화면을 표시하지 못해 기본 안내창으로 대신 알려드립니다. 접수 내용은 그대로 유지됩니다.`,
        buttons:['확인'],defaultId:0,noLink:true})).catch(()=>warn('K99 기본 업데이트 안내 표시 실패'))
        .finally(()=>{nativePending=false;if(!closing&&state.phase!==phase)nativeNotice();});
    }catch{nativePending=false;warn('K99 기본 업데이트 안내 표시 실패');}
  }
  function fail(current,reason){
    if(window!==current||closing)return;
    warn('K99 업데이트 안내 대체 표시:',reason);
    broken=true;clearTimers();window=null;loaded=false;
    try{if(!current.isDestroyed())current.destroy();}catch{}
    nativeNotice();
  }
  function paint(){
    if(!loaded||!window||window.isDestroyed()||painting)return;
    const data=noticeText(state),current=window,signature=JSON.stringify(data);
    painting=true;paintTimer=later(()=>fail(current,'상태 표시 응답 지연'),2000);
    // Values are serialized, never interpolated as HTML. The page has no IPC,
    // Node integration, network access or user-controlled markup.
    try{
      Promise.resolve(current.webContents.executeJavaScript(`(()=>{const s=${signature};
        for(const key of ['title','details','progress'])document.getElementById(key).textContent=s[key];})()`))
        .then(()=>{
          if(window!==current)return;
          cancel(paintTimer);painting=false;
          if(JSON.stringify(noticeText(state))!==signature)paint();
        },()=>fail(current,'상태 표시 실패'));
    }catch{fail(current,'상태 표시 예외');}
  }
  function show(next){
    if(closing)return;
    state={...state,...next};
    if(state.phase===dismissedPhase)return;
    if(broken){nativeNotice();return;}
    if(next.phase==='error'&&!window)return;
    if(!window||window.isDestroyed()){
      const owner=parent?.();
      try{
      window=new BrowserWindow({width:760,height:560,show:false,resizable:false,backgroundColor:'#0f172a',
        minimizable:false,maximizable:false,title:'K99 업데이트 안내',autoHideMenuBar:true,
        ...(owner&&!owner.isDestroyed()?{parent:owner}:{}),
        webPreferences:{sandbox:true,nodeIntegration:false,contextIsolation:true,devTools:false}});
      const current=window;
      loaded=false;window.center();
      window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
      window.webContents.on('will-navigate',(event,url)=>{
        event.preventDefault();
        if(url==='k99-update-notice:close'&&window===current){dismissedPhase=state.phase;close();}
      });
      window.webContents.once('did-finish-load',()=>{
        if(window!==current)return;
        cancel(loadTimer);loaded=true;paint();
        if(window===current&&!current.isDestroyed())current.showInactive();
      });
      window.webContents.on('did-fail-load',(_e,code,_text,_url,main)=>{
        if(main!==false)fail(current,`화면 로드 실패 (${code})`);
      });
      window.webContents.on('render-process-gone',()=>fail(current,'안내 화면 실행 종료'));
      window.on('unresponsive',()=>fail(current,'안내 화면 응답 없음'));
      window.on('closed',()=>{if(window===current){clearTimers();dismissedPhase=state.phase;window=null;loaded=false;}});
      loadTimer=later(()=>fail(current,'화면 로드 시간 초과'),4000);
      try{
        Promise.resolve(window.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(updateNoticeHtml())))
          .catch(()=>fail(current,'안내 주소 로드 실패'));
      }catch{fail(current,'안내 주소 로드 예외');}
      }catch{
        const failed=window;window=null;loaded=false;broken=true;clearTimers();
        try{failed?.destroy();}catch{}
        warn('K99 업데이트 안내 창 생성 실패');nativeNotice();
      }
    }
    const percent=Math.floor((state.percent||0)/5);
    if(lastPhase!==state.phase||percent!==lastPercent||state.deferred){lastPhase=state.phase;lastPercent=percent;paint();}
  }
  const waitForPaint=()=>new Promise(resolve=>{show({phase:'installing'});later(resolve,1200);});
  function close(){clearTimers();const current=window;window=null;loaded=false;if(current&&!current.isDestroyed())current.destroy();}
  return {show,waitForPaint,close,dispose(){closing=true;close();}};
}
module.exports={createUpdateNotice,noticeText,updateNoticeHtml};
