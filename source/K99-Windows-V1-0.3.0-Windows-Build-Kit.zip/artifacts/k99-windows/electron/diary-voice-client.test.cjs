'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createDiaryVoiceClient,serverUrl,installDiaryVoice}=require('./diary-voice-client.cjs');
const key='test-only-access-code-123456789';
function fixture(t,fetchImpl,extra={}){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-voice-client-')),file=path.join(dir,'voice.json');
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const client=createDiaryVoiceClient({file,env:{},safeStorage:{
    isEncryptionAvailable:()=>true,encryptString:v=>Buffer.from('encrypted:'+v),decryptString:v=>v.toString().slice(10)},
    store:()=>({api:()=>({store_id:'test-store',glossary:[{source:'오염',target:'얼룩'}],corrections:[]})}),fetchImpl,...extra});
  return {client,file};
}
test('공급자 키 없이 게시된 기본 서버를 사용하고 접근 코드 미설정이면 네트워크를 호출하지 않는다',async t=>{
  let called=0;const f=fixture(t,async()=>{called++;});
  assert.equal((await f.client.request('status')).url,'https://k-99-windows-v-1.replit.app');
  await assert.rejects(f.client.request('organize',{raw_text:'시험'}),/접근 코드/);assert.equal(called,0);
  assert.throws(()=>serverUrl('http://example.com'),/HTTPS/);
  assert.throws(()=>serverUrl('https://user:pass@example.com'),/HTTPS/);
  assert.throws(()=>serverUrl('https://localhost'),/HTTPS/);
});
test('접근 코드는 암호화 저장·응답에서 제외하고 전체 원문과 새 사전을 서버로 전달한다',async t=>{
  let request;const f=fixture(t,async(url,input)=>{request={url,...input};return Response.json({text:'정리 결과'});});
  await f.client.request('configure',{url:'https://voice.example.com',token:key});
  const status=await f.client.request('status');assert.equal(status.tokenConfigured,true);assert.equal(status.token,undefined);
  assert.equal(fs.readFileSync(f.file,'utf8').includes(key),false);
  assert.equal((await f.client.request('organize',{raw_text:'누적된 전체 원문'})).text,'정리 결과');
  assert.equal(request.redirect,'error');
  assert.equal(request.headers.Authorization,`Bearer ${key}`);
  assert.deepEqual(JSON.parse(request.body).context.glossary,[{source:'오염',target:'얼룩'}]);
  assert.equal(JSON.parse(request.body).raw_text,'누적된 전체 원문');
});
test('환경변수 주소·접근 코드 재정의와 HTML·실패 응답·동시 요청 방어',async t=>{
  let release;const f=fixture(t,()=>new Promise(resolve=>{release=resolve;}),{env:{K99_DIARY_VOICE_SERVER_URL:'https://override.example.com',K99_DIARY_VOICE_ACCESS_TOKEN:key}});
  const pending=f.client.request('organize',{raw_text:'시험 일기'});
  await assert.rejects(f.client.request('organize',{raw_text:'중복'}),/처리 중/);
  release(new Response('<html>로그인</html>',{headers:{'content-type':'text/html'}}));
  await assert.rejects(pending,/게시|제한/);
  assert.equal((await f.client.request('status')).url,'https://override.example.com');
});
test('음성 IPC는 직원의 신뢰된 메인 프레임에서만 허용한다',async()=>{
  let handler,calls=0;const staff={};
  installDiaryVoice({ipcMain:{handle:(_name,fn)=>{handler=fn;}},trusted:e=>{if(!e.trusted)throw Error('권한 없음');},
    isStaff:sender=>sender===staff,client:{request:async()=>{calls++;return {text:'시험'};}}});
  assert.equal((await handler({trusted:false,sender:staff},{action:'status'})).ok,false);
  assert.equal((await handler({trusted:true,sender:{}},{action:'status'})).ok,false);
  assert.equal(calls,0);
  assert.equal((await handler({trusted:true,sender:staff},{action:'status'})).ok,true);
});
