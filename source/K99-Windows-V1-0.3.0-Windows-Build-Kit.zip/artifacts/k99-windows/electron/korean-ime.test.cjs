'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {spawnSync}=require('node:child_process');
const {IME_SCRIPT,nativeHandle,createKoreanIme,installKoreanIme}=require('./korean-ime.cjs');
const win={isDestroyed:()=>false,isFocused:()=>true,getNativeWindowHandle:()=>{const b=Buffer.alloc(8);b.writeBigUInt64LE(0x123456789n);return b;}};
test('native HWND remains 64-bit, renderer cannot supply a command or a path',()=>{
  assert.equal(nativeHandle(win),'4886718345');
  assert.match(IME_SCRIPT,/ImmGetDefaultIMEWnd/);assert.match(IME_SCRIPT,/GetGUIThreadInfo/);
  assert.match(IME_SCRIPT,/GetAncestor\(front,2\)!=root/);
  assert.match(IME_SCRIPT,/SendMessageTimeout/);assert.doesNotMatch(IME_SCRIPT,/Invoke-Expression|Set-ItemProperty/);
});
test('non-Windows and background windows do not spawn helpers',async()=>{
  let calls=0;const engine=createKoreanIme({platform:'linux',spawn(){calls++;}});
  assert.equal((await engine.request(win)).state,'inactive');engine.dispose();
  const windows=createKoreanIme({platform:'win32',spawn(){calls++;}});
  assert.equal((await windows.request({...win,isFocused:()=>false})).state,'inactive');
  windows.dispose();assert.equal(calls,0);
});
test('one warm worker coalesces focus storms, switches English and closes on quit',async()=>{
  const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();
  child.stdin=new EventEmitter();const sent=[];child.stdin.write=line=>{sent.push(JSON.parse(line));};
  let spawns=0,killed=0;child.kill=()=>{killed++;};
  const engine=createKoreanIme({platform:'win32',spawn(command,args,options){
    spawns++;assert.equal(command,'powershell.exe');assert.equal(options.windowsHide,true);
    assert.equal(args.at(-2),'-EncodedCommand');return child;
  }});
  const first=engine.request(win),second=engine.request(win);
  assert.equal((await first).state,'superseded');
  child.stdout.emit('data','{"ready":true}\n');assert.equal(sent.length,1);
  assert.equal(sent[0].hwnd,'4886718345');assert.equal(sent[0].korean,true);
  child.stdout.emit('data',JSON.stringify({id:sent[0].id,state:'requested'})+'\n');
  assert.equal((await second).state,'requested');
  const english=engine.request(win,false);assert.equal(sent[1].korean,false);
  child.stdout.emit('data',JSON.stringify({id:sent[1].id,state:'requested'})+'\n');await english;
  assert.equal(spawns,1);engine.dispose();assert.equal(killed,1);
});
test('spawn denial is harmless and a later focus can retry',async()=>{
  const engine=createKoreanIme({platform:'win32',spawn(){throw Error('보안 프로그램 차단');}});
  assert.equal((await engine.request(win)).state,'unavailable');
  assert.equal((await engine.request(win)).state,'unavailable');engine.dispose();
});
test('IPC validates origin, derives window on main side and remembers English opt-out',async()=>{
  const app=new EventEmitter(),calls=[];let handler;
  const engine={request:(...args)=>{calls.push(args);return Promise.resolve({state:'requested'});},dispose(){}};
  const stop=installKoreanIme({app,BrowserWindow:{fromWebContents:()=>win},
    ipcMain:{handle:(channel,fn)=>{assert.equal(channel,'ime:force-korean');handler=fn;},removeHandler(){}},
    trusted:event=>{if(!event.allowed)throw Error('403');},engine});
  assert.throws(()=>handler({allowed:false},{korean:true}),/403/);
  assert.equal(handler({allowed:true},{hwnd:'injected',korean:'true'}).state,'invalid');
  await handler({allowed:true},{korean:false});app.emit('browser-window-focus',{},win);
  assert.equal(calls.at(-1)[1],false);stop();
});
test('Windows 실제 PowerShell/C# 컴파일 및 포그라운드 보호 API 실행',
  {skip:process.platform!=='win32'},()=>{
  const result=spawnSync('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',
    Buffer.from(IME_SCRIPT,'utf16le').toString('base64')],
    {input:'{"id":1,"hwnd":"0","korean":true}\n',encoding:'utf8',timeout:25000,windowsHide:true});
  assert.equal(result.status,0,result.stderr);
  const lines=result.stdout.trim().split(/\r?\n/).map(s=>JSON.parse(s));
  assert.equal(lines[0].ready,true);assert.equal(lines[1].state,'not-foreground');
});
