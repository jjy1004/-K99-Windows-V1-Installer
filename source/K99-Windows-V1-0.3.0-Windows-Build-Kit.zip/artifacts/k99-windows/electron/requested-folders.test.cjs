'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {prepareStorageLayout,provisionStoreName}=require('./storage-layout.cjs');
function disk(){
  const nodes=new Map([['D:\\',null],['C:\\',null],['E:\\',null]]);
  const io={existsSync:p=>nodes.has(p),mkdirSync:p=>nodes.set(p,null),accessSync(){},
    lstatSync:()=>({isSymbolicLink:()=>false}),readdirSync:()=>[],
    openSync:p=>{assert.ok(!nodes.has(p));nodes.set(p,'');return p;},writeFileSync:(p,v)=>nodes.set(p,v),readFileSync:p=>nodes.get(p),
    fsyncSync(){},closeSync(){},renameSync:(a,b)=>{nodes.set(b,nodes.get(a));nodes.delete(a);}};
  return {nodes,io};
}
const drives=[{root:'E:\\',type:2,external:true},{root:'D:\\',type:3},{root:'C:\\',type:3}];
test('신규 상호 폴더는 D 우선 K99 매장명, 기존 과천 루트는 그대로 보존한다',()=>{
  const a=disk(),x=prepareStorageLayout('/isolated',{io:a.io,drives,storeName:'가상과천세탁소',namedLayout:true});
  assert.equal(x.root,'D:\\K99 가상과천세탁소');
  assert.ok(a.nodes.has('D:\\K99 가상과천세탁소\\01_고객세탁사진'));
  const b=disk();b.nodes.set('D:\\K99과천매장',null);
  const old=prepareStorageLayout('/isolated',{io:b.io,drives,storeName:'가상다른상호',namedLayout:true});
  assert.equal(old.root,'D:\\K99과천매장');assert.equal(provisionStoreName('/isolated','새로운상호',{io:b.io}).changed,false);
});
test('사진 없는 신규 미등록 루트만 최초 상호 등록에 연결하고 이전 폴더는 남긴다',()=>{
  const f=disk(),a=prepareStorageLayout('/isolated',{io:f.io,drives,namedLayout:true});
  const b=provisionStoreName('/isolated','가상매장',{io:f.io});
  assert.equal(b.changed,true);assert.equal(b.root,'D:\\K99 가상매장');
  assert.ok(f.nodes.has(a.root));assert.ok(b.previousRoots.includes(a.root));
  assert.equal(provisionStoreName('/isolated','또바꾼매장',{io:f.io}).changed,false);
});
test('신규 고객 폴더 이름과 기존 날짜별 사진 폴더 모두 덮어쓰지 않고 연다',async t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-named-photos-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const {createPhotoArchive}=require('./photo-archive.cjs');
  const archive=createPhotoArchive({getRoot:()=>root,openPath:async()=>'',customerFolders:true});
  const order={id:'fake',customerName:'가상고객',customerPhone:'01000009876',createdAt:'2026-11-28T00:00:00.000Z'};
  const a=await archive.open(order,'intake');assert.equal(path.basename(a.folder),'가상고객_9876');
  const legacy=path.join(root,'02_세탁전후사진','20261128_가상고객_9876');fs.mkdirSync(legacy,{recursive:true});
  fs.writeFileSync(path.join(legacy,'원본보존.txt'),'변경금지');
  const b=await archive.open(order,'comparison');assert.equal(b.folder,legacy);
  assert.equal(fs.readFileSync(path.join(legacy,'원본보존.txt'),'utf8'),'변경금지');
});
