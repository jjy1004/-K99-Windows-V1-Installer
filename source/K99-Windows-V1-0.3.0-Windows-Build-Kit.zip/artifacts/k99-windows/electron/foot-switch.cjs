'use strict';
function createFootSwitch({globalShortcut,getMain}){
  let key;
  const dispose=()=>{if(key)globalShortcut.unregister(key);key=undefined;};
  function set(input){
    if(typeof input?.active!=='boolean')throw Error('촬영 준비 상태가 필요합니다.');
    if(!input.active){dispose();return {active:false};}
    const next=input.accelerator||'F12';
    if(!/^(F([1-9]|1[0-2])|Space|Enter|[A-Z])$/.test(next))throw Error('풋 스위치는 F1~F12, Space, Enter, A~Z를 지원합니다.');
    if(key===next)return {active:true,accelerator:key};
    dispose();
    const ok=globalShortcut.register(next,()=>{
      const main=getMain();
      if(main&&!main.isDestroyed())main.webContents.send('k99:foot-capture',{at:Date.now(),accelerator:next});
    });
    if(!ok)throw Error(`${next} 전역 단축키 등록 실패. 다른 프로그램의 사용 여부를 확인하세요.`);
    key=next;return {active:true,accelerator:key};
  }
  return {set,dispose};
}
module.exports={createFootSwitch};
