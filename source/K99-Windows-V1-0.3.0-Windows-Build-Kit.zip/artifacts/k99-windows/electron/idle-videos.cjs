'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {fileVideoResponse}=require('./customer-video.cjs');
const IMAGE_MIME={'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp'};
function imageSignature(file,ext){
  const bytes=Buffer.alloc(12),fd=fs.openSync(file,'r');
  try{fs.readSync(fd,bytes,0,12,0);}finally{fs.closeSync(fd);}
  if(ext==='.png')return bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'));
  if(ext==='.webp')return bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
  return bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
}
// The renderer gets opaque tokens, never arbitrary filesystem paths.
function createIdleVideos({folder,openPath}){
  let entries=new Map();
  const checkRoot=()=>{
    if(!folder)throw Error('고객 모니터 영상 폴더는 Windows 앱에서 지원합니다.');
    if(fs.lstatSync(folder).isSymbolicLink()||fs.realpathSync(folder)!==path.resolve(folder))
      throw Error('영상 폴더의 링크·정션은 허용하지 않습니다.');
  };
  function list(){
    checkRoot();
    const next=new Map();
    const names=fs.readdirSync(folder).filter(name=>/\.(mp4|webm|jpe?g|png|webp)$/i.test(name)).sort((a,b)=>
      a.localeCompare(b,'ko',{numeric:false,sensitivity:'variant'}));
    for(const name of names){
      const file=path.join(folder,name);
      let s;try{s=fs.lstatSync(file);}catch{continue;}
      if(!s.isFile()||s.isSymbolicLink()||!s.size)continue;
      const mime=IMAGE_MIME[path.extname(name).toLowerCase()];
      if(mime&&(s.size>20*1024*1024||!imageSignature(file,path.extname(name).toLowerCase())))continue;
      const token=crypto.createHash('sha256').update(name).digest('hex');
      next.set(token,{name,file,mime});
    }
    entries=next;
    return {success:true,files:[...entries].map(([token,{name,mime}])=>({name,url:`k99://app/idle-videos/${token}`,...(mime?{kind:'image',durationMs:10000}:{})}))};
  }
  async function response(request){
    const token=new URL(request.url).pathname.slice('/idle-videos/'.length);
    const entry=/^[a-f0-9]{64}$/.test(token)&&entries.get(token);
    if(!entry)return new Response('영상을 찾을 수 없습니다.',{status:404});
    try{
      checkRoot();
      const s=fs.lstatSync(entry.file);
      if(!s.isFile()||s.isSymbolicLink()||fs.realpathSync(entry.file)!==path.resolve(entry.file))
        return new Response('허용되지 않은 영상입니다.',{status:403});
      if(entry.mime&&(s.size>20*1024*1024||!imageSignature(entry.file,path.extname(entry.file).toLowerCase())))
        return new Response('이미지 파일을 확인하세요.',{status:415});
    }catch{return new Response('영상 파일이 이동되었거나 삭제되었습니다.',{status:404});}
    return fileVideoResponse(request,entry.file,entry.mime);
  }
  async function open(){
    checkRoot();const error=await openPath(folder);
    if(error)throw Error(error);
    return {success:true};
  }
  return {list,response,open};
}
module.exports={createIdleVideos};
