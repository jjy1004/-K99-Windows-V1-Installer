'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createKdeCliPath,createKdePathCache}=require('./services/kde-sms.cjs');
const pf='C:\\Program Files',local='C:\\Users\\가상사용자\\AppData\\Local';
function fixture(files=[],options={}){
  let saved=options.saved||'',writes=0,commands=[];
  const environment={ProgramFiles:pf,'ProgramFiles(x86)':'C:\\Program Files (x86)',LOCALAPPDATA:local};
  const discover=createKdeCliPath({environment,exists:f=>files.includes(f),readSaved:()=>saved,saveFound:f=>{saved=f;writes++;},
    listDirectory:()=>options.packages||[],run:async(file,args)=>{commands.push([file,args]);return {code:options.where?0:1,out:options.where||''};}});
  return {discover,commands,get saved(){return saved;},get writes(){return writes;}};
}
test('저장된 유효 CLI가 최우선이며 where·재저장을 하지 않는다',async()=>{
  const saved='D:\\설치 도구\\kdeconnect-cli.exe',f=fixture([saved,pf+'\\KDE Connect\\bin\\kdeconnect-cli.exe'],{saved});
  assert.equal(await f.discover(),saved);assert.equal(f.writes,0);assert.equal(f.commands.length,0);
});
test('표준 64비트→32비트→사용자 bin 순으로 찾아 자동 저장한다',async()=>{
  const paths=[pf+'\\KDE Connect\\bin\\kdeconnect-cli.exe','C:\\Program Files (x86)\\KDE Connect\\bin\\kdeconnect-cli.exe',
    local+'\\Programs\\KDE Connect\\bin\\kdeconnect-cli.exe'];
  for(let i=0;i<paths.length;i++){const f=fixture(paths.slice(i));assert.equal(await f.discover(),paths[i]);assert.equal(f.saved,paths[i]);}
});
test('WindowsApps 패키지 최신 버전과 사용자 실행 별칭은 where보다 먼저 찾는다',async()=>{
  const one='KDEe.V.KDEConnect_24.1.0_x64__test',two='KDEe.V.KDEConnect_25.1.0_x64__test';
  const file=pf+'\\WindowsApps\\'+two+'\\bin\\kdeconnect-cli.exe',alias=local+'\\Microsoft\\WindowsApps\\kdeconnect-cli.exe';
  const f=fixture([file,alias],{packages:[one,two]});assert.equal(await f.discover(),file);assert.equal(f.commands.length,0);
  const a=fixture([alias]);assert.equal(await a.discover(),alias);assert.equal(a.commands.length,0);
});
test('이전 경로가 사라지면 재탐색하고 where 결과 중 실제 CLI만 저장한다',async()=>{
  const next='D:\\새 버전\\kdeconnect-cli.exe',f=fixture([next],{saved:'C:\\옛 버전\\kdeconnect-cli.exe',
    where:'relative\\kdeconnect-cli.exe\r\nC:\\wrong.exe\r\n'+next+'\r\n'});
  assert.equal(await f.discover(),next);assert.equal(f.saved,next);assert.equal(f.writes,1);assert.equal(f.commands.length,1);
});
test('찾지 못하면 null이며 폴더 권한을 바꾸거나 문자를 보내지 않는다',async()=>{
  const f=fixture();assert.equal(await f.discover(),null);assert.equal(f.writes,0);
  assert.deepEqual(f.commands,[['where.exe',['kdeconnect-cli.exe']]]);
});
test('자동 저장은 내부 전용 파일에 영구 유지하며 일반 매장 설정을 건드리지 않는다',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-kde-cache-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  fs.writeFileSync(path.join(dir,'매장설정.json'),'원본 유지');
  createKdePathCache(dir).save('C:\\KDE Connect\\bin\\kdeconnect-cli.exe');
  assert.equal(createKdePathCache(dir).read(),'C:\\KDE Connect\\bin\\kdeconnect-cli.exe');
  assert.equal(fs.readFileSync(path.join(dir,'매장설정.json'),'utf8'),'원본 유지');
  assert.equal(fs.readdirSync(dir).filter(n=>n.endsWith('.tmp')).length,0);
});
test('새 실행에서도 저장 경로를 사용하고 업데이트로 삭제되면 새 경로를 영구 갱신한다',async t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-kde-upgrade-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const old='D:\\KDE 이전\\kdeconnect-cli.exe',next=pf+'\\KDE Connect\\bin\\kdeconnect-cli.exe';
  createKdePathCache(dir).save(old);
  const cache=createKdePathCache(dir);
  const discover=createKdeCliPath({environment:{ProgramFiles:pf},exists:p=>p===next,readSaved:cache.read,saveFound:cache.save,
    listDirectory:()=>[],run:async()=>{throw Error('표준 경로가 있으므로 where 호출 금지');}});
  assert.equal(await discover(),next);assert.equal(createKdePathCache(dir).read(),next);
});
test('WindowsApps 접근 거부에도 사용자 실행 별칭 탐색은 계속한다',async()=>{
  const alias=local+'\\Microsoft\\WindowsApps\\kdeconnect-cli.exe';
  const discover=createKdeCliPath({environment:{ProgramFiles:pf,LOCALAPPDATA:local},exists:p=>p===alias,
    listDirectory:()=>{throw Object.assign(Error('접근 거부'),{code:'EACCES'});},run:async()=>{throw Error('where 호출 금지');}});
  assert.equal(await discover(),alias);
});
