'use strict';
const path=require('node:path');
const os=require('node:os');
const {execFile}=require('node:child_process');
const CONSENT='Software\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\webcam';
const CAMERA_SETTINGS='ms-settings:privacy-webcam';

/** Read-only diagnostics: no consent writes, network probes or startup waits. */
function createCameraChecks({platform=process.platform,env=process.env,appExecutable=process.execPath,
  interfaces=()=>os.networkInterfaces(),now=()=>Date.now(),shell,
  execute=(file,args)=>new Promise((resolve,reject)=>execFile(file,args,
    {windowsHide:true,timeout:1800,maxBuffer:16384,shell:false},
    (error,stdout)=>error?reject(error):resolve(stdout))),
}={}){
  let pending=null,cached=null;
  const reg=path.win32.join(env.SystemRoot||'C:\\Windows','System32','reg.exe');
  const scopes=[
    ['HKCU\\'+CONSENT,'Value','사용자 카메라'],
    ['HKCU\\'+CONSENT+'\\NonPackaged','Value','데스크톱 앱'],
    ['HKLM\\'+CONSENT,'Value','PC 카메라'],
    ['HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppPrivacy','LetAppsAccessCamera','PC 관리 정책'],
    ...(platform==='win32'&&path.win32.isAbsolute(appExecutable)?
      [['HKCU\\'+CONSENT+'\\NonPackaged\\'+appExecutable.replace(/\\/g,'#'),'Value','이 프로그램']]:[]),
  ];
  function network(){
    try{
      const connected=Object.values(interfaces()).flat().some(row=>row&&!row.internal&&
        row.address&&!/^(?:127\.|169\.254\.|0\.0\.0\.0$|::1$|::$|fe80:)/i.test(row.address));
      return {state:connected?'connected':'offline',note:connected?
        'PC 네트워크가 연결되어 있어요. 휴대폰도 같은 매장 와이파이인지 확인해 주세요.':
        'PC 네트워크 연결을 확인해 주세요. USB 직접 연결은 네트워크 없이 작동할 수도 있어요.'};
    }catch{return {state:'unknown',note:'네트워크 상태를 확인하지 못했어요. 촬영 연결은 계속 시도합니다.'};}
  }
  async function inspect(){
    const rows=await Promise.all(scopes.map(async([key,name,label])=>{
      try{
        const text=await execute(reg,['query',key,'/v',name,'/reg:64']);
        const value=name==='Value'?/^\s*Value\s+REG_SZ\s+(Allow|Deny)\s*$/im.exec(text)?.[1]?.toLowerCase():
          /^\s*LetAppsAccessCamera\s+REG_DWORD\s+(0x[0-9a-f]+|\d+)\s*$/im.exec(text)?.[1];
        return {label,value:name==='Value'?value:value!==undefined?
          Number(value)===2?'deny':'allow':undefined};
      }catch{return {label,value:undefined};}
    }));
    const blocked=rows.filter(row=>row.value==='deny').map(row=>row.label);
    return {checkedAt:now(),permission:{state:blocked.length?'denied':
      rows.some(row=>row.value==='allow')?'not-denied':'unknown',blocked,
      checked:rows.filter(row=>row.value!==undefined).length},network:network()};
  }
  function status(){
    if(platform!=='win32')return Promise.resolve({checkedAt:now(),
      permission:{state:'unsupported',blocked:[],checked:0},network:network()});
    if(pending)return pending;
    if(cached&&now()-cached.checkedAt<5000)return Promise.resolve({...cached,network:network()});
    pending=inspect().then(value=>(cached=value)).finally(()=>{pending=null;});
    return pending;
  }
  async function openSettings(){
    if(platform!=='win32')throw Error('카메라 권한 설정은 Windows 매장 프로그램에서 열어 주세요.');
    try{await shell.openExternal(CAMERA_SETTINGS);cached=null;return {opened:true};}
    catch{throw Error('Windows 설정을 열지 못했어요. 시작 메뉴에서 카메라 개인정보 설정을 열어 주세요.');}
  }
  return {status,openSettings};
}
module.exports={createCameraChecks,CAMERA_SETTINGS};
