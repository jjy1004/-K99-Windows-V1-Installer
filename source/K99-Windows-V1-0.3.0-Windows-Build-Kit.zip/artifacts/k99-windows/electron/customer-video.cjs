'use strict';
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path');
const {Readable}=require('node:stream');
const VIDEO_FILES=Object.freeze({value:'value.mp4',process:'process.mp4',water:'water.mp4',sneakers:'sneakers.mp4'});
async function videoResponse(request,root) {
  const name=new URL(request.url).pathname.slice('/videos/'.length);
  if(name!=='promo.mp4'&&!Object.values(VIDEO_FILES).includes(name))return new Response('Unknown video',{status:404});
  // Never substitute an instructional clip when the idle asset is absent.
  const file=path.join(root,name);
  let stat;try{stat=await fsp.stat(file);}catch{return new Response('안내 MP4가 설치본에 없습니다.',{status:404});}
  if(!stat.isFile()||!stat.size)return new Response('Invalid video',{status:404});
  const headers={'Content-Type':'video/mp4','Accept-Ranges':'bytes','Cache-Control':'private, max-age=3600'};
  const range=request.headers.get('range');let start=0,end=stat.size-1,status=200;
  if(range){
    const m=/^bytes=(\d*)-(\d*)$/.exec(range);
    if(!m||(!m[1]&&!m[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${stat.size}`}});
    if(!m[1])start=Math.max(0,stat.size-Number(m[2]));
    else {start=Number(m[1]);if(m[2])end=Math.min(end,Number(m[2]));}
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>end||start>=stat.size)
      return new Response(null,{status:416,headers:{'Content-Range':`bytes */${stat.size}`}});
    status=206;headers['Content-Range']=`bytes ${start}-${end}/${stat.size}`;
  }
  headers['Content-Length']=String(end-start+1);
  if(request.method==='HEAD')return new Response(null,{status,headers});
  return new Response(Readable.toWeb(fs.createReadStream(file,{start,end})),{status,headers});
}
module.exports={videoResponse,VIDEO_FILES};
