'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createCareLabelController}=require('./care-label-controller.cjs');
const {createAutomaticTags}=require('./automatic-tag-controller.cjs');
const {createMobilePhotoController}=require('./mobile-photo-controller.cjs');
const JPEG=Buffer.concat([Buffer.from([255,216]),Buffer.alloc(100,42),Buffer.from([255,217])]);
const result={status:'success',materialTag:'PT20 면40 N40',error:'',
  basket:{no:'바구니 4',name:'유색 · 나일론 바구니',color:'#DD6B20'}};
function fixture(t,{classify=async()=>result,uncertain=false}={}){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-auto-tag-')),db=path.join(root,'k99.db'),attempts=[];
  const target={orderId:'automatic-tag-order-1',unitKey:'1:1',itemId:'shirt',itemName:'셔츠',customerName:'자동검증',customerPhone:'01000001234'};
  let f;
  function open(){
    const store=createStore(db,'test-only',{nativeDesktop:true});
    store.equipment.configure({mode:'real',printerName:'TSC TE210',labelWidthMm:60,labelHeightMm:40,
      labelVerified:true,cameraDeviceId:'test-camera',hardwareConfirmed:true},true);
    const active='k99-active-staff-intake-v1';
    if(!store.storage({op:'get',key:active}))store.storage({op:'set',key:active,expected:null,value:JSON.stringify({
      draftId:target.orderId,data:{customerName:target.customerName,customerPhone:target.customerPhone,
        rows:[{id:1,itemId:'shirt',quantity:2}]}})});
    const archive=createPhotoArchive({getRoot:()=>path.join(root,'test-D'),openPath:async()=>'',encodeJpeg:()=>JPEG});
    const adapters={native:true,archivePhoto:archive.photo,print:async job=>{
      attempts.push(job);
      if(uncertain)throw Object.assign(Error('인쇄 결과 미확인'),{submissionUncertain:true});
    }};
    const api=createEquipmentApi(store,adapters);
    let auto;
    const labels=createCareLabelController({store,equipmentApi:api,native:true,classify,onResult:r=>auto.onAnalysis(r)});
    auto=createAutomaticTags({store,equipmentApi:api,labels});
    Object.assign(adapters,{deferDraftTag:()=>true,beforeDraftCapture:auto.beforeCapture,afterDraftCapture:auto.afterCapture});
    const bridge=createMobilePhotoController({store,equipmentApi:api,archivePhoto:archive.photo,native:true,
      onMobileSaved:labels.onMobileSaved,nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:1,height:1})})},
      host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1']});
    adapters.archivePhoto=bridge.archivePhoto;
    f={store,api,labels,auto,bridge};
  }
  open();
  const close=()=>{f.labels.close();f.bridge.close();f.store.close();};
  t.after(()=>{close();fs.rmSync(root,{recursive:true,force:true});});
  return {target,attempts,get f(){return f;},
    capture:(unitKey,id)=>f.api.api('POST','/api/equipment/command',{...target,unitKey,
      action:'capture-draft',requestId:id,expectedMode:'real',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`}),
    async mobile(id){
      const s=await f.bridge.api('POST','/api/mobile-photo/start',target),u=new URL(s.urls[0]);
      const response=await fetch(`${u.origin}/api/upload-mobile-photo`,{method:'POST',headers:{'Content-Type':'image/jpeg',
        'X-K99-Session-Token':u.searchParams.get('token'),'X-K99-Upload-Id':id},body:JPEG});
      assert.equal(response.status,200);
      await f.bridge.api('POST','/api/mobile-photo/stop',{id:s.id});
    },
    reopen(){close();open();},
  };
}
test('no-label garment prints once with unclear material on next garment; final garment prints at finalize',async t=>{
  const x=fixture(t);
  await x.capture('1:1','first-pc-photo1');
  await x.capture('1:1','extra-pc-photo1');
  assert.equal(x.attempts.length,0);
  assert.equal(x.f.auto.state(x.target.orderId,'1:1').isTagPrinted,false);
  await x.capture('1:2','second-pc-photo1');
  assert.equal(x.attempts.length,1);assert.equal(x.attempts[0].payload.materialTag,'불명확');
  const ready=await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,2);assert.equal(ready.warnings.length,0);
  assert.ok(ready.units.every(u=>u.garment.isTagPrinted===true));
  assert.ok(ready.units.every(u=>u.garment.materialTag==='불명확'));
  await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,2);
});
test('label success automatically dispatches original pending job without a click or duplicate after more photos',async t=>{
  const x=fixture(t);
  await x.capture('1:1','overall-before-label');
  await x.mobile('label-mobile-photo1');
  await x.f.labels.settleForOrder(x.target.orderId);
  assert.equal(x.attempts.length,1);
  assert.equal(x.attempts[0].payload.materialTag,'PT20 면40 N40');
  assert.equal(x.f.auto.state(x.target.orderId,'1:1').isTagPrinted,true);
  await x.mobile('label-mobile-photo2');
  await x.f.labels.settleForOrder(x.target.orderId);
  await x.capture('1:1','extra-after-label');
  await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,1);
  assert.equal(x.f.store.equipment.drafts.state(x.target.orderId).units[0].garment.photoHistory.length,4);
});
test('AI failure dispatches general material, preserves photos, and never auto retries an already submitted tag',async t=>{
  const x=fixture(t,{classify:async()=>{throw Error('API unavailable');}});
  await x.mobile('failed-label-photo1');
  await x.f.labels.settleForOrder(x.target.orderId);
  assert.equal(x.attempts.length,1);assert.equal(x.attempts[0].payload.materialTag,'일반');
  assert.equal(x.f.labels.list()[0].status,'failed');
  await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,1);
});
test('next camera capture does not wait on pending AI or print unclear prematurely; finalize waits before synchronous order commit',async t=>{
  let finish;
  const x=fixture(t,{classify:()=>new Promise(resolve=>{finish=resolve;})});
  await x.mobile('pending-label-photo1');
  await x.capture('1:2','next-during-analysis');
  assert.equal(x.attempts.length,0);
  const before=x.f.store.equipment.drafts.state(x.target.orderId);
  const order={id:x.target.orderId,customerName:x.target.customerName,customerPhone:x.target.customerPhone,customerAddress:'',
    createdAt:new Date().toISOString(),items:[{displayNameKo:'셔츠',quantity:2}],estimatedTotal:6000,laundryTotal:6000,
    garments:before.units.map((u,i)=>({...u.garment,sequence:i+1,itemIndex:1,unitIndex:i+1,totalSequence:2}))};
  const input={op:'set',key:'k99-confirmed-orders-v1',expected:null,value:JSON.stringify([order])};
  assert.throws(()=>x.f.auto.assertReadyForOrders(input),/자동 발행 준비/);
  let done=false;const ready=x.f.auto.finalize(x.target.orderId).then(r=>{done=true;return r;});
  await new Promise(resolve=>setImmediate(resolve));assert.equal(done,false);
  finish(result);
  const finalized=await ready;
  assert.equal(x.attempts.length,2);assert.equal(x.attempts[0].payload.materialTag,result.materialTag);
  order.garments=finalized.units.map((u,i)=>({...u.garment,sequence:i+1,itemIndex:1,unitIndex:i+1,totalSequence:2}));
  input.value=JSON.stringify([order]);
  x.f.auto.assertReadyForOrders(input);x.f.store.storage(input);
  assert.equal(x.f.store.status().orderCount,1);
  assert.equal(x.f.store.equipment.getOrder(x.target.orderId).garments[0].isTagPrinted,true);
});
test('restart remembers submitted job and does not duplicate printing',async t=>{
  const x=fixture(t);
  await x.capture('1:1','restart-overall-1');
  await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,1);
  x.reopen();
  assert.equal(x.f.auto.state(x.target.orderId,'1:1').isTagPrinted,true);
  await x.f.auto.finalize(x.target.orderId);
  await x.f.auto.onAnalysis({...result,orderId:x.target.orderId,unitKey:'1:1'});
  assert.equal(x.attempts.length,1);
});
test('uncertain physical result never sets printed true or blindly resubmits, including after restart',async t=>{
  const x=fixture(t,{uncertain:true});
  await x.capture('1:1','uncertain-overall-1');
  let ready=await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,1);assert.equal(ready.units[0].garment.isTagPrinted,false);
  assert.equal(ready.units[0].garment.autoTagStatus,'unknown');assert.equal(ready.warnings.length,1);
  x.reopen();ready=await x.f.auto.finalize(x.target.orderId);
  assert.equal(x.attempts.length,1);assert.equal(ready.warnings.length,1);
});
