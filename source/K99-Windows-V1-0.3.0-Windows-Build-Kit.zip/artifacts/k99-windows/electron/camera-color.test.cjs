'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {createRequire}=require('node:module'),req=createRequire(path.join(__dirname,'../package.json')),ts=req('typescript');
const cache={};
function load(name){
  if(cache[name])return cache[name];
  const module={exports:{}},file=path.join(__dirname,'../src',name+'.ts');
  new Function('require','exports','module',ts.transpileModule(fs.readFileSync(file,'utf8'),{
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(
      id=>id.startsWith('./')?load(id.slice(2)):req(id),module.exports,module);
  return cache[name]=module.exports;
}
const color=load('camera-color'),chart=load('camera-color-chart');
function frame(rgb=[205,190,178],w=400,h=300){
  const data=new Uint8ClampedArray(w*h*4);for(let i=0;i<data.length;i+=4)data.set([...rgb,255],i);
  return {width:w,height:h,data};
}
test('default profile has requested brightness/gamma/saturation/contrast; alpha and dark details survive',()=>{
  const p=color.DEFAULT_CAMERA_COLOR;
  assert.deepEqual([p.brightness,p.gamma,p.saturation,p.contrast],[1.12,1.12,.92,1.05]);
  const pixels=new Uint8ClampedArray([0,0,0,125,255,255,255,255,80,100,120,255]);
  color.makeColorTransform(p)(pixels);
  assert.equal(pixels[3],125);assert.deepEqual([...pixels.slice(4,7)],[248,248,248]);
  assert.ok(pixels[8]>0&&pixels[8]<pixels[10]);
});
test('border white balance maps neutral background to RGB 248 without sampling center garment',()=>{
  const f=frame();
  for(let y=60;y<240;y++)for(let x=80;x<320;x++)f.data.set([90,0,0,255],(y*f.width+x)*4);
  const p=color.calibrateWhiteFrame(f);
  const pixel=new Uint8ClampedArray([205,190,178,255]);color.makeColorTransform(p)(pixel);
  for(const value of pixel.slice(0,3))assert.ok(Math.abs(value-248)<=1);
  assert.equal(color.validColorProfile(p),true);
  const fabric=new Uint8ClampedArray([205,190,178,255,220,206,193,255,245,230,216,255]);
  color.makeColorTransform(p)(fabric);
  assert.ok(fabric[0]<fabric[4]&&fabric[4]<=fabric[8],'highlight texture must not be hard clipped to one value');
});
test('covered/colorful/dark or uneven borders fail without inventing a calibration',()=>{
  assert.throws(()=>color.calibrateWhiteFrame(frame([10,10,10])),/흰 바탕/);
  assert.throws(()=>color.calibrateWhiteFrame(frame([250,20,20])),/흰 바탕/);
  const f=frame([220,220,220]);for(let y=0;y<25;y++)for(let x=0;x<f.width;x++)f.data.set([80,80,80,255],(y*f.width+x)*4);
  assert.throws(()=>color.calibrateWhiteFrame(f),/그림자/);
});
test('profile persists in real temporary SQLite and restores only for the same camera after reopen',t=>{
  const {createStore}=require('../../../lib/k99-local/index.cjs');
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'k99-camera-color-')),db=path.join(directory,'k99.db');
  let store=createStore(db,'test-only',{nativeDesktop:true});
  t.after(()=>{store.close();fs.rmSync(directory,{recursive:true,force:true});});
  const storage={getItem:key=>store.storage({op:'get',key}),setItem:(key,value)=>store.storage({
    op:'set',key,value,expected:store.storage({op:'get',key})})};
  const p={...color.calibrateWhiteFrame(frame()),brightnessAdjustment:12,temperatureAdjustment:10,contrastAdjustment:8};
  color.saveCameraColor('physical-usb-camera',p,storage);store.close();store=createStore(db,'test-only',{nativeDesktop:true});
  assert.deepEqual(color.loadCameraColor('physical-usb-camera',storage),p);
  assert.equal(color.loadCameraColor('obs-camera',storage).calibratedAt,null);
  assert.throws(()=>color.saveCameraColor('camera',{...p,gains:[NaN,1,1]},storage),/올바르지/);
});
test('classic 24-patch chart fits bounded color matrix and rejects a blank non-chart',()=>{
  const f=frame([220,220,220]),g=chart.CHART_GUIDE;
  chart.CLASSIC_24_RGB.forEach((rgb,index)=>{
    const col=index%6,row=Math.floor(index/6);
    for(let y=Math.floor(f.height*(g.y+g.height*row/4));y<Math.ceil(f.height*(g.y+g.height*(row+1)/4));y++)
      for(let x=Math.floor(f.width*(g.x+g.width*col/6));x<Math.ceil(f.width*(g.x+g.width*(col+1)/6));x++)
        f.data.set([...rgb,255],(y*f.width+x)*4);
  });
  const profile=chart.calibrateClassic24(f,color.calibrateWhiteFrame(f));
  assert.equal(color.validColorProfile(profile),true);assert.equal(profile.chartMatrix.length,3);
  assert.throws(()=>chart.calibrateClassic24(frame(),color.DEFAULT_CAMERA_COLOR),/24색/);
});
test('automatic white correction uses raw borders without a click, retains adjustments, and limits later gain changes',()=>{
  const settings={...color.DEFAULT_CAMERA_COLOR,brightnessAdjustment:10,temperatureAdjustment:8,contrastAdjustment:7};
  const first=color.automaticWhiteProfile(frame(),settings,settings,true);
  assert.equal(first.brightnessAdjustment,10);assert.equal(first.temperatureAdjustment,8);
  assert.equal(first.contrastAdjustment,7);
  const next=color.automaticWhiteProfile(frame([160,170,180]),first,settings);
  first.gains.forEach((g,i)=>assert.ok(Math.abs(g-next.gains[i])<=.020001));
  assert.throws(()=>color.automaticWhiteProfile(frame([10,10,10]),first,settings),/흰 바탕/);
});
test('brightness and temperature sliders are bounded, software-only and independently change output pixels',()=>{
  const apply=p=>{const data=new Uint8ClampedArray([100,100,100,255]);color.makeColorTransform(p)(data);return data;};
  const base=apply(color.DEFAULT_CAMERA_COLOR);
  const light=apply({...color.DEFAULT_CAMERA_COLOR,brightnessAdjustment:20});
  const warm=apply({...color.DEFAULT_CAMERA_COLOR,temperatureAdjustment:40});
  assert.ok(light[0]>base[0]);assert.ok(warm[0]>warm[2]);
  assert.equal(color.validColorProfile({...color.DEFAULT_CAMERA_COLOR,temperatureAdjustment:51}),false);
  const dark=new Uint8ClampedArray([30,30,30,255]);
  const normal=new Uint8ClampedArray(dark);
  color.makeColorTransform(color.DEFAULT_CAMERA_COLOR)(normal);
  color.makeColorTransform({...color.DEFAULT_CAMERA_COLOR,contrastAdjustment:30})(dark);
  assert.ok(dark[0]<normal[0]);
  assert.equal(color.validColorProfile({...color.DEFAULT_CAMERA_COLOR,contrastAdjustment:31}),false);
});
test('both saved-photo paths apply the same transform before JPEG serialization; camera preview is corrected too',()=>{
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const source=fs.readFileSync(path.join(__dirname,'../src',name),'utf8');
    assert.ok(source.includes('correctCameraCanvas('));
    assert.ok(source.indexOf('correctCameraCanvas(')<source.lastIndexOf("toDataURL('image/jpeg'"));
    assert.ok(source.includes('useCameraColorPreview('));
    assert.ok(source.includes('.effective.current'));
    assert.ok(source.includes('<CameraColorSliders'));
  }
  const stage=fs.readFileSync(path.join(__dirname,'../../../scripts/stage-windows-app.cjs'),'utf8');
  assert.ok(stage.includes('electron/obs-automation.cjs'));
});
test('live preview and saved canvas share exactly the same current software coefficients',()=>{
  const effects=[],state=[],raw=frame(),video={current:{videoWidth:raw.width,videoHeight:raw.height,readyState:2}};
  let nextFrame,previewBytes,cancelled=false;
  const exports={};
  new Function('require','exports','requestAnimationFrame','cancelAnimationFrame',ts.transpileModule(
    fs.readFileSync(path.join(__dirname,'../src/use-camera-color-preview.ts'),'utf8'),{
      compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(
      id=>id==='react'?{useEffect:f=>effects.push(f),useRef:v=>({current:v}),useState:v=>[v,n=>state.push(n)]}:color,
      exports,f=>{nextFrame=f;return 1;},()=>{cancelled=true;});
  const hook=exports.useCameraColorPreview(video,true,color.DEFAULT_CAMERA_COLOR);
  hook.canvas.current={width:0,height:0,getContext:()=>({drawImage(){},
    getImageData:()=>({...raw,data:new Uint8ClampedArray(raw.data)}),putImageData:image=>{previewBytes=image.data;}})};
  const cleanup=effects[0]();nextFrame(1200);
  assert.ok(state.includes(true),'corrected overlay becomes visible only after drawing pixels');
  const saved={...raw,data:new Uint8ClampedArray(raw.data)};
  color.correctCameraCanvas({canvas:raw,getImageData:()=>saved,putImageData(){}},hook.effective.current);
  assert.deepEqual(saved.data,previewBytes);
  hook.canvas.current.getContext=()=>({drawImage(){},getImageData(){throw Error('canvas unavailable');}});
  nextFrame(2400);assert.ok(state.some(s=>/기본 카메라/.test(s)));
  cleanup();assert.equal(cancelled,true);
});
