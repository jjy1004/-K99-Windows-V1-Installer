'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {createRequire}=require('node:module'),req=createRequire(path.join(__dirname,'../package.json')),ts=req('typescript');
const src=name=>fs.readFileSync(path.join(__dirname,'../src',name),'utf8');
const exportsObject={};
new Function('exports',ts.transpileModule(src('camera-color.ts'),{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(exportsObject);
const c=exportsObject,standard=c.DEFAULT_CAMERA_COLOR;
const frame=(values,w=values.length/4)=>({width:w,height:values.length/4/w,data:new Uint8ClampedArray(values)});
const apply=(p,values,w)=>{const f=frame(values,w);c.makeColorTransform({...standard,...p})(f);return [...f.data];};
test('standard is neutral: all 256 channel values and alpha survive byte-for-byte',()=>{
  assert.equal(standard.version,2);
  for(const key of ['brightness','contrast','temperature','saturation','sharpness'])assert.equal(standard[key],0);
  const values=Array.from({length:256},(_,v)=>[v,255-v,v,v]).flat();
  assert.deepEqual(apply({},values),values);
  assert.deepEqual(c.CAMERA_RESOLUTIONS,{HD:[1280,720],FHD:[1920,1080],'2K':[2560,1440]});
});
test('neutral capture does not read or rewrite a canvas',()=>{
  c.correctCameraCanvas({getImageData(){throw Error('unnecessary pixel read');}},standard);
});
for(const key of ['brightness','contrast','temperature','saturation','sharpness']){
  test(`${key} supports fine one-step adjustments within valid bounds`,()=>{
    const max=key==='sharpness'?100:50,min=key==='sharpness'?0:-50;
    for(let value=min;value<=max;value++)assert.equal(c.validColorProfile({...standard,[key]:value}),true);
    assert.equal(c.validColorProfile({...standard,[key]:max+1}),false);
    assert.equal(c.validColorProfile({...standard,[key]:NaN}),false);
  });
}
test('brightness changes all channels without changing alpha',()=>{
  const input=[70,100,130,97],bright=apply({brightness:20},input),dark=apply({brightness:-20},input);
  for(let i=0;i<3;i++){assert.ok(bright[i]>input[i]);assert.ok(dark[i]<input[i]);}
  assert.equal(bright[3],97);
});
test('contrast increases separation around mid-grey',()=>{
  const out=apply({contrast:25},[60,60,60,255,190,190,190,255]);
  assert.ok(out[0]<60);assert.ok(out[4]>190);
});
test('manual warm/cool control changes red and blue in opposite directions',()=>{
  const warm=apply({temperature:25},[120,120,120,255]),cool=apply({temperature:-25},[120,120,120,255]);
  assert.ok(warm[0]>warm[2]);assert.ok(cool[0]<cool[2]);assert.equal(warm[1],120);
});
test('saturation can increase or reduce colour distance',()=>{
  const input=[170,80,50,255],high=apply({saturation:30},input),low=apply({saturation:-30},input);
  assert.ok(high[0]-high[2]>120);assert.ok(low[0]-low[2]<120);
});
test('sharpness enhances a local edge but preserves a constant field and alpha',()=>{
  const values=[80,80,80,25,120,120,120,35,80,80,80,45];
  const out=apply({sharpness:70},values,3);
  assert.ok(out[4]>120);assert.ok(out[0]<80);assert.equal(out[7],35);
  const flat=[90,90,90,155,90,90,90,155,90,90,90,155];
  assert.deepEqual(apply({sharpness:100},flat,3),flat);
});
test('preview and full-resolution capture use the exact same pixel transform',()=>{
  const p={...standard,brightness:8,contrast:10,temperature:-5,saturation:12,sharpness:20};
  const original=frame([80,100,120,255,200,170,120,255],2),expected=frame([...original.data],2);
  c.makeColorTransform(p)(expected);
  let written;
  c.correctCameraCanvas({canvas:{width:2,height:1},getImageData:()=>original,putImageData:f=>{written=f;}},p);
  assert.deepEqual(written.data,expected.data);
  assert.match(src('use-camera-color-preview.ts'),/makeColorTransform\(profile\)/);
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx'])assert.match(src(name),/correctCameraCanvas\(g,appearance\.profile\)/);
});
test('invalid pixels and profiles fail explicitly instead of inventing a correction',()=>{
  assert.throws(()=>c.makeColorTransform({...standard,version:1}),/범위/);
  assert.throws(()=>c.makeColorTransform(standard)({width:2,height:2,data:new Uint8ClampedArray(4)}),/픽셀/);
});
test('manual settings persist through a real temporary SQLite close and reopen',t=>{
  const {createStore}=require('../../../lib/k99-local/index.cjs');
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'k99-manual-colour-')),db=path.join(directory,'k99.db');
  let store=createStore(db,'test-only',{nativeDesktop:true});
  t.after(()=>{store.close();fs.rmSync(directory,{recursive:true,force:true});});
  const storage={getItem:key=>store.storage({op:'get',key}),setItem:(key,value)=>store.storage({
    op:'set',key,value,expected:store.storage({op:'get',key})})};
  const p={...standard,resolution:'2K',brightness:12,contrast:7,temperature:-8,saturation:11,sharpness:33};
  c.saveCameraColor('physical-usb-camera',p,storage);store.close();store=createStore(db,'test-only',{nativeDesktop:true});
  assert.deepEqual(c.loadCameraColor('physical-usb-camera',storage),p);
  assert.deepEqual(c.loadCameraColor('other-camera',storage),standard);
  c.saveCameraColor('physical-usb-camera',{...standard},storage);
  assert.deepEqual(c.loadCameraColor('physical-usb-camera',storage),standard);
});
test('old automatic profiles are not carried into the new neutral manual mode',()=>{
  const values=new Map([['k99-camera-color-profiles-v1',JSON.stringify({usb:{version:1,brightness:1.12,gamma:1.12}})]]);
  const storage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v)};
  assert.deepEqual(c.loadCameraColor('usb',storage),standard);
  c.saveCameraColor('__proto__',{...standard,brightness:1},storage);
  assert.equal(c.loadCameraColor('__proto__',storage).brightness,1);
  assert.equal(values.has('k99-camera-color-profiles-v1'),true,'old settings are not destructively deleted');
});
test('corrupt optional settings do not block startup, and a failed write is reported',()=>{
  assert.deepEqual(c.loadCameraColor('usb',{getItem:()=>'{bad'}),standard);
  assert.throws(()=>c.saveCameraColor('usb',standard,{getItem:()=>null,setItem(){throw Error('disk full');}}),/disk full/);
});
test('all six controls, minus/plus buttons and standard restore are wired in both camera screens',()=>{
  const ui=src('CameraColorSliders.tsx');
  for(const key of ['brightness','contrast','temperature','saturation','sharpness'])assert.ok(ui.includes(`key:'${key}'`));
  assert.match(ui,/onClick=\{onReset\}/);assert.match(ui,/onResolution\(name as CameraResolution\)/);
  assert.match(ui,/set\(value-1\)/);assert.match(ui,/set\(value\+1\)/);
  assert.match(ui,/onChange=\{e=>set\(Number\(e.target.value\)\)\}/);
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx'])assert.match(src(name),/<CameraColorSliders \{\.\.\.appearance\}/);
});
