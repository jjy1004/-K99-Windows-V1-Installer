'use strict';
const fs = require('node:fs'), path = require('node:path');
const {fileVideoResponse, VIDEO_FILES} = require('./customer-video.cjs');
const DEFAULTS = [
  ['value', '세탁 가격 안내'], ['process', '세탁 안내'],
  ['water', '드라이세탁 안내'], ['sneakers', '프리미엄 운동화'],
];

function assertDirectory(folder) {
  const stat = fs.lstatSync(folder);
  if (!stat.isDirectory() || stat.isSymbolicLink() || fs.realpathSync(folder) !== path.resolve(folder))
    throw Error('영상 폴더의 링크·정션은 허용하지 않습니다.');
}
// Bounded header reads; never load a shop's whole video into main-process RAM.
function inspectMp4(file) {
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || fs.realpathSync(file) !== path.resolve(file) || !stat.size)
    throw Error('비어 있거나 허용되지 않은 파일입니다.');
  const fd = fs.openSync(file, 'r'), found = new Set();
  try {
    let offset = 0, boxes = 0;
    while (offset < stat.size) {
      if (++boxes > 10000) throw Error('MP4 구획이 너무 많습니다.');
      const header = Buffer.alloc(16);
      const read = fs.readSync(fd, header, 0, Math.min(16, stat.size - offset), offset);
      if (read < 8) throw Error('MP4 파일이 잘렸습니다.');
      let size = header.readUInt32BE(0), headerSize = 8;
      const type = header.toString('ascii', 4, 8);
      if (size === 1) {
        if (read < 16) throw Error('MP4 헤더가 잘렸습니다.');
        const wide = header.readBigUInt64BE(8);
        if (wide > BigInt(Number.MAX_SAFE_INTEGER)) throw Error('MP4 크기가 잘못되었습니다.');
        size = Number(wide); headerSize = 16;
      } else if (size === 0) size = stat.size - offset;
      if (size < headerSize || offset + size > stat.size) throw Error('MP4 구획 크기가 잘못되었습니다.');
      if (['ftyp','moov','mdat'].includes(type) && size <= headerSize) throw Error('MP4 필수 구획이 비어 있습니다.');
      if (type === 'moov' && !hasVideoTrack(fd, offset + headerSize, offset + size))
        throw Error('MP4 영상 트랙을 확인할 수 없습니다.');
      found.add(type); offset += size;
    }
    if (!['ftyp', 'moov', 'mdat'].every(key => found.has(key)))
      throw Error('MP4 필수 구획이 없습니다.');
  } finally { fs.closeSync(fd); }
  return stat;
}

function hasVideoTrack(fd, start, end, level = 0) {
  let video = false, count = 0;
  for (let offset = start; offset < end;) {
    if (++count > 10000 || end - offset < 8) throw Error('MP4 영상 정보가 잘렸습니다.');
    const bytes = Buffer.alloc(16), read = fs.readSync(fd, bytes, 0, Math.min(16, end - offset), offset);
    let size = bytes.readUInt32BE(0), head = 8;
    if (size === 1) {
      if (read < 16 || bytes.readBigUInt64BE(8) > BigInt(Number.MAX_SAFE_INTEGER)) throw Error('MP4 영상 정보가 잘못되었습니다.');
      size = Number(bytes.readBigUInt64BE(8)); head = 16;
    } else if (!size) size = end - offset;
    if (size < head || offset + size > end) throw Error('MP4 영상 정보 크기가 잘못되었습니다.');
    const type = bytes.toString('ascii', 4, 8);
    if (type === ['trak','mdia'][level] && level < 2)
      video = hasVideoTrack(fd, offset + head, offset + size, level + 1) || video;
    if (level === 2 && type === 'hdlr') {
      const handler = Buffer.alloc(4);
      if (size < head + 12 || fs.readSync(fd, handler, 0, 4, offset + head + 8) !== 4)
        throw Error('MP4 트랙 정보가 잘렸습니다.');
      video = handler.toString('ascii') === 'vide' || video;
    }
    offset += size;
  }
  return video;
}

function createGuideVideos({parent, openPath, defaultRoot}) {
  const folder = parent && path.join(parent, '개별 안내 영상');
  let selected = new Map();
  function root() {
    if (!parent) throw Error('영상 파일 관리는 Windows 설치 프로그램에서 사용할 수 있습니다.');
    assertDirectory(parent);
    if (!fs.existsSync(folder)) fs.mkdirSync(folder);
    assertDirectory(folder);
  }
  function list() {
    root();
    const names = fs.readdirSync(folder), errors = [], next = new Map();
    for (const name of names) {
      if (!/^(0[1-4])_(.+)\.mp4$/i.test(name)) {
        errors.push(`${name}: 파일명은 01_제목.mp4 ~ 04_제목.mp4로 지정하세요.`);
      }
    }
    const slots = DEFAULTS.map(([video, defaultTitle], index) => {
      const number = index + 1;
      const candidates = names.filter(name => new RegExp(`^0${number}_(.+)\\.mp4$`, 'i').test(name));
      let entry, error;
      if (candidates.length > 1) error = `${number}번 파일이 중복되었습니다. 하나만 남겨 주세요.`;
      else if (candidates.length === 1) {
        const name = candidates[0], title = name.slice(3, -4).trim();
        try {
          if (!title) throw Error('제목이 비어 있습니다.');
          inspectMp4(path.join(folder, name));
          entry = {file:path.join(folder, name), name, title};
          next.set(video, entry);
        } catch (e) { error = `${name}: ${e.message}`; }
      }
      let defaultAvailable;
      if (!entry && defaultRoot) {
        try { inspectMp4(path.join(defaultRoot, VIDEO_FILES[video])); defaultAvailable = true; }
        catch { defaultAvailable = false; error = [error, '설치된 기본 영상도 확인하지 못했습니다.'].filter(Boolean).join(' '); }
      }
      if (error) errors.push(error);
      return {number, video, title:entry?.title || defaultTitle, source:entry ? 'custom' : 'default',
        name:entry?.name || VIDEO_FILES[video], error, defaultAvailable};
    });
    selected = next;
    return {success:errors.length === 0, slots, errors};
  }
  async function open() {
    root();
    const error = await openPath(folder);
    if (error) throw Error(error);
    return {success:true};
  }
  async function response(request) {
    const name = new URL(request.url).pathname.slice('/videos/'.length);
    const video = Object.keys(VIDEO_FILES).find(key => VIDEO_FILES[key] === name);
    const entry = selected.get(video);
    if (!entry) return null;
    try { root(); inspectMp4(entry.file); }
    catch (error) { return new Response(`사용자 안내 영상을 확인하세요: ${error.message}`, {status:415}); }
    return fileVideoResponse(request, entry.file);
  }
  // Read actual files on startup. A missing Windows folder is reported by list,
  // not turned into an app-start failure or an implicit change of storage root.
  try { list(); } catch { /* Settings reports the concrete error on request. */ }
  return {list, open, response};
}
module.exports = {createGuideVideos, inspectMp4};
