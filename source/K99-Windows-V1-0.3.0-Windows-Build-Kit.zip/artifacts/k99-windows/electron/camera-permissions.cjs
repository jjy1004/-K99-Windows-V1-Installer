'use strict';
function internalCameraPermission({webContents,mainWindow,permission,details={},origin}){
  if(permission!=='media'||!webContents||webContents!==mainWindow?.webContents||details.isMainFrame===false)return false;
  const internal=value=>{try{const u=new URL(value);return u.protocol==='k99:'&&u.hostname==='app';}catch{return false;}};
  try{
    if(!internal(webContents.getURL()))return false;
    for(const value of [origin,details.requestingUrl,details.securityOrigin])
      if(value&&!internal(value))return false;
    return true;
  }catch{return false;}
}
module.exports={internalCameraPermission};
