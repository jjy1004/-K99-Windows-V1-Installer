'use strict';
function internalCameraPermission({webContents,mainWindow,permission,details={},origin}){
  if(permission!=='media'||!webContents||webContents!==mainWindow?.webContents)return false;
  const internal=value=>{try{const u=new URL(value);return u.protocol==='k99:'&&u.hostname==='app';}catch{return false;}};
  try{
    if(!internal(webContents.getURL()))return false;
    for(const value of [origin,details.requestingUrl,details.securityOrigin])
      if(value&&!internal(value))return false;
    if(details.isMainFrame===false){
      const frame=new URL(details.requestingUrl);
      if(frame.pathname!=='/camera-context.html'||frame.search||frame.hash)return false;
      if(details.mediaTypes?.some(type=>type!=='video')||details.mediaType==='audio')return false;
    }
    return true;
  }catch{return false;}
}
module.exports={internalCameraPermission};
