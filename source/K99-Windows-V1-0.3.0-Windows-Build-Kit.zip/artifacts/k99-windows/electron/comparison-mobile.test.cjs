'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
const {createPhotoArchive}=require('./photo-archive.cjs');
const {createComparisonMobilePhotos}=require('./comparison-mobile-photo.cjs');
const {createMobilePhotoBridge}=require('./mobile-photo-bridge.cjs');
const PNG=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jVioAAAAASUVORK5CYII=','base64');
// Image decoder is a test double. Archive, HTTP, SQLite and request validation are real.
const JPEG=Buffer.concat([Buffer.from([255,216,255]),Buffer.alloc(40),Buffer.from([255,217])]);
async function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-comparison-mobile-'));
  const file=path.join(root,'data/k99.db');
  const store=createStore(file,'test',{nativeDesktop:true,archiveRoot:path.join(root,'archive')});
  store.storage({op:'set',key:'k99-confirmed-orders-v1',expected:null,value:JSON.stringify([{
    id:'comparison-order',customerName:'시험고객',customerPhone:'01000001234',createdAt:'2026-11-01T01:00:00Z',
    estimatedTotal:5000,choices:{},items:[{displayNameKo:'코트',quantity:1}],
    garments:[{orderId:'comparison-order',garmentId:'comparison-g1',itemName:'코트',barcodeValue:'comparison-g1',
      tagStatus:'not-generated',photoStatus:'not-captured',serviceType:'general'}]}])});
  const archive=createPhotoArchive({getRoot:()=>path.join(root,'archive'),openPath:async()=>'',encodeJpeg:()=>JPEG});
  const api=createEquipmentApi(store,{native:true,archivePhoto:archive.photo,archiveComparison:archive.comparison});
  const controller=createComparisonMobilePhotos({store,equipmentApi:api,native:true,port:0,host:'127.0.0.1',
    addresses:()=>['127.0.0.1'],nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:1,height:1})})}});
  t.after(()=>{controller.close();store.close();fs.rmSync(root,{recursive:true,force:true});});
  const session=await controller.api('POST','/api/comparison-mobile/start',{orderId:'comparison-order',garmentId:'comparison-g1'});
  const u=new URL(session.urls[0]);
  const upload=id=>fetch(u.origin+'/api/upload-mobile-photo',{method:'POST',headers:{
    'Content-Type':'image/png','X-K99-Session-Token':u.searchParams.get('token'),'X-K99-Upload-Id':id},body:PNG});
  return {root,file,store,api,controller,session,upload};
}
test('After QR uploads persist in original SQLite and comparison archive without issuing tags',async t=>{
  const f=await fixture(t);
  for(const id of ['after-photo-0001','after-photo-0002']){
    const r=await f.upload(id);assert.equal(r.status,200,await r.text());
  }
  const status=await f.controller.api('GET',`/api/comparison-mobile/status?id=${f.session.id}`);
  assert.equal(status.uploadedCount,2);
  assert.equal(status.lastResult.photo.role,'completion');
  assert.equal(status.lastResult.photo.orderId,'comparison-order');
  assert.equal(status.lastResult.photo.garmentId,'comparison-g1');
  assert.match(status.lastResult.photo.url,/^\/api\/equipment\/photos\//);
  assert.match(status.lastResult.archive.folder,/02_세탁전후사진/);
  assert.ok(fs.existsSync(path.join(status.lastResult.archive.folder,status.lastResult.archive.fileName)));
  assert.equal(f.store.equipment.state().jobs.length,0);
  const readOnly=require('../../../lib/k99-local/node_modules/better-sqlite3')(f.file,{readonly:true});
  try{assert.equal(readOnly.prepare('SELECT COUNT(*) AS n FROM equipment_photos').get().n,2);}
  finally{readOnly.close();}
});
test('After QR retry is idempotent and wrong garment / revoked token are rejected',async t=>{
  const f=await fixture(t);
  assert.equal((await f.upload('after-repeat-0001')).status,200);
  assert.equal((await f.upload('after-repeat-0001')).status,200);
  assert.equal(f.store.equipment.state().photos.length,1);
  await assert.rejects(()=>f.controller.api('POST','/api/comparison-mobile/start',{
    orderId:'comparison-order',garmentId:'another-garment'}),/의류/);
  await f.controller.api('POST','/api/comparison-mobile/start',{orderId:'comparison-order',garmentId:'comparison-g1'});
  assert.equal((await f.upload('after-revoked-0001')).status,410);
});
test('Photo folder open resolves the order-owned intake directory, never a renderer path',async t=>{
  const f=await fixture(t);let opened;
  const api=createEquipmentApi(f.store,{native:true,openPhotoFolder:async(order,kind)=>{opened={order,kind};return {opened:true};}});
  assert.deepEqual(await api.api('POST','/api/equipment/command',{
    action:'open-photo-folder',orderId:'comparison-order',kind:'intake',path:'C:\\Windows'}),{opened:true});
  assert.equal(opened.order.id,'comparison-order');assert.equal(opened.kind,'intake');
  await assert.rejects(()=>api.api('POST','/api/equipment/command',{
    action:'open-photo-folder',orderId:'not-an-order',kind:'intake'}));
});
test('Concurrent uploads keep the latest requested successful photo even if older upload completes last',async t=>{
  let releaseFirst;
  const first=new Promise(resolve=>{releaseFirst=resolve;});
  const bridge=createMobilePhotoBridge({host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1'],
    validateTarget:()=>({orderId:'order',customerName:'시험',phoneLast4:'1234'}),
    capture:async input=>{
      if(input.requestId==='concurrent-old')await first;
      return {photo:{id:input.requestId},archive:{fileName:input.requestId+'.jpg'}};
    }});
  t.after(()=>bridge.close());
  const s=await bridge.api('POST','/api/mobile-photo/start',{}),u=new URL(s.urls[0]);
  const post=id=>fetch(u.origin+'/api/upload-mobile-photo',{method:'POST',headers:{
    'Content-Type':'image/png','X-K99-Session-Token':u.searchParams.get('token'),'X-K99-Upload-Id':id},body:PNG});
  const old=post('concurrent-old');
  await new Promise(resolve=>setTimeout(resolve,30));
  assert.equal((await post('concurrent-new')).status,200);
  releaseFirst();assert.equal((await old).status,200);
  const status=await bridge.api('GET',`/api/mobile-photo/status?id=${s.id}`);
  assert.equal(status.lastResult.photo.id,'concurrent-new');
});
