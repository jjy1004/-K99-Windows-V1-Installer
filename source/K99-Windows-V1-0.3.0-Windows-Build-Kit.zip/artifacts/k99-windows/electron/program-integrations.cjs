'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {AI_PARTITION}=require('./ai-session.cjs');
const SETTINGS_KEY='k99-program-integrations-v1';
const DEFAULT_PRESCRIPTION_URL='https://k-99-washcare-ai.replit.app';
const DEFAULT_LUXURY_URL='https://k-99-luxury-laundry-pricing.replit.app';
function settingsWithDefaults(input){
  if(!input)return {luxuryTarget:DEFAULT_LUXURY_URL,prescriptionUrl:DEFAULT_PRESCRIPTION_URL};
  const value=validateSettings(input);
  if(!value.luxuryTarget)value.luxuryTarget=DEFAULT_LUXURY_URL;
  if(!value.prescriptionUrl&&input.prescriptionConfigured!==true)value.prescriptionUrl=DEFAULT_PRESCRIPTION_URL;
  return value;
}
function httpsUrl(value){
  const url=new URL(value);
  if(url.protocol!=='https:'||url.username||url.password)throw Error('인증정보 없는 HTTPS 주소를 입력해 주세요.');
  return url;
}
function validateSettings(input){
  if(!input||typeof input.luxuryTarget!=='string'||typeof input.prescriptionUrl!=='string')
    throw Error('연동 설정 형식을 확인해 주세요.');
  const luxuryTarget=input.luxuryTarget.trim(),prescriptionUrl=input.prescriptionUrl.trim();
  if(luxuryTarget.length>2048||prescriptionUrl.length>2048)throw Error('연동 주소가 너무 깁니다.');
  if(luxuryTarget&&!/^[A-Za-z]:\\[^<>|"?*\r\n]+\.exe$/i.test(luxuryTarget))httpsUrl(luxuryTarget);
  if(prescriptionUrl)httpsUrl(prescriptionUrl);
  return {luxuryTarget,prescriptionUrl};
}
function validateLuxuryResult(input){
  if(!input||typeof input.itemName!=='string'||!input.itemName.trim()||input.itemName.trim().length>100||
    /[\u0000-\u001f]/.test(input.itemName)||!Number.isSafeInteger(input.finalPrice)||
    input.finalPrice<1||input.finalPrice>100000000)throw Error('계산 결과의 품목명과 최종 세탁비(1원~1억 원)를 확인해 주세요.');
  return {itemName:input.itemName.trim(),finalPrice:input.finalPrice};
}
function prescriptionUrl(target,label){
  const url=httpsUrl(target);
  for(const key of ['material','color']){
    if(typeof label?.[key]!=='string'||label[key].length>120)throw Error('소재와 색상을 확인해 주세요.');
    url.searchParams.set(key,label[key]);
  }
  return url.href;
}
function findCalculator(folder){
  if(!folder||!fs.existsSync(folder))return null;
  if(fs.lstatSync(folder).isSymbolicLink()||fs.realpathSync(folder)!==path.resolve(folder))throw Error('계산기 폴더의 링크·정션은 허용하지 않습니다.');
  const names=fs.readdirSync(folder).filter(name=>/\.exe$/i.test(name)&&
    !/(?:setup|install|unins|update)/i.test(name)&&!/^K99-Laundry-V[12]\.exe$/i.test(name))
    .sort((a,b)=>Number(!/^K99-Laundry-/i.test(a))-Number(!/^K99-Laundry-/i.test(b))||a.localeCompare(b,'en'));
  return names.map(name=>path.join(folder,name)).find(file=>{
    const s=fs.lstatSync(file);
    return s.isFile()&&!s.isSymbolicLink()&&s.size>0&&path.resolve(file)!==path.resolve(process.execPath);
  })||null;
}
function createProgramLauncher({readSettings,BrowserWindow,spawn,owner,resultFolder,onResult,platform=process.platform,aiSession,programFolder,openFolder,navigationTimeoutMs=15000}){
  const sessions=new Map();
  const cleanup=id=>{
    const session=sessions.get(id);if(!session)return;
    if(session.timer)clearInterval(session.timer);
    if(session.file)fs.rmSync(session.file,{force:true});
    sessions.delete(id);
  };
  function deliver(id,input){
    const session=sessions.get(id);
    if(!session||input?.sessionId!==id)throw Error('계산 세션이 일치하지 않습니다.');
    const value=validateLuxuryResult(input);
    onResult(value);
    cleanup(id);
    return value;
  }
  function receive(event,input){
    const session=sessions.get(input?.sessionId);
    if(!session||!session.window||event.sender!==session.window.webContents||
      event.senderFrame!==event.sender.mainFrame)throw Error('허용되지 않은 계산 결과입니다.');
    if(new URL(event.senderFrame.url).origin!==session.origin)throw Error('계산기 주소가 일치하지 않습니다.');
    return deliver(input.sessionId,input);
  }
  async function open(kind,label){
    const settings=validateSettings(readSettings());
    if(kind==='prescription'){
      if(!settings.prescriptionUrl)throw Error('추후 연동 예정입니다.');
      return openWeb(prescriptionUrl(settings.prescriptionUrl,label),false);
    }
    if(kind!=='luxury')throw Error('연동 프로그램을 확인해 주세요.');
    const automatic=platform==='win32'?findCalculator(programFolder):null;
    let target=automatic||settings.luxuryTarget||DEFAULT_LUXURY_URL;
    // A missing explicitly registered exe can fall back to the standard folder guidance.
    if(!automatic&&programFolder&&target&&!/^https:/i.test(target)&&!fs.existsSync(target))target=DEFAULT_LUXURY_URL;
    if(!target){
      if(programFolder&&openFolder){
        const error=await openFolder(programFolder);if(error)throw Error(error);
        return {opened:true,resultMode:'none',warning:'계산기 폴더를 열었습니다. 명품 계산기 실행 파일을 넣거나 통합관리센터에 계산기 웹 주소를 등록해 주세요.'};
      }
      throw Error('통합관리센터에서 명품 세탁비 계산기 경로/URL을 먼저 저장해 주세요.');
    }
    if(/^https:/i.test(target))return openWeb(target,true);
    if(platform!=='win32')throw Error('실행 파일 연결은 Windows 앱에서 사용할 수 있습니다.');
    if(!fs.existsSync(target)||!fs.statSync(target).isFile())throw Error('설정한 계산기 실행 파일을 찾을 수 없습니다.');
    fs.mkdirSync(resultFolder,{recursive:true});
    const id=crypto.randomUUID(),file=path.join(resultFolder,id+'.json');
    // No shell or command-string evaluation. Calculator cooperation is optional.
    const child=spawn(target,['--k99-result-file',file,'--k99-session',id],{shell:false,windowsHide:false,detached:false,stdio:'ignore'});
    await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});
    const entry={file,started:Date.now(),timer:null};sessions.set(id,entry);
    entry.timer=setInterval(()=>{
      try{
        if(Date.now()-entry.started>3600000){cleanup(id);return;}
        if(!fs.existsSync(file))return;
        const st=fs.lstatSync(file);
        if(!st.isFile()||st.isSymbolicLink()||st.size>65536){cleanup(id);return;}
        // A partial write is retried; a valid result is accepted once only.
        deliver(id,JSON.parse(fs.readFileSync(file,'utf8')));
      }catch{/* Calculator may still be writing. Manual confirmation remains available. */}
    },750);
    entry.timer.unref?.();
    return {opened:true,resultMode:'file-or-manual'};
  }
  async function openWeb(target,returnResult){
    const url=httpsUrl(target),id=crypto.randomUUID();
    if(!returnResult)aiSession?.prepare();
    if(returnResult){url.searchParams.set('k99_session',id);url.searchParams.set('k99_return','postMessage');}
    const win=new BrowserWindow({parent:owner(),width:1050,height:800,show:returnResult,
      title:returnResult?'명품 세탁비 산정':'AI 세탁 처방',
      webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,
        partition:returnResult?'k99-program-'+id:AI_PARTITION,...(returnResult?{preload:path.join(__dirname,'calculator-preload.cjs')}:{})}});
    const webSession=win.webContents.session;
    webSession?.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    const guardNavigation=(event,next)=>{
      try{if(httpsUrl(next).origin!==url.origin)event.preventDefault();}catch{event.preventDefault();}
    };
    win.webContents.on('will-navigate',guardNavigation);
    win.webContents.on('will-redirect',guardNavigation);
    if(returnResult)sessions.set(id,{window:win,origin:url.origin});
    win.on('closed',()=>{
      if(!returnResult){
        try{
          webSession?.flushStorageData?.();
          Promise.resolve(webSession?.cookies?.flushStore?.()).catch(()=>console.warn('AI 처방 세션 저장을 확인하지 못했습니다.'));
        }catch{console.warn('AI 처방 세션 저장을 확인하지 못했습니다.');}
      }
      cleanup(id);
    });
    try{
      if(!returnResult)await aiSession?.attach(webSession);
      let timer;
      try{
        await Promise.race([win.loadURL(url.href),new Promise((_,reject)=>{
          timer=setTimeout(()=>reject(Error('연동 페이지 연결 시간 초과')),navigationTimeoutMs);
        })]);
      }finally{clearTimeout(timer);}
      const auth=!returnResult?await aiSession?.connect(win,url.href):null;
      win.show?.();win.focus?.();
      return {opened:true,resultMode:returnResult?'message-or-manual':'none',...(auth?.warning?{warning:auth.warning}:{})};
    }catch{
      win.destroy();cleanup(id);throw Error('연동 페이지를 열지 못했습니다. 인터넷 연결 또는 AI 로그인 저장소 승계를 확인하세요.');
    }
  }
  return {open,receive,close:()=>{for(const id of [...sessions.keys()])cleanup(id);}};
}
module.exports={SETTINGS_KEY,DEFAULT_LUXURY_URL,DEFAULT_PRESCRIPTION_URL,settingsWithDefaults,validateSettings,validateLuxuryResult,prescriptionUrl,createProgramLauncher,findCalculator};
