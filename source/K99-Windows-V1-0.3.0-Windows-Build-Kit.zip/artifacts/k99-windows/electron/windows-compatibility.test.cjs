'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {configureWindowsRendering}=require('./windows-compatibility.cjs');
test('Windows software rendering is enabled before any window without weakening sandboxing',()=>{
  const calls=[];
  const app={disableHardwareAcceleration:()=>calls.push('software'),
    commandLine:{appendSwitch:name=>calls.push(name)}};
  configureWindowsRendering(app,'win32');
  assert.deepEqual(calls,['software','disable-gpu','disable-gpu-compositing']);
  configureWindowsRendering(app,'linux');
  assert.equal(calls.length,3);
  const main=fs.readFileSync(path.join(__dirname,'main.cjs'),'utf8');
  assert.ok(main.indexOf('configureWindowsRendering(app)')<main.indexOf('app.whenReady()'));
  assert.match(main,/sandbox:true,webSecurity:true,webviewTag:false,backgroundThrottling:false/);
  assert.doesNotMatch(calls.join(' '),/no-sandbox|disable-web-security|ignore-gpu-blocklist/);
});
test('Windows 10 and 11 share x64 asInvoker installer policy and all startup modules are staged',()=>{
  const root=path.resolve(__dirname,'../../..'),config=require('../electron-builder.cjs');
  assert.deepEqual(config.win.target,[{target:'nsis',arch:['x64']}]);
  assert.equal(config.win.requestedExecutionLevel,'asInvoker');
  assert.equal(config.nsis.perMachine,false);assert.equal(config.nsis.allowElevation,false);
  assert.equal(config.nsis.createDesktopShortcut,'always');assert.equal(config.nsis.createStartMenuShortcut,true);
  const nsis=fs.readFileSync(path.join(__dirname,'../installer/data-preservation.nsh'),'utf8');
  assert.match(nsis,/\$\{AtLeastWin10\}/);assert.match(nsis,/\$\{RunningX64\}/);
  const stage=fs.readFileSync(path.join(root,'scripts/stage-windows-app.cjs'),'utf8');
  for(const name of ['local-startup.cjs','windows-compatibility.cjs'])assert.ok(stage.includes(`'${name}'`));
});
