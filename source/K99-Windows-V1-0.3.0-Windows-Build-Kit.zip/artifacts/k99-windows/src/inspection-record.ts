import type { ConfirmedOrder, OrderItem } from './order-record';
import { createStagedApproval, validateStagedInspection } from './staged-approval.ts';
import type { StagedApproval } from './staged-approval.ts';
import { createItemNotice } from './item-notice.ts';
import type { ItemNotice } from './item-notice.ts';
import { inspectionItemExplanation } from './inspection-message-wording.ts';

export const INSPECTION_FIELDS = [
  '소재/원단 상태', '케어라벨 정보', '오염/얼룩 상태', '변색/황변 여부',
  '이염 위험', '기존 손상 여부', '봉제 상태', '단추/지퍼/장식 상태',
  '접착제 열화 여부', '형태 변형 여부', '명품/고가품 특이사항', '기타 검수사항',
] as const;
export type InspectionField = typeof INSPECTION_FIELDS[number];
export type InspectionRating = '정상' | '주의' | '문제 있음' | '해당 없음';
export type ActualCleaningMethod = '물세탁' | '드라이세탁';
export const CARE_LABEL_METHODS = [
  '물세탁 가능', '드라이세탁 권장', '드라이세탁만 가능', '손세탁 권장',
  '세탁 불가/전문가 확인 필요', '표시 없음', '확인 불가', '기타',
] as const;
export type CareLabelMethod = typeof CARE_LABEL_METHODS[number];
export const RISK_FACTORS = [
  '색 빠짐', '이염', '수축', '형태 변형', '원단 손상', '부자재 손상', '접착부 손상',
  '프린트/코팅 손상', '광택 변화', '촉감 변화', '장식 손상', '기타',
] as const;
export type RiskFactor = typeof RISK_FACTORS[number];
export const CUSTOMER_DECISIONS = [
  '변경 세탁방법 동의', '추가요금 동의', '위험 안내 확인', '면책 동의', '면책 동의하지 않음',
  '전체 진행 동의', '기존 방법 유지 요청', '세탁 취소', '문의 있음', '연락 안 됨',
] as const;
export type CustomerDecision = typeof CUSTOMER_DECISIONS[number];
export type ApprovalRequirements = { method: boolean; price: boolean; risk: boolean; waiver: boolean; work: boolean; otherPriceChange: boolean };
export const CLEANING_METHODS = [
  '기존 방법 유지', '일반 세탁', '프리미엄 세탁', '물세탁', '드라이클리닝',
  '초음파 세탁', '운동화 일반 세탁', '운동화 프리미엄 세탁', '복원세탁', '기타',
] as const;
export type CleaningMethod = typeof CLEANING_METHODS[number];
export const ADDITIONAL_WORK = [
  '추가 작업 없음', '색빠짐 방지 가공', '전처리', '특수 얼룩 제거', '이염 제거',
  '황변 제거', '복원세탁', '형태 안정화', '발수 가공', '기타',
] as const;
export type AdditionalWork = typeof ADDITIONAL_WORK[number];

export type InspectionItem = {
  index: number;
  itemId: string;
  checks: Partial<Record<InspectionField, InspectionRating>>;
  actualCleaningMethod?: ActualCleaningMethod;
  plannedCleaningMethod?: ActualCleaningMethod;
  careLabelMethod?: CareLabelMethod;
  careLabelOther?: string;
  methodChangeReason?: string;
  riskFactors?: RiskFactor[];
  riskDetails?: string;
  memo: string;
  method: CleaningMethod;
  customMethod: string;
  additionalWork: AdditionalWork[];
  additionalWorkDescription: string;
};
export type InspectionDraft = {
  guidanceKind?: import('./inspection-guidance').GuidanceKind;
  guidanceWorkDescription?: string;
  /** Explicit staff-selected physical garments affected by the exception; absent means order-wide. */
  affectedGarmentIds?: string[];
  items: InspectionItem[];
  revisedPrice: number;
  riskRequired: boolean;
  riskNotice: string;
  additionalCharge?: number;
  /** Staff-entered garment name used in the technical-fee stage-1 template. */
  feeItemName?: string;
  /** Mirrors riskRequired (staff guidance setting). Never evidence of customer consent. */
  waiverRequired?: boolean;
  /** Mirrors riskNotice so the concrete risk evidence stays in the draft and record. */
  waiverNotice?: string;
  stagedStainRemoval?: boolean;
};
export type InspectionFinding = {
  itemId: string;
  index: number;
  itemName: string;
  quantity: number;
  category: InspectionField;
  result: '주의' | '문제 있음';
  memo: string;
};
export type InspectionRecord = InspectionDraft & {
  inspectedAt: string;
  originalPrice: number;
  priceDifference: number;
  originalMethods: string[];
  needsApproval: boolean;
  approvalRequirements?: ApprovalRequirements;
  customerMessage: string;
  shortCustomerMessage?: string;
  messageReadyAt?: string;
  shortMessageReadyAt?: string;
  response?: { choice?: '세탁 진행 동의' | '세탁 진행 거절' | '보류'; decisions?: CustomerDecision[];
    content: string; respondedAt?: string; confirmedAt: string; staffName: string };
  stagedApproval?: StagedApproval;
  itemNotice?: ItemNotice;
  /** Simplified one-toggle field consent records (append-only). Never proof of SMS or e-signature. */
  fieldConsents?: FieldConsentRecord[];
};
export type FieldConsentRecord = {
  mode: 'field-simplified' | 'field-fee';
  /** Notice fee this consent refers to (0 when none). */
  noticeFee?: number;
  consent: '동의 완료' | '미동의';
  message: string;
  recordedAt: string;
  recordedBy: string;
  staffAssertion: string;
  acknowledged: CustomerDecision[];
  previousStatus: string;
  actuallySent: false;
  customerSignature: false;
};
export type OrderHistoryEvent = {
  at: string;
  kind: 'original-intake' | 'inspection' | 'inspection-finding' | 'price-change' | 'method-change' | 'additional-work'
    | 'risk-notice' | 'generated-message' | 'staff-message-review' | 'customer-response' | 'approval-status'
    | 'operations-update' | 'notification-draft' | 'inspection-start' | 'care-label-conflict'
    | 'customer-consent' | 'send-preparation' | 'staged-message-draft' | 'staged-message-prepared'
     | 'staged-customer-response' | 'staged-care-label-request'
     | 'item-notice-draft' | 'item-notice-review' | 'item-notice-prepared' | 'item-notice-response';
  details: Record<string, unknown>;
};

export function originalMethod(order: ConfirmedOrder, item: OrderItem): string {
  if (item.isSneaker) return item.itemId === 'sneakers_premium' ? '운동화 프리미엄 세탁' : '운동화 일반 세탁';
  const levels = order.choices.unitServiceLevels?.[order.items.indexOf(item)];
  if (levels) {
    const premium = levels.filter(level => level === 'premium').length;
    return premium === levels.length ? '프리미엄 세탁' : premium === 0 ? '일반 세탁'
      : `일반 ${levels.length - premium}벌 · 프리미엄 ${premium}벌`;
  }
  return order.choices.serviceLevel === 'premium' ? '프리미엄 세탁' : '일반 세탁';
}

export function inspectionFindings(order: ConfirmedOrder, draft: InspectionDraft): InspectionFinding[] {
  return draft.items.flatMap((item, index) => INSPECTION_FIELDS.flatMap((category) => {
    const result = item.checks[category];
    return result === '주의' || result === '문제 있음'
      ? [{ itemId: item.itemId, index, itemName: order.items[index].displayNameKo,
        quantity: order.items[index].quantity, category, result, memo: item.memo.trim() }] : [];
  }));
}

export function originalCleaningMethod(order: ConfirmedOrder, draft: InspectionDraft, index: number): ActualCleaningMethod | undefined {
  return order.items[index].plannedCleaningMethod ?? draft.items[index].plannedCleaningMethod;
}

export function careLabelConflict(item: InspectionItem): boolean {
  if (!item.actualCleaningMethod) return false;
  if (item.careLabelMethod === '드라이세탁 권장' || item.careLabelMethod === '드라이세탁만 가능')
    return item.actualCleaningMethod !== '드라이세탁';
  if (item.careLabelMethod === '손세탁 권장') return item.actualCleaningMethod !== '물세탁';
  if (item.careLabelMethod === '세탁 불가/전문가 확인 필요') return true;
  return false; // "물세탁 가능" does not prohibit dry cleaning; unknown labels are not inferred.
}

export function actualCleaningMethodChanged(order: ConfirmedOrder, draft: InspectionDraft, index: number): boolean {
  const original = originalCleaningMethod(order, draft, index);
  return !order.items[index].isSneaker && original !== undefined
    && draft.items[index].actualCleaningMethod !== undefined && draft.items[index].actualCleaningMethod !== original;
}

export function inspectionMethodChanged(order: ConfirmedOrder, draft: InspectionDraft): boolean {
  return draft.items.some((item, index) =>
    (item.method !== '기존 방법 유지' && (item.method === '기타' || item.method !== originalMethod(order, order.items[index])))
    || actualCleaningMethodChanged(order, draft, index));
}

export function inspectionApprovalRequirements(order: ConfirmedOrder, draft: InspectionDraft): ApprovalRequirements {
  return {
    method: inspectionMethodChanged(order, draft),
    price: draft.revisedPrice > order.estimatedTotal,
    otherPriceChange: draft.revisedPrice < order.estimatedTotal,
    risk: draft.riskRequired || draft.waiverRequired === true || draft.items.some((item, index) =>
      !order.items[index].isSneaker && (careLabelConflict(item) || actualCleaningMethodChanged(order, draft, index))),
    waiver: draft.waiverRequired === true,
    work: draft.items.some((item) => item.additionalWork.some((work) => work !== '추가 작업 없음')),
  };
}

export function inspectionNeedsApproval(order: ConfirmedOrder, draft: InspectionDraft): boolean {
  return Object.values(inspectionApprovalRequirements(order, draft)).some(Boolean);
}

export function validateInspection(order: ConfirmedOrder, draft: InspectionDraft): void {
  if (order.inspection) throw new Error('이미 완료한 검수입니다.');
  if (!Number.isSafeInteger(draft.revisedPrice) || draft.revisedPrice < 0) throw new Error('검수 후 예상금액을 확인해 주세요.');
  if (draft.additionalCharge !== undefined && (!Number.isSafeInteger(draft.additionalCharge) || draft.additionalCharge < 0))
    throw new Error('추가요금은 0원 이상의 정수로 입력해 주세요.');
  if (draft.additionalCharge !== undefined && draft.additionalCharge > Math.max(0, draft.revisedPrice - order.estimatedTotal))
    throw new Error('추가요금이 검수 후 금액의 증가분을 초과합니다.');
  if (draft.revisedPrice > order.estimatedTotal
    && draft.items.some((item) => item.additionalWork.some((work) => work !== '추가 작업 없음'))
    && (!draft.additionalCharge || draft.additionalCharge < 1))
    throw new Error('유료 추가 작업의 추가요금을 직원이 직접 입력해 주세요.');
  if (draft.items.length !== order.items.length) throw new Error('모든 품목을 검수해 주세요.');
  draft.items.forEach((item, index) => {
    if (item.index !== index || item.itemId !== order.items[index].itemId)
      throw new Error(`${order.items[index].displayNameKo}: 검수 품목을 확인해 주세요.`);
    if (!order.items[index].isSneaker && !(['물세탁', '드라이세탁'] as const).some((method) => item.actualCleaningMethod === method))
      throw new Error(`${order.items[index].displayNameKo}: 세탁 방법이 선택되지 않은 품목이 있습니다. 각 품목의 물세탁 또는 드라이세탁을 선택해 주세요.`);
    if (order.items[index].plannedCleaningMethod && item.plannedCleaningMethod
      && item.plannedCleaningMethod !== order.items[index].plannedCleaningMethod)
      throw new Error(`${order.items[index].displayNameKo}: 접수 당시 예정 세탁방법은 변경할 수 없습니다.`);
    if (item.careLabelMethod === '기타' && !item.careLabelOther?.trim())
      throw new Error(`${order.items[index].displayNameKo}: 기타 세탁표시 내용을 입력해 주세요.`);
    if (actualCleaningMethodChanged(order, draft, index) && !item.methodChangeReason?.trim())
      throw new Error(`${order.items[index].displayNameKo}: 세탁방법 변경 사유를 입력해 주세요.`);
    if (!order.items[index].isSneaker && (careLabelConflict(item) || actualCleaningMethodChanged(order, draft, index))
      && !((item.riskDetails?.trim() || draft.riskNotice.trim()) && (item.riskFactors?.length || draft.riskNotice.trim())))
      throw new Error(`${order.items[index].displayNameKo}: 변경된 세탁방법 또는 위험에 대한 위험 안내 상세 내용을 입력해 주세요.`);
    if (INSPECTION_FIELDS.some((field) => !item.checks[field]))
      throw new Error(`${order.items[index].displayNameKo}: 모든 검수 항목을 선택해 주세요.`);
    if (item.method === '기타' && !item.customMethod.trim()) throw new Error(`${order.items[index].displayNameKo}: 세탁 방법을 입력해 주세요.`);
    if (item.additionalWork.some((work) => work !== '추가 작업 없음') && !item.additionalWorkDescription.trim())
      throw new Error(`${order.items[index].displayNameKo}: 추가 작업 설명을 입력해 주세요.`);
  });
  if (draft.riskRequired && !draft.riskNotice.trim()) throw new Error('면책 및 위험 안내 내용을 입력해 주세요.');
  if (draft.guidanceKind) {
    if (!['waiver','fee','both'].includes(draft.guidanceKind)) throw new Error('고객 안내 유형을 확인하세요.');
    const fee = draft.additionalCharge ?? 0;
    if (draft.guidanceKind === 'waiver' && fee !== 0) throw new Error('추가 기술료가 있으면 복합 안내를 선택하세요.');
    if (draft.guidanceKind !== 'waiver' && (!Number.isSafeInteger(fee) || fee <= 0
      || !draft.guidanceWorkDescription?.trim()))
      throw new Error('추가 작업 내용과 1원 이상의 추가 기술료를 입력하세요.');
    if (draft.guidanceKind !== 'fee' && (!draft.riskRequired || !draft.waiverRequired || !draft.riskNotice.trim()))
      throw new Error('구체적인 위험 내용을 입력하세요. 실제 동의는 고객 회신에서 별도로 확인합니다.');
    if (draft.revisedPrice !== order.estimatedTotal + fee) throw new Error('기존 세탁비와 추가 기술료의 합계를 확인하세요.');
  }
  if (draft.waiverRequired && !draft.waiverNotice?.trim() && !draft.riskNotice.trim()) throw new Error('예상 위험 내용을 구체적으로 입력해 주세요.');
  if (draft.waiverRequired && !draft.riskNotice.trim() && !draft.items.some((item) => item.riskDetails?.trim()))
    throw new Error('면책을 요청하는 경우 사전에 안내할 구체적인 위험을 입력해 주세요.');
  if (draft.stagedStainRemoval) validateStagedInspection(order, draft);
}

const won = (amount: number) => `${amount.toLocaleString('ko-KR')}원`;
const difference = (amount: number) => `${amount > 0 ? '+' : ''}${won(amount)}`;

export function generateInspectionMessage(order: ConfirmedOrder, inspection: InspectionRecord): string {
  const findings = inspectionFindings(order, inspection);
  const observations = inspection.items.flatMap((item, index) => {
    const name = order.items[index].displayNameKo;
    const explanation = inspectionItemExplanation({
      name, item, originalService: inspection.originalMethods[index],
      conflict: careLabelConflict(item), actualMethodChanged: actualCleaningMethodChanged(order, inspection, index),
      riskNotice: inspection.items.length === 1 ? inspection.riskNotice : '',
    });
    const noted = findings.filter((finding) => finding.index === index).map((finding) =>
      `${name}의 ${finding.category}에 ${finding.result === '문제 있음' ? '문제가 있는' : '주의가 필요한'} 부분을 확인했습니다.`);
    const memo = item.memo.trim().replace(/\s*확인$/, '');
    if (memo && !explanation.join(' ').includes(memo))
      noted.push(`${name}의 ${memo} 상태도 확인했습니다.`);
    return [...noted, ...explanation];
  });
  return [
    '[K99 품격세탁소]',
    `${order.customerName} 고객님, 맡겨주신 세탁물을 전문 검수한 결과 안내드립니다.`,
    ...observations,
    ...(inspection.riskRequired && inspection.riskNotice.trim()
      ? [`추가로 ${inspection.riskNotice.trim()} 내용을 확인했습니다.`] : []),
    ...(inspection.waiverRequired && inspection.waiverNotice?.trim()
      ? [`진행 전 안내드린 위험 범위에 대한 면책 동의가 필요합니다. ${inspection.waiverNotice.trim()}`] : []),
    ...(inspection.priceDifference ? [
      `예상 세탁비는 기존 ${won(inspection.originalPrice)}에서 ${won(inspection.revisedPrice)}으로 변경됩니다.`
      + ` 추가 작업비는 ${won(inspection.additionalCharge ?? 0)}입니다. (변동금액 ${difference(inspection.priceDifference)})`,
    ] : []),
    ...(findings.length && !inspectionMethodChanged(order, inspection) && !inspection.priceDifference
      ? ['세탁방법과 예상금액은 기존과 같습니다.'] : []),
    '안내드린 내용으로 진행해 드릴까요? 고객님의 확인 전에는 변경된 작업을 시작하지 않겠습니다.',
    '① 네, 진행해주세요.  ② 아니요, 진행하지 않을게요.  ③ 상담 후 결정하겠습니다.',
    '감사합니다. K99 품격세탁소',
  ].join('\n');
}

export function generateShortInspectionMessage(order: ConfirmedOrder, inspection: InspectionRecord): string {
  const findings = inspectionFindings(order, inspection);
  const explanations = inspection.items.flatMap((item, index) => inspectionItemExplanation({
    name: order.items[index].displayNameKo, item, originalService: inspection.originalMethods[index],
    conflict: careLabelConflict(item), actualMethodChanged: actualCleaningMethodChanged(order, inspection, index),
    riskNotice: inspection.items.length === 1 ? inspection.riskNotice : '',
  }));
  return [
    '[K99 품격세탁소]',
    `${order.customerName} 고객님, 맡겨주신 세탁물을 전문 검수했습니다.`,
    ...explanations,
    ...(!explanations.length && findings.length
      ? ['세탁 전 확인된 상태를 고려해 주의하여 작업하겠습니다.'] : []),
    ...(inspection.riskRequired && inspection.riskNotice.trim()
      ? [`추가로 ${inspection.riskNotice.trim()} 내용을 확인했습니다.`] : []),
    ...(inspection.waiverRequired && inspection.waiverNotice?.trim()
      ? [`진행 전 안내드린 위험 범위에 대한 면책 동의가 필요합니다. ${inspection.waiverNotice.trim()}`] : []),
    ...(inspection.priceDifference ? [
      `기존 예상금액 ${won(inspection.originalPrice)} → 최종 예상금액 ${won(inspection.revisedPrice)}입니다.`
      + ` 추가 작업비는 ${won(inspection.additionalCharge ?? 0)}입니다. (추가금액 ${difference(inspection.priceDifference)})`,
    ] : []),
    ...(!inspectionMethodChanged(order, inspection) && !inspection.priceDifference && findings.length
      ? ['세탁방법과 예상금액은 기존과 같습니다.'] : []),
    '안내드린 내용으로 진행해 드릴까요? ① 진행 ② 진행하지 않음 ③ 상담 후 결정',
  ].join('\n');
}

export function completeInspection(order: ConfirmedOrder, draft: InspectionDraft, at = new Date()): ConfirmedOrder {
  validateInspection(order, draft);
  if (draft.affectedGarmentIds !== undefined &&
      (!draft.affectedGarmentIds.length ||
       new Set(draft.affectedGarmentIds).size !== draft.affectedGarmentIds.length ||
       draft.affectedGarmentIds.some(id => !order.garments?.some(g => g.garmentId === id && g.orderId === order.id))))
    throw new Error('동의가 필요한 의류를 현재 주문의 고유 의류번호로 확인해 주세요.');
  const timestamp = at.toISOString();
  const originalMethods = order.items.map((item) => originalMethod(order, item));
  const needsApproval = inspectionNeedsApproval(order, draft);
  const approvalRequirements = inspectionApprovalRequirements(order, draft);
  const methodChanged = inspectionMethodChanged(order, draft);
  const priceChanged = draft.revisedPrice !== order.estimatedTotal;
  const inspection: InspectionRecord = {
    ...draft,
    ...(draft.affectedGarmentIds ? { affectedGarmentIds: [...draft.affectedGarmentIds] } : {}),
    items: draft.items.map((item) => ({
      ...item, checks: { ...item.checks }, additionalWork: [...item.additionalWork],
      riskFactors: [...(item.riskFactors ?? [])],
      memo: item.memo.trim(), customMethod: item.customMethod.trim(), additionalWorkDescription: item.additionalWorkDescription.trim(),
      methodChangeReason: item.methodChangeReason?.trim(), riskDetails: item.riskDetails?.trim(),
      ...(!order.items[item.index].isSneaker && originalCleaningMethod(order, draft, item.index)
        ? { plannedCleaningMethod: originalCleaningMethod(order, draft, item.index) } : {}),
    })),
    riskNotice: draft.riskNotice.trim(), waiverNotice: draft.waiverNotice?.trim(), inspectedAt: timestamp,
    originalPrice: order.estimatedTotal, priceDifference: draft.revisedPrice - order.estimatedTotal,
    originalMethods, needsApproval, approvalRequirements, customerMessage: '', shortCustomerMessage: '',
  };
  if (draft.stagedStainRemoval) {
    inspection.stagedApproval = createStagedApproval(order, inspection);
  } else {
    inspection.itemNotice = createItemNotice(order, inspection);
  }
  const findings = inspectionFindings(order, inspection);
  if (inspection.stagedApproval) {
    inspection.customerMessage = inspection.stagedApproval.steps[1]!.message;
    inspection.shortCustomerMessage = inspection.customerMessage;
  } else if (inspection.itemNotice) {
    inspection.customerMessage = inspection.itemNotice.steps[1]!.message;
    inspection.shortCustomerMessage = inspection.customerMessage;
  } else if (needsApproval || findings.length) {
    inspection.customerMessage = generateInspectionMessage(order, inspection);
    inspection.shortCustomerMessage = generateShortInspectionMessage(order, inspection);
  }
  const event = (kind: OrderHistoryEvent['kind'], details: Record<string, unknown>): OrderHistoryEvent => ({ at: timestamp, kind, details });
  const history: OrderHistoryEvent[] = [
    ...(order.history?.length ? order.history : [{ ...event('original-intake', {
      orderId: order.id, intakeAt: order.intakeAt, customerFolderName: order.customerFolderName,
      customerName: order.customerName, customerPhone: order.customerPhone, customerAddress: order.customerAddress,
      items: order.items, choices: order.choices, laundryTotal: order.laundryTotal,
      serviceFee: order.serviceFee, estimatedTotal: order.estimatedTotal, status: '접수 확정',
    }), at: order.intakeAt }]),
    event('inspection-start', { inspectedAt: timestamp, originalPrice: order.estimatedTotal }),
    event('inspection', { inspectedAt: timestamp, originalPrice: order.estimatedTotal,
      ...(draft.affectedGarmentIds ? { affectedGarmentIds: [...draft.affectedGarmentIds] } : {}),
      revisedPrice: inspection.revisedPrice, priceDifference: inspection.priceDifference,
      originalMethods, items: inspection.items, riskRequired: inspection.riskRequired,
      riskNotice: inspection.riskNotice, waiverRequired: inspection.waiverRequired,
      waiverNotice: inspection.waiverNotice, additionalCharge: inspection.additionalCharge,
      approvalRequirements }),
  ];
  if (findings.length) history.push(event('inspection-finding', {
    inspectedAt: timestamp, findings, originalPrice: inspection.originalPrice,
    revisedPrice: inspection.revisedPrice, methodChanged, priceChanged,
  }));
  if (inspection.priceDifference) history.push(event('price-change', {
    originalPrice: inspection.originalPrice, revisedPrice: inspection.revisedPrice, difference: inspection.priceDifference,
  }));
  inspection.items.forEach((item, index) => {
    const revised = item.method === '기타' ? item.customMethod : item.method;
    if (item.method !== '기존 방법 유지' && revised !== originalMethods[index])
      history.push(event('method-change', { itemId: item.itemId, index, original: originalMethods[index], revised }));
    if (item.plannedCleaningMethod && item.actualCleaningMethod !== item.plannedCleaningMethod)
      history.push(event('method-change', { itemId: item.itemId, index, type: 'actual-cleaning-method',
        original: item.plannedCleaningMethod, revised: item.actualCleaningMethod, reason: item.methodChangeReason }));
    if (careLabelConflict(item))
      history.push(event('care-label-conflict', { itemId: item.itemId, index, careLabel: item.careLabelMethod,
        proposedMethod: item.actualCleaningMethod, riskFactors: item.riskFactors, riskDetails: item.riskDetails }));
    if (item.additionalWork.some((work) => work !== '추가 작업 없음'))
      history.push(event('additional-work', { itemId: item.itemId, index, selections: item.additionalWork,
        description: item.additionalWorkDescription, additionalCharge: inspection.additionalCharge ?? 0 }));
  });
  if (approvalRequirements.risk) history.push(event('risk-notice', { notice: inspection.riskNotice,
    items: inspection.items.map((item) => ({ itemId: item.itemId, factors: item.riskFactors ?? [], details: item.riskDetails })) }));
  if (needsApproval || findings.length) history.push(event('generated-message', {
    message: inspection.customerMessage, shortMessage: inspection.shortCustomerMessage, actuallySent: false }));
  if (inspection.stagedApproval) history.push(event('staged-message-draft', {
    step: 1, message: inspection.stagedApproval.steps[1]!.message, actuallySent: false }));
  if (inspection.itemNotice) history.push(event('item-notice-draft', {
    stage: 1, message: inspection.itemNotice.steps[1]!.message, actuallySent: false }));
  const status = needsApproval ? '고객 회신 대기' : '세탁 진행 승인';
  history.push(event('approval-status', { status, reason: needsApproval ? '고객 재확인 필요'
    : findings.length ? '검수 특이사항 있음' : '변경사항 없음' }));
  return { ...order, status, inspection, history };
}

export function updateInspectionMessage(
  order: ConfirmedOrder, message: string, action: 'edit' | 'regenerate' | 'ready',
  at = new Date(), version: 'detail' | 'short' = 'detail', channel: 'kakao' | 'sms' = 'kakao',
): ConfirmedOrder {
  if (!order.inspection || (!order.inspection.needsApproval && !inspectionFindings(order, order.inspection).length))
    throw new Error('고객 안내 대상 검수가 아닙니다.');
  if (order.inspection.itemNotice) throw new Error('품목별 고객 안내 화면에서 문안을 확인해 주세요.');
  if (!message.trim()) throw new Error('고객 안내 메시지를 입력해 주세요.');
  const timestamp = at.toISOString();
  return {
    ...order,
    inspection: { ...order.inspection,
      [version === 'detail' ? 'customerMessage' : 'shortCustomerMessage']: message,
      ...(action === 'ready' ? { [version === 'detail' ? 'messageReadyAt' : 'shortMessageReadyAt']: timestamp } : {}) },
    history: [...(order.history ?? []), { at: timestamp,
      kind: action === 'ready' ? 'send-preparation'
        : action === 'regenerate' ? 'generated-message' : 'staff-message-review',
      details: { action, version, channel, message, ...(action === 'ready' ? { readyForSending: true, actuallySent: false } : {}) },
    }],
  };
}

export function missingInspectionApprovals(order: ConfirmedOrder, decisions: CustomerDecision[]): string[] {
  const requirements = order.inspection?.approvalRequirements;
  if (!requirements) return [];
  const agreed = new Set(decisions);
  return [
    ...(requirements.method && !agreed.has('변경 세탁방법 동의') ? ['세탁방법 변경에 대한 고객 동의가 필요합니다.'] : []),
    ...(requirements.price && !agreed.has('추가요금 동의') ? ['추가요금에 대한 고객 동의가 필요합니다.'] : []),
    ...(requirements.risk && !agreed.has('위험 안내 확인') ? ['위험 안내 확인이 필요합니다.'] : []),
    ...(requirements.waiver && !agreed.has('면책 동의') ? ['안내된 위험 범위에 대한 면책 동의가 필요합니다.'] : []),
    ...(requirements.work && !agreed.has('전체 진행 동의') ? ['추가 작업에 대한 전체 진행 동의가 필요합니다.'] : []),
    ...(requirements.otherPriceChange && !agreed.has('전체 진행 동의') ? ['변경된 금액에 대한 전체 진행 동의가 필요합니다.'] : []),
  ];
}

export function recordInspectionResponse(
  order: ConfirmedOrder,
  response: { choice: '세탁 진행 동의' | '세탁 진행 거절' | '보류'; content: string; staffName: string }
    | { decisions: CustomerDecision[]; content: string; staffName: string; respondedAt?: string },
  at = new Date(),
): ConfirmedOrder {
  if (!order.inspection?.needsApproval) throw new Error('고객 회신 대상 주문이 아닙니다.');
  if (order.inspection.stagedApproval) throw new Error('단계별 고객 답변 화면에서 순서대로 확인해 주세요.');
  if (order.inspection.itemNotice) throw new Error('품목별 고객 안내 화면에서 순서대로 확인해 주세요.');
  if (!response.staffName.trim()) throw new Error('고객 회신과 확인 직원을 입력해 주세요.');
  const isNew = 'decisions' in response;
  if (isNew && (!response.decisions.length || response.decisions.some((decision) => !CUSTOMER_DECISIONS.includes(decision))))
    throw new Error('고객 회신 항목을 선택해 주세요.');
  if (!isNew && !['세탁 진행 동의', '세탁 진행 거절', '보류'].includes(response.choice))
    throw new Error('고객 회신과 확인 직원을 입력해 주세요.');
  if (!isNew && order.inspection.approvalRequirements)
    throw new Error('필요한 동의 항목을 각각 확인해 주세요.');
  if (isNew && response.respondedAt && !Number.isFinite(Date.parse(response.respondedAt)))
    throw new Error('고객 회신 일시를 확인해 주세요.');
  const selected = isNew ? response.decisions : [];
  const previous = order.inspection.response?.decisions ?? [];
  const confirmedDecisions = [...new Set([...previous, ...selected])];
  const declined = selected.includes('세탁 취소') || selected.includes('면책 동의하지 않음');
  const held = selected.some((decision) => ['기존 방법 유지 요청', '문의 있음', '연락 안 됨'].includes(decision));
  const missing = missingInspectionApprovals(order, confirmedDecisions);
  const status = isNew
    ? declined ? '세탁 진행 거절' : held ? '보류' : '고객 회신 대기'
    : response.choice === '세탁 진행 동의' ? '세탁 진행 승인'
      : response.choice === '세탁 진행 거절' ? '세탁 진행 거절' : '보류';
  const confirmedAt = at.toISOString();
  const respondedAt = isNew ? response.respondedAt || confirmedAt : confirmedAt;
  return { ...order, status,
    inspection: { ...order.inspection, response: { ...response, ...(isNew ? { decisions: confirmedDecisions } : {}),
      content: response.content.trim(), staffName: response.staffName.trim(), respondedAt, confirmedAt } },
    history: [...(order.history ?? []),
      { at: confirmedAt, kind: 'customer-response', details: { ...response, respondedAt,
        staffName: response.staffName.trim(), confirmedAt, missingApprovals: missing } },
      { at: confirmedAt, kind: 'approval-status', details: { status, staffName: response.staffName.trim(),
        missingApprovals: missing } }],
  };
}

export function approveInspectionCleaning(order: ConfirmedOrder, staffName: string, at = new Date()): ConfirmedOrder {
  if (order.inspection?.stagedApproval) throw new Error('단계별 고객 확인이 끝나기 전에는 승인할 수 없습니다.');
  if (order.inspection?.itemNotice) throw new Error('품목별 고객 안내의 필요한 회신을 먼저 확인해 주세요.');
  if (!order.inspection?.needsApproval || !order.inspection.response || order.status !== '고객 회신 대기')
    throw new Error('고객 동의 확인 전에는 세탁 진행을 승인할 수 없습니다.');
  if (!staffName.trim()) throw new Error('승인 확인 직원을 입력해 주세요.');
  if (!order.inspection.approvalRequirements)
    throw new Error('기존 검수 주문은 기존 고객 회신 절차로 확인해 주세요.');
  const decisions = order.inspection.response.decisions ?? [];
  if (decisions.some((decision) => ['면책 동의하지 않음', '세탁 취소', '기존 방법 유지 요청', '문의 있음', '연락 안 됨'].includes(decision)))
    throw new Error('고객 거절 또는 보류 중인 주문은 승인할 수 없습니다.');
  const missing = missingInspectionApprovals(order, decisions);
  if (missing.length) throw new Error(missing.join(' '));
  const confirmedAt = at.toISOString();
  return { ...order, status: '세탁 진행 승인',
    history: [...(order.history ?? []),
      { at: confirmedAt, kind: 'customer-consent', details: { decisions, staffName: staffName.trim(),
        responseAt: order.inspection.response.respondedAt, confirmedAt } },
      { at: confirmedAt, kind: 'approval-status', details: { status: '세탁 진행 승인',
        staffName: staffName.trim(), confirmedAt } }],
  };
}