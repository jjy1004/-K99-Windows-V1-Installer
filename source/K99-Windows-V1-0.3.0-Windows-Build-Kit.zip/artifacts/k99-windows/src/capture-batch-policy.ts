import type { GarmentRecord } from './garment-record';

export function batchTagSubmission(g: GarmentRecord) {
  const reprint = Boolean(g.photoBridgeReprintRequestId);
  const status = reprint ? g.photoBridgeReprintStatus : g.photoBridgeAutoTagStatus;
  const mode = reprint ? g.photoBridgeReprintMode : g.photoBridgeAutoTagMode;
  const requestId = reprint ? g.photoBridgeReprintRequestId : g.photoBridgeAutoTagRequestId;
  const jobId = reprint ? g.photoBridgeReprintJobId : g.photoBridgeAutoTagJobId;
  return mode === 'STORE' && status === 'submitted' && requestId && jobId &&
    g.photoStatus === 'saved' && g.captureRequestId && g.photoPath && g.photoTimestamp && !g.lastError
    ? { requestId, jobId } : null;
}

export function staffCheckBatchTag(g: GarmentRecord, at = new Date()): GarmentRecord {
  const submission = batchTagSubmission(g);
  if (!submission) throw new Error('저장 사진과 전달된 STORE 태그 요청을 먼저 확인하세요.');
  return { ...g, captureBatchTagCheck: {
    at: at.toISOString(), tagRequestId: submission.requestId, tagJobId: submission.jobId,
    photoRequestId: g.captureRequestId!, photoPath: g.photoPath!, photoTimestamp: g.photoTimestamp!,
  } };
}

export function batchTagComplete(g: GarmentRecord, mode?: string | null): boolean {
  const submission = mode === 'STORE' ? batchTagSubmission(g) : null;
  const check = g.captureBatchTagCheck;
  if (submission && check?.at && check.tagRequestId === submission.requestId &&
      check.tagJobId === submission.jobId && check.photoRequestId === g.captureRequestId &&
      check.photoPath === g.photoPath && check.photoTimestamp === g.photoTimestamp) return true;
  if (g.tagStatus !== 'printed' || mode === 'DEV' || mode === 'TEST') return false;
  if (mode !== 'STORE') return true;
  const status = g.photoBridgeReprintRequestId ? g.photoBridgeReprintStatus : g.photoBridgeAutoTagStatus;
  const reason = g.photoBridgeReprintRequestId ? g.photoBridgeReprintReason : g.photoBridgeAutoTagReason;
  return status === 'printed' && Boolean(reason?.includes('1장 완료 응답 확인'));
}

export function batchGarmentState(g: GarmentRecord, mode?: string | null): 'done' | 'attention' | 'pending' {
  const tag = g.photoBridgeReprintRequestId ? g.photoBridgeReprintStatus : g.photoBridgeAutoTagStatus;
  if (g.photoStatus === 'failed' || g.tagStatus === 'failed' || g.lastError ||
      tag === 'failed' || tag === 'unknown') return 'attention';
  return g.photoStatus === 'saved' && batchTagComplete(g, mode) ? 'done' : 'pending';
}

/** Failed garments are handled separately, not repeatedly re-armed by the batch. */
export function nextBatchPhotoIndex(garments: GarmentRecord[], from: number): number {
  for (let offset = 1; offset < garments.length; offset++) {
    const index = (from + offset + garments.length) % garments.length;
    if (garments[index].photoStatus === 'not-captured' && !garments[index].lastError) return index;
  }
  return -1;
}
