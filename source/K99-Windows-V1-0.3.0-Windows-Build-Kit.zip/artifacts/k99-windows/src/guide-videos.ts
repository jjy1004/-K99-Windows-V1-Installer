import { useEffect, useState } from 'react';
import { CUSTOMER_VIDEO_BUTTONS, type ManualCustomerVideo } from './customer-media';

export type GuideVideoSlot = {
  number:number; video:ManualCustomerVideo; title:string; name:string;
  source:'default'|'custom'; error?:string; defaultAvailable?:boolean;
};
export type GuideVideosReply = {success:boolean; slots?:GuideVideoSlot[]; errors?:string[]; error?:string};
export const DEFAULT_GUIDE_SLOTS: GuideVideoSlot[] = CUSTOMER_VIDEO_BUTTONS.map((button, index) => ({
  number:index+1, video:button.video, title:button.label, name:`${button.video}.mp4`, source:'default',
}));
export function useGuideVideoSlots() {
  const [slots, setSlots] = useState(DEFAULT_GUIDE_SLOTS);
  useEffect(() => {
    let alive = true, sequence = 0;
    const reload = async () => {
      const mine = ++sequence;
      try {
        const reply = await window.k99Desktop?.guideVideos?.('list');
        if (alive && mine === sequence && reply?.slots?.length === 4) setSlots(reply.slots);
      } catch { /* Management shows the detailed error; packaged titles stay available. */ }
    };
    void reload();
    const off = window.k99Desktop?.onGuideVideosChanged?.(() => void reload());
    return () => { alive = false; off?.(); };
  }, []);
  return slots;
}
