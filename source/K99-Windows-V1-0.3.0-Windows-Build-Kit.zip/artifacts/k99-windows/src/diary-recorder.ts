export const DIARY_SILENCE_MS = 4500;
export const DIARY_MAX_RECORDING_MS = 300000;
export class SilenceDetector {
  lastSound: number;
  constructor(now: number) { this.lastSound = now; }
  update(rms: number, now: number) {
    if (rms > 0.015) this.lastSound = now;
    return now - this.lastSound >= DIARY_SILENCE_MS;
  }
}

/** 중단·재개 시 같은 MediaRecorder와 청크 배열을 사용한다. 촬영 카메라는 요청하지 않는다. */
export class DiaryRecorder {
  private stream: MediaStream | null = null;
  private context: AudioContext | null = null;
  private recorder: MediaRecorder | null = null;
  private chunks: Blob[] = [];
  private timer: ReturnType<typeof setInterval> | null = null;
  private cancelled = false;
  private finished: Blob | null = null;
  private detector = new SilenceDetector(performance.now());
  private activeMs = 0;
  private lastTick = 0;
  constructor(private onPause: (reason: 'silence' | 'limit' | 'device') => void, private onLevel: (level: number) => void) {}
  async start() {
    let expired = false;
    const request = navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    // 권한 요청이 늦게 끝나도 이미 닫힌 모달의 마이크를 점유하지 않는다.
    void request.then(stream => { if (expired || this.cancelled) stream.getTracks().forEach(t => t.stop()); }, () => {});
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      this.stream = await Promise.race([request, new Promise<never>((_, reject) => {
        timeout = setTimeout(() => { expired = true; reject(Error('마이크 연결이 지연됩니다. Windows 마이크 권한과 연결을 확인해 주세요.')); }, 12000);
      })]);
      if (this.cancelled) throw Error('녹음을 취소했습니다.');
      this.context = new AudioContext();
      await this.context.resume();
      if (this.cancelled) throw Error('녹음을 취소했습니다.');
      const analyser = this.context.createAnalyser();
      analyser.fftSize = 1024;
      this.context.createMediaStreamSource(this.stream).connect(analyser);
      const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find(m => MediaRecorder.isTypeSupported(m));
      this.recorder = new MediaRecorder(this.stream, mime ? { mimeType: mime } : undefined);
      this.recorder.ondataavailable = e => { if (e.data.size) this.chunks.push(e.data); };
      this.stream.getAudioTracks().forEach(track => track.addEventListener('ended', () => {
        if (!this.cancelled) { this.pause(); this.onPause('device'); }
      }));
      this.recorder.start(500);
      const samples = new Float32Array(analyser.fftSize);
      this.detector = new SilenceDetector(performance.now());
      this.lastTick = performance.now();
      this.timer = setInterval(() => {
        const now = performance.now(), delta = now - this.lastTick; this.lastTick = now;
        if (this.recorder?.state !== 'recording') return;
        this.activeMs += delta;
        analyser.getFloatTimeDomainData(samples);
        const rms = Math.sqrt(samples.reduce((sum, v) => sum + v * v, 0) / samples.length);
        this.onLevel(Math.min(1, rms * 8));
        if (this.activeMs >= DIARY_MAX_RECORDING_MS) { this.pause(); this.onPause('limit'); }
        else if (this.detector.update(rms, now)) { this.pause(); this.onPause('silence'); }
      }, 100);
    } catch (e) { this.abort(); throw e; }
    finally { if (timeout) clearTimeout(timeout); }
  }
  pause() { if (this.recorder?.state === 'recording') this.recorder.pause(); this.onLevel(0); }
  resume() {
    if (this.activeMs >= DIARY_MAX_RECORDING_MS) throw Error('한 번에 5분까지 녹음할 수 있습니다. 먼저 정리한 뒤 이어 기록해 주세요.');
    if (this.recorder?.state !== 'paused' || !this.stream?.getAudioTracks().some(t => t.readyState === 'live'))
      throw Error('마이크 연결이 끊겼습니다. 지금까지 녹음한 내용으로 정리한 뒤 다시 녹음해 주세요.');
    this.detector = new SilenceDetector(performance.now());
    this.lastTick = performance.now(); this.recorder.resume();
  }
  async finish(): Promise<Blob> {
    if (this.finished) return this.finished;
    const recorder = this.recorder;
    if (!recorder) throw Error('보관된 녹음이 없습니다.');
    if (recorder.state !== 'inactive') await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(Error('녹음 마무리가 지연됩니다. 다시 시도해 주세요.')), 4000);
      recorder.addEventListener('stop', () => { clearTimeout(timer); resolve(); }, { once: true });
      recorder.stop();
    });
    this.finished = new Blob(this.chunks, { type: recorder.mimeType || 'audio/webm' });
    this.cleanup();
    if (!this.finished.size) throw Error('녹음된 음성이 없습니다. 마이크를 확인해 주세요.');
    return this.finished;
  }
  private cleanup() {
    if (this.timer) clearInterval(this.timer); this.timer = null;
    this.stream?.getTracks().forEach(t => t.stop()); this.stream = null;
    void this.context?.close().catch(() => {}); this.context = null; this.onLevel(0);
  }
  abort() {
    this.cancelled = true;
    try { if (this.recorder && this.recorder.state !== 'inactive') this.recorder.stop(); } catch { /* 종료된 녹음 */ }
    this.cleanup();
  }
}

/** 브라우저 녹음은 메모리에서 16kHz PCM WAV로 변환한다. 서버에 임시 음성 파일을 남기지 않는다. */
export function pcmWav(samples: Float32Array, sampleRate = 16000) {
  const buffer = new ArrayBuffer(44 + samples.length * 2), view = new DataView(buffer);
  const str = (offset: number, value: string) => [...value].forEach((c, i) => view.setUint8(offset + i, c.charCodeAt(0)));
  str(0, 'RIFF'); view.setUint32(4, 36 + samples.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true); view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true); view.setUint16(34, 16, true); str(36, 'data'); view.setUint32(40, samples.length * 2, true);
  samples.forEach((sample, i) => { const value = Math.max(-1, Math.min(1, sample)); view.setInt16(44 + i * 2, Math.round(value * (value < 0 ? 32768 : 32767)), true); });
  return new Uint8Array(buffer);
}
export async function recordingBase64(blob: Blob) {
  const decoder = new AudioContext();
  try {
    const decoded = await decoder.decodeAudioData(await blob.arrayBuffer());
    if (decoded.duration < 0.5 || decoded.duration > 301) throw Error('녹음은 0.5초~5분 사이로 나누어 주세요.');
    const offline = new OfflineAudioContext(1, Math.min(4800000, Math.ceil(decoded.duration * 16000)), 16000);
    const source = offline.createBufferSource(); source.buffer = decoded; source.connect(offline.destination); source.start();
    const output = await offline.startRendering(), bytes = pcmWav(output.getChannelData(0));
    let binary = ''; for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return btoa(binary);
  } finally { await decoder.close(); }
}
