import { useEffect, useRef, useState } from 'react';
import bwipjs from 'bwip-js/browser';
import { ArrowLeft, ArrowRight, Download, QrCode } from 'lucide-react';
import { PhoneGuideScene } from './PhoneGuideScene';
import { IRIUN_OFFICIAL_URL, IRIUN_PLAY_URL, USB_CAMERA_STANDARD, USB_CAMERA_STEPS } from './iriun-usb-guide';
import type { GuideCard } from './guide-data';
import './iriun-usb-guide.css';

function InstallQr({ url, title }: { url: string; title: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    try {
      const options = {
        bcid: 'qrcode', text: url, eclevel: 'L', scale: 6, padding: 4,
        backgroundcolor: 'FFFFFF',
      };
      if (ref.current) bwipjs.toCanvas(ref.current, options);
      setFailed(false);
    } catch { setFailed(true); }
  }, [url]);
  return <div className="ius-qr">
    {failed ? <p role="alert">QR을 표시하지 못했습니다. 아래 주소를 이용해 주세요.</p>
      : <canvas ref={ref} role="img" aria-label={`${title} 설치 QR 코드`} data-qr-url={url} />}
  </div>;
}

export function IriunDownloads() {
  return <section className="ius-downloads" aria-label="Iriun 휴대폰 앱 설치 QR과 공식 주소">
    <article>
      <h3><QrCode aria-hidden />방법 1 · Google Play 바로 설치</h3>
      <InstallQr url={IRIUN_PLAY_URL} title="Google Play" />
      <p>플레이 스토어에서 검색하지 마시고, 휴대폰 카메라로 위 QR 코드를 비추면 바로 [설치] 화면이 열립니다.</p>
      <a href={IRIUN_PLAY_URL} target="_blank" rel="noopener noreferrer">{IRIUN_PLAY_URL}</a>
    </article>
    <article>
      <h3><Download aria-hidden />방법 2 · 구형폰 공식 안내</h3>
      <InstallQr url={IRIUN_OFFICIAL_URL} title="Iriun 공식 홈페이지" />
      <p>설치 버튼이 안 보이면 휴대폰에서 아래 공식 홈페이지를 열어 지원 기종·설치 안내를 확인하세요.</p>
      <a href={IRIUN_OFFICIAL_URL} target="_blank" rel="noopener noreferrer">{IRIUN_OFFICIAL_URL}</a>
      <p className="ius-note">현재 공식 홈페이지에 별도 APK 다운로드는 확인되지 않았습니다. 출처가 불분명한 APK는 설치하지 마세요. 호환되지 않는 구형폰은 다른 지원 휴대폰이 필요할 수 있습니다.</p>
    </article>
  </section>;
}

export function usbGuideCard(index: number): GuideCard {
  const step = USB_CAMERA_STEPS[index];
  return {
    title: `${index + 1}단계 · ${step.title}`, body: step.body,
    device: 'phone', bar: step.bar, rows: [...step.rows], hit: step.hit,
    phoneScene: step.scene, diagram: true,
  };
}

export function IriunUsbGuide({ slides = false }: { slides?: boolean }) {
  const [index, setIndex] = useState(0);
  const [downloads, setDownloads] = useState(!slides);
  const indices = slides ? [index] : USB_CAMERA_STEPS.map((_, i) => i);
  return <section className="ius-guide" aria-label="USB 데이터 케이블 촬영 7단계 표준 안내">
    <p className="ius-standard">{USB_CAMERA_STANDARD}</p>
    <button type="button" className="ius-button" aria-expanded={downloads} onClick={() => setDownloads(v => !v)}>
      <QrCode aria-hidden />{downloads ? '앱 설치 QR·주소 접기' : '앱 설치 QR·주소 보기'}
    </button>
    {downloads && <IriunDownloads />}
    <ol className={`ius-steps${slides ? ' is-slides' : ''}`} start={slides ? index + 1 : 1}>
      {indices.map(i => {
        const card = usbGuideCard(i);
        return <li key={i} data-testid={`usb-guide-step-${i + 1}`} value={i + 1}>
          <div className="ius-art"><PhoneGuideScene card={card} /></div>
          <div><h3>{card.title}</h3><p>{card.body}</p><small>안내 도해 · 실제 기종과 메뉴 이름은 다를 수 있습니다.</small></div>
        </li>;
      })}
    </ol>
    {slides && <nav className="ius-nav" aria-label="촬영 준비 그림 넘기기">
      <button type="button" className="ius-button" disabled={index === 0} onClick={() => setIndex(i => i - 1)}><ArrowLeft aria-hidden />이전 그림</button>
      <strong role="status">{index + 1} / {USB_CAMERA_STEPS.length}</strong>
      <button type="button" className="ius-button" disabled={index === USB_CAMERA_STEPS.length - 1} onClick={() => setIndex(i => i + 1)}>다음 그림<ArrowRight aria-hidden /></button>
    </nav>}
    <p className="ius-note">USB 디버깅은 신뢰하는 매장 PC에서만 허용하세요. 이 안내는 휴대폰 설정을 자동 변경하지 않습니다. PC·휴대폰에 Iriun이 설치되고 연결 승인이 완료되어 있어야 하며, 발열이나 케이블 불량까지 없어지는 것은 아닙니다.</p>
  </section>;
}
