/**
 * Maps a physical key event to the ASCII character a barcode wedge intended,
 * independently of the OS input method (e.g. Korean IME). Never changes the OS mode.
 * Returns null for keys that are not part of a barcode.
 */
export function barcodeCharFromKey(e: { key: string; code: string; shiftKey: boolean }): string | null {
  if (/^[\x21-\x7e]$/.test(e.key)) return e.key;
  const code = e.code || '';
  let m = /^Key([A-Z])$/.exec(code);
  if (m) return e.shiftKey ? m[1] : m[1].toLowerCase();
  m = /^(?:Digit|Numpad)([0-9])$/.exec(code);
  if (m && !e.shiftKey) return m[1];
  const map: Record<string, [string, string]> = {
    Minus: ['-', '_'], NumpadSubtract: ['-', '-'], Period: ['.', '>'], Slash: ['/', '?'], Equal: ['=', '+'],
  };
  const pair = map[code];
  return pair ? pair[e.shiftKey ? 1 : 0] : null;
}
