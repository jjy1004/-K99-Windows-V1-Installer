export type DirectoryCustomer = {
  id: string; name: string; phone: string; address: string; totalVisits: number; nextVisit: number;
  sourceCustomerId?: string; needsReview?: boolean; reportedItems?: number; reportedLaundry?: number;
  lastVisitDate?: string | null; recentYear?: RecentYearSummary;
};
export type MasterVisit = {
  id: string; visitDate: string; receiptAt: string; orderNumber: string; itemCount: number; totalAmount: number;
  status: string; source: 'import' | 'local'; items: {label: string; quantity: number}[];
};
export type MasterCustomer = DirectoryCustomer & {
  totalItems: number; totalAmount: number; visits: MasterVisit[];
};
export const listCustomerDirectory = () =>
  directoryRequest<{customers: MasterCustomer[]}>('GET', '/api/customers/directory');
export type CustomerVisit = {
  id: string; visitDate: string; itemCount: number; totalAmount: number; memo: string; source: 'import' | 'local';
  laundryAmount?: number; paymentKnown?: boolean; status?: string; needsReview?: boolean;
  items?: { sourceItemId?: string; label: string; price?: number; status?: string; paymentTerms?: string; quantity: number }[];
};
export type VisitHistory = {
  customer: DirectoryCustomer; visits: CustomerVisit[]; totalItems: number; totalAmount: number;
  totalLaundry?: number; unknownPaymentVisits?: number; review?: ReviewRow[];
  recentYear: RecentYearSummary; recentVisits: CustomerVisit[];
};
export type RecentYearSummary = { startDate: string; endDate: string; visitCount: number; itemCount: number; totalAmount: number };
export type ReviewRow = { sheet: string; row: number; issues: string[] };
export type LedgerStatus = { sources: Record<string, number>[]; reviewRows: number; preservedRows: number };
export type ImportPreview = {
  token: string; headers: string[]; rowCount: number; customerCount: number; historyCount: number;
  duplicateCount: number; warnings: string[]; sample: Record<string, unknown>[];
  format?: string; summary?: Record<string, number>;
};
export async function directoryRequest<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
  if (!window.k99Desktop) throw new Error('고객 DB 기능은 Windows 앱에서 사용합니다. 브라우저 미리보기는 고객 DB에 연결하지 않습니다.');
  const reply = await window.k99Desktop.request({ method, path, body });
  if (!reply.ok) throw new Error(reply.error);
  return reply.result as T;
}
export async function searchCustomers(q: string): Promise<{ customers: DirectoryCustomer[] }> {
  if (window.k99Desktop?.searchCustomers) {
    const result = await window.k99Desktop.searchCustomers(q);
    if (!result.success) throw Error(result.error || 'SQLite 고객 검색에 실패했습니다.');
    return { customers: result.customers };
  }
  return directoryRequest('GET', `/api/customers/search?q=${encodeURIComponent(q)}`);
}
export const customerHistory = (id: string) =>
  directoryRequest<VisitHistory>('GET', `/api/customers/${encodeURIComponent(id)}/history`);
export const ledgerStatus = () => directoryRequest<LedgerStatus>('GET', '/api/customers/import/status');
export const ledgerReview = () => directoryRequest<{ rows: ReviewRow[] }>('GET', '/api/customers/import/review');
export async function previewCustomerFile(file: File, mapping: Record<string, string> = {}) {
  if (file.size > 8 * 1024 * 1024) throw new Error('고객 파일은 8MB 이하로 선택하세요.');
  const data = new Uint8Array(await file.arrayBuffer());
  let binary = '';
  for (let i = 0; i < data.length; i += 8192) binary += String.fromCharCode(...data.subarray(i, i + 8192));
  return directoryRequest<ImportPreview>('POST', '/api/customers/import/preview',
    { fileName: file.name, data: btoa(binary), mapping });
}
export const commitCustomerImport = (token: string) =>
  directoryRequest<{ customers: number; histories: number; duplicates: number; backup: string }>(
    'POST', '/api/customers/import/commit', { token });
