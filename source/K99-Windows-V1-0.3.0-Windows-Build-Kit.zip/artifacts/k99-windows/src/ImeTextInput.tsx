import { useEffect, useLayoutEffect, useRef, useState, type ComponentPropsWithoutRef } from 'react';
import { SCANNER_RESTORE_EVENT } from './keyboard-tag-reader';
import { composeKoreanInput, convertKoreanSearch } from './korean-input-conversion';
import { publishImeValue } from './ime-search-policy';
type Props = Omit<ComponentPropsWithoutRef<'input'>, 'value' | 'onChange'> & {
  value: string; onValue: (value: string) => void; onTyping?: () => void;
  koreanFirst?: boolean | 'search';
};
/** Name suggestions see native composition text, but prop updates never replace
 * the IME-owned input buffer or consume its Enter key. */
export function ImeTextInput({ value, onValue, onTyping, koreanFirst = true, ...props }: Props) {
  const [text, setText] = useState(value);
  const composing = useRef(false);
  const input = useRef<HTMLInputElement>(null);
  const caret = useRef<{ text: string; position: number } | null>(null);
  const searchBuffer = useRef({ raw: value, display: value });
  // A native Windows IME may emit an ASCII input immediately before
  // compositionstart. Never rewrite that first keystroke synchronously.
  const pendingInput = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelPending = () => {
    if (pendingInput.current !== null) clearTimeout(pendingInput.current);
    pendingInput.current = null;
  };
  useEffect(() => cancelPending, []);
  const onValueRef = useRef(onValue);
  const convert = (raw: string) => koreanFirst === 'search' ? convertKoreanSearch(raw) : koreanFirst ? composeKoreanInput(raw) : raw;
  onValueRef.current = onValue;
  useLayoutEffect(() => {
    const field = input.current, pending = caret.current;
    caret.current = null;
    if (!composing.current && field && pending?.text === text && field.value === text && document.activeElement === field)
      field.setSelectionRange(pending.position, pending.position);
  }, [text]);
  useEffect(() => {
    const restore = (event: Event) => {
      const restored = (event as Event & { restoredValue: string }).restoredValue;
      composing.current = false; setText(restored); onValueRef.current(restored);
    };
    const field = input.current;
    field?.addEventListener(SCANNER_RESTORE_EVENT, restore);
    return () => field?.removeEventListener(SCANNER_RESTORE_EVENT, restore);
  }, []);
  useEffect(() => {
    if (!composing.current) {
      setText(value);
      if (searchBuffer.current.display !== value) searchBuffer.current = { raw: value, display: value };
    }
  }, [value]);
  return <input {...props} ref={input} value={text} lang="ko" inputMode="text" spellCheck={false} data-korean-managed="true"
    onCompositionStart={(event) => { cancelPending(); composing.current = true; caret.current = null; onTyping?.(); props.onCompositionStart?.(event); }}
    onCompositionEnd={(event) => {
      composing.current = false;
      const final = event.currentTarget.value;
      searchBuffer.current = { raw: final, display: final };
      setText(final); onValue(final); props.onCompositionEnd?.(event);
    }}
    onChange={(event) => {
      const field = event.currentTarget;
      const raw = field.value;
      const native = event.nativeEvent as InputEvent;
      const nativeComposition = composing.current || native.isComposing || /composition/i.test(native.inputType || '');
      // Preserve raw ASCII on append: K → ㅏ, then K9 → K9, never ㅏ9.
      const previous = searchBuffer.current;
      const candidate = koreanFirst === 'search' && raw.startsWith(previous.display)
        && !nativeComposition ? previous.raw + raw.slice(previous.display.length) : raw;
      cancelPending();
      const next = nativeComposition ? raw : convert(candidate);
      searchBuffer.current = { raw: candidate, display: next };
      const cursor = field.selectionStart;
      caret.current = null;
      if (!nativeComposition && next !== raw && cursor !== null)
        caret.current = { text: next, position: convert(raw.slice(0, cursor)).length };
      // Keep the native buffer intact until an adjacent compositionstart can
      // claim it. Real IME text is never transliterated or written twice.
      const delayed = !nativeComposition && next !== raw;
      setText(delayed ? raw : next); onTyping?.();
      if (delayed) {
        caret.current = null;
        pendingInput.current = setTimeout(() => {
          pendingInput.current = null;
          if (composing.current || input.current?.value !== raw) return;
          searchBuffer.current = { raw: candidate, display: next };
          if (cursor !== null) caret.current = { text: next, position: convert(raw.slice(0, cursor)).length };
          setText(next); onValueRef.current(next);
        }, 30);
        return;
      }
      if (publishImeValue(nativeComposition, koreanFirst)) {
        onValue(next);
      }
    }}
    onKeyDown={(event) => {
      if (event.nativeEvent.isComposing || event.keyCode === 229) {
        cancelPending(); composing.current = true;
      }
      if (composing.current || event.nativeEvent.isComposing || event.keyCode === 229)
        event.stopPropagation();
      else props.onKeyDown?.(event);
    }}
    onBlur={(event) => {
      const flush = pendingInput.current !== null && !composing.current;
      cancelPending();
      if (flush) {
        const final=convert(event.currentTarget.value);
        searchBuffer.current={raw:event.currentTarget.value,display:final};
        setText(final);onValueRef.current(final);
      }
      if (composing.current) {
        composing.current = false;
        const final = event.currentTarget.value; setText(final); onValue(final);
      }
      props.onBlur?.(event);
    }} />;
}
