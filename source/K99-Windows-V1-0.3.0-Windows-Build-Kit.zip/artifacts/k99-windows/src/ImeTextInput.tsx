import { useEffect, useRef, useState, type ComponentPropsWithoutRef } from 'react';
import { SCANNER_RESTORE_EVENT } from './keyboard-tag-reader';
import { composeKoreanInput, convertKoreanSearch } from './korean-input-conversion';
import { publishImeValue } from './ime-search-policy';
type Props = Omit<ComponentPropsWithoutRef<'input'>, 'value' | 'onChange'> & {
  value: string; onValue: (value: string) => void; onTyping?: () => void;
  koreanFirst?: boolean | 'search';
};
/** Name suggestions see native composition text, but prop updates never replace
 * the IME-owned input buffer or consume its Enter key. */
export function ImeTextInput({ value, onValue, onTyping, koreanFirst = false, ...props }: Props) {
  const [text, setText] = useState(value);
  const composing = useRef(false);
  const input = useRef<HTMLInputElement>(null);
  const searchBuffer = useRef({ raw: value, display: value });
  const onValueRef = useRef(onValue);
  const convert = (raw: string) => koreanFirst === 'search' ? convertKoreanSearch(raw) : koreanFirst ? composeKoreanInput(raw) : raw;
  onValueRef.current = onValue;
  useEffect(() => {
    const restore = (event: Event) => {
      const restored = (event as Event & { restoredValue: string }).restoredValue;
      composing.current = false; setText(restored); onValueRef.current(restored);
    };
    const field = input.current;
    field?.addEventListener(SCANNER_RESTORE_EVENT, restore);
    return () => field?.removeEventListener(SCANNER_RESTORE_EVENT, restore);
  }, []);
  useEffect(() => {
    if (!composing.current) {
      setText(value);
      if (searchBuffer.current.display !== value) searchBuffer.current = { raw: value, display: value };
    }
  }, [value]);
  return <input {...props} ref={input} value={text} lang="ko" inputMode="text" spellCheck={false}
    onCompositionStart={() => { composing.current = true; onTyping?.(); }}
    onCompositionEnd={(event) => {
      composing.current = false;
      const final = event.currentTarget.value;
      searchBuffer.current = { raw: final, display: final };
      setText(final); onValue(final);
    }}
    onChange={(event) => {
      const field = event.currentTarget;
      const raw = field.value;
      const nativeComposition = composing.current || (event.nativeEvent as InputEvent).isComposing;
      // Preserve raw ASCII on append: K → ㅏ, then K9 → K9, never ㅏ9.
      const previous = searchBuffer.current;
      const candidate = koreanFirst === 'search' && raw.startsWith(previous.display)
        && !nativeComposition ? previous.raw + raw.slice(previous.display.length) : raw;
      const next = nativeComposition ? raw : convert(candidate);
      searchBuffer.current = { raw: candidate, display: next };
      const cursor = field.selectionStart;
      setText(next); onTyping?.();
      if (publishImeValue(nativeComposition, koreanFirst)) {
        onValue(next);
        if (next !== raw && cursor !== null) {
          const position = convert(raw.slice(0, cursor)).length;
          requestAnimationFrame(() => {
            if (document.activeElement === field) field.setSelectionRange(position, position);
          });
        }
      }
    }}
    onKeyDown={(event) => {
      if (composing.current || event.nativeEvent.isComposing || event.keyCode === 229)
        event.stopPropagation();
    }} />;
}
