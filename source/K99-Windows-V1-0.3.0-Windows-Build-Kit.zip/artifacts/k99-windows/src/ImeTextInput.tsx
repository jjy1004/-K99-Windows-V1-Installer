import { useEffect, useRef, useState, type ComponentPropsWithoutRef } from 'react';
import { SCANNER_RESTORE_EVENT } from './keyboard-tag-reader';
type Props = Omit<ComponentPropsWithoutRef<'input'>, 'value' | 'onChange'> & {
  value: string; onValue: (value: string) => void; onTyping?: () => void;
};
/** Keep IME-owned text local until composition ends; parent updates must
 * never replace a composing Korean name/address or consume its Enter key. */
export function ImeTextInput({ value, onValue, onTyping, ...props }: Props) {
  const [text, setText] = useState(value);
  const composing = useRef(false);
  const input = useRef<HTMLInputElement>(null);
  const onValueRef = useRef(onValue);
  onValueRef.current = onValue;
  useEffect(() => {
    const restore = (event: Event) => {
      const restored = (event as Event & { restoredValue: string }).restoredValue;
      composing.current = false; setText(restored); onValueRef.current(restored);
    };
    const field = input.current;
    field?.addEventListener(SCANNER_RESTORE_EVENT, restore);
    return () => field?.removeEventListener(SCANNER_RESTORE_EVENT, restore);
  }, []);
  useEffect(() => { if (!composing.current) setText(value); }, [value]);
  return <input {...props} ref={input} value={text} lang="ko" inputMode="text" spellCheck={false}
    onCompositionStart={() => { composing.current = true; onTyping?.(); }}
    onCompositionEnd={(event) => {
      composing.current = false;
      const final = event.currentTarget.value;
      setText(final); onValue(final);
    }}
    onChange={(event) => {
      setText(event.currentTarget.value); onTyping?.();
      if (!composing.current && !(event.nativeEvent as InputEvent).isComposing) onValue(event.currentTarget.value);
    }}
    onKeyDown={(event) => {
      if (composing.current || event.nativeEvent.isComposing || event.keyCode === 229)
        event.stopPropagation();
    }} />;
}
