/** Saved work must be addressed explicitly, never through a shared last-order pointer. */
export function intakeEntryOrderId(search: string): string | null {
  const params = new URLSearchParams(search);
  const id = params.get('orderId');
  if (params.has('orderId') && (!id?.trim() || id.length > 160 || /[\x00-\x1f\x7f]/.test(id)))
    throw new Error('유효한 주문번호가 필요합니다. 관리센터에서 해당 주문을 다시 열어 주세요.');
  if (!id && (params.has('inspection') || params.has('capture') || params.has('garment')))
    throw new Error('작업할 주문번호가 없는 링크입니다. 과거 주문을 자동 선택하지 않습니다. 관리센터에서 해당 주문을 다시 열어 주세요.');
  return id || null;
}

export function savedIntakeUrl(orderId: string, search = ''): string {
  const params = new URLSearchParams(search);
  params.set('orderId', orderId);
  return `/?${params.toString()}`;
}

export function orderWorkspaceUrl(orderId: string, work = '', garmentId?: string): string {
  const params = new URLSearchParams();
  if (work) params.set('work',work);
  if (garmentId) params.set('garment',garmentId);
  return `/orders/${encodeURIComponent(orderId)}${params.size ? `?${params}` : ''}`;
}