import { directoryRequest } from './customer-directory-client';
export type CareLabelResult = {
  id:string;photoId:string;orderId:string;garmentId:string;itemName:string;unitKey:string;
  createdAt:string;completedAt?:string;status:'pending'|'success'|'review'|'failed'|'interrupted';
  materialTag:string;error:string;raw_composition?:string;canPrint:boolean;
  material_group?:'폴리에스테르'|'식물성 혼방'|'울/실크'|'나일론'|null;
  wash_method?:'물세탁'|'드라이세탁'|null;
  color?:string;
  basket:null|{no:string;name:string;color:string};
  autoTag?:{isTagPrinted:boolean;status:string;materialTag?:string;error?:string};
};
export const careLabelResults=()=>directoryRequest<CareLabelResult[]>('GET','/api/care-label/results');
export const finalizeAutomaticTags=(orderId:string)=>
  directoryRequest<{units:import('./NativeDraftCamera').DraftNativeUnit[];warnings:string[]}>('POST','/api/care-label/finalize',{orderId});
