/** Names expose in-progress text for suggestions without replacing the native IME buffer.
 * Publishing shorter text is necessary to invalidate suggestions after deletion. */
export const publishImeValue = (isComposing: boolean, koreanFirst: boolean | 'search') =>
  !isComposing || koreanFirst === true;
