import { useState } from 'react';
import type { CustomerNotification } from './notification-workflow';
import { confirmExternalCustomerSend } from './notification-workflow';
import type { ConfirmedOrder } from './order-record';

export function ExternalSendConfirmation({ order, notification, onConfirm }: {
  order: ConfirmedOrder; notification: CustomerNotification;
  onConfirm: (update: () => ConfirmedOrder) => void;
}) {
  const [staffName, setStaffName] = useState('');
  const [recipient, setRecipient] = useState(order.customerPhone);
  const [channel, setChannel] = useState<'kakao' | 'sms' | 'other'>('kakao');
  const [sentAt, setSentAt] = useState('');
  const [evidence, setEvidence] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const record = notification.externalSendConfirmation;
  if (record) return <p data-testid={`external-send-record-${notification.id}`}>
    외부 발송 직원 확인 · {record.staffName} · 수신 대상 {record.recipient} ·
    {' '}{new Date(record.sentAt).toLocaleString('ko-KR')} · {record.channel}<br />
    확인 근거: {record.evidence}<br />직원 수동 확인 기록이며 서비스 전송·도달 증명이 아닙니다.
  </p>;
  if (!notification.sendPreparationAt) return null;
  return <details data-testid={`external-send-form-${notification.id}`}>
    <summary>외부 카카오톡 등 실제 발송 확인 기록</summary>
    <p>이 버튼은 메시지를 보내지 않습니다. 외부 서비스에서 대상 고객에게 실제 발송한 내용을 확인한 후 기록하세요.</p>
    <label>확인 직원<input value={staffName} onChange={(event) => setStaffName(event.target.value)}
      data-testid={`external-send-staff-${notification.id}`} /></label>
    <label>수신 대상<input value={recipient} onChange={(event) => setRecipient(event.target.value)} /></label>
    <label>외부 발송 채널<select value={channel} onChange={(event) => setChannel(event.target.value as typeof channel)}>
      <option value="kakao">카카오톡</option><option value="sms">문자</option><option value="other">기타</option>
    </select></label>
    <label>실제 발송 시각 · 이 PC의 시간<input type="datetime-local" step="1" value={sentAt}
      onChange={(event) => setSentAt(event.target.value)} data-testid={`external-send-time-${notification.id}`} /></label>
    <label>실제 발송 확인 근거<textarea value={evidence} onChange={(event) => setEvidence(event.target.value)}
      placeholder="대상 고객 대화창·발송 문안·발송 시각을 확인한 내용" data-testid={`external-send-evidence-${notification.id}`} /></label>
    <label><input type="checkbox" checked={confirmed} onChange={(event) => setConfirmed(event.target.checked)}
      data-testid={`external-send-check-${notification.id}`} />위 수신 대상에게 승인 문안이 실제 발송된 것을 외부 서비스에서 확인했습니다.</label>
    <button type="button" disabled={!confirmed || !staffName.trim() || !recipient.trim() || !evidence.trim() || !sentAt}
      data-testid={`button-confirm-external-send-${notification.id}`}
      onClick={() => onConfirm(() => confirmExternalCustomerSend(order, notification.id, {
        staffName, recipient, channel, evidence, sentAt, confirmed,
      }))}>외부 실제 발송 확인 기록 저장 · 전송 버튼 아님</button>
  </details>;
}
