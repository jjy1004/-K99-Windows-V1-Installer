type PricedRow = {
  itemId: string;
  quantity: number;
  generalPrice: number;
  premiumPrice: number;
};

export const isSneakerService = (itemId: string) =>
  itemId === 'sneakers_general' || itemId === 'sneakers_premium';

export function getCombinedBreakdown<T extends PricedRow>(rows: ReadonlyArray<T>) {
  const garments = rows.filter((row) => !isSneakerService(row.itemId));
  const sneakers = rows.filter((row) => isSneakerService(row.itemId));
  const garmentGeneral = garments.reduce((sum, row) => sum + row.generalPrice * row.quantity, 0);
  const garmentPremium = garments.reduce((sum, row) => sum + row.premiumPrice * row.quantity, 0);
  const sneakerTotal = sneakers.reduce((sum, row) => sum + row.generalPrice * row.quantity, 0);
  return {
    garments,
    sneakers,
    garmentGeneral,
    garmentPremium,
    sneakerTotal,
    combinedGeneral: garmentGeneral + sneakerTotal,
    combinedPremium: garmentPremium + sneakerTotal,
  };
}