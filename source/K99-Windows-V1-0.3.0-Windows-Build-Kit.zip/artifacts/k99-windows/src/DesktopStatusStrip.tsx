import { useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { getGetDesktopStatusQueryKey, useGetDesktopStatus } from '@workspace/api-client-react';
import './desktop-status.css';

const MIN = 16;
const MAX = 1024;

function errorText(cause: unknown, fallback: string) {
  const data = (cause as { data?: { error?: unknown; message?: unknown } })?.data;
  if (typeof data?.error === 'string') return data.error;
  if (typeof data?.message === 'string') return data.message;
  if (cause instanceof Error && cause.message) return cause.message;
  return fallback;
}

export function DesktopStatusStrip() {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const status = useGetDesktopStatus({ query: { queryKey: getGetDesktopStatusQueryKey(), refetchInterval: 10000 } });
  const [setupOpen, setSetupOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  if (location.startsWith('/customer')) return null;

  const data = status.data;
  const isDesktop = data ? /electron|desktop/i.test(data.mode) : false;
  const modeLabel = !data ? '확인 중' : isDesktop ? 'Electron 데스크톱' : '브라우저 미리보기';

  async function submit(event: FormEvent) {
    event.preventDefault();
    const value = password;
    const invalid = value.length < MIN ? `관리자 비밀번호는 ${MIN}자 이상이어야 합니다.`
      : value.length > MAX ? `관리자 비밀번호는 ${MAX}자 이하여야 합니다.`
      : value !== confirm ? '비밀번호 확인이 일치하지 않습니다.' : '';
    setPassword(''); setConfirm('');
    if (invalid) { setMessage({ kind: 'error', text: invalid }); return; }
    setBusy(true); setMessage(null);
    try {
      const response = await fetch('/api/desktop/admin/setup', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: value }),
      });
      if (!response.ok) {
        let text = '';
        try { const body = await response.json(); text = body?.error ?? body?.message ?? ''; } catch { /* no body */ }
        throw new Error(text || `관리자 설정 실패 (HTTP ${response.status})`);
      }
      setMessage({ kind: 'ok', text: '이 PC의 관리자 비밀번호를 설정했습니다.' });
      await queryClient.invalidateQueries({ queryKey: getGetDesktopStatusQueryKey() });
    } catch (cause) {
      setMessage({ kind: 'error', text: errorText(cause, '관리자 설정을 완료하지 못했습니다.') });
    } finally { setBusy(false); }
  }

  return (
    <aside className="dstrip" aria-label="Windows V1 실행 상태" data-testid="strip-desktop-status">
      <div className="dstrip__row">
        <span className="dstrip__tag">K99 Windows V1</span>
        {status.isLoading && <span className="dstrip__skel" aria-hidden="true" />}
        {status.isError && (
          <span className="dstrip__err" role="alert" data-testid="text-desktop-status-error">
            상태 확인 실패: {errorText(status.error, '데스크톱 상태를 불러오지 못했습니다.')}
            <button type="button" onClick={() => void status.refetch()} data-testid="button-desktop-status-retry">다시 시도</button>
          </span>
        )}
        {data && <>
          <span className={`dstrip__chip ${isDesktop ? 'is-desktop' : 'is-preview'}`} data-testid="status-desktop-mode">
            <i aria-hidden="true" />{modeLabel}</span>
          <span className="dstrip__chip" data-testid="status-desktop-storage">저장소 {data.storage}</span>
          <span className="dstrip__chip" data-testid="status-desktop-order-count">주문 {data.orderCount.toLocaleString('ko-KR')}건</span>
          <span className="dstrip__chip is-warn" data-testid="status-desktop-price-basis">가격 임시 원본 기준 · {data.priceBasis}</span>
          <span className="dstrip__chip is-warn" role="note" data-testid="status-desktop-hardware">
            {data.hardwareEnabled ? '실제 장비 모드 · 실물 확인 필요' : '모의 장비 모드 · 실제 장비 미사용'}</span>
          {status.isFetching && !status.isLoading && <span className="dstrip__sync">갱신 중</span>}
        </>}
        <button type="button" className="dstrip__toggle" aria-expanded={setupOpen} aria-controls="dstrip-setup"
          onClick={() => { setSetupOpen((v) => !v); setMessage(null); }} data-testid="button-desktop-admin-setup-toggle">
          {setupOpen ? '설정 닫기' : '최초 관리자 설정'}</button>
      </div>
      {data && !data.hardwareEnabled && (
        <p className="dstrip__sr" role="status">모의 장비 기능은 장비·현장 화면에서 검사할 수 있습니다. 실제 장비 동작 검증과 구분됩니다.</p>
      )}
      {setupOpen && (
        <form id="dstrip-setup" className="dstrip__form" onSubmit={submit} autoComplete="off">
          <p>이 PC에서만 사용하는 로컬 관리자 비밀번호입니다. 원격 인증을 사용하지 않습니다. 설정 후 데이터 보존 화면에서 관리자 복구 코드와 백업 복구 키를 발급·보관하세요.</p>
          <label>관리자 비밀번호 · {MIN}자 이상
            <input type="password" autoComplete="new-password" maxLength={MAX} value={password}
              onChange={(e) => setPassword(e.target.value)} data-testid="input-desktop-admin-password" /></label>
          <label>비밀번호 확인
            <input type="password" autoComplete="new-password" maxLength={MAX} value={confirm}
              onChange={(e) => setConfirm(e.target.value)} data-testid="input-desktop-admin-confirm" /></label>
          <button type="submit" disabled={busy} data-testid="button-desktop-admin-setup">{busy ? '설정 중' : '관리자 설정'}</button>
          {message && <span className={`dstrip__msg is-${message.kind}`} role={message.kind === 'error' ? 'alert' : 'status'}
            data-testid="text-desktop-admin-setup-result">{message.text}</span>}
        </form>
      )}
    </aside>
  );
}

export default DesktopStatusStrip;
