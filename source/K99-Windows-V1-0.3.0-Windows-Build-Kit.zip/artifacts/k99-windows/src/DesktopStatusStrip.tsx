import { useLocation } from 'wouter';
import { ApplicationUpdateButton } from './ApplicationUpdateButton';
import { getGetDesktopStatusQueryKey, useGetDesktopStatus } from '@workspace/api-client-react';
import './desktop-status.css';
import { NumUnit } from './NumUnit';

function errorText(cause: unknown, fallback: string) {
  const data = (cause as { data?: { error?: unknown; message?: unknown } })?.data;
  if (typeof data?.error === 'string') return data.error;
  if (typeof data?.message === 'string') return data.message;
  if (cause instanceof Error && cause.message) return cause.message;
  return fallback;
}

export function DesktopStatusStrip() {
  const [location] = useLocation();
  const status = useGetDesktopStatus({ query: { queryKey: getGetDesktopStatusQueryKey(), refetchInterval: 10000 } });

  if (location.startsWith('/customer')) return null;

  const data = status.data;
  const isDesktop = data ? /electron|desktop/i.test(data.mode) : false;
  const modeLabel = !data ? '확인 중' : isDesktop ? '매장 PC 프로그램' : '인터넷 미리보기';

  return (
    <aside className="dstrip" aria-label="매장 프로그램 실행 상태" data-testid="strip-desktop-status">
      <div className="dstrip__row">
        <span className="dstrip__tag" data-testid="text-build-patch-id">K99 스마트 접수 시스템 버전 2 (K99 Laundry V2)</span>
        {status.isLoading && <span className="dstrip__skel" aria-hidden="true" />}
        {status.isError && (
          <span className="dstrip__err" role="alert" data-testid="text-desktop-status-error">
            상태 확인 실패: {errorText(status.error, '데스크톱 상태를 불러오지 못했습니다.')}
            <button type="button" onClick={() => void status.refetch()} data-testid="button-desktop-status-retry">다시 시도</button>
          </span>
        )}
        {data && <>
          <span className={`dstrip__chip ${isDesktop ? 'is-desktop' : 'is-preview'}`} data-testid="status-desktop-mode">
            <i aria-hidden="true" />{modeLabel}</span>
          <span className="dstrip__chip" data-testid="status-desktop-storage">매장 장부</span>
          <span className="dstrip__chip" data-testid="status-desktop-order-count">주문 <NumUnit>{data.orderCount.toLocaleString('ko-KR')}건</NumUnit></span>
          <span className="dstrip__chip" data-testid="status-desktop-price-basis">세탁비는 통합관리센터에서 수정</span>
          <span className="dstrip__chip is-warn" role="note" data-testid="status-desktop-hardware">
            {data.hardwareEnabled ? '매장 장치 설정 사용' : '매장 장치는 설치 프로그램에서 연결'}</span>
          {status.isFetching && !status.isLoading && <span className="dstrip__sync">갱신 중</span>}
        </>}
        <ApplicationUpdateButton />
      </div>
    </aside>
  );
}

export default DesktopStatusStrip;
