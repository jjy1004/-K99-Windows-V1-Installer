import { Link, useLocation } from 'wouter';
import { getGetDesktopStatusQueryKey, useGetDesktopStatus } from '@workspace/api-client-react';
import './desktop-status.css';

function errorText(cause: unknown, fallback: string) {
  const data = (cause as { data?: { error?: unknown; message?: unknown } })?.data;
  if (typeof data?.error === 'string') return data.error;
  if (typeof data?.message === 'string') return data.message;
  if (cause instanceof Error && cause.message) return cause.message;
  return fallback;
}

export function DesktopStatusStrip() {
  const [location] = useLocation();
  const status = useGetDesktopStatus({ query: { queryKey: getGetDesktopStatusQueryKey(), refetchInterval: 10000 } });

  if (location.startsWith('/customer')) return null;

  const data = status.data;
  const isDesktop = data ? /electron|desktop/i.test(data.mode) : false;
  const modeLabel = !data ? '확인 중' : isDesktop ? 'Electron 데스크톱' : '브라우저 미리보기';

  return (
    <aside className="dstrip" aria-label="Windows V1 실행 상태" data-testid="strip-desktop-status">
      <div className="dstrip__row">
        <span className="dstrip__tag" data-testid="text-build-patch-id">K99 Windows V1 · V2-TODAY-IME-20261105</span>
        {status.isLoading && <span className="dstrip__skel" aria-hidden="true" />}
        {status.isError && (
          <span className="dstrip__err" role="alert" data-testid="text-desktop-status-error">
            상태 확인 실패: {errorText(status.error, '데스크톱 상태를 불러오지 못했습니다.')}
            <button type="button" onClick={() => void status.refetch()} data-testid="button-desktop-status-retry">다시 시도</button>
          </span>
        )}
        {data && <>
          <span className={`dstrip__chip ${isDesktop ? 'is-desktop' : 'is-preview'}`} data-testid="status-desktop-mode">
            <i aria-hidden="true" />{modeLabel}</span>
          <span className="dstrip__chip" data-testid="status-desktop-storage">저장소 {data.storage}</span>
          <span className="dstrip__chip" data-testid="status-desktop-order-count">주문 {data.orderCount.toLocaleString('ko-KR')}건</span>
          <span className="dstrip__chip is-warn" data-testid="status-desktop-price-basis">가격 임시 원본 기준 · {data.priceBasis}</span>
          <span className="dstrip__chip is-warn" role="note" data-testid="status-desktop-hardware">
            {data.hardwareEnabled ? '실제 장비 모드 · 실물 확인 필요' : '모의 장비 모드 · 실제 장비 미사용'}</span>
          {status.isFetching && !status.isLoading && <span className="dstrip__sync">갱신 중</span>}
        </>}
        <Link href="/maintenance" className="dstrip__toggle" data-testid="button-desktop-admin-setup-toggle">
          관리자 설정</Link>
      </div>
      {data && !data.hardwareEnabled && (
        <p className="dstrip__sr" role="status">모의 장비 기능은 장비·현장 화면에서 검사할 수 있습니다. 실제 장비 동작 검증과 구분됩니다.</p>
      )}
    </aside>
  );
}

export default DesktopStatusStrip;
