import { directoryRequest } from './customer-directory-client';
import {noticeDeliveryChanged} from './notice-api';
export type NoticeKind = 'direct-pickup' | 'delivery' | 'day7' | 'day12';
export type NoticeCard = {
  kind: NoticeKind; title: string; text: string; sentAt: string | null;
  recommended: boolean; canMark: boolean; sentKind?: NoticeKind;blockedReason?:string;
};
export type NoticeOrder = {
  payment_type?: import('./order-payment').PaymentType;
  payment_status?: import('./order-payment').PaymentState;
  estimatedTotal?: number;
  orderId: string; customerName: string; customerPhone: string; intakeDate: string;
  itemCount: number; elapsedDays: number; completedAt: string; deliveryRequested: boolean; cards: NoticeCard[];
};
export type NoticeList = { orders: NoticeOrder[]; recommendedCount: number; asOf: string };
export const listPickupNotices = () => directoryRequest<NoticeList>('GET', '/api/pickup-notices');
export const markPickupNotice = async(orderId: string, kind: NoticeKind, messageText: string, source?:'button-click') =>{
  const result=await directoryRequest<NoticeList>('POST', '/api/pickup-notices/mark', { orderId, kind, messageText,
    ...(source?{source}:{confirmedExternalSend:true}) });
  if(typeof window.dispatchEvent==='function')noticeDeliveryChanged();
  return result;
};
