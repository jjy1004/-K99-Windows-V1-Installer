// 그림 카드뉴스 설명서 데이터. captureId 가 있으면 실제 화면 캡처(public/guide-captures), diagram 은 안내 도해.
export type GuideDevice = 'pc' | 'phone';
export type GuideCard = {
  title: string; body: string; device: GuideDevice; bar: string; rows: string[]; hit: number; warn?: boolean;
  /** 휴대폰 설명 그림 종류(없으면 기존 목록 그림) */
  phoneScene?: PhoneScene;
  /** 실제 캡처 이름(manifest.json 의 captures 키). 있으면 실제 화면 사진을 우선 사용 */
  captureId?: CaptureId;
  /** manifest 안 실제 버튼 좌표 id. 순서대로 1,2,3 번호를 붙임. 없으면 표시 안 함 */
  targetKeys?: string[];
  /** 실제 캡처가 불가능한 외부 기기 화면: '안내 도해' 라벨 고정 */
  diagram?: boolean;
};
export type CaptureId = 'main' | 'settings' | 'hardware' | 'receipt' | 'phone' | 'owner' | 'tag' | 'excel' | 'backup' | 'ai-login' | 'ai-home';
export type PhoneScene = 'home' | 'settings' | 'connections' | 'tethering' | 'iriun' | 'brightness' | 'battery80' | 'lockCompare' | 'allow' | 'appbattery' | 'recents';
export type GuideTopic = { id: string; title: string; cards: GuideCard[] };
/** titleLines·summaryLines: 단어가 한 글자씩 잘리지 않도록 명시 줄바꿈 */
export type GuideTheme = { id: string; title: string; summary: string; titleLines: string[]; summaryLines: string[]; topics: GuideTopic[] };

export const AI_URL = 'https://k-99-washcare-ai.replit.app';
const AI_HOST = 'k-99-washcare-ai.replit.app';
const x = (card: GuideCard, extra: Partial<GuideCard>): GuideCard => ({ ...card, ...extra });
const c = (title: string, body: string, device: GuideDevice, bar: string, rows: string[], hit: number, warn = false, phoneScene?: PhoneScene): GuideCard =>
  ({ title, body, device, bar, rows, hit, warn, ...(phoneScene ? { phoneScene } : {}) });

export const GUIDE_THEMES: GuideTheme[] = [
  { id: 'ai', title: '휴대폰 AI 도우미', summary: '홈 화면 바로가기 · AI 사용법', titleLines: ['휴대폰', 'AI 도우미'], summaryLines: ['홈 화면 바로가기', 'AI 사용법'], topics: [
    { id: 'home', title: '홈 화면 바로가기 만들기', cards: [
      x(c('받은 링크 누르기', `카톡이나 문자로 받은 ${AI_HOST} 링크를 손가락으로 한 번 누릅니다. 주소를 직접 입력하거나 점 세 개(⋮) 메뉴를 찾지 않아도 됩니다.`, 'phone', '카카오톡 대화', ['K99 세탁 AI 링크', AI_HOST], 1), { diagram: true }),
      x(c('홈 화면 설치 안내 열기', '① 열린 앱에서 [휴대폰 홈 화면 앱 아이콘 설치 안내]를 누르세요 → ② 앱에서 [홈 화면 바로가기]가 표시되면 누르세요. 현재 공개 화면에서는 설치 안내 링크까지만 확인했습니다. 실제 휴대폰의 바로가기 추가 화면은 현장 사진을 받아 안내를 완성합니다.', 'phone', 'K99 세탁 AI', ['휴대폰 홈 화면 앱 아이콘 설치 안내'], 0), { captureId: 'ai-home', targetKeys: ['homeShortcut'] }),
      x(c('홈의 K99 아이콘 누르기', '휴대폰 홈 화면에 생긴 K99 아이콘을 누르면 다음부터 링크 없이 바로 열립니다.', 'phone', '홈 화면', ['전화', '문자', 'K99', '카메라'], 2), { diagram: true }),
      x(c('로그인하기', '첫째 칸에 본인 휴대폰 번호를 넣습니다. 둘째 칸은 처음이면 영문 소문자 k + 휴대폰 뒷자리 4개(예: k1234), 비밀번호를 바꾼 분은 본인 비밀번호(5~20자리)를 넣고 [로그인]을 누릅니다.', 'phone', AI_HOST, ['휴대폰 번호', '비밀번호', '로그인'], 2), { captureId: 'ai-login', targetKeys: ['phone', 'password', 'login'] }),
    ] },
    { id: 'use', title: 'AI 세탁 도우미 사용하기', cards: [
      x(c('세탁 라벨 촬영', '옷 안쪽 세탁 라벨(케어라벨)을 화면 가운데 맞추고 촬영 단추를 누릅니다.', 'phone', '라벨 촬영', ['라벨을 네모 안에', '촬영하기'], 1), { diagram: true }),
      x(c('얼룩 사진 올리기', '① 얼룩 사진을 올리는 버튼을 누르세요 → ② 얼룩이 선명하게 보이도록 찍으세요 → ③ 사진을 확인하세요. 로그인 이후 실제 화면 사진은 추가 확인이 필요합니다.', 'phone', '얼룩 사진', ['얼룩 사진 올리기', '사진 확인'], 0), { diagram: true }),
      x(c('질문 또는 얼룩 사진', '궁금한 점을 글로 적거나 얼룩 부분 사진을 함께 올립니다.', 'phone', '질문하기', ['질문 적기', '얼룩 사진 올리기', '보내기'], 2), { diagram: true }),
      x(c('결과 확인', 'AI 결과는 참고용입니다. 최종 세탁 방법은 점주님이 옷 상태를 직접 보고 판단하세요.', 'phone', '결과', ['세탁 방법 안내', '주의할 점', '다시 묻기'], 0), { diagram: true }),
    ] },
  ] },
  { id: 'pc', title: 'PC 프로그램 설치', summary: '내려받기부터 바탕화면 아이콘까지', titleLines: ['PC 프로그램', '설치'], summaryLines: ['내려받기부터', '바탕화면 아이콘까지'], topics: [
    { id: 'install', title: 'PC 설치 5단계', cards: [
      x(c('설치 안내 페이지 접속', '본사에서 알려준 공식 주소로만 접속합니다. 모르는 문자·메일 속 링크는 누르지 마세요.', 'pc', '공식 설치 안내 주소', ['K99 스마트 접수', 'Windows용 내려받기'], 1), { diagram: true }),
      x(c('설치 파일 내려받기', '[Windows용 내려받기]를 누르고 다운로드 폴더에 저장된 파일을 확인합니다.', 'pc', '다운로드', ['K99 설치 파일', '폴더 열기'], 0), { diagram: true }),
      x(c("'추가 정보'가 뜨면", "Windows 보호 창이 뜨면 '추가 정보'를 누릅니다. 출처를 확인한 공식 설치본일 때만 진행하세요.", 'pc', 'Windows의 PC 보호', ['추가 정보', '실행 안 함'], 0, true), { diagram: true }),
      x(c('실행 누르기', "공식 설치본이 맞다면 '실행'을 누르고 안내에 따라 설치를 끝까지 진행합니다.", 'pc', 'Windows의 PC 보호', ['게시자 확인', '실행', '실행 안 함'], 1, true), { diagram: true }),
      x(c('바탕화면 아이콘', '바탕화면에 생긴 K99 아이콘을 두 번 눌러 프로그램을 엽니다. 기존 자료는 그대로 유지됩니다.', 'pc', '바탕화면', ['휴지통', 'K99 스마트 접수', '내 PC'], 1), { diagram: true }),
    ] },
  ] },
  { id: 'setup', title: '장비 · 매장 설정', summary: '촬영 휴대폰 · 수기택 · 영수증 · 보안', titleLines: ['장비 · 매장', '설정'], summaryLines: ['촬영 휴대폰 · 수기택', '· 영수증 · 보안'], topics: [
    { id: 'menu', title: '설정 5대 메뉴 들어가기', cards: [
      x(c('설정 열기', "접수 화면 위쪽의 '매장 맞춤 설정'을 누릅니다.", 'pc', 'K99 스마트 접수', ['도움말', '매장 맞춤 설정'], 1), { captureId: 'main', targetKeys: ['settings'] }),
      x(c('5개 큰 그림 중 고르기', '매장정보 · 가격정책 · 점주/관리자 · 하드웨어 · 휴대폰연결 중 필요한 것을 누릅니다. 뒤로가기로 언제든 돌아옵니다.', 'pc', '매장 맞춤 설정', ['매장정보', '가격정책', '점주·관리자', '하드웨어', '휴대폰연결'], 3), { captureId: 'settings', targetKeys: ['hardware'] }),
    ] },
    { id: 'usb', title: '촬영 휴대폰 USB 연결', cards: [
      x(c('케이블 연결', '데이터 전송이 되는 USB 케이블로 휴대폰과 PC를 연결합니다. 충전 전용 케이블은 연결되지 않을 수 있습니다.', 'pc', 'USB 연결', ['휴대폰 ─ 케이블 ─ PC'], 0), { diagram: true }),
      x(c('휴대폰 설정 열기', '휴대폰 홈 화면에서 톱니 모양 설정 앱을 누릅니다.', 'phone', '휴대폰 홈 화면', ['설정', '카메라', 'Iriun Webcam'], 0, false, 'home'), { diagram: true }),
      x(c('연결 누르기', "'연결'을 누릅니다. 브랜드·기종에 따라 '네트워크 및 인터넷' 등으로 표시됩니다.", 'phone', '설정', ['연결', '디스플레이', '배터리', '애플리케이션'], 0, false, 'settings'), { diagram: true }),
      x(c('모바일 핫스팟 및 테더링', "연결 화면에서 '모바일 핫스팟 및 테더링'을 누릅니다. 기종에 따라 '테더링'만 보일 수 있습니다.", 'phone', '연결', ['Wi-Fi', '모바일 핫스팟 및 테더링'], 1, false, 'connections'), { diagram: true }),
      x(c('USB 테더링 또는 앱 설정', 'Iriun 앱 안내에 따라 USB 테더링 등 필요한 설정을 켭니다. USB 테더링만으로 연결이 보장되지는 않습니다.', 'phone', '테더링', ['모바일 핫스팟', 'Bluetooth 테더링', 'USB 테더링'], 2, true, 'tethering'), { diagram: true }),
      x(c('아침에 Iriun 켜기', '출근 후 휴대폰에서 Iriun Webcam 앱을 한 번 켜 둡니다. PC 촬영 창을 열면 연결을 시도합니다.', 'phone', '앱', ['Iriun Webcam', '카메라', '갤러리'], 0, false, 'iriun'), { diagram: true }),
    ] },
    { id: 'heat', title: '촬영 휴대폰 발열 줄이기', cards: [
      x(c('화면 밝기 낮추기', '촬영 휴대폰 화면 밝기를 낮추면 열이 덜 납니다.', 'phone', '디스플레이', ['밝기', '자동 밝기'], 0, false, 'brightness'), { diagram: true }),
      x(c('배터리 보호 (지원 시)', "'배터리 보호 · 최대 80%' 기능이 있는 휴대폰만 켜세요. 메뉴가 없는 휴대폰도 있습니다.", 'phone', '배터리 보호', ['기본', '적응형', '최대 80%'], 2, true, 'battery80'), { diagram: true }),
      x(c('불필요한 앱만 닫기', '쓰지 않는 앱만 닫으세요. Iriun Webcam 앱은 닫지 말고 켜 두어야 촬영이 됩니다.', 'phone', '최근 앱', ['게임 (닫기)', '동영상 (닫기)', 'Iriun (유지)'], 2, true, 'recents'), { diagram: true }),
    ] },
    { id: 'storephone', title: '매장 휴대폰 연결 유지', cards: [
      x(c('화면 잠금 풀기', '연결할 때는 휴대폰 화면 잠금을 풀어 둡니다.', 'phone', '잠금 화면', ['위로 밀어 잠금 해제'], 0, false, 'lockCompare'), { diagram: true }),
      x(c('허용·연결 창 확인', 'PC와 연결할 때 뜨는 허용·연결 창을 확인하고, 우리 매장 PC일 때만 허용합니다.', 'phone', '연결 요청', ['연결 허용', '취소'], 0, true, 'allow'), { diagram: true }),
      x(c('백그라운드 유지', '앱 정보 > 배터리에서 사용 제한을 풀면 연결이 덜 끊깁니다. 메뉴 이름은 휴대폰마다 다릅니다.', 'phone', '앱 정보', ['배터리', '제한 없음', '최적화'], 1, false, 'appbattery'), { diagram: true }),
    ] },
    { id: 'owner', title: '점주 보안', cards: [
      x(c('점주 정보 처음 등록하기', '① [매장 맞춤 설정] → [매장 점주·관리자]를 누르세요 → ② 본인 휴대폰 번호와 생년월일 6자리를 입력하세요 → ③ [새 방식으로 전환하기]를 누르세요. Windows 설치 앱에서만 저장됩니다. 기존 고객 자료는 삭제하지 않습니다.', 'pc', '점주·관리자', ['본인 휴대폰 번호', '새 방식으로 전환하기'], 0, true), { captureId: 'owner', targetKeys: ['adminPassword','adminConfirm'] }),
      x(c('나만의 비밀번호로 바꾸기', '① 등록 후 [비밀번호 바꾸기]를 누르세요 → ② 현재 비밀번호와 새 비밀번호를 입력하세요 → ③ 새 비밀번호를 한 번 더 입력하고 저장하세요. 비밀번호를 직원과 공유하지 마세요. 이 사진은 최초 등록 화면입니다.', 'pc', '관리자 확인', ['현재 비밀번호', '새 비밀번호', '저장'], 0, true), { captureId: 'owner', targetKeys: [] }),
      x(c('자리 비울 때', '자리를 비울 때는 고객 정보 창을 닫아 두세요.', 'pc', 'K99 스마트 접수', ['고객 명부 닫기'], 0), { captureId: 'main', targetKeys: [] }),
    ] },
    { id: 'manualtag', title: '수기택 번호', cards: [
      x(c('고객 1번의 품목 번호', '첫 고객이 2벌이면 1-1, 1-2 로 적습니다. 앞 숫자는 고객 번호, 뒤 숫자는 품목 순서입니다.', 'pc', '수기택', ['1-1 셔츠', '1-2 바지'], 0), { captureId: 'tag', targetKeys: [] }),
      x(c('다음 고객과 번호 바꾸기', '다음 고객은 2-1 부터 시작합니다. 시작 고객 번호는 하드웨어 > 라벨에서 바꿀 수 있고, 이미 쓴 번호는 바뀌지 않습니다.', 'pc', '라벨 설정', ['다음 고객 번호', '2', '저장'], 1), { captureId: 'tag', targetKeys: ['customerNumber','save'] }),
    ] },
    { id: 'receipt', title: '영수증 출력기', cards: [
      x(c('회사 버튼으로 출력기 고르기', '① [하드웨어 설정] → [카드 단말기·영수증 출력기]를 누르세요 → ② 매장 단말기 회사를 누르세요 → ③ 자동 선택 안내를 확인하세요. 찾지 못하면 [일반 영수증 프린터 상세 설정]을 누르세요. 이미 선택된 회사를 다시 누르면 미사용입니다. 카드 승인은 별도입니다.', 'pc', '카드단말기·영수증', ['이지체크 / KICC', 'KIS정보통신', 'NICE / 스마트로'], 0), { captureId: 'receipt', targetKeys: ['easycheck','details'] }),
      x(c('홍보 문구 2줄', '영수증 최상단에 넣을 홍보 문구를 최대 2줄 적습니다. 비워 두면 넣지 않습니다. 저장 → 미리보기 → 테스트 인쇄 순서로 확인합니다.', 'pc', '영수증 문구', ['1줄 문구', '2줄 문구', '저장', '미리보기'], 2), { captureId: 'receipt', targetKeys: ['promoLine1','save'] }),
    ] },
  ] },
  { id: 'work', title: '실전 접수', summary: '전화번호 뒷자리부터 출고까지', titleLines: ['실전 접수'], summaryLines: ['전화번호 뒷자리부터', '출고까지'], topics: [
    { id: 'flow', title: '접수 6단계', cards: [
      x(c('전화 뒷자리 4개', '고객 전화번호 뒷자리 4개로 찾고, 없으면 이름과 번호를 새로 적습니다.', 'pc', '고객 찾기', ['전화 뒷자리 4자리', '찾기'], 0), { captureId: 'main', targetKeys: ['phoneSearch'] }),
      x(c('품목 고르기 · 자유 기재', "목록에 없으면 맨 아래 '기타 (자유 기재)' 칸에 품목명과 금액을 적고 + 를 누릅니다.", 'pc', '세탁물 품목', ['품목 선택', '세탁물 품목명', '금액 입력', '+ 자유 품목 추가'], 3), { captureId: 'main', targetKeys: ['freeItem'] }),
      x(c('결제 · 접수증', '선불·후불을 고르고 [접수증 출력]을 누릅니다. 접수증 인쇄와 카드 단말기 승인은 별개입니다. 단말기 승인 연동은 아직 검증되지 않았으니 결제 승인은 단말기 화면에서 직접 확인하세요.', 'pc', '결제 구분', ['선불', '후불', '접수증 출력'], 2, true), { captureId: 'main', targetKeys: ['receiptPrint'] }),
      x(c('여러 벌 촬영', '촬영 창에서 옷을 하나씩 고르고 발판(F7/F8/F9)이나 촬영 단추로 찍습니다.', 'pc', '촬영 창', ['1번 옷', '2번 옷', '촬영'], 2), { captureId: 'main', targetKeys: ['captureOpen'] }),
      x(c('완료 알림 보내기', '세탁이 끝나면 고객 메시지 편집에서 안내문을 고르고 직접 확인 후 보냅니다.', 'pc', '고객 메시지', ['안내문 고르기', '보낼 글', '카톡 준비'], 2), { captureId: 'main', targetKeys: [] }),
      x(c('출고', '고객이 찾아가면 출고 처리합니다. 후불이면 결제를 먼저 확인합니다.', 'pc', '출고', ['결제 확인', '출고 완료'], 1), { captureId: 'main', targetKeys: [] }),
    ] },
  ] },
  { id: 'excel', title: '엑셀 · 백업', summary: '고객 명부 엑셀과 전체 백업은 다릅니다', titleLines: ['엑셀 · 백업'], summaryLines: ['고객 명부 엑셀과', '전체 백업은 다릅니다'], topics: [
    { id: 'ledger', title: '고객 엑셀 · 전체 백업', cards: [
      x(c('엑셀 칸 순서 확인', '통합관리센터 > 고객 명부에서 [엑셀 열 구성 예시]를 보고 같은 칸 순서로 엑셀을 만듭니다.', 'pc', '고객 명부', ['엑셀 열 구성 예시', '엑셀 가져오기'], 0), { captureId: 'excel', targetKeys: ['excelExample'] }),
      x(c('필수 칸 채우기', '고객명과 전화번호는 꼭 적습니다. 주소는 선택입니다.', 'pc', '엑셀', ['고객명 (필수)', '전화번호 (필수)', '주소 (선택)'], 1), { diagram: true }),
      x(c('가져오기', '[엑셀 가져오기]로 채운 엑셀을 고릅니다. 고객 명부만 추가되고 기존 주문은 바뀌지 않습니다.', 'pc', '고객 명부', ['엑셀 열 구성 예시', '엑셀 가져오기'], 1), { captureId: 'excel', targetKeys: ['excelImport'] }),
      x(c('전체 백업은 따로', '전체 백업은 주문·사진 정보까지 담은 복원용 파일로, 고객 엑셀과 다릅니다. 내보내기는 관리자 확인이 필요하며 보안 정책이 바뀔 수 있습니다.', 'pc', '전체 백업', ['전체 백업 만들기', '복원'], 0, true), { captureId: 'backup', targetKeys: ['backupCreate'] }),
    ] },
  ] },
];

export const OPEN_GUIDE_EVENT = 'k99-open-guide';
export function openGuide(theme?: string, topic?: string) {
  window.dispatchEvent(new CustomEvent(OPEN_GUIDE_EVENT, { detail: { theme, topic } }));
}
