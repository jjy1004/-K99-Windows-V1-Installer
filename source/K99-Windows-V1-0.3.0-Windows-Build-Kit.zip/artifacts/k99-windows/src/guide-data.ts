import manifest from './reception-help.json';
import usageManual from './usage-help.json';

export type GuidePage = {name:string;path:string;bytes:number;sha256:string;width:number;height:number};
export type GuideEntry = {name:string;path:string;kind:'folder'|'image';pages:GuidePage[]};
/** Existing ZIP order and original names stay intact; the added manual has its own sorted index. */
export const RECEPTION_HELP = manifest.entries as GuideEntry[];
export const RECEPTION_HELP_WITH_USAGE = [...RECEPTION_HELP,usageManual] as GuideEntry[];
export const OPEN_GUIDE_EVENT = 'k99-open-guide';
export function guideImageUrl(page:GuidePage):string {
  return `${import.meta.env?.BASE_URL ?? './'}images/${page.path.split('/').map(encodeURIComponent).join('/')}`;
}
/** Old entry-point arguments remain accepted and open the preserved index plus added manuals. */
export function openGuide(_theme?:string,_topic?:string) {
  window.dispatchEvent(new CustomEvent(OPEN_GUIDE_EVENT));
}

/** Shared camera-guide data contract; not a help topic or resource. */
export type GuideCard = {
  title:string;body:string;device:'pc'|'phone';bar:string;rows:string[];hit:number;warn?:boolean;
  diagram?:boolean;phoneScene?:string;
};
