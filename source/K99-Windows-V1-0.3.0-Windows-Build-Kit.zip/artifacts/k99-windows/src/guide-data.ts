import manifest from './reception-help.json';

export type GuidePage = {name:string;path:string;bytes:number;sha256:string;width:number;height:number};
export type GuideEntry = {name:string;path:string;kind:'folder'|'image';pages:GuidePage[]};
/** ZIP central-directory order, original spelling and nested paths. Never sort or rename. */
export const RECEPTION_HELP = manifest.entries as GuideEntry[];
export const OPEN_GUIDE_EVENT = 'k99-open-guide';
export function guideImageUrl(page:GuidePage):string {
  return `${import.meta.env?.BASE_URL ?? './'}images/${page.path.split('/').map(encodeURIComponent).join('/')}`;
}
/** Old entry-point arguments remain accepted; removed topics open the new six-item index. */
export function openGuide(_theme?:string,_topic?:string) {
  window.dispatchEvent(new CustomEvent(OPEN_GUIDE_EVENT));
}

/** Shared camera-guide data contract; not a help topic or resource. */
export type GuideCard = {
  title:string;body:string;device:'pc'|'phone';bar:string;rows:string[];hit:number;warn?:boolean;
  diagram?:boolean;phoneScene?:string;
};
