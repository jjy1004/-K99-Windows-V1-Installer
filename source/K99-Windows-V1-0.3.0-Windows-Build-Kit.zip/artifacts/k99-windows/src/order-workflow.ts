import type { ConfirmedOrder } from './order-record';
import { readConfirmedOrders, updateSavedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';
import { listGarments } from './garment-scanner';
import { advanceGarmentInOrder, garmentProcessStatus } from './laundry-process';
import { advanceOrderStage, currentOperations } from './order-operations';
import { completeInspection, INSPECTION_FIELDS, type ActualCleaningMethod } from './inspection-record';
import { reviewClassification } from './item-intake-details';
import { hasIntakeConcern, normalApprovalSignature, normalGarmentApproved, specialistRequired } from './normal-inspection-policy';

export type WorkflowStage = 'intake' | 'prewash' | 'postwash' | 'final';
export type WorkflowBatchAction = 'start' | 'complete' | 'postwash' | 'final';
export const WORKFLOW_STAGES: readonly { key: WorkflowStage; label: string }[] = [
  { key: 'intake', label: '접수' }, { key: 'prewash', label: '세탁 전' },
  { key: 'postwash', label: '세탁 후' }, { key: 'final', label: '완료 검수' },
];
const fields = (values: string[][]) => values.map(([key, label]) => ({ key, label }));
export const WORKFLOW_FIELDS: Record<WorkflowStage, readonly { key: string; label: string }[]> = {
  intake: fields([['label','소재/케어라벨'],['stain','얼룩'],['damage','손상'],['color','변색/이염 위험'],
    ['accessories','부속품'],['luxury','명품 여부'],['price','가격변경'],['consent','고객 고지/동의']]),
  prewash: fields([['method','세탁방법 확인'],['stain','얼룩 전처리'],['color','색빠짐/이염 위험'],
    ['damage','손상 위험'],['accessories','부속품 제거/보호'],['special','특수처리 필요'],['consent','고객 추가확인']]),
  postwash: fields([['stain','얼룩 제거상태'],['color','변색/이염'],['shape','형태변형'],['damage','손상'],
    ['rewash','재세탁 필요'],['finish','다림질/마무리'],['photo','사진 기록 필요']]),
  final: fields([['appearance','최종 외관'],['stain','얼룩/손상 최종확인'],['accessories','부속품'],
    ['packaging','포장'],['photo','완성사진'],['notice','고객 안내'],['handover','출고 가능 여부']]),
};
const cycle = (g: GarmentRecord) => g.rewashCount ?? 0;
export function workflowReviewFor(g: GarmentRecord, stage: WorkflowStage) {
  const review = g.workflowReviews?.[stage];
  return review?.cycle === cycle(g) ? review : undefined;
}
function baselineIssues(order: ConfirmedOrder, g: GarmentRecord, stage: WorkflowStage) {
  const issues: {key: string; label: string}[] = [];
  const add = (key: string, label: string) => issues.push({key,label});
  const item = order.items[g.itemIndex - 1];
  const d = item?.intakeDetails;
  if (stage === 'prewash') {
    if (hasIntakeConcern(d?.stain)) add('stain', `얼룩 상태 확인: ${d!.stain}`);
    if (hasIntakeConcern(d?.damage)) add('damage', `손상 확인: ${d!.damage}`);
    if (/(이염|색빠짐|변색)/.test(d?.color ?? '')) add('color', `이염 위험 확인: ${d?.color}`);
    if (d && reviewClassification(item.itemId, d).requiresReview)
      add('special', `소재·고가품 등 전문 확인: ${reviewClassification(item.itemId,d).reasons.join(', ') || '직원 확인 필요'}`);
    if (!order.inspection && order.choices.luxuryItem) add('special', '명품 전문검수 필요');
    if (!order.inspection && hasIntakeConcern(order.choices.customerRequests))
      add('consent', `고객 요청 확인: ${order.choices.customerRequests}`);
    if (stage === 'prewash') {
      const inspected = order.inspection?.items[g.itemIndex - 1];
      for (const [field, rating] of Object.entries(inspected?.checks ?? {})) {
        if (rating === '주의' || rating === '문제 있음') add(
          /얼룩|오염/.test(field) ? 'stain' : /손상/.test(field) ? 'damage' : /이염|변색/.test(field) ? 'color' : 'special',
          `${field} 확인${inspected?.memo ? `: ${inspected.memo}` : ''}`);
      }
    }
  }
  if ((stage === 'postwash' || stage === 'final') && g.qcHoldReason) add('damage', `추가 확인: ${g.qcHoldReason}`);
  if (stage === 'final' && g.completionComment?.trim()) add('notice', `고객 안내: ${g.completionComment}`);
  return issues;
}
function signature(order: ConfirmedOrder, g: GarmentRecord, stage: WorkflowStage): string {
  return JSON.stringify([baselineIssues(order,g,stage), order.inspection?.inspectedAt ?? '',
    order.items[g.itemIndex - 1]?.intakeDetails ?? null]);
}
export function getWorkflowIssues(order: ConfirmedOrder, g: GarmentRecord, stage: WorkflowStage) {
  const review = workflowReviewFor(g,stage);
  const base = baselineIssues(order,g,stage);
  if (review?.completedAt && review.signature === signature(order,g,stage) && !g.qcHoldReason) return [];
  return [...base, ...(review?.selected ?? []).map((key) => ({
    key, label: WORKFLOW_FIELDS[stage].find((field) => field.key === key)?.label ?? key,
  }))].filter((issue,index,all) => all.findIndex((other) => other.key === issue.key && other.label === issue.label) === index);
}
export function workflowStageState(order: ConfirmedOrder, g: GarmentRecord, stage: WorkflowStage): 'done'|'attention'|'pending' {
  const status = garmentProcessStatus(order,g);
  const issues = getWorkflowIssues(order,g,stage);
  if (stage === 'intake') return ['세탁 중','세탁 완료','완성 검수','출고 대기','반출 완료'].includes(status)
    ? 'done' : issues.length ? 'attention' : 'done';
  const passed = stage === 'prewash'
    ? ['세탁 중','세탁 완료','완성 검수','출고 대기','반출 완료'].includes(status)
    : stage === 'postwash' ? ['완성 검수','출고 대기','반출 완료'].includes(status)
    : ['출고 대기','반출 완료'].includes(status);
  if (passed) return 'done';
  const current = stage === 'prewash' ? !['세탁 중','세탁 완료','완성 검수','출고 대기','반출 완료'].includes(status)
    : stage === 'postwash' ? status === '세탁 완료' : status === '완성 검수';
  return current && issues.length ? 'attention' : 'pending';
}
function criticalInspectionRequired(order: ConfirmedOrder): boolean {
  return listGarments(order).some(garment => specialistRequired(order, garment));
}
function globalBlocker(order: ConfirmedOrder): string {
  const ops = currentOperations(order);
  if (ops.cancelledAt) return '취소된 주문은 진행할 수 없습니다.';
  if (ops.completedAt || ['배달중','배달완료','매장수령완료'].includes(ops.stage)) return '출고된 주문은 진행할 수 없습니다.';
  if (!['매장입고','세탁중','세탁완료'].includes(ops.stage)) return '매장 입고 확인이 필요합니다.';
  const everyGarmentNeedsApproval = listGarments(order).every(garment => specialistRequired(order, garment));
  if (order.inspection && everyGarmentNeedsApproval && !['세탁 진행 승인','전체 세탁 완료 / 반출 대기'].includes(order.status))
    return '전문검수·고객 동의가 필요합니다. 고객 확인 화면에서 처리해 주세요.';
  if (!order.inspection && everyGarmentNeedsApproval)
    return '전문검수·고객 요청/위험/가격 확인이 필요합니다. 고객 확인 화면에서 처리해 주세요.';
  return '';
}
const actionStage: Record<WorkflowBatchAction,WorkflowStage | undefined> = {
  start:'prewash', complete:undefined, postwash:'postwash', final:'final',
};
function atAction(order: ConfirmedOrder, g: GarmentRecord, action: WorkflowBatchAction): boolean {
  const status = garmentProcessStatus(order,g);
  return action === 'start' ? ['접수 완료','촬영/태그 완료','전문검수 완료','세탁 대기'].includes(status)
    : action === 'complete' ? status === '세탁 중'
    : action === 'postwash' ? status === '세탁 완료' : status === '완성 검수';
}
export function workflowBatchPlan(order: ConfirmedOrder, action: WorkflowBatchAction) {
  const blocker = globalBlocker(order);
  const blockers = blocker ? [blocker] : [];
  const eligible: string[] = [];
  for (const g of listGarments(order)) {
    if (!atAction(order,g,action)) continue;
    const stage = actionStage[action];
    const issues = stage ? [...(stage === 'prewash' ? getWorkflowIssues(order,g,'intake') : []),
      ...getWorkflowIssues(order,g,stage)] : [];
    if (!['세탁 진행 승인','전체 세탁 완료 / 반출 대기'].includes(order.status) &&
        specialistRequired(order, g))
      issues.push({key:'consent',label:'이 의류의 전문검수·필요한 고객 동의 확인'});
    if (g.qcHoldReason && !issues.some((i) => i.label.includes(g.qcHoldReason!)))
      issues.push({key:'damage',label:g.qcHoldReason});
    if (issues.length) blockers.push(...issues.map((issue) => `${g.itemName} ${g.sequence}번 – ${issue.label}`));
    else if (!blocker) eligible.push(g.garmentId);
  }
  const target = {start:'세탁 시작',complete:'세탁 완료 기록',postwash:'완료',final:'완료'}[action];
  return {eligible, blockers:[...new Set(blockers)],
    label: action === 'complete' ? `세탁 완료 ${eligible.length}벌 기록`
      : `${blockers.length ? `정상 ${eligible.length}벌` : '전체 이상 없음'} → ${target}`};
}
function recordReview(order: ConfirmedOrder, id: string, stage: WorkflowStage, selected: string[], note: string,
  resolved: boolean, at: Date): ConfirmedOrder {
  const timestamp = at.toISOString();
  return {...order, garments:listGarments(order).map((g) => g.garmentId !== id ? g : {
    ...g, workflowReviews:{...g.workflowReviews,[stage]:{
      selected:[...new Set(selected)],note:note.trim(),recordedAt:timestamp,
      ...(resolved ? {completedAt:timestamp}:{}),cycle:cycle(g),signature:signature(order,g,stage),
    }},
    auditEvents:[...g.auditEvents,{at:timestamp,type:'workflow-review',status:resolved?'확인 완료':'확인 필요',
      orderId:order.id,garmentId:id,source:'manual',details:`${stage} · ${selected.join(', ')} · ${note.trim()}`}],
  })};
}
function ensureNormalInspection(order: ConfirmedOrder, methods: Record<number,ActualCleaningMethod>, at: Date, eligible: string[]): ConfirmedOrder {
  if (order.inspection && order.status === '세탁 진행 승인') return order;
  // An explicit staff batch can approve only the eligible normal garments.
  // Keep exceptional garments, original inspection and customer reply untouched.
  if (order.inspection || criticalInspectionRequired(order)) {
    const approvals = {...order.normalGarmentApprovals};
    for (const id of eligible) {
      const garment = listGarments(order).find(g => g.garmentId === id)!;
      if (specialistRequired(order, garment)) throw new Error('예외 의류는 전문검수·고객 동의가 필요합니다.');
      const method = methods[garment.itemIndex - 1];
      if (!['물세탁','드라이세탁'].includes(method)) throw new Error('세탁 방법을 직접 선택해 주세요.');
      const original = order.items[garment.itemIndex - 1].plannedCleaningMethod ??
        order.inspection?.items[garment.itemIndex - 1]?.actualCleaningMethod;
      if (original && original !== method) throw new Error('세탁 방법 변경 사유와 고객 동의를 전문검수에서 확인해 주세요.');
      approvals[id] = {at:at.toISOString(),method,cycle:garment.rewashCount ?? 0,
        signature:normalApprovalSignature(order, garment)};
    }
    const allNormal = !criticalInspectionRequired(order) && eligible.length === listGarments(order).length;
    return {...order, status:allNormal ? '세탁 진행 승인' : order.status,
      normalGarmentApprovals:approvals,
      history:[...(order.history ?? []),{at:at.toISOString(),kind:'approval-status',
        details:{source:'staff-normal-batch',garmentIds:eligible,customerConsentRecorded:false,
          status:allNormal ? '세탁 진행 승인' : order.status}}]};
  }
  return completeInspection(order,{
    items:order.items.map((item,index) => ({
      index,itemId:item.itemId,
      checks:Object.fromEntries(INSPECTION_FIELDS.map((field) => {
        const issues = listGarments(order).filter((g)=>g.itemIndex===index+1)
          .flatMap((g)=>getWorkflowIssues(order,g,'prewash'));
        const flagged = issues.some((issue)=> issue.key === 'stain' && field === '오염/얼룩 상태'
          || issue.key === 'damage' && field === '기존 손상 여부'
          || issue.key === 'color' && field === '이염 위험');
        return [field,flagged ? '주의':'정상'];
      })) as Record<typeof INSPECTION_FIELDS[number],'정상'|'주의'>,
      actualCleaningMethod:methods[index], method:'기존 방법 유지' as const, customMethod:'',
      additionalWork:['추가 작업 없음' as const],additionalWorkDescription:'',
      memo:listGarments(order).filter((g) => g.itemIndex === index+1)
        .map((g) => workflowReviewFor(g,'prewash')?.note ?? '').filter(Boolean).join(' / '),
    })),revisedPrice:order.estimatedTotal,riskRequired:false,riskNotice:'',
  },at);
}
/** All transitions are validated in memory; the caller performs one guarded storage write. */
export function applyWorkflowBatch(order: ConfirmedOrder, action: WorkflowBatchAction,
  methods: Record<number,ActualCleaningMethod> = {}, at = new Date()): ConfirmedOrder {
  const plan = workflowBatchPlan(order,action);
  if (!plan.eligible.length) throw new Error(plan.blockers.join('\n') || '진행할 의류가 없습니다.');
  let updated = action === 'start' ? ensureNormalInspection(order,methods,at,plan.eligible) : order;
  if (updated.status !== '세탁 진행 승인' && plan.eligible.some(id =>
      !normalGarmentApproved(updated, listGarments(updated).find(g => g.garmentId === id)!)))
    throw new Error('필요한 전문검수·고객 동의를 먼저 확인해 주세요.');
  if (action === 'start' && currentOperations(updated).stage === '매장입고')
    updated = advanceOrderStage(updated,'세탁중',at);
  for (const id of plan.eligible) {
    const g = listGarments(updated).find((item) => item.garmentId === id)!;
    const stage = actionStage[action];
    if (stage) updated = recordReview(updated,id,stage,workflowReviewFor(g,stage)?.selected ?? [],
      workflowReviewFor(g,stage)?.note ?? '직원 일괄 이상 없음 확인',true,at);
    updated = advanceGarmentInOrder(updated,id,
      action === 'start' ? 'start' : action === 'complete' ? 'complete' : action === 'postwash' ? 'inspect' : 'qc-pass',
      'manual','',at);
    if (action === 'postwash') {
      const inspected = listGarments(updated).find((item)=>item.garmentId===id)!;
      if (!getWorkflowIssues(updated,inspected,'final').length) {
        updated = recordReview(updated,id,'final',[],'직원 일괄 최종 이상 없음 확인',true,at);
        updated = advanceGarmentInOrder(updated,id,'qc-pass','manual','',at);
      }
    }
  }
  return updated;
}
export function applyWorkflowReview(order: ConfirmedOrder, id: string, stage: WorkflowStage, selected: string[],
  note: string, resolved: boolean, at = new Date()): ConfirmedOrder {
  const g = listGarments(order).find((item) => item.garmentId === id);
  if (!g) throw new Error('이 주문에 속하지 않은 의류입니다.');
  if (currentOperations(order).cancelledAt || currentOperations(order).completedAt)
    throw new Error('취소·출고한 주문은 검수를 변경할 수 없습니다.');
  if (!WORKFLOW_STAGES.some((item) => item.key === stage) ||
    selected.some((key) => !WORKFLOW_FIELDS[stage].some((field) => field.key === key)))
    throw new Error('확인 항목이 올바르지 않습니다.');
  const status = garmentProcessStatus(order,g);
  if (stage === 'postwash' && status !== '세탁 완료' || stage === 'final' && status !== '완성 검수' ||
      ['intake','prewash'].includes(stage) && !atAction(order,g,'start'))
    throw new Error('현재 단계의 의류만 확인할 수 있습니다.');
  const existing = getWorkflowIssues(order,g,stage);
  const keys = [...new Set([...selected,...existing.map((item) => item.key)])];
  if (keys.length && !note.trim()) throw new Error('예외 항목의 확인 결과/처리 내용을 입력해 주세요.');
  if (note.length > 1000) throw new Error('메모는 1000자 이내로 입력해 주세요.');
  if (resolved && keys.includes('photo') && !g.completionPhoto?.path)
    throw new Error('완성사진을 실제 연결한 뒤 확인해 주세요. 의류 사진 화면에서 처리할 수 있습니다.');
  if (resolved && g.qcHoldReason) throw new Error('상세 세탁 화면에서 추가 확인 보류를 해제한 뒤 진행해 주세요.');
  let updated = recordReview(order,id,stage,keys,note,resolved,at);
  if (!resolved) return updated;
  if (stage === 'postwash' && keys.includes('rewash')) {
    // A rewash is a new cycle, not a successful QC pass.
    updated = advanceGarmentInOrder(updated,id,'inspect','manual','',at);
    return advanceGarmentInOrder(updated,id,'qc-rewash','manual',note,at);
  }
  if (stage === 'postwash') return advanceGarmentInOrder(updated,id,'inspect','manual','',at);
  if (stage === 'final') return advanceGarmentInOrder(updated,id,'qc-pass','manual','',at);
  if (stage === 'prewash' && order.inspection && !globalBlocker(updated) &&
      !getWorkflowIssues(updated,g,'intake').length)
    return advanceGarmentInOrder(updated,id,'start','manual','',at);
  return updated;
}
export function persistWorkflowUpdate(expected: ConfirmedOrder, apply: (order: ConfirmedOrder) => ConfirmedOrder) {
  const matches = readConfirmedOrders().filter((order) => order.id === expected.id);
  if (matches.length !== 1 || JSON.stringify(matches[0]) !== JSON.stringify(expected))
    throw new Error('다른 화면에서 주문이 변경되었습니다. 최신 주문을 다시 불러온 뒤 확인해 주세요.');
  const updated = apply(matches[0]);
  updateSavedOrder(updated,matches[0]);
  return updated;
}
