export type KoreanField = {
  tag: string; type?: string; mode?: string; signature?: string; label?: string;
  preference?: string | null; readOnly?: boolean;
};
/** Human Korean text only. Machine identifiers and paths must stay literal. */
export function koreanFieldPolicy(field: KoreanField): 'text' | 'search' | null {
  if (field.preference === 'off' || field.readOnly) return null;
  if (field.tag !== 'TEXTAREA' && !['text', 'search', ''].includes(field.type || 'text')) return null;
  if (/^(numeric|decimal|tel|url|email)$/.test(field.mode || '')) return null;
  if (field.preference === 'on') return 'text';
  const value = `${field.signature || ''} ${field.label || ''}`;
  const humanSearch = /검색|찾기|고객명.*(?:전화|휴대폰)|(?:전화|휴대폰).*고객명/.test(value) || field.type === 'search';
  if (/바코드|barcode|scanner|태그.*(?:번호|원문)|롤태그/i.test(value) && !/고객명|고객 이름/.test(value)) return null;
  if (/url|https?:|[a-z]:\\|경로|폴더|비밀번호|password|복구키|복구 키|인증키|api.?key|토큰|token|브리지|프린터|카메라|모델|키 코드|key.?code|foot.?switch|단축키|포트|uuid/i.test(value)) return null;
  if (!humanSearch && /phone|전화|휴대폰|연락처|금액|세탁비|할인율|원\)|수량|건수/i.test(value)) return null;
  return humanSearch ? 'search' : 'text';
}
