/** Shared reception/management rules. No records are invented or persisted here. */
export type CustomerSearchField = 'name' | 'phone';
export type CustomerQuery = { keyword: string; kind: CustomerSearchField };
export function customerQuery(name: string, phone: string, field: CustomerSearchField): CustomerQuery | null {
  const value = (field === 'phone' ? phone : name).normalize('NFC').trim();
  const digits = value.replace(/\D/g, '');
  if (field === 'phone' || /^[\d\s()+.-]+$/.test(value)) {
    return /^[\d\s()+.-]+$/.test(value) && digits.length === 4 ? { keyword: digits, kind: 'phone' } : null;
  }
  return Array.from(value).length >= 2 ? { keyword: value, kind: 'name' } : null;
}
/** Arrow-key navigation explicitly assigns the next Enter to customer selection. */
export function customerKeyboardOwnsEnter(key: string, value: string, field: CustomerSearchField, armedKeyword: string | null, popupVisible: boolean) {
  return key === 'Enter' && popupVisible && !!armedKeyword &&
    customerQuery(field === 'name' ? value : '', field === 'phone' ? value : '', field)?.keyword === armedKeyword;
}
export function uniquePhoneCustomer<T>(query: CustomerQuery | null, customers: readonly T[]): T | null {
  return query?.kind === 'phone' && customers.length === 1 ? customers[0] : null;
}
export function customerOptionIndex(current: number, key: string, count: number) {
  if (!count) return -1;
  return (current + (key === 'ArrowUp' ? -1 : 1) + count) % count;
}
export function customerPhoneDisplay(phone: string) {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 11) return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
  if (digits.length === 10 && !digits.startsWith('02')) return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  // Never invent a full number for historical short/foreign telephone values.
  return phone;
}
