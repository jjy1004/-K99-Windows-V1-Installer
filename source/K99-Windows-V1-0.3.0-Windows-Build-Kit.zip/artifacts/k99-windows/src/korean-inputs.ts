import { composeKoreanEdit, convertKoreanSearch } from './korean-input-conversion';
import { koreanFieldPolicy } from './korean-field-policy';
import { installKoreanControls, koreanEnabled } from './korean-input-controls';

/** Chromium ignores CSS ime-mode. Keep real IME ownership and supply a Korean
 * keyboard fallback for human text when Windows remains in English mode. */
export function installKoreanInputs(doc: Document = document) {
  doc.documentElement.lang = 'ko';
  type Field = HTMLInputElement | HTMLTextAreaElement;
  const composing = new WeakSet<Field>();
  const buffers = new WeakMap<Field, { raw: string; display: string }>();
  const pending = new Map<Field, ReturnType<typeof setTimeout>>();
  const commits = new WeakMap<Field, () => void>();
  const notifying = new WeakSet<Field>();
  const cancel = (target: Field) => { clearTimeout(pending.get(target)); pending.delete(target); commits.delete(target); };
  const field = (value: EventTarget | null): Field | null =>
    value instanceof HTMLInputElement || value instanceof HTMLTextAreaElement ? value : null;
  const policy = (input: Field) => koreanFieldPolicy({
    tag: input.tagName, type: input instanceof HTMLInputElement ? input.type : undefined,
    mode: input.inputMode, readOnly: input.readOnly, preference: input.dataset.koreanInput ||
      (input.dataset.koreanFirst === 'true' ? 'on' : input.dataset.koreanFirst === 'false' ? 'off' : undefined),
    signature: [input.id, input.name, input.getAttribute('data-testid'), input.getAttribute('aria-label'), input.placeholder].join(' '),
    label: input.closest('label')?.textContent || '',
  });
  const prepare = (input: Field) => {
    if (!policy(input)) return;
    if (input.lang !== 'ko') input.lang = 'ko';
    if (input.inputMode !== 'text') input.inputMode = 'text';
    if (/disabled|inactive/i.test(input.style.getPropertyValue('ime-mode')))
      input.style.setProperty('ime-mode', 'active');
  };
  const apply = () => doc.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>('input,textarea')
    .forEach(prepare);
  apply();
  const observer = new MutationObserver(apply);
  observer.observe(doc.documentElement, { childList: true, subtree: true });
  const focus = (event: FocusEvent) => {
    const target = field(event.target);
    if (target) { prepare(target); buffers.set(target, { raw: target.value, display: target.value }); }
  };
  const start = (event: Event) => {
    const target = field(event.target);
    if (target && policy(target)) { cancel(target); composing.add(target); target.dataset.koreanComposing = 'true'; buffers.delete(target); }
  };
  const end = (event: Event) => {
    const target = field(event.target);
    if (target && event.type === 'focusout' && !composing.has(target)) commits.get(target)?.();
    if (target) { cancel(target); composing.delete(target); delete target.dataset.koreanComposing; buffers.delete(target); }
  };
  const input = (event: Event) => {
    const target = field(event.target), native = event as InputEvent;
    if (target && notifying.has(target)) return;
    if (!target || target.dataset.koreanManaged || composing.has(target) || native.isComposing || /composition/i.test(native.inputType || '')) return;
    cancel(target);
    if (native.inputType !== 'insertText') { buffers.set(target, { raw: target.value, display: target.value }); return; }
    if (!native.data || !/^[a-z0-9]+$/i.test(native.data)) return;
    const kind = policy(target); if (!kind) return;
    if (!koreanEnabled(target)) { buffers.set(target, { raw: target.value, display: target.value }); return; }
    const raw = target.value, previous = buffers.get(target);
    const candidate = kind === 'search' && previous && raw.startsWith(previous.display)
      ? previous.raw + raw.slice(previous.display.length) : raw;
    const next = kind === 'search' ? convertKoreanSearch(candidate) : composeKoreanEdit(previous?.display || '', raw);
    const cursor = target.selectionStart;
    buffers.set(target, { raw: candidate, display: next });
    if (next === raw) return;
    // Use the native setter before React's delegated onChange. Never write
    // through its value tracker or dispatch a second recursive input event.
    const prototype = target instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const commit = () => {
      commits.delete(target);
      pending.delete(target);
      if (!target.isConnected || composing.has(target) || !koreanEnabled(target) || target.value !== raw) return;
      Object.getOwnPropertyDescriptor(prototype, 'value')!.set!.call(target, next);
      if (cursor !== null) {
        const position = Math.max(0, Math.min(next.length, cursor + next.length - raw.length));
        target.setSelectionRange(position, position);
      }
      // Deferred conversion happens after React's original change handler.
      notifying.add(target);
      try { target.dispatchEvent(new Event('input', { bubbles: true })); }
      finally { notifying.delete(target); }
    };
    commits.set(target, commit);
    pending.set(target, setTimeout(commit, 30));
  };
  const key = (event: KeyboardEvent) => {
    const target = field(event.target);
    if (target && policy(target) && (event.isComposing || event.keyCode === 229)) {
      cancel(target); composing.add(target); target.dataset.koreanComposing='true';
    }
    if (target && composing.has(target) && ['Enter', 'Escape'].includes(event.key))
      event.stopPropagation(); // Commit/cancel native IME, not business actions.
  };
  doc.addEventListener('focusin', focus, true);
  doc.addEventListener('compositionstart', start, true);
  doc.addEventListener('compositionend', end, true);
  doc.addEventListener('focusout', end, true);
  doc.addEventListener('input', input, true);
  doc.addEventListener('keydown', key, true);
  const stopControls = installKoreanControls(doc, target => {
    const input = field(target);
    if (input) return !!policy(input) && !input.disabled;
    return target.isContentEditable && koreanFieldPolicy({ tag: 'TEXTAREA', type: 'text',
      preference: target.dataset.koreanInput, signature: target.getAttribute('aria-label') || '' }) !== null;
  }, target => { const input = field(target); if (input) { cancel(input); buffers.set(input, { raw: input.value, display: input.value }); } });
  return () => {
    stopControls();
    pending.forEach(clearTimeout); pending.clear();
    observer.disconnect(); doc.removeEventListener('focusin', focus, true);
    doc.removeEventListener('compositionstart', start, true); doc.removeEventListener('compositionend', end, true);
    doc.removeEventListener('focusout', end, true); doc.removeEventListener('input', input, true);
    doc.removeEventListener('keydown', key, true);
  };
}
