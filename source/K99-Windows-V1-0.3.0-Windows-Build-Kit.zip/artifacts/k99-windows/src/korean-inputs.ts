/** Chromium does not implement ime-mode; language hints must not intercept composition or scanner keys. */
export function installKoreanInputs(doc: Document = document) {
  doc.documentElement.lang = 'ko';
  const apply = () => doc.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>('input,textarea')
    .forEach(input => { if (input.lang !== 'ko') input.lang = 'ko'; });
  apply();
  const observer = new MutationObserver(apply);
  observer.observe(doc.documentElement, { childList: true, subtree: true });
  const focus = (event: FocusEvent) => {
    const target = event.target;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)
      if (target.lang !== 'ko') target.lang = 'ko';
  };
  doc.addEventListener('focusin', focus, true);
  return () => { observer.disconnect(); doc.removeEventListener('focusin', focus, true); };
}
