// Display-only diagnostics. Never normalize lookup input or write order records.
export type ScanDiagnostic = {
  raw: string;
  source: 'input-submit' | 'keyboard-wedge';
  keyEvents: string[];
  pasteRaw: string | null;
  capturedAt: string;
};

export function describeScanText(value: string) {
  const escaped = `"${Array.from(value, char => {
    if (char === '\r') return '\\r';
    if (char === '\n') return '\\n';
    if (char === '\t') return '\\t';
    if (/\s|[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u2060-\u206f]/u.test(char)) {
      return `\\u${char.charCodeAt(0).toString(16).toUpperCase().padStart(4, '0')}`;
    }
    return JSON.stringify(char).slice(1, -1);
  }).join('')}"`;
  return { length: value.length, escaped };
}

function unit(value: string, index: number) {
  return index >= value.length ? '문자 없음'
    : `U+${value.charCodeAt(index).toString(16).toUpperCase().padStart(4, '0')}`;
}

export function compareScanText(raw: string, saved: string) {
  if (raw === saved) return '원문 완전 일치 (진단 비교이며 출고 성공 판정은 아닙니다)';
  let index = 0;
  while (index < raw.length && index < saved.length && raw[index] === saved[index]) index++;
  return `${index + 1}번째 문자부터 다름: scannedId ${unit(raw,index)} / 저장 ID ${unit(saved,index)}`;
}
