import { useState } from 'react';
import { CAMERA_GUIDE_IMAGES, GUIDE_USB_NOTICE } from './original-guide-images';
import './original-guide-images.css';

type GuideImageKind = 'camera';
const imagesFor = (_kind: GuideImageKind) => CAMERA_GUIDE_IMAGES;

export function OriginalGuideImage({ index, kind = 'camera' }: { index: number; kind?: GuideImageKind }) {
  const image = imagesFor(kind)[index];
  const [failed, setFailed] = useState(false);
  if (!image) return null;
  // BASE_URL은 웹의 하위 경로와 Electron의 ./ 경로를 모두 지원한다.
  const base = import.meta.env?.BASE_URL ?? './';
  return <figure className="ogi-figure">
    {failed ? <p role="alert">안내 이미지를 불러오지 못했습니다. 이전·다음 버튼으로 다른 사진을 확인하거나 안내창을 다시 열어 주세요.</p>
      : <img src={`${base}images/original-guides/${image.file}`} alt={image.title}
        onError={() => setFailed(true)} decoding="async" data-original-guide={image.file} />}
    <figcaption>제공받은 안내 이미지 원본 · {image.title}</figcaption>
  </figure>;
}

export function OriginalGuideImages({ kind = 'camera' }: { kind?: GuideImageKind }) {
  const [index, setIndex] = useState(0);
  const images = imagesFor(kind);
  return <section className="ogi-gallery" aria-label="첨부한 실제 안내 이미지">
    <h3>촬영용 휴대폰 USB 연결 · 1탄과 2탄</h3>
    <p className="ogi-context">1탄의 1~4단계를 먼저 확인한 뒤 [다음 그림]을 눌러 2탄의 5~7단계를 따라 하세요. 휴대폰 기종과 Iriun 앱 버전에 따라 메뉴 이름이 다를 수 있습니다.</p>
    <nav className="ogi-nav" aria-label="실제 안내 이미지 넘기기">
      <button type="button" disabled={index === 0} onClick={() => setIndex(i => i - 1)}>◀ 이전 그림</button>
      <strong role="status">{index + 1} / {images.length}</strong>
      <button type="button" disabled={index === images.length - 1} onClick={() => setIndex(i => i + 1)}>다음 그림 ▶</button>
    </nav>
    <div className="ogi-image-scroll" key={`${kind}-${index}`}><OriginalGuideImage index={index} kind={kind} /></div>
    <p className="ogi-usb-notice">{GUIDE_USB_NOTICE}</p>
  </section>;
}
