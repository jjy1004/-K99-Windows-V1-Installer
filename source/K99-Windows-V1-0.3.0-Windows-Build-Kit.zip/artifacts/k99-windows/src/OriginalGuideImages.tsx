import { useState } from 'react';
import { ORIGINAL_GUIDE_IMAGES, GUIDE_USB_NOTICE } from './original-guide-images';
import './original-guide-images.css';

export function OriginalGuideImage({ index }: { index: number }) {
  const image = ORIGINAL_GUIDE_IMAGES[index];
  const [failed, setFailed] = useState(false);
  if (!image) return null;
  // BASE_URL은 웹의 하위 경로와 Electron의 ./ 경로를 모두 지원한다.
  const base = import.meta.env?.BASE_URL ?? './';
  return <figure className="ogi-figure">
    {failed ? <p role="alert">안내 이미지를 불러오지 못했습니다. 이전·다음 버튼으로 다른 사진을 확인하거나 안내창을 다시 열어 주세요.</p>
      : <img src={`${base}images/original-guides/${image.file}`} alt={image.title}
        onError={() => setFailed(true)} decoding="async" data-original-guide={image.file} />}
    <figcaption>제공받은 실제 화면 원본 · {image.title}</figcaption>
  </figure>;
}

export function OriginalGuideImages() {
  const [index, setIndex] = useState(0);
  return <section className="ogi-gallery" aria-label="첨부한 실제 안내 이미지">
    <h3>실제 화면으로 보는 AI 앱 안내</h3>
    <p className="ogi-context">아래 사진은 AI 세탁 처방 앱의 실제 화면이며, 촬영용 휴대폰 USB 설정과는 별도의 안내입니다. 사진 속 초기 비밀번호는 최초 로그인용이며, 변경한 분은 본인 비밀번호를 사용하세요.</p>
    <nav className="ogi-nav" aria-label="실제 안내 이미지 넘기기">
      <button type="button" disabled={index === 0} onClick={() => setIndex(i => i - 1)}>◀ 이전 그림</button>
      <strong role="status">{index + 1} / {ORIGINAL_GUIDE_IMAGES.length}</strong>
      <button type="button" disabled={index === ORIGINAL_GUIDE_IMAGES.length - 1} onClick={() => setIndex(i => i + 1)}>다음 그림 ▶</button>
    </nav>
    <div className="ogi-image-scroll"><OriginalGuideImage key={index} index={index} /></div>
    <p className="ogi-usb-notice">{GUIDE_USB_NOTICE}</p>
  </section>;
}
