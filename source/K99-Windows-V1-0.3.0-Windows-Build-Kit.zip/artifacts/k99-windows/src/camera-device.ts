/** Device selection never substitutes another camera after an open failure. */
export const isVirtualCamera = (label: string) => /virtual|가상|\bobs\b/i.test(label);
export const isInternalCamera = (label:string) => /integrated|built.?in|facetime|front.?camera|user.?facing|내장|전면|internal/i.test(label);
export const isExternalCamera = (label:string) => !isVirtualCamera(label)&&!isInternalCamera(label)&&
  /su200|usb|uvc|webcam|insta360|logitech|logi|brio|c9[0-9]{2}|카메라.*외장/i.test(label);
export function automaticCamera(devices: readonly MediaDeviceInfo[]) {
  const physical = devices.filter(d => d.kind === 'videoinput' && d.label &&
    !isVirtualCamera(d.label) && !['default', 'communications'].includes(d.deviceId));
  return physical.find(d => /su200[-_ ]?mb|2bc5.*0529/i.test(d.label)) ?? physical.find(d=>isExternalCamera(d.label)) ??
    physical.find(d=>!isInternalCamera(d.label));
}
export function initialDirectCamera(devices:readonly MediaDeviceInfo[],saved=''){
  const previous=devices.find(d=>d.deviceId===saved);
  // An old OBS preference is not a dependency of the new direct-USB mode.
  if(previous&&(!previous.label||isVirtualCamera(previous.label)))return automaticCamera(devices)?.deviceId||'';
  return saved||automaticCamera(devices)?.deviceId||'';
}
export function cameraFailure(error: unknown): string {
  const name = error instanceof Error ? error.name : '';
  const detail: Record<string, string> = {
    NotAllowedError: 'Windows 개인정보 설정의 카메라 권한과 앱 접근 허용을 확인하세요.',
    NotFoundError: '선택한 카메라가 연결되어 있는지 확인하세요.',
    NotReadableError: 'PC 본체 USB 포트에 직접 연결하고, OBS·화상회의 등 다른 앱이 카메라를 사용 중이면 종료해 주세요.',
    OverconstrainedError: '선택한 카메라가 요청한 영상 조건을 지원하는지 확인하세요.',
    AbortError: 'USB 연결 상태를 확인한 뒤 다시 시도하세요.',
  };
  return `카메라 연결 실패 - ${detail[name] ?? (error instanceof Error ? error.message : 'USB 연결과 다른 앱의 카메라 사용 여부를 확인하세요.')} 다른 카메라로 자동 전환하지 않았습니다. 휴대폰 QR 촬영은 계속 사용할 수 있습니다.`;
}
export const cameraAbort=()=>Object.assign(new Error('이전 카메라 연결 요청을 취소했습니다.'),{name:'AbortError'});
const streamDevices=new WeakMap<MediaStream,string>();
export function cameraStreamDeviceId(stream?:MediaStream|null){
  return stream?(streamDevices.get(stream)||stream.getVideoTracks()[0]?.getSettings?.().deviceId||''):'';
}
export function stopCameraStream(stream:MediaStream){stream.getTracks().forEach(track=>track.stop());}
export const cameraDelay=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
export function safeCameraConstraints(deviceId=''):MediaStreamConstraints{
  return {audio:false,video:{...(deviceId?{deviceId}:{}),
    width:{ideal:1920},height:{ideal:1080}}};
}
function requestStream(media:Pick<MediaDevices,'getUserMedia'>,constraints:MediaStreamConstraints,signal?:AbortSignal){
  return new Promise<MediaStream>((resolve,reject)=>{
    let settled=false;
    const cleanup=()=>{clearTimeout(timer);signal?.removeEventListener('abort',cancel);};
    const fail=(error:unknown)=>{if(!settled){settled=true;cleanup();reject(error);}};
    const cancel=()=>fail(cameraAbort());
    const timer=setTimeout(()=>fail(Object.assign(new Error('카메라 영상 응답 시간이 초과되었습니다. USB 연결과 다른 앱의 점유를 확인해 주세요.'),{name:'NotReadableError'})),6000);
    signal?.addEventListener('abort',cancel,{once:true});
    if(signal?.aborted){cancel();return;}
    try{Promise.resolve(media.getUserMedia(constraints)).then(stream=>{
      if(settled){stopCameraStream(stream);return;}
      settled=true;cleanup();resolve(stream);
    },fail);}catch(error){fail(error);}
  });
}
export async function acquireCamera(media: Pick<MediaDevices, 'enumerateDevices' | 'getUserMedia'>,
  deviceId = '',signal?:AbortSignal): Promise<MediaStream> {
  let inventory=await media.enumerateDevices();
  if(signal?.aborted)throw cameraAbort();
  let selected=deviceId||automaticCamera(inventory)?.deviceId;
  if(!selected&&!deviceId&&inventory.some(d=>d.kind==='videoinput'&&!d.label)){
    // New PCs may hide all labels until permission is granted. This probe is
    // never displayed or saved; immediately release it before selecting UVC.
    let permission:MediaStream;
    try{permission=await requestStream(media,safeCameraConstraints(),signal);}
    catch(error){if(signal?.aborted)throw cameraAbort();permission=await requestStream(media,{audio:false,video:true},signal);}
    stopCameraStream(permission);
    await cameraDelay(300);
    inventory=await media.enumerateDevices();
    selected=automaticCamera(inventory)?.deviceId;
  }
  if(signal?.aborted)throw cameraAbort();
  if(!selected)throw new Error('자동 선택할 물리 카메라가 없습니다. 목록에서 카메라를 직접 선택하세요. 가상 카메라는 자동 선택하지 않습니다.');
  async function attempt(constraints:MediaStreamConstraints){
    const stream=await requestStream(media,constraints,signal);
    try{
      const track=stream.getVideoTracks()[0];
      // Some UVC drivers omit deviceId. Missing metadata is not a failed stream.
      // Reject only a demonstrably different camera; never substitute OBS.
      const actual=track?.getSettings?.().deviceId;
      const requested=inventory.find(d=>d.deviceId===selected);
      const alias=actual==='default'||actual==='communications';
      if(!track||(actual&&!alias&&actual!==selected)||
        ((!actual||alias)&&requested?.label&&track.label&&track.label!==requested.label))
        throw Error('브라우저가 선택한 USB 카메라 대신 다른 장치를 반환했습니다. 장치 목록과 권한을 확인해 주세요.');
      streamDevices.set(stream,selected!);
      return stream;
    }catch(error){
      stopCameraStream(stream);
      throw error;
    }
  }
  try{return await attempt(safeCameraConstraints(selected));}
  catch(error){
    if(signal?.aborted)throw cameraAbort();
    // No forced resolution, frame rate, exact, minimum or manual UVC controls.
    return attempt({audio:false,video:{deviceId:selected}});
  }
}
