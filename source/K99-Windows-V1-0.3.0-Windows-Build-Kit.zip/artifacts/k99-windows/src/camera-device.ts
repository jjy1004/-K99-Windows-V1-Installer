/** Direct UVC, no OBS dependency or hardware exposure/white-balance control. */
// Phone webcam drivers are deliberately allowed even when their Windows
// friendly name contains "Virtual". OBS/Insta360 virtual outputs are not.
export const isSmartphoneCamera = (label:string) => !/\bobs\b|insta360.*virtual|virtual.*insta360/i.test(label)&&
  /\biriun\b|\bdroid\s?cam\b|\bivcam\b|\bepoccam\b/i.test(label);
export const isVirtualCamera = (label: string) => !isSmartphoneCamera(label)&&
  /virtual|가상|\bobs\b|manycam|snap camera|xsplit|nvidia broadcast|splitcam|\bndi\b|vcam/i.test(label);
export const isInternalCamera = (label:string) => !isSmartphoneCamera(label)&&/integrated|built.?in|facetime|front.?camera|user.?facing|내장|전면|internal/i.test(label);
export const isExternalCamera = (label:string) => !isVirtualCamera(label)&&!isInternalCamera(label)&&
  /usb|uvc|webcam|카메라.*외장|external/i.test(label);
export const selectableCameras=(devices:readonly MediaDeviceInfo[])=>devices.filter(d=>d.kind==='videoinput'&&
  !!d.label&&!isVirtualCamera(d.label)&&!isInternalCamera(d.label)&&!['default','communications'].includes(d.deviceId));
export function automaticCamera(devices: readonly MediaDeviceInfo[]) {
  const physical = devices.filter(d => d.kind === 'videoinput' && d.label &&
    !isVirtualCamera(d.label) && !['default', 'communications'].includes(d.deviceId));
  return physical.find(d=>isExternalCamera(d.label)) ??
    physical.find(d=>!isInternalCamera(d.label));
}
export function cameraFailure(error: unknown): string {
  const name = error instanceof Error ? error.name : '';
  const detail: Record<string, string> = {
    NotAllowedError: 'Windows 개인정보 설정의 카메라 권한과 앱 접근 허용을 확인하세요.',
    NotFoundError: '선택한 카메라가 연결되어 있는지 확인하세요.',
    NotReadableError: 'PC 본체 USB 포트에 직접 연결하거나 다른 앱에서 사용 중인지 확인하세요.',
    OverconstrainedError: '선택한 카메라가 요청한 영상 조건을 지원하는지 확인하세요.',
    AbortError: 'USB 연결 상태를 확인한 뒤 다시 시도하세요.',
  };
  return `카메라 연결 실패 - ${detail[name] ?? (error instanceof Error ? error.message : 'USB 연결과 다른 앱의 카메라 사용 여부를 확인하세요.')} 다른 카메라로 자동 전환하지 않았습니다. 휴대폰 QR 촬영은 계속 사용할 수 있습니다.`;
}
const stopStream=(s:MediaStream)=>s.getTracks().forEach(t=>t.stop());
const selectedDevices=new WeakMap<MediaStream,string>();
export function cameraStreamDeviceId(stream:MediaStream|null|undefined){
  return stream?.getVideoTracks()[0]?.getSettings().deviceId||(stream?selectedDevices.get(stream):'')||'';
}
async function requestStream(media:Pick<MediaDevices,'getUserMedia'>,constraints:MediaStreamConstraints,ms=5000){
  let expired=false,timer:ReturnType<typeof setTimeout>|undefined;
  try{
    return await new Promise<MediaStream>((resolve,reject)=>{
      timer=setTimeout(()=>{expired=true;reject(Object.assign(Error('카메라 연결 응답 시간이 초과되었습니다.'),{name:'CameraOpenTimeout'}));},ms);
      Promise.resolve(media.getUserMedia(constraints)).then(s=>{
        if(expired){stopStream(s);return;}clearTimeout(timer);resolve(s);
      },reject);
    });
  }finally{clearTimeout(timer);expired=true;}
}
export async function acquireCamera(media: Pick<MediaDevices, 'enumerateDevices' | 'getUserMedia'>,
  deviceId = '',verify?:(s:MediaStream)=>Promise<void>): Promise<MediaStream> {
  // Keep device enumeration pure and independently testable; load optional
  // software settings/decoder only when an actual stream is being opened.
  const decode=verify||(await import('./camera-video')).inspectCameraStream;
  let devices=await media.enumerateDevices();
  let selected=deviceId||automaticCamera(devices)?.deviceId;
  // A new Windows user may not have camera labels until permission is granted.
  // This probe is never displayed as the reception camera without validation.
  if(!selected&&devices.some(d=>d.kind==='videoinput'&&!d.label)){
    const probe=await requestStream(media,{audio:false,video:{width:{ideal:1920},height:{ideal:1080}}});
    try{
      devices=await media.enumerateDevices();selected=automaticCamera(devices)?.deviceId;
      const track=probe.getVideoTracks()[0];
      if(selected&&track?.getSettings().deviceId===selected&&!isVirtualCamera(track.label||'')){
        await decode(probe);selectedDevices.set(probe,selected);return probe;
      }
    }catch(error){stopStream(probe);throw error;}
    stopStream(probe);
  }
  if(!selected)throw Error('자동 선택할 물리 카메라가 없습니다. 목록에서 카메라를 직접 선택하세요. 가상 카메라는 자동 선택하지 않습니다.');
  const chosen=devices.find(d=>d.deviceId===selected);
  if(chosen&&(isVirtualCamera(chosen.label)||isInternalCamera(chosen.label)))
    throw Error('가상·내장 카메라는 사용할 수 없습니다. 연결된 휴대폰 카메라 또는 외장 USB 카메라를 선택하세요.');
  const {CAMERA_RESOLUTIONS,DEFAULT_CAMERA_COLOR,loadCameraColor}=await import('./camera-color');
  const saved=typeof window==='undefined'?DEFAULT_CAMERA_COLOR:loadCameraColor(selected);
  const preferred=CAMERA_RESOLUTIONS[saved.resolution];
  const sizes:readonly (readonly [number,number]|null)[]=[
    preferred,...(saved.resolution==='2K'?[[1920,1080] as const]:[]),
    ...(saved.resolution!=='HD'?[[1280,720] as const]:[]),null,
  ];
  let last:unknown;
  for(const size of sizes){
    let stream:MediaStream|undefined;
    try{
      stream=await requestStream(media,{audio:false,video:{
        deviceId:selected,...(size?{width:{ideal:size[0]},height:{ideal:size[1]}}:{}),
      }});
      const track=stream.getVideoTracks()[0],actual=track?.getSettings().deviceId,label=track?.label||'';
      if(!track||(actual&&actual!==selected)||
        (label&&isVirtualCamera(label)&&!isVirtualCamera(chosen?.label||''))||
        (!actual&&label&&devices.some(d=>d.deviceId!==selected&&d.label===label)))
        throw Object.assign(Error('선택한 USB 카메라 대신 다른 장치가 반환되어 사용하지 않았습니다.'),{name:'CameraDeviceMismatch'});
      await decode(stream);selectedDevices.set(stream,selected);return stream;
    }catch(error){
      if(stream)stopStream(stream);last=error;
      const name=error instanceof Error?error.name:'';
      if(['NotAllowedError','SecurityError','CameraDeviceMismatch','CameraOpenTimeout'].includes(name))throw error;
    }
  }
  throw last instanceof Error?last:Error('선택한 USB 카메라를 열지 못했습니다.');
}
