import type {FinalIntakeChoices} from './order-record';

export const INTAKE_PAYMENT_WARNING='⚠️ 결제 구분(선불 또는 후불)을 먼저 선택해 주세요! (카드 결제 완료 시 자동 선불 체크)';
export function isIntakePaymentType(value:unknown):value is 'PREPAID'|'POSTPAID'{
  return value==='PREPAID'||value==='POSTPAID';
}
/** Only the unfinished draft's old selection is reset, never a saved order. */
export function initialIntakeChoices(draft:Partial<FinalIntakeChoices>|undefined,saved?:FinalIntakeChoices['paymentType']):Partial<FinalIntakeChoices>{
  const {paymentType:ignored,...rest}=draft??{};
  return saved?{...rest,paymentType:saved}:rest;
}
/** Read-only main-process event, not a renderer DOM event or print result. */
export type CardApproval={
  orderId:string;status:'APPROVED';approvalNumber:string;approvedAt:string;amount:number;
};
export function matchesCardApproval(value:unknown,orderId:string,amount:number):value is CardApproval{
  if(!value||typeof value!=='object')return false;
  const a=value as Partial<CardApproval>;
  return a.orderId===orderId&&a.status==='APPROVED'
    &&typeof a.approvalNumber==='string'&&!!a.approvalNumber.trim()&&a.approvalNumber.length<=120
    &&typeof a.approvedAt==='string'&&Number.isFinite(Date.parse(a.approvedAt))
    &&Number.isSafeInteger(amount)&&amount>0&&a.amount===amount;
}
