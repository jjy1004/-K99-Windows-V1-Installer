import { useCallback, useEffect, useRef, useState } from 'react';
import { listDiaries, loadStoreName, saveDiary, searchDiaryCustomers, type Diary, type DiaryCustomer } from './laundry-diary-api';
import './laundry-diary.css';

/* ---- 모달이 열려 있는 동안 접수 발판키(F7/Enter)·바코드 리더 등 창 단위 키 처리가 뚫고 나가지 않도록 차단 ---- */
let diaryOpen = false;
let diaryKeyHandler: ((e: KeyboardEvent) => void) | null = null;
if (typeof window !== 'undefined') {
  // 이 모듈은 앱 시작 시 로드되므로 기존 window capture 리스너보다 먼저 등록된다.
  window.addEventListener('keydown', e => {
    if (!diaryOpen) return;
    e.stopImmediatePropagation();
    if (['F7','F8','F9'].includes(e.key)) e.preventDefault();
    diaryKeyHandler?.(e);
  }, true);
  window.addEventListener('k99:foot-capture', e => { if (diaryOpen) e.stopImmediatePropagation(); }, true);
}

type Form = { id?: string; updated_at?: string; customer: DiaryCustomer | null; raw: string; content: string; keywords: string[]; created_at?: string };
const EMPTY: Form = { customer: null, raw: '', content: '', keywords: ['', '', '', '', ''] };
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);
const fmt = (s: string) => { const d = new Date(s);const pad=(n:number)=>String(n).padStart(2,'0');return isNaN(d.getTime()) ? s : `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const last4 = (p: string) => p.replace(/\D/g, '').slice(-4);
const sameForm = (a: Form, b: Form) => a.raw === b.raw && a.content === b.content && JSON.stringify(a.keywords) === JSON.stringify(b.keywords) && (a.customer?.id ?? '') === (b.customer?.id ?? '');

export function LaundryDiary({ onClose }: { onClose: () => void }) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const [diaries, setDiaries] = useState<Diary[]>([]);
  const [pending, setPending] = useState(0);
  const [listState, setListState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [listError, setListError] = useState('');
  const [query, setQuery] = useState('');
  const [storeName, setStoreName] = useState('');
  const [form, setForm] = useState<Form>(EMPTY);
  const baseline = useRef<Form>(EMPTY);
  const [custQuery, setCustQuery] = useState('');
  const [custResults, setCustResults] = useState<DiaryCustomer[] | null>(null);
  const [custBusy, setCustBusy] = useState(false);
  const [custError, setCustError] = useState('');
  const [step, setStep] = useState<'edit' | 'saving'>('edit');
  const savingRef = useRef(false);
  const [feedback, setFeedback] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [confirmLeave, setConfirmLeave] = useState<null | 'close' | { load: Form }>(null);
  const dirty = !sameForm(form, baseline.current);
  const listRequest=useRef(0);

  const refresh = useCallback(async (q: string) => {
    const request=++listRequest.current;
    setListState('loading');
    try { const r = await listDiaries(q);if(request!==listRequest.current)return; setDiaries(r.diaries); setPending(r.pending); setListState('ready'); }
    catch (e) {if(request!==listRequest.current)return; setListError(errText(e, '일기 목록을 불러오지 못했습니다.')); setListState('error'); }
  }, []);

  useEffect(() => { void loadStoreName().then(setStoreName); }, []);
  useEffect(() => { const t = setTimeout(() => void refresh(query.trim()), 300); return () => clearTimeout(t); }, [query, refresh]);
  useEffect(()=>{
    let live=true,request=0;
    const update=async()=>{const current=++request;try{
      const r=await listDiaries(query.trim());
      if(live&&current===request){setDiaries(r.diaries);setPending(r.pending);}
    }catch{/* The saved local editor remains usable while status refresh fails. */}};
    const timer=setInterval(()=>void update(),15000);
    window.addEventListener('online',update);
    return()=>{live=false;clearInterval(timer);window.removeEventListener('online',update);};
  },[query]);

  // 열림 상태와 포커스 이동/복귀
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    diaryOpen = true;
    dialogRef.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus();
    return () => {
      diaryOpen = false; diaryKeyHandler = null;
      prev?.focus?.();
    };
  }, []);

  function requestClose() {
    if (step === 'saving') return;
    if (step !== 'edit') { setStep('edit'); return; }
    if (confirmLeave) { setConfirmLeave(null); return; }
    if (dirty) { setConfirmLeave('close'); return; }
    onClose();
  }

  const closeRef = useRef(requestClose); closeRef.current = requestClose;
  diaryKeyHandler = (e: KeyboardEvent) => {
    const el = dialogRef.current;
    if (e.key === 'Escape') { e.preventDefault(); closeRef.current(); return; }
    if (e.key !== 'Tab' || !el) return;
    const f = Array.from(el.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),[tabindex="0"]'))
      .filter(n => n.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (!el.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
    else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };

  function applyForm(next: Form) {
    setForm(next); baseline.current = next; setConfirmLeave(null); setFeedback(null);
    setCustResults(null); setCustQuery(''); setStep('edit');
  }
  function openForm(next: Form) { if (dirty) setConfirmLeave({ load: next }); else applyForm(next); }
  const fromDiary = (d: Diary): Form => ({
    id: d.id, updated_at: d.updated_at, created_at: d.created_at, raw: d.raw_voice_text, content: d.content,
    keywords: Array.from({ length: 5 }, (_, i) => d.keywords[i] ?? ''),
    customer: d.customer_id ? { id: d.customer_id, name: d.customer_name, phone: d.customer_phone_last4 } : null,
  });

  async function findCustomer() {
    const q = custQuery.trim(); if (!q) { setCustError('이름이나 전화번호 뒷자리를 입력하세요.'); return; }
    setCustBusy(true); setCustError('');
    try { setCustResults((await searchDiaryCustomers(q)).customers); }
    catch (e) { setCustError(errText(e, '고객을 찾지 못했습니다.')); }
    finally { setCustBusy(false); }
  }

  async function beginSave() {
    if (savingRef.current) return;
    if (!form.content.trim()) { setFeedback({ kind: 'error', text: '일기 내용을 먼저 적어 주세요.' }); return; }
    savingRef.current = true;
    setFeedback(null);
    setStep('saving');
    try {
      const r = await saveDiary({
        ...(form.id ? { id: form.id, updated_at: form.updated_at } : {}),
        ...(form.customer ? { customer_id: form.customer.id } : {}),
        input_mode: 'manual',
        store_name: storeName, raw_voice_text: form.raw, content: form.content, keywords: form.keywords,
      });
      const saved = fromDiary(r.diary);
      setForm(saved); baseline.current = saved; setStep('edit');
      setFeedback({ kind: 'ok', text: `저장했습니다. (${fmt(r.diary.updated_at)})${r.diary.synced_at ? '' : ' 서버 전송은 대기 중입니다.'}` });
      void refresh(query.trim());
    } catch (e) {
      setStep('edit');
      setFeedback({ kind: 'error', text: `저장하지 못했습니다. 적은 내용은 그대로 있으니 다시 저장을 눌러 주세요. (${errText(e, '오류')})` });
    } finally { savingRef.current = false; }
  }

  const lastDiary = diaries[0];
  const busy = step === 'saving';

  return (
    <div className="ldy-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) requestClose(); }}>
      <div ref={dialogRef} className="ldy-modal" role="dialog" aria-modal="true" aria-labelledby="ldy-title" data-testid="dialog-laundry-diary">
        <header className="ldy-head">
          <div>
            <h2 id="ldy-title">나의 세탁 일기</h2>
            <p className="ldy-sub">{storeName ? `${storeName} · ` : ''}세탁 작업과 배운 요령을 적어 두세요. 본문에는 이름·주소·전화번호 등 개인정보를 적지 마세요.</p>
          </div>
          <div className="ldy-sync" data-testid="status-diary-sync">
            {pending > 0 && <span className="ldy-chip is-wait">전송 대기 {pending}건</span>}
            {lastDiary && (lastDiary.synced_at
              ? <span className="ldy-chip is-ok">마지막 일기 서버 확인됨</span>
              : <span className="ldy-chip is-wait">마지막 일기 전송 대기</span>)}
          </div>
          <button type="button" className="ldy-btn" onClick={requestClose} data-testid="button-diary-close">닫기</button>
        </header>

        <div className="ldy-body">
          <aside className="ldy-list">
            <button type="button" className="ldy-btn is-primary ldy-new" disabled={busy} onClick={() => openForm(EMPTY)} data-testid="button-diary-new">새 일기 쓰기</button>
            <label className="ldy-label" htmlFor="ldy-search">일기 찾기</label>
            <input id="ldy-search" className="ldy-input" value={query} onChange={e => setQuery(e.target.value)}
              placeholder="이름, 전화 뒷4자리, 내용, 날짜, 키워드" data-testid="input-diary-search" />
            <div className="ldy-items" aria-live="polite">
              {listState === 'loading' && diaries.length === 0 && [0, 1, 2].map(i => <div key={i} className="ldy-skel" />)}
              {listState === 'error' && <div className="ldy-empty is-error" role="alert">{listError}
                <button type="button" className="ldy-btn" onClick={() => void refresh(query.trim())} data-testid="button-diary-retry">다시 불러오기</button></div>}
              {listState === 'ready' && diaries.length === 0 && <div className="ldy-empty" data-testid="text-diary-empty">
                {query.trim() ? '찾는 일기가 없습니다.' : '아직 쓴 일기가 없습니다. 오른쪽에 첫 일기를 적어 보세요.'}</div>}
              {diaries.map(d => (
                <button key={d.id} type="button" className={`ldy-item${form.id === d.id ? ' is-active' : ''}`}
                  disabled={busy} onClick={() => openForm(fromDiary(d))} data-testid={`card-diary-${d.id}`}>
                  <span className="ldy-item-top"><b>{fmt(d.created_at)}</b>{!d.synced_at && <span className="ldy-dot">대기</span>}</span>
                  {d.customer_name && <span className="ldy-item-cust">{d.customer_name}{d.customer_phone_last4 ? ` · ${d.customer_phone_last4}` : ''}</span>}
                  <span className="ldy-item-text">{d.content}</span>
                  {d.keywords.some(Boolean) && <span className="ldy-kws">{d.keywords.filter(Boolean).map((k, i) => <span key={i} className="ldy-kw">{k}</span>)}</span>}
                </button>
              ))}
            </div>
          </aside>

          <section className="ldy-editor">
            <div className="ldy-editor-head">
              <h3 data-testid="text-diary-mode">{form.id ? `일기 고치기 · ${form.created_at ? fmt(form.created_at) : ''}` : '새 일기'}</h3>
              {dirty && <span className="ldy-chip is-wait" data-testid="status-diary-dirty">저장 안 된 변경 있음</span>}
            </div>

            <div className="ldy-block">
              <span className="ldy-label">손님 (선택)</span>
              {form.customer ? (
                <div className="ldy-cust-sel" data-testid="text-diary-customer">
                  <b>{form.customer.name}</b> <span>전화 뒷자리 {last4(form.customer.phone)}</span>
                  <button type="button" className="ldy-btn" disabled={busy} onClick={() => setForm(f => ({ ...f, customer: null }))} data-testid="button-diary-customer-clear">손님 연결 해제</button>
                </div>
              ) : (
                <>
                  <div className="ldy-row">
                    <input className="ldy-input" value={custQuery} onChange={e => setCustQuery(e.target.value)}
                      placeholder="이름 또는 전화 뒷자리" data-testid="input-diary-customer" />
                    <button type="button" className="ldy-btn" disabled={custBusy} onClick={() => void findCustomer()} data-testid="button-diary-customer-search">{custBusy ? '찾는 중' : '손님 찾기'}</button>
                  </div>
                  {custError && <p className="ldy-msg is-error" role="alert">{custError}</p>}
                  {custResults && (custResults.length === 0 ? <p className="ldy-msg">맞는 손님이 없습니다. 손님 없이도 저장할 수 있습니다.</p> :
                    <div className="ldy-cust-list">{custResults.map(c => (
                      <button key={c.id} type="button" className="ldy-cust" disabled={busy} onClick={() => { setForm(f => ({ ...f, customer: c })); setCustResults(null); }}
                        data-testid={`button-diary-customer-${c.id}`}><b>{c.name}</b> 뒷자리 {last4(c.phone)}</button>))}</div>)}
                </>
              )}
            </div>

            <div className="ldy-block">
              <div className="ldy-row ldy-spread">
                <label className="ldy-label" htmlFor="ldy-content">일기 내용</label>
                <button type="button" className="ldy-btn" disabled={busy} onClick={() => document.getElementById('ldy-content')?.focus()} data-testid="button-diary-edit">내용 수정</button>
              </div>
              <textarea id="ldy-content" data-autofocus className="ldy-textarea" value={form.content} disabled={busy}
                onChange={e => setForm(f => ({ ...f, content: e.target.value }))} placeholder="예) 흰 블라우스 목둘레 땀 자국을 확인하고 원단에 맞게 세탁함."
                data-testid="input-diary-content" />
              <p className="ldy-msg">직접 쓰거나 복사한 글을 붙여넣으세요. 입력한 본문은 자동으로 정리하거나 요약하지 않습니다.</p>
            </div>

            <div className="ldy-block">
              <h3 className="ldy-label">검색 키워드 (선택 · 최대 5개)</h3>
              <p className="ldy-msg">필요한 칸만 적으세요. 모두 비워 두어도 저장할 수 있습니다.</p>
              <div className="ldy-kw-edit">{form.keywords.map((k, i) => (
                <label key={i} className="ldy-kw-field" htmlFor={`ldy-keyword-${i}`}>키워드 {i + 1}
                  <input id={`ldy-keyword-${i}`} className="ldy-input" value={k} maxLength={40} disabled={busy}
                    onChange={e => setForm(f => ({ ...f, keywords: f.keywords.map((x, j) => j === i ? e.target.value : x) }))}
                    data-testid={`input-diary-keyword-${i}`} />
                </label>))}</div>
              <p className="ldy-ai">저장한 본문과 직접 입력한 키워드를 기존 학습 전송 대기열에 반영합니다. 서버의 저장 확인 전까지는 전송 대기로 표시합니다.</p>
            </div>

            {feedback && <div className={`ldy-feedback is-${feedback.kind}`} role={feedback.kind === 'error' ? 'alert' : 'status'} data-testid="status-diary-save">{feedback.text}</div>}

            <div className="ldy-foot">
              <button type="button" className="ldy-btn is-primary ldy-save" disabled={busy || !form.content.trim()} onClick={() => void beginSave()} data-testid="button-diary-save">
                {step === 'saving' ? '저장 중' : '일기 저장'}</button>
            </div>

            {confirmLeave && (
              <div className="ldy-sheet" role="alertdialog" aria-modal="true" aria-labelledby="ldy-leave-title" data-testid="dialog-diary-unsaved">
                <div className="ldy-sheet-card">
                  <h3 id="ldy-leave-title">저장하지 않은 내용이 있습니다.</h3>
                  <p className="ldy-msg">{confirmLeave === 'close' ? '닫으면 지금 적은 내용이 사라집니다.' : '다른 일기를 열면 지금 적은 내용이 사라집니다.'}</p>
                  <div className="ldy-row ldy-end">
                    <button type="button" className="ldy-btn ldy-big" onClick={() => {
                      if (confirmLeave === 'close') { onClose(); } else applyForm(confirmLeave.load);
                    }} data-testid="button-diary-discard">버리기</button>
                    <button type="button" className="ldy-btn is-primary ldy-big" autoFocus onClick={() => setConfirmLeave(null)} data-testid="button-diary-keep">계속 쓰기</button>
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

export default LaundryDiary;
