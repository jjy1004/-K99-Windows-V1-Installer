import { convertEngToKor } from './utils/koreanAutomata';

const initials = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
const vowels = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ';
const finals = ['', ...'ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ'];
const pairs: Record<string, string> = {
  'ㅗㅏ':'ㅘ', 'ㅗㅐ':'ㅙ', 'ㅗㅣ':'ㅚ', 'ㅜㅓ':'ㅝ', 'ㅜㅔ':'ㅞ', 'ㅜㅣ':'ㅟ', 'ㅡㅣ':'ㅢ',
  'ㄱㅅ':'ㄳ', 'ㄴㅈ':'ㄵ', 'ㄴㅎ':'ㄶ', 'ㄹㄱ':'ㄺ', 'ㄹㅁ':'ㄻ', 'ㄹㅂ':'ㄼ',
  'ㄹㅅ':'ㄽ', 'ㄹㅌ':'ㄾ', 'ㄹㅍ':'ㄿ', 'ㄹㅎ':'ㅀ', 'ㅂㅅ':'ㅄ',
};
const split = Object.fromEntries(Object.entries(pairs).map(([key, value]) => [value, key]));

/** Re-open the displayed final syllable so the next ASCII keystroke composes it.
 * The supplied standalone converter is preserved; this adapter fixes its
 * compound-final transfer and adjacent standalone-vowel edge cases. */
export function composeKoreanInput(text: string): string {
  let jamo = '';
  for (const ch of text) {
    const code = ch.charCodeAt(0) - 0xac00;
    if (code >= 0 && code < 11172) {
      jamo += initials[Math.floor(code / 588)] + vowels[Math.floor(code % 588 / 28)] + finals[code % 28];
    } else jamo += /[a-z]/i.test(ch)
      ? convertEngToKor(/[QWERTOP]/.test(ch) ? ch : ch.toLowerCase()) : ch;
  }
  let result = '', initial = '', vowel = '', final = '';
  const flush = () => {
    result += initial && vowel
      ? String.fromCharCode(0xac00 + initials.indexOf(initial) * 588 + vowels.indexOf(vowel) * 28 + finals.indexOf(final))
      : initial + vowel;
    initial = ''; vowel = ''; final = '';
  };
  for (const ch of jamo) {
    if (vowels.includes(ch)) {
      if (final) {
        const parts = split[final];
        const next = parts ? parts[1] : final;
        final = parts ? parts[0] : '';
        flush(); initial = next; vowel = ch;
      } else if (vowel) {
        if (pairs[vowel + ch]) vowel = pairs[vowel + ch];
        else { flush(); vowel = ch; }
      } else vowel = ch;
    } else if (initials.includes(ch) || finals.includes(ch) && ch !== '') {
      if (initial && vowel && !final && finals.includes(ch)) final = ch;
      else if (final && pairs[final + ch]) final = pairs[final + ch];
      else { flush(); initial = ch; }
    } else { flush(); result += ch; }
  }
  flush();
  return result;
}

/** IDs, phone numbers and scanner tokens stay byte-for-byte intact. */
export function convertKoreanSearch(text: string): string {
  return /[0-9_:@./\\-]/.test(text) ? text : composeKoreanInput(text);
}

/** Convert only the new edit, not English text deliberately entered earlier.
 * Reopen one adjacent Korean syllable so sequential ASCII keys compose. */
export function composeKoreanEdit(before: string, after: string): string {
  let start = 0, end = after.length, oldEnd = before.length;
  while (start < before.length && start < after.length && before[start] === after[start]) start++;
  while (end > start && oldEnd > start && after[end - 1] === before[oldEnd - 1]) { end--; oldEnd--; }
  if (!/[a-z]/i.test(after.slice(start, end))) return after;
  if (start && /[가-힣ㄱ-ㅎㅏ-ㅣ]/.test(after[start - 1])) start--;
  return after.slice(0, start) + composeKoreanInput(after.slice(start, end)) + after.slice(end);
}
