import { useCallback, useEffect, useState } from 'react';
import { readAllConfirmedOrders, type ConfirmedOrder } from './order-record';
import { restoreOrderWithAdmin, restoreOrdersBackupWithAdmin } from './order-deletion';
import { createCleanupBackup } from './test-history-cleanup';
import './order-deletion.css';

type Feedback = { kind: 'ok' | 'error'; message: string } | null;
const when = (iso?: string) => iso ? new Date(iso).toLocaleString('ko-KR') : '-';
const itemsOf = (o: ConfirmedOrder) => o.items.map(i => `${i.displayNameKo} ${i.quantity}벌`).join(', ');

export default function AdminOrderMaintenance() {
  const [orders, setOrders] = useState<ConfirmedOrder[]>([]);
  const [loadError, setLoadError] = useState('');
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [busy, setBusy] = useState(false);
  const [backupText, setBackupText] = useState('');
  const [backupName, setBackupName] = useState('');

  const refresh = useCallback(() => {
    try { setOrders(readAllConfirmedOrders()); setLoadError(''); }
    catch (cause) { setLoadError(cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.'); }
  }, []);
  useEffect(() => {
    refresh();
    window.addEventListener('storage', refresh); window.addEventListener('focus', refresh);
    return () => { window.removeEventListener('storage', refresh); window.removeEventListener('focus', refresh); };
  }, [refresh]);

  const deleted = orders.filter(o => o.orderDeletion);
  const audit = orders.flatMap(o => (o.orderDeletionAudit ?? []).map(a => ({ ...a, customerName: o.customerName })))
    .sort((a, b) => b.at.localeCompare(a.at));

  function download() {
    try {
      const backup = createCleanupBackup(window.localStorage);
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }));
      const a = document.createElement('a');
      a.href = url; a.download = `k99-orders-backup-${backup.createdAt.replace(/[:.]/g, '-')}.json`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setFeedback({ kind: 'ok', message: '삭제 표시된 주문을 포함한 전체 원본 백업을 내려받았습니다.' });
    } catch (cause) { setFeedback({ kind: 'error', message: cause instanceof Error ? cause.message : '백업을 만들지 못했습니다.' }); }
  }

  async function importBackup() {
    if (busy || !backupText) return;
    if (!window.confirm(`백업 파일 "${backupName}"에서 현재 브라우저에 없는 주문을 가져옵니다. 충돌하는 주문은 덮어쓰지 않습니다. 계속할까요?`)) return;
    setBusy(true);
    try { const n = await restoreOrdersBackupWithAdmin(backupText, ''); setFeedback({ kind: 'ok', message: `백업에서 주문 ${n}건을 가져왔습니다.` }); setBackupText(''); setBackupName(''); refresh(); }
    catch (cause) { setFeedback({ kind: 'error', message: `백업 가져오기 실패: ${cause instanceof Error ? cause.message : '알 수 없는 오류'}` }); }
    finally { setBusy(false); }
  }

  async function restore(order: ConfirmedOrder) {
    if (busy) return;
    if (!window.confirm(`다음 주문을 복원합니다.\n고객: ${order.customerName}\n주문번호: ${order.id}\n품목: ${itemsOf(order)}\n총 ${order.totalQuantity}벌\n계속할까요?`)) return;
    setBusy(true);
    try { await restoreOrderWithAdmin(order, ''); setFeedback({ kind: 'ok', message: `주문 ${order.id}을(를) 복원했습니다.` }); }
    catch (cause) { setFeedback({ kind: 'error', message: `복원 실패: ${cause instanceof Error ? cause.message : '알 수 없는 오류'}` }); }
    finally { setBusy(false); refresh(); }
  }

  return <section className="order-maint" data-scanner-input data-testid="admin-order-maintenance">
    <h2>주문 삭제·복원 관리</h2>
    <p>직원 삭제는 비밀번호 없이 확인 후 논리 삭제하며, 복구는 관리자 인증이 필요합니다. 주문 원본·사진·태그와 처리 이력은 보존됩니다. 직원 기록은 이 브라우저의 처리이며 개인 계정 인증을 뜻하지 않습니다.</p>
    <p className="operations-dashboard__warning">주문 기록은 이 브라우저에만 저장됩니다. 다른 PC와 중앙 동기화되지 않으므로 백업 파일로 보관하세요.</p>
    {loadError && <p role="alert" className="order-deletion__error">{loadError} <button type="button" onClick={refresh}>다시 읽기</button></p>}
    {feedback && <p role={feedback.kind === 'error' ? 'alert' : 'status'} data-testid="order-maint-feedback"
      className={feedback.kind === 'error' ? 'order-deletion__error' : 'order-deletion__ok'}>{feedback.message}</p>}

    <h3>전체 원본 백업</h3>
    <button type="button" disabled={busy} onClick={download} data-testid="button-download-orders-backup">백업 다운로드 (삭제 기록 포함)</button>

    <h3>백업 가져오기</h3>
    <div className="order-maint__restore">
      <input type="file" accept="application/json,.json" disabled={busy} data-testid="input-backup-file"
        onChange={e => { const f = e.target.files?.[0]; if (!f) return; setBackupName(f.name); void f.text().then(setBackupText).catch(() => setFeedback({ kind: 'error', message: '파일을 읽지 못했습니다.' })); }} />
      <button type="button" disabled={busy || !backupText} onClick={() => void importBackup()} data-testid="button-import-backup">백업 가져오기</button>
    </div>
    {!backupText && <small data-testid="backup-disabled-reason">백업 파일을 선택하세요.</small>}

    <h3>삭제된 주문 · {deleted.length}건</h3>
    {!deleted.length && <p>삭제 표시된 주문이 없습니다.</p>}
    {deleted.map(order => <div className="order-maint__row" key={order.id} data-testid={`deleted-order-${order.id}`}>
      <strong>{order.customerName} · <code>{order.id}</code></strong>
      <span>{itemsOf(order)} · 총 {order.totalQuantity}벌</span>
      <small>삭제 {when(order.orderDeletion?.deletedAt)} · {order.orderDeletion?.adminLabel} ({order.orderDeletion?.adminId}) · 승인 {order.orderDeletion?.authorizationId}</small>
      <div className="order-maint__restore">
        <button type="button" disabled={busy} onClick={() => void restore(order)} data-testid={`button-restore-order-${order.id}`}>복원</button>
      </div>
    </div>)}

    <h3>삭제·복원 감사 기록</h3>
    {!audit.length && <p>기록이 없습니다.</p>}
    <div data-testid="order-deletion-audit">{audit.map((a, i) => <p className="order-maint__audit" key={`${a.orderId}-${a.at}-${i}`}>
      {when(a.at)} · {a.action === 'soft-delete' ? '삭제' : '복원'} · {a.customerName} <code>{a.orderId}</code> · {a.adminLabel} ({a.adminId}) · 처리 기록 {a.authorizationId}
    </p>)}</div>
  </section>;
}
