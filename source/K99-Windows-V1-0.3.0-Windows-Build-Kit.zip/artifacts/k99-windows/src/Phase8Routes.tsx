import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation } from 'wouter';
import CareResultCard from './CareResultCard';
import { getCustomerSafeResult, type CustomerSafeCareResult } from './garment-care';
import { activePhotosOf } from './manual-photo-link';
import { loadPhotoPreview } from './photo-source';
import { GarmentPhotoWorkspace } from './GarmentPhotoWorkspace';
import { SimpleStatisticsCenter } from './SimpleStatisticsCenter';
import { TodayOperationsCenter } from './TodayOperationsCenter';
import { StoreHardwareTest } from './StoreHardwareTest';
import { PhotoBridgeSettings } from './PhotoBridgeSettings';
import { clearActiveConfirmedOrder, readConfirmedOrders, resumeConfirmedOrder } from './order-record';
import { orderWorkspaceUrl } from './order-entry';
import './phase8-routes.css';

const READY = 'K99_CARE_RESULT_READY';
const DATA = 'K99_CARE_RESULT_DATA';
const NAVIGATE = 'K99_CARE_RESULT_NAVIGATE';
const MAX_CUSTOMER_IMAGE_DATA_URL = 900_000;

type CustomerImagePreview = {
  before: string | null;
  after: string | null;
  beforeStatus: 'pending' | 'available' | 'missing' | 'failed';
  afterStatus: 'pending' | 'available' | 'missing' | 'failed';
  beforeSimulated: boolean;
  afterSimulated: boolean;
};

type ResultPayload = {
  customerName: string;
  results: CustomerSafeCareResult[];
  index: number;
  images?: CustomerImagePreview;
};

function customerImageDataUrl(value: unknown): value is string {
  if (typeof value !== 'string' || value.length > MAX_CUSTOMER_IMAGE_DATA_URL) return false;
  const jpegPrefix = 'data:image/jpeg;base64,';
  if (value.startsWith(jpegPrefix)) {
    const encoded = value.slice(jpegPrefix.length);
    return /^[A-Za-z0-9+/]*={0,2}$/.test(encoded) && encoded.length % 4 === 0;
  }
  const svgPrefix = 'data:image/svg+xml;charset=utf-8,';
  if (!value.startsWith(svgPrefix)) return false;
  try {
    const svg = decodeURIComponent(value.slice(svgPrefix.length));
    return svg.length <= MAX_CUSTOMER_IMAGE_DATA_URL && /^<svg(?:\s|>)/i.test(svg)
      && !/<(?:script|foreignObject)\b|\son[a-z]+\s*=|(?:href|src)\s*=\s*["'](?:https?:|\/\/)/i.test(svg);
  } catch {
    return false;
  }
}

function validCustomerImagePreview(value: unknown): value is CustomerImagePreview {
  if (!value || typeof value !== 'object') return false;
  const images = value as Partial<CustomerImagePreview>;
  const status = (item: unknown) => ['pending', 'available', 'missing', 'failed'].includes(String(item));
  const image = (item: unknown) => item === null || customerImageDataUrl(item);
  return image(images.before) && image(images.after)
    && status(images.beforeStatus) && status(images.afterStatus)
    && typeof images.beforeSimulated === 'boolean' && typeof images.afterSimulated === 'boolean'
    && (images.beforeStatus !== 'available' || customerImageDataUrl(images.before))
    && (images.afterStatus !== 'available' || customerImageDataUrl(images.after));
}

function customerCareResult(order: ReturnType<typeof readConfirmedOrders>[number], garment: NonNullable<ReturnType<typeof readConfirmedOrders>[number]['garments']>[number]) {
  const condition = order.items[garment.itemIndex - 1]?.intakeDetails;
  const intakeCondition = [
    condition?.material && `소재: ${condition.material}`,
    condition?.color && `색상: ${condition.color}`,
    condition?.stain && `접수 오염: ${condition.stain}`,
    condition?.damage && `접수 손상: ${condition.damage}`,
  ].filter(Boolean).join(' · ');
  return getCustomerSafeResult(garment, { intakeCondition });
}

export function StaffManagementNav() {
  const [location, navigate] = useLocation();
  if (location.startsWith('/customer')) return null;
  return <nav className="phase8-staff-nav" aria-label="K99 직원 주요 화면">
    <button type="button" onClick={() => navigate('/')} aria-current={location === '/' ? 'page' : undefined}>접수</button>
    <button type="button" onClick={() => navigate('/laundry')} aria-current={location === '/laundry' || location.startsWith('/orders') || location.startsWith('/laundry-process') ? 'page' : undefined}
      data-testid="button-open-laundry-desk">세탁·검수</button>
    <button type="button" onClick={() => navigate('/scan')} aria-current={location === '/scan' ? 'page' : undefined}
      data-testid="button-open-scanner-desk">완성 의류·출고</button>
    <button type="button" onClick={() => navigate('/management')} aria-current={location.startsWith('/management') ? 'page' : undefined}
      data-testid="button-open-management-center">통합관리센터</button>
  </nav>;
}

export function ManagementRoute() {
  const [, navigate] = useLocation();
  return <SimpleStatisticsCenter
    onBack={() => navigate('/')}
    onNewIntake={() => { clearActiveConfirmedOrder(); navigate('/'); }}
  />;
}

export function PhotoBridgeSettingsRoute() {
  return <PhotoBridgeSettings />;
}

export function TodayOperationsRoute() {
  const [, navigate] = useLocation();
  return <TodayOperationsCenter
    onBack={() => navigate('/management')}
    onOpenHistory={(orderId) => navigate(`/management?orderId=${encodeURIComponent(orderId)}`)}
    onOpenOrder={(orderId) => {
      try { resumeConfirmedOrder(orderId); navigate(orderWorkspaceUrl(orderId)); }
      catch (cause) { window.alert(cause instanceof Error ? cause.message : '저장 주문을 열지 못했습니다.'); }
    }}
    onOpenPhoto={(orderId, garmentId) => navigate(`/photo/${encodeURIComponent(orderId)}/${encodeURIComponent(garmentId)}`)}
    onOpenStoreTest={() => navigate('/management/store-test')}
  />;
}

export function StoreHardwareTestRoute() {
  const [, navigate] = useLocation();
  return <StoreHardwareTest onBack={() => navigate('/management/today')}
    onOpenOrders={() => navigate('/?operations=1')} />;
}

export function PhotoWorkspaceRoute({ orderId, garmentId, onBack }: { orderId: string; garmentId?: string; onBack?: () => void }) {
  const [, navigate] = useLocation();
  const popup = useRef<Window | null>(null);
  const [selectedId, setSelectedId] = useState(garmentId ?? '');
  const [version, setVersion] = useState(0);
  const publishGeneration = useRef(0);
  const select = useCallback((id: string) => {
    publishGeneration.current += 1;
    setSelectedId(id);
  }, []);
  const updated = useCallback(() => {
    publishGeneration.current += 1;
    setVersion((value) => value + 1);
  }, []);

  const publish = useCallback(() => {
    if (!popup.current || popup.current.closed) return;
    const target = popup.current;
    const generation = ++publishGeneration.current;
    try {
      const order = readConfirmedOrders().find((item) => item.id === orderId);
      if (!order) return;
      const garments = order.garments ?? [];
      const index = garments.findIndex((item) => item.garmentId === selectedId);
      if (index < 0) return;
      const garment = garments[index];
      const payload: ResultPayload = {
        customerName: order.customerName,
        results: garments.map((item) => customerCareResult(order, item)),
        index,
        images: {
          before: null,
          after: null,
          beforeStatus: 'pending',
          afterStatus: 'pending',
          beforeSimulated: false,
          afterSimulated: false,
        },
      };
      popup.current.postMessage({ type: DATA, payload }, window.location.origin);
      const active = activePhotosOf(garment);
      const beforePhotos = active.filter((photo) => photo.role === 'intake');
      const before = beforePhotos.find((photo) => photo.requestId === garment.representativeBeforePhotoId)
        ?? beforePhotos[0];
      const after = active.filter((photo) => photo.role === 'completion')
        .reduce<(typeof active)[number] | undefined>((latest, photo) =>
          !latest || Date.parse(photo.timestamp) >= Date.parse(latest.timestamp) ? photo : latest, undefined);
      const resolveImage = async (photo: (typeof active)[number] | undefined) => {
        if (!photo) return { data: null, status: 'missing' as const, simulated: false };
        if (!photo.sourcePhotoId || (photo.origin !== 'simulation' && photo.origin !== 'bridge'))
          return { data: null, status: 'failed' as const, simulated: false };
        try {
          const data = await loadPhotoPreview(photo.sourcePhotoId, photo.origin);
          if (!customerImageDataUrl(data)) throw new Error('미리보기 크기 또는 형식이 허용 범위를 벗어납니다.');
          return { data, status: 'available' as const, simulated: photo.origin === 'simulation' };
        } catch {
          return { data: null, status: 'failed' as const, simulated: photo.origin === 'simulation' };
        }
      };
      void Promise.all([resolveImage(before), resolveImage(after)]).then(([beforeImage, afterImage]) => {
        if (generation !== publishGeneration.current || popup.current !== target || target.closed) return;
        const images: CustomerImagePreview = {
          before: beforeImage.data,
          after: afterImage.data,
          beforeStatus: beforeImage.status,
          afterStatus: afterImage.status,
          beforeSimulated: beforeImage.simulated,
          afterSimulated: afterImage.simulated,
        };
        target.postMessage({ type: DATA, payload: { ...payload, images } }, window.location.origin);
      });
    } catch {
      // Do not replace the last valid customer-facing view with a failed read.
    }
  }, [orderId, selectedId, version]);

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== popup.current) return;
      if (event.data?.type === READY) publish();
      if (event.data?.type === NAVIGATE && (event.data.delta === 1 || event.data.delta === -1)) {
        try {
          const garments = readConfirmedOrders().find((item) => item.id === orderId)?.garments ?? [];
          const next = garments.findIndex((item) => item.garmentId === selectedId) + event.data.delta;
          if (next >= 0 && next < garments.length) select(garments[next].garmentId);
        } catch { /* A failed read cannot change the selection. */ }
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [orderId, selectedId, publish, select]);
  useEffect(() => { publish(); }, [publish]);
  useEffect(() => () => { popup.current?.close(); }, []);

  const showCustomer = (_orderId: string, id: string) => {
    select(id);
    if (popup.current && !popup.current.closed) {
      popup.current.focus();
      return;
    }
    const path = `${import.meta.env.BASE_URL.replace(/\/$/, '')}/customer-result`;
    popup.current = window.open(path, 'k99-care-result', 'width=1140,height=850');
    if (!popup.current) window.alert('고객 화면을 열지 못했습니다. 팝업 차단 설정을 확인해 주세요.');
  };

  return <GarmentPhotoWorkspace key={orderId} orderId={orderId} initialGarmentId={garmentId}
    selectedGarmentId={selectedId} onSelectionChange={select} onOrderChange={updated}
    onBack={onBack ?? (() => navigate(`/orders/${encodeURIComponent(orderId)}`))} onShowCustomer={showCustomer} />;
}

export function CustomerResultRoute() {
  const [payload, setPayload] = useState<ResultPayload | null>(null);
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== window.opener
        || event.data?.type !== DATA) return;
      const incoming: unknown = event.data.payload;
      if (!incoming || typeof incoming !== 'object') return;
      const result = incoming as Partial<ResultPayload>;
      if (typeof result.customerName !== 'string' || !Array.isArray(result.results)
        || !Number.isInteger(result.index) || result.index! < 0 || result.index! >= result.results.length
        || (result.images !== undefined && !validCustomerImagePreview(result.images))) return;
      setPayload(result as ResultPayload);
    };
    window.addEventListener('message', onMessage);
    window.opener?.postMessage({ type: READY }, window.location.origin);
    return () => window.removeEventListener('message', onMessage);
  }, []);
  if (!payload) return <main className="phase8-result-wait" role="status">
    <h1>K99 고객 세탁 결과</h1><p>직원 화면에서 표시할 의류를 선택해 주세요.</p>
  </main>;
  return <CareResultCard result={payload.results[payload.index]} customerName={payload.customerName}
    imagePreviews={payload.images}
    onPrevious={payload.index > 0 ? () => window.opener?.postMessage({ type: NAVIGATE, delta: -1 }, window.location.origin) : undefined}
    onNext={payload.index < payload.results.length - 1
      ? () => window.opener?.postMessage({ type: NAVIGATE, delta: 1 }, window.location.origin) : undefined}
    onClose={() => { setPayload(null); window.close(); }} />;
}