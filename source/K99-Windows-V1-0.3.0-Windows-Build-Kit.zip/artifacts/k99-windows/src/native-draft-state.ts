import type { DraftNativeUnit } from './NativeDraftCamera';

/** Full native snapshots are cumulative. Delayed PC/phone replies must not erase newer shots. */
export function mergeDraftCapture(current: DraftNativeUnit[], incoming: DraftNativeUnit): DraftNativeUnit[] {
  const index = current.findIndex(u => u.unitKey === incoming.unitKey && u.itemId === incoming.itemId);
  if (index < 0) return [...current, incoming];
  const previous = current[index];
  if (previous.garment.garmentId !== incoming.garment.garmentId) return current;
  const known = previous.garment.photoHistory ?? [];
  const next = incoming.garment.photoHistory ?? [];
  if (known.some(photo => !next.some(p => p.requestId === photo.requestId))) return current;
  const snapshot={...incoming,garment:{...incoming.garment,
    ...(incoming.garment.materialTag===undefined&&previous.garment.materialTag!==undefined?{materialTag:previous.garment.materialTag}:{}),
    ...(incoming.garment.material_group===undefined?{material_group:previous.garment.material_group}:{}),
    ...(incoming.garment.wash_method===undefined?{wash_method:previous.garment.wash_method}:{}),
    ...(incoming.garment.color===undefined?{color:previous.garment.color}:{}),
    ...(previous.garment.isTagPrinted===true?{isTagPrinted:true,autoTagStatus:previous.garment.autoTagStatus}:{}),
  }};
  return current.map((unit, i) => i === index ? snapshot : unit);
}
