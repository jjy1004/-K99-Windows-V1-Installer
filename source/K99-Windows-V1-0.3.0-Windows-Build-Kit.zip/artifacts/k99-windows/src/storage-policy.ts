import type { ConfirmedOrder } from './order-record';

export const FREE_STORAGE_DAYS = 15;
export const STORAGE_FEE_PER_ITEM_PER_DAY = 1000;
export const STORAGE_REMINDER_DAYS = [9, 13] as const;
export type StorageReminderDay = typeof STORAGE_REMINDER_DAYS[number];

function parseCalendarDate(value: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('보관 날짜 형식을 확인해 주세요.');
  const timestamp = Date.parse(`${value}T00:00:00.000Z`);
  if (Number.isNaN(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== value)
    throw new Error('보관 날짜 형식을 확인해 주세요.');
  return timestamp;
}

/** Returns whole calendar-day boundaries, independent of local timezone and DST. */
export function calendarDaysBetween(startDate: string, endDate: string): number {
  const days = (parseCalendarDate(endDate) - parseCalendarDate(startDate)) / 86400000;
  if (!Number.isInteger(days) || days < 0) throw new Error('접수일보다 이전 날짜는 계산할 수 없습니다.');
  return days;
}

/** Converts timestamps to the Korean business calendar before applying date-only rules. */
export function koreaCalendarDate(value: string | Date): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error('보관 날짜를 확인해 주세요.');
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(date);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}

export function storageDaysElapsed(intakeDate: string, asOfDate: string): number {
  return calendarDaysBetween(intakeDate, asOfDate);
}

/** Intake day is day 1; day 16 is the first chargeable day. */
export function storageFee(intakeDate: string, asOfDate: string, itemCount: number): number {
  if (!Number.isSafeInteger(itemCount) || itemCount < 0) throw new Error('보관 세탁물 수량을 확인해 주세요.');
  const chargeableDays = Math.max(0, storageDaysElapsed(intakeDate, asOfDate) - (FREE_STORAGE_DAYS - 1));
  const fee = chargeableDays * itemCount * STORAGE_FEE_PER_ITEM_PER_DAY;
  if (!Number.isSafeInteger(fee)) throw new Error('보관료 계산 금액이 안전한 범위를 초과했습니다.');
  return fee;
}

export function intakeCalendarDate(order: Pick<ConfirmedOrder, 'intakeAt'>): string {
  return koreaCalendarDate(order.intakeAt);
}

export function daysSinceIntake(order: Pick<ConfirmedOrder, 'intakeAt'>, asOf: string | Date): number {
  return storageDaysElapsed(intakeCalendarDate(order), koreaCalendarDate(asOf));
}

export function currentStorageFee(order: Pick<ConfirmedOrder, 'intakeAt' | 'totalQuantity'>, asOf: string | Date): number {
  return storageFee(intakeCalendarDate(order), koreaCalendarDate(asOf), order.totalQuantity);
}