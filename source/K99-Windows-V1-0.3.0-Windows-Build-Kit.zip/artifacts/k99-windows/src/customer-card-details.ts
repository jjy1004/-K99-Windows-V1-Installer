import {openCustomerNotice,type NoticeOpenOptions} from './notice-api';

/** 카드의 빈 영역만 상세를 연다. 결제·삭제·알림 선택·출고 등의 독립 동작은 가로채지 않는다. */
export function isCustomerCardControl(target:EventTarget|null):boolean {
  return typeof Element!=='undefined' && target instanceof Element &&
    !!target.closest('button,input,select,textarea,a,summary,[role="button"],[data-card-control]');
}
export function openCustomerCardDetails(orderId:string,templateId='inspection-consent',onHandover?:NoticeOpenOptions['onHandover']):void {
  openCustomerNotice(orderId,templateId,{showOrderDetails:true,...(onHandover?{onHandover}:{})});
}
