import type { ReactNode } from 'react';

/** Display-only wrapper keeping a number and its unit on one line. Text content is unchanged. */
export function NumUnit({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={className ? `k99-num-unit ${className}` : 'k99-num-unit'}>{children}</span>;
}
