import type { CatalogEntry } from './price-catalog';
export type CustomItemFields = { customName?: string; customPrice?: number };
export function resolveRowPrice(row: { itemId: string } & CustomItemFields, catalog: readonly CatalogEntry[]): CatalogEntry {
  const base = catalog.find(item => item.id === row.itemId);
  if (!base) throw new Error('등록된 세탁 품목을 확인하세요.');
  if (row.itemId !== 'other') return base;
  const price = Number.isSafeInteger(row.customPrice) ? row.customPrice! : 0;
  return { ...base, displayNameKo: row.customName?.trim() || '기타 (품목명 미입력)', generalPrice: price, premiumPrice: price };
}
export function validateCustomRows(rows: readonly ({ itemId: string } & CustomItemFields)[]) {
  for (const row of rows) if (row.itemId === 'other') {
    if (!row.customName?.trim() || row.customName.trim().length > 100)
      throw new Error('기타 세탁물 품목명을 1~100자로 입력하세요.');
    if (!Number.isSafeInteger(row.customPrice) || row.customPrice! <= 0 || row.customPrice! > 100000000)
      throw new Error('기타 세탁비를 1원 이상 1억 원 이하의 정수로 입력하세요.');
  }
}
