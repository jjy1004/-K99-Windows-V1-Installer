import { useEffect, useRef, useState } from 'react';
import { searchCustomers, type DirectoryCustomer } from './customer-directory-client';
import {
  VOUCHER_PLANS, buildVoucherRequest, fetchVoucherHistory, notifyVoucherChanged, purchaseVoucher, voucherBlock,
  voucherDeduction, wonText, sameVoucherNumber, type VoucherAccount, type VoucherAccountState, type VoucherPlan, type VoucherReceipt, type VoucherRequest,
} from './vouchers';
import './voucher.css';

type AccountView = { status: VoucherAccountState['status']; account: VoucherAccount | null; error: string; refresh: () => void };

export function VoucherBadge({ label, balance, testId = 'badge-voucher' }: { label: string; balance: number; testId?: string }) {
  if (balance <= 0) return null;
  return <span className="voucher-badge" data-testid={testId}>{label} 고객 : + {wonText(balance)}</span>;
}

export function VoucherReceiptSummary({ receipt }: { receipt: VoucherReceipt }) {
  const buy = receipt.plan !== 'DEDUCT';
  return (
    <div className="voucher-receipt" data-testid="voucher-receipt-summary">
      <strong>{receipt.label} · {buy ? '구매 충전' : '차감'}</strong>
      <dl>
        {buy && <><dt>결제 금액</dt><dd>{wonText(receipt.paidAmount)}</dd><dt>충전 금액</dt><dd>{wonText(receipt.credit)}</dd></>}
        {receipt.debit > 0 && <><dt>세탁비 차감</dt><dd>- {wonText(receipt.debit)}</dd></>}
        <dt>이전 잔액</dt><dd>{wonText(receipt.balanceBefore)}</dd>
        <dt>남은 잔액</dt><dd data-testid="text-voucher-balance-after">{wonText(receipt.balanceAfter)}</dd>
        {receipt.number && <><dt>정액권 번호</dt><dd>{receipt.number}</dd></>}
      </dl>
      {receipt.shortfall > 0 && <p className="voucher-warn" role="alert">부족 차액 {wonText(receipt.shortfall)}은 미납입니다. 별도로 받아 주세요.</p>}
    </div>
  );
}

function HistoryDialog({ customerId, onClose }: { customerId: string; onClose: () => void }) {
  const [data, setData] = useState<{ history: Record<string, unknown>[] } | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let live = true; setData(null); setError('');
    fetchVoucherHistory(customerId).then(r => { if (live) setData(r); })
      .catch(e => { if (live) setError(e instanceof Error ? e.message : '이력 조회 실패'); });
    return () => { live = false; };
  }, [customerId, attempt]);
  const num = (v: unknown) => typeof v === 'number' ? wonText(v) : '-';
  return (
    <div className="voucher-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={e => { e.stopPropagation(); if (e.key === 'Escape') onClose(); }}>
      <div className="voucher-dialog" role="dialog" aria-modal="true" aria-label="정액권 충전·차감 이력">
        <div className="voucher-row"><h2>정액권 충전·차감 이력</h2>
          <button type="button" className="voucher-btn" autoFocus onClick={onClose} data-testid="button-voucher-history-close">닫기</button></div>
        {error ? <p className="voucher-warn" role="alert">{error} <button type="button" className="voucher-btn" onClick={() => setAttempt(a => a + 1)}>다시 시도</button></p>
          : !data ? <div className="voucher-skel" aria-busy="true" />
          : !data.history.length ? <p className="voucher-hint">충전·차감 기록이 없습니다.</p>
          : <table className="voucher-table" data-testid="table-voucher-history">
              <thead><tr><th>일시</th><th>구분</th><th>충전</th><th>차감</th><th>잔액</th><th>당시 별도 결제액</th></tr></thead>
              <tbody>{data.history.map((h, i) => (
                <tr key={String(h.id ?? i)}>
                  <td>{typeof h.createdAt === 'string' ? new Date(h.createdAt).toLocaleString('ko-KR') : '-'}</td>
                  <td>{h.plan === 'DEDUCT' ? '차감' : h.plan === 'BUY_100' || h.plan === 'BUY_200' ? '충전' : h.plan === 'RETURN' ? '취소 차감 복원' : h.plan === 'REAPPLY' ? '취소 복구 재차감' : '확인 필요'}</td>
                  <td>{num(h.credit)}</td><td>{num(h.debit)}</td><td>{num(h.balanceAfter)}</td>
                  <td>{typeof h.shortfall === 'number' && h.shortfall > 0 ? wonText(h.shortfall) : '-'}</td>
                </tr>))}</tbody>
            </table>}
      </div>
    </div>
  );
}

export function VoucherControls({ customerId, name, phone, address, account, value, onChange, laundryTotal, hasItems, onSelectCustomer, onPurchased, locked }: {
  customerId: string; name: string; phone: string; address: string; account: AccountView;
  value: VoucherRequest | null; onChange: (v: VoucherRequest | null) => void; laundryTotal: number; hasItems: boolean;
  onSelectCustomer: (c: DirectoryCustomer) => void; onPurchased: (r: VoucherReceipt, a: VoucherAccount) => void; locked?: boolean;
}) {
  const [lookup, setLookup] = useState('');
  const [lookupState, setLookupState] = useState<{ busy: boolean; error: string; results: DirectoryCustomer[] }>({ busy: false, error: '', results: [] });
  const lookupSeq = useRef(0);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [buying, setBuying] = useState(false);
  const [buyError, setBuyError] = useState('');
  const requestIdRef = useRef<{ key: string; id: string } | null>(null);
  const acc = account.account;
  const block = voucherBlock(value, account);
  const identityReady = account.status !== 'idle';
  const identityKey = `${customerId}|${name.trim()}|${phone.replace(/\D/g, '')}`;
  const plan = value?.plan ?? null;

  // Customer switch: drop the old request so it can never apply to someone else.
  const lastCustomer = useRef(identityKey);
  useEffect(() => {
    if (lastCustomer.current !== identityKey) { lastCustomer.current = identityKey; onChange(null); setBuyError(''); requestIdRef.current = null; }
  }, [identityKey, onChange]);

  const runLookup = async () => {
    const q = lookup.trim();
    if (!q) return;
    const id = ++lookupSeq.current;
    setLookupState({ busy: true, error: '', results: [] });
    try {
      const r = await searchCustomers(q);
      if (id !== lookupSeq.current) return;
      const list = r.customers.filter(c => c.voucher && sameVoucherNumber(c.voucher.number, q) && c.voucher.customerId === c.id);
      setLookupState({ busy: false, error: list.length ? '' : '해당 정액권 번호의 고객을 찾지 못했습니다.', results: list });
      if (list.length === 1) { onSelectCustomer(list[0]); setLookupState({ busy: false, error: '', results: [] }); setLookup(''); }
    } catch (e) {
      if (id === lookupSeq.current) setLookupState({ busy: false, error: e instanceof Error ? e.message : '번호 조회 실패', results: [] });
    }
  };

  const setPlan = (p: VoucherPlan | null) => { requestIdRef.current = null; setBuyError(''); onChange(p ? { plan: p, number: value?.number } : null); };

  const buyAlone = async () => {
    if (!value || value.plan === 'DEDUCT' || block || buying) return;
    const key = `${identityKey}|${value.plan}|${value.number ?? ''}`;
    if (!requestIdRef.current || requestIdRef.current.key !== key) requestIdRef.current = { key, id: crypto.randomUUID() };
    const forCustomer = identityKey;
    setBuying(true); setBuyError('');
    try {
      const r = await purchaseVoucher({
        requestId: requestIdRef.current.id, customerName: name.trim(), customerPhone: phone, customerAddress: address,
        directoryCustomerId: customerId || undefined, request: buildVoucherRequest(value, acc)!,
      });
      if (lastCustomer.current !== forCustomer) return;
      requestIdRef.current = null;
      onChange(null);
      notifyVoucherChanged();
      onPurchased(r.receipt, r.account);
    } catch (e) {
      setBuyError(`${e instanceof Error ? e.message : '정액권 구매 저장 실패'} · 다시 누르면 같은 요청으로 재시도하며 중복 충전되지 않습니다.`);
    } finally { setBuying(false); }
  };

  const ded = acc ? voucherDeduction(acc.balance, laundryTotal) : null;
  return (
    <section className="voucher-panel" aria-label="정액권" data-testid="section-voucher">
      <div className="voucher-row">
        <strong className="voucher-title">정액권</strong>
        {account.status === 'loading' && <span className="voucher-skel voucher-skel--inline" aria-label="정액권 확인 중" />}
        {account.status === 'ready' && acc && <span className="voucher-chip" data-testid="text-voucher-account">{acc.label} · 잔액 {wonText(acc.balance)}{acc.number ? ` · No.${acc.number}` : ''}</span>}
        {account.status === 'ready' && !acc && <span className="voucher-hint">보유 정액권 없음</span>}
        {account.status === 'error' && <span className="voucher-warn" role="alert">조회 실패: {account.error} <button type="button" className="voucher-btn" onClick={account.refresh} data-testid="button-voucher-retry">다시 조회</button></span>}
        {acc && <button type="button" className="voucher-btn" onClick={() => setHistoryOpen(true)} data-testid="button-voucher-history">충전·차감 이력</button>}
      </div>
      <div className="voucher-row">
        <input className="voucher-input" value={lookup} placeholder="정액권 번호로 고객 찾기" inputMode="numeric" aria-label="정액권 번호 조회"
          onChange={e => setLookup(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); void runLookup(); } }}
          data-testid="input-voucher-lookup" disabled={locked} />
        <button type="button" className="voucher-btn" onClick={() => void runLookup()} disabled={locked || lookupState.busy || !lookup.trim()} data-testid="button-voucher-lookup">
          {lookupState.busy ? '조회 중' : '번호 조회'}</button>
      </div>
      {lookupState.error && <p className="voucher-warn" role="alert">{lookupState.error}</p>}
      {lookupState.results.length > 1 && <ul className="voucher-results">{lookupState.results.map(c => (
        <li key={c.id}><button type="button" className="voucher-btn" onClick={() => { onSelectCustomer(c); setLookupState({ busy: false, error: '', results: [] }); setLookup(''); }}
          data-testid={`button-voucher-pick-${c.id}`}>{c.name} · {c.phone.slice(-4)} · {c.voucher?.label}</button></li>))}</ul>}
      {!locked && <>
        <div className="voucher-plans" role="radiogroup" aria-label="정액권 처리">
          {([[null, '사용 안 함'], ['BUY_100', '10만 원 구매 (11만 충전)'], ['BUY_200', '20만 원 구매 (23만 충전)'], ['DEDUCT', '잔액에서 차감']] as const).map(([p, label]) => (
            <label key={String(p)} className={`voucher-plan${plan === p ? ' is-on' : ''}`}>
              <input type="radio" name="voucher-plan" checked={plan === p} onChange={() => setPlan(p)} disabled={!identityReady && p !== null}
                data-testid={`radio-voucher-${p ?? 'none'}`} />{label}
            </label>))}
        </div>
        {!identityReady && <p className="voucher-hint">고객명과 전체 휴대전화번호를 입력하거나 정액권 번호로 조회하면 정액권을 사용할 수 있습니다.</p>}
        {value && value.plan !== 'DEDUCT' && <label className="voucher-row">정액권 번호(선택)
          <input className="voucher-input" value={value.number ?? ''} maxLength={40} onChange={e => onChange({ ...value, number: e.target.value })} data-testid="input-voucher-number" /></label>}
        {value && value.plan !== 'DEDUCT' && <p className="voucher-hint">결제 {wonText(VOUCHER_PLANS[value.plan].paid)} → {wonText(VOUCHER_PLANS[value.plan].credit)} 충전{acc ? ` · 기존 잔액에 누적` : ''}</p>}
        {value?.plan === 'DEDUCT' && ded && <p className="voucher-hint" data-testid="text-voucher-deduct-preview">세탁비 {wonText(laundryTotal)} 중 {wonText(ded.debit)} 차감 · 남은 잔액 {wonText(ded.after)}
          {ded.shortfall > 0 && <b className="voucher-warn"> · 부족 {wonText(ded.shortfall)} 미납 안내</b>}</p>}
        {block && <p className="voucher-warn" role="status" data-testid="status-voucher-block">{block}</p>}
        {value && value.plan !== 'DEDUCT' && !hasItems && <button type="button" className="voucher-btn voucher-btn--main" disabled={!!block || buying}
          onClick={() => void buyAlone()} data-testid="button-voucher-buy-alone">{buying ? '저장 중…' : '정액권만 구매 확정 · 영수증'}</button>}
        {buyError && <p className="voucher-warn" role="alert">{buyError}</p>}
      </>}
      {historyOpen && acc && <HistoryDialog customerId={acc.customerId} onClose={() => setHistoryOpen(false)} />}
    </section>
  );
}
