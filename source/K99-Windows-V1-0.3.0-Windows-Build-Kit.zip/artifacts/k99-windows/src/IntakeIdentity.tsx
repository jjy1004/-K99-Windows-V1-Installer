import './intake-identity.css';
import { koreaCalendarDate } from './storage-policy';

/** Match the existing Korean business calendar, without inventing a date. */
export function intakeDateCode(value: unknown): string | null {
  if (typeof value !== 'string' || !value.trim()) return null;
  const text = value.trim();
  // Reject rollover dates (for example February 31), which Date otherwise accepts.
  const match = /^(\d{4})-(\d{2})-(\d{2})(?:$|T| )/.exec(text);
  if (!match) return null;
  const [, y, m, d] = match;
  const calendar = new Date(Date.UTC(+y, +m - 1, +d));
  if (calendar.getUTCFullYear() !== +y || calendar.getUTCMonth() !== +m - 1 || calendar.getUTCDate() !== +d) return null;
  const date = new Date(text);
  if (!Number.isFinite(date.getTime())) return null;
  // Historical date-only / unzoned records already denote a shop calendar day.
  if (!/(?:Z|[+-]\d{2}:?\d{2})$/i.test(text)) return `${y.slice(-2)}${m}${d}`;
  return koreaCalendarDate(date).replace(/-/g, '').slice(2);
}

export function IntakeDateBadge({ intakeAt }: { intakeAt: unknown }) {
  const code = intakeDateCode(intakeAt);
  return <span className="intake-date-badge" aria-label={code ? `접수 날짜 ${code}` : '접수일 미상'}>{code ?? '접수일 미상'}</span>;
}

export function IntakeIdentity({ order }: { order: { intakeAt?: string; customerName: string; customerPhone: string } }) {
  return <span className="intake-identity intake-identity--customer"><IntakeDateBadge intakeAt={order.intakeAt} />
    <span>{order.customerName}</span><span className="intake-identity__phone">{order.customerPhone || '전화번호 미등록'}</span></span>;
}
