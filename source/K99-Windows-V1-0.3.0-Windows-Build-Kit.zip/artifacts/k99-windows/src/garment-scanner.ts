import { createGarmentRecords, type GarmentCompletionMethod, type GarmentRecord } from './garment-record.ts';
import { readAllConfirmedOrders, readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record.ts';
import { completeLaundryByScan, currentOperations } from './order-operations.ts';
import { completionNoticeText } from './customer-notice-text.ts';
import { normalGarmentApproved } from './normal-inspection-policy';
import { hasRecordedStoreTagSubmission } from './tag-action-policy';

export const GARMENT_READY_STATUS = 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER' as const;
export const ORDER_READY_STATUS = '전체 세탁 완료 / 반출 대기' as const;
const UNKNOWN_AUDIT_KEY = 'k99-unknown-barcode-audit-v1';

export type ScanAuditEvent = {
  timestamp: string;
  orderId?: string;
  garmentId?: string;
  barcodeValue: string;
  eventType: 'BARCODE_SCANNED' | 'GARMENT_COMPLETED' | 'DUPLICATE_SCAN' |
    'UNKNOWN_BARCODE' | 'SCAN_BLOCKED' | 'COMPLETION_UNDONE' | 'ORDER_COMPLETED' | 'MESSAGE_PREPARED';
  previousStatus?: string;
  newStatus?: string;
  scanResult: 'completed' | 'duplicate' | 'unknown' | 'blocked' | 'undone' | 'prepared';
  operator?: string;
  details?: string;
};

export type ScanResult = {
  outcome: 'completed' | 'duplicate' | 'unknown' | 'blocked';
  message: string;
  order?: ConfirmedOrder;
  garment?: GarmentRecord;
  completedCount?: number;
  total?: number;
  event: ScanAuditEvent;
};

export function listGarments(order: ConfirmedOrder): GarmentRecord[] {
  return order.garments ?? createGarmentRecords(order);
}

function findUniqueGarment(orders: ConfirmedOrder[], barcodeValue: string):
  { order: ConfirmedOrder; garment: GarmentRecord } | null {
  // UUID hex digits have no case distinction. Only this full UUID+sequence
  // format gets transport-case tolerance; never shorten or reconstruct an ID.
  const uuidGarment = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-[0-9]{2,}$/i;
  const uuidInput = uuidGarment.test(barcodeValue);
  const matches = orders.flatMap((order) => listGarments(order)
    .filter((garment) => garment.garmentId === barcodeValue || garment.barcodeValue === barcodeValue ||
      (uuidInput && uuidGarment.test(garment.garmentId) &&
        garment.garmentId.toLowerCase() === barcodeValue.toLowerCase()))
    .map((garment) => ({ order, garment })));
  if (matches.length > 1)
    throw new Error('같은 세탁물 ID가 여러 기록에 있어 조회·완료 처리를 중단했습니다. 접수 기록을 확인해 주세요.');
  const match = matches[0];
  if (!match) return null;
  if (match.garment.orderId !== match.order.id)
    throw new Error('세탁물의 접수 ID와 저장된 접수 기록이 일치하지 않습니다. 기록을 확인해 주세요.');
  // Historical tags may use a distinct saved barcode. Match the full saved
  // value uniquely above; never manufacture or rewrite the garment identity.
  if (match.garment.barcodeValue !== match.garment.garmentId &&
      barcodeValue !== match.garment.barcodeValue)
    throw new Error('저장된 의류 바코드와 의류 ID가 일치하지 않습니다. 원본 태그 값으로 조회해 주세요.');
  return match;
}

export function findSavedGarment(barcode: string): { order: ConfirmedOrder; garment: GarmentRecord } | null {
  const barcodeValue = barcode.trim();
  if (!barcodeValue || barcodeValue.length > 160 || /[\x00-\x1f\x7f]/.test(barcodeValue))
    throw new Error('유효한 의류 바코드를 입력해 주세요.');
  return findUniqueGarment(readConfirmedOrders(), barcodeValue);
}

export function isGarmentComplete(garment: GarmentRecord): boolean {
  return garment.status === GARMENT_READY_STATUS || garment.completionStatus === 'complete';
}

function eventFor(barcodeValue: string, eventType: ScanAuditEvent['eventType'],
  scanResult: ScanAuditEvent['scanResult'], timestamp: string, operator?: string,
  orderId?: string, garmentId?: string, previousStatus?: string,
  newStatus?: string, details?: string): ScanAuditEvent {
  return { timestamp, barcodeValue, eventType, scanResult,
    ...(operator?.trim() && { operator: operator.trim() }),
    ...(orderId && { orderId }), ...(garmentId && { garmentId }),
    ...(previousStatus && { previousStatus }), ...(newStatus && { newStatus }),
    ...(details && { details }) };
}

function readUnknownEvents(): ScanAuditEvent[] {
  const raw = window.localStorage.getItem(UNKNOWN_AUDIT_KEY);
  if (!raw) return [];
  const value: unknown = JSON.parse(raw);
  if (!Array.isArray(value) || !value.every((item) => item && typeof item === 'object'
    && typeof item.timestamp === 'string' && typeof item.barcodeValue === 'string')) {
    throw new Error('미등록 바코드 스캔 기록을 읽을 수 없습니다.');
  }
  return value as ScanAuditEvent[];
}

export function readScanAuditLog(): ScanAuditEvent[] {
  return [...readUnknownEvents(), ...readConfirmedOrders().flatMap((order) => order.scanAuditEvents ?? [])]
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

function completionDraft(order: ConfirmedOrder): string {
  return completionNoticeText(order);
}

export function scanSavedGarment(
  barcode: string, method: GarmentCompletionMethod, operator?: string, at = new Date(), reason?: string,
  issuedTagReady = false,
): ScanResult {
  const barcodeValue = barcode.trim();
  if (!barcodeValue || barcodeValue.length > 160 || /[\x00-\x1f\x7f]/.test(barcodeValue))
    throw new Error('유효한 의류 바코드를 입력해 주세요.');
  if (!['scanner', 'simulation', 'manual-entry', 'manual'].includes(method))
    throw new Error('스캔 입력 방식을 확인해 주세요.');
  if (method === 'manual' && !reason?.trim()) throw new Error('수동 완료 사유를 입력해 주세요.');
  const timestamp = at.toISOString();
  const orders = readAllConfirmedOrders();
  const match = findUniqueGarment(orders, barcodeValue);
  if (!match) {
    const event = eventFor(barcodeValue, 'UNKNOWN_BARCODE', 'unknown', timestamp, operator);
    const previous = readUnknownEvents();
    window.localStorage.setItem(UNKNOWN_AUDIT_KEY, JSON.stringify([...previous, event]));
    return { outcome: 'unknown', message: '등록되지 않은 세탁물 태그입니다.', event };
  }
  const { order, garment } = match;
  if (order.orderDeletion) throw new Error('관리자가 삭제한 주문의 태그입니다. 스캔으로 복구하거나 출고 준비할 수 없습니다.');
  const garments = listGarments(order);
  const base = { order, garment, completedCount: garments.filter(isGarmentComplete).length, total: garments.length };
  if (isGarmentComplete(garment)) {
    const event = eventFor(barcodeValue, 'DUPLICATE_SCAN', 'duplicate', timestamp, operator,
      order.id, garment.garmentId, GARMENT_READY_STATUS, GARMENT_READY_STATUS);
    const updated = { ...order, garments, scanAuditEvents: [...(order.scanAuditEvents ?? []), event] };
    updateSavedOrder(updated, order);
    return { ...base, order: updated, outcome: 'duplicate',
      message: `이미 완료 처리된 세탁물입니다. ${garment.itemName} · ${garment.garmentId} · 최초 완료: ${garment.completedAt ?? '기존 기록'}`, event };
  }
  if (issuedTagReady && (order.operations?.cancelledAt || order.operations?.completedAt || garment.handoverStatus === 'complete'))
    throw new Error('취소되었거나 실제 인도된 주문은 출고 준비로 변경할 수 없습니다.');
  if (issuedTagReady && !['generated', 'printed', 'print-requested'].includes(garment.tagStatus)
      && !hasRecordedStoreTagSubmission(garment))
    throw new Error('정상 발행된 태그가 아닙니다. 태그 발행 기록을 확인하세요.');
  if (!issuedTagReady && garments.some((item) => item.processStatus) && garment.processStatus !== '출고 대기') {
    const event = eventFor(barcodeValue, 'SCAN_BLOCKED', 'blocked', timestamp, operator,
      order.id, garment.garmentId, garment.processStatus, undefined, '완성 검수를 마친 의류만 완료 스캔할 수 있습니다.');
    const updated = { ...order, garments, scanAuditEvents: [...(order.scanAuditEvents ?? []), event] };
    updateSavedOrder(updated, order);
    return { ...base, order: updated, outcome: 'blocked',
      message: '세탁 진행 관리에서 완성 검수를 마친 뒤 완료 스캔해 주세요.', event };
  }
  const stage = currentOperations(order).stage;
  // A normal sibling outside an explicit consent scope proceeds on its own evidence;
  // the scoped exceptional garment (or any unscoped order) still waits.
  const scope = order.inspection?.affectedGarmentIds;
  const scopedNormal = !!order.inspection?.inspectedAt && !!scope?.length && !scope.includes(garment.garmentId)
    && new Set(scope).size === scope.length
    && scope.every(id => garments.some(g => g.orderId === order.id && g.garmentId === id))
    && ['고객 회신 대기', '보류', '세탁 진행 거절'].includes(order.status);
  const normalApproved = normalGarmentApproved(order, garment);
  if (!issuedTagReady && !scopedNormal && (order.status === '고객 회신 대기' || (order.inspection?.needsApproval &&
      order.status === '보류'))) {
    const warning = '고객 동의가 완료되지 않은 세탁물입니다.';
    const event = eventFor(barcodeValue, 'SCAN_BLOCKED', 'blocked', timestamp, operator,
      order.id, garment.garmentId, garment.status ?? garment.completionStatus, undefined,
      `${warning} 고객 회신·동의 항목을 직원이 확인해야 합니다.`);
    const updated = { ...order, garments, scanAuditEvents: [...(order.scanAuditEvents ?? []), event] };
    updateSavedOrder(updated, order);
    return { ...base, order: updated, outcome: 'blocked',
      message: `${warning} 고객 회신과 필요한 동의 항목을 직원이 확인한 뒤 다시 스캔해 주세요.`, event };
  }
  if (!issuedTagReady && ((order.status !== '세탁 진행 승인' && !scopedNormal && !normalApproved) ||
      (!order.inspection && !normalApproved) ||
      order.operations?.cancelledAt || order.operations?.completedAt ||
      !(['매장입고', '세탁중', '세탁완료'] as string[]).includes(stage))) {
    const event = eventFor(barcodeValue, 'SCAN_BLOCKED', 'blocked', timestamp, operator,
      order.id, garment.garmentId, garment.status ?? garment.completionStatus, undefined,
      '전문 검수·고객 승인·매장 입고 또는 주문 취소 상태를 확인해야 합니다.');
    const updated = { ...order, garments, scanAuditEvents: [...(order.scanAuditEvents ?? []), event] };
    updateSavedOrder(updated, order);
    return { ...base, order: updated, outcome: 'blocked',
      message: '전문 검수·고객 승인·매장 입고 상태를 확인해 주세요. 수거 전이나 인도 후에는 완료할 수 없습니다.', event };
  }
  const event = eventFor(barcodeValue, 'GARMENT_COMPLETED', 'completed', timestamp, operator,
    order.id, garment.garmentId, garment.status ?? garment.completionStatus,
    GARMENT_READY_STATUS, method === 'manual' ? reason?.trim() : undefined);
  const updatedGarment: GarmentRecord = {
    ...garment, status: GARMENT_READY_STATUS, completionStatus: 'complete',
    ...(issuedTagReady ? { processStatus: '출고 대기' as const, processUpdatedAt: timestamp } : {}),
    completedAt: timestamp, scannedAt: timestamp, lastScannedAt: timestamp, completionMethod: method,
    auditEvents: [...(garment.auditEvents ?? []), {
      at: timestamp, type: 'barcode-scan', status: GARMENT_READY_STATUS,
      details: `${method}${operator?.trim() ? ` · ${operator.trim()}` : ''}${reason?.trim() ? ` · ${reason.trim()}` : ''}`,
    }],
  };
  // Commit against the resolved original ID, not the keyboard's casing.
  const updatedGarments = garments.map((item) => item.garmentId === garment.garmentId ? updatedGarment : item);
  const allDone = updatedGarments.every(isGarmentComplete);
  const operations = currentOperations(order);
  const needsStageUpdate = allDone && operations.stage !== '세탁완료';
  const message = allDone ? completionDraft(order) : '';
  const stagedOrder = needsStageUpdate ? completeLaundryByScan(order, message, at, issuedTagReady) : order;
  const events: ScanAuditEvent[] = [...(order.scanAuditEvents ?? []),
    eventFor(barcodeValue, 'BARCODE_SCANNED', 'completed', timestamp, operator, order.id, garment.garmentId),
    event, ...(allDone ? [eventFor(barcodeValue, 'ORDER_COMPLETED', 'completed', timestamp,
      operator, order.id, garment.garmentId, order.status, ORDER_READY_STATUS)] : [])];
  const updated: ConfirmedOrder = { ...stagedOrder, garments: updatedGarments, scanAuditEvents: events,
    ...(allDone ? { status: ORDER_READY_STATUS, orderCompletedAt: timestamp,
      completionMessage: { message, generatedAt: timestamp,
        status: '초안' as const, actuallySent: false as const } } : {}) };
  if (needsStageUpdate) updated.preCompletionStage = operations.stage;
  updateSavedOrder(updated, order);
  return { outcome: 'completed', message: allDone
    ? '전체 세탁 완료 / 반출 대기 · 고객 안내문 초안을 생성했습니다. 발송하지 않았습니다.'
    : `${updatedGarment.itemName} · ${updatedGarments.filter(isGarmentComplete).length}/${updatedGarments.length} 완료`,
  order: updated, garment: updatedGarment, completedCount: updatedGarments.filter(isGarmentComplete).length,
  total: updatedGarments.length, event };
}

/** Explicit V1 staff policy: issued tag means ready, not proof of washing, QC or customer consent. */
export function scanIssuedTagForHandover(barcode: string, method: GarmentCompletionMethod = 'scanner',
  operator?: string, at = new Date(), reason?: string): ScanResult {
  return scanSavedGarment(barcode, method, operator, at, reason, true);
}

export function undoSavedGarment(garmentId: string, reason: string, operator?: string, at = new Date()): ConfirmedOrder {
  if (!reason.trim()) throw new Error('완료 취소 사유를 입력해 주세요.');
  const order = readConfirmedOrders().find((entry) => listGarments(entry).some((item) => item.garmentId === garmentId));
  if (!order) throw new Error('해당 의류 기록을 찾지 못했습니다.');
  const garments = listGarments(order);
  const garment = garments.find((item) => item.garmentId === garmentId)!;
  if (!isGarmentComplete(garment)) throw new Error('완료되지 않은 의류는 취소할 수 없습니다.');
  if (order.operations?.completedAt || (order.status === ORDER_READY_STATUS &&
      order.operations && !(['매장입고', '세탁중', '세탁완료'] as string[]).includes(order.operations.stage)))
    throw new Error('이미 인도·포장 단계로 진행한 주문입니다. 주문 기록을 확인해 주세요.');
  const timestamp = at.toISOString();
  const event = eventFor(garmentId, 'COMPLETION_UNDONE', 'undone', timestamp, operator,
    order.id, garmentId, GARMENT_READY_STATUS, 'pending', reason.trim());
  const updated: ConfirmedOrder = { ...order,
    garments: garments.map((item) => item.garmentId === garmentId
      ? { ...item, status: undefined, completionStatus: 'pending', completedAt: undefined,
        ...(item.processStatus === '출고 대기' ? { processStatus: '완성 검수' as const, processUpdatedAt: timestamp } : {}),
        completionMethod: undefined, auditEvents: [...(item.auditEvents ?? []),
          { at: timestamp, type: 'completion-undo', status: 'pending', details: reason.trim(),
            ...(item.processStatus === '출고 대기' ? {
              orderId: order.id, garmentId, previousStatus: '출고 대기' as const,
              newStatus: '완성 검수' as const, source: 'manual' as const,
            } : {}) }] } : item),
    scanAuditEvents: [...(order.scanAuditEvents ?? []), event],
    ...(order.status === ORDER_READY_STATUS ? { status: '세탁 진행 승인' as const, orderCompletedAt: undefined,
      preCompletionStage: undefined,
      ...(order.preCompletionStage && order.operations?.stage === '세탁완료'
        ? { operations: { ...order.operations, stage: order.preCompletionStage, updatedAt: timestamp,
          notifications: order.operations.notifications.filter((notice) =>
            notice.id !== `${order.id}-${order.orderCompletedAt}-scanner-completion`) },
          history: [...(order.history ?? []), { at: timestamp, kind: 'operations-update' as const,
            details: { action: 'scanner-completion-undo', previous: '세탁완료',
              revised: order.preCompletionStage, reason: reason.trim() } }] } : {}),
      completionMessage: order.completionMessage
        ? { ...order.completionMessage, status: '취소됨' as const, actuallySent: false as const } : undefined } : {}),
  };
  updateSavedOrder(updated, order);
  return updated;
}

export function reviewCompletionMessage(orderId: string, text: string, operator?: string, at = new Date()): ConfirmedOrder {
  if (!text.trim()) throw new Error('고객 안내문 내용을 입력해 주세요.');
  const order = readConfirmedOrders().find((item) => item.id === orderId);
  if (!order || order.status !== ORDER_READY_STATUS || order.completionMessage?.status === '취소됨'
      || !order.completionMessage) throw new Error('완료된 주문의 고객 안내문 초안을 찾을 수 없습니다.');
  const timestamp = at.toISOString();
  const message = text.trim();
  const notificationId = `${order.id}-${order.orderCompletedAt}-scanner-completion`;
  const updated: ConfirmedOrder = { ...order,
    completionMessage: { ...order.completionMessage, message, status: '발송 준비',
      reviewedAt: timestamp, actuallySent: false },
    ...(order.operations ? { operations: { ...order.operations,
      notifications: order.operations.notifications.map((notice) =>
        notice.id === notificationId ? { ...notice, message } : notice) } } : {}),
    scanAuditEvents: [...(order.scanAuditEvents ?? []),
      eventFor('', 'MESSAGE_PREPARED', 'prepared', timestamp, operator, order.id, undefined,
        '초안', '발송 준비', '직원 검토 완료 · 실제 발송 안 함')],
    history: [...(order.history ?? []), { at: timestamp, kind: 'staff-message-review',
      details: { trigger: '세탁완료', message, operator: operator?.trim(), actuallySent: false } }],
  };
  updateSavedOrder(updated, order);
  return updated;
}