export const CUSTOMER_VIDEO_FILES = {
  value: 'web/value-v1.mp4',
  process: 'web/process-v1.mp4',
  water: 'web/water-v1.mp4',
  sneakers: 'web/sneakers-v1.mp4',
} as const;
export const CUSTOMER_ORIGINAL_VIDEO_FILES = {
  value: '01_가치 세탁.mp4', process: '02_세탁과정.mp4',
  water: '03_물세탁.mp4', sneakers: '03_운동화.mp4',
} as const;
// Mapping verified from the actual pictures/subtitles, not the legacy filenames.
export const CUSTOMER_VIDEO_BUTTONS = [
  { label: '세탁 가격 안내', video: 'value', testId: 'button-customer-price-video' },
  { label: '세탁 안내', video: 'process', testId: 'button-customer-water-video' },
  { label: '드라이세탁 안내', video: 'water', testId: 'button-customer-dry-video' },
  { label: '프리미엄 운동화', video: 'sneakers', testId: 'button-customer-sneakers-video' },
] as const;
export const CUSTOMER_MEDIA_COMMAND = 'k99-customer-media-command';
export const CUSTOMER_MEDIA_ACK = 'k99-customer-media-ack';
export type ManualCustomerVideo = keyof typeof CUSTOMER_VIDEO_FILES;
export type CustomerMediaCommand = { id: string; video: ManualCustomerVideo; issuedAt?: number };
export type CustomerMediaState = { phase: 'prices' | ManualCustomerVideo; commandId: string | null };
export type CustomerMediaEvent =
  | { type: 'ended' } | { type: 'playback-failed' }
  | { type: 'manual'; command: CustomerMediaCommand };
export const INITIAL_CUSTOMER_MEDIA: CustomerMediaState = { phase: 'prices', commandId: null };
export function customerVideoPath(video: ManualCustomerVideo, base = '/') {
  return `${base.replace(/\/?$/, '/')}media/${CUSTOMER_VIDEO_FILES[video].split('/').map(encodeURIComponent).join('/')}`;
}
export function customerMediaReducer(state: CustomerMediaState, event: CustomerMediaEvent): CustomerMediaState {
  if (event.type === 'manual') return state.commandId === event.command.id ? state :
    { phase: event.command.video, commandId: event.command.id };
  if (event.type === 'ended' || event.type === 'playback-failed')
    return state.phase === 'prices' ? state : { ...state, phase: 'prices' };
  // Old start/estimate/timer events cannot initiate playback, even if an old
  // sender sends them. No persisted phase or pending follow-up is recovered.
  return state;
}
export function isMediaCommand(value: unknown, now = Date.now()): value is CustomerMediaCommand {
  if (!value || typeof value !== 'object') return false;
  const command = value as CustomerMediaCommand;
  if (command.issuedAt !== undefined && (!Number.isFinite(command.issuedAt) ||
      command.issuedAt > now + 5000 || now - command.issuedAt > 4500)) return false;
  return typeof command.id === 'string' && command.id.length > 0 && command.id.length < 200 &&
    Object.hasOwn(CUSTOMER_VIDEO_FILES, command.video);
}
export function customerPlaybackError(error: unknown, mediaErrorCode?: number): string {
  const name = error && typeof error === 'object' && 'name' in error ? error.name : '';
  if (name === 'NotSupportedError' || mediaErrorCode === 4)
    return '이 브라우저에서 영상을 재생하지 못했습니다. 직원이 MP4 영상 지원을 확인해 주세요.';
  if (name === 'NotAllowedError')
    return '고객 영상 재생이 차단되었습니다. 직원이 영상 재생 권한을 확인해 주세요.';
  return '고객 영상 파일을 재생하지 못했습니다. 직원 화면에서 연결과 영상 지원을 확인해 주세요.';
}
