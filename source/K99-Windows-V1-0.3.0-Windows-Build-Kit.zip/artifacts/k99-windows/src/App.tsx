import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { MaintenanceWorkspace } from './MaintenanceWorkspace';
import { updateCustomerBeforePhoto } from './customer-identity-update';
import type { ServiceLevel } from './order-record';
import GlobalTagScanner from './GlobalTagScanner';
import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  ClipboardList,
  ExternalLink,
  Info,
  Minus,
  MonitorUp,
  Plus,
  Shirt,
  Trash2,
  X,
} from 'lucide-react';
import { Route, Router as WouterRouter, Switch, useLocation, useSearch } from 'wouter';
import { SneakerServiceIntro } from './SneakerServiceIntro';
import { CommonPreIntakeInfo } from './IntakeFlowScreens';
import { getCombinedBreakdown } from './combined-pricing';
import { CombinedOrderDetails } from './CombinedOrderDetails';
import { FinalIntakeConfirmation } from './FinalIntakeConfirmation';
import { GarmentCaptureWorkspace } from './GarmentCaptureWorkspace';
import GarmentScannerWorkspace from './GarmentScannerWorkspace';
import LaundryProcessWorkspace from './LaundryProcessWorkspace';
import OrderWorkspace from './OrderWorkspace';
import { formatCustomerPhone, requiredIntakeIdentity } from './customer-input';
import { createGarmentRecords } from './garment-record';
import { ProfessionalInspection } from './ProfessionalInspection';
import { SavedOrderLookup } from './SavedOrderLookup';
import { OperationsDashboard } from './OperationsDashboard';
import { CustomerResultRoute, ManagementRoute, PhotoBridgeSettingsRoute, PhotoWorkspaceRoute, StaffManagementNav, StoreHardwareTestRoute, TodayOperationsRoute } from './Phase8Routes';
import { readPhotoBridgeSession, registerPhotoOrder } from './passive-photo-client';
import { PhotoBridgeConnection } from './PhotoBridgeConnection';
import { readPhotoBridgePairingEntry, leavePhotoBridgePairingEntry } from './photo-bridge-recovery';
import { IntakePhotoBridge, type IntakePhotoTarget } from './IntakePhotoBridge';
import { IntakePhotoCopy } from './IntakePhotoCopy';
import { LIVE_VIDEO_CHANNEL, StaffVideoChannel, CustomerVideoChannel, type LiveVideoStatus } from './customer-video-channel';
import {
  CUSTOMER_WINDOW_NAME, CUSTOMER_ACTIVATE_MESSAGE, activateCustomerWindow, customerWindowFeatures,
  readCustomerMonitors, rememberCustomerMonitor, monitorKey, validMonitor, type CustomerMonitor,
} from './customer-screen-window';
import {
  ACTIVE_INTAKE_DRAFT_KEY, clearActiveIntakeDraft, getDraftPhotoForTarget, isDraftPhotoIdAvailable, matchDraftPhotosToTargets, readActiveIntakeDraft, sanitizeDraftPhotoAssociations,
  writeActiveIntakeDraft, type DraftPhotoAssociation,
} from './intake-draft';
import type { DeliveryPolicy } from './delivery-policy';
import { ItemIntakeDetailsFields } from './ItemIntakeDetailsFields';
import { CATALOG_DEFAULTS, PRICE_STORAGE_KEY, catalogOrderIndex, groupByCategory, readManagedCatalog, selectableEntries, type CatalogEntry } from './price-catalog';
import { resolveRowPrice, validateCustomRows, type CustomItemFields } from './custom-item';
import { readSharedCatalog, SHARED_PRICE_EVENT } from './shared-price-catalog';
import { clearActiveConfirmedOrder, createConfirmedOrder, insertConfirmedOrder, readConfirmedOrders, resumeConfirmedOrder, saveConfirmedOrder, updateSavedOrder, type ConfirmedOrder, type FinalIntakeChoices, type ItemIntakeDetails } from './order-record';
import { intakeEntryOrderId, savedIntakeUrl } from './order-entry';
import type { IntakeMode } from './intake-mode';
import { CustomerMedia } from './CustomerMedia';
import { seedWorkflowHistory } from './workflow-navigation';
import { isCustomerReadyPeer, LINKED_CUSTOMER_SOURCE_KEY } from './customer-window-peer';
import { CUSTOMER_VIDEO_PROTOCOL, CUSTOMER_VIDEO_PING, CUSTOMER_VIDEO_PONG, validVideoPong,
  videoLinkState, VIDEO_LINK_LABELS, type VideoProbe, type VideoHeartbeat, type VideoLinkState } from './customer-video-link';
import { CUSTOMER_VIDEO_BUTTONS, CUSTOMER_MEDIA_COMMAND, CUSTOMER_MEDIA_ACK,
  isMediaCommand, type CustomerMediaCommand, type ManualCustomerVideo } from './customer-media';
import { ImeTextInput } from './ImeTextInput';
import { LaundryDesk } from './LaundryDesk';
import './v1-layout.css';
import { DesktopStatusStrip } from './DesktopStatusStrip';
import EquipmentWorkspace from './EquipmentWorkspace';
import EquipmentCustomer from './EquipmentCustomer';
import { customerSnapshotKey, newerCustomerSnapshot } from './customer-display-snapshot';

type LaundryItemId = string;

type LaundryPrice = CatalogEntry & { id: LaundryItemId };

type LaundryRow = CustomItemFields & {
  id: number;
  itemId: LaundryItemId;
  quantity: number;
};

type DisplayRow = LaundryRow & {
  displayNameKo: string;
  generalPrice: number;
  premiumPrice: number;
  selectedServices?: string[];
  selectedAmount?: number;
};

type DisplayPayload = {
  sourceId: string;
  revision: number;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  rows: DisplayRow[];
  totalQuantity: number;
  normalTotal: number;
  premiumTotal: number;
  intakeActive?: boolean;
  selectedTotal?: number;
};

const ITEM_MASTER: LaundryPrice[] = CATALOG_DEFAULTS.map((entry) => ({ ...entry }));

const STORAGE_KEY = 'k99-laundry-display-state';
const CHANNEL_NAME = 'k99-laundry-display';
const SYNC_MESSAGE_TYPE = 'k99-laundry-sync';
const READY_MESSAGE_TYPE = 'k99-laundry-ready';
const SNEAKER_INTRO_CONFIRMED_TYPE = 'k99-sneaker-intro-confirmed';
const SCREEN_MESSAGE_TYPE = 'k99-intake-screen';
const SCREEN_CONFIRMED_TYPE = 'k99-intake-screen-confirmed';
type PresentationScreen = 'order' | 'common' | 'sneaker';

const formatWon = (value: number) => `${value.toLocaleString('ko-KR')}원`;
const isSneakerItem = (id: LaundryItemId) => id === 'sneakers_general' || id === 'sneakers_premium';
const isSneakerOnlyOrder = (rows: ReadonlyArray<{ itemId: LaundryItemId }>) =>
  rows.length > 0 && rows.every((row) => isSneakerItem(row.itemId));
const getPrice = (itemId: LaundryItemId, catalog: ReadonlyArray<LaundryPrice> = ITEM_MASTER) => {
  const price = catalog.find((entry) => entry.id === itemId);
  if (!price) throw new Error(`Unknown laundry item ID: ${itemId}`);
  return price;
};
const createRow = (id: number): LaundryRow => ({ id, itemId: ITEM_MASTER[0].id, quantity: 1 });
const sortRowsByCatalog = <T extends { itemId: string }>(rows: readonly T[]): T[] =>
  rows.map((row, index) => ({ row, index }))
    .sort((x, y) => catalogOrderIndex(ITEM_MASTER, x.row.itemId) - catalogOrderIndex(ITEM_MASTER, y.row.itemId) || x.index - y.index)
    .map(({ row }) => row);

function calculateTotals(rows: LaundryRow[], catalog: ReadonlyArray<LaundryPrice> = ITEM_MASTER) {
  return rows.reduce(
    (sum, row) => {
      const price = resolveRowPrice(row, catalog);
      sum.normal += price.generalPrice * row.quantity;
      sum.premium += price.premiumPrice * row.quantity;
      return sum;
    },
    { normal: 0, premium: 0 },
  );
}

function isLaundryItemId(value: unknown): value is LaundryItemId {
  return typeof value === 'string' && ITEM_MASTER.some((entry) => entry.id === value);
}

function isLaundryRow(value: unknown): value is LaundryRow {
  if (!value || typeof value !== 'object') return false;
  const row = value as Partial<LaundryRow>;
  return (
    typeof row.id === 'number' &&
    Number.isInteger(row.id) &&
    isLaundryItemId(row.itemId) &&
    typeof row.quantity === 'number' &&
    Number.isInteger(row.quantity) &&
    row.quantity >= 1 &&
    row.quantity <= 99 &&
    (row.customName === undefined || typeof row.customName === 'string') &&
    (row.customPrice === undefined || (typeof row.customPrice === 'number' && Number.isFinite(row.customPrice)))
  );
}

type StaffIntakeDraftData = {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  rows: LaundryRow[];
  rowDetails: Record<number, ItemIntakeDetails>;
  unitServiceDraft?: Record<number, ServiceLevel[]>;
  nextId: number;
  sneakerStep: 'normal' | 'intro' | 'intake';
  preStage: 'common' | 'ready';
  intakeMode: IntakeMode | null;
  estimateConfirmed: boolean;
  photos: DraftPhotoAssociation[];
  usedPhotoIds: string[];
};

function normalizeStaffIntakeDraft(value: unknown, draftId: string): StaffIntakeDraftData | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const draft = value as Partial<StaffIntakeDraftData>;
  const intakeMode = draft.intakeMode;
  const nextId = draft.nextId;
  if (typeof draft.customerName !== 'string' || draft.customerName.length > 200 ||
      typeof draft.customerPhone !== 'string' || draft.customerPhone.length > 48 ||
      typeof draft.customerAddress !== 'string' || draft.customerAddress.length > 2000 ||
      !Array.isArray(draft.rows) || draft.rows.length > 200 || !draft.rows.every(isLaundryRow) ||
      new Set(draft.rows.map((row) => row.id)).size !== draft.rows.length ||
      !draft.rowDetails || typeof draft.rowDetails !== 'object' || Array.isArray(draft.rowDetails) ||
      typeof nextId !== 'number' || !Number.isSafeInteger(nextId) || !['normal', 'intro', 'intake'].includes(draft.sneakerStep ?? '') ||
      !['common', 'ready'].includes(draft.preStage ?? '') ||
      !(intakeMode === null || intakeMode === 'garment' || intakeMode === 'sneaker' || intakeMode === 'combined') ||
      typeof draft.estimateConfirmed !== 'boolean' ||
      (draft.usedPhotoIds !== undefined && (!Array.isArray(draft.usedPhotoIds) || draft.usedPhotoIds.length > 300 ||
        !draft.usedPhotoIds.every((id) => typeof id === 'string' && /^[a-f0-9]{64}$/.test(id))))) return null;
  const rowIds = new Set(draft.rows.map((row) => row.id));
  const rowDetails = draft.rowDetails as Record<string, unknown>;
  if (!Object.entries(rowDetails).every(([id, details]) => {
    const parsedId = Number(id);
    return Number.isInteger(parsedId) && rowIds.has(parsedId) && !!details &&
      typeof details === 'object' && !Array.isArray(details) &&
      Object.entries(details).every(([key, item]) => {
        if (!['brand', 'material', 'color', 'stain', 'damage'].includes(key))
          return key === 'purchasePrice' ? Number.isSafeInteger(item) && (item as number) >= 0 && (item as number) <= 100_000_000
            : key === 'staffRiskOverride' ? item === '확인 필요' || item === '일반 접수' : false;
        return typeof item === 'string' && item.length <= 500;
      });
  })) return null;
  const rows = draft.rows;
  if (draft.unitServiceDraft && (typeof draft.unitServiceDraft !== 'object' ||
    Object.values(draft.unitServiceDraft).some(levels => !Array.isArray(levels) ||
      levels.some(level => level !== 'general' && level !== 'premium')))) return null;
  return {
    customerName: draft.customerName,
    customerPhone: draft.customerPhone,
    customerAddress: draft.customerAddress,
    rows,
    rowDetails: rowDetails as Record<number, ItemIntakeDetails>,
    unitServiceDraft: draft.unitServiceDraft,
    nextId: Math.max(nextId, ...rows.map((row) => row.id + 1), 1),
    sneakerStep: draft.sneakerStep as StaffIntakeDraftData['sneakerStep'],
    preStage: draft.preStage as StaffIntakeDraftData['preStage'],
    intakeMode,
    estimateConfirmed: draft.estimateConfirmed,
    photos: sanitizeDraftPhotoAssociations(draft.photos, draftId).filter((photo) =>
      rows.some((row) => row.id === photo.rowId && row.itemId === photo.itemId &&
        row.quantity === photo.rowQuantity && photo.unitIndex <= row.quantity)),
    usedPhotoIds: [...new Set([
      ...(draft.usedPhotoIds ?? []),
      ...sanitizeDraftPhotoAssociations(draft.photos, draftId)
        .filter((photo) => rows.some((row) => row.id === photo.rowId && row.itemId === photo.itemId &&
          row.quantity === photo.rowQuantity && photo.unitIndex <= row.quantity)).map((photo) => photo.sourcePhotoId),
    ])],
  };
}

function reviewedBridgePhotosFromSavedOrder(order: ConfirmedOrder): DraftPhotoAssociation[] {
  const associations: DraftPhotoAssociation[] = [];
  for (const garment of order.garments ?? []) {
    const photo = garment.beforePhoto;
    const sourceItem = order.items[garment.itemIndex - 1];
    if (!photo || photo.status !== 'saved' || photo.role !== 'intake' || photo.origin !== 'bridge' ||
        !photo.sourcePhotoId || !photo.path || !photo.requestId || !sourceItem ||
        sourceItem.itemId !== garment.itemType) continue;
    const filename = photo.path.split(/[\\/]/).at(-1) ?? '';
    associations.push({
      garmentId: garment.garmentId,
      rowId: garment.itemIndex,
      itemId: sourceItem.itemId,
      rowQuantity: sourceItem.quantity,
      unitIndex: garment.unitIndex,
      sourcePhotoId: photo.sourcePhotoId,
      filename,
      sourcePath: photo.path,
      capturedAt: photo.timestamp,
      requestId: photo.requestId,
    });
  }
  return sanitizeDraftPhotoAssociations(associations, order.id);
}

function isDisplayRow(value: unknown): value is DisplayRow {
  if (!isLaundryRow(value)) return false;
  const row = value as DisplayRow;
  return typeof row.displayNameKo === 'string'
    && Number.isSafeInteger(row.generalPrice) && row.generalPrice >= 0
    && Number.isSafeInteger(row.premiumPrice) && row.premiumPrice >= 0;
}

function normalizePayload(value: unknown): DisplayPayload | null {
  if (!value || typeof value !== 'object') return null;
  const candidate = value as Partial<DisplayPayload>;
  if (
    typeof candidate.sourceId !== 'string' || !candidate.sourceId ||
    typeof candidate.revision !== 'number' || !Number.isSafeInteger(candidate.revision) || candidate.revision < 1 ||
    typeof candidate.customerName !== 'string' ||
    (candidate.customerPhone !== undefined && typeof candidate.customerPhone !== 'string') ||
    (candidate.customerAddress !== undefined && typeof candidate.customerAddress !== 'string') ||
    !Array.isArray(candidate.rows) ||
    !candidate.rows.every(isDisplayRow) ||
    !Number.isSafeInteger(candidate.totalQuantity) ||
    !Number.isSafeInteger(candidate.normalTotal) ||
    !Number.isSafeInteger(candidate.premiumTotal) ||
    candidate.totalQuantity !== candidate.rows.reduce((sum, row) => sum + row.quantity, 0) ||
    candidate.normalTotal !== candidate.rows.reduce((sum, row) => sum + row.generalPrice * row.quantity, 0) ||
    candidate.premiumTotal !== candidate.rows.reduce((sum, row) => sum + row.premiumPrice * row.quantity, 0)
  ) return null;

  return {
    sourceId: candidate.sourceId,
    revision: candidate.revision,
    customerName: candidate.customerName,
    customerPhone: candidate.customerPhone ?? '',
    customerAddress: '',
    rows: candidate.rows.map((row) => ({ ...row })),
    totalQuantity: candidate.totalQuantity,
    normalTotal: candidate.normalTotal,
    premiumTotal: candidate.premiumTotal,
    ...(typeof candidate.selectedTotal === 'number' && Number.isSafeInteger(candidate.selectedTotal)
      && candidate.selectedTotal >= 0 ? { selectedTotal: candidate.selectedTotal } : {}),
    intakeActive: candidate.intakeActive === true,
  };
}

function readPayload(): DisplayPayload | null {
  const params = new URLSearchParams(window.location.search);
  const encodedPayload = params.get('data');
  let payload: DisplayPayload | null = null;
  try {
    if (encodedPayload) payload = normalizePayload(JSON.parse(encodedPayload));
  } catch {
    // Never substitute a shared storage value for invalid or missing URL data.
  }
  if (params.has('source') && payload?.sourceId !== params.get('source')) payload = null;
  if (payload) {
    try {
      const cached = normalizePayload(JSON.parse(
        window.sessionStorage.getItem(customerSnapshotKey(payload.sourceId)) || 'null',
      ));
      payload = newerCustomerSnapshot(payload, cached);
    } catch {
      // Keep the valid opening snapshot; never borrow shared or unscoped data.
    }
  }
  if (import.meta.env.DEV) {
    console.debug('[K99 customer/received]', {
      customerUrl: window.location.href,
      parsed: payload,
      error: payload ? null : 'Missing, invalid, or mismatched order data in URL',
    });
  }
  return payload;
}

function LogoLockup() {
  return (
    <div className="brand-lockup" data-testid="brand-lockup">
      <div className="brand-mark" data-testid="brand-mark">
        <Shirt aria-hidden="true" />
      </div>
      <div>
        <div className="brand-name">K99 품격세탁소</div>
        <div className="brand-place">과천점 · 직원 접수</div>
      </div>
    </div>
  );
}

let linkedCustomerWindow: Window | null = null;
let customerStartupAttempted = false;

function StaffIntake() {
  const [, navigate] = useLocation();
  const search = useSearch();
  const entry = new URLSearchParams(search);
  const [priceCatalogState, setPriceCatalogState] = useState(() => {
    try { return { catalog: readManagedCatalog(ITEM_MASTER), error: '공통 가격표를 서버에서 확인 중입니다.' }; }
    catch { return { catalog: ITEM_MASTER, error: '저장된 가격표를 읽을 수 없어 기본 가격표를 표시합니다. 운영 관리에서 가격표를 확인·저장해 주세요.' }; }
  });
  const managedCatalog = priceCatalogState.catalog;
  useEffect(() => {
    let live = true;
    let loading = false;
    const refresh = async () => {
      if (loading) return;
      loading = true;
      try {
        const catalog = await readSharedCatalog(ITEM_MASTER);
        if (live) setPriceCatalogState(old => JSON.stringify(old.catalog) === JSON.stringify(catalog) && !old.error
          ? old : {catalog, error: ''});
      } catch {
        if (live) setPriceCatalogState(old => ({...old, error: '공통 가격표 연결 실패. 표시된 가격은 최신 확인 전이며 새 접수 확정을 중단합니다. 기존 주문은 유지됩니다.'}));
      } finally { loading = false; }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 10000);
    window.addEventListener('focus', refresh);
    window.addEventListener(SHARED_PRICE_EVENT, refresh);
    return () => { live = false; clearInterval(timer); window.removeEventListener('focus', refresh); window.removeEventListener(SHARED_PRICE_EVENT, refresh); };
  }, []);
  const [restored] = useState(() => {
    try {
      const id = intakeEntryOrderId(window.location.search);
      if (!id) return { order: null, error: '' };
      const matches = readConfirmedOrders().filter((order) => order.id === id);
      if (matches.length !== 1) throw new Error('해당 주문번호의 저장 기록을 하나로 확인하지 못했습니다. 관리센터에서 원본 주문을 확인해 주세요.');
      const order = matches[0];
      const garmentId = entry.get('garment');
      if (garmentId && !order.garments?.some((garment) => garment.garmentId === garmentId && garment.orderId === id))
        throw new Error('의류 ID가 지정한 주문에 속하지 않습니다. 작업을 중지했습니다.');
      return { order, error: '' };
    } catch (cause) {
      return { order: null, error: cause instanceof Error ? cause.message : '저장된 접수 기록을 읽지 못했습니다.' };
    }
  });
  const restoredOrder = restored.order;
  const [confirmedOrder, setConfirmedOrder] = useState<ConfirmedOrder | null>(restoredOrder);
  // Saved orders keep their own price snapshot; catalog edits only apply to new selections.
  const priceCatalog = useMemo(() => confirmedOrder ? managedCatalog.map((entry) => {
    const saved = confirmedOrder.items.find((item) => item.itemId === entry.id);
    return saved ? { ...entry, displayNameKo: saved.displayNameKo, generalPrice: saved.generalPrice, premiumPrice: saved.premiumPrice } : entry;
  }) : managedCatalog, [managedCatalog, confirmedOrder]);
  const [draftStart] = useState(() => {
    const stored = readActiveIntakeDraft<unknown>(window.localStorage);
    if (!stored.ok) return { record: null, data: null, error: stored.error };
    if (!stored.draft) return { record: null, data: null, error: '' };
    const data = normalizeStaffIntakeDraft(stored.draft.data, stored.draft.draftId);
    return data
      ? { record: stored.draft, data, error: '' }
      : { record: stored.draft, data: null, error: '저장된 현재 접수 초안의 개인정보 또는 품목 형식을 확인할 수 없습니다. 자동 복원·덮어쓰기를 중지했습니다.' };
  });
  const resumedDraft = restoredOrder ? null : draftStart.data;
  const sourceIdRef = useRef(restoredOrder?.id ?? draftStart.record?.draftId ?? '');
  if (!sourceIdRef.current) sourceIdRef.current = crypto.randomUUID();
  const draftId = sourceIdRef.current;
  const reviewedPhotosAtStart = restoredOrder ? reviewedBridgePhotosFromSavedOrder(restoredOrder) : [];
  const draftRevisionRef = useRef(draftStart.record?.revision ?? -1);
  const [draftSaveError, setDraftSaveError] = useState(draftStart.error);
  const [draftConflict, setDraftConflict] = useState(!!draftStart.error);
  const [draftPhotos, setDraftPhotos] = useState<DraftPhotoAssociation[]>(restoredOrder
    ? reviewedPhotosAtStart : resumedDraft?.photos ?? []);
  const [draftUsedPhotoIds, setDraftUsedPhotoIds] = useState<string[]>(() =>
    [...new Set([
      ...(resumedDraft?.usedPhotoIds ?? []),
      ...reviewedPhotosAtStart.map((photo) => photo.sourcePhotoId),
    ])]);
  const [customerName, setCustomerName] = useState(resumedDraft?.customerName ?? restoredOrder?.customerName ?? '');
  const [customerPhone, setCustomerPhone] = useState(resumedDraft?.customerPhone ?? restoredOrder?.customerPhone ?? '');
  const [customerAddress, setCustomerAddress] = useState(resumedDraft?.customerAddress ?? restoredOrder?.customerAddress ?? '');
  const [rows, setRows] = useState<LaundryRow[]>(() => restoredOrder?.items.map((item, index) => ({
    id: index + 1, itemId: item.itemId as LaundryItemId, quantity: item.quantity,
    ...(item.itemId === 'other' && { customName: item.displayNameKo, customPrice: item.generalPrice }),
  })) ?? resumedDraft?.rows ?? []);
  const [rowDetails, setRowDetails] = useState<Record<number, ItemIntakeDetails>>(() =>
    Object.fromEntries(restoredOrder
      ? restoredOrder.items.map((item, index) => [index + 1, item.intakeDetails ?? {}])
      : Object.entries(resumedDraft?.rowDetails ?? {}).map(([id, details]) => [Number(id), details])));
  const [nextId, setNextId] = useState(resumedDraft?.nextId ?? (restoredOrder?.items.length ?? 0) + 1);
  const [popupWarning, setPopupWarning] = useState(false);
  const [sneakerStep, setSneakerStep] = useState<'normal' | 'intro' | 'intake'>('intake');
  const [sneakerQuantities, setSneakerQuantities] = useState({ sneakers_general: 0, sneakers_premium: 0 });
  const [preStage, setPreStage] = useState<'common' | 'ready'>('ready');
  const [intakeMode, setIntakeMode] = useState<IntakeMode | null>(restoredOrder ? null : resumedDraft?.intakeMode ?? 'combined');
  const [estimateConfirmed, setEstimateConfirmed] = useState(!!restoredOrder || entry.get('stage') === 'final');
  useEffect(() => {
    setEstimateConfirmed(!!restoredOrder || new URLSearchParams(search).get('stage') === 'final');
  }, [search, restoredOrder]);
  const [unitServiceDraft, setUnitServiceDraft] = useState<Record<number, ServiceLevel[]>>(() =>
    restoredOrder ? Object.fromEntries(restoredOrder.items.map((item, i) => [i + 1,
      restoredOrder.choices.unitServiceLevels?.[i] ?? Array.from({ length: item.quantity }, () => restoredOrder.choices.serviceLevel)]))
      : resumedDraft?.unitServiceDraft ?? {});
  const unitServices = useMemo(() => rows.map(row => Array.from({ length: row.quantity },
    (_, u) => unitServiceDraft[row.id]?.[u] ?? 'general')), [rows, unitServiceDraft]);
  const setUnitServices = (levels: ServiceLevel[][]) =>
    setUnitServiceDraft(Object.fromEntries(rows.map((row, i) => [row.id, levels[i] ?? []])));
  useEffect(() => {
    const refresh = () => setConfirmedOrder(current => current
      ? readConfirmedOrders().find(order => order.id === current.id) ?? null : null);
    window.addEventListener('storage', refresh);
    return () => window.removeEventListener('storage', refresh);
  }, []);
  const [inspectionOpen, setInspectionOpen] = useState(() => !!restoredOrder && entry.has('inspection'));
  const [garmentCaptureOpen, setGarmentCaptureOpen] = useState(() => !!restoredOrder && entry.has('capture'));
  const [scannerOpen, setScannerOpen] = useState(() => entry.has('scanner'));
  const [scannerOrderId, setScannerOrderId] = useState<string | undefined>();
  const [scannerGarmentId, setScannerGarmentId] = useState<string | undefined>();
  const scannerReturnOrderIdRef = useRef<string | null>(null);
  const [captureGarmentId, setCaptureGarmentId] = useState<string | undefined>(() => entry.get('garment') ?? undefined);
  const [captureReturnToScanner, setCaptureReturnToScanner] = useState(false);
  const [operationsOpen, setOperationsOpen] = useState(() => entry.has('operations'));
  const [orderSaveError, setOrderSaveError] = useState('');
  const [photoFolderStatus, setPhotoFolderStatus] = useState('');
  const preStageRef = useRef<'common' | 'ready'>('ready');
  const intakeModeRef = useRef<IntakeMode | null>(null);
  const presentedScreenRef = useRef<PresentationScreen>('order');
  const sneakerStepRef = useRef<'normal' | 'intro' | 'intake'>('intake');
  const rowsEditedRef = useRef(false);
  const channelRef = useRef<BroadcastChannel | null>(null);
  const customerWindowRef = useRef<Window | null>(linkedCustomerWindow);
  const customerSourceRef = useRef<string | null>(null);
  const payloadRef = useRef<DisplayPayload | null>(null);
  const draftExpectedRef = useRef({
    draftId: draftStart.record?.draftId ?? null,
    revision: draftStart.record?.revision ?? -1,
  });
  const revisionRef = useRef(0);
  const [typingStarted, setTypingStarted] = useState(false);
  const pendingMediaCommandRef = useRef<CustomerMediaCommand | undefined>(undefined);
  const activeMediaCommandRef = useRef<CustomerMediaCommand | undefined>(undefined);
  const videoProbeRef = useRef<VideoProbe | undefined>(undefined);
  const videoHeartbeatRef = useRef<VideoHeartbeat | undefined>(undefined);
  const videoProtocolRef = useRef<number | undefined>(undefined);
  const liveVideoRef = useRef<StaffVideoChannel | null>(null);
  const customerPlacementRef = useRef<CustomerMonitor | undefined>(undefined);
  const [customerMonitors, setCustomerMonitors] = useState<CustomerMonitor[]>([]);
  const [customerWindowNote, setCustomerWindowNote] = useState('고객 화면 자동 연결을 준비하고 있습니다.');
  const [videoConnection, setVideoConnection] = useState<VideoLinkState>('closed');
  const videoConnectionRef = useRef(videoConnection);
  videoConnectionRef.current = videoConnection;
  const [customerMonitorNote, setCustomerMonitorNote] = useState('');
  const [customerMonitorKey, setCustomerMonitorKey] = useState('');
  const customerOpenTimeoutRef = useRef<number | undefined>(undefined);
  const customerOpeningFailedRef = useRef(false);
  const [videoProgress, setVideoProgress] = useState('');
  const videoProgressRef = useRef('');
  const [mediaError, setMediaError] = useState('');
  const [mediaDiagnostic, setMediaDiagnostic] = useState('');
  const updateVideoProgress = useCallback((progress: string) => {
    videoProgressRef.current = progress;
    setVideoProgress(progress);
  }, []);
  const probeCustomerVideo = useCallback(() => {
    const peer = customerWindowRef.current;
    if (!peer || peer.closed) { setVideoConnection('closed'); return; }
    const now = Date.now();
    if (!videoProbeRef.current || videoProbeRef.current.sourceId !== sourceIdRef.current ||
        now - videoProbeRef.current.at > 4500) {
      videoProbeRef.current = { id: crypto.randomUUID(), sourceId: sourceIdRef.current, at: now };
    }
    try {
      peer.postMessage({ type: CUSTOMER_VIDEO_PING, sourceId: sourceIdRef.current,
        probeId: videoProbeRef.current.id }, window.location.origin);
    } catch { setVideoConnection('stale'); }
  }, []);
  const intakeActive = typingStarted || !!(customerName || customerPhone || customerAddress || rows.length);

  const presentScreen = useCallback((screen: PresentationScreen) => {
    presentedScreenRef.current = screen;
    customerWindowRef.current?.postMessage(
      { type: SCREEN_MESSAGE_TYPE, sourceId: sourceIdRef.current, screen },
      window.location.origin,
    );
  }, []);

  const changePreStage = useCallback((stage: 'common' | 'ready') => {
    preStageRef.current = stage;
    setPreStage(stage);
  }, []);

  const setStep = useCallback((step: 'normal' | 'intro' | 'intake') => {
    sneakerStepRef.current = step;
    setSneakerStep(step);
    presentScreen(step === 'intro' ? 'sneaker' : 'order');
  }, [presentScreen]);

  const confirmCommonInfo = useCallback(() => {
    if (preStageRef.current !== 'common') return;
    changePreStage('ready');
    setStep('intake');
  }, [changePreStage, setStep]);

  const confirmSneakerIntro = useCallback(() => {
    if (sneakerStepRef.current !== 'intro') return;
    setStep('intake');
  }, [changePreStage, setStep]);

  const photoTargets = useMemo<IntakePhotoTarget[]>(() => {
    let sequence = 0;
    return rows.flatMap((row) => {
      const item = resolveRowPrice(row, priceCatalog);
      return Array.from({ length: row.quantity }, (_, index) => {
        sequence += 1;
        const unitIndex = index + 1;
        return {
          garmentId: `${draftId}-${String(sequence).padStart(2, '0')}`,
          rowId: row.id,
          itemId: row.itemId,
          rowQuantity: row.quantity,
          unitIndex,
          label: `${item.displayNameKo} · ${unitIndex}/${row.quantity}개 의류 · 접수 의류 ${sequence}번`,
        };
      });
    });
  }, [draftId, priceCatalog, rows]);

  const validDraftPhotos = useMemo(() => {
    return matchDraftPhotosToTargets(draftPhotos, photoTargets);
  }, [draftPhotos, photoTargets]);

  useEffect(() => {
    if (validDraftPhotos.length !== draftPhotos.length) setDraftPhotos(validDraftPhotos);
  }, [draftPhotos.length, validDraftPhotos]);

  const resetIntake = useCallback(() => {
    const draftClear = clearActiveIntakeDraft(window.localStorage, draftExpectedRef.current);
    if (!draftClear.ok) {
      setDraftSaveError(draftClear.error);
      setDraftConflict(true);
      return;
    }
    draftExpectedRef.current = { draftId: null, revision: -1 };
    clearActiveConfirmedOrder();
    sourceIdRef.current = crypto.randomUUID();
    setDraftPhotos([]);
    setDraftUsedPhotoIds([]);
    setDraftSaveError('');
    setDraftConflict(false);
    revisionRef.current = 0;
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setTypingStarted(false);
    pendingMediaCommandRef.current = undefined;
    setMediaError('');
    setMediaDiagnostic('');
    setRows([]);
    setRowDetails({});
    setUnitServiceDraft({});
    setNextId(1);
    rowsEditedRef.current = false;
    setSneakerQuantities({ sneakers_general: 0, sneakers_premium: 0 });
    setEstimateConfirmed(false);
    setConfirmedOrder(null);
    setInspectionOpen(false);
    setGarmentCaptureOpen(false);
    setOperationsOpen(false);
    setOrderSaveError('');
    navigate('/', { replace: true });
    intakeModeRef.current = null;
    setIntakeMode('combined');
    changePreStage('ready');
    setStep('intake');
    presentScreen('order');
  }, [changePreStage, setStep, presentScreen, navigate]);

  useEffect(() => {
    const handleCustomerConfirmation = (event: MessageEvent<{ type?: string; sourceId?: string; screen?: PresentationScreen }>) => {
      if (event.origin !== window.location.origin || event.source !== customerWindowRef.current ||
          event.data.sourceId !== sourceIdRef.current) return;
      if (event.data.type === SCREEN_CONFIRMED_TYPE && event.data.screen === 'common') confirmCommonInfo();
      if ((event.data.type === SCREEN_CONFIRMED_TYPE && event.data.screen === 'sneaker') ||
          event.data.type === SNEAKER_INTRO_CONFIRMED_TYPE) confirmSneakerIntro();
    };
    window.addEventListener('message', handleCustomerConfirmation);
    return () => window.removeEventListener('message', handleCustomerConfirmation);
  }, [confirmCommonInfo, confirmSneakerIntro]);

  useEffect(() => {
    if ('BroadcastChannel' in window) {
      channelRef.current = new BroadcastChannel(CHANNEL_NAME);
    }
    return () => channelRef.current?.close();
  }, []);

  const totals = useMemo(
    () => calculateTotals(rows, priceCatalog),
    [rows, priceCatalog],
  );
  const sneakerOnly = isSneakerOnlyOrder(rows);
  useEffect(() => {
    if (rows.length === 0) return;
    const hasShoes = rows.some((row) => isSneakerItem(row.itemId));
    const hasGarments = rows.some((row) => !isSneakerItem(row.itemId));
    const mode: IntakeMode = hasShoes && hasGarments ? 'combined' : hasShoes ? 'sneaker' : 'garment';
    intakeModeRef.current = mode;
    setIntakeMode(mode);
  }, [rows]);

  const payload = useMemo<DisplayPayload>(
    () => ({
      sourceId: sourceIdRef.current,
      revision: (() => {
        // Continue the source revision when saved-order navigation remounts
        // the staff form; the customer must never reject new manual controls.
        let previous = 0;
        const key = `k99-display-revision:${sourceIdRef.current}`;
        try { previous = Number(localStorage.getItem(key)) || 0; } catch { /* Use local counter. */ }
        revisionRef.current = Math.max(revisionRef.current, Number.isSafeInteger(previous) ? previous : 0) + 1;
        try { localStorage.setItem(key, String(revisionRef.current)); } catch { /* Live channels remain. */ }
        return revisionRef.current;
      })(),
      // Only the current customer's requested display fields; no staff notes/address.
      customerName,
      customerPhone,
      customerAddress: '',
      rows: rows.map((row, i) => {
        const price = resolveRowPrice(row, priceCatalog);
        const levels = confirmedOrder?.choices.unitServiceLevels ?? unitServices;
        const fallback = confirmedOrder?.choices.serviceLevel ?? 'general';
        const selectedServices = Array.from({ length: row.quantity }, (_, u) =>
          isSneakerItem(row.itemId) ? (row.itemId === 'sneakers_premium' ? '프리미엄' : '일반')
            : (levels?.[i]?.[u] ?? fallback) === 'premium' ? '프리미엄' : '일반');
        return {
          ...row,
          displayNameKo: price.displayNameKo,
          generalPrice: price.generalPrice,
          premiumPrice: price.premiumPrice,
          selectedServices,
          selectedAmount: selectedServices.reduce((sum, level) => sum +
            (!isSneakerItem(row.itemId) && level === '프리미엄' ? price.premiumPrice : price.generalPrice), 0),
        };
      }),
      totalQuantity: rows.reduce((sum, row) => sum + row.quantity, 0),
      normalTotal: totals.normal,
      premiumTotal: totals.premium,
      ...(confirmedOrder ? { selectedTotal: confirmedOrder.laundryTotal } : unitServices ? {
        selectedTotal: rows.reduce((sum, row, i) => {
          const price = resolveRowPrice(row, priceCatalog);
          return sum + Array.from({ length: row.quantity }, (_, u) =>
            !isSneakerItem(row.itemId) && unitServices[i]?.[u] === 'premium' ? price.premiumPrice : price.generalPrice)
            .reduce((a, b) => a + b, 0);
        }, 0),
      } : {}),
      intakeActive,
    }),
    [rows, totals, priceCatalog, intakeActive, customerName, customerPhone, unitServices, confirmedOrder],
  );
  const breakdown = getCombinedBreakdown(payload.rows);
  const customRowsError = useMemo(() => {
    try { validateCustomRows(rows); return ''; }
    catch (error) { return error instanceof Error ? error.message : '기타 품목명·세탁비를 확인하세요.'; }
  }, [rows]);
  const canProceedToFinal = requiredIntakeIdentity(customerName, customerPhone) && rows.length > 0 && !customRowsError;

  payloadRef.current = payload;

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch { /* Live messages still work when persistent browser storage is unavailable. */ }
    try { channelRef.current?.postMessage(payload); } catch { /* A popup has its own live channel. */ }
    try {
      const peer = customerWindowRef.current;
      if (!peer || peer.closed) return;
      peer.postMessage(
        { type: customerSourceRef.current !== payload.sourceId ? 'k99-new-intake' : SYNC_MESSAGE_TYPE, payload },
        window.location.origin,
      );
      customerSourceRef.current = payload.sourceId;
      try { sessionStorage.setItem(LINKED_CUSTOMER_SOURCE_KEY, payload.sourceId); } catch { /* Live pairing remains. */ }
    } catch { /* A closed popup must not stop intake. */ }
  }, [payload]);

  useEffect(() => {
    if (confirmedOrder || draftConflict || restored.error) return;
    const snapshot: StaffIntakeDraftData = {
      customerName,
      customerPhone,
      customerAddress,
      rows,
      rowDetails,
      unitServiceDraft,
      nextId,
      sneakerStep,
      preStage,
      intakeMode,
      // Re-enter the existing final checklist after refresh; its own choices
      // are deliberately collected again rather than silently assumed.
      estimateConfirmed: false,
      photos: validDraftPhotos,
      usedPhotoIds: draftUsedPhotoIds,
    };
    const result = writeActiveIntakeDraft(window.localStorage, draftExpectedRef.current, snapshot, new Date(), draftId);
    if (!result.ok) {
      setDraftSaveError(result.error);
      setDraftConflict(true);
      return;
    }
    draftExpectedRef.current = { draftId: result.draft.draftId, revision: result.draft.revision };
    setDraftSaveError('');
  }, [confirmedOrder, customerAddress, customerName, customerPhone, draftConflict, draftId, draftUsedPhotoIds,
    intakeMode, nextId, preStage, restored.error, rowDetails, rows, sneakerStep, validDraftPhotos, unitServiceDraft]);

  useEffect(() => {
    const changedInOtherTab = (event: StorageEvent) => {
      if (event.key !== ACTIVE_INTAKE_DRAFT_KEY && event.key !== null) return;
      const remote = readActiveIntakeDraft<unknown>(window.localStorage);
      if (!remote.ok || remote.draft?.draftId !== draftExpectedRef.current.draftId ||
          remote.draft?.revision !== draftExpectedRef.current.revision) {
        setDraftConflict(true);
        setDraftSaveError('다른 브라우저 탭에서 접수가 변경되거나 초기화되었습니다. 기존 내용을 덮어쓰지 않았습니다. 이 탭을 새로고침해 최신 접수를 불러와 주세요.');
      }
    };
    window.addEventListener('storage', changedInOtherTab);
    return () => window.removeEventListener('storage', changedInOtherTab);
  }, []);

  useEffect(() => {
    const handleCustomerReady = (event: MessageEvent<{ type?: string; sourceId?: string; videoProtocol?: number }>) => {
      if (event.origin !== window.location.origin || event.data?.type !== READY_MESSAGE_TYPE) return;
      let pairedSource: string | null = null;
      let owned = false;
      try { pairedSource = sessionStorage.getItem(LINKED_CUSTOMER_SOURCE_KEY); } catch { /* Do not guess a peer. */ }
      try { owned = (event.source as Window | null)?.opener === window; } catch { /* Reject cross-origin senders. */ }
      if (!isCustomerReadyPeer({sender:event.source,linked:customerWindowRef.current,owned,
          sourceId:event.data.sourceId,pairedSource})) return;
      const peer = event.source as Window;
      try { peer.name = CUSTOMER_WINDOW_NAME; } catch { /* Keep the live pairing if naming is unavailable. */ }
      customerWindowRef.current = peer;
      linkedCustomerWindow = peer;
      videoProtocolRef.current = event.data.videoProtocol ?? 0;
      setVideoConnection(videoLinkState(true, videoProtocolRef.current, videoHeartbeatRef.current, sourceIdRef.current));
      peer.postMessage(
        { type: event.data.sourceId === sourceIdRef.current ? SYNC_MESSAGE_TYPE : 'k99-new-intake',
          payload: payloadRef.current ? { ...payloadRef.current, intakeActive: true } : null },
        window.location.origin,
      );
      customerSourceRef.current = sourceIdRef.current;
      try { sessionStorage.setItem(LINKED_CUSTOMER_SOURCE_KEY, sourceIdRef.current); } catch { /* Live peer is known. */ }
      peer.postMessage(
        { type: SCREEN_MESSAGE_TYPE, sourceId: sourceIdRef.current, screen: presentedScreenRef.current },
        window.location.origin,
      );
      probeCustomerVideo();
    };
    window.addEventListener('message', handleCustomerReady);
    return () => window.removeEventListener('message', handleCustomerReady);
  }, [probeCustomerVideo]);

  useEffect(() => {
    const pulse = () => {
      const peer = customerWindowRef.current;
      if (!peer || peer.closed || peer.opener !== window) {
        liveVideoRef.current?.probe();
        return;
      }
      setVideoConnection(videoLinkState(!!peer && !peer.closed, videoProtocolRef.current,
        videoHeartbeatRef.current, sourceIdRef.current));
      probeCustomerVideo();
    };
    const timer = window.setInterval(pulse, 2000);
    return () => window.clearInterval(timer);
  }, [probeCustomerVideo]);

  useEffect(() => {
    if (!('BroadcastChannel' in window)) return;
    const link = new StaffVideoChannel(new BroadcastChannel(LIVE_VIDEO_CHANNEL), {
      source: () => sourceIdRef.current,
      onLink: (connected) => {
        const peer = customerWindowRef.current;
        if (!peer || peer.closed || peer.opener !== window) setVideoConnection(connected ? 'connected' : 'closed');
      },
      onAck: (commandId) => {
        if (pendingMediaCommandRef.current?.id !== commandId) return;
        pendingMediaCommandRef.current = undefined;
        updateVideoProgress('고객 화면 명령 수신 확인');
      },
      onStatus: ({ error, diagnostic }) => {
        if (diagnostic.commandId !== activeMediaCommandRef.current?.id) return;
        setMediaError(error);
        setMediaDiagnostic(JSON.stringify(diagnostic, null, 2));
        if (error) updateVideoProgress('명령 전달됨 · 영상 재생 실패');
        else if (diagnostic.event === 'playing' || diagnostic.event === 'first-frame')
          updateVideoProgress('고객 화면 영상 재생 중');
        else if (diagnostic.event === 'ended') updateVideoProgress('영상 종료 · 고객정보 화면 복귀');
        else if (diagnostic.event === 'play-request') updateVideoProgress('명령 전달됨 · 고객 화면 재생 요청');
      },
    });
    liveVideoRef.current = link;
    link.probe();
    return () => { link.close(); liveVideoRef.current = null; };
  }, [updateVideoProgress]);

  useEffect(() => {
    const handleMediaStatus = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== customerWindowRef.current ||
          event.data?.sourceId !== sourceIdRef.current) return;
      if (validVideoPong(event.data, videoProbeRef.current)) {
        videoProtocolRef.current = CUSTOMER_VIDEO_PROTOCOL;
        videoHeartbeatRef.current = { sourceId: sourceIdRef.current, at: Date.now() };
        videoProbeRef.current = undefined;
        setVideoConnection('connected');
        const pending = pendingMediaCommandRef.current;
        if (pending && isMediaCommand(pending)) {
          customerWindowRef.current?.postMessage(
            { type: CUSTOMER_MEDIA_COMMAND, sourceId: sourceIdRef.current, command: pending }, window.location.origin);
        }
        return;
      }
      if (event.origin === window.location.origin && event.source === customerWindowRef.current &&
          event.data?.type === CUSTOMER_MEDIA_ACK && event.data.sourceId === sourceIdRef.current &&
          event.data.commandId === pendingMediaCommandRef.current?.id) {
        pendingMediaCommandRef.current = undefined;
        updateVideoProgress('고객 화면 명령 수신 확인');
        return;
      }
      if (event.origin === window.location.origin && event.source === customerWindowRef.current &&
          event.data?.type === 'k99-customer-media-status' && event.data.sourceId === sourceIdRef.current &&
          typeof event.data.error === 'string') {
        const diagnostic = event.data.diagnostic;
        if (diagnostic?.commandId !== activeMediaCommandRef.current?.id) return;
        setMediaError(event.data.error);
        if (diagnostic) setMediaDiagnostic(JSON.stringify(diagnostic, null, 2));
        if (event.data.error) updateVideoProgress('명령 전달됨 · 영상 재생 실패');
        else if (diagnostic?.event === 'playing' || diagnostic?.event === 'first-frame')
          updateVideoProgress('고객 화면 영상 재생 중');
        else if (diagnostic?.event === 'ended') updateVideoProgress('영상 종료 · 고객정보 화면 복귀');
        else if (diagnostic?.event === 'play-request') updateVideoProgress('명령 전달됨 · 고객 화면 재생 요청');
      }
    };
    window.addEventListener('message', handleMediaStatus);
    return () => window.removeEventListener('message', handleMediaStatus);
  }, [updateVideoProgress]);

  const updateRow = useCallback((id: number, updates: Partial<LaundryRow>) => {
    rowsEditedRef.current = true;
    setRows((current) => current.map((row) => (row.id === id ? { ...row, ...updates } : row)));
    if (updates.itemId) setRowDetails((current) => {
      const next = { ...current };
      delete next[id];
      return next;
    });
  }, []);

  const addRow = useCallback(() => {
    rowsEditedRef.current = true;
    setRows((current) => [...current, createRow(nextId)]);
    setNextId((current) => current + 1);
  }, [nextId]);

  const removeRow = useCallback((id: number) => {
    rowsEditedRef.current = true;
    setRows((current) => current.filter((row) => row.id !== id));
    setRowDetails((current) => {
      const next = { ...current };
      delete next[id];
      return next;
    });
  }, []);

  const openCustomerView = useCallback(() => {
    if(window.k99Desktop) {
      setCustomerWindowNote('Windows 고객 화면은 상단 장비 연동에서 연결할 모니터를 선택한 뒤 여세요.');
      return;
    }
    pendingMediaCommandRef.current = undefined;
    setPopupWarning(false);
    const currentPayload = payloadRef.current ?? payload;
    const snapshot = { ...currentPayload, rows: currentPayload.rows.map((row) => ({ ...row })) };
    const base = import.meta.env.BASE_URL || '/';
    const customerUrl = new URL(
      `${window.location.origin}${base.endsWith('/') ? base : `${base}/`}customer`,
    );
    customerUrl.searchParams.set('source', snapshot.sourceId);
    customerUrl.searchParams.set('data', JSON.stringify(snapshot));
    customerUrl.searchParams.set('screen', presentedScreenRef.current);
    const watchConnection = () => {
      customerOpeningFailedRef.current = false;
      window.clearTimeout(customerOpenTimeoutRef.current);
      customerOpenTimeoutRef.current = window.setTimeout(() => {
        if (videoConnectionRef.current === 'connected') return;
        customerOpeningFailedRef.current = true;
        setCustomerWindowNote('고객 화면 응답 확인에 실패했습니다. ‘고객 화면 재연결’을 눌러 기존 창을 복구해 주세요.');
      }, 8000);
    };
    // Preserve the page already placed on the customer monitor. Reopening or
    // focusing another tab can put the video on the staff monitor instead.
    const existingCustomer = customerWindowRef.current;
    if (existingCustomer && !existingCustomer.closed) {
      if (customerOpeningFailedRef.current || videoConnectionRef.current === 'stale' ||
          videoConnectionRef.current === 'closed') {
        try { existingCustomer.location.replace(customerUrl.toString()); }
        catch { setCustomerWindowNote('기존 고객 화면을 복구하지 못했습니다. 해당 창의 사이트 주소를 확인해 주세요.'); return; }
      }
      existingCustomer.postMessage({ type: SYNC_MESSAGE_TYPE, payload: snapshot }, window.location.origin);
      existingCustomer.postMessage({ type: SCREEN_MESSAGE_TYPE, sourceId: sourceIdRef.current,
        screen: presentedScreenRef.current }, window.location.origin);
      activateCustomerWindow(existingCustomer, customerPlacementRef.current);
      setCustomerWindowNote('기존 고객 화면을 재사용하며 연결·활성화를 확인하고 있습니다.');
      probeCustomerVideo();
      watchConnection();
      return;
    }
    if (videoConnectionRef.current === 'connected') {
      channelRef.current?.postMessage({ type: CUSTOMER_ACTIVATE_MESSAGE,
        sourceId: sourceIdRef.current, placement: customerPlacementRef.current });
      setCustomerWindowNote('이미 연결된 기존 고객 화면에 활성화를 요청했습니다. 새 창은 만들지 않습니다.');
      return;
    }
    if (import.meta.env.DEV) {
      console.debug('[K99 customer/open]', {
        customerName: snapshot.customerName,
        items: snapshot.rows.map((row) => ({
          item: row.displayNameKo,
          quantity: row.quantity,
          generalPrice: row.generalPrice,
          premiumPrice: row.premiumPrice,
        })),
        generalTotal: snapshot.normalTotal,
        premiumTotal: snapshot.premiumTotal,
        totalQuantity: snapshot.totalQuantity,
        customerUrl: customerUrl.toString(),
      });
    }
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
      channelRef.current?.postMessage(snapshot);
    } catch {
      // 저장이 막힌 환경에서는 새 창이 열려도 현재 접수 화면을 기준으로 계속 안내합니다.
    }
    let customerWindow: Window | null = null;
    try {
      customerWindow = window.open(customerUrl.toString(), CUSTOMER_WINDOW_NAME,
        customerWindowFeatures(customerPlacementRef.current));
    } catch { /* Report popup restrictions without breaking staff intake. */ }
    if (!customerWindow) {
      setPopupWarning(true);
      setCustomerWindowNote('고객 화면 자동 열기가 차단되었습니다. 이 사이트의 팝업을 허용한 뒤 ‘고객 화면 재연결’을 눌러 주세요.');
      return;
    }
    if (customerWindowRef.current && !customerWindowRef.current.closed) {
      customerWindowRef.current.close();
    }
    customerWindowRef.current = customerWindow;
    linkedCustomerWindow = customerWindow;
    customerSourceRef.current = snapshot.sourceId;
    try { sessionStorage.setItem(LINKED_CUSTOMER_SOURCE_KEY, snapshot.sourceId); } catch { /* Live pairing works. */ }
    const sendCurrentPayload = () => {
      customerWindow.postMessage(
        { type: SYNC_MESSAGE_TYPE, payload: payloadRef.current ?? snapshot },
        window.location.origin,
      );
      customerWindow.postMessage(
        { type: SCREEN_MESSAGE_TYPE, sourceId: sourceIdRef.current, screen: presentedScreenRef.current },
        window.location.origin,
      );
    };
    sendCurrentPayload();
    window.setTimeout(sendCurrentPayload, 250);
    window.setTimeout(sendCurrentPayload, 800);
    activateCustomerWindow(customerWindow, customerPlacementRef.current);
    setCustomerWindowNote('고객 전용 창을 열었습니다. 고객 화면 응답과 연결을 확인하고 있습니다.');
    watchConnection();
  }, [payload, probeCustomerVideo]);

  // Let an already-open monitor announce itself before attempting one named
  // popup. Never retry automatically or use a video click to open a window.
  const openCustomerRef = useRef(openCustomerView);
  openCustomerRef.current = openCustomerView;
  useEffect(() => {
    if (customerStartupAttempted) return;
    let cancelled = false;
    const timer = window.setTimeout(() => {
      void readCustomerMonitors().then((result) => {
        if (cancelled) return;
        customerPlacementRef.current = result.selected;
        setCustomerMonitors(result.screens);
        setCustomerMonitorKey(result.selected ? monitorKey(result.selected) : '');
        setCustomerMonitorNote(result.note);
        customerStartupAttempted = true;
        openCustomerRef.current();
      });
    }, 1700);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      window.clearTimeout(customerOpenTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    if (videoConnection === 'connected') setCustomerWindowNote('고객 전용 화면 연결 확인됨 · 기존 화면을 사용합니다.');
    else if (videoConnection === 'stale' || (videoConnection === 'closed' && customerStartupAttempted))
      setCustomerWindowNote('고객 화면 응답이 없거나 연결이 끊겼습니다. ‘고객 화면 재연결’을 눌러 주세요.');
  }, [videoConnection]);

  const applyCustomerMonitor = (area: CustomerMonitor) => {
    customerPlacementRef.current = area;
    setCustomerMonitorKey(monitorKey(area));
    rememberCustomerMonitor(area);
    const peer = customerWindowRef.current;
    if (peer && !peer.closed) activateCustomerWindow(peer, area);
    else if (videoConnectionRef.current === 'connected') channelRef.current?.postMessage({
      type: CUSTOMER_ACTIVATE_MESSAGE, sourceId: sourceIdRef.current, placement: area,
    });
    setCustomerMonitorNote(peer && !peer.closed || videoConnectionRef.current === 'connected'
      ? '선택한 고객 모니터로 배치를 요청했습니다. 실제 창 위치를 확인해 주세요.'
      : '고객 모니터 위치를 저장했습니다. ‘고객 화면 재연결’을 눌러 고객 창을 열어 주세요.');
  };
  const configureCustomerMonitor = async () => {
    // Request placement permission from this explicit gesture without opening
    // or focusing another window while the browser's permission prompt is shown.
    const result = await readCustomerMonitors(true);
    setCustomerMonitors(result.screens);
    setCustomerMonitorNote(result.note);
    if (result.selected) applyCustomerMonitor(result.selected);
  };

  const playCustomerExplanation = (video: ManualCustomerVideo) => {
    setMediaError('');
    setMediaDiagnostic('');
    const peer = customerWindowRef.current;
    const direct = peer && !peer.closed && peer.opener === window;
    if (!direct && !liveVideoRef.current) {
      setVideoConnection('closed');
      setMediaError('고객 화면을 먼저 열어 주세요.');
      return;
    }
    const connection = direct
      ? videoLinkState(true, videoProtocolRef.current, videoHeartbeatRef.current, sourceIdRef.current)
      : videoConnection;
    if (direct) setVideoConnection(connection);
    const command = { id: crypto.randomUUID(), video, issuedAt: Date.now() };
    pendingMediaCommandRef.current = command;
    activeMediaCommandRef.current = command;
    updateVideoProgress('고객 화면 연결·명령 수신 확인 중');
    try {
      if (!direct) {
        void liveVideoRef.current!.send(command).catch((error) => {
          if (activeMediaCommandRef.current?.id !== command.id) return;
          pendingMediaCommandRef.current = undefined;
          updateVideoProgress('명령 수신 확인 실패');
          setMediaError(error instanceof Error ? error.message : '기존 고객 화면 연결을 확인하지 못했습니다.');
        });
      } else if (connection === 'connected' || connection === 'legacy') peer.postMessage(
        { type: CUSTOMER_MEDIA_COMMAND, sourceId: sourceIdRef.current, command }, window.location.origin,
      );
      else probeCustomerVideo();
    } catch {
      pendingMediaCommandRef.current = undefined;
      setMediaError('고객 화면 연결을 확인해 주세요.');
      return;
    }
    window.setTimeout(() => {
      if (pendingMediaCommandRef.current?.id !== command.id) return;
      pendingMediaCommandRef.current = undefined;
      updateVideoProgress('명령 수신 확인 실패');
      setMediaError('고객 화면에서 영상 명령을 받지 못했습니다. 같은 운영 사이트의 고객 화면인지, 이전 버전 화면인지 연결 상태를 확인해 주세요.');
    }, 4500);
    window.setTimeout(() => {
      if (activeMediaCommandRef.current?.id !== command.id || pendingMediaCommandRef.current ||
          !['고객 화면 명령 수신 확인', '명령 전달됨 · 고객 화면 재생 요청'].includes(videoProgressRef.current)) return;
      updateVideoProgress('명령 전달됨 · 재생 시작 확인 실패');
      setMediaError('고객 화면은 영상 명령을 받았지만 재생 시작을 확인하지 못했습니다. 아래 재생 기록에서 파일 주소·브라우저 오류를 확인해 주세요.');
    }, 15000);
  };

  const addSneakers = useCallback((items: Array<{ itemId: LaundryItemId; quantity: number }>) => {
    if (items.length === 0) return;
    rowsEditedRef.current = true;
    setNextId((previous) => previous + items.length);
    setRows((current) => {
      let next = [...current];
      let id = Math.max(0, ...current.map((row) => row.id)) + 1;
      for (const item of items) {
        const existing = next.find((row) => row.itemId === item.itemId);
        if (existing) {
          next = next.map((row) => row === existing ? { ...row, quantity: Math.min(99, row.quantity + item.quantity) } : row);
        } else {
          next.push({ id: id++, ...item });
        }
      }
      return next;
    });
  }, []);

  const addCombinedItems = useCallback((items: Array<{ itemId: LaundryItemId; quantity: number }>) => {
    if (items.length === 0) return;
    rowsEditedRef.current = true;
    setNextId((previous) => previous + items.length);
    setRows((current) => {
      let id = Math.max(0, ...current.map((row) => row.id)) + 1;
      return [...current, ...items.map((item) => ({ ...item, id: id++ }))];
    });
  }, []);
  const visibleRows = rows.filter((row) => !isSneakerItem(row.itemId));

  const resumeSavedOrder = (id: string) => {
    const draftClear = clearActiveIntakeDraft(window.localStorage, draftExpectedRef.current);
    if (!draftClear.ok) {
      setDraftSaveError(draftClear.error);
      setDraftConflict(true);
      return;
    }
    draftExpectedRef.current = { draftId: null, revision: -1 };
    const order = resumeConfirmedOrder(id);
    navigate(savedIntakeUrl(order.id), { replace: true });
    customerWindowRef.current?.close();
    customerWindowRef.current = null;
    sourceIdRef.current = order.id;
    revisionRef.current = 0;
    setCustomerName(order.customerName);
    setCustomerPhone(order.customerPhone);
    setCustomerAddress(order.customerAddress);
    setRows(order.items.map((item, index) => ({
      id: index + 1, itemId: item.itemId as LaundryItemId, quantity: item.quantity,
      ...(item.itemId === 'other' && { customName: item.displayNameKo, customPrice: item.generalPrice }),
    })));
    setRowDetails(Object.fromEntries(order.items.map((item, index) => [index + 1, item.intakeDetails ?? {}])));
    setNextId(order.items.length + 1);
    const savedPhotos = reviewedBridgePhotosFromSavedOrder(order);
    setDraftPhotos(savedPhotos);
    setDraftUsedPhotoIds(savedPhotos.map((photo) => photo.sourcePhotoId));
    setDraftSaveError('');
    setDraftConflict(false);
    setSneakerQuantities({ sneakers_general: 0, sneakers_premium: 0 });
    rowsEditedRef.current = true;
    setConfirmedOrder(order);
    setEstimateConfirmed(true);
    setInspectionOpen(false);
    setGarmentCaptureOpen(false);
    setOperationsOpen(false);
    changePreStage('ready');
    setStep('intake');
  };

  const startGarmentCapture = () => {
    if (!confirmedOrder || confirmedOrder.operations?.cancelledAt) return;
    try {
      const stored = resumeConfirmedOrder(confirmedOrder.id);
      const ready = stored.garments ? stored : { ...stored, garments: createGarmentRecords(stored) };
      if (!stored.garments) updateSavedOrder(ready, stored);
      setConfirmedOrder(ready);
      setOrderSaveError('');
      setCaptureGarmentId(undefined);
      setCaptureReturnToScanner(false);
      navigate(`/equipment?orderId=${encodeURIComponent(ready.id)}`);
    } catch (cause) {
      setOrderSaveError(cause instanceof Error ? cause.message : '의류 기록을 열지 못했습니다.');
    }
  };

  const openLaundryProcess = () => {
    if (!confirmedOrder) return;
    setOrderSaveError('');
    navigate(`/orders/${encodeURIComponent(confirmedOrder.id)}`);
  };

  const openCaptureFromScanner = (orderId: string, garmentId: string) => {
    try {
      const stored = resumeConfirmedOrder(orderId);
      const ready = stored.garments ? stored : { ...stored, garments: createGarmentRecords(stored) };
      if (!stored.garments) updateSavedOrder(ready, stored);
      setConfirmedOrder(ready);
      setScannerOrderId(orderId);
      navigate(`/equipment?orderId=${encodeURIComponent(orderId)}&garmentId=${encodeURIComponent(garmentId)}`, { replace: true });
    } catch (cause) {
      setOrderSaveError(cause instanceof Error ? cause.message : '의류 기록을 열지 못했습니다.');
    }
  };

  const photoBridgePanel = <><IntakePhotoCopy
    draftId={draftId}
    customerName={customerName}
    customerPhone={customerPhone}
    active={!confirmedOrder && !draftConflict && !draftSaveError && !draftStart.error}
  /><IntakePhotoBridge
    draftId={draftId}
    targets={photoTargets}
    associations={validDraftPhotos}
    usedPhotoIds={draftUsedPhotoIds}
    canImport={!confirmedOrder && !draftConflict && !draftSaveError && !draftStart.error}
    conflict={draftConflict}
    onAssociationsChange={setDraftPhotos}
    onPhotoUsed={(photoId) => setDraftUsedPhotoIds((current) =>
      isDraftPhotoIdAvailable(current, photoId) ? [...current, photoId] : current)}
  /></>;

  if (restored.error) {
    return <main className="app-shell"><p role="alert">{restored.error}</p>
      <button type="button" onClick={() => navigate('/management')}>통합관리센터로 돌아가기</button></main>;
  }

  if (operationsOpen) {
    return <OperationsDashboard onBack={() => setOperationsOpen(false)} onResume={(id) => navigate(`/orders/${encodeURIComponent(id)}`)}
      catalog={priceCatalog} defaults={ITEM_MASTER}
      onCatalogSaved={() => setPriceCatalogState({ catalog: readManagedCatalog(ITEM_MASTER), error: '' })} />;
  }

  if (scannerOpen) {
    return <GarmentScannerWorkspace initialOrderId={scannerOrderId} initialGarmentId={scannerGarmentId} captureError={orderSaveError}
      onBack={() => {
        setScannerOpen(false);
        setCaptureReturnToScanner(false);
        if (scannerReturnOrderIdRef.current) {
          try { resumeSavedOrder(scannerReturnOrderIdRef.current); }
          catch (cause) { setOrderSaveError(cause instanceof Error ? cause.message : '주문 기록을 다시 열지 못했습니다.'); }
        } else {
          clearActiveConfirmedOrder();
          setConfirmedOrder(null);
          setEstimateConfirmed(false);
        }
      }}
      onOpenCapture={openCaptureFromScanner} />;
  }

  if (confirmedOrder && garmentCaptureOpen) {
    return <GarmentCaptureWorkspace key={confirmedOrder.id} order={confirmedOrder}
      initialGarmentId={captureGarmentId}
      onOrderChange={setConfirmedOrder} onBack={() => {
        setGarmentCaptureOpen(false);
        if (captureReturnToScanner) setScannerOpen(true);
      }} />;
  }

  if (preStage === 'common') {
    return <>
      <CommonPreIntakeInfo onConfirm={confirmCommonInfo} onShowCustomer={openCustomerView} />
      {photoBridgePanel}
      {draftSaveError && <p role="alert" data-testid="staff-intake-draft-error">{draftSaveError}</p>}
      {restored.error && <p role="alert" style={{ padding: 20 }}>{restored.error}</p>}
      {priceCatalogState.error && <p role="alert" style={{ padding: 20 }}>{priceCatalogState.error}</p>}
      <SavedOrderLookup onResume={(id) => navigate(`/orders/${encodeURIComponent(id)}`)} onOpenOperations={() => setOperationsOpen(true)} />
    </>;
  }

  if (sneakerStep === 'intro') {
    return <><SneakerServiceIntro onConfirm={confirmSneakerIntro} onShowCustomer={openCustomerView} />
      {photoBridgePanel}
      {draftSaveError && <p role="alert" data-testid="staff-intake-draft-error">{draftSaveError}</p>}</>;
  }

  if (confirmedOrder && inspectionOpen) {
    return <ProfessionalInspection order={confirmedOrder} onBack={() => setInspectionOpen(false)}
      onProceedCleaning={openLaundryProcess} cleaningError={orderSaveError}
      onSave={(updated) => {
        saveConfirmedOrder(updated, confirmedOrder);
        setConfirmedOrder(updated);
      }} />;
  }

  if (estimateConfirmed) {
    return <><div hidden>{photoBridgePanel}</div>{draftSaveError && <p role="alert" data-testid="staff-intake-draft-error">{draftSaveError}</p>}
      <FinalIntakeConfirmation
      orderId={sourceIdRef.current}
      customerName={customerName}
      customerPhone={customerPhone}
      customerAddress={customerAddress}
      initialUnitServices={unitServices}
      onUnitServicesChange={setUnitServices}
      onCustomerSave={value => {
        if (confirmedOrder) {
          const updated = updateCustomerBeforePhoto(confirmedOrder, value);
          setConfirmedOrder(updated);
        } else if (validDraftPhotos.length) {
          throw new Error('이미 촬영한 접수입니다. 원본 사진 연결을 보존하기 위해 수정을 중지했습니다.');
        }
        setCustomerName(value.customerName); setCustomerPhone(value.customerPhone); setCustomerAddress(value.customerAddress);
      }}
      items={payload.rows.map((row) => ({
        itemId: row.itemId,
        displayNameKo: row.displayNameKo,
        quantity: row.quantity,
        generalPrice: row.generalPrice,
        premiumPrice: row.premiumPrice,
        isSneaker: isSneakerItem(row.itemId),
        ...(rowDetails[row.id] && { intakeDetails: { ...rowDetails[row.id] } }),
      }))}
      onBack={confirmedOrder
        ? () => navigate(`/orders/${encodeURIComponent(confirmedOrder.id)}`)
        : () => { setEstimateConfirmed(false); navigate('/'); }}
      onNewIntake={resetIntake}
      confirmedOrder={confirmedOrder}
      onOpenWorkspace={confirmedOrder ? () => navigate(`/orders/${encodeURIComponent(confirmedOrder.id)}`) : undefined}
      photoFolderStatus={photoFolderStatus}
      onStartInspection={confirmedOrder && !confirmedOrder.operations?.cancelledAt
        ? () => navigate(`/orders/${encodeURIComponent(confirmedOrder.id)}?work=inspection`) : undefined}
      onStartGarmentCapture={confirmedOrder && !confirmedOrder.operations?.cancelledAt ? startGarmentCapture : undefined}
      onStartScanner={confirmedOrder && !confirmedOrder.operations?.cancelledAt
        ? () => navigate(`/orders/${encodeURIComponent(confirmedOrder.id)}?work=scan`) : undefined}
      onStartLaundry={confirmedOrder && confirmedOrder.inspection &&
        ['세탁 진행 승인', '전체 세탁 완료 / 반출 대기'].includes(confirmedOrder.status) &&
        !confirmedOrder.operations?.cancelledAt ? openLaundryProcess : undefined}
      saveError={orderSaveError}
      onConfirm={(choices: FinalIntakeChoices, feePolicy: DeliveryPolicy) => {
        if (confirmedOrder) return false;
        if (priceCatalogState.error) {
          setOrderSaveError('서버 공통 가격표를 확인한 뒤 접수를 확정해 주세요. 기존 주문은 변경하지 않았습니다.');
          return false;
        }
        if (draftConflict || (draftPhotos.length > 0 && draftSaveError)) {
          setOrderSaveError(draftSaveError || '다른 브라우저 탭에서 접수가 변경되었습니다. 기존 내용을 덮어쓰지 않도록 새로고침한 뒤 최신 접수를 다시 확인해 주세요.');
          return false;
        }
        const currentDraft = readActiveIntakeDraft<unknown>(window.localStorage);
        if (!currentDraft.ok || currentDraft.draft?.draftId !== draftExpectedRef.current.draftId ||
            currentDraft.draft?.revision !== draftExpectedRef.current.revision) {
          setDraftConflict(true);
          setDraftSaveError(currentDraft.ok
            ? '현재 초안의 저장 버전이 다른 탭의 변경과 일치하지 않습니다. 최신 접수 내용을 불러온 뒤 다시 확인해 주세요.'
            : currentDraft.error);
          setOrderSaveError('현재 접수 초안이 안전하게 저장되었는지 확인하지 못했습니다. 사진 연결을 포함한 접수를 중복 없이 보존하기 위해 저장을 중지했습니다.');
          return false;
        }
        try {
          validateCustomRows(rows);
          const draftOrder = createConfirmedOrder({
            id: sourceIdRef.current, customerName, customerPhone, customerAddress,
            items: payload.rows.map((row) => ({
              itemId: row.itemId, displayNameKo: row.displayNameKo, quantity: row.quantity,
              generalPrice: row.generalPrice, premiumPrice: row.premiumPrice,
              isSneaker: isSneakerItem(row.itemId),
                ...(rowDetails[row.id] && { intakeDetails: { ...rowDetails[row.id] } }),
            })),
          }, choices, new Date(), feePolicy);
          const order = validDraftPhotos.length
            ? {
                ...draftOrder,
                garments: createGarmentRecords(draftOrder).map((garment) => {
                  const row = rows[garment.itemIndex - 1];
                  const source = row ? getDraftPhotoForTarget(validDraftPhotos, {
                    garmentId: garment.garmentId,
                    rowId: row.id,
                    itemId: garment.itemType,
                    rowQuantity: row.quantity,
                    unitIndex: garment.unitIndex,
                  }) : null;
                  if (!source) return garment;
                  const photo = {
                    garmentId: garment.garmentId,
                    requestId: source.requestId,
                    role: 'intake' as const,
                    status: 'saved' as const,
                    timestamp: source.capturedAt,
                    origin: 'bridge' as const,
                    sourcePhotoId: source.sourcePhotoId,
                    path: source.sourcePath,
                  };
                  return {
                    ...garment,
                    photoStatus: 'saved' as const,
                    photoPath: source.sourcePath,
                    photoTimestamp: source.capturedAt,
                    beforePhoto: photo,
                    photoHistory: [...(garment.photoHistory ?? []), photo],
                    representativeBeforePhotoId: source.requestId,
                  };
                }),
              }
            : draftOrder;
          insertConfirmedOrder(order);
          const clearedDraft = clearActiveIntakeDraft(window.localStorage, draftExpectedRef.current);
          if (clearedDraft.ok) draftExpectedRef.current = { draftId: null, revision: -1 };
          else {
            // The order is already saved and must not be submitted twice; surface
            // the preserved conflicting-tab draft rather than claiming it cleared.
            setDraftSaveError(`접수는 저장되었습니다. 다른 탭의 초안은 보존했습니다: ${clearedDraft.error}`);
            setDraftConflict(true);
          }
          setConfirmedOrder(order);
          navigate(`/orders/${encodeURIComponent(order.id)}?work=inspection`, { replace: true });
          setOrderSaveError('');
          if (readPhotoBridgeSession()) {
            setPhotoFolderStatus('Windows 보조 프로그램의 사진 연결 경로 확인 중입니다.');
            // insertConfirmedOrder materializes garment rows in its stored copy.
            // Register that saved copy, never the pre-save order without garmentIds.
            let stored: ConfirmedOrder | undefined;
            try {
              stored = readConfirmedOrders().find((item) => item.id === order.id);
            } catch {
              // A failed follow-up read must not turn a saved intake into a
              // misleading "order save failed" message.
            }
            if (!stored) {
              setPhotoFolderStatus('접수 기록은 저장됐지만 사진 폴더를 등록할 저장 의류 기록을 찾지 못했습니다. 관리자 설정에서 재확인해 주세요.');
              return true;
            }
            void registerPhotoOrder(stored).then(({ folderPath }) => {
              setPhotoFolderStatus(`사진 연결 경로 확인: ${folderPath}. 실제 촬영 사진은 아직 연결되지 않았습니다.`);
            }).catch((cause: unknown) => {
              setPhotoFolderStatus(`접수 기록은 저장됐지만 사진 연결 경로는 확인되지 않았습니다: ${cause instanceof Error ? cause.message : '연결 오류'}. 관리자 설정에서 재확인해 주세요.`);
            });
          } else {
            setPhotoFolderStatus('접수 기록은 저장됐지만 Windows 사진 보조 프로그램이 연결되지 않아 사진 경로는 확인되지 않았습니다.');
          }
          return true;
        } catch (error) {
          setOrderSaveError(error instanceof Error ? error.message : '접수 기록 저장에 실패했습니다.');
          return false;
        }
      }}
      /></>;
  }

  return (
    <main className="app-shell v1-staff-intake" data-testid="staff-intake-screen">
      <div className="staff-layout k99-intake-split">
        <section className="k99-intake-left">
          <LogoLockup />
          {priceCatalogState.error && <p role="alert">{priceCatalogState.error}</p>}
          <div className="staff-heading">
            <div className="eyebrow">COUNTER / 01</div>
              <h1>스마트 접수</h1>
              <p>{intakeMode === 'combined' ? '일반 세탁물과 운동화를 한 고객의 한 주문으로 접수합니다.' : '고객 정보를 입력하고 세탁물의 품목·수량을 선택해 주세요.'}</p>
          </div>

          <div hidden>{photoBridgePanel}</div>
          <p className="v1-intake-notice">현재 세탁비는 예상 금액입니다. 검수 후 변경 시 안내하고 고객 동의 후 진행합니다.</p>
          <SavedOrderLookup onResume={(id) => navigate(`/orders/${encodeURIComponent(id)}`)}
            onOpenOperations={() => navigate('/management')} />
          {draftSaveError && <p role="alert" data-testid="staff-intake-draft-error">{draftSaveError}</p>}

          <div className="staff-card intake-card" data-testid="intake-form-card">
            <div className="section-header">
              <div>
                <h2 className="section-title">고객 정보</h2>
                <p className="section-caption">접수 내용을 확인하기 위한 기본 정보입니다.</p>
                {intakeMode === 'combined' && <p className="section-caption" data-testid="staff-order-id">접수번호 {sourceIdRef.current.slice(0, 8)}</p>}
              </div>
              <button type="button" className="intake-text-button" data-testid="button-new-intake" onClick={resetIntake}>새 접수 시작</button>
            </div>

            <div className="field-grid">
              <label>
                <span className="field-label">고객 이름 <span aria-hidden="true">*</span></span>
                <ImeTextInput
                  className="field-input"
                  data-testid="input-customer-name"
                  type="text"
                  lang="ko"
                  inputMode="text"
                  autoCapitalize="none"
                  spellCheck={false}
                  value={customerName}
                  placeholder="이름을 입력해 주세요"
                  autoComplete="name"
                  onValue={setCustomerName}
                  onTyping={() => setTypingStarted(true)}
                />
              </label>
              <label>
                <span className="field-label">휴대전화번호 <span aria-hidden="true">*</span></span>
                <input
                  className="field-input"
                  data-testid="input-customer-phone"
                  type="tel"
                  inputMode="numeric"
                  value={customerPhone}
                  placeholder="010-0000-0000"
                  autoComplete="tel"
                  onChange={(event) => setCustomerPhone(
                    (event.nativeEvent as Event & { k99ScannerRestore?: boolean }).k99ScannerRestore
                      ? event.target.value : formatCustomerPhone(event.target.value))}
                />
              </label>
              <label className="address-field">
                <span className="field-label">주소 · 수거/배달 시 필수</span>
                <ImeTextInput className="field-input" data-testid="input-customer-address" type="text"
                  value={customerAddress} placeholder="주소를 입력해 주세요"
                  autoComplete="street-address" onValue={setCustomerAddress} onTyping={() => setTypingStarted(true)} />
              </label>
            </div>



          </div>
        <section className="summary-card staff-card" data-testid="price-summary">
          <div className="section-header">
            <div>
              <h2 className="section-title">예상금액</h2>
              <p className="section-caption">검수 후 실제 금액이 확정됩니다.</p>
            </div>
            <CheckCircle2 aria-hidden="true" size={19} />
          </div>
          {rows.some((row) => row.itemId) && <ul className="k99-intake-reviewed" data-testid="list-intake-reviewed" aria-label="확인한 품목과 수량">
            {Array.from(rows.filter((row) => row.itemId).reduce((map, row) =>
              map.set(row.itemId, (map.get(row.itemId) ?? 0) + row.quantity), new Map<string, number>()))
              .map(([itemId, quantity]) => <li key={itemId}>
                <span>{priceCatalog.find((entry) => entry.id === itemId)?.displayNameKo ?? itemId}</span>
                <strong>× {quantity}</strong>
              </li>)}
          </ul>}
          <div className={`summary-grid${sneakerOnly ? ' single' : ''}`}>
            {sneakerOnly ? (
              <div>
                <span className="summary-label">선택 서비스 합계</span>
                <strong className="summary-value" data-testid="text-total-selected">{formatWon(totals.normal)}</strong>
              </div>
            ) : (
              <>
                <div>
                  <span className="summary-label">{intakeMode === 'combined' ? '합계 · 일반 세탁 예상금액' : '일반 세탁 예상금액'}</span>
                  <strong className="summary-value" data-testid="text-total-normal">{formatWon(totals.normal)}</strong>
                </div>
                <div>
                  <span className="summary-label">{intakeMode === 'combined' ? '합계 · 프리미엄 세탁 예상금액' : '프리미엄 세탁 예상금액'}</span>
                  <strong className="summary-value" data-testid="text-total-premium">{formatWon(totals.premium)}</strong>
                </div>
              </>
            )}
          </div>
          {intakeMode === 'combined' && (
            <div className="combined-staff-breakdown" data-testid="staff-combined-breakdown">
              <div><span>일반 세탁물 · 일반</span><strong data-testid="staff-garment-general">{formatWon(breakdown.garmentGeneral)}</strong></div>
              <div><span>일반 세탁물 · 프리미엄</span><strong data-testid="staff-garment-premium">{formatWon(breakdown.garmentPremium)}</strong></div>
              <div><span>선택한 운동화 서비스</span><strong data-testid="staff-sneaker-total">{formatWon(breakdown.sneakerTotal)}</strong></div>
              <div><span>합계 · 일반</span><strong>{formatWon(breakdown.combinedGeneral)}</strong></div>
              <div><span>합계 · 프리미엄</span><strong>{formatWon(breakdown.combinedPremium)}</strong></div>
            </div>
          )}
          <div className="summary-note"><Info aria-hidden="true" /> 소재와 오염 상태에 따라 최종 금액이 달라질 수 있습니다.</div>
          <button className="open-display-button" data-testid="button-open-customer-display" type="button" onClick={openCustomerView}>
            고객 화면 열기 <MonitorUp aria-hidden="true" />
          </button>
          <div className="combined-confirmation">
            {!canProceedToFinal && <p className="section-caption" role="status" data-testid="status-initial-estimate-validation">
              {[
                !customerName.trim() && '고객 이름',
                !/^01\d{8,9}$/.test(customerPhone.replace(/\D/g, '')) && '유효한 휴대전화번호',
                !customerAddress.trim() && '주소',
                !rows.length && '접수 품목',
                customRowsError && '기타 품목명·세탁비',
              ].filter(Boolean).join(' · ')}을(를) 확인해 주세요.
            </p>}
            <button type="button" className="sneaker-add-button"
              data-testid={intakeMode === 'combined' ? 'button-confirm-combined-order' : 'button-confirm-initial-estimate'}
              disabled={!canProceedToFinal} onClick={() => {
                try { validateCustomRows(rows); } catch (error) {
                  setOrderSaveError(error instanceof Error ? error.message : '기타 품목을 확인하세요.'); return;
                }
                setOrderSaveError('');
                setEstimateConfirmed(true);
                navigate('/?stage=final');
              }}>
              접수 내용 최종 확인
            </button>
            <p className="section-caption">고객님과 품목·수량·초기 예상금액을 검토한 뒤 눌러 주세요. 이 단계에서는 주문이 저장되지 않습니다.</p>
          </div>
          {popupWarning && (
            <div className="popup-warning" data-testid="status-popup-blocked" role="alert">
              <AlertTriangle aria-hidden="true" />
              <span>고객 화면을 열 수 없습니다. 브라우저의 팝업 차단을 해제한 뒤 다시 눌러 주세요.</span>
            </div>
          )}
          <div className="status-strip" data-testid="status-sync">
            <span className="status-dot" data-active="true" /> 고객 화면과 실시간 동기화 중
          </div>
        </section>
        </section>
        <section className="k99-intake-right" aria-label="고객 안내 영상과 품목 선택">
          <div className="staff-card k99-intake-right__media" data-testid="customer-video-panel">
          <div className="v1-explanation-buttons">
            {CUSTOMER_VIDEO_BUTTONS.map(({ label, video, testId }) =>
              <button key={video} type="button" data-testid={testId} onClick={() => playCustomerExplanation(video)}>{label}</button>)}
          </div>
          <p role="status" data-testid="staff-customer-video-connection">
            {VIDEO_LINK_LABELS[videoConnection]}{videoProgress && ` · ${videoProgress}`}
          </p>
          <div className="v1-explanation-buttons" data-testid="customer-screen-controls">
            <button type="button" data-testid="button-reconnect-customer-display" onClick={openCustomerView}>
              {videoConnection === 'connected' ? '고객 화면 재연결·활성화' : '고객 화면 재연결'}
            </button>
            <button type="button" data-testid="button-configure-customer-monitor" onClick={() => { void configureCustomerMonitor(); }}>
              모니터 배치 설정
            </button>
            {customerMonitors.length > 1 && <label>고객 모니터{' '}
              <select data-testid="select-customer-monitor" value={customerMonitorKey} onChange={(event) => {
                const area = customerMonitors.find((monitor) => monitorKey(monitor) === event.target.value);
                if (area) applyCustomerMonitor(area);
              }}>
                <option value="">모니터 선택</option>
                {customerMonitors.map((area) => <option key={monitorKey(area)} value={monitorKey(area)}>
                  {area.label} · {area.width}×{area.height}
                </option>)}
              </select>
            </label>}
          </div>
          <p role="status" data-testid="customer-screen-opening-status">{customerWindowNote}</p>
          {customerMonitorNote && <p role="status" data-testid="customer-screen-monitor-status">{customerMonitorNote}</p>}
          {mediaDiagnostic && new URLSearchParams(window.location.search).has('debug') && <details data-testid="staff-customer-media-diagnostic"><summary>고객 영상 재생 기록</summary><pre>{mediaDiagnostic}</pre></details>}
          {mediaError && <p role="alert" data-testid="staff-customer-media-error">{mediaError}
          </p>}
          </div>
          <div className="staff-card k99-intake-right__items">
            {<div className="items-block" data-testid="garment-intake-section">
              <div className="item-heading">
                <div>
                  <h2 className="section-title">일반 세탁물</h2>
                  <p className="section-caption" data-testid="text-item-count">{visibleRows.length}개 품목 · 수량을 포함해 계산합니다.</p>
                </div>
                {<button className="add-item-button" data-testid="button-add-item" type="button" onClick={addRow}>
                  <Plus aria-hidden="true" /> 품목 추가
                </button>}
              </div>

              {visibleRows.length > 0 ? (
                <table className="item-table" data-testid="table-laundry-items">
                  <thead>
                    <tr>
                      <th scope="col">품목</th>
                      <th scope="col">수량</th>
                      <th scope="col">기본 단가</th>
                      <th scope="col"><span className="sr-only">삭제</span></th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortRowsByCatalog(visibleRows).map((row) => {
                      const price = resolveRowPrice(row, priceCatalog);
                      return (
                        <tr className="item-row" key={row.id} data-testid={`row-laundry-item-${row.id}`}>
                          <td>
                            <select
                              className="item-select"
                              data-testid={`select-item-${row.id}`}
                              aria-label={`품목 ${row.id}`}
                              value={row.itemId}
                              onChange={(event) => updateRow(row.id, { itemId: event.target.value as LaundryItemId })}
                            >
                              {groupByCategory(selectableEntries(priceCatalog).filter((option) => !isSneakerItem(option.id))).map((group) => (
                                <optgroup key={group.category} label={group.label}>
                                  {group.items.map((option) => (
                                    <option key={option.id} value={option.id}>{option.displayNameKo}</option>
                                  ))}
                                </optgroup>
                              ))}
                              {price.legacy && <option value={price.id}>{price.displayNameKo} (이전 품목)</option>}
                            </select>
                            <ItemIntakeDetailsFields itemId={row.itemId} value={rowDetails[row.id] ?? {}}
                              onChange={(details) => setRowDetails((current) => ({ ...current, [row.id]: details }))} />
                            {row.itemId === 'other' && <div className="custom-item-fields" data-testid={`custom-item-${row.id}`}>
                              <label>세탁물 품목명 <input maxLength={100} value={row.customName ?? ''}
                                data-testid={`custom-item-name-${row.id}`} onChange={e => updateRow(row.id, { customName: e.target.value })} /></label>
                              <label>세탁비 (1벌) <input type="number" min="1" max="100000000" step="1"
                                data-testid={`custom-item-price-${row.id}`} value={row.customPrice ?? ''}
                                onChange={e => updateRow(row.id, { customPrice: e.target.value === '' ? undefined : Number(e.target.value) })} /></label>
                              <small>입력 금액은 이 주문에만 적용됩니다. 일반·프리미엄은 최종 확인에서 한 벌씩 선택할 수 있습니다.</small>
                            </div>}
                          </td>
                          <td>
                            <div className="quantity-control" data-testid={`quantity-control-${row.id}`}>
                              <button
                                type="button"
                                data-testid={`button-decrease-quantity-${row.id}`}
                                aria-label={`${price.displayNameKo} 수량 줄이기`}
                                onClick={() => updateRow(row.id, { quantity: Math.max(1, row.quantity - 1) })}
                              >
                                <Minus aria-hidden="true" />
                              </button>
                              <span className="quantity-value" data-testid={`text-quantity-${row.id}`}>{row.quantity}</span>
                              <button
                                type="button"
                                data-testid={`button-increase-quantity-${row.id}`}
                                aria-label={`${price.displayNameKo} 수량 늘리기`}
                                onClick={() => updateRow(row.id, { quantity: Math.min(99, row.quantity + 1) })}
                              >
                                <Plus aria-hidden="true" />
                              </button>
                            </div>
                          </td>
                           <td><span className="row-price" data-testid={`text-item-price-${row.id}`}>{formatWon(price.generalPrice)}{price.unit === 'pair' ? ' / 켤레' : ''}</span></td>
                          <td>
                            <button
                              className="delete-row"
                              type="button"
                              data-testid={`button-delete-item-${row.id}`}
                              aria-label={`${price.displayNameKo} 삭제`}
                              onClick={() => removeRow(row.id)}
                            >
                              <Trash2 aria-hidden="true" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                <div className="empty-items" data-testid="empty-laundry-items">
                  <ClipboardList aria-hidden="true" />
                  <span>아직 세탁물이 없습니다. 품목을 추가해 주세요.</span>
                </div>
              )}
              <p className="helper-text">품목별 수량은 오른쪽 더하기 버튼으로 조정할 수 있습니다.</p>
            </div>}
            {sneakerStep === 'intake' && (
              <section className="sneaker-intake-panel" data-testid="sneaker-intake-screen" aria-label="운동화 접수">
                <div className="sneaker-intake-heading">
                  <div><h2>운동화 종류와 수량</h2></div>
                  <button type="button" className="intake-text-button" data-testid="button-show-sneaker-info" onClick={() => playCustomerExplanation('sneakers')}>운동화 서비스 안내 보기</button>
                </div>
                {(['sneakers_general', 'sneakers_premium'] as const).map((id) => (
                  <div className="sneaker-intake-row" key={id}>
                    <div><strong>{getPrice(id, priceCatalog).displayNameKo} 세탁</strong><span>{formatWon(getPrice(id, priceCatalog).generalPrice)} / 1켤레</span></div>
                    <div className="quantity-control">
                      <button type="button" aria-label={`${getPrice(id, priceCatalog).displayNameKo} 수량 줄이기`} onClick={() => {
                        const row = rows.find((entry) => entry.itemId === id);
                        if (sneakerQuantities[id] || !row) setSneakerQuantities((current) => ({ ...current, [id]: Math.max(0, current[id] - 1) }));
                        else updateRow(row.id, { quantity: Math.max(1, row.quantity - 1) });
                      }}><Minus aria-hidden="true" /></button>
                      <span className="quantity-value" data-testid={`sneaker-intake-quantity-${id}`}>{rows.filter((row) => row.itemId === id).reduce((sum, row) => sum + row.quantity, 0) + sneakerQuantities[id]}</span>
                      <button type="button" aria-label={`${getPrice(id, priceCatalog).displayNameKo} 수량 늘리기`} onClick={() => {
                        const row = rows.find((entry) => entry.itemId === id);
                        if (row && !sneakerQuantities[id]) updateRow(row.id, { quantity: Math.min(99, row.quantity + 1) });
                        else setSneakerQuantities((current) => ({ ...current, [id]: Math.min(99, current[id] + 1) }));
                      }}><Plus aria-hidden="true" /></button>
                    </div>
                  </div>
                ))}
                <button type="button" className="sneaker-add-button" data-testid="button-add-sneaker-quantities"
                  disabled={!sneakerQuantities.sneakers_general && !sneakerQuantities.sneakers_premium}
                  onClick={() => {
                    addSneakers((['sneakers_general', 'sneakers_premium'] as const)
                      .filter((id) => sneakerQuantities[id] > 0)
                      .map((id) => ({ itemId: id, quantity: sneakerQuantities[id] })));
                    setSneakerQuantities({ sneakers_general: 0, sneakers_premium: 0 });
                  }}>선택 수량 접수에 추가</button>
                {rows.filter((row) => isSneakerItem(row.itemId)).map((row) => (
                  <div className="sneaker-intake-row" key={row.id} data-testid={`row-laundry-item-${row.id}`}>
                    <div><strong>{getPrice(row.itemId, priceCatalog).displayNameKo} · {row.quantity}켤레</strong>
                      <span>{formatWon(getPrice(row.itemId, priceCatalog).generalPrice)} / 1켤레</span></div>
                    <div className="quantity-control">
                      <button type="button" aria-label={`${getPrice(row.itemId, priceCatalog).displayNameKo} 수량 줄이기`}
                        onClick={() => updateRow(row.id, { quantity: Math.max(1, row.quantity - 1) })}><Minus aria-hidden="true" /></button>
                      <span className="quantity-value" data-testid={`text-quantity-${row.id}`}>{row.quantity}</span>
                      <button type="button" aria-label={`${getPrice(row.itemId, priceCatalog).displayNameKo} 수량 늘리기`}
                        onClick={() => updateRow(row.id, { quantity: Math.min(99, row.quantity + 1) })}><Plus aria-hidden="true" /></button>
                    </div>
                    <button type="button" className="delete-row" aria-label={`${getPrice(row.itemId, priceCatalog).displayNameKo} 삭제`}
                      onClick={() => removeRow(row.id)}><Trash2 aria-hidden="true" /></button>
                  </div>
                ))}
              </section>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}

function CustomerDisplayRoute() {
  const [payload, setPayload] = useState<DisplayPayload | null>(() => readPayload());
  // Ephemeral, opener- or display-targeted live button commands only. Never recover a video from
  // URL payloads, snapshots or sessionStorage when this page opens/reloads.
  const [mediaCommand, setMediaCommand] = useState<CustomerMediaCommand>();
  const liveVideoRef = useRef<CustomerVideoChannel | null>(null);
  const [presentationScreen, setPresentationScreen] = useState<PresentationScreen>(
    () => {
      const screen = new URLSearchParams(window.location.search).get('screen');
      return screen === 'common' || screen === 'sneaker' ? screen : 'order';
    },
  );
  const [isLoading, setIsLoading] = useState(true);
  const sourceIdRef = useRef(new URLSearchParams(window.location.search).get('source') ?? payload?.sourceId ?? null);
  const videoSourceRef = useRef<string | null>(null);
  videoSourceRef.current = payload?.sourceId === sourceIdRef.current ? sourceIdRef.current : null;

  useEffect(() => {
    if (!('BroadcastChannel' in window)) return;
    const link = new CustomerVideoChannel(new BroadcastChannel(LIVE_VIDEO_CHANNEL), {
      source: () => videoSourceRef.current,
      onCommand: setMediaCommand,
    });
    liveVideoRef.current = link;
    return () => { link.close(); liveVideoRef.current = null; };
  }, []);

  useEffect(() => {
    if (!payload || payload.sourceId !== sourceIdRef.current) return;
    try {
      window.sessionStorage.setItem(customerSnapshotKey(payload.sourceId), JSON.stringify(payload));
    } catch { /* Live handoff still works if per-window storage is unavailable. */ }
  }, [payload]);

  useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 420);
    const handlePayload = (nextPayload: unknown) => {
      const normalized = normalizePayload(nextPayload);
      if (!normalized || !sourceIdRef.current || normalized.sourceId !== sourceIdRef.current) return;
      setPayload((current) => current && current.revision > normalized.revision ? current : normalized);
      setIsLoading(false);
    };
    const handleStorage = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;
      try {
        handlePayload(JSON.parse(event.newValue));
      } catch {
        // 손상된 저장값은 무시하고 현재 화면을 유지합니다.
      }
    };
    const handleWindowMessage = (
      event: MessageEvent<{ type?: string; payload?: unknown; sourceId?: string; screen?: PresentationScreen; command?: unknown }>,
    ) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === 'k99-new-intake' && event.source === window.opener) {
        const next = normalizePayload(event.data.payload);
        if (!next) return;
        sourceIdRef.current = next.sourceId;
        setMediaCommand(undefined);
        setPayload(next);
        setPresentationScreen('order');
        setIsLoading(false);
        const url = new URL(window.location.href);
        url.searchParams.set('source', next.sourceId);
        url.searchParams.set('data', JSON.stringify(next));
        url.searchParams.set('screen', 'order');
        window.history.replaceState(window.history.state, '', url);
        return;
      }
      if (event.data?.type === CUSTOMER_MEDIA_COMMAND && event.source === window.opener &&
          event.data.sourceId === sourceIdRef.current && isMediaCommand(event.data.command)) {
        setMediaCommand(event.data.command);
        window.opener?.postMessage(
          { type: CUSTOMER_MEDIA_ACK, sourceId: sourceIdRef.current, commandId: event.data.command.id },
          window.location.origin,
        );
        return;
      }
      if (event.data?.type === CUSTOMER_VIDEO_PING && event.source === window.opener &&
          event.data.sourceId === sourceIdRef.current && typeof (event.data as { probeId?: unknown }).probeId === 'string') {
        window.opener?.postMessage({ type: CUSTOMER_VIDEO_PONG, sourceId: sourceIdRef.current,
          probeId: (event.data as { probeId?: string }).probeId, videoProtocol: CUSTOMER_VIDEO_PROTOCOL }, window.location.origin);
        return;
      }
      if (event.data?.type === SYNC_MESSAGE_TYPE) handlePayload(event.data.payload);
      if (event.data?.type === SCREEN_MESSAGE_TYPE && event.source === window.opener &&
          event.data.sourceId === sourceIdRef.current &&
          (event.data.screen === 'common' || event.data.screen === 'sneaker' || event.data.screen === 'order')) {
        setPresentationScreen(event.data.screen);
      }
    };
    let channel: BroadcastChannel | null = null;
    if ('BroadcastChannel' in window) {
      channel = new BroadcastChannel(CHANNEL_NAME);
      channel.addEventListener('message', (event: MessageEvent<{ type?: string; sourceId?: string; placement?: unknown }>) => {
        if (event.data?.type === CUSTOMER_ACTIVATE_MESSAGE && event.data.sourceId === sourceIdRef.current) {
          activateCustomerWindow(window, validMonitor(event.data.placement) ? event.data.placement : undefined);
          return;
        }
        handlePayload(event.data);
      });
    }
    window.addEventListener('storage', handleStorage);
    window.addEventListener('message', handleWindowMessage);
    const ready = () => window.opener?.postMessage({ type: READY_MESSAGE_TYPE, sourceId: sourceIdRef.current,
      videoProtocol: CUSTOMER_VIDEO_PROTOCOL }, window.location.origin);
    ready();
    // The staff page may reload and lose its JS Window reference while this activated monitor stays open.
    const readyTimer = window.setInterval(ready, 1500);
    return () => {
      window.clearTimeout(timer);
      window.clearInterval(readyTimer);
      channel?.close();
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('message', handleWindowMessage);
    };
  }, []);

  const closeCustomerView = () => {
    window.close();
    window.setTimeout(() => {
      if (!window.closed) window.location.replace(`${window.location.origin}${import.meta.env.BASE_URL}customer`);
    }, 120);
  };

  if (isLoading) {
    return (
      <main className="customer-shell customer-loading" data-testid="customer-view-loading">
        <div className="loading-card">
          <div className="loading-mark" aria-hidden="true" />
          <p>고객 화면을 준비하고 있습니다.</p>
        </div>
      </main>
    );
  }

  if (!payload) {
    return (
      <main className="customer-shell customer-loading" data-testid="customer-payload-error" role="alert">
        <div className="loading-card">
          <p>접수 정보를 확인할 수 없습니다.</p>
          <p>직원 화면에서 ‘고객 화면 열기’를 다시 눌러 주세요.</p>
        </div>
      </main>
    );
  }

  return (
    <CustomerMedia key={payload.sourceId} sourceId={payload.sourceId}
      onStatus={(status: LiveVideoStatus) => liveVideoRef.current?.status(status)}
      command={mediaCommand}><CustomerDisplay
      payload={payload}
      onClose={closeCustomerView}
    /></CustomerMedia>
  );
}

function CustomerDisplay({ payload }: { payload: DisplayPayload; onClose: () => void }) {
  const sneakerOnly = isSneakerOnlyOrder(payload.rows);
  const combinedBreakdown = getCombinedBreakdown(payload.rows);
  const isMixedOrder = combinedBreakdown.garments.length > 0 && combinedBreakdown.sneakers.length > 0;
  const displayRows = sortRowsByCatalog(payload.rows);
  const rowPrice = (id: string, fallback: number) => payload.rows.find((row) => row.itemId === id)?.generalPrice ?? fallback;
  const shoeTypes = [
    { id: 'sneakers_general', title: '일반 운동화 세탁', description: '전문 운동화 세탁공장 위탁 세탁', price: rowPrice('sneakers_general', 9000) },
    { id: 'sneakers_premium', title: '프리미엄 운동화 세탁', description: 'K99 직접 검수 및 직접 세탁', price: rowPrice('sneakers_premium', 18000) },
  ].filter((type) => payload.rows.some((row) => row.itemId === type.id));

  return (
    <main className="customer-shell" data-testid="customer-display-screen">
      <div className="customer-inner customer-split" data-testid="customer-split-layout">
        <section className="customer-main customer-split__left" data-testid="customer-split-left">
          <h1 className="customer-title" data-testid="text-customer-display-title">
            <small>K99 품격세탁소</small>
            세탁물 접수 및 예상 금액 안내
          </h1>
          <div className="customer-name" data-testid="text-customer-name">{payload.customerName ? `${payload.customerName} 고객님` : '고객님'}</div>
          <div className="customer-contact" data-testid="customer-order-info">
            {payload.customerPhone && <span data-testid="text-customer-phone">{payload.customerPhone}</span>}
            <span data-testid="customer-order-id">접수번호&nbsp; {payload.sourceId.slice(0, 8)}</span>
          </div>

          {isMixedOrder ? <CombinedOrderDetails rows={payload.rows} /> : <>
          <div className="customer-items">
            <div className={`customer-items-heading${sneakerOnly ? ' sneaker-only' : ''}`}>
              <span>세탁물 품목</span>
              <span>수량</span>
              {sneakerOnly ? <span>선택 서비스 금액</span> : (
                <>
                  <span>일반 금액</span>
                  <span>프리미엄 추가금액</span>
                </>
              )}
            </div>
            {displayRows.length > 0 ? displayRows.map((row) => (
              <div className={`customer-item-row${sneakerOnly ? ' sneaker-only' : ''}`} key={row.id} data-testid={`customer-row-laundry-${row.id}`}>
                <span data-testid={`customer-text-item-${row.id}`}>{row.displayNameKo}{!sneakerOnly && isSneakerItem(row.itemId) ? ' 세탁' : ''}
                  {row.selectedServices && <small style={{ display: 'block' }} data-testid={`customer-unit-services-${row.id}`}>
                    {row.selectedServices.map((level, u) => `${u + 1}번 ${level}`).join(' · ')}
                    {typeof row.selectedAmount === 'number' && ` · 선택금액 ${formatWon(row.selectedAmount)}`}
                  </small>}
                </span>
                <span data-testid={`customer-text-quantity-${row.id}`}>{row.quantity}{isSneakerItem(row.itemId) ? '켤레' : '개'}</span>
                {sneakerOnly ? (
                  <span className="customer-item-price" data-testid={`customer-price-selected-${row.id}`}>
                    {formatWon(row.generalPrice * row.quantity)}
                    <small>단가 {formatWon(row.generalPrice)} / 1켤레</small>
                  </span>
                ) : (
                  <>
                    <span className="customer-item-price" data-testid={`customer-price-normal-${row.id}`}>
                      <small className="customer-price-type">{isSneakerItem(row.itemId) ? '선택 서비스' : '일반'}</small>
                      {formatWon(row.generalPrice * row.quantity)}
                      <small>단가 {formatWon(row.generalPrice)}{isSneakerItem(row.itemId) ? ' / 1켤레' : ''}</small>
                    </span>
                    <span className="customer-item-price" data-testid={`customer-price-premium-${row.id}`}>
                      <small className="customer-price-type">{isSneakerItem(row.itemId) ? '선택 서비스' : '프리미엄 추가금액'}</small>
                      {isSneakerItem(row.itemId) ? formatWon(row.premiumPrice * row.quantity)
                        : `+${formatWon((row.premiumPrice - row.generalPrice) * row.quantity)}`}
                      <small>{isSneakerItem(row.itemId) ? `단가 ${formatWon(row.premiumPrice)} / 1켤레`
                        : `1개당 +${formatWon(row.premiumPrice - row.generalPrice)}`}</small>
                      {!isSneakerItem(row.itemId) && <small data-testid={`customer-price-difference-${row.id}`}>
                        일반 대비 +{formatWon((row.premiumPrice - row.generalPrice) * row.quantity)}
                      </small>}
                    </span>
                  </>
                )}
              </div>
            )) : (
              <div className="customer-item-row" data-testid="customer-empty-items">
                <span>등록된 세탁물이 없습니다.</span>
                <span>—</span>
                <span>—</span>
                <span>—</span>
              </div>
            )}
            <p className="customer-total-quantity" data-testid="customer-total-quantity">
              총 수량: <strong>{payload.totalQuantity}{sneakerOnly ? '켤레' : '개'}</strong>
            </p>
          </div>

          <div className={`customer-prices${sneakerOnly ? ' single' : ''}`} data-testid="customer-price-summary">
            {payload.selectedTotal !== undefined && <div className="price-panel">
              <span className="price-panel-label">세탁물별 선택 세탁비 합계</span>
              <strong className="price-panel-value" data-testid="customer-unit-total">{formatWon(payload.selectedTotal)}</strong>
            </div>}
            {sneakerOnly ? (
              <div className="price-panel">
                <span className="price-panel-label">선택 서비스 합계</span>
                <strong className="price-panel-value" data-testid="customer-total-selected">{formatWon(payload.normalTotal)}</strong>
              </div>
            ) : (
              <>
                <div className="price-panel">
                  <span className="price-panel-label">일반 세탁 예상금액</span>
                  <strong className="price-panel-value" data-testid="customer-total-normal">{formatWon(payload.normalTotal)}</strong>
                </div>
                <div className="price-panel premium">
                  <span className="price-panel-label">프리미엄 추가금액 · 일반 대비</span>
                  <strong className="price-panel-value" data-testid="customer-total-premium">+{formatWon(payload.premiumTotal - payload.normalTotal)}</strong>
                </div>
              </>
            )}
          </div>
          </>}


           {shoeTypes.length > 0 && (
            <section className="shoe-notice" data-testid="shoe-wash-notice">
               <h3>선택하신 운동화 세탁 서비스</h3>
               <div className={`shoe-prices${shoeTypes.length === 1 ? ' single' : ''}`}>
                 {shoeTypes.map((type) => (
                   <div key={type.id}>
                     <span className="shoe-price-label">{type.title}</span>
                     <strong className="shoe-price-value" data-testid={type.id === 'sneakers_general' ? 'shoe-normal-price' : 'shoe-premium-price'}>{formatWon(type.price)} / 1켤레</strong>
                     <span className="shoe-service">{type.description}</span>
                     <span className="shoe-service">{type.id === 'sneakers_premium'
                       ? '일반 운동화 9,000원 대비 +9,000원 / 1켤레 · 선택 금액에 포함'
                       : '프리미엄 운동화로 변경 시 +9,000원 / 1켤레 · 별도 선택'}</span>
                   </div>
                 ))}
              </div>
              <p className="shoe-copy" data-testid="shoe-inspection-copy">
                 일반 운동화 세탁은 K99의 전문 협력 세탁소에서 진행합니다.<br />
                 프리미엄 운동화 세탁은 매장에서 교수님이 직접 상태를 정밀 검수한 후 세탁합니다.<br />
                 프리미엄 운동화는 상태에 따라 발수 가공을 진행하며, 흰색 운동화 끈은 새 끈으로, 깔창은 새 깔창으로 교환해 드립니다.
              </p>
            </section>
          )}

          <footer className="customer-footer">
            <span data-testid="text-customer-footer">고객님, 맡겨 주셔서 감사합니다.</span>
          </footer>
        </section>
        <aside className="customer-aside customer-split__right" data-testid="customer-split-right">
          <LogoLockup />
          <section className="inspection-notice customer-estimate-warning" data-testid="text-inspection-notice" aria-live="off">
            <p className="customer-estimate-warning__lead" data-testid="text-estimate-warning-lead">현재 표시된 세탁비는 예상 금액입니다.</p>
            <p>검수 결과에 따라 세탁비가 변경될 수 있습니다.</p>
            <p>변경 시 고객님께 안내드리고, 동의 후 세탁을 진행합니다.</p>
          </section>
          <div className="customer-kicker">
            <strong>K99 QUALITY LAUNDRY</strong>
            <span>가격보다 품격을 담았습니다.</span>
          </div>
        </aside>
      </div>
    </main>
  );
}

function NotFound() {
  return (
    <main className="app-shell" data-testid="not-found-screen">
      <div className="staff-layout">
        <section>
          <LogoLockup />
          <div className="staff-heading">
            <div className="eyebrow">404 / NOT FOUND</div>
            <h1>페이지를<br />찾을 수 없습니다.</h1>
            <p>직원 접수 화면으로 돌아가 주세요.</p>
            <button className="ghost-button" data-testid="button-return-home" type="button" onClick={() => { window.location.href = import.meta.env.BASE_URL; }}>
              접수 화면으로 돌아가기 <ArrowUpRight aria-hidden="true" />
            </button>
          </div>
        </section>
      </div>
    </main>
  );
}

function LaundryProcessRoute({ orderId }: { orderId: string }) {
  const [, navigate] = useLocation();
  // Older bookmarked process URLs must open the actionable order overview
  // before approval, rather than trap intake orders behind the legacy gate.
  try {
    const saved = readConfirmedOrders().find((order) => order.id === orderId);
    if (!saved?.inspection || !['세탁 진행 승인', '전체 세탁 완료 / 반출 대기'].includes(saved.status))
      return <OrderWorkspace key={orderId} orderId={orderId} />;
  } catch {
    return <OrderWorkspace key={orderId} orderId={orderId} />;
  }
  return <LaundryProcessWorkspace key={orderId} orderId={orderId} onBack={() => {
    try { resumeConfirmedOrder(orderId); } catch { /* The saved-order screen can show a missing order. */ }
    navigate(savedIntakeUrl(orderId));
  }} />;
}

function ScannerRoute() {
  const [, navigate] = useLocation();
  return <GarmentScannerWorkspace onBack={() => navigate('/')} onOpenCapture={(orderId, garmentId) => {
    resumeConfirmedOrder(orderId);
    navigate(`/equipment?orderId=${encodeURIComponent(orderId)}&garmentId=${encodeURIComponent(garmentId)}`);
  }} />;
}

function EquipmentChrome() {
  const [location, navigate] = useLocation();
  if (location.startsWith('/equipment/customer') || location.startsWith('/customer')) return null;
  return <>
    <DesktopStatusStrip />
    <nav className="eqnav" aria-label="장비 2단계">
      <button type="button" onClick={() => navigate('/equipment')} aria-current={location === '/equipment' ? 'page' : undefined}
        data-testid="link-equipment-workspace">장비 연동 (2단계)</button>
      <button type="button" onClick={() => navigate('/maintenance')} aria-current={location === '/maintenance' ? 'page' : undefined}
        data-testid="link-maintenance-workspace">데이터 보존 (3단계)</button>
    </nav>
  </>;
}

function StaffIntakeRoute() {
  const search = useSearch();
  const id = new URLSearchParams(search).get('orderId');
  // Wouter pathname subscriptions alone do not react to query-only navigation.
  // Remount when identity changes so a previous order cannot remain in React state.
  return <StaffIntake key={id ?? 'draft'} />;
}

function App() {
  // A native launch can open a second tab solely for authentication. Do not
  // mount another editable intake there and mutate/conflict with the live draft.
  const [bridgePairingEntry, setBridgePairingEntry] = useState(() => readPhotoBridgePairingEntry());
  useEffect(() => { seedWorkflowHistory(import.meta.env.BASE_URL); }, []);
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
      <EquipmentChrome />
      <PhotoBridgeConnection />
      <GlobalTagScanner />
      <StaffManagementNav />
      <Switch>
        <Route path="/equipment/customer" component={EquipmentCustomer} />
        <Route path="/equipment" component={EquipmentWorkspace} />
        <Route path="/maintenance" component={MaintenanceWorkspace} />
        <Route path="/">
          {bridgePairingEntry ? <main className="app-shell">
            <h1>사진 도우미 연결</h1>
            <p>연결 확인 후 원래 접수 창으로 돌아가세요. 접수 내용은 그대로 유지됩니다.</p>
            <button type="button" onClick={() => {
              leavePhotoBridgePairingEntry();
              setBridgePairingEntry(false);
            }}>이 창에서 접수 화면 열기</button>
          </main> : <StaffIntakeRoute />}
        </Route>
        <Route path="/scan">{() => <ScannerRoute />}</Route>
        <Route path="/laundry" component={LaundryDesk} />
        <Route path="/orders/:orderId">
          {(params) => <OrderWorkspace key={params.orderId} orderId={params.orderId} />}
        </Route>
        <Route path="/management/today" component={TodayOperationsRoute} />
        <Route path="/management/store-test" component={StoreHardwareTestRoute} />
        <Route path="/management/photo-settings" component={PhotoBridgeSettingsRoute} />
        <Route path="/management" component={ManagementRoute} />
        <Route path="/customer-result" component={CustomerResultRoute} />
        <Route path="/photo/:orderId/:garmentId">
          {(params) => <PhotoWorkspaceRoute orderId={params.orderId} garmentId={params.garmentId} />}
        </Route>
        <Route path="/photo/:orderId">
          {(params) => <PhotoWorkspaceRoute orderId={params.orderId} />}
        </Route>
        <Route path="/customer" component={CustomerDisplayRoute} />
        <Route path="/laundry-process/:orderId">
          {(params) => <LaundryProcessRoute orderId={params.orderId} />}
        </Route>
        <Route component={NotFound} />
      </Switch>
    </WouterRouter>
  );
}

export default App;