import { useState, type FormEvent } from 'react';

export function NativeLedgerImportPanel() {
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const supported = typeof window.k99Desktop?.importCustomerLedger === 'function';
  async function importFile(event: FormEvent) {
    event.preventDefault();
    if (busy || !supported) return;
    setBusy(true); setNotice(''); setError('');
    try {
      const result = await window.k99Desktop!.importCustomerLedger!({ password });
      if (result.cancelled) { setNotice('파일 선택을 취소했습니다. DB는 변경하지 않았습니다.'); return; }
      if (!result.success) throw new Error(result.error || '장부를 저장하지 못했습니다.');
      if (!Number.isInteger(result.customerCount) || !Number.isInteger(result.orderCount))
        throw new Error('저장 결과를 확인하지 못했습니다. 중복 업로드 전에 등록 내역을 확인하세요.');
      setNotice(`고객 ${result.customerCount}명, 주문 ${result.orderCount}건 등록 완료`);
      setPassword('');
      window.dispatchEvent(new Event('k99-equipment-changed'));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '엑셀 가져오기에 실패했습니다.');
    } finally { setBusy(false); }
  }
  return <section className="eq-card" aria-label="고객 장부 엑셀 가져오기">
    <h2>고객 장부 엑셀 가져오기</h2>
    <p>실제 파일 선택창에서 XLSX·XLS·CSV를 선택합니다. 저장 전 안전 백업 후 이 PC의 SQLite 고객·주문 테이블에 영구 반영합니다.</p>
    <form onSubmit={event => void importFile(event)}>
      <label>관리자 비밀번호
        <input type="password" className="eq-input" autoComplete="current-password" value={password}
          onChange={event => setPassword(event.target.value)} disabled={busy || !supported} maxLength={128}
          data-testid="input-native-ledger-password" />
      </label>
      <button type="submit" className="eq-btn is-primary" disabled={!supported || busy || !password}
        data-testid="button-native-ledger-import">
        {busy ? '실제 장부를 읽고 저장하는 중…' : '고객 장부 엑셀 파일(.xlsx/.csv) 불러오기'}
      </button>
    </form>
    {!supported && <p>이 기능은 Windows 설치본에서만 사용할 수 있습니다. 브라우저 파일·Mock 데이터로 대체하지 않습니다.</p>}
    <p>동일 이력은 중복 생성하지 않습니다. “주문 0건”은 새로 추가된 일자 주문이 없다는 뜻입니다. 원본 파일·기존 사진은 변경하지 않습니다.</p>
    {notice && <p role="status" data-testid="status-native-ledger-import">{notice}</p>}
    {error && <p role="alert" className="eq-error">{error}</p>}
  </section>;
}
