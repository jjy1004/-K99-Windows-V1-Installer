import { useState, type FormEvent } from 'react';

export function NativeLedgerImportPanel() {
  const [busy, setBusy] = useState(false);
  const [tplBusy, setTplBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const supported = typeof window.k99Desktop?.importCustomerLedger === 'function';
  const tplSupported = typeof window.k99Desktop?.downloadCustomerTemplate === 'function';

  async function importFile(event: FormEvent) {
    event.preventDefault();
    if (busy || !supported) return;
    setBusy(true); setNotice(''); setError('');
    try {
      const result = await window.k99Desktop!.importCustomerLedger!();
      if (result.cancelled) { setNotice('파일 선택을 취소했습니다. DB는 변경하지 않았습니다.'); return; }
      if (!result.success) throw new Error(result.error || '장부를 저장하지 못했습니다.');
      if (!Number.isInteger(result.customerCount) || !Number.isInteger(result.orderCount))
        throw new Error('저장 결과를 확인하지 못했습니다. 중복 업로드 전에 등록 내역을 확인하세요.');
      setNotice(`고객 ${result.customerCount}명, 주문 ${result.orderCount}건 등록 완료`);
      window.dispatchEvent(new Event('k99-equipment-changed'));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '엑셀 가져오기에 실패했습니다.');
    } finally { setBusy(false); }
  }

  async function downloadTemplate() {
    if (tplBusy) return;
    setNotice(''); setError('');
    if (!tplSupported) { setError('샘플 양식 다운로드는 Windows 설치본 앱에서만 사용할 수 있습니다.'); return; }
    setTplBusy(true);
    try {
      const result = await window.k99Desktop!.downloadCustomerTemplate!();
      if (result.cancelled) { setNotice('저장을 취소했습니다.'); return; }
      if (!result.success) throw new Error(result.error || '샘플 양식을 저장하지 못했습니다.');
      setNotice('샘플 양식을 저장했습니다. 엑셀로 열어 고객을 입력한 뒤 업로드하세요.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '샘플 양식을 저장하지 못했습니다.');
    } finally { setTplBusy(false); }
  }

  return <section className="eq-card" id="customer-ledger-import" tabIndex={-1} aria-label="고객 엑셀 일괄 업로드">
    <h2>고객 엑셀 일괄 업로드</h2>
    <p>1) 샘플 양식을 받아 2) 고객을 입력하고 3) 업로드하세요. XLSX·XLS·CSV 파일을 사용할 수 있습니다.</p>
    <p><b>입력 칸:</b> 고객명, 휴대폰번호, 주소, 방문일, 방문횟수, 누적금액, 메모</p>
    <p>고객 명단은 성함(또는 고객명), 전체 전화번호, 주소, 메모(또는 비고)만 있어도 등록할 수 있습니다. 주소·메모와 방문 이력은 선택 항목입니다.</p>
    <p>같은 이름과 전체 전화번호는 기존 고객에 병합합니다. 동명이인이나 전화번호 끝4자리만 같은 고객은 임의로 합치지 않습니다.</p>
    <p>누적금액은 고객 프로필 요약 정보로만 저장됩니다. 매출이나 가상 주문으로 만들지 않으므로 매출 합계에 중복으로 더해지지 않습니다.</p>
    <button type="button" className="eq-btn" onClick={() => void downloadTemplate()} disabled={tplBusy}
      data-testid="button-download-customer-template">
      {tplBusy ? '샘플 양식 저장 중…' : '샘플 양식 다운로드'}
    </button>
    <form onSubmit={event => void importFile(event)}>
      <p>파일을 선택하면 검증·안전 백업 후 이 PC의 고객 장부에 바로 저장됩니다.</p>
      <button type="submit" className="eq-btn is-primary" disabled={!supported || busy}
        data-testid="button-native-ledger-import">
        {busy ? '고객 엑셀을 읽고 저장하는 중…' : '고객 엑셀 일괄 업로드'}
      </button>
    </form>
    {!supported && <p>이 기능은 Windows 설치본 앱에서만 사용할 수 있습니다. 브라우저 파일·Mock 데이터로 대체하지 않습니다.</p>}
    <p>동일 이력은 중복 생성하지 않습니다. “주문 0건”은 새로 추가된 일자 주문이 없다는 뜻입니다. 원본 파일·기존 사진은 변경하지 않습니다.</p>
    <p>등록 후 접수 화면에서 이름 두 글자 이상 또는 전화번호 끝4자리로 검색하면 이름·전체 전화번호·주소를 불러올 수 있습니다.</p>
    {notice && <p role="status" data-testid="status-native-ledger-import">{notice}</p>}
    {error && <p role="alert" className="eq-error">{error}</p>}
  </section>;
}
