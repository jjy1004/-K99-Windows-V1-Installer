import { useEffect, useRef, useState } from 'react';
import { DiaryRecorder, recordingBase64, SilenceDetector } from './diary-recorder';
import './diary-voice.css';

type Connection = { url: string; tokenConfigured: boolean; urlOverridden?: boolean; tokenOverridden?: boolean };
export async function diaryVoiceRequest<T>(input: { action: string; url?: string; token?: string; audio_base64?: string; raw_text?: string }): Promise<T> {
  const send = window.k99Desktop?.diaryVoice;
  if (!send) throw Error('음성 기록은 Windows 설치 앱에서 사용합니다.');
  const reply = await send(input);
  if (!reply.ok) throw Error(reply.error || '음성 요청 실패');
  return reply.result as T;
}

export function DiaryVoiceControls({ disabled, onTranscript, onOrganized, onBusy, registerStop, savedAt }: {
  disabled: boolean;
  onTranscript: (raw: string) => void;
  onOrganized: (text: string) => void;
  onBusy: (busy: boolean) => void;
  registerStop: (stop: () => void) => void;
  savedAt?: string;
}) {
  const [state, setState] = useState<'idle' | 'starting' | 'recording' | 'paused' | 'processing' | 'file-ready'>('idle');
  const [message, setMessage] = useState('');
  const [level, setLevel] = useState(0);
  const [connection, setConnection] = useState<Connection | null>(null);
  const [settings, setSettings] = useState(false);
  const [url, setUrl] = useState('');
  const [token, setToken] = useState('');
  const [configBusy, setConfigBusy] = useState(false);
  const [fileName, setFileName] = useState('');
  const [trace, setTrace] = useState<string[]>([]);
  const [rawResult, setRawResult] = useState('');
  const [organizedResult, setOrganizedResult] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const injectedFile = useRef<File | null>(null);
  const saveBaseline = useRef(savedAt);
  const recorder = useRef<DiaryRecorder | null>(null);
  const transcript = useRef('');
  const alive = useRef(true);
  const operation = useRef(false);
  const callbacks = useRef({ onTranscript, onOrganized }); callbacks.current = { onTranscript, onOrganized };
  const supported = typeof MediaRecorder !== 'undefined' && typeof AudioContext !== 'undefined' && !!navigator.mediaDevices?.getUserMedia;
  useEffect(() => { onBusy(state !== 'idle'); }, [state, onBusy]);
  useEffect(() => {
    alive.current = true;
    registerStop(() => { recorder.current?.abort(); recorder.current = null; injectedFile.current = null; transcript.current = ''; setState('idle'); });
    void diaryVoiceRequest<Connection>({ action: 'status' }).then(c => {
      if (alive.current) { setConnection(c); setUrl(c.url); }
    }).catch(e => { if (alive.current) setMessage(e.message); });
    return () => { alive.current = false; recorder.current?.abort(); onBusy(false); };
  }, [registerStop, onBusy]);

  async function start() {
    if (operation.current) return;
    if (state === 'recording') { recorder.current?.pause(); setState('paused'); return; }
    if (!connection?.tokenConfigured) { setSettings(true); setMessage('먼저 본사가 발급한 음성 서비스 접근 코드를 연결 설정에 저장해 주세요.'); return; }
    operation.current = true; saveBaseline.current = savedAt; setState('starting'); setMessage('');
    setTrace([]); setRawResult(''); setOrganizedResult(''); setFileName('');
    const current = new DiaryRecorder(reason => {
      if (!alive.current) return;
      setState('paused');
      setMessage(reason === 'limit' ? '5분 분량을 녹음했습니다. 지금까지 내용으로 정리해 주세요.'
        : reason === 'device' ? '마이크 연결이 끊겼습니다. 지금까지 녹음은 보관되어 있습니다.' : '');
    }, value => { if (alive.current) setLevel(value); });
    recorder.current = current; transcript.current = '';
    try { await current.start(); if (alive.current) { setState('recording'); setMessage('듣고 있습니다. 말씀이 4.5초 멈추면 정리 여부를 여쭙습니다.'); } }
    catch (e) { if (alive.current) { setState('idle'); setMessage(e instanceof DOMException ? '마이크 사용 권한과 연결을 확인해 주세요. 입력된 본문은 유지됩니다.' : (e as Error).message || '마이크를 시작하지 못했습니다.'); } }
    finally { operation.current = false; }
  }
  async function organize() {
    if (operation.current || (!recorder.current && !injectedFile.current)) return;
    operation.current = true; setState('processing');
    try {
      if (!transcript.current) {
        setMessage('누적된 녹음 전체를 전사하고 있습니다...');
        const audio = injectedFile.current || await recorder.current!.finish();
        setTrace(t => [...t, '② 전사 시작: 원본 녹음 전체를 WAV로 변환해 전송합니다.']);
        const data = await recordingBase64(audio);
        if (!alive.current) return;
        const result = await diaryVoiceRequest<{ text: string }>({ action: 'transcribe', audio_base64: data });
        if (!alive.current) return;
        transcript.current = result.text;
        setRawResult(result.text);
        setTrace(t => [...t, `② 전사 완료: ${result.text.length.toLocaleString('ko-KR')}자. 원문은 별도로 보존합니다.`]);
        callbacks.current.onTranscript(result.text);
      }
      setMessage('매장 수정 사전을 참고해 일기 문장을 정리하고 있습니다...');
      const result = await diaryVoiceRequest<{ text: string }>({ action: 'organize', raw_text: transcript.current });
      if (!alive.current) return;
      callbacks.current.onOrganized(result.text);
      setOrganizedResult(result.text);
      setTrace(t => [...t, '③ AI 문장 정리 완료. [내용 수정] 후 저장하여 교정 기록을 확인하세요.']);
      recorder.current?.abort(); recorder.current = null; transcript.current = '';
      injectedFile.current = null;
      setState('idle'); setMessage('AI 문장을 넣었습니다. [내용 수정]으로 확인한 뒤 [일기 저장]을 누르세요.');
    } catch (e) {
      if (alive.current) { setState('paused'); setMessage(`${e instanceof DOMException ? '음성을 읽지 못했습니다. 지원되는 M4A·WAV·MP3 파일인지 확인해 주세요.' : (e as Error).message} 녹음·전사 원문은 창을 닫기 전까지 보관됩니다.`); }
    } finally { operation.current = false; }
  }
  function resume() {
    if (injectedFile.current) {
      setTrace(t => [...t, '침묵 모사 → 이어 말하기: 불러온 원본 파일 전체를 그대로 유지했습니다.']);
      setState('file-ready'); setMessage('파일 주입 검증입니다. 실제 마이크 녹음을 재개한 것은 아니며 원본 파일 전체가 유지됩니다.'); return;
    }
    try { recorder.current?.resume(); setState('recording'); setMessage('앞선 녹음을 유지한 채 이어 듣고 있습니다.'); }
    catch (e) { setMessage((e as Error).message); }
  }
  function loadFile(file: File | undefined) {
    if (!file) return;
    if (file.size > 20 * 1024 * 1024 || !file.size) { setMessage('음성 파일은 20MB 이하로 선택해 주세요.'); return; }
    recorder.current?.abort(); recorder.current = null;
    injectedFile.current = file; transcript.current = ''; saveBaseline.current = savedAt;
    setFileName(file.name); setRawResult(''); setOrganizedResult('');
    setTrace([`① 원본 파일 주입: ${file.name} (${file.size.toLocaleString('ko-KR')}바이트). 구간 절단·요약 없이 전체를 처리합니다.`]);
    setState('file-ready'); setMessage('전체 파일 전사·정리를 누르세요. 4.5초 침묵의 상태 전환은 별도 모사 버튼으로 확인할 수 있습니다.');
  }
  function simulateSilence() {
    const detector = new SilenceDetector(0);
    const before = detector.update(0, 4499), after = detector.update(0, 4500);
    if (!before && after) {
      setTrace(t => [...t, '4.5초 침묵 모사: 4,499ms에는 유지, 4,500ms에는 일시 정지. 실제 파일의 무음 분석과는 별도 상태 검사입니다.']);
      setState('paused'); setMessage('음성 파일 입력 경로의 침묵 상태 전환을 모사 중입니다. 원본 음성은 자르지 않았습니다.');
    }
  }
  async function saveConnection() {
    setConfigBusy(true);
    try {
      const c = await diaryVoiceRequest<Connection>({ action: 'configure', url, ...(token ? { token } : {}) });
      if (!alive.current) return;
      setConnection(c); setUrl(c.url); setToken(''); setMessage('연결 설정을 보안 저장했습니다. AI 공급자 비밀키는 서버에만 있습니다.'); setSettings(false);
    } catch (e) { if (alive.current) setMessage((e as Error).message); }
    finally { if (alive.current) setConfigBusy(false); }
  }
  return <section className="dv-controls" aria-label="말로 기록하기">
    <div className="dv-actions">
      <button type="button" className="ldy-btn ldy-mic" disabled={!supported || disabled || ['starting', 'processing', 'paused', 'file-ready'].includes(state)}
        onClick={() => void start()} data-testid="button-diary-voice">
        {state === 'starting' ? '마이크 준비 중' : state === 'recording' ? '말하기 마침 · 정리 선택' : state === 'processing' ? '음성 정리 중' : '말로 기록하기'}
      </button>
      <button type="button" className="ldy-btn" disabled={state !== 'idle' || configBusy} onClick={() => setSettings(v => !v)}>음성 서버 연결 설정</button>
      <button type="button" className="ldy-btn" disabled={disabled || !['idle', 'file-ready'].includes(state)} onClick={() => fileInput.current?.click()} data-testid="button-diary-audio-file">음성 파일 불러와 검증</button>
      <input ref={fileInput} type="file" accept="audio/*,.m4a,.mp3,.wav,.webm" hidden data-testid="input-diary-audio-file" onChange={e => { loadFile(e.target.files?.[0]); e.target.value = ''; }} />
    </div>
    {state === 'file-ready' && <div className="dv-actions">
      <button type="button" className="ldy-btn is-primary" onClick={() => void organize()} data-testid="button-diary-file-organize">불러온 전체 파일 전사·정리</button>
      <button type="button" className="ldy-btn" onClick={simulateSilence} data-testid="button-diary-simulate-silence">4.5초 침묵 흐름 모사</button>
      <button type="button" className="ldy-btn" onClick={() => { injectedFile.current = null; setState('idle'); setMessage('파일 입력을 취소했습니다. 입력된 본문은 유지합니다.'); }}>파일 입력 취소</button>
    </div>}
    {trace.length > 0 && <details className="dv-verification" open data-testid="diary-voice-verification">
      <summary>음성 검증 단계별 결과 {fileName && `· ${fileName}`}</summary>
      <ol>{trace.map((line, i) => <li key={i}>{line}</li>)}</ol>
      {rawResult && <details><summary>전사 원문 전체</summary><pre>{rawResult}</pre></details>}
      {organizedResult && <details><summary>AI 정리 결과 전체</summary><pre>{organizedResult}</pre></details>}
      {savedAt && organizedResult && savedAt !== saveBaseline.current && <p>④ SQLite 저장 확인: {savedAt}. AI 원본과 최종 수정본은 교정 이력에 함께 보존됩니다.</p>}
    </details>}
    {state === 'recording' && <div className="dv-meter" role="meter" aria-label="현재 말소리 크기" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(level * 100)}><span style={{ width: `${level * 100}%` }} /></div>}
    <p className="dv-note">정리를 선택하면 녹음이 음성 서버로 전송됩니다. 이름·전화번호 등 개인정보는 말하지 마세요. 네트워크가 없어도 직접 입력·로컬 저장은 가능합니다.</p>
    {message && <p className="ldy-msg" role="status" data-testid="text-diary-voice">{message}</p>}
    {settings && <fieldset className="dv-connection">
      <legend>본사 음성 서비스 연결 (최초 1회)</legend>
      <p>OpenAI API 키를 입력하는 칸이 아닙니다. 본사에서 발급한 서비스 접근 코드만 입력하세요.</p>
      <label>게시된 서버 주소<input type="url" className="ldy-input" value={url} disabled={connection?.urlOverridden} onChange={e => setUrl(e.target.value)} /></label>
      <label>음성 서비스 접근 코드<input type="password" autoComplete="off" className="ldy-input" value={token} disabled={connection?.tokenOverridden} onChange={e => setToken(e.target.value)}
        placeholder={connection?.tokenConfigured ? '저장되어 있음 · 바꿀 때만 입력' : '본사 발급 접근 코드 (24자 이상)'} /></label>
      <button type="button" className="ldy-btn is-primary" disabled={configBusy} onClick={() => void saveConnection()}>연결 설정 보안 저장</button>
    </fieldset>}
    {(state === 'paused' || state === 'processing') && <div className="ldy-sheet dv-sheet" role="alertdialog" aria-modal="true" aria-labelledby="dv-silence-title" data-testid="dialog-diary-silence">
      <div className="ldy-sheet-card">
        <h3 id="dv-silence-title">말씀이 잠시 멈췄습니다. 지금까지 말씀하신 내용으로 정리할까요?</h3>
        {message && <p className="ldy-msg" role="status">{message}</p>}
        <div className="dv-choices">
          <button type="button" className="ldy-btn is-primary ldy-big" disabled={state === 'processing'} onClick={() => void organize()} data-testid="button-diary-organize">네, 이대로 정리하기</button>
          <button type="button" className="ldy-btn ldy-big" disabled={state === 'processing'} onClick={resume} data-testid="button-diary-resume">이어서 더 말하기</button>
        </div>
        <button type="button" className="ldy-btn" disabled={state === 'processing'} onClick={() => { recorder.current?.abort(); recorder.current = null; injectedFile.current = null; transcript.current = ''; setState('idle'); setMessage('녹음을 취소했습니다. 이미 입력된 본문과 전사 원문은 유지했습니다.'); }}>녹음 취소 (입력된 본문 유지)</button>
      </div>
    </div>}
  </section>;
}
