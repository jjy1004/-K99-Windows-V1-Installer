import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ArrowRight, BookOpen, ChevronLeft, ShieldAlert, X } from 'lucide-react';
import { GUIDE_THEMES, OPEN_GUIDE_EVENT, type GuideCard } from './guide-data';
import { CaptureMissing, CaptureView, useCapture } from './GuideCapture';
import { IriunDownloads } from './IriunUsbGuide';
import { OriginalGuideImage, OriginalGuideImages } from './OriginalGuideImages';
import { GUIDE_USB_NOTICE } from './original-guide-images';
import './picture-guide.css';

/** 원본 사진이 없는 조작은 가짜 화면을 그리지 않고 정확한 글 안내만 표시한다. */
export function GuideScene({ card }: { card: GuideCard }) {
  return <div className="pg-no-image"><strong>{card.title}</strong><p>{card.body}</p><small>이 단계의 실제 화면 사진은 아직 제공되지 않았습니다.</small></div>;
}

function CardArt({ card }: { card: GuideCard }) {
  const cap = useCapture(card.captureId);
  const [failed, setFailed] = useState(false);
  if (card.aiProgramImage !== undefined) return <OriginalGuideImage key={`ai-program-${card.aiProgramImage}`} index={card.aiProgramImage} kind="ai-program" />;
  if (card.originalImage !== undefined) return <OriginalGuideImage key={card.originalImage} index={card.originalImage} />;
  if (card.iriunDownloads) return <IriunDownloads />;
  if (card.captureId && cap.state === 'loading') return <div className="pg-shot-skel" aria-label="실제 화면 불러오는 중" />;
  if (card.captureId && cap.state === 'ready' && cap.entry && !failed)
    return <CaptureView entry={cap.entry} targetKeys={card.targetKeys ?? []} label={card.title} onFail={() => setFailed(true)} />;
  return <>{card.captureId && <CaptureMissing />}<GuideScene card={card} /></>;
}

export function PictureGuide({ initialTheme, initialTopic, onClose }: { initialTheme?: string; initialTopic?: string; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [themeId, setThemeId] = useState<string | undefined>(initialTheme);
  const [topicId, setTopicId] = useState<string | undefined>(initialTopic);
  const [index, setIndex] = useState(0);
  const [originals, setOriginals] = useState<false | 'camera' | 'ai-program'>(!initialTheme ? 'camera' : false);
  useEffect(() => { ref.current?.focus(); }, []);
  const theme = GUIDE_THEMES.find(t => t.id === themeId);
  const topic = theme?.topics.find(t => t.id === topicId) ?? (theme && theme.topics.length === 1 && topicId === undefined ? theme.topics[0] : undefined);
  const card = topic?.cards[index];
  const back = () => { setIndex(0); if (topic && theme && theme.topics.length > 1) setTopicId(undefined); else { setTopicId(undefined); setThemeId(undefined); } };
  const onKey = (e: KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape') onClose();
    if (!originals && topic && e.key === 'ArrowRight') setIndex(i => Math.min(topic.cards.length - 1, i + 1));
    if (!originals && topic && e.key === 'ArrowLeft') setIndex(i => Math.max(0, i - 1));
  };
  return createPortal(
    <div className="pg-backdrop" onKeyDown={onKey} onKeyUp={e => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className="pg-modal" role="dialog" aria-modal="true" aria-label="그림 설명서">
        <header className="pg-head">
          {originals ? <button type="button" className="pg-back" onClick={() => setOriginals(false)}><ChevronLeft aria-hidden />주제별 설명서</button>
            : theme ? <button type="button" className="pg-back" onClick={back} data-testid="button-guide-back"><ChevronLeft aria-hidden />뒤로가기</button>
            : <span className="pg-title"><BookOpen aria-hidden />그림 설명서</span>}
          <strong className="pg-crumb">{originals ? '첨부한 실제 안내 이미지 원본' : topic ? topic.title : theme ? theme.title : '주제를 고르세요'}</strong>
          <button type="button" className="pg-close" onClick={onClose} data-testid="button-guide-close"><X aria-hidden />닫기</button>
        </header>
        <button type="button" className="pg-original-entry" onClick={() => { setOriginals('ai-program'); setIndex(0); }}>K99 AI 세탁 처방 프로그램 · 휴대폰 설치 · 홈 화면 · 선택 검색 · 케미컬 주문 안내</button>
        {originals ? <div className="pg-original-gallery"><OriginalGuideImages key={originals} kind={originals} /></div> : <>
          <button type="button" className="pg-original-entry" onClick={() => setOriginals('camera')}>촬영용 휴대폰 USB 안내 이미지 크게 보기</button>
          {!theme && <div className="pg-themes">
            {GUIDE_THEMES.map((t, i) => <button key={t.id} type="button" className={`pg-theme pg-theme-${i + 1}`} data-testid={`button-guide-theme-${t.id}`}
              onClick={() => { setThemeId(t.id); setTopicId(t.topics.length === 1 ? t.topics[0].id : undefined); setIndex(0); }}>
              <span className="pg-num">{i + 1}</span><b aria-label={t.title}>{t.titleLines.map((l, k) => <span key={k} className="pg-line">{l}</span>)}</b><small aria-label={t.summary}>{t.summaryLines.map((l, k) => <span key={k} className="pg-line">{l}</span>)}</small>
            </button>)}
          </div>}
          {theme && !topic && <div className="pg-topics">
            {theme.topics.map(t => <button key={t.id} type="button" className="pg-topic" data-testid={`button-guide-topic-${t.id}`}
              onClick={() => { setTopicId(t.id); setIndex(0); }}><b>{t.title}</b><small>안내 {t.cards.length}장</small></button>)}
          </div>}
          {topic && card && <article className="pg-card" key={`${topic.id}-${index}`}>
            <div className="pg-art"><CardArt card={card} /></div>
            <div className="pg-text">
              <span className="pg-step" data-testid="text-guide-progress">{index + 1} / {topic.cards.length}</span>
              <h3>{card.title}</h3><p>{card.body}</p>
              {card.warn && <p className="pg-warn"><ShieldAlert aria-hidden />권한·보안 창은 내용을 읽고 우리 매장 기기일 때만 허용하세요.</p>}
              <p className="pg-note">{card.originalImage !== undefined || card.aiProgramImage !== undefined ? '첨부한 원본 이미지입니다. 초기 비밀번호 안내와 이미 변경한 본인 비밀번호를 구분해 주세요.' : card.captureId ? '사진 위 빨간 번호 순서대로 누르세요. 사진을 불러오지 못하면 글 안내를 확인해 주세요.' : '실제 화면 사진이 없는 단계는 글로 안내합니다. 기종마다 메뉴 이름과 위치가 다릅니다.'}</p>
              {card.originalImage !== undefined && <p className="ogi-usb-notice">{GUIDE_USB_NOTICE}</p>}
            </div>
          </article>}
          {topic && card && <nav className="pg-nav">
            <button type="button" className="pg-prev" disabled={index === 0} onClick={() => setIndex(i => i - 1)} data-testid="button-guide-prev"><ArrowLeft aria-hidden />이전 그림</button>
            <div className="pg-dots" aria-hidden>{topic.cards.map((_, i) => <i key={i} data-on={i === index} />)}</div>
            {index < topic.cards.length - 1
              ? <button type="button" className="pg-next" onClick={() => setIndex(i => i + 1)} data-testid="button-guide-next">다음 그림<ArrowRight aria-hidden /></button>
              : <button type="button" className="pg-next" onClick={back} data-testid="button-guide-done">다 봤어요</button>}
          </nav>}
        </>}
      </div>
    </div>, document.body);
}

/** 전역 이벤트(openGuide)로 열리는 설명서 호스트 */
export function PictureGuideHost() {
  const [open, setOpen] = useState<{ theme?: string; topic?: string; key: number } | null>(null);
  useEffect(() => {
    const h = (e: Event) => { const d = (e as CustomEvent<{ theme?: string; topic?: string }>).detail || {}; setOpen({ ...d, key: Date.now() }); };
    window.addEventListener(OPEN_GUIDE_EVENT, h);
    return () => window.removeEventListener(OPEN_GUIDE_EVENT, h);
  }, []);
  return open ? <PictureGuide key={open.key} initialTheme={open.theme} initialTopic={open.topic} onClose={() => setOpen(null)} /> : null;
}

export default PictureGuide;
