import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ArrowRight, BookOpen, ChevronLeft, RotateCw, X } from 'lucide-react';
import { OPEN_GUIDE_EVENT, RECEPTION_HELP, guideImageUrl } from './guide-data';
import './picture-guide.css';

const FOCUSABLE = 'button:not([disabled]), [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';

export function PictureGuide(props: { initialTheme?: string; initialTopic?: string; onClose: () => void }) {
  const { onClose } = props;
  const ref = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [entryIdx, setEntryIdx] = useState<number | null>(null);
  const [page, setPage] = useState(0);
  const [fit, setFit] = useState(true);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [retry, setRetry] = useState(0);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    return () => { if (prev && typeof prev.focus === 'function') prev.focus(); };
  }, []);

  const entry = entryIdx === null ? undefined : RECEPTION_HELP[entryIdx];
  const current = entry?.pages[page];
  const total = entry?.pages.length ?? 0;

  useEffect(() => {
    setStatus('loading');
    if (scrollRef.current) { scrollRef.current.scrollTop = 0; scrollRef.current.scrollLeft = 0; }
  }, [entryIdx, page, retry]);

  const open = (i: number) => { setEntryIdx(i); setPage(0); setFit(true); setRetry(0); };
  const toIndex = () => { setEntryIdx(null); setPage(0); };
  const go = (d: number) => setPage(p => Math.min(total - 1, Math.max(0, p + d)));

  const onKey = (e: KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); onCloseRef.current(); return; }
    if (entry && e.key === 'ArrowRight') { e.preventDefault(); go(1); }
    if (entry && e.key === 'ArrowLeft') { e.preventDefault(); go(-1); }
    if (e.key === 'Tab' && ref.current) {
      const els = Array.from(ref.current.querySelectorAll<HTMLElement>(FOCUSABLE));
      if (!els.length) { e.preventDefault(); return; }
      const first = els[0], last = els[els.length - 1];
      const a = document.activeElement;
      if (e.shiftKey && (a === first || a === ref.current)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && a === last) { e.preventDefault(); first.focus(); }
    }
  };

  const src = current ? guideImageUrl(current) + (retry ? `?r=${retry}` : '') : '';

  return createPortal(
    <div className="pg-backdrop" onKeyDown={onKey} onKeyUp={e => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className="pg-modal" role="dialog" aria-modal="true" aria-label="접수 도움말">
        <header className="pg-head">
          {entry ? <button type="button" className="pg-back" onClick={toIndex} data-testid="button-guide-back"><ChevronLeft aria-hidden />목차</button>
            : <span className="pg-title"><BookOpen aria-hidden />접수 도움말</span>}
          <strong className="pg-crumb" data-testid="text-guide-title">{entry ? entry.name : '보실 안내를 고르세요'}</strong>
          <button type="button" className="pg-close" onClick={onClose} data-testid="button-guide-close"><X aria-hidden />닫기</button>
        </header>

        {!entry && <ol className="pg-index">
          {RECEPTION_HELP.map((en, i) => <li key={en.path}>
            <button type="button" className="pg-entry" onClick={() => open(i)} data-testid={`button-guide-entry-${i}`}>
              <span className="pg-num">{i + 1}</span>
              <b>{en.name}</b>
              <small>{en.kind === 'folder' ? `그림 ${en.pages.length}장` : '그림 1장'}</small>
            </button>
          </li>)}
        </ol>}

        {entry && current && <>
          <div className="pg-toolbar">
            <span className="pg-file" data-testid="text-guide-file">{current.name}</span>
            <span className="pg-step" data-testid="text-guide-progress">{page + 1} / {total}</span>
            <button type="button" className="pg-zoom" aria-pressed={!fit} onClick={() => setFit(f => !f)} data-testid="button-guide-zoom">
              {fit ? '원래 크기로 크게 보기' : '창에 맞추기'}
            </button>
          </div>
          <div ref={scrollRef} className={`pg-viewer ${fit ? 'is-fit' : 'is-full'}`} data-testid="area-guide-image">
            {status === 'loading' && <div className="pg-loading" role="status">그림을 불러오는 중입니다…</div>}
            {status === 'error' ? <div className="pg-error" role="alert">
              <p>그림을 불러오지 못했습니다.<br /><span>{current.name}</span></p>
              <button type="button" className="pg-retry" onClick={() => setRetry(r => r + 1)} data-testid="button-guide-retry"><RotateCw aria-hidden />다시 불러오기</button>
            </div> : <img key={src} src={src} alt={current.name} width={current.width} height={current.height}
              className={status === 'ready' ? '' : 'is-hidden'}
              onLoad={() => setStatus('ready')} onError={() => setStatus('error')} draggable={false} />}
          </div>
          <nav className="pg-nav">
            <button type="button" className="pg-prev" disabled={page === 0} onClick={() => go(-1)} data-testid="button-guide-prev"><ArrowLeft aria-hidden />이전 장</button>
            <span className="pg-count">{page + 1} / {total} 장</span>
            <button type="button" className="pg-next" disabled={page >= total - 1} onClick={() => go(1)} data-testid="button-guide-next">다음 장<ArrowRight aria-hidden /></button>
          </nav>
        </>}
      </div>
    </div>, document.body);
}

/** 전역 이벤트(openGuide)로 열리는 설명서 호스트. 구버전 진입값은 새 목차로 연다. */
export function PictureGuideHost() {
  const [open, setOpen] = useState<{ theme?: string; topic?: string; key: number } | null>(null);
  useEffect(() => {
    const h = (e: Event) => { const d = (e as CustomEvent<{ theme?: string; topic?: string }>).detail || {}; setOpen({ ...d, key: Date.now() }); };
    window.addEventListener(OPEN_GUIDE_EVENT, h);
    return () => window.removeEventListener(OPEN_GUIDE_EVENT, h);
  }, []);
  return open ? <PictureGuide key={open.key} initialTheme={open.theme} initialTopic={open.topic} onClose={() => setOpen(null)} /> : null;
}

export default PictureGuide;
