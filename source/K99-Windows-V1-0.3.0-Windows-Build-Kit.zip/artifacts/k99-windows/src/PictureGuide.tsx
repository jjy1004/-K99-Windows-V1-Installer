import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ArrowRight, BookOpen, ChevronLeft, PencilRuler, ShieldAlert, X } from 'lucide-react';
import { GUIDE_THEMES, OPEN_GUIDE_EVENT, type GuideCard } from './guide-data';
import { PhoneGuideScene } from './PhoneGuideScene';
import { CaptureMissing, CaptureView, useCapture } from './GuideCapture';
import { IriunDownloads } from './IriunUsbGuide';
import './picture-guide.css';

/** 실제로 그린 PC·휴대폰 화면 + 빨간 손가락 표식 */
export function GuideScene({ card }: { card: GuideCard }) {
  if (card.device === 'phone' && card.phoneScene) return <PhoneGuideScene card={card} />;
  const phone = card.device === 'phone';
  const sx = phone ? 190 : 60, sy = phone ? 20 : 30, sw = phone ? 220 : 480, sh = phone ? 380 : 290;
  const top = sy + (phone ? 46 : 40), rowH = Math.min(phone ? 62 : 52, (sh - (phone ? 80 : 70)) / Math.max(card.rows.length, 1));
  const hitY = card.hit >= 0 ? top + card.hit * rowH + rowH / 2 : sy+20;
  const hitX = phone ? sx + sw / 2 + 40 : sx + sw / 2 + 120;
  return (
    <svg viewBox={phone?'100 0 400 420':'0 0 600 420'} className="pg-scene" role="img" aria-label={`그림: ${card.bar} 화면${card.hit >= 0 ? `, ${card.rows[card.hit]} 누르기` : ', 주소창 누르기'}`}>
      <rect x="0" y="0" width="600" height="420" rx="24" fill="#eef3ee" />
      {phone ? <>
        <rect x={sx - 12} y={sy - 10} width={sw + 24} height={sh + 22} rx="34" fill="#1d2b30" />
        <rect x={sx + sw / 2 - 30} y={sy - 2} width="60" height="8" rx="4" fill="#3a4b51" />
      </> : <>
        <rect x={sx - 14} y={sy - 14} width={sw + 28} height={sh + 28} rx="16" fill="#1d2b30" />
        <rect x="270" y={sy + sh + 14} width="60" height="44" fill="#3a4b51" />
        <rect x="210" y={sy + sh + 56} width="180" height="14" rx="7" fill="#1d2b30" />
      </>}
      <rect x={sx} y={sy} width={sw} height={sh} rx={phone ? 22 : 6} fill="#fbf8ef" />
      <rect x={sx} y={sy} width={sw} height={phone ? 38 : 32} rx={phone ? 22 : 6} fill={card.warn ? '#b6462f' : '#1f5c55'} />
      <text x={sx + 14} y={sy + (phone ? 26 : 22)} fontSize={20} fontWeight="700" fill="#fff8e6">{card.bar.length > (phone?17:30) ? `${card.bar.slice(0, phone?16:29)}…` : card.bar}</text>
      {card.rows.map((r, i) => {
        const y = top + i * rowH, hot = i === card.hit;
        return <g key={i}>
          <rect x={sx + 14} y={y + 4} width={sw - 28} height={rowH - 10} rx="10"
            fill={hot ? '#ffe3d6' : '#ffffff'} stroke={hot ? '#d4361f' : '#cfd8d0'} strokeWidth={hot ? 4 : 2} />
          {r === 'K99' && <image href={`${import.meta.env.BASE_URL}k99-ai-icon.png`} x={sx + 22} y={y + 7} width={rowH - 16} height={rowH - 16} />}
          <text x={sx + (r === 'K99' ? 80 : 28)} y={y + rowH / 2 + 6} fontSize={phone ? 22 : 24} fontWeight={hot ? 800 : 600} fill="#1d2b30"
            textLength={r.length*(phone?22:24)>(sw-56)?sw-56:undefined} lengthAdjust="spacingAndGlyphs">{r}</text>
        </g>;
      })}
      {<g className="pg-finger" transform={`translate(${hitX} ${hitY})`}>
        <circle r="26" fill="none" stroke="#d4361f" strokeWidth="5" opacity=".55" />
        <circle r="9" fill="#d4361f" />
        <path d="M6 12 L6 64 Q6 80 22 84 L48 84 Q62 82 64 66 L66 38 Q66 30 58 30 Q52 30 50 36 L50 28 Q50 20 42 20 Q36 20 34 26 L34 20 Q34 12 26 12 Q20 12 18 18 L18 12 Q18 2 12 2 Q6 2 6 12 Z"
          fill="#e5543a" stroke="#8a1f10" strokeWidth="3" />
      </g>}
      {card.warn && <g transform={`translate(${phone?115:30} 340)`}>
        <rect width="150" height="56" rx="12" fill="#b6462f" />
        <text x="18" y="36" fontSize="20" fontWeight="800" fill="#fff8e6">주의 확인</text>
      </g>}
    </svg>
  );
}

/** 실제 캡처 우선, 없거나 실패하면 '안내 그림'임을 밝히고 그림 표시 */
function CardArt({ card }: { card: GuideCard }) {
  const cap = useCapture(card.captureId);
  const [failed, setFailed] = useState(false);
  if (card.iriunDownloads) return <IriunDownloads />;
  if (card.captureId && cap.state === 'loading') return <div className="pg-shot-skel" aria-label="실제 화면 불러오는 중" />;
  if (card.captureId && cap.state === 'ready' && cap.entry && !failed)
    return <CaptureView entry={cap.entry} targetKeys={card.targetKeys ?? []} label={card.title} onFail={() => setFailed(true)} />;
  return <>
    {card.captureId && <CaptureMissing />}
    <div className="pg-diagram">
      <GuideScene card={card} />
      <span className="pg-badge pg-badge-diagram"><PencilRuler aria-hidden />{card.diagram ? '안내 도해 · 실제 기종에 따라 다름' : '안내 그림 · 실제 화면 아님'}</span>
    </div>
  </>;
}

export function PictureGuide({ initialTheme, initialTopic, onClose }: { initialTheme?: string; initialTopic?: string; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [themeId, setThemeId] = useState<string | undefined>(initialTheme);
  const [topicId, setTopicId] = useState<string | undefined>(initialTopic);
  const [index, setIndex] = useState(0);
  useEffect(() => { ref.current?.focus(); }, []);
  const theme = GUIDE_THEMES.find(t => t.id === themeId);
  const topic = theme?.topics.find(t => t.id === topicId) ?? (theme && theme.topics.length === 1 && topicId === undefined ? theme.topics[0] : undefined);
  const card = topic?.cards[index];
  const back = () => { setIndex(0); if (topic && theme && theme.topics.length > 1) setTopicId(undefined); else { setTopicId(undefined); setThemeId(undefined); } };
  const onKey = (e: KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape') onClose();
    if (topic && e.key === 'ArrowRight') setIndex(i => Math.min(topic.cards.length - 1, i + 1));
    if (topic && e.key === 'ArrowLeft') setIndex(i => Math.max(0, i - 1));
  };
  return createPortal(
    <div className="pg-backdrop" onKeyDown={onKey} onKeyUp={e => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className="pg-modal" role="dialog" aria-modal="true" aria-label="그림 설명서">
        <header className="pg-head">
          {theme ? <button type="button" className="pg-back" onClick={back} data-testid="button-guide-back"><ChevronLeft aria-hidden />뒤로가기</button>
            : <span className="pg-title"><BookOpen aria-hidden />그림 설명서</span>}
          <strong className="pg-crumb">{topic ? topic.title : theme ? theme.title : '주제를 고르세요'}</strong>
          <button type="button" className="pg-close" onClick={onClose} data-testid="button-guide-close"><X aria-hidden />닫기</button>
        </header>
        {!theme && <div className="pg-themes">
          {GUIDE_THEMES.map((t, i) => <button key={t.id} type="button" className={`pg-theme pg-theme-${i + 1}`} data-testid={`button-guide-theme-${t.id}`}
            onClick={() => { setThemeId(t.id); setTopicId(t.topics.length === 1 ? t.topics[0].id : undefined); setIndex(0); }}>
            <span className="pg-num">{i + 1}</span><b aria-label={t.title}>{t.titleLines.map((l, k) => <span key={k} className="pg-line">{l}</span>)}</b><small aria-label={t.summary}>{t.summaryLines.map((l, k) => <span key={k} className="pg-line">{l}</span>)}</small>
          </button>)}
        </div>}
        {theme && !topic && <div className="pg-topics">
          {theme.topics.map(t => <button key={t.id} type="button" className="pg-topic" data-testid={`button-guide-topic-${t.id}`}
            onClick={() => { setTopicId(t.id); setIndex(0); }}><b>{t.title}</b><small>그림 {t.cards.length}장</small></button>)}
        </div>}
        {topic && card && <article className="pg-card" key={`${topic.id}-${index}`}>
          <div className="pg-art"><CardArt card={card} /></div>
          <div className="pg-text">
            <span className="pg-step" data-testid="text-guide-progress">{index + 1} / {topic.cards.length}</span>
            <h3>{card.title}</h3>
            <p>{card.body}</p>
            {card.warn && <p className="pg-warn"><ShieldAlert aria-hidden />권한·보안 창은 내용을 읽고 우리 매장 기기일 때만 허용하세요.</p>}
            <p className="pg-note">{card.captureId ? '사진 위 빨간 번호 순서대로 누르세요. 사진을 불러오지 못하면 그림으로 대신 보여드립니다.' : '이 그림은 안내 도해입니다. 휴대폰·PC 브랜드와 기종마다 메뉴 이름과 위치가 다릅니다.'}</p>
          </div>
        </article>}
        {topic&&card&&<nav className="pg-nav">
            <button type="button" className="pg-prev" disabled={index === 0} onClick={() => setIndex(i => i - 1)} data-testid="button-guide-prev"><ArrowLeft aria-hidden />이전 그림</button>
            <div className="pg-dots" aria-hidden>{topic.cards.map((_, i) => <i key={i} data-on={i === index} />)}</div>
            {index < topic.cards.length - 1
              ? <button type="button" className="pg-next" onClick={() => setIndex(i => i + 1)} data-testid="button-guide-next">다음 그림<ArrowRight aria-hidden /></button>
              : <button type="button" className="pg-next" onClick={back} data-testid="button-guide-done">다 봤어요</button>}
          </nav>}
      </div>
    </div>, document.body);
}

/** 전역 이벤트(openGuide)로 열리는 설명서 호스트 */
export function PictureGuideHost() {
  const [open, setOpen] = useState<{ theme?: string; topic?: string; key: number } | null>(null);
  useEffect(() => {
    const h = (e: Event) => { const d = (e as CustomEvent<{ theme?: string; topic?: string }>).detail || {}; setOpen({ ...d, key: Date.now() }); };
    window.addEventListener(OPEN_GUIDE_EVENT, h);
    return () => window.removeEventListener(OPEN_GUIDE_EVENT, h);
  }, []);
  return open ? <PictureGuide key={open.key} initialTheme={open.theme} initialTopic={open.topic} onClose={() => setOpen(null)} /> : null;
}

export default PictureGuide;
