import type { GarmentRecord, GarmentTagData, PhotoBridgeTagJobStatus } from './garment-record';
import type { PhotoBridgeTagJob, PhotoBridgeTagMode, PhotoBridgeTagTemplate } from './passive-photo-client';
import { hasDevicePrintProof } from './passive-photo-client.ts';

export type PhotoBridgeTagJobSnapshot = {
  requestId: string;
  status: PhotoBridgeTagJobStatus;
  mode: 'DEV' | 'TEST' | 'STORE';
  jobId?: string;
  reason?: string;
  createdAt: string;
};

export type ConfirmedIntakePhoto = {
  requestId: string;
  status: 'saved' | 'simulated';
  timestamp: string;
  photoPath?: string;
};
export type PhotoBridgeAutoTagReservation = {
  garment: GarmentRecord;
  requestId?: string;
  created: boolean;
};

/** Only a current, non-unlinked intake-photo record is eligible for tag-job proof. */
export function currentIntakePhotoProof(garment: GarmentRecord): ConfirmedIntakePhoto | null {
  if (garment.photoStatus !== 'saved' && garment.photoStatus !== 'simulated') return null;
  const requestId = garment.captureRequestId;
  if (!requestId || garment.unlinkedPhotoIds?.includes(requestId)) return null;
  const photo = (garment.photoHistory ?? []).find((entry) =>
    entry.requestId === requestId && entry.garmentId === garment.garmentId && entry.role === 'intake' &&
    entry.status === garment.photoStatus);
  if (photo) {
    if (!photo.timestamp || !Number.isFinite(Date.parse(photo.timestamp))) return null;
    if (photo.status === 'saved' && (!photo.path || !photo.path.trim())) return null;
    return {
      requestId,
      status: photo.status,
      timestamp: photo.timestamp,
      ...(photo.status === 'saved' ? { photoPath: photo.path } : {}),
    };
  }
  const legacy = garment.beforePhoto;
  if (!legacy || legacy.requestId !== requestId || legacy.garmentId !== garment.garmentId ||
      legacy.role !== 'intake' || legacy.status !== garment.photoStatus || !legacy.timestamp ||
      !Number.isFinite(Date.parse(legacy.timestamp)) ||
      (legacy.status === 'saved' && (!legacy.path || !legacy.path.trim()))) return null;
  return {
    requestId,
    status: legacy.status,
    timestamp: legacy.timestamp,
    ...(legacy.status === 'saved' ? { photoPath: legacy.path } : {}),
  };
}

export function photoBridgeTagAutoRequest(
  garment: GarmentRecord,
): {
  requestId: string;
  alreadyPrinted: boolean;
  photo: ConfirmedIntakePhoto;
} | null {
  const photo = currentIntakePhotoProof(garment);
  if (!photo) return null;
  if (garment.photoBridgeAutoTagRequestId) {
    return { requestId: garment.photoBridgeAutoTagRequestId, alreadyPrinted: garment.tagStatus === 'printed', photo };
  }
  if (garment.tagStatus === 'printed') return null;
  if (garment.barcodeValue !== garment.garmentId) return null;
  return { requestId: '', alreadyPrinted: false, photo };
}

/** Persist this before sending the helper request; an existing ID is never reissued automatically. */
export function reserveFirstPhotoBridgeAutoTag(
  garment: GarmentRecord,
  requestId: string,
  mode: PhotoBridgeTagMode,
  createdAt: string,
): PhotoBridgeAutoTagReservation {
  const confirmedPhoto = currentIntakePhotoProof(garment);
  if (!confirmedPhoto) {
    throw new Error('연결이 확인된 접수 사진 이후에만 자동 태그 요청을 예약할 수 있습니다.');
  }
  if (mode === 'STORE' && (confirmedPhoto.status !== 'saved' ||
      !garment.photoBridgePhotoConfirmations?.some((confirmation) =>
        confirmation.photoRequestId === confirmedPhoto.requestId &&
        confirmation.mode === 'STORE' && confirmation.photoVerified))) {
    throw new Error('STORE 자동 태그 예약 전 Photo Bridge의 저장 사진 확인 증거가 필요합니다.');
  }
  const hadTestReservation = Boolean(garment.photoBridgeAutoTagRequestId &&
    (garment.photoBridgeAutoTagMode === 'DEV' || garment.photoBridgeAutoTagMode === 'TEST'));
  const replaceTestReservationWithStore = hadTestReservation && mode === 'STORE';
  const priorTestMode = garment.photoBridgeAutoTagMode === 'DEV' || garment.photoBridgeAutoTagMode === 'TEST'
    ? garment.photoBridgeAutoTagMode : undefined;
  if (garment.photoBridgeAutoTagRequestId && !replaceTestReservationWithStore) {
    return { garment, requestId: garment.photoBridgeAutoTagRequestId, created: false };
  }
  const baseGarment: GarmentRecord = replaceTestReservationWithStore
    ? {
        ...garment,
        photoBridgeDevTestAutoTagRequestId: garment.photoBridgeAutoTagRequestId,
        photoBridgeDevTestAutoTagStatus: garment.photoBridgeAutoTagStatus,
        photoBridgeDevTestAutoTagJobId: garment.photoBridgeAutoTagJobId,
        photoBridgeDevTestAutoTagMode: priorTestMode,
        photoBridgeDevTestAutoTagReason: garment.photoBridgeAutoTagReason,
        photoBridgeDevTestAutoTagCreatedAt: garment.photoBridgeAutoTagCreatedAt,
        photoBridgeAutoTagRequestId: undefined,
        photoBridgeAutoTagStatus: undefined,
        photoBridgeAutoTagJobId: undefined,
        photoBridgeAutoTagMode: undefined,
        photoBridgeAutoTagReason: undefined,
        photoBridgeAutoTagCreatedAt: undefined,
      }
    : garment;
  if (garment.tagStatus === 'printed') {
    return {
      garment: {
        ...baseGarment,
        photoBridgeAutoTagStatus: 'skipped',
        photoBridgeAutoTagMode: mode,
        photoBridgeAutoTagReason: '이미 인쇄됨으로 기록된 의류는 자동 중복 인쇄에서 제외했습니다.',
        photoBridgeAutoTagCreatedAt: createdAt,
      },
      created: false,
    };
  }
  if (garment.barcodeValue !== garment.garmentId || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(requestId)) {
    throw new Error('자동 태그 요청 ID 또는 garmentId 바코드가 올바르지 않습니다.');
  }
  return {
    garment: {
      ...baseGarment,
      photoBridgeAutoTagRequestId: requestId,
      photoBridgeAutoTagStatus: 'pending',
      photoBridgeAutoTagMode: mode,
      photoBridgeAutoTagCreatedAt: createdAt,
      photoBridgeAutoTagReason: undefined,
    },
    requestId,
    created: true,
  };
}

export function applyPhotoBridgeTagJobSnapshot(
  garment: GarmentRecord,
  job: PhotoBridgeTagJob,
  kind: 'auto' | 'reprint',
): GarmentRecord {
  if (job.orderId !== garment.orderId || job.garmentId !== garment.garmentId ||
      (job.barcodeValue !== undefined && job.barcodeValue !== garment.barcodeValue) ||
      (job.status === 'printed' ? !hasDevicePrintProof(job) : job.hardwareVerified !== false) || job.copies !== 1 ||
      job.automatic !== (kind === 'auto') ||
      (kind === 'auto' && job.requestId !== garment.photoBridgeAutoTagRequestId) ||
      (kind === 'reprint' && job.requestId !== garment.photoBridgeReprintRequestId)) {
    throw new Error('Photo Bridge 태그 작업이 현재 의류의 저장된 1장 요청과 일치하지 않습니다.');
  }
  if (kind === 'auto') {
    return {
      ...garment,
      photoBridgeAutoTagStatus: job.status,
      photoBridgeAutoTagJobId: job.jobId,
      photoBridgeAutoTagMode: job.mode,
      photoBridgeAutoTagReason: job.reason,
      photoBridgeAutoTagCreatedAt: garment.photoBridgeAutoTagCreatedAt ?? job.createdAt,
      ...(job.mode === 'STORE' && job.status === 'printed' ? { tagStatus: 'printed' as const } : {}),
    };
  }
  return {
    ...garment,
    photoBridgeReprintStatus: job.status,
    photoBridgeReprintJobId: job.jobId,
    photoBridgeReprintMode: job.mode,
    photoBridgeReprintReason: job.reason,
    photoBridgeReprintCreatedAt: garment.photoBridgeReprintCreatedAt ?? job.createdAt,
    ...(job.mode === 'STORE' && job.status === 'printed' ? { tagStatus: 'printed' as const } : {}),
  };
}

export function photoBridgeTagJobSnapshotMatches(
  garment: GarmentRecord,
  job: PhotoBridgeTagJob,
  kind: 'auto' | 'reprint',
): boolean {
  if (job.orderId !== garment.orderId || job.garmentId !== garment.garmentId ||
      (job.barcodeValue !== undefined && job.barcodeValue !== garment.barcodeValue))
    return false;
  return kind === 'auto'
    ? garment.photoBridgeAutoTagRequestId === job.requestId &&
      garment.photoBridgeAutoTagStatus === job.status &&
      garment.photoBridgeAutoTagJobId === job.jobId &&
      garment.photoBridgeAutoTagMode === job.mode &&
      garment.photoBridgeAutoTagReason === job.reason
    : garment.photoBridgeReprintRequestId === job.requestId &&
      garment.photoBridgeReprintStatus === job.status &&
      garment.photoBridgeReprintJobId === job.jobId &&
      garment.photoBridgeReprintMode === job.mode &&
      garment.photoBridgeReprintReason === job.reason;
}

/** Renders data only; each position, size, label and barcode kind remains file-owned. */
export function resolvePhotoBridgeTagElements(
  template: PhotoBridgeTagTemplate,
  tag: GarmentTagData,
): Array<{
  element: PhotoBridgeTagTemplate['elements'][number];
  value: string;
}> {
  if (tag.barcodeValue !== tag.garmentId) {
    throw new Error('태그 바코드 값은 현재 garmentId와 같아야 합니다.');
  }
  return template.elements.map((element) => {
    if (element.type === 'text') {
      const value = element.field === 'serviceLabel'
        ? template.serviceLabels[tag.serviceType]
        : tag[element.field];
      if (typeof value !== 'string' || value.length > 240) {
        throw new Error('외부 태그 템플릿 필드를 안전하게 읽을 수 없습니다.');
      }
      return { element, value };
    }
    if (element.field !== 'barcodeValue') {
      throw new Error('태그 템플릿 코드는 garmentId 바코드 하나만 표시할 수 있습니다.');
    }
    return { element, value: tag.garmentId };
  });
}