import { useCallback, useEffect, useRef, useState } from 'react';
import { FolderOpen, MonitorPlay, RefreshCw } from 'lucide-react';
import { DEFAULT_GUIDE_SLOTS, type GuideVideosReply } from './guide-videos';
import './video-management.css';

export function VideoManagement() {
  const [guides, setGuides] = useState<GuideVideosReply>();
  const [idle, setIdle] = useState<{success:boolean; error?:string; files?:{name:string}[]}>();
  const [busy, setBusy] = useState(false), [message, setMessage] = useState('');
  const generation = useRef(0);
  const available = !!window.k99Desktop?.guideVideos && !!window.k99Desktop?.idleVideos;
  const refresh = useCallback(async (action:'list'|'refresh') => {
    const seq = ++generation.current;
    if (!window.k99Desktop?.guideVideos || !window.k99Desktop?.idleVideos) return;
    setBusy(true); setMessage('');
    const [g, i] = await Promise.allSettled([
      window.k99Desktop.guideVideos(action), window.k99Desktop.idleVideos(action),
    ]);
    if (seq !== generation.current) return;
    setGuides(g.status === 'fulfilled' ? g.value : {success:false,error:String(g.reason)});
    setIdle(i.status === 'fulfilled' ? i.value : {success:false,error:String(i.reason)});
    setBusy(false);
    if (action === 'refresh') setMessage('목록을 다시 확인했습니다. 아래 오류와 각 번호의 적용 상태를 확인해 주세요.');
  }, []);
  useEffect(() => { void refresh('list'); return () => { ++generation.current; }; }, [refresh]);
  const open = async (kind:'guide'|'idle') => {
    setMessage('');
    try {
      const reply = kind === 'guide' ? await window.k99Desktop?.guideVideos?.('open') : await window.k99Desktop?.idleVideos?.('open');
      if (!reply?.success) throw Error(reply?.error || 'Windows 설치 프로그램에서 열어 주세요.');
      setMessage(`${kind === 'guide' ? '1~4번 개별 안내' : '5번 대기 홍보'} 폴더를 열었습니다. 파일을 넣은 뒤 탐색기 창을 닫고 [영상 목록 새로고침]을 누르세요`);
    } catch (error) { setMessage(error instanceof Error ? error.message : '폴더를 열지 못했습니다.'); }
  };
  return <section className="video-management" data-testid="video-management">
    <h3>1~4번 안내 영상 · 5번 대기 홍보 영상</h3>
    <ol>
      <li><b>1~4번 개별 안내 영상 폴더</b>를 열고 바꿀 번호만 넣으세요.</li>
      <li><code>01_제목.mp4</code> ~ <code>04_제목.mp4</code> 형식으로 번호마다 파일 하나만 넣으세요. 예: <code>02_우리 매장 세탁과정.mp4</code></li>
      <li><b>영상 목록 새로고침</b>을 누르면 접수창과 고객 화면 제목에 번호·확장자를 뺀 제목이 반영됩니다. 없는 번호는 기본 영상·제목을 씁니다. 삭제 후 새로고침하면 기본값으로 돌아갑니다.</li>
      <li>5번은 기존 대기 홍보 폴더를 사용합니다. 1~4번 파일은 그 안의 별도 <b>개별 안내 영상</b> 폴더에만 넣으세요.</li>
    </ol>
    <p className="video-management__notice" style={{fontSize:20}} data-testid="text-video-refresh-notice"><b>파일을 넣은 뒤 탐색기 창을 닫고 [영상 목록 새로고침]을 누르세요</b></p>
    {!available && <p role="status">파일 관리는 매장 Windows 설치 프로그램에서 사용할 수 있습니다. 브라우저 미리보기에서는 기본 구성만 표시합니다.</p>}
    <div className="sh-actions">
      <button type="button" className="sh-btn ghost" disabled={!available || busy} onClick={() => void open('guide')} data-testid="button-guide-videos-folder"><FolderOpen aria-hidden/>1~4번 개별 교체 폴더</button>
      <button type="button" className="sh-btn ghost" disabled={!available || busy} onClick={() => void open('idle')} data-testid="button-idle-videos-folder"><FolderOpen aria-hidden/>5번 대기 홍보 폴더</button>
      <button type="button" className="sh-btn gold" disabled={!available || busy} onClick={() => void refresh('refresh')} data-testid="button-videos-refresh"><RefreshCw aria-hidden className={busy?'animate-spin':''}/>{busy?'확인 중…':'영상 목록 새로고침'}</button>
    </div>
    {message && <p role="status">{message}</p>}
    {(guides?.error || idle?.error || guides?.errors?.length) ? <div role="alert" className="video-management__error">
      {guides?.error && <p>1~4번 확인 실패: {guides.error}</p>}
      {idle?.error && <p>5번 확인 실패: {idle.error}</p>}
      {guides?.errors?.map(text => <p key={text}>{text}</p>)}
    </div> : null}
    <div className="video-management__scroll"><table data-testid="video-slots-table">
      <caption>현재 적용 상태 · 1~5번</caption>
      <thead><tr><th>번호</th><th>버튼 제목</th><th>영상 파일</th><th>적용 상태</th></tr></thead>
      <tbody>{(guides?.slots ?? DEFAULT_GUIDE_SLOTS).map(slot => <tr key={slot.number}>
        <th>{slot.number}</th><td>{slot.title}</td><td>{slot.name}</td>
        <td>{!available?'기본 구성 · PC 확인 필요':!guides?.slots?'확인 불가':slot.defaultAvailable===false?'오류 · 기본 영상 확인 불가':slot.error?'오류 · 기본 영상 사용':slot.source==='custom'?'사용자 영상 · 구조 확인':'기본 영상'}</td>
      </tr>)}
      <tr><th>5</th><td>대기 홍보 영상</td><td>{idle?.files?.map(file=>file.name).join(' / ') || 'promo.mp4'}</td>
        <td>{!available?'기본 구성 · PC 확인 필요':!idle?.success?'확인 불가':idle.files?.length?'사용자 홍보 목록':'기본 대기 홍보 영상'}</td></tr></tbody>
    </table></div>
    <div className="sh-actions">
      <button type="button" className="sh-btn ghost" disabled={!available || busy} onClick={() => void open('idle')} data-testid="button-idle-videos-howto"><MonitorPlay aria-hidden/>고객 화면에 홍보 영상 넣는 방법</button>
    </div>
    <p>파일 구조 확인은 실제 재생 검증과 다릅니다. 교체 후 고객 화면에서 끝까지 재생·소리·종료 후 영수증 복귀를 확인해 주세요. 재생 중 새로고침은 영상을 강제로 다시 시작하지 않습니다.</p>
  </section>;
}
