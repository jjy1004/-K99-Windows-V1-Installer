import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';

/** Presentation only: preserve workflow enums, audit history, and saved legacy records. */
export function orderHandedOver(order: ConfirmedOrder): boolean {
  return Boolean(order.operations?.completedAt ||
    ['매장수령완료', '배달완료'].includes(order.operations?.stage ?? '') ||
    (order.garments?.length && order.garments.every(g =>
      g.handoverStatus === 'complete' || g.processStatus === '반출 완료')));
}

export function orderDisplayStatus(order: ConfirmedOrder, fallback: string = order.status): string {
  return orderHandedOver(order) ? '인도 완료' : fallback;
}

export function garmentDisplayStatus(order: ConfirmedOrder, garment: GarmentRecord, fallback: string): string {
  return orderHandedOver(order) || garment.handoverStatus === 'complete' || garment.processStatus === '반출 완료'
    ? '인도 완료' : fallback;
}
