import type { ConfirmedOrder } from './order-record';

export type PaymentType = 'PREPAID' | 'POSTPAID';
export type PaymentState = 'PAID' | 'UNPAID';
type PaymentOrder = Partial<Pick<ConfirmedOrder, 'payment_type' | 'payment_status' | 'estimatedTotal' | 'operations'>>;
export function paymentInfo(order: PaymentOrder) {
  const type = order.payment_type ?? 'PREPAID';
  const status = order.operations?.paymentStatus === '환불' ? 'UNPAID'
    : order.operations?.paymentStatus === '결제완료' ? 'PAID'
    : order.payment_status ?? (type === 'POSTPAID' ? 'UNPAID' : 'PAID');
  return { type, status, due: status === 'UNPAID' ? Math.max(0, order.estimatedTotal || 0) : 0 };
}
export function paymentNotice(order: PaymentOrder): string {
  const info = paymentInfo(order);
  return info.type === 'PREPAID' ? '(선불 결제 완료 건으로 매장 방문 시 바로 수령 가능합니다.)'
    : info.status === 'PAID' ? '(후불 결제 완료 건)'
    : `(결제 예정 금액: ${info.due.toLocaleString('ko-KR')}원 / 수령 시 결제 부탁드립니다.)`;
}
export function PaymentBadge({ order }: { order: PaymentOrder }) {
  const info = paymentInfo(order);
  const unpaid = info.status === 'UNPAID';
  return <span style={{ display: 'inline-block', fontSize: 13, fontWeight: 800, borderRadius: 6,
    padding: '3px 7px', background: unpaid ? '#fff7ed' : '#dcfce7', color: unpaid ? '#9a3412' : '#166534',
    border: `1px solid ${unpaid ? '#f97316' : '#86efac'}` }}>
    {info.type === 'PREPAID' ? '선불 완료' : unpaid ? `후불 · 결제필요 ${info.due.toLocaleString('ko-KR')}원` : '후불 · 결제완료'}
  </span>;
}
