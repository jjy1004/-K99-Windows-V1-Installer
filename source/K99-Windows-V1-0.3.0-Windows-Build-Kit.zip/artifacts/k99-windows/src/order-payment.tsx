import type { ConfirmedOrder } from './order-record';

export type PaymentType = 'PREPAID' | 'POSTPAID';
export type PaymentState = 'PAID' | 'UNPAID';
type PaymentOrder = Partial<Pick<ConfirmedOrder, 'payment_type' | 'payment_status' | 'estimatedTotal' | 'operations' | 'voucher'>>;
export function paymentInfo(order: PaymentOrder) {
  const type = order.payment_type ?? 'PREPAID';
  const status = order.operations?.paymentStatus === '환불' ? 'UNPAID'
    : order.operations?.paymentStatus === '결제완료' ? 'PAID'
    : order.payment_status ?? (type === 'POSTPAID' ? 'UNPAID' : 'PAID');
  if (order.voucher) {
    // 정액권 주문: 세탁비는 잔액에서 차감됐고 부족 차액(shortfall)만 별도 결제 대상.
    const shortfall = Math.max(0, order.voucher.shortfall || 0);
    const vStatus: PaymentState = order.operations?.paymentStatus === '결제완료' ? 'PAID'
      : order.operations?.paymentStatus === '환불' ? 'UNPAID' : shortfall > 0 ? 'UNPAID' : 'PAID';
    return { type, status: vStatus, due: vStatus === 'UNPAID' ? shortfall : 0, voucherShortfall: true as const };
  }
  return { type, status, due: status === 'UNPAID' ? Math.max(0, order.estimatedTotal || 0) : 0 };
}
export function paymentNotice(order: PaymentOrder): string {
  const info = paymentInfo(order);
  if ('voucherShortfall' in info) return info.status === 'UNPAID'
    ? `(정액권 잔액 부족 차액: ${info.due.toLocaleString('ko-KR')}원 / 수령 시 결제 부탁드립니다.)`
    : '(정액권 차감 완료 건으로 매장 방문 시 바로 수령 가능합니다.)';
  return info.type === 'PREPAID' ? '(선불 결제 완료 건으로 매장 방문 시 바로 수령 가능합니다.)'
    : info.status === 'PAID' ? '(후불 결제 완료 건)'
    : `(결제 예정 금액: ${info.due.toLocaleString('ko-KR')}원 / 수령 시 결제 부탁드립니다.)`;
}
export function PaymentBadge({ order }: { order: PaymentOrder }) {
  const info = paymentInfo(order);
  const unpaid = info.status === 'UNPAID';
  if ('voucherShortfall' in info) return <span data-testid="badge-voucher-payment" style={{ display: 'inline-block', fontSize: 13, fontWeight: 800, borderRadius: 6,
    padding: '3px 7px', background: unpaid ? '#fff7ed' : '#fef3c7', color: unpaid ? '#9a3412' : '#7a5a12',
    border: `1px solid ${unpaid ? '#f97316' : '#c9a23f'}` }}>
    {unpaid ? `정액권 차액 · 결제필요 ${info.due.toLocaleString('ko-KR')}원` : '정액권 차감 완료'}
  </span>;
  return <span style={{ display: 'inline-block', fontSize: 13, fontWeight: 800, borderRadius: 6,
    padding: '3px 7px', background: unpaid ? '#fff7ed' : '#dcfce7', color: unpaid ? '#9a3412' : '#166534',
    border: `1px solid ${unpaid ? '#f97316' : '#86efac'}` }}>
    {info.type === 'PREPAID' ? '선불 완료' : unpaid ? `후불 · 결제필요 ${info.due.toLocaleString('ko-KR')}원` : '후불 · 결제완료'}
  </span>;
}
