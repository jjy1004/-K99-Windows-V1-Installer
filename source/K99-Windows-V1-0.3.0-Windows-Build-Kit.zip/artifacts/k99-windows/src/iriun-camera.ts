import {inspectCameraStream} from './camera-video';

export const iriunDevices=(all:readonly MediaDeviceInfo[])=>all.filter(d=>
  d.kind==='videoinput'&&/\biriun\b/i.test(d.label)&&!/\bobs\b|insta360/i.test(d.label));
const release=(stream:MediaStream)=>stream.getTracks().forEach(track=>track.stop());

/** Late streams are stopped even after close/abort; USB webcams never become the preview. */
export async function openIriunCamera(media:Pick<MediaDevices,'enumerateDevices'|'getUserMedia'>,signal:AbortSignal,
  inspect:(stream:MediaStream)=>Promise<void>=inspectCameraStream,timeoutMs=6000):Promise<MediaStream>{
  const request=(video:MediaTrackConstraints)=>new Promise<MediaStream>((resolve,reject)=>{
    let settled=false;
    const done=(error?:Error,stream?:MediaStream)=>{
      if(settled){if(stream)release(stream);return;}
      settled=true;clearTimeout(timer);signal.removeEventListener('abort',abort);
      if(error)reject(error);else resolve(stream!);
    };
    const abort=()=>done(new DOMException('촬영 창이 닫혔습니다.','AbortError'));
    const timer=setTimeout(()=>done(Object.assign(Error('Iriun 연결이 지연됩니다. 휴대폰 앱과 PC 수신기를 확인한 후 다시 연결하세요.'),{name:'CameraOpenTimeout'})),timeoutMs);
    if(signal.aborted){abort();return;}
    signal.addEventListener('abort',abort,{once:true});
    Promise.resolve().then(()=>{signal.throwIfAborted();return media.getUserMedia({audio:false,video});})
      .then(s=>done(undefined,s),e=>done(e instanceof Error?e:Error('카메라 연결 실패')));
  });
  let all=await media.enumerateDevices();signal.throwIfAborted();
  if(!iriunDevices(all).length&&all.some(d=>d.kind==='videoinput'&&!d.label)){
    const permission=await request({});
    const closePermission=()=>release(permission);
    signal.addEventListener('abort',closePermission,{once:true});
    try{signal.throwIfAborted();all=await media.enumerateDevices();}
    finally{signal.removeEventListener('abort',closePermission);release(permission);}
  }
  signal.throwIfAborted();
  const selected=iriunDevices(all)[0];
  if(!selected)throw Error('Iriun 카메라를 찾지 못했습니다. PC에 Iriun Webcam을 설치하고 휴대폰 앱을 켠 뒤 다시 연결하세요.');
  let last:unknown;
  for(const size of [true,false]){
    signal.throwIfAborted();
    let stream:MediaStream|undefined;
    try{
      stream=await request({deviceId:selected.deviceId,...(size?{width:{ideal:1920},height:{ideal:1080}}:{})});
      const track=stream.getVideoTracks()[0],actual=track?.getSettings().deviceId;
      if(!track||(actual&&actual!==selected.deviceId)||(track.label&&!/\biriun\b/i.test(track.label)))
        throw Error('Iriun 대신 다른 카메라가 반환되어 연결을 중단했습니다.');
      signal.throwIfAborted();
      let cancelDecode!:()=>void;
      const cancelled=new Promise<never>((_,reject)=>{
        cancelDecode=()=>{release(stream!);reject(new DOMException('촬영 창이 닫혔습니다.','AbortError'));};
        signal.addEventListener('abort',cancelDecode,{once:true});
      });
      try{await Promise.race([inspect(stream),cancelled]);signal.throwIfAborted();return stream;}
      finally{signal.removeEventListener('abort',cancelDecode);}
    }catch(error){
      if(stream)release(stream);last=error;
      if(signal.aborted||['NotAllowedError','SecurityError','CameraOpenTimeout'].includes((error as Error)?.name))throw error;
    }
  }
  throw last;
}
export function iriunFailure(error:unknown){
  const name=error instanceof Error?error.name:'';
  const detail:Record<string,string>={
    NotAllowedError:'Windows 카메라 개인정보 설정에서 K99 앱 접근을 허용해 주세요.',
    SecurityError:'Windows 카메라 접근 권한을 확인해 주세요.',
    NotReadableError:'휴대폰 Iriun 앱과 PC 수신기를 켜고, 다른 앱이 카메라를 사용 중인지 확인해 주세요.',
    NotFoundError:'PC에 Iriun Webcam을 설치하고 휴대폰 앱을 켠 뒤 다시 연결해 주세요.',
  };
  return `Iriun 연결 실패 · ${detail[name]||(error instanceof Error?error.message:'휴대폰 앱과 PC 수신기를 확인해 주세요.')}`;
}
