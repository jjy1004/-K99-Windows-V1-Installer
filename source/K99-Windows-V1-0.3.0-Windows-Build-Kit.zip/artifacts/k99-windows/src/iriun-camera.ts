import {inspectCameraStream} from './camera-video';
import {isVirtualCamera} from './camera-device';

export const iriunDevices=(all:readonly MediaDeviceInfo[])=>all.filter(d=>
  d.kind==='videoinput'&&/\biriun\b/i.test(d.label)&&!/\bobs\b|insta360/i.test(d.label));
const release=(stream:MediaStream)=>stream.getTracks().forEach(track=>track.stop());

/** Iriun only. Old saved USB/virtual device IDs must never affect reception. */
export async function openIriunCamera(media:Pick<MediaDevices,'enumerateDevices'|'getUserMedia'>,signal:AbortSignal,
  inspect:(stream:MediaStream)=>Promise<void>=inspectCameraStream,timeoutMs=6000):Promise<MediaStream>{
  let last:unknown;
  for(let attempt=0;attempt<=5;attempt++){
    signal.throwIfAborted();
    try{return await openOnce();}
    catch(error){
      last=error;
      if(signal.aborted||['NotAllowedError','SecurityError','CameraOpenTimeout'].includes((error as Error)?.name))throw error;
      if(attempt===5)break;
      await new Promise<void>((resolve,reject)=>{
        const abort=()=>{clearTimeout(timer);reject(new DOMException('촬영 창이 닫혔습니다.','AbortError'));};
        const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},1000);
        signal.addEventListener('abort',abort,{once:true});
        if(signal.aborted)abort();
      });
    }
  }
  throw last;

  async function openOnce():Promise<MediaStream>{
  const request=(video:MediaTrackConstraints)=>new Promise<MediaStream>((resolve,reject)=>{
    let settled=false;
    const done=(error?:Error,stream?:MediaStream)=>{
      if(settled){if(stream)release(stream);return;}
      settled=true;clearTimeout(timer);signal.removeEventListener('abort',abort);
      if(error)reject(error);else resolve(stream!);
    };
    const abort=()=>done(new DOMException('촬영 창이 닫혔습니다.','AbortError'));
    const timer=setTimeout(()=>done(Object.assign(Error('Iriun 연결이 지연됩니다. 휴대폰 앱과 PC 수신기를 확인한 후 다시 연결하세요.'),{name:'CameraOpenTimeout'})),timeoutMs);
    if(signal.aborted){abort();return;}
    signal.addEventListener('abort',abort,{once:true});
    Promise.resolve().then(()=>{signal.throwIfAborted();return media.getUserMedia({audio:false,video});})
      .then(s=>done(undefined,s),e=>done(e instanceof Error?e:Error('카메라 연결 실패')));
  });
  const all=await new Promise<MediaDeviceInfo[]>((resolve,reject)=>{
    const abort=()=>reject(new DOMException('촬영 창이 닫혔습니다.','AbortError'));
    signal.addEventListener('abort',abort,{once:true});
    Promise.resolve().then(()=>{signal.throwIfAborted();return media.enumerateDevices();})
      .then(resolve,reject).finally(()=>signal.removeEventListener('abort',abort));
    if(signal.aborted)abort();
  });signal.throwIfAborted();
  signal.throwIfAborted();
  const selected=iriunDevices(all)[0];
  if(!selected)throw Error('Iriun Webcam을 찾는 중입니다. PC 수신기와 휴대폰의 Iriun 앱을 켜고 카메라 접근을 허용해 주세요.');
  let streamError:unknown;
  for(const size of [true,false]){
    signal.throwIfAborted();
    let stream:MediaStream|undefined;
    try{
      stream=await request({deviceId:selected.deviceId,...(size?{width:{ideal:1920},height:{ideal:1080}}:{})});
      const track=stream.getVideoTracks()[0],actual=track?.getSettings().deviceId;
      if(!track||(actual&&actual!==selected.deviceId)||(track.label&&!/\biriun\b/i.test(track.label))||(track.label&&
        (isVirtualCamera(track.label)||(!actual&&all.some(d=>d.deviceId!==selected.deviceId&&d.label===track.label)))))
        throw Error('선택한 장치와 다른 카메라가 반환되어 연결을 중단했습니다.');
      signal.throwIfAborted();
      let cancelDecode!:()=>void;
      const cancelled=new Promise<never>((_,reject)=>{
        cancelDecode=()=>{release(stream!);reject(new DOMException('촬영 창이 닫혔습니다.','AbortError'));};
        signal.addEventListener('abort',cancelDecode,{once:true});
      });
      try{await Promise.race([inspect(stream),cancelled]);signal.throwIfAborted();return stream;}
      finally{signal.removeEventListener('abort',cancelDecode);}
    }catch(error){
      if(stream)release(stream);streamError=error;
      if(signal.aborted||['NotAllowedError','SecurityError','CameraOpenTimeout'].includes((error as Error)?.name))throw error;
    }
  }
  throw streamError;
  }
}
export function iriunFailure(error:unknown){
  const name=error instanceof Error?error.name:'';
  const detail:Record<string,string>={
    NotAllowedError:'Windows 카메라 개인정보 설정에서 K99 앱 접근을 허용해 주세요.',
    SecurityError:'Windows 카메라 접근 권한을 확인해 주세요.',
    NotReadableError:'휴대폰 Iriun 앱과 PC 수신기를 켜고, 다른 앱이 카메라를 사용 중인지 확인해 주세요.',
    NotFoundError:'PC에 Iriun Webcam을 설치하고 휴대폰 앱을 켠 뒤 다시 연결해 주세요.',
  };
  return `Iriun 연결 실패 · ${detail[name]||(error instanceof Error?error.message:'휴대폰 앱과 PC 수신기를 확인해 주세요.')}`;
}
