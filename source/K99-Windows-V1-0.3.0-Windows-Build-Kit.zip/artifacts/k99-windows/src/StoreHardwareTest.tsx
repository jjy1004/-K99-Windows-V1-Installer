import { useEffect, useState } from 'react';
import { ArrowLeft, ClipboardCheck, Info, RotateCcw, ShieldAlert } from 'lucide-react';
import './store-hardware-test.css';
import { NumUnit } from './NumUnit';

export type StoreHardwareTestProps = { onBack: () => void; onOpenOrders?: () => void };

type TestStatus = '미검증' | '테스트 중' | '성공' | '실패' | '재확인 필요';
type TestEntry = {
  status: TestStatus;
  statusUpdatedAt: string | null;
  note: string;
  noteUpdatedAt: string | null;
};
type StoredChecklist = { version: 1; items: Record<string, TestEntry> };
type LoadResult = { records: StoredChecklist; error: string; malformed: boolean };

const STORAGE_KEY = 'k99:store-hardware-test:v1';
const STATUSES: readonly TestStatus[] = ['미검증', '테스트 중', '성공', '실패', '재확인 필요'];
const ITEMS = [
  { id: 'windows-local-bridge', title: 'Windows Local Bridge', hint: '매장 PC의 로컬 브리지 응답을 직원이 확인' },
  { id: 'camera', title: 'Camera', hint: '카메라 연결과 화면을 직원이 확인' },
  { id: 'foot-switch', title: 'Foot switch', hint: '발판 스위치 입력 반응을 직원이 확인' },
  { id: 'intake-photo-capture', title: 'Intake photo capture', hint: '접수 사진 촬영 결과를 직원이 확인' },
  { id: 'windows-photo-storage', title: 'Windows 사진 저장 위치', hint: '관리자 설정의 사진 저장 위치와 실제 파일을 직원이 확인' },
  { id: 'tsc-te210-connection', title: 'TSC TE210 connection', hint: '프린터 연결 상태를 직원이 확인' },
  { id: 'test-tag-print', title: 'Test tag print', hint: '테스트 태그 출력물을 직원이 확인' },
  { id: 'automatic-tag-print', title: 'Automatic tag print', hint: '자동 태그 출력 흐름을 직원이 확인' },
  { id: 'barcode-scanner', title: 'Barcode scanner', hint: '스캐너 입력을 직원이 확인' },
  { id: 'barcode-exact-garment-lookup', title: 'Barcode → exact garment lookup', hint: '스캔 결과가 해당 의류 한 점과 일치하는지 확인' },
  { id: 'completion-photo', title: 'Completion photo', hint: '완성 사진 촬영 결과를 직원이 확인' },
  { id: 'before-after-photo-linkage', title: 'Before/after photo linkage', hint: '세탁 전후 사진이 같은 의류에 연결되는지 확인' },
] as const;

const emptyEntry = (): TestEntry => ({
  status: '미검증', statusUpdatedAt: null, note: '', noteUpdatedAt: null,
});
const emptyRecords = (): StoredChecklist => ({
  version: 1,
  items: Object.fromEntries(ITEMS.map((item) => [item.id, emptyEntry()])),
});
const validTime = (value: unknown): value is string | null =>
  value === null || (typeof value === 'string' && !Number.isNaN(Date.parse(value)));

function loadRecords(): LoadResult {
  const fallback = emptyRecords();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === null) return { records: fallback, error: '', malformed: false };
    const value: unknown = JSON.parse(raw);
    if (!value || typeof value !== 'object' || (value as StoredChecklist).version !== 1 ||
      !(value as StoredChecklist).items || typeof (value as StoredChecklist).items !== 'object' ||
      Array.isArray((value as StoredChecklist).items)) throw new Error('invalid schema');
    const stored = (value as StoredChecklist).items;
    const items: Record<string, TestEntry> = {};
    for (const item of ITEMS) {
      const entry = stored[item.id];
      if (entry === undefined) {
        items[item.id] = emptyEntry();
        continue;
      }
      if (!entry || typeof entry !== 'object' || !STATUSES.includes(entry.status) ||
        typeof entry.note !== 'string' || entry.note.length > 1000 ||
        !validTime(entry.statusUpdatedAt) || !validTime(entry.noteUpdatedAt)) {
        throw new Error('invalid item');
      }
      items[item.id] = {
        status: entry.status,
        statusUpdatedAt: entry.statusUpdatedAt,
        note: entry.note,
        noteUpdatedAt: entry.noteUpdatedAt,
      };
    }
    return { records: { version: 1, items }, error: '', malformed: false };
  } catch (cause) {
    if (cause instanceof SyntaxError || (cause instanceof Error && /invalid (schema|item)/.test(cause.message))) {
      return {
        records: fallback,
        error: '저장된 테스트 기록의 형식을 확인할 수 없습니다. 기존 기록을 덮어쓰지 않도록 편집을 중지했습니다.',
        malformed: true,
      };
    }
    return {
      records: fallback,
      error: '이 브라우저의 테스트 기록 저장소를 읽을 수 없습니다. 저장소 권한 또는 브라우저 설정을 확인해 주세요.',
      malformed: false,
    };
  }
}

function formattedTime(value: string | null) {
  if (!value) return '기록 없음';
  return new Date(value).toLocaleString('ko-KR', { dateStyle: 'medium', timeStyle: 'short' });
}

export function StoreHardwareTest({ onBack, onOpenOrders }: StoreHardwareTestProps) {
  const [loaded, setLoaded] = useState<LoadResult>(loadRecords);
  const [drafts, setDrafts] = useState<Record<string, string>>(() =>
    Object.fromEntries(ITEMS.map((item) => [item.id, loaded.records.items[item.id].note])));
  const [saveError, setSaveError] = useState('');
  const [notice, setNotice] = useState('');
  const blocked = Boolean(loaded.error);

  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY) return;
      const next = loadRecords();
      setLoaded(next);
      setDrafts(Object.fromEntries(ITEMS.map((item) => [item.id, next.records.items[item.id].note])));
      setSaveError('');
      setNotice(next.error ? '' : '다른 탭에서 변경된 수동 기록을 다시 읽었습니다. 저장하지 않은 메모 입력은 유지되지 않습니다.');
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const retry = () => {
    const next = loadRecords();
    setLoaded(next);
    if (!next.error) {
      setDrafts(Object.fromEntries(ITEMS.map((item) => [item.id, next.records.items[item.id].note])));
      setSaveError('');
      setNotice('저장된 기록을 다시 읽었습니다.');
    }
  };
  const clearMalformed = () => {
    if (!window.confirm('읽을 수 없는 매장 장비 테스트 기록만 삭제합니다. 삭제한 기록은 복구할 수 없습니다. 계속할까요?')) return;
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      const next = loadRecords();
      setLoaded(next);
      if (!next.error) {
        setDrafts(Object.fromEntries(ITEMS.map((item) => [item.id, ''])));
        setSaveError('');
        setNotice('읽을 수 없는 테스트 기록을 삭제했습니다. 모든 항목은 미검증으로 시작합니다.');
      }
    } catch {
      setSaveError('저장소에서 기록을 삭제하지 못했습니다. 브라우저 저장소 설정을 확인해 주세요.');
    }
  };
  const persist = (id: string, update: Partial<TestEntry>) => {
    if (blocked) return;
    const next: StoredChecklist = {
      version: 1,
      items: {
        ...loaded.records.items,
        [id]: { ...loaded.records.items[id], ...update },
      },
    };
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      setLoaded({ records: next, error: '', malformed: false });
      setSaveError('');
      setNotice('');
    } catch {
      setSaveError('변경사항을 저장하지 못했습니다. 저장 공간 부족 또는 브라우저 차단일 수 있습니다. 이전에 저장된 기록은 그대로 유지됩니다. 공간을 확인한 뒤 다시 시도해 주세요.');
    }
  };
  const tally = Object.fromEntries(STATUSES.map((status) =>
    [status, ITEMS.filter((item) => loaded.records.items[item.id].status === status).length])) as Record<TestStatus, number>;
  const reviewed = ITEMS.length - tally['미검증'];

  return <main className="store-hardware-test" data-testid="store-hardware-test">
    <div className="sht-wrap">
      <header className="sht-top">
        <div className="sht-brand"><span className="sht-monogram">K99</span><div><strong>품격세탁소 · 과천점</strong><small>STAFF / MANAGEMENT CENTER</small></div></div>
        <button type="button" onClick={onBack} data-testid="button-back-hardware-test"><ArrowLeft /> 관리센터로 돌아가기</button>
      </header>

      <div className="sht-intro">
        <div><span className="sht-kicker">STORE TEST / MANUAL LOG</span><h1>매장 장비 테스트</h1>
          <p>오늘 오후 매장에서 직접 관찰한 결과를 항목별로 남기는 체크리스트입니다. 각 상태와 메모의 기록 시각은 따로 보관됩니다.</p></div>
        <span className="sht-stamp">PHASE 8.1 · 12 CHECKPOINTS</span>
      </div>

      <div className="sht-disclaimer" role="note">
        <ShieldAlert aria-hidden="true" />
        <div><strong>이 화면은 장비를 작동시키거나 연결 상태를 검사하지 않습니다.</strong>
          <p>모든 항목은 미검증에서 시작합니다. ‘성공’은 담당자가 실제 매장 현장에서 확인한 뒤 직접 선택한 수동 기록일 뿐, 시스템이 물리적 동작을 보증한다는 뜻이 아닙니다.</p></div>
      </div>

      {(loaded.error || saveError) && <div className="sht-alert" role="alert" data-testid="status-hardware-test-error">
        <strong>기록 저장 확인 필요</strong><p>{loaded.error || saveError}</p>
        <div className="sht-alert-actions">
          {loaded.error && <button type="button" onClick={retry} data-testid="button-retry-hardware-test"><RotateCcw /> 다시 읽기</button>}
          {loaded.malformed && <button type="button" onClick={clearMalformed} data-testid="button-clear-malformed-hardware-test">기록 삭제 후 새로 시작</button>}
        </div>
      </div>}
      {notice && !loaded.error && <div className="sht-success" role="status" data-testid="status-hardware-test-notice">{notice}</div>}

      <section className="sht-disclaimer" aria-label="다중 의류 현장 검증 7단계" data-testid="store-workflow-checklist">
        <ClipboardCheck aria-hidden="true" />
        <div>
          <strong>다중 의류 현장 검증 · 한 주문으로 7단계 확인</strong>
          <p>기존 Windows Bridge를 그대로 사용합니다. 아래 안내는 자동 테스트 결과나 실물 작동 보증이 아닙니다.</p>
          <ol>
            <li>저장 주문 <NumUnit>1건</NumUnit> 열기 — 주문번호·고객·전체 의류 확인.</li>
            <li>2벌 이상 촬영 — 풋스위치 사진이 현재 의류에 연결되고 다음 의류가 자동 대기하는지 확인.</li>
            <li>기존 태그 출력 방식으로 실물 태그 1회 출력 — 바코드와 의류 확인.</li>
            <li>정상 의류 일괄 진행 — 세탁방법 선택 후 실제 작업에 맞춰 시작·완료·검수 기록.</li>
            <li>예외 의류 1벌만 개별 확인 — 다른 의류는 진행되고 해당 의류는 처리 전까지 보류되는지 확인.</li>
            <li>완성 바코드 연속 스캔 — 중복은 수량 유지, 다른 주문은 경고, 전부 확인 전 출고 차단.</li>
            <li>전체 출고 완료 — 새로고침 후 주문번호·의류별 상태·출고 기록 유지 확인.</li>
          </ol>
          {onOpenOrders && <button type="button" onClick={onOpenOrders} data-testid="button-store-checklist-orders">저장 주문 목록 열기</button>}
        </div>
      </section>

      <div className="sht-layout">
        <div className="sht-main">
          <div className="sht-section-head">
            <div><span className="sht-kicker">OBSERVATION RECORD</span><h2>현장 확인 항목</h2><p>상태 선택과 메모 저장은 각각 별도의 수동 작업입니다.</p></div>
            <span className="sht-count" data-testid="text-hardware-test-reviewed">{reviewed} / {ITEMS.length} 미검증 외 상태</span>
          </div>
          <div className="sht-list">
            {ITEMS.map((item, index) => {
              const entry = loaded.records.items[item.id];
              const changed = drafts[item.id] !== entry.note;
              return <article className="sht-item" key={item.id} data-status={entry.status} data-testid={`card-hardware-test-${item.id}`}>
                <div className="sht-item-head">
                  <div className="sht-item-title"><span className="sht-number">{String(index + 1).padStart(2, '0')}</span>
                    <div><h3 id={`sht-title-${item.id}`}>{item.title}</h3><p>{item.hint}</p></div></div>
                  <span className="sht-current" data-status={entry.status} data-testid={`status-hardware-test-${item.id}`}>{entry.status}</span>
                </div>
                <div className="sht-controls" role="group" aria-labelledby={`sht-title-${item.id}`}>
                  {STATUSES.map((status) => <button type="button" className="sht-option" key={status}
                    aria-pressed={entry.status === status} disabled={blocked}
                    onClick={() => persist(item.id, { status, statusUpdatedAt: new Date().toISOString() })}
                    data-testid={`button-status-${item.id}-${STATUSES.indexOf(status)}`}>{status}</button>)}
                </div>
                <div className="sht-meta">
                  <span data-testid={`text-status-time-${item.id}`}>상태 기록 {formattedTime(entry.statusUpdatedAt)}</span>
                  <span data-testid={`text-note-time-${item.id}`}>메모 기록 {formattedTime(entry.noteUpdatedAt)}</span>
                </div>
                <div className="sht-note">
                  <label htmlFor={`sht-note-${item.id}`}>관찰 메모</label>
                  <textarea id={`sht-note-${item.id}`} value={drafts[item.id]} maxLength={1000} disabled={blocked}
                    onChange={(event) => setDrafts((previous) => ({ ...previous, [item.id]: event.target.value }))}
                    placeholder="직접 본 현상, 확인한 시각, 다시 볼 부분만 적어 주세요."
                    data-testid={`input-note-${item.id}`} />
                  <div className="sht-note-actions"><span>고객 이름, 전화번호, 주소 등 개인정보는 적지 마세요. {drafts[item.id].length}/1000</span>
                    <button type="button" className="sht-save" disabled={blocked || !changed}
                      onClick={() => persist(item.id, { note: drafts[item.id], noteUpdatedAt: new Date().toISOString() })}
                      data-testid={`button-save-note-${item.id}`}>메모 저장</button></div>
                </div>
              </article>;
            })}
          </div>
        </div>

        <aside className="sht-side" aria-label="테스트 기록 요약">
          <section className="sht-panel">
            <h2>수동 기록 현황</h2>
            <div className="sht-progress"><strong data-testid="text-hardware-test-progress">{reviewed}</strong><span>/ <NumUnit>{ITEMS.length}개</NumUnit> 미검증 외 상태</span></div>
            <div className="sht-track" aria-hidden="true"><span style={{ transform: `scaleX(${reviewed / ITEMS.length})` }} /></div>
            <dl className="sht-tally">{STATUSES.map((status) =>
              <div key={status}><dt>{status}</dt><dd data-testid={`text-hardware-test-count-${STATUSES.indexOf(status)}`}>{tally[status]}</dd></div>)}</dl>
          </section>
          <section className="sht-panel">
            <h2><ClipboardCheck aria-hidden="true" /> 기록 원칙</h2>
            <p>이 기록은 현재 브라우저의 별도 로컬 저장소에만 보관됩니다. 주문, 의류, 사진 기록에는 영향을 주지 않습니다.</p>
            <p>상태를 변경해도 기존 메모와 메모 기록 시각은 바뀌지 않습니다. 메모를 저장해도 상태 기록 시각은 바뀌지 않습니다.</p>
            <p className="sht-caution"><Info aria-hidden="true" /> 다른 PC나 브라우저에 자동 동기화되지 않습니다.</p>
          </section>
        </aside>
      </div>
    </div>
  </main>;
}

export default StoreHardwareTest;