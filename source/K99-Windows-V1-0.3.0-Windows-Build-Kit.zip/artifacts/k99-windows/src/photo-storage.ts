const WINDOWS_INVALID = /[<>:"/\\|?*\x00-\x1f]/;
const RESERVED_WINDOWS_NAME = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/i;

function validateFolderName(value: string): string {
  const name = value.trim();
  if (!name || name === '.' || name === '..' || WINDOWS_INVALID.test(name)
    || /[ .]$/.test(name) || RESERVED_WINDOWS_NAME.test(name))
    throw new Error('Windows 사진 폴더명에 사용할 수 없는 값이 있습니다.');
  return name;
}

/**
 * Validates a future Windows storage root. This is path-contract validation only:
 * it does not test or write to the filesystem.
 */
export function validateWindowsPhotoRoot(root: string): string {
  const normalized = root.trim().replaceAll('/', '\\');
  if (!/^[A-Z]:\\/i.test(normalized)) throw new Error('사진 저장 경로는 Windows 드라이브의 절대 경로여야 합니다.');
  const path = normalized.slice(3).replace(/\\+$/, '');
  const segments = path ? path.split('\\') : [];
  if (segments.some((segment) => !segment || segment === '.' || segment === '..'))
    throw new Error('사진 저장 경로의 폴더 구성을 확인해 주세요.');
  segments.forEach(validateFolderName);
  return `${normalized.slice(0, 2).toUpperCase()}\\${segments.join('\\')}${segments.length ? '\\' : ''}`;
}

/** Returns a labeled simulation contract; no directory or file is created. */
export function simulatedGarmentPhotoFolder(root: string, customerFolderName: string, garmentId: string): {
  mode: 'simulated';
  label: '시뮬레이션 저장';
  path: string;
} {
  const safeRoot = validateWindowsPhotoRoot(root);
  const customerFolder = validateFolderName(customerFolderName);
  const safeGarmentId = validateFolderName(garmentId);
  return {
    mode: 'simulated',
    label: '시뮬레이션 저장',
    path: `${safeRoot}${customerFolder}\\${safeGarmentId}`,
  };
}