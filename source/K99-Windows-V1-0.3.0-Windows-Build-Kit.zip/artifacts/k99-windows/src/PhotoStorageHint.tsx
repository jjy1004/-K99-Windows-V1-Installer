import {useEffect,useState} from 'react';
import './desktop-runtime';
export function photoStorageMessage(folder:string){
  const drive=/^([a-z]):[\\/]/i.exec(folder)?.[1].toUpperCase();
  return `📁 사진 자동 저장: ${folder}${drive?` (${drive} 드라이브 자동 인식)`:''}`;
}
export function PhotoStorageHint(){
  const [text,setText]=useState('📁 사진 자동 저장: Windows 설치 앱에서 실제 경로를 확인합니다.');
  useEffect(()=>{
    let live=true;
    const load=()=>{void window.k99Desktop?.storageLayout?.({action:'status'}).then(status=>{
      if(!live)return;
      const folder=status.success&&status.folders?.find(f=>f.key==='intake');
      if(folder)setText(folder.ready?photoStorageMessage(folder.path):`📁 사진 저장 폴더 권한 확인 필요: ${folder.path}`);
      else setText('📁 사진 저장 경로를 확인하지 못했습니다. 기존 저장 설정은 유지됩니다.');
    }).catch(()=>{if(live)setText('📁 사진 저장 경로 확인 지연 · 기존 저장 설정 유지');});};
    load();window.addEventListener('k99-hardware-settings-changed',load);
    return()=>{live=false;window.removeEventListener('k99-hardware-settings-changed',load);};
  },[]);
  return <p className="rcs-storage-hint" data-testid="photo-storage-hint" title={text}>{text}</p>;
}
