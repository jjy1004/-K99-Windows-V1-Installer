import type { ConfirmedOrder } from './order-record';
import { currentOperations } from './order-operations';

/** Inspection is historical evidence; delivery/cancellation is the current order lifecycle. */
export function currentInspectionStatus(order: ConfirmedOrder): { status: string; terminal: boolean; message?: string } {
  const operations = currentOperations(order);
  if (operations.cancelledAt) return {status:'접수 취소',terminal:true,message:'취소된 주문입니다. 아래 전문검수 내용은 이전 기록입니다.'};
  if (operations.completedAt || ['매장수령완료','배달완료'].includes(operations.stage))
    return {status:operations.stage,terminal:true,message:'주문 출고·수령이 완료되었습니다. 아래 전문검수와 고객 동의는 이전 작업의 기록이며 추가 승인이 필요한 상태가 아닙니다.'};
  if (operations.stage === '배달중')
    return {status:'배달 중 · 매장 출고 완료',terminal:true,message:'매장 출고를 완료하고 배달 중입니다. 아래 전문검수 내용은 이전 작업의 기록입니다.'};
  if (order.status === '전체 세탁 완료 / 반출 대기')
    return {status:order.status,terminal:false,message:'전체 의류의 세탁과 완성 검수가 끝났습니다. 출고 화면에서 각 의류의 바코드를 확인해 주세요.'};
  return {status:order.status,terminal:false};
}
