import { useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import ScannerIdentityDiagnostics from './ScannerIdentityDiagnostics';
import { BackupPreview } from './BackupPreview';
import { getPhotoBridgeTagJob, type PhotoBridgeTagJob } from './passive-photo-client';

/** Read-only administrator investigation; never runs completion or prints. */
export function AdminTagDiagnostics({ orders }: { orders: ConfirmedOrder[] }) {
  const [selected, setSelected] = useState('');
  const [raw, setRaw] = useState('');
  const [jobs, setJobs] = useState<Record<string, PhotoBridgeTagJob | null>>({});
  const [message, setMessage] = useState('');
  return <><BackupPreview orders={orders} /><details>
    <summary>관리자 · 이전 태그 원문과 저장된 의류 연결 조사</summary>
    <p>조회만 합니다. ID를 변경하거나 태그를 발행하지 않습니다.</p>
    <label>태그에서 읽은 전체 원문<input value={raw} onChange={event => setRaw(event.target.value)}
      autoComplete="off" /></label>
    <ScannerIdentityDiagnostics orders={orders} selectedOrderId={selected} onSelectOrder={setSelected}
      lastScan={raw ? { raw, source: 'input-submit', keyEvents: [], pasteRaw: null,
        capturedAt: new Date().toISOString() } : null} />
    {orders.find(order => order.id === selected)?.garments?.map(g => <section key={g.garmentId}>
      <h3>{g.itemName} · {g.garmentId}</h3>
      <p>주문 연결: {g.orderId === selected ? '일치' : '불일치'} · 스캔: {!raw ? '원문 입력 필요' : raw.trim() === g.barcodeValue ? '일치' : '불일치'}</p>
      <p>저장 바코드: {g.barcodeValue} · 사진: {g.photoPath || '경로 기록 없음'} · 상태: {g.photoStatus}</p>
      <p>사진 요청: {g.captureRequestId || '없음'} · 자동 발행: {g.photoBridgeAutoTagStatus || g.tagStatus} · 재출력: {g.photoBridgeReprintStatus || '없음'}</p>
      <p>파일 존재와 실물 출력은 이 저장 기록만으로 확인되지 않습니다.</p>
      <button onClick={async () => {
        setMessage('브리지 이력 조회 중');
        try {
          const job = await getPhotoBridgeTagJob(g.garmentId);
          setJobs(old => ({ ...old, [g.garmentId]: job }));
          setMessage(job ? '이력 조회 완료 · 주문을 변경하지 않았습니다.' : '브리지 출력 이력 없음');
        } catch (cause) { setMessage(cause instanceof Error ? cause.message : '브리지 조회 실패'); }
      }}>브리지 출력 이력 조회</button>
      {jobs[g.garmentId] && <div>
        <p>브리지 주문·의류: {jobs[g.garmentId]!.orderId === g.orderId && jobs[g.garmentId]!.garmentId === g.garmentId ? '일치' : '불일치'}</p>
        <p>검증된 출력 바코드: {!jobs[g.garmentId]!.barcodeValue ? '증거 없음' : jobs[g.garmentId]!.barcodeValue === g.barcodeValue ? '일치' : '불일치'}</p>
        <p>출력 당시 사진 경로: {jobs[g.garmentId]!.verifiedPhoto?.photoPath ?? '증거 없음'} · 현재 저장 경로와 {
          !jobs[g.garmentId]!.verifiedPhoto?.photoPath || !g.photoPath ? '비교 불가' :
          jobs[g.garmentId]!.verifiedPhoto!.photoPath === g.photoPath ? '일치' : '다름 (관리자 확인 필요)'}</p>
        <pre>{JSON.stringify(jobs[g.garmentId], null, 2)}</pre>
      </div>}
      <details><summary>사진 연결·출력 감사 이력</summary><pre>{JSON.stringify({
        photos: g.photoHistory, beforePhoto: g.beforePhoto, events: g.auditEvents,
        autoRequest: g.photoBridgeAutoTagRequestId, reprintRequest: g.photoBridgeReprintRequestId,
      }, null, 2)}</pre></details>
    </section>)}
    <p role="status">{message}</p>
  </details></>;
}
