import type { ConfirmedOrder } from './order-record';
import type { OrderHistoryEvent } from './inspection-record';
import { createGarmentRecords } from './garment-record';
import { STORAGE_REMINDER_DAYS, daysSinceIntake, type StorageReminderDay } from './storage-policy.ts';
import { completionNoticeText, logisticsNoticeText, storageReminderText } from './customer-notice-text.ts';

export const STORAGE_NOTICE_POLICY = 'v2-intake-7-12';

export const CUSTOMER_NOTIFICATION_TYPES = [
  '전문 검수 후 세탁방법 변경',
  '추가 비용 발생',
  '위험 안내 및 고객 동의 요청',
  '세탁 완료',
  '수거/배달 안내',
  '직접 수령 안내',
  '장기 미수령 알림',
] as const;
export type CustomerNotificationType = typeof CUSTOMER_NOTIFICATION_TYPES[number];

export type InspectionNotificationSnapshot = {
  originalCleaningMethods: Array<{ garmentId: string; method: string }>;
  revisedCleaningMethods: Array<{ garmentId: string; method: string }>;
  originalPrice: number;
  revisedPrice: number;
  riskExplanation: string;
  waiverConsentStatus: string;
};

export type CustomerNotification = {
  id: string;
  orderId: string;
  garmentId?: string;
  type: CustomerNotificationType;
  draftText: string;
  createdAt: string;
  approvalAt?: string;
  sendPreparationAt?: string;
  manualReply?: { text: string; recordedAt: string };
  inspectionSnapshot?: InspectionNotificationSnapshot;
  reminderDay?: StorageReminderDay;
  storagePolicy?: string;
  sourceKey?: string;
  purpose?: 'completion' | 'pickup' | 'delivery';
  externalSendConfirmation?: {
    confirmedAt: string; sentAt: string; staffName: string; channel: 'kakao' | 'sms' | 'other';
    recipient: string; evidence: string; text: string;
  };
  actuallySent: false;
};

function timestamp(at: Date): string {
  if (!(at instanceof Date) || Number.isNaN(at.getTime())) throw new Error('알림 기록 시각을 확인해 주세요.');
  return at.toISOString();
}

function snapshotFor(order: ConfirmedOrder, garmentId?: string): InspectionNotificationSnapshot | undefined {
  const inspection = order.inspection;
  if (!inspection) return undefined;
  const recordedConsent = [
    inspection.response?.decisions?.join(', '),
    inspection.response?.choice,
    inspection.stagedApproval?.outcome,
    ...Object.values(inspection.stagedApproval?.steps ?? {}).map((step) => step?.response?.choice),
    inspection.itemNotice?.outcome,
    ...Object.values(inspection.itemNotice?.steps ?? {}).map((step) => step?.response?.choice),
  ].filter((value): value is string => !!value);
  const garments = (order.garments ?? createGarmentRecords(order))
    .filter(garment => garment.orderId === order.id && (!garmentId || garment.garmentId === garmentId));
  return {
    originalCleaningMethods: garments.map(garment => ({
      garmentId: garment.garmentId,
      method: inspection.originalMethods[garment.itemIndex - 1]
        ?? order.items[garment.itemIndex - 1]?.plannedCleaningMethod ?? '확인되지 않음',
    })),
    revisedCleaningMethods: garments.map(garment => ({
      garmentId: garment.garmentId,
      method: inspection.items[garment.itemIndex - 1]?.actualCleaningMethod
        ?? inspection.items[garment.itemIndex - 1]?.method ?? '확인되지 않음',
    })),
    originalPrice: inspection.originalPrice,
    revisedPrice: inspection.revisedPrice,
    riskExplanation: [
      inspection.riskNotice,
      inspection.waiverNotice,
      ...inspection.items.map((item, index) => item.riskDetails?.trim()
        ? `${order.items[index]?.displayNameKo ?? item.itemId}: ${item.riskDetails.trim()}` : ''),
    ].filter(Boolean).join('\n'),
    waiverConsentStatus: recordedConsent.join(' · ')
      || (inspection.waiverRequired ? '고객 동의 확인 전' : '면책 동의 요청 없음'),
  };
}

export function defaultNotificationDraft(order: ConfirmedOrder, type: CustomerNotificationType, garmentId?: string): string {
  if (!garmentId && (type === '세탁 완료' || type === '직접 수령 안내')) return completionNoticeText(order);
  if (!garmentId && type === '수거/배달 안내') return logisticsNoticeText(order, order.choices.deliveryRequested ? 'delivery' : 'pickup');
  const garment = order.garments?.find((item) => item.garmentId === garmentId);
  const subject = garment ? `${garment.itemName} ` : '';
  const closing = '안내 내용을 확인해 주세요. 이 메시지는 직원 검토용 초안입니다.';
  const detail: Record<CustomerNotificationType, string> = {
    '전문 검수 후 세탁방법 변경': '전문 검수 결과 세탁방법 변경이 필요합니다.',
    '추가 비용 발생': '전문 검수 결과 추가 비용이 발생합니다. 변경 금액을 확인해 주세요.',
    '위험 안내 및 고객 동의 요청': '세탁 과정의 위험 사항을 안내드리며 진행 동의를 요청드립니다.',
    '세탁 완료': '주문하신 세탁이 완료되었습니다.',
    '수거/배달 안내': '주문하신 세탁물의 수거 또는 배달 일정을 안내드립니다.',
    '직접 수령 안내': '주문하신 세탁물을 매장에서 직접 수령하실 수 있습니다.',
    '장기 미수령 알림': '완료된 세탁물이 장기간 매장에 보관 중입니다. 수령 일정을 확인해 주세요.',
  };
  return `[K99 품격세탁소]\n${order.customerName} 고객님, 주문 ${order.id} ${subject}${detail[type]}\n${closing}`;
}

function appendHistory(order: ConfirmedOrder, at: string, kind: OrderHistoryEvent['kind'], details: Record<string, unknown>): OrderHistoryEvent[] {
  return [...(order.history ?? []), { at, kind, details }];
}

function requireNotification(order: ConfirmedOrder, id: string): CustomerNotification {
  const notification = order.customerNotifications?.find((item) => item.id === id);
  if (!notification) throw new Error('수정할 고객 알림을 찾지 못했습니다.');
  return notification;
}

function replaceNotification(
  order: ConfirmedOrder, updated: CustomerNotification, at: string,
  kind: OrderHistoryEvent['kind'], action: string, previousDraftText?: string,
): ConfirmedOrder {
  const details = { action, notificationId: updated.id, orderId: updated.orderId, garmentId: updated.garmentId,
    type: updated.type, draftText: updated.draftText, approvalAt: updated.approvalAt,
    sendPreparationAt: updated.sendPreparationAt, manualReply: updated.manualReply,
    externalSendConfirmation: updated.externalSendConfirmation,
    ...(previousDraftText !== undefined && { previousDraftText }), actuallySent: false };
  return {
    ...order,
    customerNotifications: (order.customerNotifications ?? []).map((item) => item.id === updated.id ? updated : item),
    history: appendHistory(order, at, kind, details),
  };
}

export function createCustomerNotification(
  order: ConfirmedOrder, type: CustomerNotificationType, garmentId?: string, draftText?: string, at = new Date(),
): ConfirmedOrder {
  if (!CUSTOMER_NOTIFICATION_TYPES.includes(type)) throw new Error('고객 알림 종류를 확인해 주세요.');
  if (garmentId && !order.garments?.some((item) => item.garmentId === garmentId))
    throw new Error('알림 대상 세탁물을 주문에서 찾지 못했습니다.');
  const createdAt = timestamp(at);
  const text = (draftText ?? defaultNotificationDraft(order, type, garmentId)).trim();
  if (!text || text.length > 4000) throw new Error('알림 초안은 1~4,000자 사이로 입력해 주세요.');
  const existing = order.customerNotifications ?? [];
  const id = `${order.id}-customer-notice-${Date.parse(createdAt)}-${existing.length + 1}`;
  if (existing.some((item) => item.id === id)) throw new Error('같은 시각의 알림 번호가 이미 있습니다. 다시 시도해 주세요.');
  const notification: CustomerNotification = {
    id, orderId: order.id, ...(garmentId && { garmentId }), type, draftText: text, createdAt,
    ...(snapshotFor(order, garmentId) && { inspectionSnapshot: snapshotFor(order, garmentId) }), actuallySent: false,
  };
  return {
    ...order,
    customerNotifications: [...existing, notification],
    history: appendHistory(order, createdAt, 'notification-draft', {
      action: 'create-customer-notification', notificationId: id, orderId: order.id, garmentId, type, draftText: text, actuallySent: false,
    }),
  };
}

/**
 * Adds only due staff-review drafts. This never sends messages and is safe to
 * call repeatedly; reminder dates are stable regardless of the current time.
 */
export function ensureStorageReminderDrafts(order: ConfirmedOrder, asOf = new Date()): ConfirmedOrder {
  if (order.operations?.cancelledAt || order.operations?.completedAt ||
      ['매장수령완료', '배달완료'].includes(order.operations?.stage ?? '')) return order;
  const garments = order.garments ?? [];
  if (garments.length > 0 && garments.every((garment) =>
    garment.handoverStatus === 'complete' || garment.processStatus === '반출 완료')) return order;
  const elapsed = daysSinceIntake(order, asOf);
  let revised = order;
  for (const reminderDay of STORAGE_REMINDER_DAYS) {
    if (elapsed < reminderDay || (revised.customerNotifications ?? []).some((notice) =>
      notice.type === '장기 미수령 알림' && notice.reminderDay === reminderDay &&
      notice.storagePolicy === STORAGE_NOTICE_POLICY)) continue;
    const created = createCustomerNotification(revised, '장기 미수령 알림', undefined,
      storageReminderText(revised, reminderDay), asOf);
    const notifications = [...(created.customerNotifications ?? [])];
    const last = notifications.at(-1)!;
    notifications[notifications.length - 1] = { ...last, reminderDay, storagePolicy: STORAGE_NOTICE_POLICY };
    const history = [...(created.history ?? [])];
    const event = history.at(-1);
    if (event) history[history.length - 1] = {
      ...event, details: { ...event.details, action: 'storage-reminder-draft', reminderDay, actuallySent: false },
    };
    revised = { ...created, customerNotifications: notifications, history };
  }
  return revised;
}

export function editCustomerNotification(order: ConfirmedOrder, id: string, draftText: string, at = new Date()): ConfirmedOrder {
  const before = requireNotification(order, id);
  if (before.approvalAt || before.sendPreparationAt) throw new Error('승인 또는 발송 준비한 알림은 수정할 수 없습니다.');
  const text = draftText.trim();
  if (!text || text.length > 4000) throw new Error('알림 초안은 1~4,000자 사이로 입력해 주세요.');
  const updated = { ...before, draftText: text };
  return replaceNotification(order, updated, timestamp(at), 'notification-draft', 'edit-customer-notification', before.draftText);
}

export function approveCustomerNotification(order: ConfirmedOrder, id: string, at = new Date()): ConfirmedOrder {
  const before = requireNotification(order, id);
  if (!before.draftText.trim()) throw new Error('빈 알림 초안은 승인할 수 없습니다.');
  if (before.approvalAt) throw new Error('이미 직원 승인이 기록된 알림입니다.');
  const updated = { ...before, approvalAt: timestamp(at) };
  return replaceNotification(order, updated, updated.approvalAt, 'staff-message-review', 'explicit-staff-approval');
}

export function prepareCustomerNotification(order: ConfirmedOrder, id: string, at = new Date()): ConfirmedOrder {
  const before = requireNotification(order, id);
  if (!before.approvalAt) throw new Error('직원이 명시적으로 승인한 뒤 발송 준비를 기록해 주세요.');
  if (before.sendPreparationAt) throw new Error('이미 발송 준비가 기록된 알림입니다.');
  const updated = { ...before, sendPreparationAt: timestamp(at), actuallySent: false as const };
  return replaceNotification(order, updated, updated.sendPreparationAt, 'send-preparation', 'send-preparation-only');
}

export function recordManualCustomerReply(order: ConfirmedOrder, id: string, reply: string, at = new Date()): ConfirmedOrder {
  const before = requireNotification(order, id);
  const text = reply.trim();
  if (!text || text.length > 2000) throw new Error('고객 회신은 1~2,000자 사이로 입력해 주세요.');
  const updated = { ...before, manualReply: { text, recordedAt: timestamp(at) } };
  return replaceNotification(order, updated, updated.manualReply.recordedAt, 'customer-response', 'manual-customer-reply');
}

/** Staff attestation only: no network send, no delivery receipt, no inferred success. */
export function confirmExternalCustomerSend(
  order: ConfirmedOrder, id: string,
  input: { staffName: string; channel: 'kakao' | 'sms' | 'other'; recipient: string;
    evidence: string; sentAt: string; confirmed: boolean },
  at = new Date(),
): ConfirmedOrder {
  const before = requireNotification(order, id);
  if (!before.approvalAt || !before.sendPreparationAt) throw new Error('직원 승인과 발송 준비를 먼저 기록해 주세요.');
  if (before.externalSendConfirmation) throw new Error('이미 외부 발송 확인이 기록된 안내입니다.');
  if (input.confirmed !== true) throw new Error('외부 서비스에서 실제 발송을 확인한 경우에만 기록해 주세요.');
  if (!input.staffName.trim() || !input.recipient.trim() || !input.evidence.trim())
    throw new Error('확인 직원, 수신 대상, 실제 발송 확인 근거를 입력해 주세요.');
  if (!['kakao', 'sms', 'other'].includes(input.channel)) throw new Error('발송 채널을 확인해 주세요.');
  const confirmedAt = timestamp(at);
  const sent = new Date(input.sentAt);
  if (!input.sentAt || !Number.isFinite(sent.getTime()) || sent > at ||
      sent < new Date(before.sendPreparationAt)) throw new Error('실제 발송 시각은 발송 준비 이후이며 현재보다 미래일 수 없습니다.');
  if ([input.staffName, input.recipient, input.evidence].some((value) => value.length > 2000))
    throw new Error('발송 확인 입력이 너무 깁니다.');
  const updated = { ...before, externalSendConfirmation: {
    confirmedAt, sentAt: sent.toISOString(), staffName: input.staffName.trim(), channel: input.channel,
    recipient: input.recipient.trim(), evidence: input.evidence.trim(), text: before.draftText,
  } };
  return replaceNotification(order, updated, confirmedAt, 'send-preparation', 'external-send-confirmed-by-staff');
}