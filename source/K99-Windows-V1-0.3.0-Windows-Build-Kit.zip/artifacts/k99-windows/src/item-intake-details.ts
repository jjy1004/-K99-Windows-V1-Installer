import type { ItemIntakeDetails } from './order-record';

export function suggestedReviewReasons(itemId: string, details: ItemIntakeDetails): string[] {
  const reasons: string[] = [];
  const brand = details.brand?.trim() ?? '';
  if (/(몽클레어|버버리|막스마라|샤넬|루이비통|에르메스|구찌|프라다|디올|moncler|burberry|chanel|herm[eè]s|gucci|prada)/i.test(brand)
    || /^(moncler|burberry_maxmara)$/.test(itemId)) reasons.push('명품 브랜드');
  if ((details.purchasePrice ?? 0) >= 500000) reasons.push('구입가격 50만 원 이상');
  if (/(가죽|실크|스웨이드|캐시미어|모피|leather|silk|suede)/i.test(details.material ?? '')
    || itemId === 'leather_jacket') reasons.push('특수 소재');
  if (/(심함|심각|고착|복원|이염|황변)/.test(details.stain ?? '')) reasons.push('오염·복원 확인 필요');
  if (/(이염|색빠짐|변색)/.test(details.color ?? '')) reasons.push('이염 위험');
  if (details.damage?.trim()) reasons.push('기존 훼손 기록');
  return reasons;
}

export function reviewClassification(itemId: string, details: ItemIntakeDetails) {
  const reasons = suggestedReviewReasons(itemId, details);
  return {
    reasons,
    requiresReview: details.staffRiskOverride === '확인 필요' ||
      (details.staffRiskOverride !== '일반 접수' && reasons.length > 0),
  };
}