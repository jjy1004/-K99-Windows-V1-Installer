import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import './comparison-gallery.css';

export type ComparisonGalleryState = {
  id: string; orderId: string; customerName: string; index: number;
  photos: { id: string; name: string; url: string }[];
};
export function isComparisonGallery(value: unknown): value is ComparisonGalleryState {
  if (!value || typeof value !== 'object') return false;
  const g = value as ComparisonGalleryState;
  return typeof g.id === 'string' && typeof g.orderId === 'string' && typeof g.customerName === 'string'
    && Array.isArray(g.photos) && g.photos.length > 0 && g.photos.length <= 1000
    && Number.isInteger(g.index) && g.index >= 0 && g.index < g.photos.length
    && g.photos.every(p => p && typeof p.id === 'string' && typeof p.name === 'string'
      && /^k99:\/\/app\/comparison-photos\/[a-f0-9-]{36}$/.test(p.url));
}
export function ComparisonViewer({ gallery, compact = false, note, onMove, onClose, onLoaded }: {
  gallery: ComparisonGalleryState; compact?: boolean; note?: string;
  onMove: (direction: 'next' | 'previous') => void; onClose: () => void;
  onLoaded?: (photoId: string, loaded: boolean) => void;
}) {
  const photo = gallery.photos[gallery.index], close = useRef<HTMLButtonElement>(null);
  const [error, setError] = useState(false);
  useLayoutEffect(() => {
    const root = document.documentElement.style.overflow, body = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden'; document.body.style.overflow = 'hidden';
    return () => { document.documentElement.style.overflow = root; document.body.style.overflow = body; };
  }, []);
  useEffect(() => { close.current?.focus(); }, [gallery.id]);
  useEffect(() => setError(false), [photo.id, photo.url]);
  // Browser-only regression runs use the same-origin native IPC fixture.
  // A packaged Electron renderer always retains its k99:// URL.
  const src = window.location.protocol === 'k99:' ? photo.url : photo.url.replace('k99://app', window.location.origin);
  return <div className="comparison-overlay" role="dialog" aria-modal="true" aria-label="세탁 전후 비교 사진"
    data-testid="comparison-gallery" data-compact={compact} onKeyDown={event => {
      // Never let modal Enter/F-keys reach the outgoing scanner underneath.
      event.stopPropagation();
      if (event.nativeEvent.isComposing) return;
      if (event.key === 'Tab') {
        const buttons = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
        const first = buttons[0], last = buttons[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        return;
      }
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); onClose(); }
      else if (event.key === 'ArrowLeft') { event.preventDefault(); event.stopPropagation(); onMove('previous'); }
      else if (event.key === 'ArrowRight') { event.preventDefault(); event.stopPropagation(); onMove('next'); }
    }}>
    <section className="comparison-viewer">
      <header><div><strong>{gallery.customerName} 고객님 · 세탁 전후 사진</strong>
        {note && <small role="status">{note}</small>}</div>
        <button ref={close} type="button" onClick={onClose} data-testid="button-close-comparison">닫기 (대기 영상 복귀)</button></header>
      <div className="comparison-viewer__image">
        <img key={photo.id} src={src} alt={`${gallery.customerName} 고객님의 완성된 세탁 전후 비교 사진`}
          data-testid="comparison-image" onLoad={event => {
            const loaded = event.currentTarget.naturalWidth > 0;
            setError(!loaded); onLoaded?.(photo.id, loaded);
          }} onError={() => { setError(true); onLoaded?.(photo.id, false); }} />
        {error && <p role="alert">비교 사진 파일을 표시하지 못했습니다. 원본 보존 상태를 확인해 주세요.</p>}
      </div>
      <footer>{gallery.photos.length > 1 && <button type="button" onClick={() => onMove('previous')} data-testid="button-comparison-previous">← 이전 사진</button>}
        <span data-testid="comparison-position">{gallery.index + 1} / {gallery.photos.length}</span>
        {gallery.photos.length > 1 && <button type="button" onClick={() => onMove('next')} data-testid="button-comparison-next">다음 사진 →</button>}
      </footer>
    </section>
  </div>;
}

export function CustomerComparisonLayer() {
  const [gallery, setGallery] = useState<ComparisonGalleryState | null>(null);
  useEffect(() => {
    const desktop = window.k99Desktop;
    if (!desktop || !window.location.pathname.endsWith('/customer')) return;
    return desktop.onCustomerUpdate(data => {
      if (data.type === 'comparison' && isComparisonGallery(data.gallery)) setGallery(data.gallery);
      else if (data.type === 'comparison-close') setGallery(old => old?.id === data.sessionId ? null : old);
      else if (['video', 'screen', 'SWITCH_TO_RECEIPT'].includes(data.type)) setGallery(null);
    });
  }, []);
  if (!gallery) return null;
  const control = (direction: 'next' | 'previous' | 'close') =>
    window.k99Desktop?.customerEvent({ type: 'COMPARISON_CONTROL', sessionId: gallery.id, direction });
  return <ComparisonViewer gallery={gallery} onMove={control} onClose={() => control('close')}
    onLoaded={(photoId, loaded) => window.k99Desktop?.customerEvent({
      type: 'COMPARISON_ACK', sessionId: gallery.id, photoId, loaded,
    })} />;
}
