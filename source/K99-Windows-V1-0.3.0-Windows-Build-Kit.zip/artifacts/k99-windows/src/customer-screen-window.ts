export const CUSTOMER_WINDOW_NAME = 'k99-customer-display';
export const CUSTOMER_ACTIVATE_MESSAGE = 'k99-customer-display-activate';
const MONITOR_KEY = 'k99-customer-monitor-position';
export type CustomerMonitor = {
  left: number; top: number; width: number; height: number; label: string;
  id?:string;
};
type DetailedScreen = Screen & { availLeft: number; availTop: number; label?: string };
type PlacementWindow = Window & {
  getScreenDetails?: () => Promise<{ screens: DetailedScreen[]; currentScreen: DetailedScreen }>;
};
export function monitorKey(monitor: CustomerMonitor) { return `${monitor.left},${monitor.top}`; }
export function validMonitor(value: unknown): value is CustomerMonitor {
  if (!value || typeof value !== 'object') return false;
  const area = value as CustomerMonitor;
  return [area.left, area.top, area.width, area.height].every(Number.isFinite) &&
    area.width >= 200 && area.height >= 200 && area.width <= 20000 && area.height <= 20000 &&
    typeof area.label === 'string';
}
export function customerWindowFeatures(area?: CustomerMonitor | null) {
  return area && validMonitor(area)
    ? `popup=yes,left=${area.left},top=${area.top},width=${area.width},height=${area.height}`
    : 'popup=yes';
}
export function rememberCustomerMonitor(area: CustomerMonitor) {
  try { localStorage.setItem(MONITOR_KEY, monitorKey(area)); } catch { /* Live placement still works. */ }
}
export function chooseCustomerMonitor(screens: CustomerMonitor[], current: CustomerMonitor, saved?: string | null) {
  const remembered = screens.find((screen) => monitorKey(screen) === saved);
  if (remembered) return remembered;
  return screens.length === 2 ? screens.find((screen) => monitorKey(screen) !== monitorKey(current)) : undefined;
}
export async function readCustomerMonitors(requestPermission = false): Promise<{
  screens: CustomerMonitor[]; selected?: CustomerMonitor; note: string;
}> {
  if(window.k99Desktop){
    const status=await window.k99Desktop.customerStatus();
    const screens=status.monitors.map(m=>({id:m.id,label:m.label,left:m.bounds.x,top:m.bounds.y,
      width:m.bounds.width,height:m.bounds.height}));
    const selected=screens.find(m=>m.id===status.displayId);
    return {screens,selected,note:status.note};
  }
  const host = window as PlacementWindow;
  if (!host.getScreenDetails) return { screens: [], note: '자동 모니터 배치를 지원하지 않습니다. 고객 창을 고객 모니터로 직접 옮겨 주세요.' };
  try {
    if (!requestPermission) {
      const permission = await navigator.permissions.query({ name: 'window-management' as PermissionName });
      if (permission.state !== 'granted') return { screens: [], note: '처음 한 번 ‘모니터 배치 설정’에서 다중 모니터 권한을 허용해 주세요.' };
    }
    const details = await host.getScreenDetails();
    const normalize = (screen: DetailedScreen, index: number): CustomerMonitor => ({
      left: screen.availLeft, top: screen.availTop, width: screen.availWidth,
      height: screen.availHeight, label: screen.label || `모니터 ${index + 1}`,
    });
    const screens = details.screens.map(normalize).filter(validMonitor);
    let saved: string | null = null;
    try { saved = localStorage.getItem(MONITOR_KEY); } catch { /* Select from live monitors. */ }
    const selected = chooseCustomerMonitor(screens, normalize(details.currentScreen, 0), saved);
    return { screens, selected, note: selected ? ''
      : screens.length < 2 ? '고객 모니터가 감지되지 않습니다. 모니터 연결을 확인해 주세요.'
      : '목록에서 고객 모니터를 선택해 주세요. 임의의 모니터로 이동하지 않습니다.' };
  } catch {
    return { screens: [], note: '다중 모니터 권한이 없거나 배치 정보를 읽지 못했습니다. 권한을 허용하거나 고객 창을 직접 옮겨 주세요.' };
  }
}
export function activateCustomerWindow(peer: Window, area?: CustomerMonitor | null) {
  try {
    if (area && validMonitor(area)) {
      peer.moveTo(area.left, area.top);
      peer.resizeTo(area.width, area.height);
    }
    peer.focus();
  } catch { /* Connection state and the manual reconnect remain available. */ }
}
