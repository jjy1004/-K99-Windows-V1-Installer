import type { GarmentRecord } from './garment-record';
import type { PhotoBridgeTagJob } from './passive-photo-client';
import { hasDevicePrintProof } from './passive-photo-client';

/** A bound STORE job acknowledges issuance, not physical print completion.
 * The scanner must still resolve the exact saved barcode to one garment. */
export function hasRecordedStoreTagSubmission(g: GarmentRecord): boolean {
  if (g.barcodeValue !== g.garmentId) return false;
  return Boolean(
    (g.photoBridgeAutoTagMode === 'STORE' && g.photoBridgeAutoTagRequestId?.trim() &&
      g.photoBridgeAutoTagJobId?.trim() && ['submitted', 'printed'].includes(g.photoBridgeAutoTagStatus ?? '')) ||
    (g.photoBridgeReprintMode === 'STORE' && g.photoBridgeReprintRequestId?.trim() &&
      g.photoBridgeReprintJobId?.trim() && ['submitted', 'printed'].includes(g.photoBridgeReprintStatus ?? '')),
  );
}

export function tagJobStatusMessage(job: PhotoBridgeTagJob): string {
  const labels: Record<string, string> = {
    pending: '출력 요청 처리 중 · 실제 출력 미확인',
    submitted: '출력 요청 전달됨 · 실제 출력 미확인',
    unknown: '출력 여부 불명확 · 실물과 대기열 확인 필요',
    failed: '출력 실패 보고',
    skipped: '출력 요청 건너뜀 · 기존 기록 확인 필요',
  };
  const label = job.status === 'printed'
    ? hasDevicePrintProof(job) ? '장치의 1장 완료 응답 확인 · 실물 확인 필요' : '실제 출력 완료 증거 없음'
    : labels[job.status];
  const mode = job.mode === 'STORE' ? '운영' : job.mode === 'TEST' ? '시험 모드' : '개발 모드';
  return `${mode} · ${label}${job.reason ? ` · ${job.reason}` : ''} · 상태 조회만 했고 재전송하지 않았습니다.`;
}

export function tagAction(g?: GarmentRecord) {
  if (!g) return '태그 발행';
  const status = g.photoBridgeReprintRequestId ? g.photoBridgeReprintStatus : g.photoBridgeAutoTagStatus;
  if (['pending', 'submitted', 'unknown'].includes(status ?? '')) return '출력 여부 확인';
  if (status === 'failed' || g.tagStatus === 'failed') return '태그 발행 재시도';
  if (status === 'printed' || g.tagStatus === 'printed') return '기존 태그 재출력';
  return '태그 발행';
}

export function verifiedHistory(g: GarmentRecord, job: PhotoBridgeTagJob | null) {
  const proof = job?.verifiedPhoto;
  if (!job || job.mode !== 'STORE' || job.status !== 'printed' || !job.hardwareVerified ||
    job.orderId !== g.orderId || job.garmentId !== g.garmentId ||
    job.barcodeValue !== g.barcodeValue || g.barcodeValue !== g.garmentId || !proof || proof.status !== 'saved' ||
    !proof.requestId || !proof.photoPath || !Number.isFinite(Date.parse(proof.timestamp))) return null;
  return proof;
}
