import {useEffect,useState} from 'react';
import './desktop-runtime';
type Status=Awaited<ReturnType<NonNullable<NonNullable<Window['k99Desktop']>['storageLayout']>>>;
const NAMES:Record<string,string>={program:'명품 계산기',intake:'접수 사진',compare:'전후 비교 사진',backup:'DB 백업',videos:'고객 모니터 영상·이미지'};
export function StorageLayoutSettings({compact=false}:{compact?:boolean}={}){
  const [status,setStatus]=useState<Status|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
  useEffect(()=>{let live=true;void window.k99Desktop?.storageLayout?.({action:'status'}).then(value=>{if(live)setStatus(value);})
    .catch(()=>{if(live)setError('저장 폴더 상태를 확인하지 못했습니다.');});return()=>{live=false;};},[]);
  async function change(){
    setBusy(true);setError('');
    try{const r=await window.k99Desktop?.storageLayout?.({action:'change'});
      if(r?.success){setStatus(r);if(r.restarting)setError('새 저장 드라이브를 연결했습니다. 앱을 다시 시작합니다.');}
      else if(r&&!r.cancelled)setError(r.error||'저장 경로를 변경하지 못했습니다.');
    }catch{setError('저장 경로를 변경하지 못했습니다. 기존 경로는 보존됩니다.');}
    finally{setBusy(false);}
  }
  return <section className="eq-card" data-testid="storage-layout-settings" style={{background:'#17343d',color:'#f3ede3'}}>
    <h2>저장 드라이브 자동 연결</h2>
    <p>현재 저장 루트: <strong data-testid="storage-layout-root">{status?.root||'Windows 앱에서 확인할 수 있습니다.'}</strong></p>
    <details open={!compact}><summary>연결 폴더 상태 · 기존 자료 보존 안내</summary>
    {status?.folders?.map(folder=><p key={folder.key} style={{overflowWrap:'anywhere'}}>
      <strong>{NAMES[folder.key]||folder.key}</strong> · {folder.ready?'연결됨':'연결·쓰기 권한 확인 필요'}<br/>{folder.path}</p>)}
    <p>진행 중인 접수가 없을 때 변경할 수 있습니다. 새 저장 위치 확인 후 다시 시작하며, 기존 장부·사진은 이동하거나 삭제하지 않습니다.</p>
    </details>
    <button type="button" className="eq-btn" data-testid="button-change-storage-drive" disabled={busy||!status?.success}
      onClick={()=>void change()}>{busy?'확인 중':'저장 드라이브 변경'}</button>
    {(error||status?.error)&&<p role="status">{error||status?.error}</p>}
  </section>;
}
