import type { ConfirmedOrder } from './order-record';

export type OrderAdminAudit = {
  action: 'soft-delete' | 'restore';
  at: string;
  orderId: string;
  adminId: string;
  adminLabel: string;
  authorizationId: string;
};
export type OrderDeletion = {
  deletedAt: string; adminId: string; adminLabel: string; authorizationId: string;
};
export const isDeletedOrder = (order: Pick<ConfirmedOrder, 'orderDeletion'>): boolean => !!order.orderDeletion;
export const businessOrders = <T extends Pick<ConfirmedOrder, 'orderDeletion'>>(orders: readonly T[]): T[] =>
  orders.filter(order => !isDeletedOrder(order));

/** Never infer that a cancelled/refunded payment is settled. Require accounting review. */
export function settlementBlockReason(order: ConfirmedOrder): string | null {
  const op = order.operations;
  const financialHistory = order.history?.some(event => event.kind === 'operations-update' &&
    ['payment', 'refund', 'payment-record'].includes(String(event.details?.action)));
  if (op && (op.paymentStatus !== '미결제' || op.paidAmount !== 0 || !!op.paidAt) || financialHistory)
    return '결제·환불 기록이 있는 주문입니다. 삭제할 수 없습니다. 정산 담당자가 원본 결제·환불 기록을 확인해야 합니다.';
  return null;
}
