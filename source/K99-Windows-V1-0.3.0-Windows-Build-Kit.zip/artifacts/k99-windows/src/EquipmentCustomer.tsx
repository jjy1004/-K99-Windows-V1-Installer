import { useEffect, useState } from 'react';
import { getCustomerSnapshot, type CustomerSnapshot } from './equipment-client';
import './equipment.css';

type DesktopEvents = { k99Desktop?: { onChanged?: (cb: () => void) => (() => void) | void } };
const won = (n: number) => `${n.toLocaleString('ko-KR')}원`;

export function EquipmentCustomer() {
  const [snap, setSnap] = useState<CustomerSnapshot | null>(null);
  const [error, setError] = useState('');
  const [lastOk, setLastOk] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    let live = true; let busy = false;
    const load = async () => {
      if (busy) return; busy = true;
      try {
        const next = await getCustomerSnapshot();
        if (!live) return;
        setSnap(old => old && old.revision === next.revision && old.updatedAt === next.updatedAt ? old : next);
        setLastOk(Date.now()); setError('');
      } catch (cause) {
        if (live) setError(cause instanceof Error ? cause.message : '직원 화면 연결을 확인하세요.');
      } finally { busy = false; if (live) setNow(Date.now()); }
    };
    void load();
    const timer = window.setInterval(() => {setNow(Date.now());void load();}, 1000);
    const off = (window as unknown as DesktopEvents).k99Desktop?.onChanged?.(() => void load());
    return () => { live = false; clearInterval(timer); if (typeof off === 'function') off(); };
  }, []);

  const stale = lastOk === null || now - lastOk > 5000;
  return (
    <main className="eqc" data-testid="page-equipment-customer">
      <header className="eqc__top">
        <div><strong>K99 품격세탁소</strong><span>고객 확인 화면</span></div>
        <div className="eqc__meta">
          {snap?.mode === 'mock' && <span className="eq-pill is-mock" data-testid="status-customer-mock">모의 표시 · 실제 장비 아님</span>}
          <span className={`eq-pill ${stale ? 'is-bad' : 'is-ok'}`} data-testid="status-customer-connection">
            {lastOk === null ? '연결 확인 중' : stale ? `연결 지연 · ${Math.round((now - lastOk) / 1000)}초 전 갱신` : '연결됨'}</span>
        </div>
      </header>
      {error && <p className="eq-error" role="alert" data-testid="text-customer-error">{error}</p>}
      {!snap ? (
        <section className="eqc__empty"><div className="eq-skel" /><div className="eq-skel short" /><p>직원 화면의 주문 표시를 기다리는 중입니다.</p></section>
      ) : !snap.orderId && !snap.items.length ? (
        <section className="eqc__empty"><h1>안녕하세요</h1><p>{snap.note || '직원이 주문을 표시하면 이곳에 내역이 나타납니다.'}</p></section>
      ) : (
        <section className="eqc__body">
          <small className="eqc__kicker">접수 내역 확인</small>
          <h1 data-testid="text-customer-name">{snap.customerName ? `${snap.customerName} 고객님` : '고객님'}</h1>
          <ul className="eqc__items">
            {snap.items.map((it, i) => (
              <li key={i} data-testid={`row-customer-item-${i}`}><span>{it.name}</span><span>{it.quantity}점</span><b>{won(it.amount)}</b></li>
            ))}
          </ul>
          <div className="eqc__total"><span>예상 합계</span><b data-testid="text-customer-total">{won(snap.total)}</b></div>
          {snap.note && <p className="eqc__note">{snap.note}</p>}
        </section>
      )}
      <footer className="eqc__foot" data-testid="text-customer-revision">
        {snap ? `표시 버전 ${snap.revision} · ${new Date(snap.updatedAt).toLocaleString('ko-KR')}` : '표시 버전 없음'}
      </footer>
    </main>
  );
}

export default EquipmentCustomer;
