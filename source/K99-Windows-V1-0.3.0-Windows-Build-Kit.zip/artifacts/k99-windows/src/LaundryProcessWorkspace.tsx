import { useCallback, useEffect, useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import { updateSavedOrder } from './order-record';
import LaundryProcessView from './LaundryProcessView';
import { advanceGarmentLaundry, findLaundryGarment, loadLaundryOrder, type LaundryAction, type LaundrySource } from './laundry-process';
import { recordSimulatedCompletionPhoto } from './garment-automation';

export default function LaundryProcessWorkspace({ orderId, onBack }: { orderId: string; onBack: () => void }) {
  const [order, setOrder] = useState<ConfirmedOrder | null>(null);
  const [selectedGarmentId, setSelectedGarmentId] = useState('');
  const [selectionSource, setSelectionSource] = useState<LaundrySource>('manual');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  const refresh = useCallback((id: string) => {
    try {
      const latest = loadLaundryOrder(id);
      setOrder(latest);
      setSelectedGarmentId((previous) =>
        latest.garments?.some((item) => item.garmentId === previous)
          ? previous : latest.garments?.[0]?.garmentId ?? '');
      setError('');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : '주문을 다시 읽지 못했습니다.');
    }
  }, []);
  useEffect(() => { refresh(orderId); }, [orderId, refresh]);
  useEffect(() => {
    const onStorage = () => { if (order) refresh(order.id); };
    const onFocus = () => { if (order) refresh(order.id); };
    window.addEventListener('storage', onStorage);
    window.addEventListener('focus', onFocus);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('focus', onFocus);
    };
  }, [order?.id, refresh]);

  const lookup = (barcode: string) => {
    try {
      const found = findLaundryGarment(barcode);
      if (!found) {
        setNotice('');
        setError('등록되지 않은 의류 바코드입니다. 의류 ID를 다시 확인해 주세요.');
        return;
      }
      setOrder(found.order);
      setSelectedGarmentId(found.garment.garmentId);
      setSelectionSource('barcode');
      setNotice(`${found.order.customerName} 고객님 · ${found.order.id} · ${found.garment.itemName}을 찾았습니다. 상태 변경은 별도 확인 후 실행합니다.`);
      setError('');
    } catch (caught) {
      setNotice('');
      setError(caught instanceof Error ? caught.message : '바코드 조회에 실패했습니다.');
    }
  };
  const action = (type: LaundryAction, reason?: string, detail?: string) => {
    if (!order || !selectedGarmentId || busy) return;
    setBusy(true);
    try {
      const updated = advanceGarmentLaundry(order.id, selectedGarmentId, type,
        type === 'handover-rewash' ? 'manual' : selectionSource, reason, undefined, detail);
      setOrder(updated);
      setNotice(`의류 ${selectedGarmentId}의 작업 상태를 저장했습니다. 다른 의류 상태는 변경하지 않았습니다.`);
      setError('');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : '상태 변경에 실패했습니다.');
    } finally {
      setBusy(false);
    }
  };
  const recordCompletionPhoto = (garmentId: string) => {
    if (!order || busy) return;
    setBusy(true);
    try {
      // Reload and compare before writing so a stale screen cannot replace newer photo history.
      const current = loadLaundryOrder(order.id);
      const garments = recordSimulatedCompletionPhoto(current.garments ?? [], garmentId);
      const updated = { ...current, garments };
      updateSavedOrder(updated, current);
      setOrder(updated);
      setNotice(`의류 ${garmentId}의 완성 사진 시뮬레이션 기록을 저장했습니다. 실제 파일은 생성하지 않았습니다.`);
      setError('');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : '완성 사진 기록에 실패했습니다. 기존 사진은 유지됩니다.');
    } finally {
      setBusy(false);
    }
  };

  if (!order) return <main style={{ padding: 32 }}><button type="button" onClick={onBack}>← 접수 내역으로</button>
    <p role="alert">{error || '저장 주문을 확인하고 있습니다…'}</p>
    <button type="button" onClick={() => refresh(orderId)}>다시 불러오기</button></main>;
  return <LaundryProcessView order={order} garments={order.garments ?? []}
    selectedGarmentId={selectedGarmentId}
    onSelect={(id) => { setSelectedGarmentId(id); setSelectionSource('manual'); setError(''); }}
    onLookup={lookup} onAction={action} onCompletionPhoto={recordCompletionPhoto} onBack={onBack}
    error={error} notice={notice} busy={busy} />;
}