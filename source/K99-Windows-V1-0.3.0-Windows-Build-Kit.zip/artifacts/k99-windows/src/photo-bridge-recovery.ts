import { inspectPhotoBridgeConnection, readPhotoBridgeConnectionSession,
  setPhotoBridgeConnectionSession, type PhotoBridgeHealthDiagnostic } from './photo-bridge-session';

export const PHOTO_BRIDGE_RECOVERY_CHANNEL = 'k99-photo-bridge-recovery-v1';
export const PHOTO_BRIDGE_RECOVERY_URI = 'k99-disabled://hardware';
const PAIRING_ENTRY_KEY = 'k99-photo-bridge-pairing-entry-v1';
type EntryStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

/** Retain the authentication-only role after consuming the fragment or reloading. */
export function readPhotoBridgePairingEntry(hash = window.location.hash, storage?: EntryStorage): boolean {
  const launched = new URLSearchParams(hash.slice(1)).has('k99-bridge-pair');
  try {
    const store = storage ?? window.sessionStorage;
    if (launched) store.setItem(PAIRING_ENTRY_KEY, '1');
    return launched || store.getItem(PAIRING_ENTRY_KEY) === '1';
  } catch { return launched; }
}

export function leavePhotoBridgePairingEntry(storage?: EntryStorage): void {
  try { (storage ?? window.sessionStorage).removeItem(PAIRING_ENTRY_KEY); } catch {}
}

function launchInstalledPhotoBridge(): void {
  throw new Error('Windows V1 1단계에서는 기존 매장 도우미를 실행하지 않습니다.');
}

/** Only an explicit staff click may request the registered Windows launcher. */
export async function recoverPhotoBridge({
  inspect = inspectPhotoBridgeConnection,
  launch = launchInstalledPhotoBridge,
  wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)),
  timeoutMs = 60_000,
  channelFactory = () => new BroadcastChannel(PHOTO_BRIDGE_RECOVERY_CHANNEL),
}: {
  inspect?: () => Promise<PhotoBridgeHealthDiagnostic>;
  launch?: () => void;
  wait?: (ms: number) => Promise<void>;
  timeoutMs?: number;
  channelFactory?: () => BroadcastChannel;
} = {}): Promise<void> {
  const initial = await inspect();
  if (initial.status === 'connected' && initial.mode === 'STORE' && initial.photoConfigured) return;
  const id = crypto.randomUUID();
  let channel: BroadcastChannel | undefined;
  try {
    channel = channelFactory();
    channel.onmessage = (event) => {
      const value = event.data;
      if (value?.type !== 'session' || value.id !== id ||
          value.session?.mode !== 'STORE' || typeof value.session.token !== 'string' ||
          value.session.token.length < 16 || value.session.token.length > 512) return;
      // Same-origin, live nonce handoff only; never save credentials to localStorage.
      try { setPhotoBridgeConnectionSession(value.session.token, 'STORE'); }
      catch { /* A storage-blocked tab must not become connected. */ }
    };
    launch();
    const deadline = Date.now() + timeoutMs;
    let last = initial;
    while (Date.now() < deadline) {
      channel.postMessage({ type: 'request', id });
      await wait(1000);
      last = await inspect();
      if (last.status === 'connected' && last.mode === 'STORE' && last.photoConfigured) return;
    }
    if (last.status === 'connected') throw new Error('기존 사진 폴더를 확인하지 못했습니다.');
    if (last.status === 'unpaired') throw new Error('Chrome의 로컬 연결 허용을 확인해 주세요.');
    throw new Error('사진 도우미가 응답하지 않습니다. 최신 설치본을 한 번 실행해 주세요.');
  } catch (error) {
    if (error instanceof Error && /사진 폴더|로컬 연결|최신 설치본/.test(error.message)) throw error;
    throw new Error('Windows 사진 도우미 실행을 허용해 주세요.');
  } finally { channel?.close(); }
}

/** Reuse a live operational tab only; never launch/restart Windows or touch files. */
export async function reusePhotoBridgeSession(): Promise<PhotoBridgeHealthDiagnostic> {
  try {
    await recoverPhotoBridge({ launch: () => {}, timeoutMs: 2500 });
  } catch {
    // No responding tab is a normal outcome. The authenticated probe below,
    // not receipt of a channel message, decides whether reuse succeeded.
  }
  return inspectPhotoBridgeConnection();
}

/** An authenticated launcher tab answers only live, same-origin recovery requests. */
export function listenForPhotoBridgeRecovery(): () => void {
  if (typeof BroadcastChannel === 'undefined') return () => {};
  const channel = new BroadcastChannel(PHOTO_BRIDGE_RECOVERY_CHANNEL);
  let live = true;
  let checking = false;
  channel.onmessage = async (event) => {
    const value = event.data;
    if (value?.type !== 'request' || typeof value.id !== 'string' ||
        !/^[a-f0-9-]{36}$/.test(value.id) || checking) return;
    checking = true;
    try {
      const health = await inspectPhotoBridgeConnection();
      const session = readPhotoBridgeConnectionSession();
      if (live && health.status === 'connected' && health.mode === 'STORE' && session?.mode === 'STORE') {
        channel.postMessage({ type: 'session', id: value.id, session });
      }
    } finally { checking = false; }
  };
  return () => { live = false; channel.close(); };
}
