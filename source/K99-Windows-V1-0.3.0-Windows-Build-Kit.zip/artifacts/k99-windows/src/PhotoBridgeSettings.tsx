import { useState, type FormEvent } from 'react';
import { useLocation } from 'wouter';
import {
  checkPassivePhotoBridge, getPhotoSettings, readPhotoBridgeSession,
  savePhotoSettings, setPhotoBridgeSessionToken,
  type PhotoSettings,
} from './passive-photo-client';

export function PhotoBridgeSettings() {
  const [, navigate] = useLocation();
  const [token, setToken] = useState(() => readPhotoBridgeSession()?.token ?? '');
  const [sourceRoot, setSourceRoot] = useState('');
  const [destinationRoot, setDestinationRoot] = useState('');
  const [settings, setSettings] = useState<PhotoSettings | null>(null);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function checkConnection() {
    setBusy(true);
    setError('');
    setStatus('');
    try {
      setPhotoBridgeSessionToken(token);
      const available = await checkPassivePhotoBridge();
      if (!available) throw new Error('로컬 Windows 사진 도우미에 연결할 수 없습니다. 도우미와 토큰을 확인해 주세요.');
      const current = await getPhotoSettings();
      setSettings(current);
      setSourceRoot(current.sourceRoot);
      setDestinationRoot(current.destinationRoot);
      setStatus('Windows 사진 도우미 응답 확인 완료. 물리 촬영 또는 저장 완료를 의미하지 않습니다.');
    } catch (cause) {
      setSettings(null);
      setError(cause instanceof Error ? cause.message : 'Windows 사진 도우미 상태를 확인하지 못했습니다.');
    } finally {
      setBusy(false);
    }
  }

  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setStatus('');
    try {
      setPhotoBridgeSessionToken(token);
      const updated = await savePhotoSettings(sourceRoot, destinationRoot);
      setSettings(updated);
      setSourceRoot(updated.sourceRoot);
      setDestinationRoot(updated.destinationRoot);
      setStatus('설정을 Windows 로컬 도우미에 전달했습니다. 도우미의 설정 응답을 확인했습니다.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '사진 경로 설정 저장에 실패했습니다.');
    } finally {
      setBusy(false);
    }
  }

  return <main className="photo-bridge-settings" style={{ maxWidth: 900, margin: '0 auto', padding: '32px 20px', color: '#19332f' }}>
    <header style={{ marginBottom: 24 }}>
      <button type="button" onClick={() => navigate('/management')}>← 통합관리센터</button>
      <p style={{ marginTop: 24, color: '#96713c', fontWeight: 700 }}>K99 · LOCAL WINDOWS HELPER</p>
      <h1>Windows 사진 도우미 설정</h1>
      <p>이 설정은 이 브라우저 PC의 로컬 Windows 도우미에만 전달됩니다.</p>
    </header>
    <section style={{ border: '1px solid #d4dfd8', borderRadius: 12, padding: 20, marginBottom: 18 }}>
      <h2>연결 토큰 및 상태 확인</h2>
      <p>토큰은 현재 브라우저 탭의 sessionStorage에만 보관되며, 주문 기록이나 영구 저장소에 저장되지 않습니다.</p>
      <label style={{ display: 'grid', gap: 8, margin: '16px 0' }}>Windows 도우미 토큰
        <input type="password" autoComplete="off" value={token} onChange={(event) => setToken(event.target.value)}
          aria-label="Windows 사진 도우미 토큰" />
      </label>
      <button type="button" disabled={busy || !token.trim()} onClick={() => void checkConnection()}>
        {busy ? '확인 중…' : '도우미 상태 확인'}
      </button>
      <p role="status">{settings ? `상태: 연결 응답 · 설정 ${settings.configured ? '구성됨' : '미구성'}` : '상태: 아직 확인되지 않음'}</p>
    </section>
    <form onSubmit={(event) => void saveSettings(event)}
      style={{ border: '1px solid #d4dfd8', borderRadius: 12, padding: 20 }}>
      <h2>사진 경로</h2>
      <p><strong>원본 소스 루트</strong>: 매장 PC에서 확인된 기존 촬영 폴더는 C:\K99\세탁물사진이며, 그 아래 날짜별(YYYY-MM-DD) 폴더에 HHmm-01.jpg 형식의 사진이 있습니다. 이 안내는 경로를 변경하지 않습니다.</p>
      <p>도우미는 원본을 수정하지 않습니다. 이 설정은 경로를 지정할 뿐 기존 사진을 이동·변경하지 않습니다.</p>
      <label style={{ display: 'grid', gap: 8, margin: '16px 0' }}>원본 소스 루트
        <input type="text" required value={sourceRoot} onChange={(event) => setSourceRoot(event.target.value)}
          placeholder="C:\K99\세탁물사진" />
      </label>
      <p><strong>대상 저장 루트</strong>: 도우미가 사진을 복사해 정리할 저장소 위치입니다.</p>
      <label style={{ display: 'grid', gap: 8, margin: '16px 0' }}>대상 저장 루트
        <input type="text" required value={destinationRoot} onChange={(event) => setDestinationRoot(event.target.value)}
          placeholder="Windows 드라이브 절대 경로" />
      </label>
      <button type="submit" disabled={busy || !token.trim()}>로컬 도우미에 경로 설정 저장</button>
      {settings && <p>도우미 설정 응답: {settings.configured ? '구성됨' : '미구성'}</p>}
    </form>
    {error && <p role="alert" style={{ color: '#a12d25', padding: 12, background: '#fff0ed' }}>명시적 실패: {error}</p>}
    {status && <p role="status" style={{ color: '#175d49', padding: 12, background: '#edf7f1' }}>{status}</p>}
    <aside style={{ marginTop: 20, padding: 16, background: '#f7f5ef', borderRadius: 10 }}>
      <h2>중요한 동작 범위</h2>
      <ul>
        <li>경로 설정만으로 사진 소스 파일은 수정하거나 삭제하지 않습니다.</li>
        <li>자동 물리 촬영은 수행하지 않습니다. 촬영 요청 대기와 저장은 별도 도우미 작업입니다.</li>
        <li>사진은 도우미가 저장 상태와 실제 파일 경로·시각을 확인한 뒤에만 저장 완료로 간주해야 합니다.</li>
        <li>현재 관리 화면의 시뮬레이션 사진 기록은 실제 사진 파일이 아닙니다.</li>
      </ul>
    </aside>
  </main>;
}

export default PhotoBridgeSettings;