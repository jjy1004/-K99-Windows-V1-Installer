import { directoryRequest } from './customer-directory-client';
import type { GarmentRecord } from './garment-record';
export type MobilePhotoTarget = {
  orderId:string; unitKey:string; itemId:string; itemName:string; customerName:string; customerPhone:string;
};
export type MobilePhotoSession = {
  id:string; urls:string[]; expiresAt:number; customerName:string; phoneLast4:string; itemName:string;
  folderIdentifier:string; uploadedCount:number;
  lastResult:null|{garment:GarmentRecord;archive:{folder:string;fileName:string};job?:{status:string}};
};
export const startMobilePhotos=(target:MobilePhotoTarget)=>
  directoryRequest<MobilePhotoSession>('POST','/api/mobile-photo/start',target);
export const mobilePhotoStatus=(id:string)=>
  directoryRequest<MobilePhotoSession>('GET',`/api/mobile-photo/status?id=${encodeURIComponent(id)}`);
export const stopMobilePhotos=(id:string)=>
  directoryRequest<{closed:boolean}>('POST','/api/mobile-photo/stop',{id});
