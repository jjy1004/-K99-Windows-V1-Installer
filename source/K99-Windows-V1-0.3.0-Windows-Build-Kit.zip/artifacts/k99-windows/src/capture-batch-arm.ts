import { readPhotoBridgeSession, type PhotoArmStatus } from './passive-photo-client';
import { PHOTO_BRIDGE_LOCAL_URL } from './photo-bridge-session';
import { withPhotoReadDeadline } from './photo-read-deadline';

type ArmIdentity = { requestId: string; orderId: string; garmentId: string };

/** Capture-only status reader: expose terminal failures without changing the
 * legacy client's throwing contract, authentication, endpoint or ARM behavior. */
export async function readBatchArm(request: ArmIdentity, dependencies = {
  session: readPhotoBridgeSession, fetch: globalThis.fetch,
}): Promise<PhotoArmStatus> {
  const session = dependencies.session();
  if (!session) throw new Error('사진 도우미 연결 확인 필요');
  const fetchStatus = dependencies.fetch;
  const result = await withPhotoReadDeadline(async signal => {
    const response = await fetchStatus(
      `${PHOTO_BRIDGE_LOCAL_URL}/v1/arms/${encodeURIComponent(request.requestId)}`,
      { method: 'GET', signal, headers: {
        Accept: 'application/json', 'Content-Type': 'application/json',
        'X-K99-Bridge-Token': session.token,
      } },
    );
    if (!response.ok) throw new Error(`사진 상태 확인 실패 (${response.status}) · 기존 ARM 보존`);
    return await response.json();
  });
  if (!result || !['armed','saved','failed'].includes(result.status) ||
      result.requestId !== request.requestId || result.orderId !== request.orderId ||
      result.garmentId !== request.garmentId ||
      (result.error !== undefined && typeof result.error !== 'string')) {
    throw new Error('사진 상태의 요청·주문·의류 식별자가 일치하지 않습니다. 기존 ARM을 보존했습니다.');
  }
  if (result.status === 'saved' && (typeof result.photoPath !== 'string' || !result.photoPath.trim() ||
      typeof result.photoTimestamp !== 'string' || !result.photoTimestamp.trim()))
    throw new Error('사진 저장 경로·시각 확인 필요 · 기존 ARM 보존');
  if ((result.archivePath !== undefined && (typeof result.archivePath !== 'string' || !result.archivePath.trim())) ||
      (result.archiveError !== undefined && (typeof result.archiveError !== 'string' || !result.archiveError.trim())) ||
      (result.archivePath !== undefined && result.archiveError !== undefined))
    throw new Error('고객별 사진 사본 상태가 올바르지 않습니다. 기존 ARM을 보존했습니다.');
  return result;
}
