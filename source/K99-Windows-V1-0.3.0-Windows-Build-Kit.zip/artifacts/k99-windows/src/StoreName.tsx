import { useEffect, useState } from 'react';
import { noticeApi, type StoreProfile } from './notice-api';

export const DEFAULT_STORE_NAME = 'K99세탁매장';
export const STORE_PROFILE_CHANGED = 'k99-store-profile-changed';

let cached: string | null = null;
let pending: Promise<string> | null = null;

function fetchStoreName(force = false): Promise<string> {
  if (!force && cached) return Promise.resolve(cached);
  if (!force && pending) return pending;
  pending = noticeApi<Partial<StoreProfile>>('GET', '/profile')
    .then(p => {
      const name = typeof p?.storeName === 'string' ? p.storeName.trim() : '';
      cached = name || DEFAULT_STORE_NAME;
      return cached;
    })
    .catch(() => DEFAULT_STORE_NAME)
    .finally(() => { pending = null; });
  return pending;
}

/** Registered store name only (profile endpoint); never reads customer data. */
export function useStoreName(): string {
  const [name, setName] = useState(cached ?? DEFAULT_STORE_NAME);
  useEffect(() => {
    let alive = true;
    const apply = (force: boolean) => { void fetchStoreName(force).then(n => { if (alive) setName(n); }); };
    apply(false);
    const onChange = () => apply(true);
    window.addEventListener(STORE_PROFILE_CHANGED, onChange);
    return () => { alive = false; window.removeEventListener(STORE_PROFILE_CHANGED, onChange); };
  }, []);
  return name;
}

export function StoreName({ className }: { className?: string }) {
  const name = useStoreName();
  return <span className={className} data-testid="text-store-name">{name}</span>;
}
export default StoreName;
