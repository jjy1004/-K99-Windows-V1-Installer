/** Exact stage-1 customer message templates for additional technical fees (request section 4). */

const hasFinalConsonant = (text: string): boolean => {
  const last = text.trim().replace(/[\s.,!?)"'\]]+$/, '').slice(-1);
  if (!last) return false;
  const code = last.charCodeAt(0);
  if (code >= 0xac00 && code <= 0xd7a3) return (code - 0xac00) % 28 !== 0;
  return /[013678lmnr]$/i.test(last);
};

/** Normalizes a free-form risk so it reads naturally before "이/가 발생할 가능성이 높은". */
export function naturalRiskPhrase(risk: string): string {
  let phrase = risk.trim().replace(/[.!?。]+$/, '').trim();
  phrase = phrase.replace(/\s*(이|가)?\s*(발생할|생길)\s*(수\s*있(습니다|음|다)?|가능성.*|우려.*)$/, '').trim();
  phrase = phrase.replace(/\s*(위험|우려)\s*(있음|있습니다)?$/, (match) => match.includes('위험') ? ' 위험' : '').trim();
  if (!phrase) return '';
  return `${phrase}${hasFinalConsonant(phrase) ? '이' : '가'}`;
}

export type TechnicalFeeNoticeInput = {
  itemName: string;
  fee: number;
  riskRequired: boolean;
  risk?: string;
};

const formatFee = (fee: number) => fee.toLocaleString('ko-KR');

export function buildTechnicalFeeMessage({ itemName, fee, riskRequired, risk = '' }: TechnicalFeeNoticeInput): string {
  const name = itemName.trim();
  const amount = formatFee(fee);
  if (!riskRequired) return [
    `고객님, 맡겨주신 세탁물 중 ${name}에서 일반 세탁만으로는 충분히 제거하기 어려운 얼룩이 확인되었습니다.`,
    '',
    `얼룩을 보다 효과적으로 제거하기 위해 화학적 처리와 물리적 처리를 병행하는 특수 케어가 필요하며, 추가 기술료는 ${amount}원입니다.`,
    '',
    '일반 세탁으로 진행하면 얼룩 자국이 남을 수 있어 안내드립니다. 추가 비용을 확인하시고 댓글로 ‘동의합니다’라고 남겨주시면 세탁을 진행하겠습니다.',
  ].join('\n');
  const riskPhrase = naturalRiskPhrase(risk) || '[예상 위험 내용]이';
  return [
    `고객님, 맡겨주신 ${name}은 세탁 과정에서 ${riskPhrase} 발생할 가능성이 높은 것으로 확인되었습니다.`,
    '',
    '이러한 위험을 줄이기 위해 저희가 개발한 프리미엄 특수 케어로 세심하게 작업할 예정입니다. 다만, 주의하여 진행하더라도 안내드린 위험을 완전히 없애기는 어렵습니다.',
    '',
    `추가 기술료는 ${amount}원입니다. 추가 비용과 함께, 위에 안내드린 위험이 발생하는 경우에 대한 면책 동의를 부탁드립니다.`,
    '',
    '댓글로 ‘동의합니다’라고 남겨주시면 위 추가 비용과 면책 안내에 동의하신 것으로 확인하고 세탁을 진행하겠습니다.',
  ].join('\n');
}

/** True when the stage-1 draft must use the technical fee template. */
export const usesTechnicalFeeTemplate = (fee: number | undefined) =>
  typeof fee === 'number' && Number.isSafeInteger(fee) && fee > 0;
