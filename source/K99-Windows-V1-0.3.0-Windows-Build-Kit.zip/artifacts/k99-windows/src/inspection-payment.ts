import type { ConfirmedOrder } from './order-record';
import { paymentInfo, type PaymentType } from './order-payment';

/** Read old display values without adding a third value to the SQLite payment_type contract. */
export function inspectionPaymentLabel(order: ConfirmedOrder): '선불' | '후불' | '착불' | '미지정' {
  const value: unknown = order.payment_type ?? order.choices?.paymentType;
  if (value === 'PREPAID' || value === '선불') return '선불';
  if (value === 'POSTPAID' || value === '후불') return '후불';
  if (value === 'COD' || value === '착불') return '착불';
  return '미지정';
}

/** Change terms, never overwrite staff-entered receipts, refunds, or actual paid amounts. */
export function reviseInspectionPayment(order: ConfirmedOrder, type: PaymentType, at = new Date()): ConfirmedOrder {
  if (type !== 'PREPAID' && type !== 'POSTPAID') throw new Error('선불 또는 후불을 선택해 주세요.');
  if (order.payment_type === type && order.choices.paymentType === type) return order;
  const operations = order.operations;
  const hasReceipt = !!operations && (operations.paymentStatus === '결제완료' ||
    operations.paymentStatus === '환불' || operations.paidAmount > 0 || !!operations.paidAt);
  return {
    ...order,
    payment_type: type,
    payment_status: hasReceipt ? paymentInfo(order).status : type === 'POSTPAID' ? 'UNPAID' : 'PAID',
    choices: { ...order.choices, paymentType: type },
    history: [...(order.history ?? []), { at: at.toISOString(), kind: 'operations-update',
      details: { action: 'payment-terms-update', previous: inspectionPaymentLabel(order),
        revised: type === 'PREPAID' ? '선불' : '후불', note: '결제 구분 변경 · 실제 결제·환불 기록 보존' } }],
  };
}
