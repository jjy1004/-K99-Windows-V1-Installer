/** Letter pedals are ordinary typing inside any editable field; F keys remain dedicated. */
export function captureShortcut(event:Pick<KeyboardEvent,'key'|'code'|'target'|'isComposing'|'ctrlKey'|'altKey'|'metaKey'>):'F7'|'F8'|'F9'|null{
  if(event.isComposing||event.ctrlKey||event.altKey||event.metaKey)return null;
  if(event.key==='F7'||event.key==='F8'||event.key==='F9')return event.key;
  const el=event.target as Element|null;
  if(el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"]'))return null;
  // code also handles the Korean keyboard layout (physical A/B/C pedals).
  const aliases:Record<string,'F7'|'F8'|'F9'>={a:'F7',b:'F8',c:'F9'};
  return aliases[event.key.toLowerCase()]||(/^Key[ABC]$/.test(event.code)?aliases[event.code.slice(-1).toLowerCase()]:null);
}
