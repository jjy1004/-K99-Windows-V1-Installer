import type { ReactNode } from 'react';
import { MANUAL_MATERIALS, type LabelSelection } from './manual-label';
import './reception-sidebar.css';
import {PhotoStorageHint} from './PhotoStorageHint';

const COLORS = ['유색', '흰색'] as const;

export function ReceptionSidebar({ labelSelection, onLabelSelection, mobilePanel, onOpenCamera, onFinalConfirm, tagPanel,monitorControls }: {
  labelSelection: LabelSelection;
  onLabelSelection: (v: LabelSelection) => void;
  mobilePanel: ReactNode;
  onOpenCamera: () => void;
  onFinalConfirm: () => void;
  tagPanel?: ReactNode;
  monitorControls?: ReactNode;
}) {
  return (
    <aside className="rcs-sidebar k99-bp-photo" aria-labelledby="k99-bp-h-photo" data-testid="reception-sidebar" data-intake-zone="photos">
      <h2 className="k99-bp-title" id="k99-bp-h-photo">사진 촬영</h2>
      {monitorControls&&<div className="rcs-display-controls" aria-label="고객 모니터 제어">{monitorControls}</div>}
      <PhotoStorageHint/>
      <div className="rcs-mobile">{mobilePanel}</div>
      {tagPanel}
      <section className="rcs-group" aria-label="태그 소재">
        <div className="rcs-label">소재</div>
        <div className="rcs-grid">
          {MANUAL_MATERIALS.map((m) => (
            <button key={m} type="button" className="rcs-btn rcs-material" data-label-choice="material"
              aria-pressed={labelSelection.manualMaterial === m}
              onClick={() => onLabelSelection({ ...labelSelection, manualMaterial: m })}>{m}</button>
          ))}
        </div>
      </section>
      <section className="rcs-group" aria-label="태그 색상">
        <div className="rcs-label">색상</div>
        <div className="rcs-grid">
          {COLORS.map((c) => (
            <button key={c} type="button" className="rcs-btn rcs-color" data-label-choice="color"
              aria-pressed={labelSelection.manualColor === c}
              onClick={() => onLabelSelection({ ...labelSelection, manualColor: c })}>{c}</button>
          ))}
        </div>
      </section>
      <button type="button" className="rcs-btn rcs-camera" onClick={onOpenCamera}>촬영 창 열기</button>
      <button type="button" className="rcs-btn rcs-final" onClick={onFinalConfirm}>접수 내용 최종 확인</button>
    </aside>
  );
}

export default ReceptionSidebar;
