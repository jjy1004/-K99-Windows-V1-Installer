import type { ReactNode } from 'react';
import { MANUAL_MATERIALS, type LabelSelection } from './manual-label';
import './reception-sidebar.css';

const COLORS = ['유색', '흰색'] as const;

export function ReceptionSidebar({ labelSelection, onLabelSelection, mobilePanel, onOpenCamera, onFinalConfirm, tagPanel }: {
  labelSelection: LabelSelection;
  onLabelSelection: (v: LabelSelection) => void;
  mobilePanel: ReactNode;
  onOpenCamera: () => void;
  onFinalConfirm: () => void;
  tagPanel?: ReactNode;
}) {
  return (
    <aside className="rcs-sidebar" aria-label="접수 보조 패널" data-testid="reception-sidebar">
      <div className="rcs-mobile">{mobilePanel}</div>
      {tagPanel}
      <section className="rcs-group" aria-label="태그 소재">
        <div className="rcs-label">소재</div>
        <div className="rcs-grid">
          {MANUAL_MATERIALS.map((m) => (
            <button key={m} type="button" className="rcs-btn rcs-material" data-label-choice="material"
              aria-pressed={labelSelection.manualMaterial === m}
              onClick={() => onLabelSelection({ ...labelSelection, manualMaterial: m })}>{m}</button>
          ))}
        </div>
      </section>
      <section className="rcs-group" aria-label="태그 색상">
        <div className="rcs-label">색상</div>
        <div className="rcs-grid">
          {COLORS.map((c) => (
            <button key={c} type="button" className="rcs-btn rcs-color" data-label-choice="color"
              aria-pressed={labelSelection.manualColor === c}
              onClick={() => onLabelSelection({ ...labelSelection, manualColor: c })}>{c}</button>
          ))}
        </div>
      </section>
      <button type="button" className="rcs-btn rcs-camera" onClick={onOpenCamera}>촬영 창 열기</button>
      <button type="button" className="rcs-btn rcs-final" onClick={onFinalConfirm}>접수 내용 최종 확인</button>
    </aside>
  );
}

export default ReceptionSidebar;
