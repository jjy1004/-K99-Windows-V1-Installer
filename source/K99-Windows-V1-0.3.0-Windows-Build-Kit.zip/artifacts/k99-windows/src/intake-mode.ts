/** Shared manual intake categories; saved draft values remain unchanged. */
export type IntakeMode = 'garment' | 'sneaker' | 'combined';
