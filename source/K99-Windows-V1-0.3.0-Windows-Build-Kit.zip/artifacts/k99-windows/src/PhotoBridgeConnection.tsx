import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'wouter';
import {
  inspectPhotoBridgeConnection, createPhotoBridgeLaunchPairer, PHOTO_BRIDGE_SESSION_EVENT,
} from './photo-bridge-session';
import { createSerializedPoller } from './serialized-poller';
import { listenForPhotoBridgeRecovery, reusePhotoBridgeSession } from './photo-bridge-recovery';

const pairOnStartup = createPhotoBridgeLaunchPairer();

/** Connection status alone: it never means a camera, image or printer was verified. */
// Stage 1 never mounts the legacy pairing UI or its polling/startup effects.
export function PhotoBridgeConnection() { return null; }

function LegacyPhotoBridgeConnection() {
  const [location] = useLocation();
  const customerScreen = location.startsWith('/customer');
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const [failure, setFailure] = useState('');
  const [showPairing, setShowPairing] = useState(false);
  const [pairing, setPairing] = useState(false);
  const needsPairing = useRef(false);
  const pairLock = useRef(false);

  const useExistingSession = async () => {
    const health = await reusePhotoBridgeSession();
    if (health.status !== 'connected' || health.mode !== 'STORE') return false;
    needsPairing.current = false;
    setConnected(health.photoConfigured);
    setFailure(health.photoConfigured ? '' : '인증 성공 · 기존 사진 감시 경로를 확인하지 못했습니다. 설정을 임의로 바꾸지 마세요.');
    setShowPairing(false);
    return true;
  };

  const connect = async () => {
    if (pairLock.current) return;
    pairLock.current = true;
    setPairing(true);
    setFailure('');
    try {
      if (!await useExistingSession()) {
        setShowPairing(true);
        setFailure('사용 가능한 운영 인증 세션을 찾지 못했습니다. 아래 운영용 연결 파일을 선택하세요.');
      }
    } finally { pairLock.current = false; setPairing(false); setConnecting(false); }
  };

  const authenticate = async (file: File) => {
    if (pairLock.current) return;
    pairLock.current = true;
    setPairing(true);
    setFailure('');
    try {
      if (await useExistingSession()) return;
      if (file.size > 100_000) throw new Error('도우미가 만든 K99_CONNECT.html 파일을 선택하세요.');
      const html = await file.text();
      const href = html.match(/href="([^"]*#k99-bridge-pair=[^"]*)"/)?.[1];
      if (!href) throw new Error('연결 코드가 없습니다. 현재 도우미의 K99_CONNECT.html을 선택하세요.');
      const url = new URL(href.replace(/&amp;/g, '&'));
      if (url.origin !== window.location.origin) throw new Error('다른 사이트용 파일입니다. 운영 사이트에서 운영용 Runtime의 K99_CONNECT.html을 선택하세요.');
      const code = new URLSearchParams(url.hash.slice(1)).get('k99-bridge-pair');
      if (!code) throw new Error('일회용 연결 코드가 없습니다.');
      await pairOnStartup(code);
      needsPairing.current = false;
      const health = await inspectPhotoBridgeConnection();
      if (health.status !== 'connected') throw new Error('인증 후 연결 확인 실패. 로컬 네트워크 허용과 도우미 실행 상태를 확인하세요.');
      setConnected(health.mode === 'STORE' && health.photoConfigured);
      setFailure(health.photoConfigured ? '' : '인증 성공 · 사진 감시 경로를 확인하지 못했습니다. 기존 설정을 임의로 바꾸지 마세요.');
      setShowPairing(!health.photoConfigured);
    } catch (error) {
      setConnected(false);
      setFailure(error instanceof Error ? error.message : '인증 실패. 연결 파일을 다시 확인하세요.');
    } finally { pairLock.current = false; setPairing(false); setConnecting(false); }
  };

  useEffect(() => {
    if (customerScreen) return;
    const stopRecoveryHandoff = listenForPhotoBridgeRecovery();
    let live = true;
    const poller = createSerializedPoller(async () => {
      if (pairLock.current) return;
      const health = await inspectPhotoBridgeConnection();
      const result = health.status === 'connected' && health.mode === 'STORE' && health.photoConfigured;
      if (!live) return;
      setConnected(result);
      setConnecting(false);
      if (health.status === 'unpaired') {
        needsPairing.current = true;
        setFailure(previous => previous.startsWith('/v1/pair') ? previous :
          'HTTP 401 · 이 탭에 유효한 인증이 없습니다. 연결·인증 버튼으로 기존 운영 인증 탭을 먼저 확인하세요.');
      } else if (health.status === 'offline') {
        setFailure('도우미에 접속할 수 없습니다. 실행 상태와 브라우저의 로컬 네트워크 허용을 확인하세요.');
      } else if (health.status === 'incompatible') {
        setFailure(`연결 응답 확인 실패 (HTTP ${health.httpStatus}). 운영 사이트와 운영용 도우미 실행 상태를 확인하세요.`);
      }
      if (result) { needsPairing.current = false; setConnecting(false); setFailure(''); setShowPairing(false); }
    }, 4000);
    const changed = () => { needsPairing.current = false; setConnected(false); poller.trigger(); };
    const resume = () => poller.trigger();
    const visibilityChanged = () => {
      if (document.visibilityState === 'visible') poller.trigger();
    };
    const launchPairing = () => {
      setConnecting(true);
      void pairOnStartup().catch(async (error: unknown) => {
        if (await useExistingSession()) return;
        setFailure(error instanceof Error ? error.message : 'Photo Bridge 자동 연결 실패');
        // No token/code or long network errors are ever displayed to staff.
        console.warn('Photo Bridge 자동 연결 실패. 연결 상태를 확인하지 못했습니다.');
      }).finally(() => { if (live) { setConnecting(false); poller.trigger(); } });
    };
    window.addEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
    window.addEventListener('hashchange', launchPairing);
    window.addEventListener('pushState', launchPairing);
    window.addEventListener('replaceState', launchPairing);
    window.addEventListener('popstate', launchPairing);
    window.addEventListener('online', resume);
    document.addEventListener('visibilitychange', visibilityChanged);
    poller.start();
    launchPairing();
    return () => {
      live = false;
      stopRecoveryHandoff();
      poller.stop();
      window.removeEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
      window.removeEventListener('hashchange', launchPairing);
      window.removeEventListener('pushState', launchPairing);
      window.removeEventListener('replaceState', launchPairing);
      window.removeEventListener('popstate', launchPairing);
      window.removeEventListener('online', resume);
      document.removeEventListener('visibilitychange', visibilityChanged);
    };
  }, [customerScreen]);

  if (customerScreen) return null;
  return <div role="status" aria-live="polite" data-testid="photo-bridge-connection"
    style={{ padding: '8px 24px', fontSize: 14, color: connected ? '#72d6b5' : '#b7c4c8', background: '#091c20' }}>
    {connected ? '사진 촬영 연결됨' : connecting ? '사진촬영 연결 확인 중' :
      failure ? '사진 도우미 인증 연결을 확인해 주세요.' : '사진촬영 연결 확인 필요'}
    <button type="button" disabled={pairing} onClick={() => void connect()}
      style={{ marginLeft: 16, padding: '10px 16px', background: '#e7ff70', color: '#102321', borderRadius: 8, fontWeight: 700 }}>
      {pairing ? '인증 중…' : '포토브리지 연결·인증'}
    </button>
    {failure && <p role="alert">{failure}</p>}
    {showPairing && <section aria-label="포토브리지 인증 안내">
      <p>현재 실행 중인 운영용 도우미가 만든 K99_CONNECT.html을 선택하세요. 파일은 실행하거나 업로드하지 않고 일회용 코드만 로컬 인증에 사용합니다.</p>
      <p>파일 위치: %LOCALAPPDATA%\K99K59PhotoHelper\Runtime\K99_CONNECT.html</p>
      <label>연결 파일 선택 <input type="file" accept=".html,.htm" disabled={pairing}
        onChange={event => { const file = event.target.files?.[0]; event.target.value = ''; if (file) void authenticate(file); }} /></label>
      <p>자동으로 열린 운영 인증 탭은 닫지 마세요. 이 버튼은 같은 브라우저 프로필의 인증된 운영 탭을 먼저 확인합니다.</p>
      <p>인증된 탭이 없고 코드가 만료·사용된 경우에만 촬영·인쇄 종료 후 기존 운영용 CMD를 정상 종료하고 같은 실행 도구로 한 번 재시작하세요. 자동 인증된 탭을 열어 둔 채 이 화면의 연결·인증 버튼을 누르세요. 자동 인증이 안 되면 생성 후 5분 안에 새 파일을 선택하세요. 설정·장부·브라우저 저장소는 삭제하지 마세요.</p>
    </section>}
  </div>;
}