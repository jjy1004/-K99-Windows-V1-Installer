import { useEffect, useState } from 'react';
import { AccountlessNoticeActions } from './LocalNoticeDialogs';
import type { ConfirmedOrder } from './order-record';
import { careLabelConflict, originalCleaningMethod } from './inspection-record';
import { noticeResponses, recordItemNoticeResponse, updateItemNotice, type NoticeStage } from './item-notice';

type Props = { order: ConfirmedOrder; onSave: (order: ConfirmedOrder) => void };
const stages: NoticeStage[] = [1, 2, 3];
const won = (value: number) => `${value.toLocaleString('ko-KR')}원`;

export function ItemNoticePanel({ order, onSave }: Props) {
  const inspection = order.inspection!;
  const notice = inspection.itemNotice!;
  const currentStage = notice.activeStep ?? (notice.outcome === 'informational' ? 1 : null);
  const currentMessage = currentStage ? notice.steps[currentStage]?.message ?? '' : '';
  const [message, setMessage] = useState(currentMessage);
  const [staffName, setStaffName] = useState('');
  const [choice, setChoice] = useState('');
  const [respondedAt, setRespondedAt] = useState('');
  const [content, setContent] = useState('');
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    setMessage(currentMessage);
    setChoice('');
    setRespondedAt('');
    setContent('');
    setError('');
  }, [currentStage, currentMessage]);

  function update(step: NoticeStage, action: 'generate' | 'review' | 'ready') {
    try {
      const updated = updateItemNotice(order, step, action, message, staffName);
      onSave(updated);
      setMessage(updated.inspection!.itemNotice!.steps[step]!.message);
      setFeedback(action === 'generate' ? '현재 검수 기록에서 문안을 다시 생성했습니다.'
        : action === 'review' ? '직원이 문안을 확인했습니다. 실제 발송은 되지 않았습니다.'
          : '카카오톡/SNS 발송 준비를 기록했습니다. 실제 발송은 되지 않았습니다.');
      setError('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '문안을 기록하지 못했습니다.'); }
  }

  function respond(step: NoticeStage) {
    try {
      onSave(recordItemNoticeResponse(order, step, choice, content, staffName, respondedAt || undefined));
      setFeedback('직원이 실제 고객 회신을 확인해 기록했습니다.');
      setError('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '고객 회신을 기록하지 못했습니다.'); }
  }

  return <section className="professional-inspection__panel professional-inspection__staged"
    data-testid="inspection-item-notice">
    <div className="professional-inspection__section-heading">
       <h2>고객 안내 및 동의</h2><span>직원 검토 · 실제 발송 아님</span>
    </div>
    <p>선택한 품목별 위험·추가 작업으로 초안을 생성했습니다. 필요한 단계의 고객 회신을 직원이 직접 확인하기 전에는 다음 단계가 열리지 않습니다.</p>
    <div className="professional-inspection__staged-outcome" role="status" data-testid="item-notice-outcome">
      <span>현재 메시지 단계</span>
      <strong>{notice.outcome === 'informational' ? '위험 정보 안내만 · 별도 동의 불필요'
        : notice.outcome === 'approved' ? '필요한 고객 동의 완료 · 세탁 진행 가능'
          : notice.outcome === 'held' ? '고객 거절/문의 · 직원 검토 대기'
            : `${notice.activeStep}단계 · ${notice.activeStep === 1 ? '작업 필요 확인'
              : notice.activeStep === 2 ? '위험 및 면책 확인' : '금액 확인'}`}</strong>
    </div>
    <div className="professional-inspection__notice-item">
      <strong>초안 생성 이유 · 검수 기록</strong>
      {notice.itemIndexes.map((index) => {
        const item = inspection.items[index];
        const selectedWork = item.additionalWork.filter((work) => work !== '추가 작업 없음');
        return <dl key={`${item.itemId}-${index}`} data-testid={`item-notice-reason-${index}`}>
          <div><dt>대상 품목</dt><dd>{order.items[index].displayNameKo} × {order.items[index].quantity}</dd></div>
          <div><dt>품목별 위험 요소</dt><dd>{item.riskFactors?.join('·') || '없음'}</dd></div>
          <div><dt>추가 작업</dt><dd>{selectedWork.join('·') || '없음'}{item.additionalWorkDescription && selectedWork.length
            ? ` · ${item.additionalWorkDescription}` : ''}</dd></div>
          <div><dt>현재 / 제안 세탁방법</dt><dd>{originalCleaningMethod(order, inspection, index) ?? '접수 시 확인되지 않음'}
            {' → '}{item.actualCleaningMethod ?? '해당 없음'}</dd></div>
          {item.method !== '기존 방법 유지' && <div><dt>접수 / 권장 서비스</dt>
            <dd>{inspection.originalMethods[index]} → {item.method === '기타' ? item.customMethod : item.method}</dd></div>}
          <div><dt>케어라벨 불일치</dt><dd>{careLabelConflict(item) ? '있음' : '없음'}</dd></div>
        </dl>;
      })}
      <p>면책 동의 필요: {notice.waiverConsent ? '예' : '아니요'} · 추가요금: {inspection.additionalCharge
        ? won(inspection.additionalCharge) : '없음'}</p>
    </div>
    <div className="professional-inspection__staged-steps">
      {stages.map((step) => {
        const record = notice.steps[step];
        if (!record && ((step === 2 && !notice.riskConsent) || (step === 3 && !notice.priceConsent))) return null;
        const active = currentStage === step;
        return <section key={step} className={`professional-inspection__staged-step${!record ? ' professional-inspection__staged-step--locked' : ''}`}
          data-testid={`item-notice-stage-${step}`} aria-label={`${step}단계 고객 안내`}>
          <div className="professional-inspection__staged-step-head">
            <span className="professional-inspection__staged-number">{String(step).padStart(2, '0')}</span>
            <div><h3>{step === 1 ? '작업 필요 · 위험 정보 안내' : step === 2 ? '위험 / 면책 동의' : '추가금액 확인'}</h3>
              <span>{!record ? '이전 단계 동의 후 열림' : active ? '현재 단계' : '회신 확인됨'}</span></div>
          </div>
          {!record ? <p>이전 단계의 고객 답변을 직원이 확인하면 문안이 열립니다.</p> : <>
            {record.response && <p data-testid={`item-notice-response-${step}`}>고객 회신: {record.response.choice}
              {' · '}{new Date(record.response.respondedAt).toLocaleString('ko-KR')}
              {' · 확인 직원 '}{record.response.staffName}{record.response.content && ` · ${record.response.content}`}</p>}
            {active ? <>
               <label className="professional-inspection__field">메시지 초안 · 수정 가능
                <textarea rows={7} value={message} onChange={(event) => setMessage(event.target.value)}
                  data-testid={`item-notice-message-${step}`} />
              </label>
              <AccountlessNoticeActions recipient={order.customerPhone} body={message}/>
              <label className="professional-inspection__field">확인 직원 · 필수
                <input value={staffName} onChange={(event) => setStaffName(event.target.value)}
                  data-testid={`item-notice-staff-${step}`} />
              </label>
              <div className="professional-inspection__actions">
                <button type="button" onClick={() => update(step, 'generate')}
                   data-testid={`button-item-notice-generate-${step}`}>초안 다시 생성</button>
                <button type="button" onClick={() => update(step, 'review')}
                  data-testid={`button-item-notice-review-${step}`}>직원 확인 완료</button>
                <button type="button" className="professional-inspection__primary" onClick={() => update(step, 'ready')}
                   data-testid={`button-item-notice-ready-${step}`}>고객에게 발송 준비</button>
              </div>
              {record.reviewedAt && <p>직원 확인: {record.reviewedBy} · {new Date(record.reviewedAt).toLocaleString('ko-KR')}</p>}
              {record.readyAt && <p role="status">발송 준비: {record.readyBy} · {new Date(record.readyAt).toLocaleString('ko-KR')} · 실제 발송 아님</p>}
              {notice.outcome !== 'informational' && <>
                <label className="professional-inspection__field">고객 회신 · 직원이 직접 선택
                  <select value={choice} onChange={(event) => setChoice(event.target.value)}
                    data-testid={`item-notice-choice-${step}`}>
                    <option value="">선택해 주세요</option>
                     {noticeResponses(notice, step).map((option) => <option key={option} value={option}>
                       {option === '진행 동의' ? '동의' : option === '진행 거절' || option.endsWith('거절')
                         ? '동의하지 않음' : option === '문의/보류' ? '고객 문의 / 보류'
                           : option === '추가금액 동의' ? '금액 동의' : option}
                     </option>)}
                  </select>
                </label>
                <label className="professional-inspection__field">실제 고객 회신 일시
                  <input type="datetime-local" value={respondedAt} onChange={(event) => setRespondedAt(event.target.value)} />
                </label>
                <label className="professional-inspection__field">회신 내용 · 확인 메모
                  <textarea value={content} onChange={(event) => setContent(event.target.value)} />
                </label>
                <button type="button" className="professional-inspection__primary"
                  disabled={!record.readyAt || message !== record.message} onClick={() => respond(step)}
                   data-testid={`button-item-notice-response-${step}`}>고객 응답 기록</button>
              </>}
            </> : <p>확인 당시 문안: {record.message}</p>}
          </>}
        </section>;
      })}
    </div>
    {feedback && <p role="status">{feedback}</p>}
    {error && <p className="professional-inspection__error" role="alert">{error}</p>}
  </section>;
}