import { useEffect, useState } from 'react';
import { AccountlessNoticeActions } from './LocalNoticeDialogs';
import { MessageSquareText, Copy } from 'lucide-react';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import {
  PICKUP_KIND_LABELS, formatKoreanDate, kindsForStage, markPickupNoticeSent, pickupNoticeTargets, pickupNoticeText,
  type PickupNoticeKind, type PickupNoticeTarget,
} from './customer-pickup-notices';

/** Today center: customers whose post-completion pickup/delivery/uncollected notice is still unsent. */
export function PickupNoticeStage({ orders, asOf, disabled, onChanged }: {
  orders: ConfirmedOrder[]; asOf: string; disabled: boolean; onChanged: () => void;
}) {
  const targets = pickupNoticeTargets(orders, new Date(`${asOf}T12:00:00+09:00`));
  const [openId, setOpenId] = useState<string | null>(null);
  const [kind, setKind] = useState<PickupNoticeKind | null>(null);
  const [text, setText] = useState('');
  const [status, setStatus] = useState<{ kind: 'ok' | 'error'; message: string } | null>(null);
  const open = targets.find((target) => target.orderId === openId) ?? null;

  useEffect(() => { if (openId && !open) { setOpenId(null); setKind(null); } }, [openId, open]);

  function choose(target: PickupNoticeTarget, next: PickupNoticeKind) {
    const order = orders.find((item) => item.id === target.orderId);
    if (!order) return;
    setKind(next);
    setText(pickupNoticeText(order, next));
    setStatus(null);
  }
  function toggle(target: PickupNoticeTarget) {
    if (openId === target.orderId) { setOpenId(null); setKind(null); return; }
    setOpenId(target.orderId);
    setStatus(null);
    const kinds = kindsForStage(target.stage);
    if (kinds.length === 1) choose(target, kinds[0]); else { setKind(null); setText(''); }
  }
  async function copy() {
    // Copying never marks the notice as sent.
    try { await navigator.clipboard.writeText(text); setStatus({ kind: 'ok', message: '문안을 복사했습니다. 카카오톡 또는 문자 버튼으로 작성창을 열 수 있습니다.' }); }
    catch { setStatus({ kind: 'error', message: '복사하지 못했습니다. 문안을 직접 선택해 복사해 주세요.' }); }
  }
  function confirmSent(target: PickupNoticeTarget) {
    if (!kind) return;
    try {
      const stored = readConfirmedOrders().find((order) => order.id === target.orderId);
      if (!stored) throw new Error('주문을 찾지 못했습니다.');
      updateSavedOrder(markPickupNoticeSent(stored, target.stage, kind), stored);
      setStatus({ kind: 'ok', message: `${target.customerName} 고객 ${PICKUP_KIND_LABELS[kind]} 발송 완료를 기록했습니다. 출고 상태는 바뀌지 않습니다.` });
      setOpenId(null); setKind(null);
      onChanged();
    } catch (cause) {
      setStatus({ kind: 'error', message: cause instanceof Error ? cause.message : '발송 완료를 기록하지 못했습니다.' });
      throw cause;
    }
  }

  return (
    <div className="toc-pickup-notices" data-testid="pickup-notice-stage">
      <h3>세탁 완료 후 수거·배달 안내 · {targets.length}명</h3>
      {status && <p role={status.kind === 'error' ? 'alert' : 'status'} className={`toc-pickup-status is-${status.kind}`}
        data-testid="status-pickup-notice">{status.message}</p>}
      {targets.length === 0 ? <p className="toc-pickup-empty">미발송 안내가 없습니다. 실제 수거·배달 완료 고객은 자동으로 제외됩니다.</p> :
        <ul>{targets.map((target) => <li key={target.orderId} data-testid={`pickup-notice-${target.orderId}`} data-stage={target.stage}>
          <button type="button" className="toc-pickup-target" aria-expanded={openId === target.orderId}
            onClick={() => toggle(target)} data-testid={`button-pickup-notice-${target.orderId}`}>
            <MessageSquareText aria-hidden="true" />
            <span><strong>{target.customerName}</strong> · {target.customerPhone}</span>
            <em className={`toc-pickup-label is-${target.stage}`}>{target.label}</em>
            <small>접수 {formatKoreanDate(target.intakeDate)} · 완료 {formatKoreanDate(target.completedDate)}</small>
          </button>
          {openId === target.orderId && <div className="toc-pickup-draft">
            {kindsForStage(target.stage).length > 1 && <div className="toc-pickup-kinds" role="radiogroup" aria-label="안내 종류 선택">
              {kindsForStage(target.stage).map((option) => <button key={option} type="button" role="radio" aria-checked={kind === option}
                className={kind === option ? 'is-active' : ''} onClick={() => choose(target, option)}
                data-testid={`button-pickup-kind-${option}`}>{PICKUP_KIND_LABELS[option]}{option === 'delivery' && target.deliveryRequested ? ' (배달 요청 고객)' : ''}</button>)}
            </div>}
            {kind && <>
              <label>안내 문안 · 발송 전 확인·수정 가능
                <textarea value={text} rows={10} onChange={(event) => setText(event.target.value)} data-testid="textarea-pickup-notice" />
              </label>
              <AccountlessNoticeActions recipient={target.customerPhone} body={text} disabled={disabled} orderId={target.orderId}
                onCompleted={()=>confirmSent(target)}
                templateId={kind==='direct-pickup'?'complete-pickup':kind==='delivery'?'complete-delivery':kind==='day7'?'reminder-7':'storage-15'}/>
              <div className="toc-pickup-actions">
                <button type="button" onClick={copy} data-testid="button-copy-pickup-notice"><Copy aria-hidden="true" /> 문안 복사</button>
              </div>
              <p className="toc-pickup-help">카카오톡·문자 버튼을 누르면 발송 완료로 기록합니다. 실제 전송은 열린 앱에서 해 주세요. 출고 상태는 바뀌지 않습니다.</p>
            </>}
          </div>}
        </li>)}</ul>}
    </div>
  );
}
