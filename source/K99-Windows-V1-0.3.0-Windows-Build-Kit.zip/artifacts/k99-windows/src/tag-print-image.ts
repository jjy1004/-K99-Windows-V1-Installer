import bwipjs from 'bwip-js/browser';
import type { GarmentTagData } from './garment-record';
import type { PhotoBridgeTagTemplate } from './passive-photo-client';
import { resolvePhotoBridgeTagElements } from './photo-tag-jobs';

/** Rasterize the same fields, positions and barcode used by GarmentTagPreview. */
export function renderTagForWindows(tag: GarmentTagData, template: PhotoBridgeTagTemplate) {
  const dpi = 203;
  const dotsPerMm = dpi / 25.4;
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(template.page.widthMm * dotsPerMm);
  canvas.height = Math.round(template.page.heightMm * dotsPerMm);
  const context = canvas.getContext('2d');
  if (!context) throw new Error('태그 인쇄 이미지를 만들 수 없습니다.');
  context.fillStyle = '#fff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  const fontFamily = getComputedStyle(document.body).fontFamily || 'sans-serif';
  for (const { element, value } of resolvePhotoBridgeTagElements(template, tag)) {
    const x = element.xMm * dotsPerMm;
    const y = element.yMm * dotsPerMm;
    const width = element.widthMm * dotsPerMm;
    const height = element.heightMm * dotsPerMm;
    context.save();
    context.beginPath();
    context.rect(x, y, width, height);
    context.clip();
    if (element.type === 'code') {
      const barcode = document.createElement('canvas');
      bwipjs.toCanvas(barcode, {
        bcid: element.kind === 'qr' ? 'qrcode' : 'code128',
        text: tag.garmentId,
        scale: element.kind === 'qr' ? 3 : 2,
        height: element.heightMm,
        includetext: false,
      });
      context.imageSmoothingEnabled = false;
      context.drawImage(barcode, x, y, width, height);
    } else {
      const fontSize = element.fontSizePt * dpi / 72;
      context.font = `${element.bold ? 700 : 400} ${fontSize}px ${fontFamily}`;
      context.fillStyle = '#17232c';
      context.textBaseline = 'top';
      let line = '';
      let lineY = y;
      for (const character of value) {
        if (character === '\n' || (line && context.measureText(line + character).width > width)) {
          context.fillText(line, x, lineY);
          lineY += fontSize * 1.08;
          line = '';
          if (character === '\n') continue;
        }
        line += character;
      }
      if (line) context.fillText(line, x, lineY);
    }
    context.restore();
  }
  // Real STORE labels contain the tag fields/barcode only, not the preview's
  // TEST/PENDING verification watermark.
  return {
    pngBase64: canvas.toDataURL('image/png').split(',')[1],
    widthMm: template.page.widthMm,
    heightMm: template.page.heightMm,
    templateId: template.id,
    garmentId: tag.garmentId,
  };
}