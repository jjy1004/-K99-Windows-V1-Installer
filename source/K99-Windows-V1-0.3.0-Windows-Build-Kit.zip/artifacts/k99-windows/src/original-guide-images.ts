/** 사용자 제공 원본 파일. 리사이즈·재인코딩·덧그리기 없이 정적 리소스로 배포한다. */
export const ORIGINAL_GUIDE_IMAGES = [
  { file: '01-link-login.png', title: '받은 링크 · 크롬으로 열기 · 최초 로그인', source: 'image_1795585635440.png' },
  { file: '02-trial-install.png', title: '무료 체험 · 홈 화면에 아이콘 설치', source: 'image_1795585692427.png' },
  { file: '03-trial-install-original.png', title: '홈 화면 설치 안내 · 추가로 제공한 원본', source: 'image_1795585705649.png' },
  { file: '04-select-search.jpg', title: '선택 검색 · 세탁법과 얼룩 종류 고르기', source: 'KakaoTalk_261125_150039_11_1795586962873.jpg' },
  { file: '05-voice-search.jpg', title: '음성 검색 · 라벨과 얼룩 촬영', source: 'KakaoTalk_261125_150039_21_1795586962873.jpg' },
  { file: '06-ai-home.jpg', title: 'AI 세탁 처방 · 첫 화면 메뉴', source: 'KakaoTalk_261125_150039_31_1795586962874.jpg' },
  { file: '07-chemical-order.jpg', title: '케미컬 주문 · 품목 선택', source: 'KakaoTalk_261125_150606_1795586962874.jpg' },
] as const;

export const GUIDE_USB_NOTICE = '※ 촬영용 휴대폰은 Wi-Fi를 끄고 반드시 USB 데이터 케이블로 PC 본체 뒷면에 직접 연결합니다. (개인 휴대폰의 [폰 정밀 촬영] QR 업로드 기능은 기존과 동일하게 Wi-Fi로 정상 작동합니다)';
