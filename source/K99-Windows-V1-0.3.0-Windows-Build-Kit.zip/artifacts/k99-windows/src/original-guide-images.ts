/** 사용자 제공 원본 파일. 리사이즈·재인코딩·덧그리기 없이 정적 리소스로 배포한다. */
export const CAMERA_GUIDE_IMAGES = [
  { file: '08-usb-camera-part1.png', title: '1탄 · 최초 준비 1~4단계', source: 'Gemini_Generated_Image_9okcv89okcv89okc_1795592455803.png' },
  { file: '09-usb-camera-part2.png', title: '2탄 · 연결과 사용 5~7단계', source: 'Gemini_Generated_Image_og3k3fog3k3fog3k_1795592455802.png' },
] as const;

export const GUIDE_USB_NOTICE = '※ 촬영용 휴대폰은 Wi-Fi를 끄고 반드시 USB 데이터 케이블로 PC 본체 뒷면에 직접 연결합니다. (개인 휴대폰의 [폰 정밀 촬영] QR 업로드 기능은 기존과 동일하게 Wi-Fi로 정상 작동합니다)';
