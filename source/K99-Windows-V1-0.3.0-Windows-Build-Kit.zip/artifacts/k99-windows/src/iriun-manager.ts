import {IRIUN_MAX_ATTEMPTS, iriunFailure, openIriunCamera} from './iriun-camera';
import {createIriunContext, type IriunContext} from './iriun-context';
import {showCameraVideo} from './camera-video';
import {watchIriunStream} from './iriun-health';

export type CameraState = {
  phase: 'idle' | 'connecting' | 'ready' | 'error' | 'blocked';
  attempt: number;
  stream: MediaStream | null;
  deviceId: string;
  message: string;
};
type Binding = {
  video: () => HTMLVideoElement | null;
  change: (state: CameraState) => void;
  prepare?: () => void;
  released?: () => void;
};
type Session = {
  owner: object; binding: Binding; abort: AbortController; context?: IriunContext;
  stream?: MediaStream; video?: HTMLVideoElement; unwatch?: () => void;
  run?: Promise<void>; cooldown?: () => void; unlisten: (() => void)[];
  failedId?: string; state: CameraState;
};
type Dependencies = {
  context?: typeof createIriunContext;
  open?: typeof openIriunCamera;
  show?: typeof showCameraVideo;
  watch?: typeof watchIriunStream;
  delay?: (signal: AbortSignal, ms: number) => Promise<void>;
  schedule?: (fn: () => void, ms: number) => () => void;
  events?: EventTarget;
  page?: EventTarget & {hidden?: boolean};
};
export const idleCamera = (): CameraState => ({
  phase: 'idle', attempt: 0, stream: null, deviceId: '', message: '',
});
function delay(signal: AbortSignal, ms: number) {
  return new Promise<void>((resolve, reject) => {
    const abort = () => { clearTimeout(timer); reject(new DOMException('촬영 종료', 'AbortError')); };
    const timer = setTimeout(() => {signal.removeEventListener('abort', abort); resolve();}, ms);
    signal.addEventListener('abort', abort, {once: true});
    if (signal.aborted) abort();
  });
}

/** Single owner for BOTH capture surfaces. Business data, image capture,
 * zoom/pan, label jobs and order saving remain in their existing components. */
export function createIriunManager(deps: Dependencies = {}) {
  let session: Session | undefined;
  const events = deps.events ?? globalThis.window;
  const page = deps.page ?? globalThis.document;
  const schedule = deps.schedule ?? ((fn, ms) => {const id = setTimeout(fn, ms); return () => clearTimeout(id);});
  const current = (s: Session) => session === s && !s.abort.signal.aborted;
  function publish(s: Session, patch: Partial<CameraState>) {
    if (!current(s)) return;
    s.state = {...s.state, ...patch};
    s.binding.change(s.state);
  }
  function release(s: Session) {
    s.unwatch?.(); s.unwatch = undefined;
    s.stream?.getTracks().forEach(t => t.stop());
    if (s.video && s.video.srcObject === s.stream) s.video.srcObject = null;
    s.stream = undefined; s.video = undefined;
    s.context?.dispose(); s.context = undefined;
  }
  function stop(owner: object) {
    const s = session;
    if (!s || s.owner !== owner) return;
    s.abort.abort(); s.cooldown?.(); s.unlisten.forEach(fn => fn()); release(s);
    session = undefined;
    s.binding.released?.();
    s.binding.change(idleCamera());
  }
  function restart(s: Session) {
    if (!current(s) || s.run) return;
    s.cooldown?.(); s.cooldown = undefined;
    release(s);
    s.run = connect(s).finally(() => {s.run = undefined;});
  }
  async function connect(s: Session) {
    s.binding.prepare?.();
    for (let attempt = 1; attempt <= IRIUN_MAX_ATTEMPTS && current(s); attempt++) {
      publish(s, {phase: 'connecting', attempt, stream: null,
        message: `Iriun 자동 연결 중 · ${attempt}/${IRIUN_MAX_ATTEMPTS}회`});
      try {
        // A timed-out native request cannot lock the POS document: each failed
        // attempt retires its camera document before creating the next one.
        s.context = await (deps.context ?? createIriunContext)(s.abort.signal);
        if (!current(s)) {release(s); return;}
        const context = s.context;
        const changed = () => {if (current(s) && s.state.phase !== 'ready') restart(s);};
        context.media.addEventListener?.('devicechange', changed);
        const dispose = context.dispose;
        context.dispose = () => {
          context.media.removeEventListener?.('devicechange', changed); dispose();
        };
        const stream = await (deps.open ?? openIriunCamera)(context.media, s.abort.signal, undefined, 6000,
          {attempts: 1, avoidDeviceId: s.failedId});
        if (!current(s)) {stream.getTracks().forEach(t => t.stop()); release(s); return;}
        s.stream = stream;
        const video = s.binding.video();
        if (!video) throw Error('촬영 화면이 준비되지 않았습니다.');
        s.video = video;
        await (deps.show ?? showCameraVideo)(video, stream);
        if (!current(s)) {release(s); return;}
        const id = stream.getVideoTracks()[0]?.getSettings().deviceId || '';
        s.failedId = undefined;
        s.unwatch = (deps.watch ?? watchIriunStream)(video, stream, {
          isCurrent: () => current(s) && s.stream === stream,
          recover: reason => {
            if (!current(s)) return;
            s.failedId = id; publish(s, {message: reason});
            restart(s);
          },
        });
        publish(s, {phase: 'ready', deviceId: id, stream, message: ''});
        return;
      } catch (error) {
        release(s);
        if (!current(s)) return;
        const blocked = ['NotAllowedError', 'SecurityError'].includes((error as Error)?.name);
        if (blocked || attempt === IRIUN_MAX_ATTEMPTS) {
          publish(s, {phase: blocked ? 'blocked' : 'error', stream: null,
            message: blocked ? iriunFailure(error) :
              `${iriunFailure(error)} 30초 후 다시 자동 연결합니다. 휴대폰의 Iriun 앱을 켜 주세요.`});
          if (!blocked) s.cooldown = schedule(() => restart(s), 30000);
          return;
        }
        publish(s, {message: `${iriunFailure(error)} · 촬영 환경을 다시 준비합니다.`});
        try {await (deps.delay ?? delay)(s.abort.signal, 1000);} catch {return;}
      }
    }
  }
  function start(owner: object, binding: Binding): Promise<void> {
    if (session && session.owner !== owner) {
      binding.change({...idleCamera(), phase: 'error', message: '다른 촬영 창을 닫은 후 다시 연결해 주세요.'});
      return Promise.resolve();
    }
    if (!session) {
      const s: Session = {owner, binding, abort: new AbortController(), unlisten: [], state: idleCamera()};
      session = s;
      const recover = () => restart(s);
      for (const name of ['k99-camera-resume', 'online', 'pageshow']) {
        events?.addEventListener(name, recover);
        s.unlisten.push(() => events?.removeEventListener(name, recover));
      }
      const visible = () => {if (!page?.hidden && s.state.phase !== 'ready') restart(s);};
      page?.addEventListener('visibilitychange', visible);
      s.unlisten.push(() => page?.removeEventListener('visibilitychange', visible));
    } else session.binding = binding;
    const s = session;
    if (s.run) return s.run;
    restart(s);
    return s.run ?? Promise.resolve();
  }
  return {start, stop, state: () => session?.state ?? idleCamera()};
}
export const iriunCameraManager = createIriunManager();
