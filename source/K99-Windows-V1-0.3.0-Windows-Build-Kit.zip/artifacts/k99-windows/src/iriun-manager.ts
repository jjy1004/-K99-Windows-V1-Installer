import {IRIUN_MAX_ATTEMPTS, iriunFailure, openIriunCamera} from './iriun-camera';
import {createIriunContext, type IriunContext} from './iriun-context';
import {showCameraVideo} from './camera-video';
import {watchIriunStream} from './iriun-health';
import {createIriunFreshness, IRIUN_RECONNECT_MESSAGE, type IriunFreshness} from './iriun-freshness';

export type CameraState = {
  phase: 'idle' | 'connecting' | 'ready' | 'error' | 'blocked';
  attempt: number;
  stream: MediaStream | null;
  deviceId: string;
  message: string;
};
type Binding = {
  video: () => HTMLVideoElement | null;
  change: (state: CameraState) => void;
  prepare?: () => void;
  released?: () => void;
};
type Session = {
  owner: object; binding: Binding; abort: AbortController; context?: IriunContext;
  stream?: MediaStream; video?: HTMLVideoElement; unwatch?: () => void;
  run?: Promise<void>; cooldown?: () => void; unlisten: (() => void)[];
  failedId?: string; state: CameraState;
  freshness: IriunFreshness;
};
type Dependencies = {
  context?: typeof createIriunContext;
  open?: typeof openIriunCamera;
  show?: typeof showCameraVideo;
  watch?: typeof watchIriunStream;
  delay?: (signal: AbortSignal, ms: number) => Promise<void>;
  schedule?: (fn: () => void, ms: number) => () => void;
  events?: EventTarget;
  page?: EventTarget & {hidden?: boolean};
  freshness?: () => IriunFreshness;
};
export const idleCamera = (): CameraState => ({
  phase: 'idle', attempt: 0, stream: null, deviceId: '', message: '',
});
function delay(signal: AbortSignal, ms: number) {
  return new Promise<void>((resolve, reject) => {
    const abort = () => { clearTimeout(timer); reject(new DOMException('촬영 종료', 'AbortError')); };
    const timer = setTimeout(() => {signal.removeEventListener('abort', abort); resolve();}, ms);
    signal.addEventListener('abort', abort, {once: true});
    if (signal.aborted) abort();
  });
}

/** Single owner for BOTH capture surfaces. Business data, image capture,
 * zoom/pan, label jobs and order saving remain in their existing components. */
export function createIriunManager(deps: Dependencies = {}) {
  let session: Session | undefined;
  const events = deps.events ?? globalThis.window;
  const page = deps.page ?? globalThis.document;
  const schedule = deps.schedule ?? ((fn, ms) => {const id = setTimeout(fn, ms); return () => clearTimeout(id);});
  const current = (s: Session) => session === s && !s.abort.signal.aborted;
  function publish(s: Session, patch: Partial<CameraState>) {
    if (!current(s)) return;
    s.state = {...s.state, ...patch};
    s.binding.change(s.state);
  }
  function release(s: Session) {
    s.unwatch?.(); s.unwatch = undefined;
    s.stream?.getTracks().forEach(t => t.stop());
    if (s.video && s.video.srcObject === s.stream) s.video.srcObject = null;
    s.stream = undefined; s.video = undefined;
    s.context?.dispose(); s.context = undefined;
  }
  function stop(owner: object) {
    const s = session;
    if (!s || s.owner !== owner) return;
    s.abort.abort(); s.cooldown?.(); s.unlisten.forEach(fn => fn()); release(s);
    session = undefined;
    s.binding.released?.();
    s.binding.change(idleCamera());
  }
  function restart(s: Session) {
    if (!current(s) || s.run) return;
    s.cooldown?.(); s.cooldown = undefined;
    release(s);
    s.run = connect(s).finally(() => {s.run = undefined;});
  }
  async function connect(s: Session) {
    s.binding.prepare?.();
    for (let attempt = 1; attempt <= IRIUN_MAX_ATTEMPTS && current(s); attempt++) {
      publish(s, {phase: 'connecting', attempt, stream: null,
        message: IRIUN_RECONNECT_MESSAGE});
      try {
        // A timed-out native request cannot lock the POS document: each failed
        // attempt retires its camera document before creating the next one.
        s.context = await (deps.context ?? createIriunContext)(s.abort.signal);
        if (!current(s)) {release(s); return;}
        const context = s.context;
        const changed = () => {if (current(s) && s.state.phase !== 'ready') restart(s);};
        context.media.addEventListener?.('devicechange', changed);
        const dispose = context.dispose;
        context.dispose = () => {
          context.media.removeEventListener?.('devicechange', changed); dispose();
        };
        const stream = await (deps.open ?? openIriunCamera)(context.media, s.abort.signal, undefined, 6000,
          {attempts: 1, avoidDeviceId: s.failedId});
        if (!current(s)) {stream.getTracks().forEach(t => t.stop()); release(s); return;}
        s.stream = stream;
        const video = s.binding.video();
        if (!video) throw Error('촬영 화면이 준비되지 않았습니다.');
        s.video = video;
        await (deps.show ?? showCameraVideo)(video, stream);
        if (!current(s)) {release(s); return;}
        const health=s.freshness.sample(video,stream);
        if(!health.usable||!health.pixelAvailable||health.frozenForMs>=1000||health.stalledForMs>=1000)
          throw Error('새 실시간 영상이 아직 도착하지 않았습니다.');
        const id = stream.getVideoTracks()[0]?.getSettings().deviceId || '';
        s.failedId = undefined;
        s.unwatch = (deps.watch ?? watchIriunStream)(video, stream, {
          freshness: s.freshness,
          isCurrent: () => current(s) && s.stream === stream,
          recover: reason => {
            if (!current(s)) return;
            s.failedId = id; publish(s, {message: reason});
            restart(s);
          },
        });
        publish(s, {phase: 'ready', deviceId: id, stream, message: ''});
        return;
      } catch (error) {
        release(s);
        if (!current(s)) return;
        const blocked = ['NotAllowedError', 'SecurityError'].includes((error as Error)?.name);
        if (blocked || attempt === IRIUN_MAX_ATTEMPTS) {
          publish(s, {phase: blocked ? 'blocked' : 'connecting', stream: null,
            message: blocked ? iriunFailure(error) :
              IRIUN_RECONNECT_MESSAGE});
          if (!blocked) s.cooldown = schedule(() => restart(s), 1000);
          return;
        }
        publish(s, {message: IRIUN_RECONNECT_MESSAGE});
        try {await (deps.delay ?? delay)(s.abort.signal, 1000);} catch {return;}
      }
    }
  }
  function start(owner: object, binding: Binding): Promise<void> {
    if (session && session.owner !== owner) {
      binding.change({...idleCamera(), phase: 'error', message: '다른 촬영 창을 닫은 후 다시 연결해 주세요.'});
      return Promise.resolve();
    }
    if (!session) {
      const s: Session = {owner, binding, abort: new AbortController(), unlisten: [], state: idleCamera(),
        freshness: (deps.freshness ?? createIriunFreshness)()};
      session = s;
      const recover = () => restart(s);
      for (const name of ['k99-camera-resume', 'online', 'pageshow']) {
        events?.addEventListener(name, recover);
        s.unlisten.push(() => events?.removeEventListener(name, recover));
      }
      const visible = () => {if (!page?.hidden && s.state.phase !== 'ready') restart(s);};
      page?.addEventListener('visibilitychange', visible);
      s.unlisten.push(() => page?.removeEventListener('visibilitychange', visible));
    } else session.binding = binding;
    const s = session;
    if (s.run) return s.run;
    restart(s);
    return s.run ?? Promise.resolve();
  }
  async function ensureFresh(owner: object, timeoutMs = 20000): Promise<HTMLVideoElement> {
    const clock=()=>globalThis.performance?.now()??Date.now();
    const s = session, deadline = clock() + timeoutMs;
    if (!s || s.owner !== owner) throw Error('촬영 창을 열고 카메라 연결을 확인해 주세요.');
    const blocked = () => s.state.phase === 'blocked';
    const valid = () => {
      if (!current(s) || !s.stream || !s.video || s.state.phase !== 'ready') return false;
      const health = s.freshness.sample(s.video, s.stream);
      return health.usable && health.pixelAvailable && health.frozenForMs < 1000 && health.stalledForMs < 1000;
    };
    if (valid()) return s.video!;
    if (blocked()) throw Error(s.state.message);
    if (!s.run) {
      s.failedId = s.state.deviceId;
      publish(s, {phase: 'connecting', message: IRIUN_RECONNECT_MESSAGE});
      restart(s);
    }
    while (current(s) && clock() < deadline) {
      if (blocked()) throw Error(s.state.message);
      if (valid()) return s.video!;
      await delay(s.abort.signal, 50);
    }
    throw Error(current(s) ? '최신 카메라 영상을 기다리고 있습니다. 잔상 사진은 저장하지 않았습니다. 자동 재연결 후 다시 촬영해 주세요.' : '촬영 창이 닫혀 사진을 저장하지 않았습니다.');
  }
  return {start, stop, ensureFresh, state: () => session?.state ?? idleCamera()};
}
export const iriunCameraManager = createIriunManager();
