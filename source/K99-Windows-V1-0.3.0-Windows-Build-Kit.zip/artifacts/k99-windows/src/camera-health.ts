import type {CameraCheckReport} from './desktop-runtime';

type HealthState={report:CameraCheckReport|null;dialogOpen:boolean;opening:boolean;error:string};
let snapshot:HealthState={report:null,dialogOpen:false,opening:false,error:''};
let pending:Promise<void>|null=null,prompted=false;
const listeners=new Set<()=>void>();
const publish=(value:Partial<HealthState>)=>{
  snapshot={...snapshot,...value};listeners.forEach(listener=>listener());
};
async function bounded<T>(work:Promise<T>):Promise<T>{
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{return await Promise.race([work,new Promise<never>((_,reject)=>{
    timer=setTimeout(()=>reject(Error('설정 확인이 지연되고 있어요. 잠시 후 다시 시도해 주세요.')),6000);
  })]);}finally{clearTimeout(timer);}
}
export const cameraHealth={
  state:()=>snapshot,
  subscribe(listener:()=>void){listeners.add(listener);return ()=>{listeners.delete(listener);};},
  close(){publish({dialogOpen:false,error:''});},
  show(){publish({dialogOpen:true,error:''});},
  async settings(){
    if(snapshot.opening)return;
    publish({opening:true,error:''});
    try{
      const work=window.k99Desktop?.cameraCheck?.({action:'open-settings'});
      const result=work?await bounded(work):undefined;
      if(!result?.opened)throw Error('Windows 매장 프로그램에서 카메라 설정을 열어 주세요.');
    }catch(error){publish({error:error instanceof Error?error.message:'Windows 카메라 설정을 직접 확인해 주세요.'});}
    finally{publish({opening:false});}
  },
};

/** Neither registry/network checks nor their errors can gate getUserMedia. */
export function checkCameraEnvironment():Promise<void>{
  if(pending)return pending;
  if(typeof window==='undefined'||!window.k99Desktop?.cameraCheck)return Promise.resolve();
  pending=(async()=>{
    try{
      const report=await bounded(window.k99Desktop!.cameraCheck!({action:'status'}));
      if(report.permission.state==='not-denied')prompted=false;
      const show=report.permission.state==='denied'&&!prompted;
      if(show)prompted=true;
      publish({report,dialogOpen:report.permission.state==='not-denied'?false:show||snapshot.dialogOpen,error:''});
    }catch{
      // Read failure is unknown, not denial or successful permission.
      publish({report:null});
    }
  })().finally(()=>{pending=null;});
  return pending;
}
