// Rich local-only view models for the generic maintenance contract.
export type MaintenanceStatus={
  native:boolean;packaged:boolean;busy:boolean;dataLocation:string;backupLocation:string;
  keyProtection:string;adminConfigured:boolean;recoveryConfigured:boolean;
  schedule:{enabled:boolean;intervalHours:number};lastBackupAt:string|null;lastError:string|null;
  backupKeyExported:boolean;autostart:{supported:boolean;enabled:boolean};
  backups:{id:string;createdAt:string;size:number;reason:string}[];
};
export async function maintenanceStatus():Promise<MaintenanceStatus>{
  const r=await fetch('/api/maintenance/status');const data=await r.json();
  if(!r.ok)throw Error(data.error||'보존 설정 조회 실패');return data;
}
export async function maintenanceCommand(action:string,input:Record<string,unknown>={}):Promise<Record<string,any>>{
  const r=await fetch('/api/maintenance/command',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action,...input})});
  const data=await r.json();if(!r.ok)throw Error(data.error||'보존 작업 실패');return data;
}
