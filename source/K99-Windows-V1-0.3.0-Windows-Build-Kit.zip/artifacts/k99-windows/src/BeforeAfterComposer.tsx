import { useCallback, useEffect, useRef, useState } from 'react';
import bwipjs from 'bwip-js/browser';
import { Circle, Eraser, Smartphone, Square, X } from 'lucide-react';
import { getEquipmentState, saveComparison, type EquipmentPhoto } from './equipment-client';
import type { ConfirmedOrder } from './order-record';
import { listGarments } from './garment-scanner';
import { coverRect, drawMarks, type Mark, type MarkColor, type MarkKind } from './ba-geometry';
import { BaMarkEditor } from './BaMarkEditor';
import { comparisonMobileStatus, startComparisonMobile, stopComparisonMobile, type ComparisonMobileSession } from './comparison-mobile-client';
import './before-after.css';

type Slot = 'before' | 'after';
type TextSize = 'normal' | 'large' | 'xlarge';
const W = 1600, PAD = 40, PH = 740;
const SIZES: Record<TextSize, { label: string; px: number; lh: number }> = {
  normal: { label: '보통', px: 28, lh: 40 }, large: { label: '크게', px: 38, lh: 52 }, xlarge: { label: '아주 크게', px: 48, lh: 64 },
};
const FONT = '"Noto Sans KR", "Malgun Gothic", sans-serif';
const DEFAULT_TEXT = '전문 검수 후 소재에 맞는 세탁 방법으로 오염을 제거하고, 마무리 다림질과 완성 검수를 거쳐 출고합니다.';
const POLL_MS = 2000;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('사진을 불러오지 못했습니다.'));
    img.src = src;
  });
}

/** Splits text into all lines that fit width (no truncation). */
function wrapLines(g: CanvasRenderingContext2D, text: string, max: number): string[] {
  const out: string[] = []; let line = '';
  for (const ch of text) {
    if (ch === '\n') { out.push(line); line = ''; continue; }
    if (line && g.measureText(line + ch).width > max) { out.push(line); line = ch === ' ' ? '' : ch; }
    else line += ch;
  }
  if (line) out.push(line);
  return out;
}

function drawPhoto(g: CanvasRenderingContext2D, img: HTMLImageElement | null, marks: Mark[], x: number, y: number, w: number, h: number) {
  g.fillStyle = '#e9e4d8'; g.fillRect(x, y, w, h);
  if (!img) return;
  const r = coverRect(img.naturalWidth || img.width, img.naturalHeight || img.height, { x, y, w, h });
  g.save();g.beginPath();g.rect(x,y,w,h);g.clip();
  g.drawImage(img, r.x, r.y, r.w, r.h);
  drawMarks(g, marks, r);
  g.restore();
}

async function ensureFonts(sizes: number[]) {
  const f = typeof document !== 'undefined' ? document.fonts : undefined;
  if (!f) return;
  await Promise.all(sizes.flatMap((s) => [f.load(`${s}px ${FONT}`), f.load(`bold ${s}px ${FONT}`)])).catch(() => undefined);
  await f.ready;
}

/** Standard Before/After card editor. Saving renders a single JPEG and stores it through the native backend. */
export function BeforeAfterComposer({ order, onClose }: { order: ConfirmedOrder; onClose: () => void }) {
  const [photos, setPhotos] = useState<EquipmentPhoto[] | null>(null);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState(DEFAULT_TEXT);
  const [textSize, setTextSize] = useState<TextSize>('large');
  const [src, setSrc] = useState<Record<Slot, string>>({ before: '', after: '' });
  const [marks, setMarks] = useState<Record<Slot, Mark[]>>({ before: [], after: [] });
  const [tool, setTool] = useState<MarkKind>('circle');
  const [color, setColor] = useState<MarkColor>('red');
  const [busy, setBusy] = useState(false);
  const [rendered, setRendered] = useState<{ ok: boolean; error: string }>({ ok: false, error: '' });
  const [result, setResult] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const dialogRef = useRef<HTMLDialogElement | null>(null);
  const renderSeq = useRef(0);

  // Mobile QR session state
  const garments = listGarments(order);
  const [mobileGarment, setMobileGarment] = useState(garments[0]?.garmentId ?? '');
  const [session, setSession] = useState<ComparisonMobileSession | null>(null);
  const [mobileBusy, setMobileBusy] = useState(false);
  const [mobileNote, setMobileNote] = useState<{ kind: 'ok' | 'error' | 'info'; text: string } | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const sessionIdRef = useRef<string | null>(null);
  const startSeq = useRef(0);
  const lastPhotoKey = useRef('');
  const qrRef = useRef<HTMLCanvasElement | null>(null);

  const setSlotSrc = useCallback((slot: Slot, url: string) => {
    setSrc((s) => s[slot] === url ? s : { ...s, [slot]: url });
    setMarks((m) => ({ ...m, [slot]: [] }));
  }, []);

  useEffect(() => { dialogRef.current?.showModal(); }, []);
  useEffect(() => {
    let live = true;
    getEquipmentState().then((s) => {
      if (!live) return;
      const mine = s.photos.filter((p) => p.orderId === order.id);
      setPhotos(mine);
      setSrc({ before: mine.find((p) => p.role === 'intake')?.url ?? '', after: mine.find((p) => p.role === 'completion')?.url ?? '' });
      setMarks({ before: [], after: [] });
    }).catch((c) => { if (live) { setPhotos([]); setLoadError(c instanceof Error ? c.message : '저장된 사진을 읽지 못했습니다.'); } });
    return () => { live = false; };
  }, [order.id]);

  // ---- Mobile session lifecycle ----
  const stopSession = useCallback(() => {
    startSeq.current++;
    const id = sessionIdRef.current; sessionIdRef.current = null;
    setSession(null);
    if (id) void stopComparisonMobile(id).catch(() => undefined);
  }, []);

  useEffect(() => {
    setMobileGarment(listGarments(order)[0]?.garmentId ?? '');
    return () => { stopSession(); lastPhotoKey.current = ''; };
  }, [order.id, stopSession]); // eslint-disable-line react-hooks/exhaustive-deps

  const applyStatus = useCallback((s: ComparisonMobileSession) => {
    if (sessionIdRef.current !== s.id) return;
    setSession(s);
    const photo = s.lastResult?.photo;
    if (photo?.url) {
      const key = photo.id;
      if (key !== lastPhotoKey.current) {
        lastPhotoKey.current = key;
        setSlotSrc('after', photo.url);
        setMobileNote({ kind: 'ok', text: `휴대폰 사진을 After에 넣었습니다 · ${s.lastResult!.archive.fileName}` });
      }
    }
  }, [setSlotSrc]);

  async function startSession() {
    if (!mobileGarment) return;
    const prev = sessionIdRef.current; if (prev) stopSession();
    const seq = ++startSeq.current;
    setMobileBusy(true); setMobileNote(null);
    try {
      const s = await startComparisonMobile(order.id, mobileGarment);
      if (seq !== startSeq.current) { void stopComparisonMobile(s.id).catch(() => undefined); return; }
      sessionIdRef.current = s.id;
      lastPhotoKey.current = s.lastResult?.photo?.id ?? '';
      setSession(s);
      setMobileNote({ kind: 'info', text: '휴대폰으로 QR을 찍어 세탁 후 사진을 보내세요.' });
    } catch (c) {
      if (seq === startSeq.current) setMobileNote({ kind: 'error', text: c instanceof Error ? c.message : '휴대폰 연결을 시작하지 못했습니다.' });
    } finally { if (seq === startSeq.current) setMobileBusy(false); }
  }

  const sessionId = session?.id ?? null;
  const expired = Boolean(session && session.expiresAt <= now);
  useEffect(() => {
    if (!sessionId) return;
    let live = true; let inFlight = false;
    const tick = async () => {
      setNow(Date.now());
      if (!live || inFlight || sessionIdRef.current !== sessionId) return;
      inFlight = true;
      try { const s = await comparisonMobileStatus(sessionId); if (live) applyStatus(s); }
      catch (c) { if (live && sessionIdRef.current === sessionId) setMobileNote({ kind: 'error', text: c instanceof Error ? c.message : '휴대폰 전송 상태를 확인하지 못했습니다.' }); }
      finally { inFlight = false; }
    };
    const t = window.setInterval(() => void tick(), POLL_MS);
    return () => { live = false; window.clearInterval(t); };
  }, [sessionId, applyStatus]);

  useEffect(() => { if (expired) { stopSession(); setMobileNote({ kind: 'error', text: 'QR이 만료되었습니다. 다시 시작해 주세요.' }); } }, [expired, stopSession]);

  const qrUrl = session?.urls[0] ?? '';
  useEffect(() => {
    if (!qrRef.current || !qrUrl) return;
    try { bwipjs.toCanvas(qrRef.current, { bcid: 'qrcode', text: qrUrl, scale: 5, padding: 4 }); }
    catch { setMobileNote({ kind: 'error', text: 'QR을 만들지 못했습니다.' }); }
  }, [qrUrl]);

  // ---- Final render (atomic: draw offscreen, then copy) ----
  useEffect(() => {
    const seq = ++renderSeq.current;
    setRendered({ ok: false, error: '' });
    (async () => {
      const size = SIZES[textSize];
      try {
        await ensureFonts([30, 34, 22, size.px]);
        const [b, a] = await Promise.all([src.before, src.after].map((u) => u ? loadImage(u) : Promise.resolve(null)));
        if (seq !== renderSeq.current) return;
        const off = document.createElement('canvas'); const og = off.getContext('2d');
        if (!og) throw new Error('미리보기를 그리지 못했습니다.');
        og.font = `${size.px}px ${FONT}`;
        const lines = wrapLines(og, text, W - PAD * 2 - 60);
        const firstBase = PAD + 72 + size.px;
        const HEAD = Math.max(250, firstBase + Math.max(0, lines.length - 1) * size.lh + Math.round(size.px * .45) + 26);
        const top = HEAD + 30; const H = top + 60 + PH + PAD;
        off.width = W; off.height = H;
        const g = off.getContext('2d')!;
        g.fillStyle = '#1e2c33'; g.fillRect(0, 0, W, H);
        g.fillStyle = '#f6f2ea'; g.fillRect(PAD, PAD, W - PAD * 2, HEAD - PAD);
        g.fillStyle = '#b8894f'; g.font = `bold 30px ${FONT}`;
        g.fillText('K99 품격세탁소 · 세탁 과정', PAD + 30, PAD + 50);
        g.fillStyle = '#1e2c33'; g.font = `${size.px}px ${FONT}`;
        lines.forEach((l, i) => g.fillText(l, PAD + 30, firstBase + i * size.lh));
        const pw = (W - PAD * 3) / 2;
        drawPhoto(g, b, marks.before, PAD, top + 60, pw, PH);
        drawPhoto(g, a, marks.after, PAD * 2 + pw, top + 60, pw, PH);
        g.font = `bold 34px ${FONT}`;
        g.fillStyle = '#c9ced0'; g.fillText('세탁 전 (Before)', PAD, top + 40);
        g.fillStyle = '#d5ac72'; g.fillText('세탁 후 (After)', PAD * 2 + pw, top + 40);
        g.font = `22px ${FONT}`; g.fillStyle = '#9fadb3';
        g.fillText(`${new Date(order.intakeAt).toLocaleDateString('ko-KR')} · ${order.customerName}`, PAD, H - 12);
        const c = canvasRef.current; const cg = c?.getContext('2d');
        if (!c || !cg || seq !== renderSeq.current) return;
        c.width = W; c.height = H; cg.drawImage(off, 0, 0);
        setRendered({ ok: Boolean(b && a), error: '' });
      } catch (cause) {
        if (seq === renderSeq.current) setRendered({ ok: false, error: cause instanceof Error ? cause.message : '미리보기를 그리지 못했습니다.' });
      }
    })();
  }, [src, text, textSize, marks, order]);

  function pickFile(slot: Slot, file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setSlotSrc(slot, String(reader.result));
    reader.readAsDataURL(file);
  }

  async function save() {
    const c = canvasRef.current;
    if (!c || !src.before || !src.after || !rendered.ok) return;
    setBusy(true); setResult(null);
    try {
      const data = c.toDataURL('image/jpeg', 0.92);
      const r = await saveComparison(order.id, data);
      setResult({ kind: 'ok', text: `저장했습니다 · ${r.archive.folder}\\${r.archive.fileName}` });
    } catch (cause) {
      setResult({ kind: 'error', text: cause instanceof Error ? cause.message : '비교 사진을 저장하지 못했습니다.' });
    } finally { setBusy(false); }
  }

  const slotPanel = (slot: Slot, label: string) => (
    <section className="ba2-slot" data-slot={slot} data-testid={`slot-${slot}`}>
      <header><h3>{label}</h3>
        <label className="ba-file">PC에서 사진 선택
          <input type="file" accept="image/*" onChange={(e) => { pickFile(slot, e.target.files?.[0]); e.target.value = ''; }} data-testid={`input-${slot}-file`} /></label>
      </header>
      {slot === 'after' && <button type="button" className="ba2-btn ba2-btn--go"
        disabled={mobileBusy || !mobileGarment} data-testid="button-after-mobile-qr"
        onClick={() => {
          document.querySelector('[data-testid="panel-mobile-after"]')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          if (!session) void startSession();
        }}><Smartphone aria-hidden="true" />휴대폰 QR 촬영</button>}
      {photos === null ? <div className="ba-skel" /> : (
        <div className="ba-thumbs">
          {photos.filter((p) => slot === 'before' ? p.role === 'intake' : p.role === 'completion').map((p) => (
            <button type="button" key={p.id} aria-pressed={src[slot] === p.url} onClick={() => setSlotSrc(slot, p.url)}
              data-testid={`button-${slot}-photo-${p.id}`}><img src={p.url} alt="" /></button>
          ))}
        </div>
      )}
      <BaMarkEditor src={src[slot]} marks={marks[slot]} tool={tool} color={color} disabled={busy} testId={slot}
        onChange={(m) => setMarks((s) => ({ ...s, [slot]: m }))} />
    </section>
  );

  const remain = session ? Math.max(0, Math.round((session.expiresAt - now) / 1000)) : 0;
  const canSave = !busy && !!src.before && !!src.after && rendered.ok;

  return (
    <dialog ref={dialogRef} className="k99-modal ba-dialog ba2" onClose={onClose} aria-labelledby="ba-title" data-testid="dialog-before-after">
      <header className="k99-modal__head">
        <div><h2 id="ba-title">세탁 전·후 사진 만들기</h2><p>{order.customerName} · 주문 {order.id}</p></div>
        <button type="button" className="k99-modal__close" onClick={() => dialogRef.current?.close()} data-testid="button-close-before-after">닫기</button>
      </header>
      <div className="ba-body ba2-body">
        <aside className="ba2-side">
          <div className="ba2-tools">
            <strong>표시 도구</strong>
            <div className="ba2-seg" role="group" aria-label="도형">
              <button type="button" aria-pressed={tool === 'circle'} onClick={() => setTool('circle')} data-testid="button-tool-circle"><Circle aria-hidden="true" />원</button>
              <button type="button" aria-pressed={tool === 'rect'} onClick={() => setTool('rect')} data-testid="button-tool-rect"><Square aria-hidden="true" />사각형</button>
            </div>
            <div className="ba2-seg" role="group" aria-label="색상">
              <button type="button" className="ba2-red" aria-pressed={color === 'red'} onClick={() => setColor('red')} data-testid="button-color-red">빨강</button>
              <button type="button" className="ba2-blue" aria-pressed={color === 'blue'} onClick={() => setColor('blue')} data-testid="button-color-blue">파랑</button>
            </div>
            <small><Eraser aria-hidden="true" /> 빈 곳 드래그: 새 도형 · 테두리 드래그: 이동 · 모서리: 크기</small>
          </div>
          <div className="ba2-mobile" data-testid="panel-mobile-after">
            <strong><Smartphone aria-hidden="true" />휴대폰으로 After 촬영</strong>
            <label>After 대상 의류{garments.length > 1 ? ' (확인 필요)' : ''}
              <select value={mobileGarment} disabled={!!session || mobileBusy} onChange={(e) => setMobileGarment(e.target.value)} data-testid="select-mobile-garment">
                {garments.map((g) => <option key={g.garmentId} value={g.garmentId}>{g.itemName} {g.sequence}/{g.totalSequence}</option>)}
              </select></label>
            {session && !expired ? <>
              <div className="ba2-qr"><canvas ref={qrRef} aria-label="휴대폰 업로드 QR" data-testid="img-comparison-qr" /></div>
              <p className="ba2-mobile__meta" data-testid="text-mobile-status">받은 사진 {session.uploadedCount}장 · 남은 시간 {Math.floor(remain / 60)}:{String(remain % 60).padStart(2, '0')}</p>
              <button type="button" className="ba2-btn" onClick={() => { stopSession(); setMobileNote(null); }} data-testid="button-stop-mobile"><X aria-hidden="true" />QR 닫기</button>
            </> : <button type="button" className="ba2-btn ba2-btn--go" disabled={mobileBusy || !mobileGarment} onClick={() => void startSession()} data-testid="button-start-mobile">
              {mobileBusy ? 'QR 준비 중' : 'QR 만들기'}</button>}
            {mobileNote && <p className={`ba2-note ba2-note--${mobileNote.kind}`} role="status" data-testid="status-mobile-after">{mobileNote.text}</p>}
          </div>
          <div className="ba2-seg" role="group" aria-label="설명 글자 크기">
            {(Object.keys(SIZES) as TextSize[]).map((k) => <button key={k} type="button" aria-pressed={textSize === k}
              onClick={() => setTextSize(k)} data-testid={`button-text-size-${k}`}>{SIZES[k].label}</button>)}
          </div>
          <label className="ba-text">세탁 과정 설명
            <textarea value={text} maxLength={160} onChange={(e) => setText(e.target.value)} data-testid="input-before-after-text" /></label>
          <button type="button" className="k99-modal__primary" disabled={!canSave} onClick={() => void save()}
            data-testid="button-save-before-after">{busy ? '저장 중' : !rendered.ok && src.before && src.after && !rendered.error ? '준비 중' : '저장'}</button>
          {loadError && <p className="k99-modal__error" role="alert">{loadError}</p>}
        </aside>
        <div className="ba2-main">
          <div className="ba2-editors">
            {slotPanel('before', '세탁 전 (Before)')}
            {slotPanel('after', '세탁 후 (After)')}
          </div>
          <div className="ba-preview ba2-preview">
            <span>저장될 사진 미리보기</span>
            <canvas ref={canvasRef} width={W} height={1120} data-testid="canvas-before-after" />
          </div>
        </div>
      </div>
      <footer className="k99-modal__foot">
        {rendered.error && <p className="k99-modal__error" role="alert" data-testid="status-render-error">{rendered.error}</p>}
        {result && <p className={result.kind === 'ok' ? 'k99-modal__ok' : 'k99-modal__error'} role="status" data-testid="status-before-after">{result.text}</p>}
      </footer>
    </dialog>
  );
}
