import { useEffect, useRef, useState } from 'react';
import { getEquipmentState, saveComparison, type EquipmentPhoto } from './equipment-client';
import type { ConfirmedOrder } from './order-record';

type Slot = 'before' | 'after';
const W = 1600, H = 1120, HEAD = 250, PAD = 40;
const DEFAULT_TEXT = '전문 검수 후 소재에 맞는 세탁 방법으로 오염을 제거하고, 마무리 다림질과 완성 검수를 거쳐 출고합니다.';

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('사진을 불러오지 못했습니다.'));
    img.src = src;
  });
}

function wrap(g: CanvasRenderingContext2D, text: string, x: number, y: number, max: number, lh: number, lines = 3) {
  let line = ''; let row = 0;
  for (const ch of text) {
    if (ch === '\n' || g.measureText(line + ch).width > max) {
      g.fillText(line, x, y + row * lh); row++; line = ch === '\n' ? '' : ch;
      if (row >= lines) return;
    } else line += ch;
  }
  if (line && row < lines) g.fillText(line, x, y + row * lh);
}

function drawCover(g: CanvasRenderingContext2D, img: HTMLImageElement | null, x: number, y: number, w: number, h: number) {
  g.fillStyle = '#e9e4d8'; g.fillRect(x, y, w, h);
  if (!img) return;
  const s = Math.min(w / img.width, h / img.height);
  const dw = img.width * s, dh = img.height * s;
  g.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

/** Standard Before/After card editor. Saving renders a single JPEG and stores it through the native backend. */
export function BeforeAfterComposer({ order, onClose }: { order: ConfirmedOrder; onClose: () => void }) {
  const [photos, setPhotos] = useState<EquipmentPhoto[] | null>(null);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState(DEFAULT_TEXT);
  const [src, setSrc] = useState<Record<Slot, string>>({ before: '', after: '' });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const dialogRef = useRef<HTMLDialogElement | null>(null);

  useEffect(() => { dialogRef.current?.showModal(); }, []);
  useEffect(() => {
    let live = true;
    getEquipmentState().then((s) => {
      if (!live) return;
      const mine = s.photos.filter((p) => p.orderId === order.id);
      setPhotos(mine);
      setSrc({ before: mine.find((p) => p.role === 'intake')?.url ?? '', after: mine.find((p) => p.role === 'completion')?.url ?? '' });
    }).catch((c) => { if (live) { setPhotos([]); setLoadError(c instanceof Error ? c.message : '저장된 사진을 읽지 못했습니다.'); } });
    return () => { live = false; };
  }, [order.id]);

  useEffect(() => {
    let live = true;
    (async () => {
      const c = canvasRef.current; const g = c?.getContext('2d');
      if (!c || !g) return;
      const [b, a] = await Promise.all([src.before, src.after].map((u) => u ? loadImage(u).catch(() => null) : Promise.resolve(null)));
      if (!live) return;
      g.fillStyle = '#1e2c33'; g.fillRect(0, 0, W, H);
      g.fillStyle = '#f6f2ea'; g.fillRect(PAD, PAD, W - PAD * 2, HEAD - PAD);
      g.fillStyle = '#b8894f'; g.font = 'bold 30px "Noto Sans KR", sans-serif';
      g.fillText('K99 품격세탁소 · 세탁 과정', PAD + 30, PAD + 50);
      g.fillStyle = '#1e2c33'; g.font = '28px "Noto Sans KR", sans-serif';
      wrap(g, text, PAD + 30, PAD + 100, W - PAD * 2 - 60, 40, 3);
      const top = HEAD + 30, pw = (W - PAD * 3) / 2, ph = H - top - PAD - 60;
      drawCover(g, b, PAD, top + 60, pw, ph);
      drawCover(g, a, PAD * 2 + pw, top + 60, pw, ph);
      g.font = 'bold 34px "Noto Sans KR", sans-serif';
      g.fillStyle = '#c9ced0'; g.fillText('세탁 전 (Before)', PAD, top + 40);
      g.fillStyle = '#d5ac72'; g.fillText('세탁 후 (After)', PAD * 2 + pw, top + 40);
      g.font = '22px "Noto Sans KR", sans-serif'; g.fillStyle = '#9fadb3';
      g.fillText(`${new Date(order.intakeAt).toLocaleDateString('ko-KR')} · ${order.customerName}`, PAD, H - 26);
    })();
    return () => { live = false; };
  }, [src, text, order]);

  function pickFile(slot: Slot, file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setSrc((s) => ({ ...s, [slot]: String(reader.result) }));
    reader.readAsDataURL(file);
  }

  async function save() {
    const c = canvasRef.current;
    if (!c || !src.before || !src.after) return;
    setBusy(true); setResult(null);
    try {
      const data = c.toDataURL('image/jpeg', 0.92);
      const r = await saveComparison(order.id, data);
      setResult({ kind: 'ok', text: `저장했습니다 · ${r.archive.folder}\\${r.archive.fileName}` });
    } catch (cause) {
      setResult({ kind: 'error', text: cause instanceof Error ? cause.message : '비교 사진을 저장하지 못했습니다.' });
    } finally { setBusy(false); }
  }

  const slotPicker = (slot: Slot, label: string) => (
    <fieldset className="ba-slot" data-testid={`slot-${slot}`}>
      <legend>{label}</legend>
      {photos === null ? <div className="ba-skel" /> : (
        <div className="ba-thumbs">
          {photos.filter((p) => slot === 'before' ? p.role === 'intake' : p.role === 'completion').map((p) => (
            <button type="button" key={p.id} aria-pressed={src[slot] === p.url} onClick={() => setSrc((s) => ({ ...s, [slot]: p.url }))}
              data-testid={`button-${slot}-photo-${p.id}`}><img src={p.url} alt="" /></button>
          ))}
        </div>
      )}
      <label className="ba-file">PC에서 사진 선택
        <input type="file" accept="image/*" onChange={(e) => pickFile(slot, e.target.files?.[0])} data-testid={`input-${slot}-file`} /></label>
    </fieldset>
  );

  return (
    <dialog ref={dialogRef} className="k99-modal ba-dialog" onClose={onClose} aria-labelledby="ba-title" data-testid="dialog-before-after">
      <header className="k99-modal__head">
        <div><h2 id="ba-title">세탁 전·후 사진 만들기</h2><p>{order.customerName} · 주문 {order.id}</p></div>
        <button type="button" className="k99-modal__close" onClick={() => dialogRef.current?.close()} data-testid="button-close-before-after">닫기</button>
      </header>
      <div className="ba-body">
        <div className="ba-controls">
          <label className="ba-text">세탁 과정 설명
            <textarea value={text} maxLength={160} onChange={(e) => setText(e.target.value)} data-testid="input-before-after-text" /></label>
          {slotPicker('before', '세탁 전 (Before)')}
          {slotPicker('after', '세탁 후 (After)')}
          {loadError && <p className="k99-modal__error" role="alert">{loadError}</p>}
        </div>
        <div className="ba-preview"><canvas ref={canvasRef} width={W} height={H} data-testid="canvas-before-after" /></div>
      </div>
      <footer className="k99-modal__foot">
        {result && <p className={result.kind === 'ok' ? 'k99-modal__ok' : 'k99-modal__error'} role="status" data-testid="status-before-after">{result.text}</p>}
        <button type="button" className="k99-modal__primary" disabled={busy || !src.before || !src.after} onClick={() => void save()}
          data-testid="button-save-before-after">{busy ? '저장 중' : '저장'}</button>
      </footer>
    </dialog>
  );
}
