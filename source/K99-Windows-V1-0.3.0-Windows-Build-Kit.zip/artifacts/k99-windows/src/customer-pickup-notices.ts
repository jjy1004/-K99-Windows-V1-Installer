import type { ConfirmedOrder } from './order-record';
import { orderHandedOver } from './handover-display.ts';
import { koreaCalendarDate } from './storage-policy.ts';
import templates from '../../../lib/k99-local/pickup-templates.json';
import { paymentNotice } from './order-payment';
import { voucherReceiptText } from './voucher-receipt';

/** Request section 5: post-completion pickup/delivery guidance and uncollected reminders. */
export type PickupNoticeStage = 'completion' | 'day7' | 'day12';
export type PickupNoticeKind = 'direct-pickup' | 'delivery' | 'day7' | 'day12';
export type PickupNoticeLogEntry = { stage: PickupNoticeStage | 'day9' | 'day13'; kind: PickupNoticeKind | 'day9' | 'day13'; sentAt: string;
  /** Set when an earlier overdue stage was closed because a later stage was actually sent instead. */
  supersededBy?: PickupNoticeStage | 'day9' | 'day13' };

export const PICKUP_NOTICE_LABELS: Record<PickupNoticeStage, string> = {
  completion: '고객 직접 수거 또는 배달 안내 메시지 미발송',
  day7: '미수거 1차 안내 미발송',
  day12: '미수거 최종 안내 미발송',
};
export const PICKUP_KIND_LABELS: Record<PickupNoticeKind, string> = {
  'direct-pickup': '직접 수거 안내', delivery: '배달 안내', day7: '접수 후 7일 안내', day12: '12일 차 보관료 안내',
};

/** Adds whole days to a YYYY-MM-DD calendar date (UTC arithmetic, timezone independent). */
export function addCalendarDays(date: string, days: number): string {
  const time = Date.parse(`${date}T00:00:00.000Z`);
  if (Number.isNaN(time)) throw new Error('날짜 형식을 확인해 주세요.');
  return new Date(time + days * 86400000).toISOString().slice(0, 10);
}

/** Notice age is elapsed Seoul calendar days from intake; storage charging policy is unchanged. */
export function pickupPolicyDates(intakeAt: string) {
  const intake = koreaCalendarDate(intakeAt);
  return { intake, day7: addCalendarDays(intake, 7), day12: addCalendarDays(intake, 12), storageFeeStart: addCalendarDays(intake, 15) };
}

/** Completion establishes eligibility; reminder dates use INTAKE age, not completion age. */
export function pickupCompletionDates(order: ConfirmedOrder) {
  const at = laundryCompletedAt(order);
  if (!at) return null;
  const completed = koreaCalendarDate(at);
  return { completed, day7: pickupPolicyDates(order.intakeAt).day7, day12: pickupPolicyDates(order.intakeAt).day12 };
}

export function formatKoreanDate(date: string): string {
  const [year, month, day] = date.split('-').map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

/** Real completion evidence only: completed order status with timestamp, or every garment completed. */
export function laundryCompletedAt(order: ConfirmedOrder): string | null {
  if (order.operations?.cancelledAt) return null;
  const garments = order.garments ?? [];
  const allGarmentsDone = garments.length > 0 && garments.every((g) =>
    g.completionStatus === 'complete' || g.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER');
  if (order.status === '전체 세탁 완료 / 반출 대기' && order.orderCompletedAt) return order.orderCompletedAt;
  if (!allGarmentsDone) return null;
  const times = garments.map((g) => g.completedAt).filter((value): value is string => !!value && !Number.isNaN(Date.parse(value)));
  if (order.orderCompletedAt) return order.orderCompletedAt;
  return times.length ? times.sort().at(-1)! : null;
}

const sent = (order: ConfirmedOrder, stage: PickupNoticeStage) => (order.pickupNoticeLog ?? []).some((entry) =>
  !entry.supersededBy && (entry.stage === stage || (stage === 'day7' && entry.stage === 'day9') || (stage === 'day12' && entry.stage === 'day13')));
export const pickupNoticeSent = sent;

/** Returns only the latest due, unsent stage (or null). Handed-over/delivered orders are excluded. */
export function duePickupNoticeStage(order: ConfirmedOrder, asOf: string | Date): PickupNoticeStage | null {
  if (orderHandedOver(order) || order.operations?.cancelledAt) return null;
  const dates = pickupCompletionDates(order);
  if (!dates) return null;
  const today = koreaCalendarDate(asOf);
  if (today < dates.completed) return null;
  // Latest overdue stage supersedes every earlier one, even if earlier ones were never sent.
  if (sent(order, 'day12')) return null;
  if (today >= dates.day12) return 'day12';
  if (sent(order, 'day7')) return null;
  if (today >= dates.day7) return 'day7';
  return sent(order, 'completion') ? null : 'completion';
}

export function pickupNoticeText(order: ConfirmedOrder, kind: PickupNoticeKind, now:Date=new Date()): string {
  let body=templates[kind];
  if(kind==='day12'){
    const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
    const value=(type:string)=>Number(parts.find(p=>p.type===type)!.value);
    const date=(days:number)=>{const d=new Date(Date.UTC(value('year'),value('month')-1,value('day')+days));return `${d.getUTCMonth()+1}월 ${d.getUTCDate()}일`;};
    body=body.replaceAll('{발송일+5일}',date(5)).replaceAll('{발송일+7일}',date(7));
  }
  return body + (['direct-pickup', 'delivery'].includes(kind) ? `\n\n${paymentNotice(order)}` : '')+
    (order.voucher?`\n\n${voucherReceiptText(order.voucher)}`:'');
}

export const kindsForStage = (stage: PickupNoticeStage): PickupNoticeKind[] =>
  stage === 'completion' ? ['direct-pickup', 'delivery'] : [stage];

/**
 * Records a staff-confirmed actual send. Only called from the explicit "발송 완료" button.
 * Earlier unsent stages are not fabricated as sends. A latest-stage record suppresses obsolete recommendations.
 * Never touches handover/operations stage.
 */
export function markPickupNoticeSent(order: ConfirmedOrder, stage: PickupNoticeStage, kind: PickupNoticeKind,
  at: Date = new Date()): ConfirmedOrder {
  if (!kindsForStage(stage).includes(kind)) throw new Error('안내 종류가 단계와 맞지 않습니다.');
  if (orderHandedOver(order)) throw new Error('이미 인도 완료된 주문입니다.');
  if (sent(order, stage)) return order;
  const sentAt = at.toISOString();
  const entry: PickupNoticeLogEntry = { stage, kind, sentAt };
  return {
    ...order,
    pickupNoticeLog: [...(order.pickupNoticeLog ?? []), entry],
    history: [...(order.history ?? []), {
      kind: 'operations-update', at: sentAt,
      details: { event: 'customer-pickup-notice-sent', stage, noticeKind: kind, label: PICKUP_KIND_LABELS[kind],
        actuallySent: true, handover: false },
    }],
  };
}

export type PickupNoticeTarget = {
  orderId: string; customerName: string; customerPhone: string; stage: PickupNoticeStage; label: string;
  intakeDate: string; completedDate: string; deliveryRequested: boolean;
};

export function pickupNoticeTargets(orders: readonly ConfirmedOrder[], asOf: string | Date): PickupNoticeTarget[] {
  return orders.flatMap((order) => {
    const stage = duePickupNoticeStage(order, asOf);
    if (!stage) return [];
    const completedAt = laundryCompletedAt(order)!;
    return [{
      orderId: order.id, customerName: order.customerName, customerPhone: order.customerPhone, stage,
      label: PICKUP_NOTICE_LABELS[stage], intakeDate: pickupPolicyDates(order.intakeAt).intake,
      completedDate: koreaCalendarDate(completedAt), deliveryRequested: !!order.choices?.deliveryRequested,
    }];
  });
}
