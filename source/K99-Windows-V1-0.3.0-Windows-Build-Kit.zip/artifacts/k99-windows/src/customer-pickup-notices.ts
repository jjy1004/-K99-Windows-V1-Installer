import type { ConfirmedOrder } from './order-record';
import { orderHandedOver } from './handover-display.ts';
import { koreaCalendarDate } from './storage-policy.ts';

/** Request section 5: post-completion pickup/delivery guidance and uncollected reminders. */
export type PickupNoticeStage = 'completion' | 'day9' | 'day13';
export type PickupNoticeKind = 'direct-pickup' | 'delivery' | 'day9' | 'day13';
export type PickupNoticeLogEntry = { stage: PickupNoticeStage; kind: PickupNoticeKind; sentAt: string;
  /** Set when an earlier overdue stage was closed because a later stage was actually sent instead. */
  supersededBy?: PickupNoticeStage };

export const PICKUP_NOTICE_LABELS: Record<PickupNoticeStage, string> = {
  completion: '고객 직접 수거 또는 배달 안내 메시지 미발송',
  day9: '미수거 1차 안내 미발송',
  day13: '미수거 최종 안내 미발송',
};
export const PICKUP_KIND_LABELS: Record<PickupNoticeKind, string> = {
  'direct-pickup': '직접 수거 안내', delivery: '배달 안내', day9: '9일차 안내', day13: '13일차 최종 안내',
};

/** Adds whole days to a YYYY-MM-DD calendar date (UTC arithmetic, timezone independent). */
export function addCalendarDays(date: string, days: number): string {
  const time = Date.parse(`${date}T00:00:00.000Z`);
  if (Number.isNaN(time)) throw new Error('날짜 형식을 확인해 주세요.');
  return new Date(time + days * 86400000).toISOString().slice(0, 10);
}

/** Intake date is day 1 (Seoul calendar). Day 9 = +8, day 13 = +12, storage fee starts day 16 = +15. */
export function pickupPolicyDates(intakeAt: string) {
  const intake = koreaCalendarDate(intakeAt);
  return { intake, day9: addCalendarDays(intake, 8), day13: addCalendarDays(intake, 12), storageFeeStart: addCalendarDays(intake, 15) };
}

export function formatKoreanDate(date: string): string {
  const [year, month, day] = date.split('-').map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

/** Real completion evidence only: completed order status with timestamp, or every garment completed. */
export function laundryCompletedAt(order: ConfirmedOrder): string | null {
  if (order.operations?.cancelledAt) return null;
  const garments = order.garments ?? [];
  const allGarmentsDone = garments.length > 0 && garments.every((g) =>
    g.completionStatus === 'complete' || g.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER');
  if (order.status === '전체 세탁 완료 / 반출 대기' && order.orderCompletedAt) return order.orderCompletedAt;
  if (!allGarmentsDone) return null;
  const times = garments.map((g) => g.completedAt).filter((value): value is string => !!value && !Number.isNaN(Date.parse(value)));
  if (order.orderCompletedAt) return order.orderCompletedAt;
  return times.length ? times.sort().at(-1)! : null;
}

const sent = (order: ConfirmedOrder, stage: PickupNoticeStage) => (order.pickupNoticeLog ?? []).some((entry) => entry.stage === stage);
export const pickupNoticeSent = sent;

/** Returns only the latest due, unsent stage (or null). Handed-over/delivered orders are excluded. */
export function duePickupNoticeStage(order: ConfirmedOrder, asOf: string | Date): PickupNoticeStage | null {
  if (orderHandedOver(order) || order.operations?.cancelledAt) return null;
  if (!laundryCompletedAt(order)) return null;
  const today = koreaCalendarDate(asOf);
  const dates = pickupPolicyDates(order.intakeAt);
  // Latest overdue stage supersedes every earlier one, even if earlier ones were never sent.
  if (sent(order, 'day13')) return null;
  if (today >= dates.day13) return 'day13';
  if (sent(order, 'day9')) return null;
  if (today >= dates.day9) return 'day9';
  return sent(order, 'completion') ? null : 'completion';
}

export function pickupNoticeText(order: ConfirmedOrder, kind: PickupNoticeKind): string {
  const dates = pickupPolicyDates(order.intakeAt);
  const intake = formatKoreanDate(dates.intake);
  const completedAt = laundryCompletedAt(order);
  const completed = completedAt ? formatKoreanDate(koreaCalendarDate(completedAt)) : '[완료일]';
  const feeStart = formatKoreanDate(dates.storageFeeStart);
  switch (kind) {
    case 'direct-pickup': return [
      '고객님, K99 세탁의 품격입니다.', '',
      `${intake}에 맡겨주신 세탁물이 ${completed}에 세탁 완료되었습니다.`, '',
      '매장 운영시간에 방문하여 찾아가시기 바랍니다.',
      '평일 오전 10시~오후 7시 / 토요일 오전 11시~오후 4시',
      '일요일·공휴일은 휴무입니다.', '',
      '감사합니다.',
    ].join('\n');
    case 'delivery': return [
      '고객님, K99 세탁의 품격입니다.', '',
      `${intake}에 맡겨주신 세탁물이 ${completed}에 세탁 완료되어 배달 준비가 되었습니다.`, '',
      '배달받으실 주소와 가능하신 시간을 댓글로 알려주시면 일정을 확인하여 안내드리겠습니다.', '',
      '감사합니다.',
    ].join('\n');
    case 'day9': return [
      '고객님, K99 세탁의 품격입니다.', '',
      `${intake}에 맡겨주신 세탁물이 세탁 완료되어 매장에서 보관 중입니다. 방문 수거 또는 배달을 원하시면 댓글로 알려주시기 바랍니다.`, '',
      `접수 후 16일차인 ${feeStart}부터는 세탁물 1점당 하루 1,000원의 보관료가 발생하므로, 그 전에 수거를 부탁드립니다.`, '',
      '감사합니다.',
    ].join('\n');
    case 'day13': return [
      '고객님, K99 세탁의 품격입니다.', '',
      '보관 중인 세탁물의 수거를 다시 한번 부탁드립니다.', '',
      `${feeStart}부터 세탁물 1점당 하루 1,000원의 보관료가 발생할 예정입니다. 추가 비용이 발생하지 않도록 시작일 전에 수거해 주시면 감사하겠습니다.`, '',
      '방문 수거 또는 배달(배달비 10,000원)을 원하시면 댓글로 알려주시기 바랍니다.',
    ].join('\n');
  }
}

export const kindsForStage = (stage: PickupNoticeStage): PickupNoticeKind[] =>
  stage === 'completion' ? ['direct-pickup', 'delivery'] : [stage];

/**
 * Records a staff-confirmed actual send. Only called from the explicit "발송 완료" button.
 * Sending the latest overdue stage also closes skipped earlier stages so they never reappear.
 * Never touches handover/operations stage.
 */
export function markPickupNoticeSent(order: ConfirmedOrder, stage: PickupNoticeStage, kind: PickupNoticeKind,
  at: Date = new Date()): ConfirmedOrder {
  if (!kindsForStage(stage).includes(kind)) throw new Error('안내 종류가 단계와 맞지 않습니다.');
  if (orderHandedOver(order)) throw new Error('이미 인도 완료된 주문입니다.');
  if (sent(order, stage)) return order;
  const sentAt = at.toISOString();
  const entry: PickupNoticeLogEntry = { stage, kind, sentAt };
  const earlier: PickupNoticeStage[] = stage === 'day13' ? ['completion', 'day9'] : stage === 'day9' ? ['completion'] : [];
  const skipped: PickupNoticeLogEntry[] = earlier.filter((item) => !sent(order, item)).map((item) => ({
    stage: item, kind: item === 'completion' ? 'direct-pickup' : 'day9', sentAt, supersededBy: stage }));
  return {
    ...order,
    pickupNoticeLog: [...(order.pickupNoticeLog ?? []), ...skipped, entry],
    history: [...(order.history ?? []), {
      kind: 'operations-update', at: sentAt,
      details: { event: 'customer-pickup-notice-sent', stage, noticeKind: kind, label: PICKUP_KIND_LABELS[kind],
        actuallySent: true, handover: false },
    }],
  };
}

export type PickupNoticeTarget = {
  orderId: string; customerName: string; customerPhone: string; stage: PickupNoticeStage; label: string;
  intakeDate: string; completedDate: string; deliveryRequested: boolean;
};

export function pickupNoticeTargets(orders: readonly ConfirmedOrder[], asOf: string | Date): PickupNoticeTarget[] {
  return orders.flatMap((order) => {
    const stage = duePickupNoticeStage(order, asOf);
    if (!stage) return [];
    const completedAt = laundryCompletedAt(order)!;
    return [{
      orderId: order.id, customerName: order.customerName, customerPhone: order.customerPhone, stage,
      label: PICKUP_NOTICE_LABELS[stage], intakeDate: pickupPolicyDates(order.intakeAt).intake,
      completedDate: koreaCalendarDate(completedAt), deliveryRequested: !!order.choices?.deliveryRequested,
    }];
  });
}
