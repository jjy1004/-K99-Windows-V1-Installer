import type { ConfirmedOrder } from './order-record.ts';
import type { GarmentPhotoMetadata, GarmentRecord } from './garment-record.ts';

function auditTimestamp(at: Date | string): string {
  const value = at instanceof Date ? at.toISOString() : at;
  if (!Number.isFinite(Date.parse(value))) throw new Error('기록 시각을 확인해 주세요.');
  return new Date(value).toISOString();
}

function allPhotosOf(garment: GarmentRecord): readonly GarmentPhotoMetadata[] {
  const photos = garment.photoHistory ?? [];
  return [
    ...(garment.beforePhoto && !photos.some((photo) => photo.requestId === garment.beforePhoto!.requestId)
      ? [garment.beforePhoto] : []),
    ...photos,
    ...(garment.completionPhoto && !photos.some((photo) => photo.requestId === garment.completionPhoto!.requestId)
      ? [garment.completionPhoto] : []),
  ];
}

/** Returns only currently linked photos; archived metadata remains in photoHistory. */
export function activePhotosOf(garment: GarmentRecord): readonly GarmentPhotoMetadata[] {
  const unlinked = new Set(garment.unlinkedPhotoIds ?? []);
  return allPhotosOf(garment).filter((photo) => !unlinked.has(photo.requestId));
}

function latestActiveCompletion(garment: GarmentRecord): GarmentPhotoMetadata | undefined {
  return activePhotosOf(garment)
    .filter((photo) => photo.role === 'completion')
    .reduce<GarmentPhotoMetadata | undefined>((latest, photo) =>
      !latest || Date.parse(photo.timestamp) >= Date.parse(latest.timestamp) ? photo : latest, undefined);
}

function cloneMetadata(photo: GarmentPhotoMetadata): GarmentPhotoMetadata {
  return Object.freeze({
    ...photo,
    ...(photo.annotations ? { annotations: Object.freeze(structuredClone(photo.annotations)) } : {}),
  });
}

/**
 * Manually links existing photo metadata to this garment. A new requestId is
 * required to relink a previously unlinked source, preserving the old audit row.
 */
export function linkManualPhoto(
  garment: GarmentRecord,
  photo: GarmentPhotoMetadata,
  at: Date | string = new Date(),
): GarmentRecord {
  if (!garment.garmentId || !garment.orderId || photo.garmentId !== garment.garmentId ||
    !photo.requestId || !photo.sourcePhotoId?.trim() ||
    !['intake', 'completion'].includes(photo.role) ||
    !['saved', 'simulated'].includes(photo.status) ||
    !Number.isFinite(Date.parse(photo.timestamp))) {
    throw new Error('사진 메타데이터와 의류 연결 정보를 확인해 주세요.');
  }
  const active = activePhotosOf(garment);
  const byRequestId = allPhotosOf(garment).find((item) => item.requestId === photo.requestId);
  if (byRequestId) {
    if (!active.some((item) => item.requestId === photo.requestId) ||
      JSON.stringify(byRequestId) !== JSON.stringify(photo)) {
      throw new Error('기존 사진 요청 ID는 재사용할 수 없습니다. 재연결에는 새 요청 ID가 필요합니다.');
    }
    return garment;
  }
  const sameSource = active.filter((item) => item.sourcePhotoId === photo.sourcePhotoId);
  if (sameSource.some((item) => item.role !== photo.role))
    throw new Error('같은 원본 사진을 다른 사진 역할로 중복 연결할 수 없습니다.');
  if (sameSource.length > 0)
    throw new Error('같은 원본 사진이 이미 이 의류에 연결되어 있습니다.');

  const wasPreviouslyLinked = allPhotosOf(garment).some((item) => item.sourcePhotoId === photo.sourcePhotoId);
  const savedAt = auditTimestamp(at);
  const metadata = cloneMetadata(photo);
  const photoHistory = [...(garment.photoHistory ?? []), metadata];
  const interim: GarmentRecord = {
    ...garment,
    photoHistory,
    unlinkedPhotoIds: garment.unlinkedPhotoIds ? [...garment.unlinkedPhotoIds] : undefined,
  };
  const activeAfterLink = activePhotosOf(interim);
  const activeBeforePhoto = activeAfterLink.find((item) => item.role === 'intake');
  const representativeBeforePhotoId = garment.representativeBeforePhotoId &&
    activeAfterLink.some((item) => item.requestId === garment.representativeBeforePhotoId)
    ? garment.representativeBeforePhotoId
    : activeAfterLink.find((item) => item.role === 'intake')?.requestId;
  return {
    ...interim,
    beforePhoto: activeBeforePhoto,
    ...(representativeBeforePhotoId
      ? { representativeBeforePhotoId }
      : { representativeBeforePhotoId: undefined }),
    ...(photo.role === 'completion' ? { completionPhoto: latestActiveCompletion(interim) } : {}),
    auditEvents: [...garment.auditEvents, {
      at: savedAt,
      type: wasPreviouslyLinked ? 'photo-relink' : 'photo-link',
      status: wasPreviouslyLinked ? 'relinked' : 'linked',
      action: wasPreviouslyLinked ? 'manual-relink' : 'manual-link',
      orderId: garment.orderId,
      garmentId: garment.garmentId,
      sourcePhotoId: photo.sourcePhotoId,
      photoRequestId: photo.requestId,
      details: wasPreviouslyLinked ? '수동 사진 재연결' : '수동 사진 연결',
    }],
  };
}

/** Archives one active photo link without deleting or changing its metadata. */
export function unlinkManualPhoto(
  garment: GarmentRecord,
  requestId: string,
  at: Date | string = new Date(),
): GarmentRecord {
  if (!garment.garmentId || !garment.orderId || !requestId.trim())
    throw new Error('의류 ID와 사진 요청 정보를 확인해 주세요.');
  const photo = activePhotosOf(garment).find((item) => item.requestId === requestId);
  if (!photo) throw new Error('현재 의류에 연결된 사진을 찾을 수 없습니다.');
  const savedAt = auditTimestamp(at);
  const interim: GarmentRecord = {
    ...garment,
    unlinkedPhotoIds: [...(garment.unlinkedPhotoIds ?? []), requestId],
  };
  const activeIntake = activePhotosOf(interim).find((item) => item.role === 'intake');
  return {
    ...interim,
    beforePhoto: activeIntake,
    representativeBeforePhotoId: garment.representativeBeforePhotoId === requestId
      ? activeIntake?.requestId : garment.representativeBeforePhotoId,
    completionPhoto: latestActiveCompletion(interim),
    auditEvents: [...garment.auditEvents, {
      at: savedAt,
      type: 'photo-unlink',
      status: 'unlinked',
      action: 'manual-unlink',
      orderId: garment.orderId,
      garmentId: garment.garmentId,
      sourcePhotoId: photo.sourcePhotoId,
      photoRequestId: requestId,
      details: '수동 사진 연결 해제',
    }],
  };
}

/** Rejects active source-image reuse across garments; archived links are ignored. */
export function assertPhotoNotLinkedToAnotherGarment(
  orders: readonly ConfirmedOrder[],
  sourcePhotoId: string,
  targetOrderId: string,
  targetGarmentId: string,
): void {
  if (!sourcePhotoId.trim() || !targetOrderId.trim() || !targetGarmentId.trim())
    throw new Error('원본 사진과 대상 의류 연결 정보를 확인해 주세요.');
  const conflict = orders.some((order) => (order.garments ?? []).some((garment) =>
    !(order.id === targetOrderId && garment.garmentId === targetGarmentId) &&
    activePhotosOf(garment).some((photo) => photo.sourcePhotoId === sourcePhotoId)));
  if (conflict) throw new Error('같은 원본 사진이 다른 의류에 이미 연결되어 있습니다.');
}