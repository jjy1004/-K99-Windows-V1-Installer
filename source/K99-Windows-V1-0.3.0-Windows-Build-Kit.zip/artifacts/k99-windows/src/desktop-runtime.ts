type Operation = {op:'get'|'set'|'remove'|'keys'; key?:string; value?:string; expected?:string|null};
type Reply = {ok:true; result:unknown} | {ok:false; error:string; status:number};
export type DesktopCustomerEvent = {
  type:string; connected?:boolean; commandId?:string; error?:string;
  diagnostic?: {commandId?:string|null; event:string; [key:string]:unknown};
  payload?:unknown; screen?:'order'|'common'|'sneaker';
  command?:import('./customer-media').CustomerMediaCommand;
  request?:import('./customer-media').ReceiptRequest;
};
export type DesktopCustomerStatus = {connected:boolean;open:boolean;displayId?:string;note:string;placeholderVideos?:string[];
  monitors:{id:string;label:string;primary:boolean;bounds:{x:number;y:number;width:number;height:number}}[]};
export type FootSwitchKey = `F${1|2|3|4|5|6|7|8|9|10|11|12}`|'Space'|'Enter'|
  'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z';
export const FOOT_CAPTURE_EVENT = 'k99:foot-capture';
let lastFootCapture = -Infinity;
export function dispatchFootCapture(accelerator: string | null) {
  const now = performance.now();
  if (now - lastFootCapture < 200) return;
  lastFootCapture = now;
  window.dispatchEvent(new CustomEvent(FOOT_CAPTURE_EVENT, { detail: { accelerator } }));
}
declare global {
  interface Window {
    k99Desktop?: {
      photoSource?(input:{action?:'list';photoId?:string;pathHint?:string;orderId?:string;garmentId?:string}):Promise<import('./native-photo-client').NativePhotoSource|import('./photo-source').PhotoSourceItem[]>;
      analyzeCareLabel?(photoId:string,options?:{automatic?:boolean}):Promise<import('./care-label-client').CareLabelResult>;
      customerAction(data:DesktopCustomerEvent):void;
      customerEvent(data:DesktopCustomerEvent):void;
      customerStatus():Promise<DesktopCustomerStatus>;
      onCustomerUpdate(callback:(data:DesktopCustomerEvent)=>void):()=>void;
      onCustomerConnection(callback:(data:DesktopCustomerEvent)=>void):()=>void;
      storage(input: Operation): Reply;
      request(input: {method:string; path:string; body:unknown}): Promise<Reply>;
      searchCustomers?(keyword:string):Promise<{
        success:boolean;customers:import('./customer-directory-client').DirectoryCustomer[];error?:string;
      }>;
      customerPhotos?(input:{action:'list';customerId:string}|{action:'open';token:string}):Promise<{
        success:boolean;error?:string;opened?:boolean;folders?:{token:string;date:string;name:string}[];notes?:string[];truncated?:boolean;
      }>;
      importCustomerLedger?():Promise<{
        success:boolean;cancelled?:boolean;error?:string;customerCount?:number;orderCount?:number;
      }>;
      onChanged?(callback:()=>void):()=>void;
      /** USB foot switch (global shortcut) presses forwarded from Main. */
      onFootCapture?(callback:(data?:{accelerator?:string})=>void):()=>void;
      /** Ask Main to (un)register the global foot-switch shortcut while a live camera is ready. */
      setFootCaptureActive?(input:{active:boolean; accelerator:FootSwitchKey}):void|Promise<unknown>;
    };
  }
}

/** No browser history import. SQLite is authoritative in both runtimes. */
export function installDesktopRuntime() {
  const customer = ['/equipment/customer','/customer'].includes(window.location.pathname);
  const realFetch = window.fetch.bind(window);
  const realOpen = XMLHttpRequest.prototype.open;
  const seen = new Map<string,string|null>();
  function sync(input:Operation): unknown {
    if(customer) {
      if(input.op==='keys')return [];
      if(input.op==='get')return null;
      throw new Error('고객 화면은 읽기 전용입니다.');
    }
    if (window.k99Desktop) {
      const reply = window.k99Desktop.storage(input);
      if (!reply.ok) throw new Error(reply.error);
      return reply.result;
    }
    // Preview compatibility only: the reused application has synchronous storage
    // contracts. The shipped desktop uses IPC, never this HTTP transport.
    const xhr = new XMLHttpRequest();
    realOpen.call(xhr, 'POST', '/api/local/storage', false);
    xhr.setRequestHeader('Content-Type','application/json');
    xhr.setRequestHeader('X-K99-Local','1');
    xhr.send(JSON.stringify(input));
    const reply = JSON.parse(xhr.responseText);
    if (xhr.status !== 200) throw new Error(reply.error || 'SQLite 저장 실패');
    return reply.result;
  }
  const storage: Storage = {
    get length() {return (sync({op:'keys'}) as string[]).length;},
    key(index:number) {return (sync({op:'keys'}) as string[])[index] ?? null;},
    getItem(key:string) {
      const value = sync({op:'get',key:String(key)}) as string|null;
      seen.set(key,value); return value;
    },
    setItem(key:string,value:string) {
      if (!seen.has(key)) storage.getItem(key);
      sync({op:'set',key:String(key),value:String(value),expected:seen.get(key)!});
      seen.set(key,String(value));
    },
    removeItem(key:string) {
      if (!seen.has(key)) storage.getItem(key);
      sync({op:'remove',key:String(key),expected:seen.get(key)!}); seen.set(key,null);
    },
    clear() {throw new Error('Windows V1에서는 전체 데이터 삭제를 허용하지 않습니다.');},
  };
  // Reused code keeps its synchronous contract; writes throw before showing a
  // success screen if SQLite or concurrency checks fail.
  Object.defineProperty(window,'localStorage',{configurable:false,get:() => storage});
  window.fetch = async (input, init) => {
    const url = new URL(input instanceof Request ? input.url : String(input), window.location.href);
    const localApi = url.protocol === window.location.protocol && url.host === window.location.host && url.pathname.startsWith('/api/');
    if (!localApi) throw new Error('1단계: 외부 서버 및 기존 장치 도우미 호출을 차단했습니다.');
    const method = (init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    if (window.k99Desktop) {
      const bodyText = init?.body ?? (input instanceof Request ? await input.clone().text() : '');
      const body = typeof bodyText === 'string' && bodyText ? JSON.parse(bodyText) : {};
      const reply = await window.k99Desktop.request({method,path:url.pathname+url.search,body});
      return new Response(JSON.stringify(reply.ok ? reply.result : {error:reply.error}),
        {status:reply.ok ? 200 : reply.status,headers:{'Content-Type':'application/json'}});
    }
    const headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
    headers.set('X-K99-Local','1');
    return realFetch(input,{...init,headers});
  };
  // Block alternative XHR network paths. sync() above alone retains the native
  // open function to reach this project's local preview transport.
  XMLHttpRequest.prototype.open = function(this: XMLHttpRequest, ...args: unknown[]) {
    const url = new URL(String(args[1]), window.location.href);
    if (url.protocol !== window.location.protocol || url.host !== window.location.host || !url.pathname.startsWith('/api/'))
      throw new Error('외부 네트워크 호출 차단');
    return Reflect.apply(realOpen,this,args);
  } as typeof realOpen;
  window.print = () => {throw new Error('태그 출력은 장비·현장 화면의 이력 관리 출력을 사용하세요.');};
  window.k99Desktop?.onChanged?.(()=>{
    seen.clear();
    window.dispatchEvent(new StorageEvent('storage',{key:'k99-confirmed-orders-v1'}));
    window.dispatchEvent(new Event('k99-equipment-changed'));
  });
  // Foot-switch presses arrive over IPC and are re-dispatched as a DOM event so
  // only a mounted, camera-ready capture view reacts to them.
  window.k99Desktop?.onFootCapture?.((data)=>{
    dispatchFootCapture(data?.accelerator ?? null);
  });
  // Detect local SQLite availability before importing any business components.
  sync({op:'keys'});
}
