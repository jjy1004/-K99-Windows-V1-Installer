import { AlertTriangle, CheckCircle2, Copy, FileText, Loader2, Phone, Send } from 'lucide-react';
import './sms-qr.css';

export function SmsComposeContents({ recipient, body, onChange, onInput, onConfirm, copied,
  canConfirm, confirmed, busy, error, status }: {
  recipient: string; body: string; onChange: (value: string) => void;
  onInput: () => void; onConfirm: () => void; copied: boolean;
  canConfirm: boolean; confirmed: boolean; busy: boolean; error?: string; status?: string;
}) {
  return <div className="sqr">
    <div className="sqr-to"><Phone aria-hidden /><b>받는 번호</b><span className="num">{recipient || '번호 없음'}</span></div>
    <label className="sqr-label" htmlFor="sms-compose-body"><FileText aria-hidden />원래 문구
      <span className="sqr-tag full">전체 {body.length}자 · 직접 수정 가능</span></label>
    <textarea id="sms-compose-body" className="sqr-textarea" value={body} disabled={busy}
      onChange={e => onChange(e.target.value)} maxLength={12000} data-korean-first="true" />
    <p className="sqr-step">[입력]을 누르면 전체 문구를 먼저 복사하고 Windows 기본 문자 앱으로 고객 번호와 원문을 전달합니다. 열린 창에서 번호·본문을 확인하고 직접 전송하세요.</p>
    <div className="sqr-row">
      <button type="button" className="lnd-btn gold" disabled={busy || !body.trim()} onClick={onInput} data-testid="button-sms-compose">
        {busy ? <Loader2 aria-hidden /> : <Copy aria-hidden />}입력
      </button>
      <button type="button" className="lnd-btn" disabled={busy || !canConfirm || confirmed} onClick={onConfirm}>
        <Send aria-hidden />{confirmed ? '메시지 발송 확인 저장됨' : '문자 앱에서 발송 완료 확인'}
      </button>
    </div>
    {copied && <p className="sqr-step" role="status">전체 문구가 복사되었습니다. 자동 채움이 안 되면 문자 앱에서 Ctrl+V로 붙여넣으세요.</p>}
    {status && <p className="sqr-step" role="status">{status}</p>}
    {!canConfirm && !confirmed && <p className="sqr-step">접수가 저장된 주문에서 발송을 준비한 뒤에만 실제 발송 확인을 기록할 수 있습니다.</p>}
    {confirmed && <p className="sqr-msg ok" role="status"><CheckCircle2 aria-hidden />직원의 실제 발송 확인을 기록했습니다.</p>}
    {error && <p className="sqr-msg err" role="alert"><AlertTriangle aria-hidden />{error}</p>}
  </div>;
}
