/** Credentials stay in this tab, never in orders, logs or permanent web storage. */
const TOKEN_KEY = 'k99-passive-photo-bridge-token-v1';
const MODE_KEY = 'k99-photo-bridge-mode-v1';
export const PHOTO_BRIDGE_SESSION_EVENT = 'k99-photo-bridge-session-changed';
export const PHOTO_BRIDGE_LOCAL_URL = 'k99-disabled://hardware';
export type PhotoBridgeMode = 'DEV' | 'TEST' | 'STORE';
export type PhotoBridgeConnectionSession = { token: string; mode: PhotoBridgeMode };
export type PhotoBridgeHealthDiagnostic =
  | { status: 'offline'; httpStatus: 0 }
  | { status: 'unpaired'; httpStatus: 401 }
  | { status: 'incompatible'; httpStatus: number }
  | { status: 'connected'; httpStatus: 200; mode: PhotoBridgeMode; photoConfigured: boolean };

function isMode(value: unknown): value is PhotoBridgeMode {
  return value === 'DEV' || value === 'TEST' || value === 'STORE';
}

export function readPhotoBridgeConnectionSession(): PhotoBridgeConnectionSession | null {
  try {
    const token = window.sessionStorage.getItem(TOKEN_KEY)?.trim();
    const mode = window.sessionStorage.getItem(MODE_KEY) ?? 'STORE';
    return token && isMode(mode) ? { token, mode } : null;
  } catch {
    return null;
  }
}

/** DEV/TEST authentication must not switch intake into hardware/photo mode. */
export function readOperationalPhotoBridgeSession(): { token: string } | null {
  const session = readPhotoBridgeConnectionSession();
  return session?.mode === 'STORE' ? { token: session.token } : null;
}

export function setPhotoBridgeConnectionSession(token: string, mode: PhotoBridgeMode): void {
  if (!isMode(mode)) throw new Error('사진 도우미 모드가 올바르지 않습니다.');
  const trimmed = token.trim();
  try {
    if (trimmed) {
      window.sessionStorage.setItem(MODE_KEY, mode);
      window.sessionStorage.setItem(TOKEN_KEY, trimmed);
    } else {
      window.sessionStorage.removeItem(TOKEN_KEY);
      window.sessionStorage.removeItem(MODE_KEY);
    }
  } catch {
    // Partial credentials must never enable a hardware session.
    try { window.sessionStorage.removeItem(TOKEN_KEY); window.sessionStorage.removeItem(MODE_KEY); } catch { /* blocked storage */ }
    throw new Error('이 브라우저에서 사진 도우미 세션을 저장할 수 없습니다.');
  }
  window.dispatchEvent(new Event(PHOTO_BRIDGE_SESSION_EVENT));
}

async function localRequest(path: string, init: RequestInit, timeoutMs = 3000): Promise<{ status: number; ok: boolean; body: unknown }> {
  const controller = new AbortController();
  const upstream = init.signal;
  const cancel = () => controller.abort();
  upstream?.addEventListener('abort', cancel, { once: true });
  if (upstream?.aborted) controller.abort();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${PHOTO_BRIDGE_LOCAL_URL}${path}`, {
      ...init, cache: 'no-store', signal: controller.signal,
    });
    // Keep the timeout active while reading the body too, not only the headers.
    let body: unknown = null;
    try { body = await response.json(); }
    catch (error) { if (response.ok && controller.signal.aborted) throw error; }
    return { status: response.status, ok: response.ok, body };
  } finally {
    clearTimeout(timer);
    upstream?.removeEventListener('abort', cancel);
  }
}

/** Selection acknowledgement is communication only, never a capture or print request. */
export async function sendPhotoBridgeSelection(orderId: string, garmentId: string, signal?: AbortSignal): Promise<boolean> {
  const session = readPhotoBridgeConnectionSession();
  if (!session) return false;
  const safe = /^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/;
  if (!safe.test(orderId) || !safe.test(garmentId)) throw new Error('의류 연결 식별자가 올바르지 않습니다.');
  const response = await localRequest('/v1/selection', {
    method: 'POST', signal,
    headers: { 'Content-Type': 'application/json', 'X-K99-Bridge-Token': session.token },
    body: JSON.stringify({ orderId, garmentId }),
  });
  const value = response.body;
  if (!response.ok || !value || typeof value !== 'object') throw new Error('의류 선택 전달을 확인하지 못했습니다.');
  const acknowledgement = value as Record<string, unknown>;
  if (acknowledgement.status !== 'selected' || acknowledgement.orderId !== orderId ||
    acknowledgement.garmentId !== garmentId || acknowledgement.mode !== session.mode) {
    throw new Error('의류 선택 연결 응답이 올바르지 않습니다.');
  }
  const current = readPhotoBridgeConnectionSession();
  return current?.token === session.token && current.mode === session.mode;
}

/** A tokenless health request diagnoses loopback availability without authenticating. */
export async function inspectPhotoBridgeConnection(): Promise<PhotoBridgeHealthDiagnostic> {
  const session = readPhotoBridgeConnectionSession();
  try {
    const response = await localRequest('/v1/health', {
      headers: session
        ? { Accept: 'application/json', 'X-K99-Bridge-Token': session.token }
        : { Accept: 'application/json' },
    });
    if (response.status === 401) return { status: 'unpaired', httpStatus: 401 };
    let value = response.body;
    let photoConfigured: boolean | undefined;
    if (session && response.status === 404 && session.mode === 'STORE') {
      // Old, already configured helpers keep their existing authenticated probe.
      const legacyResponse = await localRequest('/v1/settings', {
        headers: { Accept: 'application/json', 'X-K99-Bridge-Token': session.token },
      });
      value = legacyResponse.body;
      if (legacyResponse.ok && value && typeof value === 'object') {
        const settings = value as Record<string, unknown>;
        if (typeof settings.configured === 'boolean' &&
            typeof settings.sourceRoot === 'string' && typeof settings.destinationRoot === 'string') {
          photoConfigured = settings.configured;
        }
      }
      if (photoConfigured !== undefined) {
        const current = readPhotoBridgeConnectionSession();
        return current?.token === session.token && current.mode === session.mode
          ? { status: 'connected', httpStatus: 200, mode: session.mode, photoConfigured }
          : { status: 'incompatible', httpStatus: legacyResponse.status };
      }
    }
    if (!session) return { status: 'incompatible', httpStatus: response.status };
    if (response.ok && value && typeof value === 'object') {
      const health = value as Record<string, unknown>;
      if (health.status === 'ok' && health.mode === session.mode &&
          typeof health.photoConfigured === 'boolean' && health.hardwareVerified === false) {
        const current = readPhotoBridgeConnectionSession();
        if (current?.token === session.token && current.mode === session.mode) {
          return {
            status: 'connected', httpStatus: 200, mode: session.mode,
            photoConfigured: health.photoConfigured,
          };
        }
        return { status: 'incompatible', httpStatus: response.status };
      }
    }
    return { status: 'incompatible', httpStatus: response.status };
  } catch {
    return { status: 'offline', httpStatus: 0 };
  }
}

export async function checkPhotoBridgeConnection(): Promise<boolean> {
  const diagnostic = await inspectPhotoBridgeConnection();
  return diagnostic.status === 'connected';
}

/** Only a short-lived, single-use launch code is carried in the fragment, not the token. */
export function consumePhotoBridgeLaunchCode(): string | null {
  const url = new URL(window.location.href);
  const parameters = new URLSearchParams(url.hash.slice(1));
  if (!parameters.has('k99-bridge-pair')) return null;
  const code = parameters.get('k99-bridge-pair');
  parameters.delete('k99-bridge-pair');
  parameters.delete('k99-bridge-diagnostics');
  const remaining = parameters.toString();
  window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${remaining ? `#${remaining}` : ''}`);
  if (!code || !/^[a-f0-9]{64}$/.test(code)) throw new Error('사진 도우미 실행 연결 코드가 올바르지 않습니다.');
  return code;
}

/** Memoizing outside React avoids consuming the one-time code twice in StrictMode. */
export function createPhotoBridgeLaunchPairer(
  options: { retryDelayMs?: number; timeoutMs?: number; maxAttempts?: number } = {},
): (launchCode?: string) => Promise<void> {
  let task: Promise<void> | undefined;
  let previousCode: string | undefined;
  let generation = 0;
  let running = false;
  return (launchCode?: string) => {
    const diagnosticLaunch = new URLSearchParams(new URL(window.location.href).hash.slice(1)).get('k99-bridge-diagnostics') === '1';
    let code: string | null;
    try {
      code = launchCode ?? consumePhotoBridgeLaunchCode();
      if (code && !/^[a-f0-9]{64}$/.test(code)) throw new Error('올바른 일회용 연결 코드가 필요합니다.');
    }
    catch (error) { return Promise.reject(error); }
    // Opening a launcher URL in an existing tab may only change its fragment.
    // An earlier visit without a code must not permanently disable pairing.
    if (!code) return running && task ? task : Promise.resolve();
    if (code !== previousCode) {
      previousCode = code;
      const currentGeneration = ++generation;
      const clientNonce = Array.from(crypto.getRandomValues(new Uint8Array(32)),
        (value) => value.toString(16).padStart(2, '0')).join('');
      let stage = 'network';
      let httpStatus = 0;
      running = true;
      task = (async () => {
        const maxAttempts = Math.max(1, Math.min(6, options.maxAttempts ?? 6));
        let response: Awaited<ReturnType<typeof localRequest>> | undefined;
        let legacy = false;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
          if (currentGeneration !== generation) return;
          try {
            response = await localRequest('/v1/pair', {
              method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
              body: JSON.stringify(legacy ? { code } : { code, clientNonce }),
            }, options.timeoutMs ?? 15000);
            httpStatus = response.status;
            // Old helpers reject extra fields. Keep their one-use protocol compatible.
            if (response.status === 400 && !legacy) {
              legacy = true;
              response = await localRequest('/v1/pair', {
                method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
                body: JSON.stringify({ code }),
              }, options.timeoutMs ?? 15000);
              httpStatus = response.status;
            }
            break;
          } catch {
            // Permission prompts, slow startup and a lost reply must not permanently
            // consume the browser's only chance to connect. The same nonce safely
            // recovers the new helper's successful exchange without granting another client.
            if (attempt + 1 >= maxAttempts) throw new Error('로컬 도우미 요청에 응답이 없습니다. 브라우저 로컬 네트워크 권한 또는 네트워크·보안 차단 여부를 확인해야 합니다. HTTP 상태코드를 받지 못했습니다.');
            await new Promise((resolve) => setTimeout(resolve, options.retryDelayMs ?? 1000));
          }
        }
        if (currentGeneration !== generation) return;
        if (!response) throw new Error('사진 도우미 자동 연결을 확인하지 못했습니다.');
        stage = 'pair';
        if (!response.ok) {
          const reasons: Record<number, string> = {
            401: '이 인증 코드는 현재 도우미와 다르거나 5분이 지나 만료되었거나 이미 사용되었습니다. 연결·인증 버튼으로 기존 인증 탭을 먼저 확인하세요. 같은 파일을 반복 선택하지 마세요.',
            403: '접수 앱 Origin이 허용된 서버 주소와 다릅니다.',
            429: '인증 시도 횟수 제한에 도달했습니다.',
            415: '도우미가 JSON 인증 요청을 받지 못했습니다.',
          };
          throw new Error(`/v1/pair HTTP ${response.status}: ${reasons[response.status] || '도우미에서 인증 요청을 거절했습니다.'}`);
        }
        stage = 'body';
        const value = response.body;
        if (!value || typeof value !== 'object') throw new Error('사진 도우미 연결 응답이 올바르지 않습니다.');
        const session = value as Record<string, unknown>;
        if (typeof session.token !== 'string' || session.token.length < 24 || session.token.length > 256 ||
          session.token.trim() !== session.token || !isMode(session.mode)) {
          throw new Error('사진 도우미 연결 응답이 올바르지 않습니다.');
        }
        stage = 'storage';
        if (currentGeneration === generation) setPhotoBridgeConnectionSession(session.token, session.mode);
        if (diagnosticLaunch && currentGeneration === generation) {
          stage = 'health';
          httpStatus = 0;
          const health = await localRequest('/v1/health', {
            headers: { Accept: 'application/json', 'X-K99-Bridge-Token': session.token },
          }, options.timeoutMs ?? 15000);
          httpStatus = health.status;
          const body = health.body as Record<string, unknown> | null;
          if (!health.ok || !body || body.status !== 'ok' || body.mode !== session.mode ||
              typeof body.photoConfigured !== 'boolean' || body.hardwareVerified !== false) {
            throw new Error(`/v1/health HTTP ${health.status}: 인증 후 연결 확인 응답이 올바르지 않습니다.`);
          }
        }
      })().catch((error: unknown) => {
        // Top-level navigation, unlike fetch, can deliver a diagnostic when the
        // browser blocks HTTPS-to-loopback subresource requests. No token or
        // arbitrary error text is sent; the short-lived code authenticates it.
        // Never navigate the reception window to a legacy helper/custom URL.
        // Electron camera capture is an in-app dialog using the preload IPC.
        throw error;
      }).finally(() => {
        if (currentGeneration === generation) running = false;
      });
    }
    return task ?? Promise.resolve();
  };
}