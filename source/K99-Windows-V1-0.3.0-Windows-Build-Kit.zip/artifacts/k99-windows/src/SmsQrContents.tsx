import type { ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Copy, FileText, Loader2, MessageSquareText, Phone, QrCode, Send } from 'lucide-react';
import './sms-qr.css';

export type SmsQrContentsProps = {
  recipient: string; body: string; summary: string; qr: ReactNode;
  onCopy: () => void; copied: boolean;
  onConfirm: (kind: 'summary' | 'full') => void; canConfirm: boolean;
  confirmed: boolean; busy: boolean; error?: string;
};

export function SmsQrContents({ recipient, body, summary, qr, onCopy, copied, onConfirm, canConfirm, confirmed, busy, error }: SmsQrContentsProps) {
  const differs = summary.trim() !== body.trim();
  return (
    <div className="sqr">
      <div className="sqr-to"><Phone aria-hidden="true" /><b>받는 번호</b><span className="num">{recipient || '번호 없음'}</span></div>

      {differs && (
        <p className="sqr-diff" role="note"><AlertTriangle aria-hidden="true" />
          <span><b>QR에는 요약 {summary.length}자만 들어 있습니다.</b> 면책·추가요금 동의는 원문을 별도로 보내 주세요.
            QR 열기·복사는 아직 발송이 아닙니다. 휴대폰에서 직접 [전송]한 뒤 아래 확인 버튼을 눌러 주세요.</span>
        </p>
      )}

      <div className="sqr-grid">
        <div className="sqr-col">
          <label className="sqr-label" htmlFor="sqr-full"><FileText aria-hidden="true" />원래 문구<span className="sqr-tag full">전체 {body.length}자 · 수정 불가</span></label>
          <textarea id="sqr-full" className="sqr-textarea" readOnly value={body} aria-readonly="true" />
          <p className="sqr-label">QR에 담긴 짧은 안내</p>
          <p className="sqr-summary" aria-label="QR에 담긴 요약 문자">{summary}</p>
        </div>

        <div className="sqr-col sqr-qrbox">
          <p className="sqr-label"><QrCode aria-hidden="true" />휴대폰 카메라로 비추기<span className="sqr-tag short">요약 {summary.length}자</span></p>
          <div className="sqr-qr">{qr}</div>
          <button type="button" className="lnd-btn sqr-copy" onClick={onCopy} disabled={busy}>
            {copied ? <CheckCircle2 aria-hidden="true" /> : <Copy aria-hidden="true" />}
            {copied ? '긴 문구 복사됨 (다시 복사)' : '긴 문구 복사하기'}
          </button>
        </div>
      </div>

      <div className="sqr-row" role="group" aria-label="직원이 실제 전송을 확인">
        <button type="button" className="lnd-btn gold" disabled={!canConfirm || busy || confirmed} onClick={() => onConfirm('summary')}>
          {busy ? <Loader2 aria-hidden="true" /> : <MessageSquareText aria-hidden="true" />}요약 문자(QR)를 휴대폰에서 보냈어요
        </button>
        {copied && (
          <button type="button" className="lnd-btn" disabled={busy || confirmed} onClick={() => onConfirm('full')}>
            <Send aria-hidden="true" />원래 긴 문구를 직접 보냈어요
          </button>
        )}
      </div>
      {!canConfirm && !confirmed && <p className="sqr-step">접수를 저장한 주문에서만 발송 완료를 기록할 수 있습니다. QR 스캔과 문구 복사는 지금도 사용할 수 있습니다.</p>}
      {busy && <p className="sqr-step" role="status">저장 중입니다…</p>}
      {confirmed && <p className="sqr-msg ok" role="status"><CheckCircle2 aria-hidden="true" />발송 완료로 기록했습니다.</p>}
      {error && <p className="sqr-msg err" role="alert"><AlertTriangle aria-hidden="true" /><span>{error}</span></p>}
    </div>
  );
}
