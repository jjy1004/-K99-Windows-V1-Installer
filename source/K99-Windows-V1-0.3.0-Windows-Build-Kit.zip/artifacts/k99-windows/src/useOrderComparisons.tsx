import { useCallback, useEffect, useRef, useState } from 'react';
import { directoryRequest } from './customer-directory-client';
import { ComparisonViewer, isComparisonGallery, type ComparisonGalleryState } from './ComparisonGallery';

type View = { mode: 'remote' | 'staff'; gallery: ComparisonGalleryState; note?: string };
export function useOrderComparisons(orderIds: string[], refreshKey = '') {
  const key = JSON.stringify([...new Set(orderIds)].sort()), ids = useRef(orderIds);
  ids.current = orderIds;
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [view, setView] = useState<View | null>(null), viewRef = useRef<View | null>(null);
  const [note, setNote] = useState(''), [opening, setOpening] = useState(false);
  const openingRef = useRef(false), alive = useRef(true);
  viewRef.current = view;
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      const id = viewRef.current?.gallery.id;
      if (id) void directoryRequest('POST', '/api/comparison-gallery/command', { sessionId: id, direction: 'close' }).catch(() => {});
    };
  }, []);
  useEffect(() => {
    if (!window.k99Desktop) { setCounts({}); return; }
    let live = true, request = 0;
    const refresh = async () => {
      const current = ++request;
      try {
        const result: Record<string, number> = {};
        for (let i = 0; i < ids.current.length; i += 50) {
          const r = await directoryRequest<{ counts: Record<string, number> }>('POST', '/api/comparison-gallery/inventory', { orderIds: ids.current.slice(i, i + 50) });
          Object.assign(result, r.counts);
        }
        if (live && current === request) setCounts(result);
      } catch {
        if (live && current === request) { setCounts({}); setNote('완성된 전후 사진 파일을 확인하지 못했습니다.'); }
      }
    };
    setCounts({}); void refresh();
    const timer = window.setInterval(() => void refresh(), 15000), focus = () => void refresh();
    window.addEventListener('focus', focus); window.addEventListener('k99:changed', focus);
    return () => { live = false; clearInterval(timer); window.removeEventListener('focus', focus); window.removeEventListener('k99:changed', focus); };
  }, [key, refreshKey]);
  useEffect(() => window.k99Desktop?.onCustomerConnection(data => {
    if (data.type === 'COMPARISON_UPDATE' && isComparisonGallery(data.gallery)) {
      const gallery = data.gallery;
      setView(old => old?.gallery.id === gallery.id ? { ...old, gallery, note: '고객 모니터 송출 중 · 이미지 표시 확인 중' } : old);
    } else if (data.type === 'COMPARISON_CLOSED') setView(old => old?.gallery.id === data.sessionId ? null : old);
    else if (data.type === 'COMPARISON_STATUS') setView(old => old && old.gallery.id === data.sessionId
      ? { ...old, note: data.loaded ? '고객 모니터 이미지 표시 확인' : data.error || '고객 화면의 사진을 확인해 주세요.' } : old);
  }), []);
  const open = useCallback(async (orderId: string) => {
    if (openingRef.current) return;
    openingRef.current = true; setOpening(true); setNote('');
    try {
      const result = await directoryRequest<View>('POST', '/api/comparison-gallery/show', { orderId });
      if (!isComparisonGallery(result.gallery) || !['remote', 'staff'].includes(result.mode)) throw Error('잘못된 전후 사진 응답입니다.');
      if (!alive.current) {
        await directoryRequest('POST', '/api/comparison-gallery/command', { sessionId: result.gallery.id, direction: 'close' }); return;
      }
      setView({ ...result, note: result.mode === 'remote' ? '고객 모니터 송출 중 · 이미지 표시 확인 중' : result.note });
    } catch (error) {
      if (alive.current) { setNote(error instanceof Error ? error.message : '전후 사진을 열지 못했습니다.'); setCounts(old => ({ ...old, [orderId]: 0 })); }
    } finally { openingRef.current = false; if (alive.current) setOpening(false); }
  }, []);
  const control = useCallback(async (direction: 'next' | 'previous' | 'close') => {
    const active = viewRef.current; if (!active) return;
    try {
      const result = await directoryRequest<{ gallery?: unknown; closed?: boolean }>('POST', '/api/comparison-gallery/command', { sessionId: active.gallery.id, direction });
      if (!alive.current) return;
      if (direction === 'close' || result.closed) setView(null);
      else if (isComparisonGallery(result.gallery)) {
        const gallery = result.gallery;
        setView(old => old?.gallery.id === gallery.id ? { ...old, gallery } : old);
      }
    } catch (error) {
      if (alive.current) setView(old => old ? { ...old, note: error instanceof Error ? error.message : '사진 제어에 실패했습니다.' } : old);
    }
  }, []);
  return { counts, note, opening, open, viewer: view && <ComparisonViewer gallery={view.gallery} compact={view.mode === 'remote'}
    note={view.note} onMove={direction => void control(direction)} onClose={() => void control('close')} /> };
}
