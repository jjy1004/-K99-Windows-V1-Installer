/** Manual software controls only. Defaults preserve the original pixels. */
export type CameraResolution='HD'|'FHD'|'2K';
export type CameraColorProfile={
  version:2;brightness:number;contrast:number;temperature:number;saturation:number;sharpness:number;
  resolution:CameraResolution;
};
export const DEFAULT_CAMERA_COLOR:CameraColorProfile={
  version:2,brightness:0,contrast:0,temperature:0,saturation:0,sharpness:0,resolution:'FHD',
};
export const CAMERA_RESOLUTIONS={HD:[1280,720],FHD:[1920,1080],'2K':[2560,1440]} as const;
const KEY='k99-manual-camera-profiles-v2';
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function validColorProfile(value:unknown):value is CameraColorProfile{
  const p=value as CameraColorProfile;
  return !!p&&p.version===2&&['HD','FHD','2K'].includes(p.resolution)&&
    (['brightness','contrast','temperature','saturation'] as const).every(k=>Number.isFinite(p[k])&&Math.abs(p[k])<=50)&&
    Number.isFinite(p.sharpness)&&p.sharpness>=0&&p.sharpness<=100;
}
export function neutralCameraColor(p:CameraColorProfile){
  return p.brightness===0&&p.contrast===0&&p.temperature===0&&p.saturation===0&&p.sharpness===0;
}
export function loadCameraColor(device:string,storage:Pick<Storage,'getItem'>=localStorage):CameraColorProfile{
  try{
    const value=JSON.parse(storage.getItem(KEY)||'{}')?.[device];
    if(validColorProfile(value))return {...value};
  }catch{/* Optional settings never prevent the baseline camera from opening. */}
  return {...DEFAULT_CAMERA_COLOR};
}
export function saveCameraColor(device:string,value:CameraColorProfile,storage:Pick<Storage,'getItem'|'setItem'>=localStorage){
  if(!device||device.length>512||!validColorProfile(value))throw Error('카메라 수동 설정이 올바르지 않습니다.');
  let all:Record<string,CameraColorProfile>={};
  const raw=storage.getItem(KEY);
  if(raw){
    const parsed=JSON.parse(raw);
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('기존 카메라 설정을 읽지 못해 저장하지 않았습니다.');
    all=parsed;
  }
  Object.defineProperty(all,device,{value:{...value},enumerable:true,configurable:true,writable:true});
  storage.setItem(KEY,JSON.stringify(all));
}
export function makeColorTransform(p:CameraColorProfile){
  if(!validColorProfile(p))throw Error('수동 화질 설정 범위를 확인하세요.');
  return (frame:{width:number;height:number;data:Uint8ClampedArray})=>{
    const {width:w,height:h,data}=frame;
    if(w*h*4!==data.length)throw Error('사진 픽셀 크기가 올바르지 않습니다.');
    if(neutralCameraColor(p))return;
    const gain=1+p.brightness/100,contrast=1+p.contrast/100,sat=1+p.saturation/100,warm=p.temperature/250;
    const tables=[1+warm,1,1-warm].map(t=>Float32Array.from({length:256},
      (_,v)=>(v*gain*t-127.5)*contrast+127.5));
    for(let i=0;i<data.length;i+=4){
      const r=tables[0][data[i]],g=tables[1][data[i+1]],b=tables[2][data[i+2]],l=.2126*r+.7152*g+.0722*b;
      data[i]=clamp(l+(r-l)*sat,0,255);data[i+1]=clamp(l+(g-l)*sat,0,255);data[i+2]=clamp(l+(b-l)*sat,0,255);
    }
    if(p.sharpness===0)return;
    const source=new Uint8ClampedArray(data),amount=p.sharpness/200;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const at=(y*w+x)*4,left=(y*w+Math.max(0,x-1))*4,right=(y*w+Math.min(w-1,x+1))*4;
      const top=(Math.max(0,y-1)*w+x)*4,bottom=(Math.min(h-1,y+1)*w+x)*4;
      for(let c=0;c<3;c++)data[at+c]=clamp(source[at+c]+amount*(4*source[at+c]-
        source[left+c]-source[right+c]-source[top+c]-source[bottom+c]),0,255);
    }
  };
}
export function correctCameraCanvas(context:CanvasRenderingContext2D,profile:CameraColorProfile){
  if(neutralCameraColor(profile))return;
  const frame=context.getImageData(0,0,context.canvas.width,context.canvas.height);
  makeColorTransform(profile)(frame);context.putImageData(frame,0,0);
}
