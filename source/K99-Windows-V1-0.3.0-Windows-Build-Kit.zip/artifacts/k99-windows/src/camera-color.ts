import type {HardwarePreferences} from './camera-hardware';
/** Standard preserves raw pixels; a verified white reference is optional. */
export type CameraResolution='HD'|'FHD'|'2K';
export type CameraColorProfile={
  version:2;brightness:number;contrast:number;temperature:number;saturation:number;sharpness:number;
  resolution:CameraResolution;
  calibrationMode?:'natural'|'standard';
  reference?:{red:number;green:number;blue:number;gain:number;gamma:number};
  hardware?:HardwarePreferences;
};
export const DEFAULT_CAMERA_COLOR:CameraColorProfile={
  version:2,brightness:0,contrast:0,temperature:0,saturation:0,sharpness:0,resolution:'FHD',
};
export const CAMERA_RESOLUTIONS={HD:[1280,720],FHD:[1920,1080],'2K':[2560,1440]} as const;
const KEY='k99-manual-camera-profiles-v2';
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function validColorProfile(value:unknown):value is CameraColorProfile{
  const p=value as CameraColorProfile;
  return !!p&&p.version===2&&['HD','FHD','2K'].includes(p.resolution)&&
    (['brightness','contrast','temperature','saturation'] as const).every(k=>Number.isFinite(p[k])&&Math.abs(p[k])<=50)&&
    Number.isFinite(p.sharpness)&&p.sharpness>=0&&p.sharpness<=100&&
    (p.calibrationMode===undefined||['natural','standard'].includes(p.calibrationMode))&&
    (!p.reference||(['red','green','blue'] as const).every(k=>Number.isFinite(p.reference![k])&&p.reference![k]>=.7&&p.reference![k]<=1.4)&&
      Number.isFinite(p.reference.gain)&&p.reference.gain>=.75&&p.reference.gain<=1.8&&
      Number.isFinite(p.reference.gamma)&&p.reference.gamma>=1&&p.reference.gamma<=1.15)&&
    (p.hardware===undefined||!!p.hardware&&typeof p.hardware==='object'&&!Array.isArray(p.hardware)&&
      (p.hardware.exposureMode===undefined||['continuous','manual'].includes(p.hardware.exposureMode))&&
      (['exposureTime','gain','iso','exposureCompensation'] as const).every(k=>p.hardware![k]===undefined||
        Number.isFinite(p.hardware![k])&&Math.abs(p.hardware![k]!)<=1e9));
}
export function neutralCameraColor(p:CameraColorProfile){
  return !p.reference&&p.brightness===0&&p.contrast===0&&p.temperature===0&&p.saturation===0&&p.sharpness===0;
}
export function loadCameraColor(device:string,storage:Pick<Storage,'getItem'>=localStorage):CameraColorProfile{
  try{
    const value=JSON.parse(storage.getItem(KEY)||'{}')?.[device];
    if(validColorProfile(value))return {...value};
  }catch{/* Optional settings never prevent the baseline camera from opening. */}
  return {...DEFAULT_CAMERA_COLOR};
}
export function saveCameraColor(device:string,value:CameraColorProfile,storage:Pick<Storage,'getItem'|'setItem'>=localStorage){
  if(!device||device.length>512||!validColorProfile(value))throw Error('카메라 수동 설정이 올바르지 않습니다.');
  let all:Record<string,CameraColorProfile>={};
  const raw=storage.getItem(KEY);
  if(raw){
    const parsed=JSON.parse(raw);
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('기존 카메라 설정을 읽지 못해 저장하지 않았습니다.');
    all=parsed;
  }
  Object.defineProperty(all,device,{value:{...value},enumerable:true,configurable:true,writable:true});
  storage.setItem(KEY,JSON.stringify(all));
}
export function makeColorTransform(p:CameraColorProfile){
  if(!validColorProfile(p))throw Error('수동 화질 설정 범위를 확인하세요.');
  return (frame:{width:number;height:number;data:Uint8ClampedArray})=>{
    const {width:w,height:h,data}=frame;
    if(w*h*4!==data.length)throw Error('사진 픽셀 크기가 올바르지 않습니다.');
    if(neutralCameraColor(p))return;
    const gain=1+p.brightness/100,contrast=1+p.contrast/100,sat=1+p.saturation/100,warm=p.temperature/250;
    const ref=p.reference;
    const tables=[(1+warm)*(ref?.red??1),ref?.green??1,(1-warm)*(ref?.blue??1)].map(t=>Float32Array.from({length:256},
      (_,v)=>{const scaled=v*gain*t*(ref?.gain??1);
        const tone=ref?255*Math.pow(Math.max(0,scaled)/255,1/ref.gamma):scaled;
        return (tone-127.5)*contrast+127.5;}));
    for(let i=0;i<data.length;i+=4){
      const r=tables[0][data[i]],g=tables[1][data[i+1]],b=tables[2][data[i+2]],l=.2126*r+.7152*g+.0722*b;
      const maximum=Math.max(r,g,b),rolloff=ref&&maximum>245?(245+10*(1-Math.exp(-(maximum-245)/40)))/maximum:1;
      data[i]=clamp((l+(r-l)*sat)*rolloff,0,255);data[i+1]=clamp((l+(g-l)*sat)*rolloff,0,255);data[i+2]=clamp((l+(b-l)*sat)*rolloff,0,255);
    }
    if(p.sharpness===0)return;
    const source=new Uint8ClampedArray(data),amount=p.sharpness/100*.6;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const at=(y*w+x)*4,left=(y*w+Math.max(0,x-1))*4,right=(y*w+Math.min(w-1,x+1))*4;
      const top=(Math.max(0,y-1)*w+x)*4,bottom=(Math.min(h-1,y+1)*w+x)*4;
      for(let c=0;c<3;c++){
        const mean=(source[left+c]+source[right+c]+source[top+c]+source[bottom+c])/4,detail=source[at+c]-mean;
        // Do not amplify fine sensor noise, or create dark ringing at fabric edges.
        const delta=Math.abs(detail)<3?0:clamp(amount*detail,-8,8);
        data[at+c]=clamp(source[at+c]+delta,0,255);
      }
    }
  };
}
export function naturalCameraProfile(frame:{width:number;height:number;data:Uint8ClampedArray},base:CameraColorProfile){
  const {width:w,height:h,data}=frame;
  if(w<32||h<24||data.length!==w*h*4)throw Error('카메라 프레임이 준비되지 않았습니다.');
  const groups:Array<Array<[number,number,number,number]>>=[[],[],[],[]],counts=[0,0,0,0];
  const sx=Math.ceil(w*.12),sy=Math.ceil(h*.12);
  for(let y=0;y<h;y+=2)for(let x=0;x<w;x+=2){
    if(x>=sx&&x<w-sx&&y>=sy&&y<h-sy)continue;
    const edge=y<sy?0:y>=h-sy?1:x<sx?2:3;counts[edge]++;
    const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],hi=Math.max(r,g,b),lo=Math.min(r,g,b);
    const l=.2126*r+.7152*g+.0722*b;
    if(data[i+3]<250||l<65||l>252||!hi||(hi-lo)/hi>.2)continue;
    groups[edge].push([r,g,b,l]);
  }
  const edges=groups.map((group,k)=>{
    if(group.length<20||group.length/counts[k]<.3)return null;
    group.sort((a,b)=>b[3]-a[3]);
    const bright=group.slice(0,Math.max(10,Math.ceil(group.length*.35)));
    return [0,1,2].map(c=>bright.reduce((sum,p)=>sum+p[c],0)/bright.length);
  }).filter((x):x is number[]=>x!==null);
  if(edges.length<3)throw Error('흰 배경을 확인하지 못했습니다. 옷이 덮지 않는 흰 바탕을 상·하·좌·우에 보이게 하고 다시 눌러 주세요.');
  const median=(a:number[])=>{const s=[...a].sort((a,b)=>a-b);return s[Math.floor(s.length/2)];};
  const red=median(edges.map(x=>x[0])),green=median(edges.map(x=>x[1])),blue=median(edges.map(x=>x[2]));
  if(edges.some(x=>Math.abs(x[0]/x[1]-red/green)>.1||Math.abs(x[2]/x[1]-blue/green)>.1))
    throw Error('배경 색이 균일하지 않습니다. 흰 바탕·조명을 확인한 뒤 다시 눌러 주세요.');
  const luma=.2126*red+.7152*green+.0722*blue,gamma=clamp(1+(180-luma)/600,1,1.15);
  const requestedGain=255*Math.pow(248/255,gamma)/luma;
  return {whiteLuma:luma,limited:requestedGain>1.8,profile:{...DEFAULT_CAMERA_COLOR,resolution:base.resolution,
    hardware:base.hardware,calibrationMode:'natural' as const,sharpness:12,
    reference:{red:clamp(luma/red,.7,1.4),green:clamp(luma/green,.7,1.4),blue:clamp(luma/blue,.7,1.4),
      gain:clamp(requestedGain,.75,1.8),gamma}}};
}
export function correctCameraCanvas(context:CanvasRenderingContext2D,profile:CameraColorProfile){
  if(neutralCameraColor(profile))return;
  const frame=context.getImageData(0,0,context.canvas.width,context.canvas.height);
  makeColorTransform(profile)(frame);context.putImageData(frame,0,0);
}
