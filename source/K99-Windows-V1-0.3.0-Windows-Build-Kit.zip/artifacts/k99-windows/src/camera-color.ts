export type CameraColorProfile={
  version:1;brightness:number;gamma:number;saturation:number;contrast:number;
  gains:[number,number,number];whitePoint:number;calibratedAt:string|null;
  chartMatrix?:number[][];
  brightnessAdjustment?:number;
  temperatureAdjustment?:number;
  contrastAdjustment?:number;
};
export const DEFAULT_CAMERA_COLOR:CameraColorProfile={
  version:1,brightness:1.12,gamma:1.12,saturation:.92,contrast:1.05,
  gains:[1,1,1],whitePoint:248,calibratedAt:null,
};
const KEY='k99-camera-color-profiles-v1';
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function validColorProfile(value:unknown):value is CameraColorProfile{
  const p=value as CameraColorProfile;
  return !!p&&p.version===1&&Number.isFinite(p.brightness)&&p.brightness>=.7&&p.brightness<=1.8&&
    Number.isFinite(p.gamma)&&p.gamma>=.7&&p.gamma<=1.5&&p.saturation===.92&&p.contrast===1.05&&
    (p.brightnessAdjustment===undefined||Number.isFinite(p.brightnessAdjustment)&&Math.abs(p.brightnessAdjustment)<=30)&&
    (p.temperatureAdjustment===undefined||Number.isFinite(p.temperatureAdjustment)&&Math.abs(p.temperatureAdjustment)<=50)&&
    (p.contrastAdjustment===undefined||Number.isFinite(p.contrastAdjustment)&&Math.abs(p.contrastAdjustment)<=30)&&
    p.whitePoint===248&&Array.isArray(p.gains)&&p.gains.length===3&&
    p.gains.every(v=>Number.isFinite(v)&&v>=.4&&v<=2.6)&&
    (p.calibratedAt===null||typeof p.calibratedAt==='string'&&Number.isFinite(Date.parse(p.calibratedAt)))&&
    (p.chartMatrix===undefined||Array.isArray(p.chartMatrix)&&p.chartMatrix.length===3&&p.chartMatrix.every(row=>
      Array.isArray(row)&&row.length===4&&row.every((v,i)=>Number.isFinite(v)&&Math.abs(v)<=(i===3?100:3))));
}
export function loadCameraColor(device:string,storage:Pick<Storage,'getItem'>=localStorage):CameraColorProfile{
  const raw=storage.getItem(KEY);
  if(!raw)return {...DEFAULT_CAMERA_COLOR,gains:[1,1,1]};
  try{
    const value=JSON.parse(raw)?.[device];
    if(validColorProfile(value))return value;
  }catch{/* A corrupt optional profile never blocks capture. */}
  return {...DEFAULT_CAMERA_COLOR,gains:[1,1,1]};
}
export function saveCameraColor(device:string,value:CameraColorProfile,storage:Pick<Storage,'getItem'|'setItem'>=localStorage){
  if(!device||device.length>512||!validColorProfile(value))throw Error('카메라 색감 설정이 올바르지 않습니다.');
  let all:Record<string,CameraColorProfile>={};
  const raw=storage.getItem(KEY);
  if(raw){try{const parsed=JSON.parse(raw);if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))all=parsed;}catch{
    throw Error('기존 카메라 색감 설정을 읽지 못했습니다. 저장하지 않았습니다.');
  }}
  // defineProperty handles even a literal "__proto__" device id safely.
  Object.defineProperty(all,device,{value,enumerable:true,configurable:true,writable:true});
  storage.setItem(KEY,JSON.stringify(all)); // Installed app commits this to SQLite synchronously.
}
function tone(v:number,gain:number,p:CameraColorProfile){
  const corrected=(Math.pow(Math.max(0,v/255*gain*p.brightness*(1+(p.brightnessAdjustment||0)/100)),1/p.gamma)-.5)*p.contrast*(1+(p.contrastAdjustment||0)/100)*255+127.5;
  // Soft highlight shoulder, not a hard white clip: brighter white fabric
  // must retain texture above the calibrated 248 background.
  return clamp(corrected>232?232+23*(1-Math.exp(-(corrected-232)/48)):corrected,0,255);
}
export function makeColorTransform(p:CameraColorProfile){
  if(!validColorProfile(p))throw Error('색감 보정 계수 오류');
  const temperature=(p.temperatureAdjustment||0)/500;
  const tables=p.gains.map((g,c)=>Float32Array.from({length:256},(_,v)=>tone(v,g*(c===0?1+temperature:c===2?1-temperature:1),p)));
  const m=p.chartMatrix;
  return (data:Uint8ClampedArray)=>{
    for(let i=0;i<data.length;i+=4){
      const r=tables[0][data[i]],g=tables[1][data[i+1]],b=tables[2][data[i+2]];
      const l=.2126*r+.7152*g+.0722*b;
      const r1=l+(r-l)*p.saturation,g1=l+(g-l)*p.saturation,b1=l+(b-l)*p.saturation;
      data[i]=clamp(m?m[0][0]*r1+m[0][1]*g1+m[0][2]*b1+m[0][3]:r1,0,255);
      data[i+1]=clamp(m?m[1][0]*r1+m[1][1]*g1+m[1][2]*b1+m[1][3]:g1,0,255);
      data[i+2]=clamp(m?m[2][0]*r1+m[2][1]*g1+m[2][2]*b1+m[2][3]:b1,0,255);
    }
  };
}
export function correctCameraCanvas(context:CanvasRenderingContext2D,profile:CameraColorProfile){
  const frame=context.getImageData(0,0,context.canvas.width,context.canvas.height);
  makeColorTransform(profile)(frame.data);context.putImageData(frame,0,0);
}
type Frame={width:number;height:number;data:Uint8ClampedArray};
export function calibrateWhiteFrame(frame:Frame,now=new Date().toISOString()):CameraColorProfile{
  const {width:w,height:h,data}=frame;
  if(w<32||h<32||data.length!==w*h*4)throw Error('카메라 프레임을 준비한 뒤 다시 눌러 주세요.');
  const edges:[number,number,number][][]=[[],[],[],[]];
  const step=Math.max(1,Math.floor(Math.min(w,h)/100));
  for(let y=0;y<h;y+=step)for(let x=0;x<w;x+=step){
    const side=y<h*.08?0:y>=h*.92?1:x<w*.08?2:x>=w*.92?3:-1;
    if(side<0)continue;
    const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],mean=(r+g+b)/3;
    if(data[i+3]>=250&&mean>=70&&Math.max(r,g,b)-Math.min(r,g,b)<=85)
      edges[side].push([r,g,b]);
  }
  const means=edges.map(edge=>{
    if(edge.length<10)throw Error('상·하·좌·우에 흰 바탕이 보이도록 의류를 정리해 주세요. 기존 색감은 유지됩니다.');
    edge.sort((a,b)=>(a[0]+a[1]+a[2])-(b[0]+b[1]+b[2]));
    const use=edge.slice(Math.floor(edge.length*.25),Math.ceil(edge.length*.9));
    return [0,1,2].map(c=>use.reduce((sum,rgb)=>sum+rgb[c],0)/use.length);
  });
  const luminances=means.map(rgb=>rgb.reduce((a,b)=>a+b)/3);
  if(Math.max(...luminances)-Math.min(...luminances)>45)
    throw Error('흰 바탕에 그림자나 의류가 많습니다. 조명을 고르게 한 뒤 다시 눌러 주세요.');
  const rgb=[0,1,2].map(c=>means.reduce((sum,edge)=>sum+edge[c],0)/4);
  const average=rgb.reduce((a,b)=>a+b)/3;
  const profile:CameraColorProfile={...DEFAULT_CAMERA_COLOR,
    brightness:clamp(1.12*220/average,.85,1.5),gamma:clamp(1.12+(200-average)/1000,.95,1.25),
    gains:[1,1,1],calibratedAt:now};
  profile.gains=rgb.map(value=>{
    let low=.4,high=2.6;
    for(let i=0;i<24;i++){const mid=(low+high)/2;
      if(tone(value,mid,profile)<247.9)low=mid;else high=mid;
    }
    if(high>=2.59)throw Error('바탕이 너무 어둡습니다. 조명을 밝힌 뒤 다시 맞춰 주세요.');
    return high;
  }) as [number,number,number];
  return profile;
}

/** Only software pixels are adjusted. No UVC capability/constraint calls. */
export function automaticWhiteProfile(frame:Frame,previous:CameraColorProfile,settings:CameraColorProfile,first=false):CameraColorProfile{
  const candidate=calibrateWhiteFrame(frame,settings.calibratedAt||new Date().toISOString());
  const blend=(a:number,b:number)=>first?b:a+clamp(b-a,-.08,.08)*.25;
  return {...candidate,brightness:blend(previous.brightness,candidate.brightness),
    gamma:blend(previous.gamma,candidate.gamma),gains:candidate.gains.map((g,i)=>blend(previous.gains[i],g)) as [number,number,number],
    chartMatrix:settings.chartMatrix,brightnessAdjustment:settings.brightnessAdjustment||0,
    temperatureAdjustment:settings.temperatureAdjustment||0,contrastAdjustment:settings.contrastAdjustment||0};
}
