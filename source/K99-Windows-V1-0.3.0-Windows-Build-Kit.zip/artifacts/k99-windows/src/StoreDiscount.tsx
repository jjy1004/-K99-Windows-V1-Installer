import {useEffect,useState} from 'react';
import {noticeApi,calculateStoreQuote,type StoreProfile,type NoticeQuote} from './notice-api';
import './store-discount.css';

export type DiscountSummary=NoticeQuote & {threshold:number};
const thresholdText=(n:number)=>n%10000===0?`${n/10000}만 원`:`${n.toLocaleString('ko-KR')}원`;
export function storeDiscount(subtotal:number,profile:StoreProfile|null,review=false):DiscountSummary{
  if(!profile)return {subtotal,rate:0,discount:0,reviewDiscount:0,total:subtotal,threshold:0};
  const quote=calculateStoreQuote(subtotal,profile,review);
  const d=profile.discounts;
  const threshold=quote.rate?(d.secondThreshold>0&&d.secondRate>0&&subtotal>=d.secondThreshold
    ?d.secondThreshold:d.firstThreshold):0;
  return {...quote,threshold};
}
export function useStoreDiscountPolicy(){
  const [profile,setProfile]=useState<StoreProfile|null>(null);
  const [error,setError]=useState('');
  useEffect(()=>{
    let live=true,sequence=0;
    const load=()=>{const request=++sequence;
      void noticeApi<{profile:StoreProfile}>('GET','/profile').then(r=>{
        if(live&&request===sequence){setProfile(r.profile);setError('');}
      }).catch(()=>{if(live&&request===sequence)setError('매장 할인 설정을 확인하지 못했습니다. 최종 접수에서 할인 금액을 확인해 주세요.');});
    };
    load();window.addEventListener('k99-store-profile-changed',load);
    return()=>{live=false;window.removeEventListener('k99-store-profile-changed',load);};
  },[]);
  return {profile,error};
}
export function DiscountNotice({quote,customer=false}:{quote?:DiscountSummary;customer?:boolean}){
  if(!quote?.discount)return null;
  const threshold=thresholdText(quote.threshold);
  const won=(n:number)=>`${n.toLocaleString('ko-KR')}원`;
  return <div className={`store-discount ${customer?'store-discount--customer':''}`}
    data-testid={customer?'customer-discount-banner':'intake-discount-badge'} role="status">
    <strong>{customer?'✨':'🎉'} {threshold} 이상 {customer?'고객 ':''}{quote.rate}% 할인 {customer?'혜택 적용!':'적용'}</strong>
    {customer?<><del>정상가 {won(quote.subtotal)}</del><span>할인 전 {won(quote.subtotal)} → 최종 <b>{won(quote.total)}</b></span></>
      :<span>(-{won(quote.discount)}) · 할인 전 {won(quote.subtotal)}</span>}
    {quote.reviewDiscount>0&&<span>리뷰 확인 추가 할인 -{won(quote.reviewDiscount)}</span>}
  </div>;
}
export function StoreBenefits({policy}:{policy?:StoreProfile['discounts']}){
  if(!policy)return null;
  const tiers=[[policy.firstThreshold,policy.firstRate],[policy.secondThreshold,policy.secondRate]]
    .filter(([threshold,rate])=>threshold>0&&rate>0);
  const review=policy.reviewThreshold>0&&policy.reviewDiscount>0;
  if(!tiers.length&&!review)return null;
  return <div className="customer-benefits" data-testid="customer-event-banner">
    <h2>🎉 세탁할수록 커지는 혜택</h2><ul>
      {tiers.map(([threshold,rate],i)=><li key={i}>• {thresholdText(threshold)} 이상 결제 시: <strong>{rate}% 할인</strong></li>)}
      {review&&<li>• {thresholdText(policy.reviewThreshold)} 이상 고객 영수증 리뷰 작성 확인 시: <strong>{policy.reviewDiscount.toLocaleString('ko-KR')}원 할인</strong></li>}
    </ul>
  </div>;
}
