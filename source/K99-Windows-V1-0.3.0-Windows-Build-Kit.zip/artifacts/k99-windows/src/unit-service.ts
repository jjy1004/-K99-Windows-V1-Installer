import type { FinalIntakeChoices, OrderItem, ServiceLevel } from './order-record';

/** Missing per-unit choices deliberately retain a legacy order's original grade. */
export function unitService(choices: Pick<FinalIntakeChoices, 'serviceLevel' | 'unitServiceLevels'>,
  itemIndex: number, unitIndex: number): ServiceLevel {
  return choices.unitServiceLevels?.[itemIndex]?.[unitIndex] ?? choices.serviceLevel;
}

export function unitPrice(item: OrderItem, choices: Pick<FinalIntakeChoices, 'serviceLevel' | 'unitServiceLevels'>,
  itemIndex: number, unitIndex: number): number {
  return !item.isSneaker && unitService(choices, itemIndex, unitIndex) === 'premium'
    ? item.premiumPrice : item.generalPrice;
}

export function itemTotal(item: OrderItem, choices: Pick<FinalIntakeChoices, 'serviceLevel' | 'unitServiceLevels'>,
  itemIndex: number): number {
  return Array.from({ length: item.quantity }, (_, u) => unitPrice(item, choices, itemIndex, u))
    .reduce((sum, price) => sum + price, 0);
}

export function validateUnitServices(items: OrderItem[], choices: FinalIntakeChoices): void {
  const levels = choices.unitServiceLevels;
  if (levels === undefined) return;
  if (!Array.isArray(levels) || levels.length !== items.length ||
      items.some((item, i) => !Array.isArray(levels[i]) || levels[i].length !== item.quantity ||
        levels[i].some(level => level !== 'general' && level !== 'premium')))
    throw new Error('세탁물 한 벌마다 서비스 등급을 확인해 주세요.');
}
