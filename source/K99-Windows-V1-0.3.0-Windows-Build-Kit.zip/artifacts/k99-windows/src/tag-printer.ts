import { createTagData, type GarmentRecord, type GarmentTagData } from './garment-record.ts';
import type { ConfirmedOrder } from './order-record';

export type BarcodeType = 'code128' | 'qr';
export type PrinterOperationStatus = 'simulated' | 'printed';

export type TagPrinterSettings = {
  printerModel: string;
  copies: number;
  barcodeType: BarcodeType;
  templateMode?: 'barcode' | 'legacy';
  printerName?: string;
  labelWidthMm?: number;
  labelHeightMm?: number;
  gapMm?: number;
  speed?: number;
  density?: number;
  orientation?: 'portrait' | 'landscape';
  barcodeWidthMm?: number;
  barcodeHeightMm?: number;
  labelMarginMm?: number;
  qrSizeMm?: number;
  fontSizePt?: number;
};

export type PrinterOperationResult = {
  status: PrinterOperationStatus;
  requestId: string;
  orderId?: string;
  garmentId?: string;
  message?: string;
};

export interface TagPrinterAdapter {
  getPrinterStatus(): Promise<Record<string, unknown>>;
  printGarmentTag(tagData: GarmentTagData, requestId: string): Promise<PrinterOperationResult>;
  reprintGarmentTag(tagData: GarmentTagData, requestId: string): Promise<PrinterOperationResult>;
  testPrint(requestId: string): Promise<PrinterOperationResult>;
}

/**
 * Application-facing tag functions keep UI code independent of printer details.
 * They delegate to the existing record generator and adapter APIs.
 */
export function generateGarmentTag(order: ConfirmedOrder, garment: GarmentRecord): GarmentTagData {
  return createTagData(order, garment);
}

export function printGarmentTag(
  printer: TagPrinterAdapter,
  tagData: GarmentTagData,
  requestId: string,
): Promise<PrinterOperationResult> {
  return printer.printGarmentTag(tagData, requestId);
}

export function reprintGarmentTag(
  printer: TagPrinterAdapter,
  tagData: GarmentTagData,
  requestId: string,
): Promise<PrinterOperationResult> {
  return printer.reprintGarmentTag(tagData, requestId);
}

export function testPrint(
  printer: TagPrinterAdapter,
  requestId: string,
): Promise<PrinterOperationResult> {
  return printer.testPrint(requestId);
}

export const DEFAULT_TAG_PRINTER_SETTINGS: Readonly<TagPrinterSettings> = Object.freeze({
  printerModel: 'TSC TE210',
  copies: 1,
  barcodeType: 'code128',
});

export function createTagPrinterSettings(
  overrides: Partial<TagPrinterSettings> = {},
): TagPrinterSettings {
  const settings = { ...DEFAULT_TAG_PRINTER_SETTINGS, ...overrides };
  if (!settings.printerModel.trim()) throw new Error('프린터 모델을 입력해 주세요.');
  if (!Number.isInteger(settings.copies) || settings.copies < 1) {
    throw new Error('인쇄 매수는 1 이상의 정수여야 합니다.');
  }
  if (settings.barcodeType !== 'code128' && settings.barcodeType !== 'qr') {
    throw new Error('바코드 형식은 code128 또는 qr이어야 합니다.');
  }
  if (settings.templateMode !== undefined && settings.templateMode !== 'barcode' && settings.templateMode !== 'legacy')
    throw new Error('라벨 서식은 바코드 또는 기존 3줄 서식이어야 합니다.');
  for (const key of ['labelWidthMm', 'labelHeightMm', 'gapMm', 'speed', 'density',
    'barcodeWidthMm', 'barcodeHeightMm', 'labelMarginMm', 'qrSizeMm', 'fontSizePt'] as const) {
    const value = settings[key];
    if (value !== undefined && (!Number.isFinite(value) || value < 0 ||
        (key !== 'gapMm' && key !== 'labelMarginMm' && value === 0))) {
      throw new Error(`${key} 설정은 유효한 ${key === 'gapMm' || key === 'labelMarginMm' ? '0 이상의 수' : '양수'}여야 합니다.`);
    }
  }
  return settings;
}

export class SimulationTagPrinterAdapter implements TagPrinterAdapter {
  async getPrinterStatus(): Promise<Record<string, unknown>> {
    return { status: 'simulated', online: false, message: '시뮬레이션 어댑터입니다. 실제 프린터 상태를 확인하지 않았습니다.' };
  }

  async printGarmentTag(tagData: GarmentTagData, requestId: string): Promise<PrinterOperationResult> {
    return this.simulateTagOperation(tagData, requestId);
  }

  async reprintGarmentTag(tagData: GarmentTagData, requestId: string): Promise<PrinterOperationResult> {
    return this.simulateTagOperation(tagData, requestId);
  }

  async testPrint(requestId: string): Promise<PrinterOperationResult> {
    return {
      status: 'simulated',
      requestId: requireRequestId(requestId),
      message: '테스트 인쇄를 시뮬레이션했습니다. 실제 인쇄는 수행하지 않았습니다.',
    };
  }

  private simulateTagOperation(tagData: GarmentTagData, requestId: string): PrinterOperationResult {
    const data = tagData as unknown as { orderId?: string; garmentId?: string };
    return {
      status: 'simulated',
      requestId: requireRequestId(requestId),
      ...(data.orderId && { orderId: data.orderId }),
      ...(data.garmentId && { garmentId: data.garmentId }),
      message: '태그 인쇄를 시뮬레이션했습니다. 실제 인쇄는 수행하지 않았습니다.',
    };
  }
}

export function requireRequestId(requestId: string): string {
  if (typeof requestId !== 'string' || !requestId.trim()) {
    throw new Error('요청 재시도에 사용할 안정적인 requestId가 필요합니다.');
  }
  return requestId.trim();
}