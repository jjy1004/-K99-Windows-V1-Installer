import type { ReactNode } from 'react';
import type { GuideCard, PhoneScene } from './guide-data';

/* 갤럭시 One UI 느낌의 설명용 휴대폰 그림 (실제 화면 캡처 아님) */
const INK = '#1d2b30', SUB = '#6b777b', BG = '#f4f5f7', CARD = '#ffffff', BLUE = '#3e6fe0', RED = '#d4361f';
const SW = 194, SH = 384; // 화면 크기

function StatusBar({ dark = false }: { dark?: boolean }) {
  const f = dark ? '#ffffff' : INK;
  return <g fill={f}>
    <text x="16" y="20" fontSize="12" fontWeight="700">9:41</text>
    <path d="M140 19 l6 -8 l6 8 z" opacity=".9" />
    <rect x="156" y="12" width="4" height="8" rx="1" /><rect x="161" y="9" width="4" height="11" rx="1" />
    <rect x="168" y="10" width="16" height="9" rx="2" fill="none" stroke={f} strokeWidth="1.5" />
    <rect x="170" y="12" width="10" height="5" rx="1" />
  </g>;
}
function NavBar({ dark = false }: { dark?: boolean }) {
  const s = dark ? '#ffffffcc' : '#55606a';
  return <g stroke={s} strokeWidth="2" fill="none" strokeLinecap="round">
    <path d="M44 364 h3 M52 359 v10 M58 359 v10" /><rect x="88" y="358" width="14" height="12" rx="4" /><path d="M150 358 l-6 6 l6 6" />
  </g>;
}
export function Phone({ x, y = 14, children, dark = false, label }: { x: number; y?: number; children: ReactNode; dark?: boolean; label?: string }) {
  const id = `clip-${x}-${y}`;
  return <g transform={`translate(${x} ${y})`}>
    <rect x="-8" y="-8" width={SW + 16} height={SH + 16} rx="34" fill="#1b2226" />
    <rect x="-5" y="-5" width={SW + 10} height={SH + 10} rx="31" fill="none" stroke="#4a565c" strokeWidth="1.5" />
    <rect x={SW + 8} y="70" width="3" height="40" rx="1.5" fill="#3a454a" /><rect x={SW + 8} y="124" width="3" height="26" rx="1.5" fill="#3a454a" />
    <clipPath id={id}><rect width={SW} height={SH} rx="26" /></clipPath>
    <g clipPath={`url(#${id})`}>
      <rect width={SW} height={SH} fill={dark ? '#233a5a' : BG} />
      {children}
      <StatusBar dark={dark} /><NavBar dark={dark} />
    </g>
    <circle cx={SW / 2} cy="15" r="5.5" fill="#0d1114" /><circle cx={SW / 2 + 1.5} cy="13.5" r="1.4" fill="#33424a" />
    {label && <text x={SW / 2} y={SH + 30} textAnchor="middle" fontSize="16" fontWeight="800" fill={INK}>{label}</text>}
  </g>;
}
export function Finger({ x, y }: { x: number; y: number }) {
  return <g className="pg-finger" transform={`translate(${x} ${y})`}>
    <circle r="22" fill="none" stroke={RED} strokeWidth="4" opacity=".6" />
    <circle r="8" fill={RED} />
    <path d="M6 12 L6 64 Q6 80 22 84 L48 84 Q62 82 64 66 L66 38 Q66 30 58 30 Q52 30 50 36 L50 28 Q50 20 42 20 Q36 20 34 26 L34 20 Q34 12 26 12 Q20 12 18 18 L18 12 Q18 2 12 2 Q6 2 6 12 Z"
      fill="#e5543a" stroke="#8a1f10" strokeWidth="3" />
  </g>;
}
const Title = ({ t, back = false }: { t: string; back?: boolean }) => <g>
  {back && <path d="M20 58 l-6 6 l6 6" stroke={INK} strokeWidth="2.4" fill="none" strokeLinecap="round" />}
  <text x={back ? 30 : 16} y={back ? 70 : 76} fontSize={back ? 17 : 24} fontWeight="800" fill={INK}>
    {t==='모바일 핫스팟 및 테더링'
      ? <><tspan x={back ? 30 : 16} y="59">모바일 핫스팟 및</tspan><tspan x={back ? 30 : 16} y="79">테더링</tspan></>
      : t}
  </text>
</g>;
function Toggle({ x, y, on }: { x: number; y: number; on: boolean }) {
  return <g transform={`translate(${x} ${y})`}>
    <rect width="38" height="22" rx="11" fill={on ? BLUE : '#c3c8cf'} />
    <circle cx={on ? 27 : 11} cy="11" r="8" fill="#fff" />
  </g>;
}
type Row = { t: string; s?: string; icon?: ReactNode; toggle?: boolean | null; hot?: boolean };
/** One UI 둥근 카드 묶음 */
function Group({ y, rows, h = 46 }: { y: number; rows: Row[]; h?: number }) {
  return <g transform={`translate(10 ${y})`}>
    <rect width={SW - 20} height={rows.length * h} rx="16" fill={CARD} />
    {rows.map((r, i) => <g key={i} transform={`translate(0 ${i * h})`}>
      {r.hot && <rect x="2" y="2" width={SW - 24} height={h - 4} rx="14" fill="#ffe3d6" stroke={RED} strokeWidth="3" />}
      {i > 0 && !r.hot && !rows[i - 1].hot && <line x1="12" x2={SW - 32} y1="0" y2="0" stroke="#e7e9ec" />}
      {r.icon && <g transform={`translate(12 ${h / 2 - 12})`}>{r.icon}</g>}
      <text x={r.icon ? 44 : 14} y={r.s ? h / 2 - 2 : h / 2 + 5} fontSize="14" fontWeight={r.hot ? 800 : 600} fill={INK}>{r.t}</text>
      {r.s && <text x={r.icon ? 44 : 14} y={h / 2 + 14} fontSize="10.5" fill={r.toggle ? BLUE : SUB}>{r.s}</text>}
      {r.toggle != null && <>
        <line x1={SW - 70} x2={SW - 70} y1="12" y2={h - 12} stroke="#e1e4e8" />
        <Toggle x={SW - 64} y={h / 2 - 11} on={r.toggle} />
      </>}
    </g>)}
  </g>;
}
const Ic = ({ c, children }: { c: string; children: ReactNode }) => <g>
  <rect width="24" height="24" rx="8" fill={c} />
  <g stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">{children}</g>
</g>;
const ICON = {
  wifi: <Ic c="#3e86e8"><path d="M6 10 q6 -5 12 0 M8.5 13 q3.5 -3 7 0" /><circle cx="12" cy="16.5" r="1" fill="#fff" /></Ic>,
  display: <Ic c="#f0a530"><circle cx="12" cy="12" r="3.5" /><path d="M12 5v1.5M12 17.5V19M5 12h1.5M17.5 12H19" /></Ic>,
  battery: <Ic c="#3fae6a"><rect x="8" y="6" width="8" height="13" rx="1.5" /><path d="M10.5 4.5h3" /></Ic>,
  apps: <Ic c="#7a63d9"><rect x="6" y="6" width="5" height="5" rx="1" /><rect x="13" y="6" width="5" height="5" rx="1" /><rect x="6" y="13" width="5" height="5" rx="1" /><rect x="13" y="13" width="5" height="5" rx="1" /></Ic>,
  share: <Ic c="#e0603f"><circle cx="12" cy="12" r="2" /><path d="M7.5 7.5 a6.5 6.5 0 0 0 0 9 M16.5 7.5 a6.5 6.5 0 0 1 0 9" /></Ic>,
};
function Gear({ s = 1 }: { s?: number }) {
  return <g transform={`scale(${s})`}>
    <rect width="44" height="44" rx="14" fill="#5d6b7a" />
    <g transform="translate(22 22)" fill="#fff">
      {Array.from({ length: 8 }, (_, i) => <rect key={i} x="-3" y="-15" width="6" height="7" rx="1.5" transform={`rotate(${i * 45})`} />)}
      <circle r="10" /><circle r="4.5" fill="#5d6b7a" />
    </g>
  </g>;
}
function Iriun({ s = 1 }: { s?: number }) {
  return <g transform={`scale(${s})`}>
    <rect width="44" height="44" rx="14" fill="#16233a" />
    <circle cx="22" cy="22" r="13" fill="none" stroke="#4fc3e8" strokeWidth="3" />
    <circle cx="22" cy="22" r="6" fill="#4fc3e8" /><circle cx="19.5" cy="19.5" r="1.8" fill="#fff" />
  </g>;
}
const AppIcon = ({ x, y, c, label, children, hot }: { x: number; y: number; c?: string; label: string; children?: ReactNode; hot?: boolean }) => <g transform={`translate(${x} ${y})`}>
  {hot && <rect x="-6" y="-6" width="56" height="74" rx="16" fill="#ffe3d6" stroke={RED} strokeWidth="3" />}
  {children ?? <rect width="44" height="44" rx="14" fill={c} />}
  <text x="22" y="58" textAnchor="middle" fontSize="10" fontWeight={hot ? 800 : 600} fill={hot ? INK : '#fff'}>{label}</text>
</g>;

function HomeScreen({ hot }: { hot: 'settings' | 'iriun' }) {
  return <g>
    <defs><linearGradient id={`wp-${hot}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#5e7fb8" /><stop offset="1" stopColor="#c99a8e" /></linearGradient></defs>
    <rect width={SW} height={SH} fill={`url(#wp-${hot})`} />
    <text x="20" y="74" fontSize="34" fontWeight="300" fill="#fff">9:41</text>
    <text x="22" y="94" fontSize="11" fill="#ffffffdd">5월 14일 화요일</text>
    <AppIcon x={18} y={150} c="#e0603f" label="카메라" />
    <AppIcon x={75} y={150} c="#3fae6a" label="갤러리" />
    <AppIcon x={132} y={150} label="Iriun" hot={hot === 'iriun'}><Iriun /></AppIcon>
    <AppIcon x={18} y={230} c="#f0a530" label="캘린더" />
    <AppIcon x={75} y={230} label="설정" hot={hot === 'settings'}><Gear /></AppIcon>
    <AppIcon x={132} y={230} c="#7a63d9" label="Play 스토어" />
    <rect x="14" y="310" width={SW - 28} height="34" rx="17" fill="#ffffff33" />
    {['#3fae6a', '#3e86e8', '#f0a530', '#e0603f'].map((c, i) => <rect key={c} x={28 + i * 40} y="315" width="24" height="24" rx="8" fill={c} />)}
  </g>;
}

const SCENES: Record<PhoneScene, { body: ReactNode; tap: [number, number] | null; dark?: boolean }> = {
  home: { body: <HomeScreen hot="settings" />, tap: [97, 252] },
  iriun: { body: <HomeScreen hot="iriun" />, tap: [154, 172] },
  settings: { body: <g><Title t="설정" />
    <rect x="10" y="92" width={SW - 20} height="30" rx="15" fill="#e6e8ec" /><circle cx="28" cy="107" r="5" fill="none" stroke={SUB} strokeWidth="2" />
    <Group y={134} h={48} rows={[{ t: '개발자 옵션', s: 'USB 디버깅 · 화면 켜짐', icon: ICON.apps, hot: true }, { t: '디스플레이', s: '밝기 · 다크 모드', icon: ICON.display }, { t: '배터리', s: '절전 모드 · 충전', icon: ICON.battery }, { t: '애플리케이션', s: '기본 앱 · 권한', icon: ICON.apps }]} />
  </g>, tap: [140, 158] },
  connections: { body: <g><Title t="연결" back />
    <Group y={90} rows={[{ t: 'Wi-Fi', s: '사용 안 함', toggle: false, hot: true }, { t: '블루투스', toggle: false }]} />
    <Group y={190} rows={[{ t: '데이터 사용', }, { t: '모바일 핫스팟 및', s: '테더링', hot: true }, { t: '기타 연결 설정' }]} />
  </g>, tap: [140, 259] },
  tethering: { body: <g><Title t="모바일 핫스팟 및 테더링" back />
    <Group y={90} h={52} rows={[{ t: '모바일 핫스팟', s: '사용 안 함', toggle: false }, { t: 'Bluetooth 테더링', toggle: false }, { t: 'USB 테더링', s: '켜짐', toggle: true, hot: true }]} />
    <rect x="10" y="262" width={SW - 20} height="56" rx="14" fill="#e3ecff" />
    <text x="20" y="284" fontSize="10.5" fill="#2a4c9c">USB 케이블이 연결되어야</text><text x="20" y="300" fontSize="10.5" fill="#2a4c9c">켤 수 있습니다.</text>
  </g>, tap: [149, 207] },
  brightness: { body: <g><Title t="디스플레이" back />
    <g transform="translate(10 90)"><rect width={SW - 20} height="96" rx="16" fill={CARD} stroke={RED} strokeWidth="3" />
      <text x="14" y="26" fontSize="14" fontWeight="800" fill={INK}>밝기</text>
      <circle cx="22" cy="58" r="5" fill="none" stroke={SUB} strokeWidth="2" />
      <rect x="36" y="53" width="120" height="10" rx="5" fill="#dfe3ea" /><rect x="36" y="53" width="14" height="10" rx="5" fill={BLUE} />
      <circle cx="46" cy="58" r="10" fill="#fff" stroke={BLUE} strokeWidth="3" />
      <text x="14" y="86" fontSize="10.5" fill={RED} fontWeight="700">← 왼쪽 끝까지 (최저)</text></g>
    <Group y={200} rows={[{ t: '자동 밝기', toggle: false }, { t: '다크 모드', toggle: false }]} />
  </g>, tap: [56, 148] },
  battery80: { body: <g><Title t="배터리 보호" back />
    <g transform="translate(10 90)"><rect width={SW - 20} height="44" rx="16" fill={CARD} /><text x="14" y="27" fontSize="14" fontWeight="700" fill={INK}>사용</text><Toggle x={SW - 64} y={11} on /></g>
    <g transform="translate(10 146)"><rect width={SW - 20} height="170" rx="16" fill={CARD} />
      {[['기본', '100% 충전'], ['적응형', '수면 중 조절'], ['최대', '80%까지만 충전']].map(([a, b], i) => <g key={a} transform={`translate(0 ${10 + i * 52})`}>
        {i === 2 && <rect x="4" y="0" width={SW - 28} height="48" rx="12" fill="#ffe3d6" stroke={RED} strokeWidth="3" />}
        <circle cx="22" cy="24" r="8" fill="none" stroke={i === 2 ? BLUE : '#b9bec6'} strokeWidth="2.4" />{i === 2 && <circle cx="22" cy="24" r="4" fill={BLUE} />}
        <text x="40" y="21" fontSize="14" fontWeight={i === 2 ? 800 : 600} fill={INK}>{a}</text><text x="40" y="37" fontSize="10.5" fill={SUB}>{b}</text>
      </g>)}
    </g>
  </g>, tap: [32, 270] },
  allow: { body: <g><rect width={SW} height={SH} fill="#00000055" />
    <g transform="translate(10 200)"><rect width={SW - 20} height="140" rx="22" fill={CARD} />
      <text x="16" y="30" fontSize="15" fontWeight="800" fill={INK}>이 PC를 허용할까요?</text>
      <text x="16" y="52" fontSize="10.5" fill={SUB}>우리 매장 PC일 때만 허용하세요.</text>
      <rect x="10" y="78" width="74" height="40" rx="20" fill="#eef0f3" /><text x="47" y="103" textAnchor="middle" fontSize="13" fontWeight="700" fill={INK}>취소</text>
      <rect x="90" y="78" width="74" height="40" rx="20" fill={BLUE} stroke={RED} strokeWidth="3" /><text x="127" y="103" textAnchor="middle" fontSize="13" fontWeight="800" fill="#fff">허용</text>
    </g></g>, tap: [137, 298] },
  appbattery: { body: <g><Title t="배터리" back />
    <text x="16" y="104" fontSize="11" fill={SUB}>Iriun Webcam · 앱 정보</text>
    <g transform="translate(10 116)"><rect width={SW - 20} height="168" rx="16" fill={CARD} />
      {[['제한 없음', '백그라운드에서 계속 사용'], ['최적화', '사용 패턴에 따라 조절'], ['제한', '백그라운드 사용 막음']].map(([a, b], i) => <g key={a} transform={`translate(0 ${8 + i * 52})`}>
        {i === 0 && <rect x="4" y="0" width={SW - 28} height="48" rx="12" fill="#ffe3d6" stroke={RED} strokeWidth="3" />}
        <circle cx="22" cy="24" r="8" fill="none" stroke={i === 0 ? BLUE : '#b9bec6'} strokeWidth="2.4" />{i === 0 && <circle cx="22" cy="24" r="4" fill={BLUE} />}
        <text x="40" y="21" fontSize="14" fontWeight={i === 0 ? 800 : 600} fill={INK}>{a}</text><text x="40" y="37" fontSize="10.5" fill={SUB}>{b}</text>
      </g>)}
    </g></g>, tap: [32, 148] },
  recents: { body: <g><rect width={SW} height={SH} fill="#2b3238" />
    {[['게임', '#7a63d9', 0], ['Iriun', '#16233a', 1]].map(([n, c, i]) => <g key={n as string} transform={`translate(${(i as number) * 104 - 6} 70)`}>
      <rect width="96" height="230" rx="16" fill={c as string} stroke={i ? '#4fc3e8' : 'none'} strokeWidth="3" />
      <text x="48" y="-10" textAnchor="middle" fontSize="12" fontWeight="800" fill="#fff">{n as string}{i ? ' (유지)' : ''}</text>
    </g>)}
    <rect x="62" y="316" width="70" height="28" rx="14" fill="#ffffffdd" stroke={RED} strokeWidth="3" /><text x="97" y="335" textAnchor="middle" fontSize="12" fontWeight="800" fill={INK}>모두 닫기 X</text>
    <path d="M42 290 v-40 M30 262 l12 -12 l12 12" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" />
  </g>, tap: [42, 230], dark: true },
  buildNumber: { body: <g><Title t="소프트웨어 정보" back />
    <Group y={94} h={64} rows={[{t:'Android 버전'},{t:'소프트웨어 버전'},{t:'빌드번호',s:'7번 연속 터치',hot:true}]} />
    <text x="97" y="326" textAnchor="middle" fontSize="17" fontWeight="900" fill={RED}>1 · 2 · 3 · 4 · 5 · 6 · 7</text>
  </g>, tap:[136,254] },
  usbDeveloper: { body: <g><Title t="개발자 옵션" back />
    <Group y={100} h={76} rows={[{t:'USB 디버깅',s:'켜기',toggle:true,hot:true},{t:'충전 중 화면',s:'켜짐 유지 · 켜기',toggle:true,hot:true}]} />
    <text x="97" y="294" textAnchor="middle" fontSize="14" fontWeight="800" fill={INK}>두 스위치 모두 켜기</text>
  </g>, tap:[148,138] },
  usbDefault: { body: <g><Title t="기본 USB 구성" back />
    <Group y={100} h={64} rows={[{t:'파일 전송',s:'Android Auto · 선택',hot:true},{t:'USB 테더링'},{t:'충전만'}]} />
    <circle cx="150" cy="132" r="8" fill={BLUE}/><circle cx="150" cy="132" r="3" fill="#fff"/>
  </g>, tap:[146,132] },
  usbBrightness: { body: <g><Title t="빠른 설정" />
    <rect x="18" y="112" width="158" height="36" rx="18" fill="#d7dde5"/>
    <circle cx="35" cy="130" r="14" fill={BLUE} stroke={RED} strokeWidth="3"/>
    <text x="97" y="178" textAnchor="middle" fontSize="14" fontWeight="800" fill={INK}>밝기 맨 왼쪽</text>
    <Group y={210} h={70} rows={[{t:'절전 모드',s:'사용 안 함',toggle:false,hot:true}]} />
  </g>, tap:[35,130] },
  iriunDim: { body: <g><Title t="Iriun Webcam" />
    <g transform="translate(144 42) scale(.65)"><Gear/></g>
    <Group y={132} h={80} rows={[{t:'Dim screen',s:'화면 어둡게 · 체크',toggle:true,hot:true}]} />
    <rect x="14" y="234" width="166" height="72" rx="12" fill="#16233a"/>
    <text x="97" y="276" textAnchor="middle" fontSize="14" fill="#fff">밝기·발열 줄이기</text>
  </g>, tap:[148,172] },
  usbDirect: { body: null, tap:null },
  lockCompare: { body: null, tap: null },
};

export function PhoneGuideScene({ card }: { card: GuideCard }) {
  const kind = card.phoneScene!;
  const label = `설명 그림(실제 화면 아님): ${card.bar}${card.hit >= 0 ? `, ${card.rows[card.hit]} 누르기` : ''}`;
  if (kind === 'usbDirect') {
    return <svg viewBox="100 0 400 440" className="pg-scene pg-phone" role="img" aria-label={label} data-phone-scene={kind}>
      <rect x="100" width="400" height="440" rx="24" fill="#eef3ee"/>
      <g transform="translate(148 60) scale(.65)"><Phone x={0}>
        <Title t="빠른 설정"/><Group y={110} h={70} rows={[{t:'Wi-Fi',s:'사용 안 함',toggle:false,hot:true}]}/>
        <text x="97" y="238" textAnchor="middle" fontSize="18" fontWeight="800" fill={RED}>와이파이 끄기</text>
      </Phone></g>
      <text x="392" y="58" textAnchor="middle" fontSize="18" fontWeight="900" fill={INK}>PC 본체 뒷면</text>
      <rect x="312" y="82" width="158" height="260" rx="16" fill="#263c46"/>
      {[104,118,132].map(y=><path key={y} d={`M332 ${y}h118`} stroke="#6d818a" strokeWidth="5"/>)}
      <rect x="337" y="172" width="108" height="100" rx="8" fill="#e9eeef"/>
      <rect x="354" y="187" width="64" height="23" rx="3" fill="#1161bb"/>
      <rect x="354" y="234" width="64" height="23" rx="3" fill="#1161bb"/>
      <path d="M211 318 C211 390 296 390 296 252 L296 200 H355" fill="none" stroke="#1b2226" strokeWidth="10"/>
      <rect x="343" y="188" width="26" height="24" rx="3" fill="#ccc" stroke={RED} strokeWidth="3"/>
      <Finger x={365} y={199}/>
      <text x="300" y="404" textAnchor="middle" fontSize="19" fontWeight="900" fill={INK}>데이터 케이블로 직접 연결</text>
      <text x="300" y="430" textAnchor="middle" fontSize="13" fill={SUB}>설명용 그림 · 기종마다 다름</text>
    </svg>;
  }
  if (kind === 'lockCompare') {
    return <svg viewBox="0 0 600 440" className="pg-scene pg-phone" role="img" aria-label={label} data-phone-scene={kind}>
      <rect width="600" height="440" rx="24" fill="#eef3ee" />
      <Phone x={60} dark label="잠금 화면">
        <rect width={SW} height={SH} fill="#1d2f4d" />
        <text x={SW / 2} y="110" textAnchor="middle" fontSize="44" fontWeight="300" fill="#fff">9:41</text>
        <text x={SW / 2} y="132" textAnchor="middle" fontSize="11" fill="#ffffffcc">5월 14일 화요일</text>
        <rect x={SW / 2 - 8} y="276" width="16" height="13" rx="3" fill="#fff" /><path d={`M${SW / 2 - 5} 276 v-4 a5 5 0 0 1 10 0 v4`} stroke="#fff" strokeWidth="2" fill="none" />
        <text x={SW / 2} y="314" textAnchor="middle" fontSize="11" fill="#fff">위로 밀어 잠금 해제</text>
      </Phone>
      <path d="M282 200 h36 M308 190 l10 10 l-10 10" stroke={RED} strokeWidth="5" fill="none" strokeLinecap="round" />
      <Phone x={346} label="잠금 해제 (홈 화면)"><HomeScreen hot="settings" /></Phone>
      <path d={`M${60 + SW / 2} 340 v-60`} stroke="#fff" strokeWidth="4" strokeDasharray="6 6" />
      <Finger x={60 + SW / 2} y={330} />
    </svg>;
  }
  const s = SCENES[kind];
  const px = 203;
  return <svg viewBox="100 0 400 440" className="pg-scene pg-phone" role="img" aria-label={label} data-phone-scene={kind}>
    <rect width="600" height="440" rx="24" fill="#eef3ee" />
    <Phone x={px} dark={s.dark}>{s.body}</Phone>
    {s.tap && <Finger x={px + s.tap[0]} y={14 + s.tap[1]} />}
    <text x="300" y="430" textAnchor="middle" fontSize="13" fill={SUB}>설명용 그림 · 기종마다 다름</text>
    {card.warn && <g transform="translate(408 26)"><rect width="88" height="36" rx="10" fill="#b6462f" /><text x="44" y="24" textAnchor="middle" fontSize="14" fontWeight="800" fill="#fff8e6">주의 확인</text></g>}
  </svg>;
}

export default PhoneGuideScene;
