import {noticeApi, noticeDeliveryChanged, type CustomerNotice, type NoticePrepared} from './notice-api';

export async function savedLocalNotice(orderId: string | undefined, body: string, templateId: string,
  prepared?: boolean | NoticePrepared): Promise<NoticePrepared | null> {
  if (prepared && typeof prepared === 'object') return prepared;
  if (!orderId) return null; // Never guess an order from a phone number or create a fake order.
  const result = await noticeApi<{notice: CustomerNotice}>('POST', '/drafts', {
    orderId, body, templateId, theme: '고객 안내', advertConsentConfirmed: false,
  });
  return {noticeId: result.notice.id, revision: result.notice.revision};
}
export async function prepareLocalDelivery(notice: NoticePrepared | null, recipient: string,
  channel: 'sms-qr' | 'kakao-clipboard' | 'full-clipboard', deliveryBody: string) {
  if (!notice) return undefined;
  const result = await noticeApi<{attemptId: string}>('POST', '/local-preparation', {
    ...notice, recipient, channel, deliveryBody, requestId: crypto.randomUUID(),
  });
  noticeDeliveryChanged(); return result.attemptId;
}
export async function confirmLocalDelivery(attemptId: string | undefined, source?: 'button-click') {
  if (!attemptId) throw new Error('접수를 저장하고 발송을 준비한 뒤 완료를 확인해 주세요.');
  const result = await noticeApi<{confirmed: boolean; confirmedAt: string}>('POST', '/confirm-sent', {attemptId,source});
  if (!result.confirmed) throw new Error('발송 확인을 저장하지 못했습니다.');
  noticeDeliveryChanged(); return result.confirmedAt;
}
