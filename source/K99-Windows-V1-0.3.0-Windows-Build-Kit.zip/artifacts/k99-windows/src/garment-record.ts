import type { ConfirmedOrder } from './order-record';
import { unitService } from './unit-service';

export type GarmentPhotoStatus = 'not-captured' | 'simulated' | 'saved' | 'failed';
export type GarmentTagStatus = 'not-generated' | 'simulated' | 'generated' | 'print-requested' | 'printed' | 'failed';
export type PhotoBridgeTagJobStatus = 'pending' | 'submitted' | 'unknown' | 'skipped' | 'printed' | 'failed';
export type GarmentServiceType = 'general' | 'premium' | 'sneaker-general' | 'sneaker-premium';
export type GarmentWorkflowStatus = 'pending' | 'in-progress' | 'complete';
export type GarmentCompletionMethod = 'scanner' | 'simulation' | 'manual-entry' | 'manual';
export type GarmentCompletionStatus = 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER';
export type GarmentPhotoOrigin = 'simulation' | 'bridge' | 'legacy';
export type GarmentPhotoRole = 'intake' | 'completion';
export type GarmentPhotoMetadata = {
  garmentId: string;
  requestId: string;
  role: GarmentPhotoRole;
  status: 'simulated' | 'saved';
  timestamp: string;
  origin: GarmentPhotoOrigin;
  /** Stable ID of the source image when manually linking an existing photo. */
  sourcePhotoId?: string;
  /** Browser simulation/mock path only; never implies a real file was written. */
  path?: string;
  /** Verified customer copy; original path and garment identity remain unchanged. */
  archivePath?: string;
  /** Copy failure is distinct from successful original capture. */
  archiveError?: string;
  /** Reserved for future annotations; image metadata remains independently immutable. */
  annotations?: Record<string, unknown>;
};
export type NormalizedPoint = Readonly<{ x: number; y: number }>;
export type GarmentAnnotationShape =
  | Readonly<{ id: string; type: 'pen'; points: readonly NormalizedPoint[] }>
  | Readonly<{ id: string; type: 'circle' | 'rectangle' | 'arrow'; x: number; y: number; width: number; height: number }>
  | Readonly<{ id: string; type: 'text'; x: number; y: number; text: string }>;
export type GarmentAnnotationRevision = Readonly<{
  garmentId: string;
  photoRequestId: string;
  revision: number;
  savedAt: string;
  shapes: readonly GarmentAnnotationShape[];
}>;
export type GarmentCareProcess = Readonly<{
  id: string;
  garmentId: string;
  process: string;
  at: string;
  source: string;
  note?: string;
  staff?: string;
}>;
export type GarmentCareSummary = Readonly<{
  generatedText: string;
  editedText?: string;
  updatedAt: string;
}>;
export type LaundryProcessStatus = '접수 완료' | '촬영/태그 완료' | '전문검수 완료' |
  '세탁 대기' | '세탁 중' | '세탁 완료' | '완성 검수' | '출고 대기' | '반출 완료';

export type GarmentAuditEvent = {
  at: string;
  type: 'photo' | 'tag' | 'inspection' | 'cleaning' | 'completion' | 'handover'
    | 'photo-captured' | 'tag-generated' | 'print-requested' | 'tag-printed'
    | 'capture-error' | 'print-error' | 'reprint' | 'barcode-scan' | 'completion-undo'
  | 'laundry-process' | 'workflow-review' | 'completion-photo' | 'annotation-save' | 'photo-selection'
   | 'care-process' | 'care-summary' | 'completion-comment'
   | 'photo-link' | 'photo-unlink' | 'photo-relink';
  status: string;
  details?: string;
  orderId?: string;
  garmentId?: string;
  previousStatus?: LaundryProcessStatus;
  newStatus?: LaundryProcessStatus;
  source?: 'manual' | 'barcode' | 'simulation';
  action?: string;
  reason?: string;
  detail?: string;
  rewashCycle?: number;
  sourcePhotoId?: string;
  photoRequestId?: string;
};

export type GarmentRecord = {
  /** Explicit staff reviews, scoped to a wash cycle; never inferred customer consent. */
  workflowReviews?: Partial<Record<'intake' | 'prewash' | 'postwash' | 'final', {
    selected: string[];
    note: string;
    recordedAt: string;
    completedAt?: string;
    cycle: number;
    signature: string;
  }>>;
  garmentId: string;
  orderId: string;
  sequence: number;
  totalSequence: number;
  itemIndex: number;
  unitIndex: number;
  itemType: string;
  itemName: string;
  serviceType: GarmentServiceType;
  photoStatus: GarmentPhotoStatus;
  captureRequestId?: string;
  photoPath?: string;
  photoTimestamp?: string;
  /** First successful intake photo; never replaced by a recapture. */
  beforePhoto?: Readonly<GarmentPhotoMetadata>;
  /** Most recent completion photo; prior versions remain in photoHistory. */
  completionPhoto?: Readonly<GarmentPhotoMetadata>;
  /** Append-only successful intake/recapture/completion photo metadata. */
  photoHistory?: GarmentPhotoMetadata[];
  /** Append-only request IDs for photos manually unlinked from this garment. */
  unlinkedPhotoIds?: string[];
  /** Selected original intake photo requestId; photo metadata itself remains immutable. */
  representativeBeforePhotoId?: string;
  /** Append-only, per-photo annotation revisions; original image bytes/metadata are never changed. */
  annotationRevisions?: GarmentAnnotationRevision[];
  /** Actual, explicitly recorded care processes only. */
  careProcesses?: GarmentCareProcess[];
  careSummary?: GarmentCareSummary;
  completionComment?: string;
  tagStatus: GarmentTagStatus;
  /** One durable STORE auto-tag reservation per garment; photo recaptures never replace it. */
  photoBridgeAutoTagRequestId?: string;
  photoBridgeAutoTagStatus?: PhotoBridgeTagJobStatus;
  photoBridgeAutoTagJobId?: string;
  photoBridgeAutoTagMode?: 'DEV' | 'TEST' | 'STORE';
  photoBridgeAutoTagReason?: string;
  photoBridgeAutoTagCreatedAt?: string;
  /** A TEST/DEV reservation is retained separately when the first STORE reservation is created. */
  photoBridgeDevTestAutoTagRequestId?: string;
  photoBridgeDevTestAutoTagStatus?: PhotoBridgeTagJobStatus;
  photoBridgeDevTestAutoTagJobId?: string;
  photoBridgeDevTestAutoTagMode?: 'DEV' | 'TEST';
  photoBridgeDevTestAutoTagReason?: string;
  photoBridgeDevTestAutoTagCreatedAt?: string;
  /** Helper-confirmed proof IDs let later manual reprints reuse saved proof after ARM pruning. */
  photoBridgePhotoConfirmations?: Array<{
    photoRequestId: string;
    mode: 'DEV' | 'TEST' | 'STORE';
    photoVerified: boolean;
  }>;
  /** Explicit reprint state is separate from the once-only automatic reservation. */
  photoBridgeReprintRequestId?: string;
  photoBridgeReprintStatus?: PhotoBridgeTagJobStatus;
  photoBridgeReprintJobId?: string;
  photoBridgeReprintMode?: 'DEV' | 'TEST' | 'STORE';
  photoBridgeReprintReason?: string;
  photoBridgeReprintCreatedAt?: string;
  tagGeneratedAt?: string;
  printRequestId?: string;
  tagPrintRequestedAt?: string;
  tagPrintedAt?: string;
  /** Staff's physical check for the capture screen only; never device print proof. */
  captureBatchTagCheck?: {
    at: string;
    tagRequestId: string;
    tagJobId: string;
    photoRequestId: string;
    photoPath: string;
    photoTimestamp: string;
  };
  tagPrintCount: number;
  printerName?: string;
  lastError?: string;
  barcodeValue: string;
  inspectionStatus: GarmentWorkflowStatus;
  cleaningStatus: GarmentWorkflowStatus;
  completionStatus: GarmentWorkflowStatus;
  processStatus?: LaundryProcessStatus;
  processUpdatedAt?: string;
  rewashCount?: number;
  qcHoldReason?: string;
  status?: GarmentCompletionStatus;
  completedAt?: string;
  scannedAt?: string;
  lastScannedAt?: string;
  completionMethod?: GarmentCompletionMethod;
  barcodeType?: 'code128' | 'qr';
  handoverStatus: GarmentWorkflowStatus;
  auditEvents: GarmentAuditEvent[];
};

export type GarmentTagData = {
  garmentId: string;
  orderId: string;
  customerName: string;
  sequence: number;
  totalSequence: number;
  customerPhoneLast4: string;
  itemType: string;
  itemName: string;
  sequenceLabel: string;
  serviceType: GarmentServiceType;
  intakeDate: string;
  orderNumber: string;
  barcodeValue: string;
};

function getServiceType(isSneaker: boolean, itemId: string, serviceLevel: ConfirmedOrder['choices']['serviceLevel']): GarmentServiceType {
  if (isSneaker) {
    return itemId === 'sneakers_premium' ? 'sneaker-premium' : 'sneaker-general';
  }
  return serviceLevel;
}

export function createGarmentRecords(order: ConfirmedOrder): GarmentRecord[] {
  if (!order.id || !Array.isArray(order.items) ||
      order.items.some((item) => !Number.isInteger(item.quantity) || item.quantity < 1)) {
    throw new Error('저장된 주문번호와 세탁물 수량을 확인해 주세요.');
  }

  const totalSequence = order.items.reduce((total, item) => total + item.quantity, 0);
  const records: GarmentRecord[] = [];
  let sequence = 0;

  order.items.forEach((item, itemOffset) => {
    for (let unitOffset = 0; unitOffset < item.quantity; unitOffset += 1) {
      sequence += 1;
      const garmentId = `${order.id}-${String(sequence).padStart(2, '0')}`;
      records.push({
        garmentId,
        orderId: order.id,
        sequence,
        totalSequence,
        itemIndex: itemOffset + 1,
        unitIndex: unitOffset + 1,
        itemType: item.itemId,
        itemName: item.displayNameKo,
        serviceType: getServiceType(item.isSneaker, item.itemId, unitService(order.choices, itemOffset, unitOffset)),
        photoStatus: 'not-captured',
        tagStatus: 'not-generated',
        tagPrintCount: 0,
        barcodeValue: garmentId,
        inspectionStatus: 'pending',
        cleaningStatus: 'pending',
        completionStatus: 'pending',
        handoverStatus: 'pending',
        auditEvents: [],
      });
    }
  });

  return mergeNativeDraftUnits(order, records);
}

export function createTagData(order: ConfirmedOrder, garment: GarmentRecord): GarmentTagData {
  if (typeof order.customerPhone !== 'string' || typeof order.customerName !== 'string') {
    throw new Error('저장 주문의 고객명 또는 전화번호가 없어 태그를 만들 수 없습니다.');
  }
  if (garment.orderId !== order.id || !Number.isInteger(garment.sequence) ||
      garment.sequence < 1 || garment.sequence > order.totalQuantity) {
    throw new Error('주문과 의류 기록의 연결 정보를 확인해 주세요.');
  }
  const item = order.items[garment.itemIndex - 1];
  if (!item || item.itemId !== garment.itemType || item.displayNameKo !== garment.itemName) {
    throw new Error('저장 주문에서 의류 품목을 확인할 수 없습니다.');
  }
  const phoneDigits = order.customerPhone.replace(/\D/g, '');

  return {
    garmentId: garment.garmentId,
    orderId: order.id,
    customerName: order.customerName,
    sequence: garment.sequence,
    totalSequence: garment.totalSequence,
    customerPhoneLast4: phoneDigits.slice(-4),
    itemType: item.itemId,
    itemName: item.displayNameKo,
    sequenceLabel: `${garment.sequence}/${order.totalQuantity}`,
    serviceType: garment.serviceType,
    intakeDate: order.intakeAt.slice(0, 10),
    orderNumber: order.id,
    barcodeValue: garment.garmentId,
  };
}
/** Photo/tag fields a prereceipt native capture may carry into the final garment record. */
const DRAFT_PHOTO_TAG_FIELDS = [
  'photoStatus', 'photoPath', 'photoTimestamp', 'beforePhoto', 'photoHistory', 'representativeBeforePhotoId',
  'tagStatus', 'tagPrintCount', 'tagGeneratedAt', 'printRequestId', 'tagPrintRequestedAt', 'tagPrintedAt',
  'printerName', 'barcodeType', 'lastError',
] as const;

/**
 * Merges native draft captures into fresh garment records. The reserved garmentId/barcodeValue and
 * photo/tag fields come from the draft; item, order, sequence and service metadata stay final.
 */
export function mergeNativeDraftUnits(order: ConfirmedOrder, records: GarmentRecord[]): GarmentRecord[] {
  const units = order.nativeDraftUnits ?? [];
  if (!units.length) return records;
  const merged = records.map((record) => {
    const unit = units.find((u) => u.itemIndex === record.itemIndex && u.unitIndex === record.unitIndex);
    if (!unit) return record;
    const item = order.items[record.itemIndex - 1];
    const draft = unit.garment as GarmentRecord & Record<string, unknown>;
    if (!item || (draft.itemType && draft.itemType !== item.itemId)) return record;
    const next = { ...record } as GarmentRecord & Record<string, unknown>;
    const bag = next as Record<string, unknown>;
    for (const key of DRAFT_PHOTO_TAG_FIELDS) if (draft[key] !== undefined) bag[key] = draft[key];
    if (typeof draft.garmentId === 'string' && draft.garmentId) next.garmentId = draft.garmentId;
    if (typeof draft.barcodeValue === 'string' && draft.barcodeValue) next.barcodeValue = draft.barcodeValue;
    next.orderId = order.id;
    if (Array.isArray(next.photoHistory))
      next.photoHistory = next.photoHistory.map((p) => ({ ...p, garmentId: next.garmentId }));
    if (next.beforePhoto) next.beforePhoto = { ...next.beforePhoto, garmentId: next.garmentId };
    next.auditEvents = [...record.auditEvents, ...(Array.isArray(draft.auditEvents) ? draft.auditEvents as GarmentRecord['auditEvents'] : [])];
    return next as GarmentRecord;
  });
  const ids = new Set(merged.map((g) => g.garmentId));
  const barcodes = new Set(merged.map((g) => g.barcodeValue));
  if (ids.size !== merged.length || barcodes.size !== merged.length)
    throw new Error('사전 촬영 의류 ID가 다른 의류와 겹칩니다. 저장을 중지했습니다.');
  return merged;
}
