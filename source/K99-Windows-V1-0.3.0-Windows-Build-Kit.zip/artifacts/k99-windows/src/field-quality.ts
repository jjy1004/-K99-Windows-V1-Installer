import type { ConfirmedOrder } from './order-record';
import { advanceGarmentInOrder, garmentProcessStatus } from './laundry-process';
import { currentOperations } from './order-operations';
import { GARMENT_READY_STATUS, ORDER_READY_STATUS } from './garment-scanner';
import { completionNoticeText } from './customer-notice-text';
import { moveProcessStage } from './process-stage';

/** Explicit manual final QC, never contingent on comparison/completion photographs or a new scan.
 * Pure atomic transform: the caller commits once, or nothing changes. */
export function completeFieldQuality(order: ConfirmedOrder, garmentId?: string, at = new Date()): ConfirmedOrder {
  const ops = currentOperations(order);
  if (ops.cancelledAt || ops.completedAt || ['배달중', '배달완료', '매장수령완료'].includes(ops.stage))
    throw new Error('취소되었거나 이미 인도·배달 출고한 주문은 완료 검수할 수 없습니다.');
  const garments = order.garments ?? [];
  if (!garments.length || garments.length !== order.totalQuantity || new Set(garments.map(g => g.garmentId)).size !== garments.length)
    throw new Error('주문 의류 수량과 ID를 확인해 주세요.');
  if (garmentId && !garments.some(g => g.garmentId === garmentId)) throw new Error('주문에 없는 의류입니다.');
  let updated = order;
  const timestamp = at.toISOString();
  for (const garment of garments.filter(g => !garmentId || g.garmentId === garmentId)) {
    let current = updated.garments!.find(g => g.garmentId === garment.garmentId)!;
    let state = garmentProcessStatus(updated, current);
    if (state === '세탁 완료') {
      updated = advanceGarmentInOrder(updated, garment.garmentId, 'inspect', 'manual', '', at);
      current = updated.garments!.find(g => g.garmentId === garment.garmentId)!;
      state = garmentProcessStatus(updated, current);
    }
    if (state === '완성 검수') {
      updated = advanceGarmentInOrder(updated, garment.garmentId, 'qc-pass', 'manual', '', at);
      current = updated.garments!.find(g => g.garmentId === garment.garmentId)!;
    } else if (state !== '출고 대기') throw new Error(`${garment.itemName}: 실제 세탁 완료 후 완성 검수해 주세요.`);
    if (current.qcHoldReason) throw new Error(`${garment.itemName}: 보류 사유를 먼저 확인·해제해 주세요.`);
    if (current.completionStatus === 'complete' && current.processStatus === '출고 대기') continue;
    updated = { ...updated, garments: updated.garments!.map(g => g.garmentId !== garment.garmentId ? g : {
      ...g, processStatus: '출고 대기', processUpdatedAt: timestamp, status: GARMENT_READY_STATUS,
      completionStatus: 'complete', completedAt: timestamp, completionMethod: 'manual',
      auditEvents: [...(g.auditEvents ?? []), { at: timestamp, type: 'completion', status: '검수 완료',
        orderId: order.id, garmentId: g.garmentId, source: 'manual', details: '직원이 완성 검수 확정 · 전후 사진은 선택 사항 · 바코드 스캔 아님' }],
    }) };
  }
  const allReady = updated.garments!.every(g => g.processStatus === '출고 대기' && g.completionStatus === 'complete');
  if (!allReady || (order.status === ORDER_READY_STATUS && order.orderCompletedAt)) return updated;
  const completed = { ...updated, status: ORDER_READY_STATUS, orderCompletedAt: timestamp };
  const message = completionNoticeText(completed);
  return moveProcessStage({
    ...completed,
    operations: { ...ops, stage: '세탁완료', updatedAt: timestamp },
    history: [...(updated.history ?? []),
      { at: timestamp, kind: 'operations-update', details: {
        action: 'manual-final-quality-complete', previous: ops.stage, revised: '세탁완료', actuallySent: false,
      } },
      { at: timestamp, kind: 'notification-draft', details: { message, actuallySent: false } }],
  }, '완료 검수', 'next', at);
}
