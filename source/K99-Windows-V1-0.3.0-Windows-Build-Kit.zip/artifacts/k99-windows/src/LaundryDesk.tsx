import { IntakeDateBadge } from './IntakeIdentity';
import { useCallback, useEffect, useState } from 'react';
import { Activity, ClipboardCheck, Phone, RefreshCw, Search, Tag, Trash2 } from 'lucide-react';
import { orderDisplayStatus } from './handover-display';
import { NoticeQuickActions } from './NoticeQuickActions';
import { useLocation } from 'wouter';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { inspectionPaymentLabel, reviseInspectionPayment } from './inspection-payment';
import type { PaymentType } from './order-payment';
import { orderWorkspaceUrl } from './order-entry';
import { garmentProcessStatus } from './laundry-process';
import OrderDeletionDialog from './OrderDeletionDialog';
import { CustomerJobSortControls } from './CustomerJobSortControls';
import {isCustomerCardControl,openCustomerCardDetails} from './customer-card-details';
import { isUnpaidCustomerJob, manualJobTags, sortCustomerJobs, type CustomerJobSort } from './customer-job-sort';
import './customer-job-cards.css';

const itemSummary = (order: ConfirmedOrder) => {
  const counts = new Map<string, number>();
  for (const g of order.garments ?? []) counts.set(g.itemName, (counts.get(g.itemName) ?? 0) + 1);
  return [...counts].map(([name, n]) => n > 1 ? `${name} ${n}` : name).join(' · ') || '품목 없음';
};

export function LaundryDesk() {
  const [, navigate] = useLocation();
  const [orders, setOrders] = useState<ConfirmedOrder[]>([]);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<CustomerJobSort>('date');
  const [deleting, setDeleting] = useState<ConfirmedOrder | null>(null);
  const [notice, setNotice] = useState('');
  const refresh = useCallback(() => {
    try { setOrders(readConfirmedOrders()); setError(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.'); }
  }, []);
  const changePayment = (order: ConfirmedOrder, type: PaymentType) => {
    setError(''); setNotice('');
    try {
      const revised = reviseInspectionPayment(order, type);
      if (revised !== order) updateSavedOrder(revised, order);
      refresh();
      setNotice(`${order.customerName} 고객의 결제 구분을 ${inspectionPaymentLabel(revised)}로 저장했습니다. 기존 결제·환불 기록은 유지됩니다.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '결제 구분을 저장하지 못했습니다. 새로고침 후 다시 확인해 주세요.');
    }
  };
  useEffect(() => {
    refresh();
    window.addEventListener('focus', refresh); window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('focus', refresh); window.removeEventListener('storage', refresh); };
  }, [refresh]);
  const working = orders.filter(order => !order.operations?.cancelledAt && !order.operations?.completedAt &&
    !['배달중','배달완료','매장수령완료'].includes(order.operations?.stage ?? '') &&
    (!order.garments?.length || order.garments.some(g => !['출고 대기','반출 완료'].includes(garmentProcessStatus(order, g)))) &&
    `${order.id} ${order.customerName} ${order.customerPhone}`.includes(query.trim()));
  const sorted = sortCustomerJobs(working, sort, 'inspection');
  return <main className="app-shell laundry-desk job-page" data-testid="laundry-desk">
    <header className="job-page__head">
      <div className="job-page__title"><h1>세탁·검수</h1><span className="job-page__count" data-testid="text-laundry-count">{sorted.length}</span></div>
      <CustomerJobSortControls value={sort} onChange={setSort} />
      <p className="job-page__sub">전문검수 · 고객승인 대기 · 세탁방법 · 세탁 시작/완료</p>
      <div className="job-page__tools">
        <label><Search aria-hidden="true" />주문 찾기 <input data-scanner-input value={query} onChange={event => setQuery(event.target.value)} placeholder="고객명·주문번호·전화번호" data-testid="input-laundry-search" /></label>
        <button type="button" onClick={refresh} data-testid="button-laundry-refresh"><RefreshCw aria-hidden="true" />새로고침</button>
      </div>
    </header>
    {error && <p role="alert">{error}</p>}
    {notice && <p role="status">{notice}</p>}
    {!error && !sorted.length && <div className="job-empty"><strong>진행할 세탁·검수 주문이 없습니다.</strong><span>새 접수가 확정되면 이곳에 카드로 나타납니다.</span></div>}
    {sorted.length > 0 && <div className="laundry-desk__orders customer-job-grid">{sorted.map(order => {
      const tags = manualJobTags(order);
      const pay = inspectionPaymentLabel(order);
      return <article key={order.id} className="customer-job-card" data-unpaid={isUnpaidCustomerJob(order)} data-testid={`laundry-order-${order.id}`}
        onClick={event=>{if(!isCustomerCardControl(event.target))openCustomerCardDetails(order.id);}}>
        <button type="button" className="order-deletion__danger jc-delete"
          data-testid={`button-delete-order-${order.id}`} aria-label={`${order.customerName} 주문 ${order.id} 삭제`}
          onClick={() => { setNotice(''); setDeleting(order); }}><Trash2 aria-hidden="true" />삭제</button>
        <button type="button" className="jc-body laundry-desk__card-header"
          aria-haspopup="dialog" aria-label={`${order.customerName} 주문 상세·메시지 열기`}
          data-testid={`button-laundry-details-${order.id}`}
          onClick={()=>openCustomerCardDetails(order.id)}>
          <div className="jc-who"><strong className="jc-name"><IntakeDateBadge intakeAt={order.intakeAt}/>{order.customerName}</strong>
            <span className="jc-phone"><Phone aria-hidden="true" />{order.customerPhone || '전화번호 미등록'}</span></div>
          <div className="jc-meta">
            <span className="laundry-desk__payment-badge" data-payment={pay} data-testid={`laundry-payment-${order.id}`}>{pay}</span>
            <span className="jc-chip" title={order.id}><Activity aria-hidden="true" />{order.totalQuantity}벌 · {orderDisplayStatus(order)}</span>
            {tags.length > 0 && <span className="jc-chip jc-chip--tag" title={`수기택 ${tags.join(', ')}`} data-testid={`laundry-tags-${order.id}`}><Tag aria-hidden="true" /><span>{tags[0]}{tags.length > 1 ? ` +${tags.length - 1}` : ''}</span></span>}
          </div>
          <div className="jc-items customer-job-card__items" aria-label={`${order.customerName} 세탁물 내역`}
            title={(order.garments ?? []).map(g => `${g.itemName}${g.tagNumber ? ` (태그 ${g.tagNumber})` : ''} · ${garmentProcessStatus(order, g)}`).join('\n')}>{itemSummary(order)}</div>
        </button>
        <div className="jc-row">
          <div className="laundry-desk__payment-tools" role="group" aria-label={`${order.customerName} 결제 구분 변경`}>
            <button type="button" data-testid={`laundry-prepaid-${order.id}`} aria-pressed={pay === '선불'}
              onClick={() => changePayment(order, 'PREPAID')}>선불</button>
            <button type="button" data-testid={`laundry-postpaid-${order.id}`} aria-pressed={pay === '후불'}
              onClick={() => changePayment(order, 'POSTPAID')}>후불</button>
          </div>
          <button type="button" className="jc-btn jc-btn--primary" onClick={() => navigate(orderWorkspaceUrl(order.id, 'stages'))}
            data-testid={`laundry-open-${order.id}`}><ClipboardCheck aria-hidden="true" />검수 화면 열기</button>
        </div>
        <div className="jc-row"><NoticeQuickActions orderId={order.id} compact historyOnly /></div>
      </article>;
    })}</div>}
    {deleting && <OrderDeletionDialog order={deleting} onClose={() => setDeleting(null)}
      onDeleted={() => { setDeleting(null); refresh(); setNotice('선택한 주문 한 건을 논리 삭제했습니다. 관리자 메뉴에서 복구할 수 있습니다.'); }} />}
  </main>;
}
