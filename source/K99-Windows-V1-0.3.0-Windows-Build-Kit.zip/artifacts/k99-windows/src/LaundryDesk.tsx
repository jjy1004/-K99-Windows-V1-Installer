import { useCallback, useEffect, useState } from 'react';
import { orderDisplayStatus } from './handover-display';
import { NoticeQuickActions } from './NoticeQuickActions';
import { useLocation } from 'wouter';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { inspectionPaymentLabel, reviseInspectionPayment } from './inspection-payment';
import type { PaymentType } from './order-payment';
import { orderWorkspaceUrl } from './order-entry';
import { garmentProcessStatus } from './laundry-process';
import OrderDeletionDialog from './OrderDeletionDialog';

export function LaundryDesk() {
  const [, navigate] = useLocation();
  const [orders, setOrders] = useState<ConfirmedOrder[]>([]);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [deleting, setDeleting] = useState<ConfirmedOrder | null>(null);
  const [notice, setNotice] = useState('');
  const refresh = useCallback(() => {
    try { setOrders(readConfirmedOrders()); setError(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.'); }
  }, []);
  const changePayment = (order: ConfirmedOrder, type: PaymentType) => {
    setError(''); setNotice('');
    try {
      const revised = reviseInspectionPayment(order, type);
      if (revised !== order) updateSavedOrder(revised, order);
      refresh();
      setNotice(`${order.customerName} 고객의 결제 구분을 ${inspectionPaymentLabel(revised)}로 저장했습니다. 기존 결제·환불 기록은 유지됩니다.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '결제 구분을 저장하지 못했습니다. 새로고침 후 다시 확인해 주세요.');
    }
  };
  useEffect(() => {
    refresh();
    window.addEventListener('focus', refresh); window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('focus', refresh); window.removeEventListener('storage', refresh); };
  }, [refresh]);
  const working = orders.filter(order => !order.operations?.cancelledAt && !order.operations?.completedAt &&
    !['배달중','배달완료','매장수령완료'].includes(order.operations?.stage ?? '') &&
    (!order.garments?.length || order.garments.some(g => !['출고 대기','반출 완료'].includes(garmentProcessStatus(order, g)))) &&
    `${order.id} ${order.customerName} ${order.customerPhone}`.includes(query.trim()));
  return <main className="app-shell laundry-desk" data-testid="laundry-desk">
    <header><h1>세탁·검수</h1><p>전문검수 · 고객승인 대기 · 세탁방법 · 세탁 시작/완료</p></header>
    <label>주문 찾기 <input data-scanner-input value={query} onChange={event => setQuery(event.target.value)} placeholder="고객명·주문번호·전화번호" /></label>
    <button type="button" onClick={refresh}>새로고침</button>
    {error && <p role="alert">{error}</p>}
    {notice && <p role="status">{notice}</p>}
    {!error && !working.length && <p>진행할 세탁·검수 주문이 없습니다.</p>}
    <div className="laundry-desk__orders">{working.map(order =>
      <article key={order.id} style={{ position: 'relative', paddingRight: 88 }} data-testid={`laundry-order-${order.id}`}>
        <button type="button" className="order-deletion__danger" style={{ position: 'absolute', right: 14, top: 14 }}
          data-testid={`button-delete-order-${order.id}`} aria-label={`${order.customerName} 주문 ${order.id} 삭제`}
          onClick={() => { setNotice(''); setDeleting(order); }}>삭제</button>
        <div className="laundry-desk__card-header"><strong>{order.customerName}</strong><span>{order.totalQuantity}벌 · {orderDisplayStatus(order)}</span>
          <span className="laundry-desk__payment-badge" data-payment={inspectionPaymentLabel(order)}
            data-testid={`laundry-payment-${order.id}`}>{inspectionPaymentLabel(order)}</span>
          <small>{order.id}</small></div>
        <div>{(order.garments ?? []).map(g => <span key={g.garmentId}>{g.itemName}{g.tagNumber&&<strong> · 태그 {g.tagNumber}</strong>} · {garmentProcessStatus(order, g)} </span>)}</div>
        <div className="laundry-desk__payment-tools" role="group" aria-label={`${order.customerName} 결제 구분 변경`}>
          <span>결제 구분</span>
          <button type="button" data-testid={`laundry-prepaid-${order.id}`}
            aria-pressed={inspectionPaymentLabel(order) === '선불'}
            onClick={() => changePayment(order, 'PREPAID')}>선불</button>
          <button type="button" data-testid={`laundry-postpaid-${order.id}`}
            aria-pressed={inspectionPaymentLabel(order) === '후불'}
            onClick={() => changePayment(order, 'POSTPAID')}>후불</button>
        </div>
        <NoticeQuickActions orderId={order.id}/>
        <button type="button" onClick={() => navigate(orderWorkspaceUrl(order.id, 'stages'))}
          data-testid={`laundry-open-${order.id}`}>검수 화면 열기</button>
      </article>)}</div>
    {deleting && <OrderDeletionDialog order={deleting} onClose={() => setDeleting(null)}
      onDeleted={() => { setDeleting(null); refresh(); setNotice('선택한 주문 한 건을 논리 삭제했습니다. 관리자 메뉴에서 복구할 수 있습니다.'); }} />}
  </main>;
}
