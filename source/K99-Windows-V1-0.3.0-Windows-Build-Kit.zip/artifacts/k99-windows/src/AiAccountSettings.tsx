import {useEffect,useState} from 'react';
type Status={available:boolean;configured:boolean;phone:string};
export function AiAccountSettings(){
  const [status,setStatus]=useState<Status>({available:false,configured:false,phone:''});
  const [phone,setPhone]=useState(''),[password,setPassword]=useState('');
  const [busy,setBusy]=useState(false),[message,setMessage]=useState('');
  const accept=(value:{available?:boolean;configured?:boolean;phone?:string;error?:string})=>{
    const next={available:!!value.available,configured:!!value.configured,phone:value.phone||''};
    setStatus(next);setPhone(next.phone);setPassword('');if(value.error)setMessage(value.error);
  };
  useEffect(()=>{
    let live=true;
    if(!window.k99Desktop?.aiAccount){setMessage('계정 암호화 저장은 Windows 앱에서 사용할 수 있습니다. 브라우저 미리보기에는 저장하지 않습니다.');return;}
    void window.k99Desktop.aiAccount({action:'status'}).then(value=>{
      if(!live)return;
      if(!value.success){setMessage(value.error||'계정 상태를 읽지 못했습니다.');return;}accept(value);
    }).catch(()=>{if(live)setMessage('계정 상태를 읽지 못했습니다.');});
    return()=>{live=false;};
  },[]);
  async function save(clear=false){
    if(!window.k99Desktop?.aiAccount||busy)return;
    setBusy(true);setMessage('');
    try{
      const value=await window.k99Desktop.aiAccount(clear||(!phone.trim()&&!password)?{action:'clear'}:{action:'save',phone,password});
      if(!value.success)throw new Error(value.error||'계정을 저장하지 못했습니다.');
      accept(value);
      setMessage(value.configured?'연결 계정을 Windows 암호화 저장소에 저장했습니다. 다음 처방 열기 시 서버 인증을 시도합니다.':'저장 계정을 지웠습니다. 기존 브라우저 기기 인증·쿠키는 유지됩니다.');
    }catch(error){setMessage(error instanceof Error?error.message:'계정 저장 실패');}
    finally{setPassword('');setBusy(false);}
  }
  return <fieldset className="eq-card" data-testid="ai-account-settings">
    <legend>AI 세탁 처방 연결 계정</legend>
    <p>공식 AI 처방 사이트에만 자동 로그인합니다. 계정이 없으면 브라우저에 보존된 기기 인증·쿠키를 사용합니다. 관리자·점주 권한 및 기기 승인은 처방 서버의 판정을 따릅니다.</p>
    <label className="eq-field">휴대폰 번호
      <input type="tel" inputMode="tel" autoComplete="off" value={phone} disabled={!status.available||busy}
        onChange={event=>setPhone(event.target.value)} placeholder="01012345678" maxLength={20} data-testid="input-ai-account-phone"/>
    </label>
    <label className="eq-field">비밀번호 5자리
      <input type="password" autoComplete="new-password" value={password} disabled={!status.available||busy}
        onChange={event=>setPassword(event.target.value)} placeholder={status.configured?'저장됨 · 변경할 때만 입력':'영문 1자 + 숫자 4자'} maxLength={5}
        data-testid="input-ai-account-password"/>
    </label>
    <p>비밀번호는 Windows 사용자 암호화 기능으로 보관하며 다시 표시하지 않습니다. 이 PC의 같은 Windows 사용자에서 유지됩니다. 계정 비우기는 처방 사이트 로그아웃과 별개입니다.</p>
    <div className="eq-row">
      <button type="button" className="eq-btn is-primary" disabled={!status.available||busy} onClick={()=>void save()} data-testid="button-save-ai-account">연결 계정 저장</button>
      <button type="button" className="eq-btn" disabled={!status.available||busy||!status.configured} onClick={()=>void save(true)} data-testid="button-clear-ai-account">저장 계정 비우기</button>
      <span data-testid="ai-account-status">{status.configured?'연결 계정 저장됨':'기기 토큰·쿠키 인증 사용'}</span>
    </div>
    {message&&<p role="status" data-testid="ai-account-message">{message}</p>}
  </fieldset>;
}
