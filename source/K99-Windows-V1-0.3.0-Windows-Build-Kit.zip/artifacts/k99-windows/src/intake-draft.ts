export const ACTIVE_INTAKE_DRAFT_KEY = 'k99-active-staff-intake-v1';

export type DraftPhotoAssociation = {
  garmentId: string;
  rowId: number;
  itemId: string;
  rowQuantity: number;
  unitIndex: number;
  sourcePhotoId: string;
  filename: string;
  sourcePath: string;
  capturedAt: string;
  requestId: string;
};

export type DraftPhotoTarget = Pick<DraftPhotoAssociation, 'garmentId' | 'rowId' | 'itemId' | 'rowQuantity' | 'unitIndex'>;

export type ActiveIntakeDraft<T> = {
  version: 1;
  draftId: string;
  revision: number;
  updatedAt: string;
  data: T;
};

export type DraftStorageResult<T> =
  | { ok: true; draft: ActiveIntakeDraft<T> | null }
  | { ok: false; error: string };

type DraftStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);

export function validateActiveIntakeDraft<T>(value: unknown): ActiveIntakeDraft<T> | null {
  if (!isRecord(value) || value.version !== 1 ||
      typeof value.draftId !== 'string' || !/^[a-f0-9-]{36}$/i.test(value.draftId) ||
      !Number.isSafeInteger(value.revision) || (value.revision as number) < 0 ||
      typeof value.updatedAt !== 'string' || !Number.isFinite(Date.parse(value.updatedAt)) ||
      !isRecord(value.data)) return null;
  return value as unknown as ActiveIntakeDraft<T>;
}

export function readActiveIntakeDraft<T>(storage: DraftStorage): DraftStorageResult<T> {
  try {
    const raw = storage.getItem(ACTIVE_INTAKE_DRAFT_KEY);
    if (!raw) return { ok: true, draft: null };
    const parsed: unknown = JSON.parse(raw);
    const draft = validateActiveIntakeDraft<T>(parsed);
    return draft
      ? { ok: true, draft }
      : { ok: false, error: '저장된 현재 접수 초안이 손상되었거나 형식이 맞지 않습니다. 기존 초안은 덮어쓰지 않았습니다.' };
  } catch {
    return { ok: false, error: '브라우저에서 현재 접수 초안을 읽지 못했습니다.' };
  }
}

export function writeActiveIntakeDraft<T>(
  storage: DraftStorage,
  expected: { draftId: string | null; revision: number },
  data: T,
  now = new Date(),
  createDraftId?: string,
): { ok: true; draft: ActiveIntakeDraft<T> } | { ok: false; error: string } {
  try {
    const currentResult = readActiveIntakeDraft<unknown>(storage);
    if (!currentResult.ok) return currentResult;
    const current = currentResult.draft;
    if ((current?.draftId ?? null) !== expected.draftId ||
        (current?.revision ?? -1) !== (expected.draftId ? expected.revision : -1)) {
      return { ok: false, error: '다른 브라우저 탭에서 이 접수가 변경되거나 초기화되었습니다. 접수 내용을 안전하게 보존했으며 새로고침하여 최신 초안을 불러와 주세요.' };
    }
    const draftId = expected.draftId ?? createDraftId ?? crypto.randomUUID();
    if (!/^[a-f0-9-]{36}$/i.test(draftId)) {
      return { ok: false, error: '현재 접수 초안 ID가 올바르지 않아 저장을 중단했습니다.' };
    }
    const next: ActiveIntakeDraft<T> = {
      version: 1,
      draftId,
      revision: (current?.revision ?? -1) + 1,
      updatedAt: now.toISOString(),
      data,
    };
    storage.setItem(ACTIVE_INTAKE_DRAFT_KEY, JSON.stringify(next));
    return { ok: true, draft: next };
  } catch {
    return { ok: false, error: '브라우저가 현재 접수 초안을 저장하지 못했습니다. 사진을 연결할 수 없습니다.' };
  }
}

/** Clear only the draft revision currently displayed in this tab. */
export function clearActiveIntakeDraft(
  storage: DraftStorage,
  expected: { draftId: string | null; revision: number },
): { ok: true } | { ok: false; error: string } {
  try {
    const currentResult = readActiveIntakeDraft<unknown>(storage);
    if (!currentResult.ok) return currentResult;
    const current = currentResult.draft;
    if (!current) {
      return expected.draftId === null
        ? { ok: true }
        : { ok: false, error: '현재 탭의 접수 초안은 다른 탭에서 이미 초기화되거나 저장되었습니다. 오래된 접수를 지우지 않도록 초기화를 중단했습니다.' };
    }
    if (!expected.draftId || current.draftId !== expected.draftId || current.revision !== expected.revision) {
      return { ok: false, error: '다른 탭의 새 접수를 덮어쓰지 않도록 초안 초기화를 중단했습니다. 새로고침하여 현재 접수를 확인해 주세요.' };
    }
    storage.removeItem(ACTIVE_INTAKE_DRAFT_KEY);
    return { ok: true };
  } catch {
    return { ok: false, error: '현재 접수 초안을 초기화하지 못했습니다.' };
  }
}

export function sanitizeDraftPhotoAssociations(value: unknown, draftId: string): DraftPhotoAssociation[] {
  if (!Array.isArray(value)) return [];
  const seenTargets = new Set<string>();
  const seenPhotos = new Set<string>();
  const result: DraftPhotoAssociation[] = [];
  for (const item of value) {
    if (!isRecord(item) || typeof item.garmentId !== 'string' ||
        !item.garmentId.startsWith(`${draftId}-`) || typeof item.sourcePhotoId !== 'string' ||
        !Number.isSafeInteger(item.rowId) || (item.rowId as number) < 1 ||
        typeof item.itemId !== 'string' || !/^[a-z][a-z0-9_]{0,79}$/.test(item.itemId) ||
        !Number.isSafeInteger(item.rowQuantity) || (item.rowQuantity as number) < 1 || (item.rowQuantity as number) > 99 ||
        !Number.isSafeInteger(item.unitIndex) || (item.unitIndex as number) < 1 ||
        !/^[a-f0-9]{64}$/.test(item.sourcePhotoId) || typeof item.filename !== 'string' ||
        !/^[^\\/:*?"<>|]{1,180}\.(?:png|jpe?g)$/i.test(item.filename) ||
        typeof item.sourcePath !== 'string' || item.sourcePath.length > 1024 ||
        item.sourcePath.split(/[\\/]/).at(-1)?.toLowerCase() !== item.filename.toLowerCase() ||
        typeof item.capturedAt !== 'string' || !Number.isFinite(Date.parse(item.capturedAt)) ||
        typeof item.requestId !== 'string' || !/^[a-f0-9-]{36}$/i.test(item.requestId)) continue;
    const targetKey = item.garmentId;
    if (seenTargets.has(targetKey) || seenPhotos.has(item.sourcePhotoId)) continue;
    seenTargets.add(targetKey);
    seenPhotos.add(item.sourcePhotoId);
    result.push(item as DraftPhotoAssociation);
  }
  return result;
}

/** A photo remains attached only to the same stable row and physical unit. */
export function matchDraftPhotosToTargets(
  photos: readonly DraftPhotoAssociation[],
  targets: readonly DraftPhotoTarget[],
): DraftPhotoAssociation[] {
  const byGarment = new Map(targets.map((target) => [target.garmentId, target]));
  return photos.filter((photo) => {
    const target = byGarment.get(photo.garmentId);
    return target?.rowId === photo.rowId && target.itemId === photo.itemId &&
      target.rowQuantity === photo.rowQuantity &&
      target.unitIndex === photo.unitIndex;
  });
}

/** Resolve the one allowed source image for this fully materialized garment. */
export function getDraftPhotoForTarget(
  photos: readonly DraftPhotoAssociation[],
  target: DraftPhotoTarget,
): DraftPhotoAssociation | null {
  return matchDraftPhotosToTargets(photos, [target])[0] ?? null;
}

export function isDraftPhotoIdAvailable(usedPhotoIds: readonly string[], photoId: string): boolean {
  return /^[a-f0-9]{64}$/.test(photoId) && !usedPhotoIds.includes(photoId);
}