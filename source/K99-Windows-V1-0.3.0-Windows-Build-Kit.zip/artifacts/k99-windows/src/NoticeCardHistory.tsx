import {useEffect,useState} from 'react';
import {noticeApi,NOTICE_DELIVERY_CHANGED,type NoticeDeliveryState} from './notice-api';
import {deliveryTime} from './notice-delivery-state';
type Row=NoticeDeliveryState&{templateLabel?:string;source?:string};
export function NoticeCardHistory({orderId}:{orderId:string}){
  const [state,setState]=useState<{id:string;rows:Row[];failed:boolean;loading:boolean}>({id:orderId,rows:[],failed:false,loading:true});
  useEffect(()=>{
    let alive=true,sequence=0;
    const load=async()=>{
      const request=++sequence;
      try{
        const result=await noticeApi<{states:Row[]}>('POST','/delivery-status',{orderIds:[orderId],includePickupHistory:true});
        if(alive&&request===sequence)setState({id:orderId,rows:result.states.filter(r=>r.sentAt),failed:false,loading:false});
      }catch{
        if(alive&&request===sequence)setState(old=>({id:orderId,rows:old.id===orderId?old.rows:[],failed:true,loading:false}));
      }
    };
    const refresh=()=>{void load();};refresh();
    window.addEventListener(NOTICE_DELIVERY_CHANGED,refresh);window.addEventListener('focus',refresh);window.addEventListener('storage',refresh);
    return()=>{alive=false;window.removeEventListener(NOTICE_DELIVERY_CHANGED,refresh);window.removeEventListener('focus',refresh);window.removeEventListener('storage',refresh);};
  },[orderId]);
  const ready=state.id===orderId,rows=ready?[...state.rows].sort((a,b)=>b.sentAt!.localeCompare(a.sentAt!)).slice(0,4):[];
  return <div aria-label="메시지 발송 이력" data-testid={`notice-history-${orderId}`} title="종류별 최근 발송 기록"
    style={{display:'grid',gap:4,fontSize:15,lineHeight:1.5}}>
    {(!ready||state.loading)&&<span role="status">발송 이력 확인 중</span>}
    {ready&&state.failed&&<span role="status">최신 발송 이력을 확인하지 못했습니다.</span>}
    {ready&&!state.loading&&!state.failed&&!rows.length&&<span>발송 이력 없음</span>}
    {rows.map((r,i)=><span key={`${r.templateId}-${r.sentAt}-${i}`}
      title={r.completionSource==='button-click'?'발송 버튼 클릭 기준 기록 · 외부 앱 실제 전송 미확인':r.source==='pickup'?'기존 수거·배달 발송 기록 · 발송 수단은 기록되어 있지 않습니다.':'직원이 외부 전송을 확인한 기록'}>
      {r.channel==='unknown'?'':r.channel==='kakao-clipboard'?'카카오톡 · ':'문자 · '}
      {r.templateLabel||'고객 안내'} · <time dateTime={r.sentAt!}>{deliveryTime(r.sentAt!)}</time>
    </span>)}
  </div>;
}
