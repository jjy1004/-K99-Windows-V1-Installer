export const LINKED_CUSTOMER_SOURCE_KEY = 'k99-linked-customer-source';
/** Recover only the owned, previously paired popup after staff reload, never a random same-origin sender. */
export function isCustomerReadyPeer({ sender, linked, owned, sourceId, pairedSource }: {
  sender: unknown; linked: unknown; owned: boolean; sourceId?: string; pairedSource?: string | null;
}): boolean {
  return !!sender && (!!linked ? sender === linked :
    owned && typeof sourceId === 'string' && !!sourceId && sourceId === pairedSource);
}
