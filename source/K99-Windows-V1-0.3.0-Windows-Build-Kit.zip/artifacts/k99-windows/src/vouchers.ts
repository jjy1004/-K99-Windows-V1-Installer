import { useCallback, useEffect, useRef, useState } from 'react';
import { directoryRequest } from './customer-directory-client';

export type VoucherPlan = 'BUY_100' | 'BUY_200' | 'DEDUCT';
export type VoucherKind = 'TEN' | 'TWENTY';
export type VoucherRequest = { plan: VoucherPlan; number?: string; expectedRevision?: number };
export type VoucherAccount = {
  customerId: string; kind: VoucherKind; label: string; number: string; balance: number; revision: number;
};
export type VoucherReceipt = {
  id: string; plan: VoucherPlan; customerId: string; kind: VoucherKind; label: string; number: string;
  paidAmount: number; credit: number; laundryTotal: number; debit: number;
  balanceBefore: number; balanceAfter: number; shortfall: number; createdAt: string; orderId: string | null;
};
/** Customer-monitor safe subset. Never carries number, memo, or ids. */
export type VoucherDisplay = { label: string; balance: number };

export const VOUCHER_PLANS = {
  BUY_100: { kind: 'TEN' as const, label: '10만 원 정액권', paid: 100000, credit: 110000 },
  BUY_200: { kind: 'TWENTY' as const, label: '20만 원 정액권', paid: 200000, credit: 230000 },
};
export const VOUCHER_CHANGED_EVENT = 'k99-voucher-changed';
export const VOUCHER_BANNER_TEXT = '🎁 정액권 특별 혜택 안내 : 10만 원 정액권 결제 시 11만 원 세탁 가능 / 20만 원 정액권 결제 시 23만 원 세탁 가능 .';
export const wonText = (v: number) => `${v.toLocaleString('ko-KR')}원`;

export function voucherDeduction(balance: number, laundryTotal: number) {
  const debit = Math.max(0, Math.min(balance, laundryTotal));
  return { debit, after: balance - debit, shortfall: Math.max(0, laundryTotal - debit) };
}

export function isVoucherAccount(v: unknown): v is VoucherAccount {
  if (!v || typeof v !== 'object') return false;
  const a = v as VoucherAccount;
  return typeof a.customerId === 'string' && (a.kind === 'TEN' || a.kind === 'TWENTY') && typeof a.label === 'string'
    && typeof a.number === 'string' && Number.isSafeInteger(a.balance) && a.balance >= 0 && Number.isSafeInteger(a.revision);
}

export const sameVoucherNumber = (a?: string, b?: string) => !!a && !!b && a.trim().toLocaleLowerCase() === b.trim().toLocaleLowerCase();

export function notifyVoucherChanged() {
  window.dispatchEvent(new Event(VOUCHER_CHANGED_EVENT));
  try { localStorage.setItem('k99-voucher-changed-at', String(Date.now())); } catch { /* same-window event still fires */ }
}

export const fetchVoucherAccount = (q: { name: string; phone: string; customerId: string }) =>
  directoryRequest<{ account: VoucherAccount | null }>('GET', `/api/vouchers/account?${new URLSearchParams(q)}`);
export const fetchVoucherHistory = (customerId: string) =>
  directoryRequest<{ account: VoucherAccount | null; history: Record<string, unknown>[] }>('GET',
    `/api/vouchers/history?${new URLSearchParams({ customerId })}`);
export const purchaseVoucher = (body: {
  requestId: string; customerName: string; customerPhone: string; customerAddress: string;
  directoryCustomerId?: string; request: VoucherRequest;
}) => directoryRequest<{ receipt: VoucherReceipt; account: VoucherAccount }>('POST', '/api/vouchers/purchase', body);

export type VoucherAccountState = { status: 'idle' | 'loading' | 'ready' | 'error'; account: VoucherAccount | null; error: string; key: string };

/** Latest account for the selected directory customer only. Stale replies are dropped by key + sequence. */
export function useVoucherAccount(customerId: string, name: string, phone: string) {
  const digits = phone.replace(/\D/g, '');
  // 신규 고객도 이름 + 전체 전화(8자리 이상)만으로 조회한다.
  const key = customerId || (name.trim() && digits.length >= 8) ? `${customerId}|${name.trim()}|${digits}` : '';
  const [state, setState] = useState<VoucherAccountState>({ status: 'idle', account: null, error: '', key: '' });
  const seq = useRef(0);
  const keyRef = useRef(key);
  keyRef.current = key;
  const [tick, setTick] = useState(0);
  const refresh = useCallback(() => setTick(t => t + 1), []);
  useEffect(() => {
    const on = () => setTick(t => t + 1);
    const onStorage = (e: StorageEvent) => { if (e.key === 'k99-voucher-changed-at') on(); };
    window.addEventListener(VOUCHER_CHANGED_EVENT, on);
    window.addEventListener('focus', on);
    window.addEventListener('storage', onStorage);
    return () => { window.removeEventListener(VOUCHER_CHANGED_EVENT, on); window.removeEventListener('focus', on); window.removeEventListener('storage', onStorage); };
  }, []);
  useEffect(() => {
    const id = ++seq.current;
    if (!key) { setState({ status: 'idle', account: null, error: '', key: '' }); return; }
    setState(old => ({ status: 'loading', account: old.key === key ? old.account : null, error: '', key }));
    fetchVoucherAccount({ name: name.trim(), phone: digits, customerId }).then(r => {
      if (id !== seq.current || keyRef.current !== key) return;
      // 선택 ID가 있으면 ID 일치만 허용, 없으면 현재 name/phone 요청 시퀀스(key)로 보장.
      const account = r.account && isVoucherAccount(r.account) && (!customerId || r.account.customerId === customerId) ? r.account : null;
      setState({ status: 'ready', account, error: '', key });
    }).catch(e => {
      if (id !== seq.current || keyRef.current !== key) return;
      setState({ status: 'error', account: null, error: e instanceof Error ? e.message : '정액권 조회 실패', key });
    });
  }, [key, tick]); // eslint-disable-line react-hooks/exhaustive-deps
  const current = state.key === key && (!customerId || !state.account || state.account.customerId === customerId) ? state : { status: key ? 'loading' as const : 'idle' as const, account: null, error: '', key };
  return { ...current, refresh };
}

/** Why a voucher action must not be confirmed right now (empty string = ok). */
export function voucherBlock(req: VoucherRequest | null, s: { status: VoucherAccountState['status']; account: VoucherAccount | null; error: string }) {
  if (!req) return '';
  if (s.status === 'idle') return '정액권은 고객명과 전체 휴대전화번호를 입력한 뒤 사용할 수 있습니다.';
  if (s.status === 'loading') return '정액권 잔액을 확인 중입니다.';
  if (s.status === 'error') return `정액권 조회 실패: ${s.error}`;
  if (req.plan === 'DEDUCT' && (!s.account || s.account.balance <= 0)) return '차감할 정액권 잔액이 없습니다.';
  return '';
}

export function buildVoucherRequest(req: VoucherRequest | null, account: VoucherAccount | null): VoucherRequest | undefined {
  if (!req) return undefined;
  const number = req.number?.trim();
  return { plan: req.plan, ...(number ? { number } : {}), expectedRevision: account?.revision ?? 0 };
}
