/** SMS URI는 매장 PC에서만 생성하며 외부 QR 서비스로 고객 정보를 보내지 않는다. */
export function buildSmsUri(recipient: string, body: string): string {
  const phone = String(recipient ?? '').trim();
  if (!/^\+?[\d\s().-]+$/.test(phone)) throw Error('고객의 전체 전화번호를 확인해 주세요.');
  const normalized = phone.replace(/[\s().-]/g, '');
  if (!/^\+?\d{9,15}$/.test(normalized)) throw Error('고객의 전체 전화번호를 확인해 주세요. 뒷4자리만으로는 보낼 수 없습니다.');
  if (!body.trim()) throw Error('보낼 문구를 먼저 작성해 주세요.');
  if (body.length > 12000 || body.includes('\0')) throw Error('문구가 너무 길거나 올바르지 않습니다.');
  return `sms:${normalized}?body=${encodeURIComponent(body)}`;
}

export type SmsSummaryContext = {
  body: string; storeName?: string; customerName?: string; storePhone?: string; templateId?: string;
};
const short = (value: string, limit: number) => Array.from(value.replace(/\s+/g, ' ').trim()).slice(0, limit).join('');
/** A short notification, NOT a replacement for a fee/waiver agreement or the preserved full draft. */
export function summarizeSmsBody(context: SmsSummaryContext): string {
  const purpose: Record<string, string> = {
    'pickup-quote': '접수 세탁비 안내입니다. 자세한 내용은 매장으로 문의해 주세요.',
    'inspection-consent': '세탁 전 확인사항이 있습니다. 상세 안내를 확인해 주세요.',
    'additional-fee': '추가 세탁비 안내가 있습니다. 상세 금액·조건을 확인해 주세요.',
    'inspection-consent-fee': '세탁 위험·추가비 안내가 있습니다. 상세 내용을 확인해 주세요.',
    'complete-pickup': '세탁물 완성·수령 관련 안내입니다. 매장으로 문의해 주세요.',
    'complete-delivery': '세탁물 배송 관련 안내입니다. 매장으로 문의해 주세요.',
    'reminder-7': '보관 중인 세탁물이 있습니다. 수령 일정을 알려 주세요.',
    'storage-15': '장기 보관 세탁물 안내입니다. 매장으로 연락 부탁드립니다.',
  };
  const shop = short(context.storeName || '세탁 매장', 16);
  const customer = short(context.customerName || '고객', 10);
  const phone = (context.storePhone || '').replace(/[^\d+()-]/g, '').slice(0, 18);
  const prefix = `${shop} ${customer}님\n`;
  const suffix = phone ? `\n문의 ${phone}` : '';
  const available = Math.max(0, 80 - Array.from(prefix + suffix).length);
  const lines = context.body.split(/\n+/).map(line => line.trim()).filter(Boolean);
  const candidates = lines.filter(line => !line.includes(shop) && !/^[\s[\]【】\-—]*$/.test(line));
  const source = candidates.find(line => /접수|완성|검수|추가|배송|보관|수령|면책/.test(line))
    || candidates.find(line => /세탁/.test(line));
  const sentence = source?.match(/^.*?[.!?。](?:\s|$)/)?.[0].trim() || source;
  // Never turn an edited "not completed"/"do not deliver" into a preset completion claim.
  const fallback = purpose[context.templateId || ''] || '세탁 관련 안내입니다. 자세한 내용은 매장으로 문의해 주세요.';
  const core = sentence && Array.from(sentence).length <= available ? sentence : fallback;
  return `${prefix}${short(core, available)}${suffix}`;
}
