/** SMS URI는 매장 PC에서만 생성하며 외부 QR 서비스로 고객 정보를 보내지 않는다. */
export function buildSmsUri(recipient: string, body: string): string {
  const phone = String(recipient ?? '').trim();
  if (!/^\+?[\d\s().-]+$/.test(phone)) throw Error('고객의 전체 전화번호를 확인해 주세요.');
  const normalized = phone.replace(/[\s().-]/g, '');
  if (!/^\+?\d{9,15}$/.test(normalized)) throw Error('고객의 전체 전화번호를 확인해 주세요. 뒷4자리만으로는 보낼 수 없습니다.');
  if (!body.trim()) throw Error('보낼 문구를 먼저 작성해 주세요.');
  if (body.length > 12000 || body.includes('\0')) throw Error('문구가 너무 길거나 올바르지 않습니다.');
  return `sms:${normalized}?body=${encodeURIComponent(body)}`;
}
