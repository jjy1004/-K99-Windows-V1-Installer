import { useEffect, useRef, useState, type ReactNode } from 'react';
import './customer-receipt-panel.css';

export interface CustomerReceiptPanelProps {
  children: ReactNode;
  onIdle?: () => void;
}

export function CustomerReceiptPanel({ children, onIdle }: CustomerReceiptPanelProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    if (collapsed) el.setAttribute('inert', '');
    else el.removeAttribute('inert');
  }, [collapsed]);

  const mode = collapsed ? 'collapsed' : expanded ? 'expanded' : 'normal';

  return (
    <section className="crp-root" data-mode={mode} aria-label="고객 접수 내역" data-testid="panel-customer-receipt">
      <div className="crp-frame" inert={collapsed || undefined} aria-hidden={collapsed || undefined}>
        <div className="crp-toolbar" role="toolbar" aria-label="접수 내역 화면 조작">
          <button type="button" className="crp-btn" onClick={() => setCollapsed(true)} aria-expanded={!collapsed} data-testid="button-receipt-collapse">
            <span aria-hidden="true">↓</span> 내리기
          </button>
          <button type="button" className="crp-btn" onClick={() => setExpanded((v) => !v)} aria-pressed={expanded} data-testid="button-receipt-size">
            <span aria-hidden="true">{expanded ? '⤡' : '⤢'}</span> {expanded ? '보통' : '확대'}
          </button>
          {onIdle && (
            <button type="button" className="crp-btn crp-btn--idle" onClick={onIdle} data-testid="button-receipt-idle">
              대기 홍보 영상
            </button>
          )}
        </div>
        <div ref={bodyRef} className="crp-body" aria-hidden={collapsed || undefined}>
          {children}
        </div>
      </div>
      <button
        type="button"
        className="crp-bar"
        onClick={() => setCollapsed(false)}
        aria-expanded={!collapsed}
        hidden={!collapsed}
        data-testid="button-receipt-expand"
      >
        <span aria-hidden="true">↑</span> 접수 내역 보기
      </button>
    </section>
  );
}

export default CustomerReceiptPanel;
