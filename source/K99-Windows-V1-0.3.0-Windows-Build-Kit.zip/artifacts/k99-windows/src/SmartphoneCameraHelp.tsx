import {useEffect,useRef,useState,type KeyboardEvent as RKeyboardEvent,type ReactNode} from 'react';
import {createPortal} from 'react-dom';
import bwipjs from 'bwip-js/browser';
import {AlertTriangle,BatteryCharging,BookOpen,Cable,CheckCircle2,Download,Hammer,Info,Loader2,MonitorSmartphone,ShieldCheck,Smartphone,Usb,Wifi,X,XCircle} from 'lucide-react';
import './smartphone-camera-help.css';

type Action='iriun'|'driver'|'guide';
type Props={onClose:()=>void;onAction:(action:Action)=>Promise<{message:string}>};
const GUIDE_URL='https://developer.android.com/studio/run/device?hl=ko#setting-up';
const FOCUSABLE='button:not([disabled]),[href],input,select,textarea,[tabindex]:not([tabindex="-1"])';

function usePortal(){
  const [el]=useState(()=>{const d=document.createElement('div');d.className='sch-portal';return d;});
  useEffect(()=>{document.body.appendChild(el);return()=>{el.remove();};},[el]);
  return el;
}

function Step({n,Icon,title,children}:{n:number;Icon:typeof Wifi;title:string;children:ReactNode}){
  return <li><span className="sch__num"><b>{n}</b><Icon aria-hidden="true"/></span><div><strong>{title}</strong><p>{children}</p></div></li>;
}

export function SmartphoneCameraHelp({onClose,onAction}:Props){
  const portal=usePortal();
  const dialogRef=useRef<HTMLDivElement>(null);
  const qrRef=useRef<HTMLCanvasElement>(null);
  const closeRef=useRef(onClose);closeRef.current=onClose;
  const [tab,setTab]=useState<'wifi'|'usb'>('wifi');
  const [busy,setBusy]=useState<Action|null>(null);
  const [status,setStatus]=useState<{text:string;err:boolean}|null>(null);
  const [qrErr,setQrErr]=useState(false);

  useEffect(()=>{
    const prev=document.activeElement as HTMLElement|null;
    const t=window.setTimeout(()=>dialogRef.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus(),0);
    return()=>{window.clearTimeout(t);if(prev&&document.contains(prev))prev.focus();};
  },[]);

  useEffect(()=>{
    if(tab!=='usb'||!qrRef.current)return;
    try{bwipjs.toCanvas(qrRef.current,{bcid:'qrcode',text:GUIDE_URL,scale:5,padding:4});setQrErr(false);}catch{setQrErr(true);}
  },[tab]);

  const close=()=>closeRef.current();

  // 모달 내부 키 처리: 카메라 화면(캡처/발판 A·B·C 등)으로 전파되지 않도록 차단
  const onKeyDown=(e:RKeyboardEvent<HTMLDivElement>)=>{
    e.stopPropagation();e.nativeEvent.stopImmediatePropagation?.();
    if(e.key==='Escape'){e.preventDefault();close();return;}
    if(e.key==='Tab'&&dialogRef.current){
      const list=[...dialogRef.current.querySelectorAll<HTMLElement>(FOCUSABLE)];
      if(!list.length)return;
      const first=list[0],last=list[list.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  };
  const stopKey=(e:{stopPropagation:()=>void})=>e.stopPropagation();

  const run=async(a:Action)=>{
    if(busy)return;
    setBusy(a);setStatus({text:'요청을 보내는 중입니다…',err:false});
    try{const r=await onAction(a);setStatus({text:r.message,err:false});}
    catch(err){setStatus({text:err instanceof Error?`열지 못했습니다: ${err.message}`:'열지 못했습니다. 다시 눌러 주세요.',err:true});}
    finally{setBusy(null);}
  };

  const tabKey=(e:RKeyboardEvent<HTMLButtonElement>)=>{
    if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const n=tab==='wifi'?'usb':'wifi';setTab(n);dialogRef.current?.querySelector<HTMLElement>(`#sch-tab-${n}`)?.focus();}
  };

  const actBtn=(a:Action,label:string,Icon:typeof Wifi,alt=false)=>
    <button type="button" className={`sch__btn${alt?' is-alt':''}`} disabled={!!busy} onClick={e=>{e.stopPropagation();void run(a);}} data-testid={`button-camera-help-${a}`}>
      {busy===a?<Loader2 aria-hidden="true"/>:<Icon aria-hidden="true"/>}{label}</button>;

  return createPortal(
    <div className="sch-backdrop" onMouseDown={e=>{e.stopPropagation();if(e.target===e.currentTarget)close();}} onKeyUp={stopKey} onKeyPress={stopKey} data-testid="smartphone-camera-help">
      <div ref={dialogRef} className="sch" role="dialog" aria-modal="true" aria-labelledby="sch-title" onKeyDown={onKeyDown} onClick={stopKey}>
        <header className="sch__head">
          <h2 id="sch-title"><MonitorSmartphone aria-hidden="true"/>안 쓰는 스마트폰을 카메라로 연결하기</h2>
          <button type="button" className="sch__close" data-autofocus onClick={e=>{e.preventDefault();e.stopPropagation();close();}} data-testid="button-camera-help-close"><X aria-hidden="true"/>닫기</button>
        </header>
        <div className="sch__body">
          <div className="sch__tabs" role="tablist" aria-label="연결 방법">
            <button type="button" className="sch__tab" role="tab" id="sch-tab-wifi" aria-selected={tab==='wifi'} aria-controls="sch-panel" tabIndex={tab==='wifi'?0:-1} onKeyDown={tabKey} onClick={()=>setTab('wifi')} data-testid="tab-camera-help-wifi"><Wifi aria-hidden="true"/>와이파이로 연결</button>
            <button type="button" className="sch__tab" role="tab" id="sch-tab-usb" aria-selected={tab==='usb'} aria-controls="sch-panel" tabIndex={tab==='usb'?0:-1} onKeyDown={tabKey} onClick={()=>setTab('usb')} data-testid="tab-camera-help-usb"><Usb aria-hidden="true"/>USB 선으로 연결 (안드로이드)</button>
          </div>

          <div id="sch-panel" role="tabpanel" aria-labelledby={`sch-tab-${tab}`} style={{display:'grid',gap:16}}>
            {tab==='wifi'?<>
              <ol className="sch__steps">
                <Step n={1} Icon={Wifi} title="같은 매장 와이파이에 연결">휴대폰과 이 PC를 <b>같은 매장 와이파이</b>(공유기)에 연결해 주세요.</Step>
                <Step n={2} Icon={Smartphone} title="휴대폰과 PC에서 Iriun 앱 실행">휴대폰의 Iriun Webcam 앱과 PC의 Iriun 프로그램을 둘 다 켜 두면 자동으로 찾습니다. 그다음 카메라 목록에서 Iriun을 고르세요.</Step>
                <Step n={3} Icon={BatteryCharging} title="충전 케이블 꽂아 두기">하루 종일 쓰면 배터리가 빨리 닳습니다. 충전기를 꽂아 두고 휴대폰을 거치대에 고정하세요.</Step>
              </ol>
              <div className="sch__actions">{actBtn('iriun','Iriun PC 프로그램 열기 / 설치 안내',Download)}</div>
              <div className="sch__note"><AlertTriangle aria-hidden="true"/><div>
                <b>먼저 앱 설치가 필요합니다.</b> 휴대폰에는 Play 스토어·App Store에서 “Iriun Webcam”을, PC에는 Iriun 프로그램을 점주님이 직접 설치해 주세요. 이 프로그램이 대신 설치하지 않습니다.
                <ul>
                  <li><b>게스트 와이파이</b>는 기기끼리 서로 못 보게 막혀 있는 경우(AP 격리)가 많습니다. 손님용이 아닌 매장 본 와이파이를 쓰세요.</li>
                  <li>연결이 안 되면 <b>PC 방화벽</b>이 Iriun을 막고 있을 수 있습니다. 처음 실행 때 나오는 Windows 허용 창에서 “허용”을 눌러 주세요.</li>
                  <li>아이폰(iPhone)은 이 와이파이 방법을 사용하세요.</li>
                </ul></div></div>
            </>:<>
              <div className="sch__note is-info"><Info aria-hidden="true"/><div><b>안드로이드 휴대폰 전용</b>입니다. 아이폰은 USB 방식이 되지 않으니 <button type="button" className="sch__close" style={{minHeight:44,background:'#075fc4',display:'inline-flex',verticalAlign:'middle'}} onClick={()=>setTab('wifi')} data-testid="button-camera-help-goto-wifi"><Wifi aria-hidden="true"/>와이파이 안내</button> 를 보세요.</div></div>
              <div className="sch__usb">
                <figure className="sch__qr" style={{margin:0}}>
                  {qrErr?<p>QR을 만들지 못했습니다. 아래 “공식 안내 열기”를 눌러 주세요.</p>:<canvas ref={qrRef} aria-label="Android 공식 기기 설정 안내 페이지 QR" data-testid="img-camera-help-qr"/>}
                  <figcaption>휴대폰으로 찍으면 <b>Android 공식 설정 안내 글</b>이 열립니다. 설정 화면이 바로 열리지는 않습니다.</figcaption>
                </figure>
                <ol className="sch__steps">
                  <Step n={1} Icon={Hammer} title="빌드번호 7번 누르기">설정 → 휴대전화 정보 → (소프트웨어 정보) → <b>빌드번호</b>를 7번 누르면 개발자 옵션이 생깁니다. 메뉴 위치는 기종마다 조금 다릅니다.</Step>
                  <Step n={2} Icon={Usb} title="USB 디버깅 켜기">설정 → <b>개발자 옵션</b> → <b>USB 디버깅</b>을 켜 주세요.</Step>
                  <Step n={3} Icon={Cable} title="데이터 케이블 연결 후 허용">충전 전용이 아닌 <b>데이터 전송이 되는 USB 케이블</b>로 PC에 꽂고, 휴대폰에 뜨는 창에서 “<b>이 컴퓨터에서 항상 허용</b>”을 체크한 뒤 허용을 누르세요.</Step>
                </ol>
              </div>
              <p>USB 디버깅만으로 웹캠이 되지는 않습니다. 휴대폰과 PC에 Iriun을 설치·실행한 뒤 연결하세요. Android Studio 설치는 필요하지 않습니다.</p>
              <div className="sch__actions">
                {actBtn('iriun','Iriun PC 프로그램 열기 / 설치 안내',MonitorSmartphone)}
                {actBtn('driver','제조사 USB 드라이버 공식 설치 안내',Download,true)}
                {actBtn('guide','Android 공식 설정 안내 열기',BookOpen,true)}
              </div>
              <div className="sch__note"><ShieldCheck aria-hidden="true"/><div>
                USB 디버깅 허용은 <b>믿을 수 있는 매장 PC에서만</b> 해 주세요. 드라이버 설치와 휴대폰의 허용 버튼은 <b>점주님이 직접</b> 하셔야 하며, 이 프로그램은 자동으로 설치하거나 허용하지 않습니다.
              </div></div>
            </>}
          </div>

          <p>연결을 마치면 이 창을 닫고 카메라 목록에서 <b>Iriun Webcam 또는 DroidCam</b>을 선택해 주세요.</p>
          <div className={`sch__status${status?.err?' is-err':''}`} role="status" aria-live="polite" data-testid="status-camera-help">
            {status?(status.err?<XCircle aria-hidden="true"/>:busy?<Loader2 aria-hidden="true"/>:<CheckCircle2 aria-hidden="true"/>):<Info aria-hidden="true"/>}
            {status?.text??'버튼을 누르면 결과가 여기에 표시됩니다. 카메라 화면은 그대로 유지됩니다.'}
          </div>
        </div>
      </div>
    </div>,portal);
}
