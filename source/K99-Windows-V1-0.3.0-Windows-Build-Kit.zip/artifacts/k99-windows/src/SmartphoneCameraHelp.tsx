import { useEffect, useRef, useState, type KeyboardEvent as RKeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { MonitorSmartphone, X } from 'lucide-react';
import { IriunUsbGuide } from './IriunUsbGuide';
import './smartphone-camera-help.css';

type Action = 'iriun' | 'driver' | 'guide';
// 기존 호출부 계약은 보존하되 안내를 여는 것만으로 외부 프로그램을 실행하지 않는다.
type Props = { onClose: () => void; onAction: (action: Action) => Promise<{ message: string }> };
const FOCUSABLE = 'button:not([disabled]),[href],input,select,textarea,[tabindex]:not([tabindex="-1"])';

export function SmartphoneCameraHelp({ onClose }: Props) {
  const [portal] = useState(() => {
    const node = document.createElement('div');
    node.className = 'sch-portal';
    return node;
  });
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    document.body.appendChild(portal);
    const prev = document.activeElement as HTMLElement | null;
    const timer = window.setTimeout(() => dialogRef.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus(), 0);
    return () => {
      window.clearTimeout(timer);
      portal.remove();
      if (prev && document.contains(prev)) prev.focus();
    };
  }, [portal]);
  const onKeyDown = (e: RKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation?.();
    if (e.key === 'Escape') { e.preventDefault(); closeRef.current(); return; }
    if (e.key === 'Tab' && dialogRef.current) {
      const items = [...dialogRef.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(node => node.offsetParent !== null);
      const first = items[0], last = items[items.length - 1];
      if (first && last && e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (first && last && !e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  };
  const stopKey = (e: { stopPropagation: () => void }) => e.stopPropagation();
  return createPortal(
    <div className="sch-backdrop" data-testid="smartphone-camera-help" onMouseDown={e => {
      e.stopPropagation(); if (e.target === e.currentTarget) closeRef.current();
    }} onKeyUp={stopKey} onKeyPress={stopKey}>
      <div ref={dialogRef} className="sch" role="dialog" aria-modal="true" aria-labelledby="sch-title" onKeyDown={onKeyDown} onClick={stopKey}>
        <header className="sch__head">
          <h2 id="sch-title"><MonitorSmartphone aria-hidden />촬영 휴대폰 · USB 표준 7단계</h2>
          <button type="button" className="sch__close" data-autofocus onClick={() => closeRef.current()} data-testid="button-camera-help-close"><X aria-hidden />닫기</button>
        </header>
        <div className="sch__body"><IriunUsbGuide slides /></div>
      </div>
    </div>, portal);
}
