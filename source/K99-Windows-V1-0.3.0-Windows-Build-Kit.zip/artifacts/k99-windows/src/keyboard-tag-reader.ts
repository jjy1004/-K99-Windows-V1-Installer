import { barcodeCharFromKey } from './barcode-keys';

type TextField = HTMLInputElement | HTMLTextAreaElement;
type Snapshot = { target: EventTarget | null; value: string; from: number | null; to: number | null };
type Session = Snapshot & { raw: string; boundaries: Array<Snapshot & { offset: number }> };
type Queue = Snapshot & { text: string; end: number };
export const SCANNER_RESTORE_EVENT = 'k99-scanner-restore-input';
const isTextField = (target: EventTarget | null): target is TextField =>
  target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement &&
  ['text', 'tel', 'search', 'url', 'email', 'password', 'number'].includes(target.type);
const fullTag = (text: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-\d{2,}$/i.test(text) ||
  /^K99-[A-Z0-9-]{6,}$/i.test(text);
const tagPrefix = (text: string) => /^[0-9a-f]{8}-/i.test(text) || /^K99-/i.test(text);

/**
 * No wedge device ID is available. Keep an original field snapshot across idle
 * replay, not just across one fast burst. Shift never flushes pending text.
 * Exact Enter-terminated tags restore that snapshot before changing an order.
 * Incomplete tag-like input is discarded, never replayed into customer data.
 */
export function installKeyboardTagReader(onScan: (barcode: string) => void, host: Window = window,
  knownBarcode: (value: string) => boolean = () => false,
  onRejected: (message: string) => void = () => {}) {
  let session: Session | undefined;
  let queue: Queue | undefined;
  let protection: Snapshot | undefined;
  let discarding = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let restoring = false;
  const snapshot = (target: EventTarget | null): Snapshot => ({
    target, value: isTextField(target) ? target.value : '',
    from: isTextField(target) ? target.selectionStart : null,
    to: isTextField(target) ? target.selectionEnd : null,
  });
  const write = (saved: Snapshot, value: string, from: number | null, to: number | null, restore = false) => {
    const field = saved.target;
    if (!isTextField(field) || !field.isConnected) return;
    restoring = true;
    try {
      const proto = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(field, value);
      if (restore) field.dispatchEvent(Object.assign(new Event(SCANNER_RESTORE_EVENT), { restoredValue: value }));
      field.dispatchEvent(Object.assign(new Event('input', { bubbles: true }), { k99ScannerRestore: restore }));
      // React's telephone formatter may insert hyphens synchronously. A raw
      // pre-format caret would insert the next digit before the previous one.
      const adjusted = (position: number | null) => {
        if (restore || position === null || field.value === value ||
            !(field instanceof HTMLInputElement) || field.type !== 'tel') return position;
        const digits = value.slice(0, position).replace(/\D/g, '').length;
        if (!digits) return 0;
        let seen = 0;
        for (let i = 0; i < field.value.length; i++)
          if (/\d/.test(field.value[i]) && ++seen === digits) return i + 1;
        return field.value.length;
      };
      try { field.setSelectionRange(adjusted(from), adjusted(to)); } catch { /* number fields have no selection API */ }
    } finally { restoring = false; }
  };
  const restore = (saved: Snapshot) => write(saved, saved.value, saved.from, saved.to, true);
  const reset = () => { clearTimeout(timer); queue = undefined; session = undefined; };
  const commitBoundary = (target: EventTarget | null, offset: number) => {
    if (!session) return;
    const boundary = { ...snapshot(target), offset };
    const last = session.boundaries.length - 1;
    if (session.boundaries[last]?.offset === offset) session.boundaries[last] = boundary;
    else session.boundaries.push(boundary);
  };
  const flushQueue = () => {
    const pending = queue; queue = undefined;
    if (pending && isTextField(pending.target) && pending.target.value === pending.value) {
      const caret = (pending.from ?? pending.value.length) + pending.text.length;
      write(pending, pending.value.slice(0, pending.from ?? pending.value.length) + pending.text +
        pending.value.slice(pending.to ?? pending.value.length), caret, caret);
      commitBoundary(pending.target, pending.end);
    }
  };
  const candidateSnapshot = (): Snapshot | undefined => {
    if (!session) return;
    if (tagPrefix(session.raw)) return session;
    return session.boundaries.find(boundary => tagPrefix(session!.raw.slice(boundary.offset)));
  };
  const candidate = () => !!candidateSnapshot();
  const reject = () => {
    const saved = candidateSnapshot() ?? session;
    reset();
    if (saved) { protection = saved; restore(saved); discarding = true; }
    onRejected('불완전하거나 구분하기 어려운 태그 입력을 중지했습니다. 고객정보는 보존했습니다. Enter로 태그 입력을 끝내거나 입력란을 클릭한 뒤 다시 시도하세요.');
  };
  const finish = () => {
    if (candidate()) reject();
    else { flushQueue(); reset(); }
  };
  const key = (event: KeyboardEvent) => {
    // Physical modifier keys do not terminate a barcode or change a field.
    if (['Shift', 'CapsLock'].includes(event.key)) return;
    if (discarding) {
      event.preventDefault(); event.stopImmediatePropagation();
      if (protection) restore(protection);
      if (event.key === 'Enter') discarding = false;
      return;
    }
    const element = event.target instanceof Element ? event.target : null;
    if (element?.closest('[data-scanner-input], [contenteditable="true"]')) {
      finish(); protection = undefined; return;
    }
    if (event.ctrlKey || event.altKey || event.metaKey || event.repeat) {
      finish();
      if (discarding) { event.preventDefault(); event.stopImmediatePropagation(); }
      else protection = undefined;
      return;
    }
    if (session && event.target !== session.target) {
      finish();
      if (discarding) { event.preventDefault(); event.stopImmediatePropagation(); return; }
    }
    // New deliberate typing ends the guard for a previous scan's late IME events.
    protection = undefined;
    if (event.key === 'Enter' && session) {
      const current = session;
      const matches = [{ ...current, offset: 0 }, ...current.boundaries]
        .filter(start => {
          const text = current.raw.slice(start.offset);
          return !!text && (fullTag(text) || knownBarcode(text));
        });
      if (matches.length === 1) {
        const saved = matches[0], barcode = current.raw.slice(saved.offset);
        reset(); protection = saved;
        event.preventDefault(); event.stopImmediatePropagation();
        restore(saved); onScan(barcode); return;
      }
      // A tag embedded in uncommitted human text has no reliable boundary.
      // Do not guess a customer edit or a garment ID.
      if (matches.length > 1 || /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-\d{2,}$/i.test(current.raw) ||
          /K99-[A-Z0-9-]{6,}$/i.test(current.raw)) {
        event.preventDefault(); event.stopImmediatePropagation(); reject(); discarding = false; return;
      }
      finish(); discarding = false; return;
    }
    const composing = event.isComposing || event.keyCode === 229;
    const char = composing ? barcodeCharFromKey(event) : event.key;
    if (!char || !/^[a-zA-Z0-9-]$/.test(char)) {
      finish();
      if (discarding) { event.preventDefault(); event.stopImmediatePropagation(); }
      return;
    }
    if (!session) session = { ...snapshot(event.target), raw: '', boundaries: [] };
    session.raw += char;
    if (session.raw.length > 160) {
      if (candidate()) { event.preventDefault(); event.stopImmediatePropagation(); reject(); return; }
      flushQueue();
      session = { ...snapshot(event.target), raw: char, boundaries: [] };
    }
    if (candidate()) {
      queue = undefined; restore(candidateSnapshot()!);
      event.preventDefault(); event.stopImmediatePropagation();
    } else if (composing) {
      // Ordinary Korean composition is native. Observe physical codes only;
      // a complete tag can still restore the initial field before dispatch.
      flushQueue();
    } else {
      queue ??= { ...snapshot(event.target), text: '', end: session.raw.length };
      queue.text += char;
      queue.end = session.raw.length;
      event.preventDefault(); event.stopImmediatePropagation();
    }
    clearTimeout(timer);
    timer = setTimeout(() => { if (candidate()) reject(); else flushQueue(); }, candidate() ? 1500 : 95);
  };
  const guardInput = (event: Event) => {
    if (restoring) return;
    const saved = protection ?? candidateSnapshot();
    if (saved && saved.target === event.target) {
      if (event.cancelable) event.preventDefault();
      restore(saved);
    } else if (session && session.target === event.target &&
        ['input', 'compositionend'].includes(event.type)) {
      // Native Korean edits have no queued ASCII replay. Their final value is
      // nevertheless a committed boundary for a subsequent scan on this field.
      commitBoundary(event.target, session.raw.length);
    }
  };
  const flush = () => { finish(); protection = undefined; discarding = false; };
  host.addEventListener('keydown', key, true);
  host.addEventListener('beforeinput', guardInput, true);
  host.addEventListener('input', guardInput, true);
  host.addEventListener('compositionend', guardInput, true);
  host.addEventListener('pointerdown', flush, true);
  host.addEventListener('blur', flush);
  host.addEventListener('paste', flush, true);
  return () => {
    finish();
    host.removeEventListener('keydown', key, true);
    host.removeEventListener('beforeinput', guardInput, true);
    host.removeEventListener('input', guardInput, true);
    host.removeEventListener('compositionend', guardInput, true);
    host.removeEventListener('pointerdown', flush, true);
    host.removeEventListener('blur', flush);
    host.removeEventListener('paste', flush, true);
  };
}
