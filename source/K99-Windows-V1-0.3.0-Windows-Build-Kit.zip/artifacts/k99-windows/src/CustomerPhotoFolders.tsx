import { useEffect, useState } from 'react';

export type CustomerPhotoResult = {
  folders: { token: string; date: string; name: string }[];
  notes: string[]; truncated: boolean;
};
export function CustomerPhotoFolders({ customerId }: { customerId: string }) {
  const [result, setResult] = useState<CustomerPhotoResult | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [opening, setOpening] = useState(false);
  const native = window.k99Desktop?.customerPhotos;
  useEffect(() => {
    if (!native) return;
    let live = true;
    setResult(null); setError('');
    native({ action: 'list', customerId }).then(r => {
      if (!r.success) throw Error(r.error || '사진 폴더 조회 실패');
      if (live && r.folders) setResult({ folders: r.folders, notes: r.notes ?? [], truncated: !!r.truncated });
    }).catch(e => { if (live) setError(e instanceof Error ? e.message : '사진 폴더 조회 실패'); });
    return () => { live = false; };
  }, [customerId, attempt, native]);
  async function open(token: string) {
    if (!native || opening) return;
    setOpening(true); setError('');
    try {
      const r = await native({ action: 'open', token });
      if (!r.success) throw Error(r.error || '사진 폴더 열기 실패');
    } catch (e) { setError(e instanceof Error ? e.message : '사진 폴더 열기 실패'); }
    finally { setOpening(false); }
  }
  return <section aria-label="해당 고객 최근 접수 사진" style={{ marginTop: 12 }}>
    <strong>해당 고객 최근 접수 사진 · 최근 6개월</strong>
    {!native ? <p className="cdir-hint">실제 Windows 설치본에서만 D 드라이브 폴더를 조회합니다.</p>
      : !result && !error ? <p role="status">사진 폴더를 찾는 중…</p>
        : result && <>
          {!result.folders.length && <p className="cdir-hint">고객명·전화 끝4자리가 모두 일치하는 폴더가 없습니다.</p>}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
            {result.folders.map(f => <button key={f.token} type="button" className="cdir-btn" disabled={opening}
              title={f.name} onClick={() => void open(f.token)}>{f.date} · 사진 폴더 열기</button>)}
          </div>
          {result.truncated && <p className="cdir-hint">조회 한도에 도달했습니다. 최근 최대 24개를 표시합니다.</p>}
          {result.notes.length > 0 && <details><summary>저장 경로 확인</summary>{result.notes.map(n => <p key={n}>{n}</p>)}</details>}
        </>}
    {error && <p role="alert" className="cdir-error">{error}</p>}
    {native && <button type="button" className="cdir-btn" disabled={opening} onClick={() => setAttempt(a => a + 1)}>사진 폴더 다시 조회</button>}
  </section>;
}
