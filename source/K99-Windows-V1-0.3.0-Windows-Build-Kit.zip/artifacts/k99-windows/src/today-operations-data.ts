import { businessOrders } from './order-deletion-policy';
import type { ConfirmedOrder } from './order-record.ts';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import type { GarmentRecord } from './garment-record.ts';
import { activePhotosOf } from './manual-photo-link.ts';
import { currentOperations } from './order-operations.ts';
import { koreaCalendarDate, storageDaysElapsed, storageFee } from './storage-policy.ts';

export type TodayCardKey =
  | 'today-intake' | 'inspection-pending' | 'customer-approval-pending'
  | 'laundry-pending' | 'laundry-in-progress' | 'completion-inspection-pending'
  | 'rewash' | 'ready-for-handover' | 'today-pickup-delivery'
  | 'uncollected' | 'photo-check' | 'tag-barcode-check';

export type TodayFilterRecord = {
  orderId: string;
  garmentId?: string;
  customerName: string;
  itemName?: string;
  currentStatus: string;
  verificationNote?: string;
};
export type TodaySummaryCard = {
  key: TodayCardKey;
  label: string;
  count: number;
  records: TodayFilterRecord[];
  orderIds: string[];
  garmentIds: string[];
};
export type TodayOperationsSummary = { asOf: string; cards: TodaySummaryCard[] };

export type AttentionWarningType =
  | 'incomplete-garment-record' | 'photo-missing' | 'missing-tag-barcode'
  | 'inspection-incomplete' | 'customer-approval-missing' | 'risk-waiver-approval-missing' | 'message-review-pending'
  | 'long-wait-status' | 'rewash-in-progress' | 'completion-inspection-missing'
  | 'completion-photo-missing' | 'pickup-delivery-contradiction' | 'uncollected'
  | 'storage-fee-applicable' | 'photo-association-problem'
  | 'invalid-or-duplicate-garment-id' | 'hardware-action-failed';
export type AttentionWarning = {
  type: AttentionWarningType;
  title: string;
  message: string;
  orderId: string;
  garmentId?: string;
  details?: Record<string, string | number | boolean>;
};

export type DataQualityCheckKey =
  | 'missing-customer-name' | 'malformed-phone' | 'missing-garment-id'
  | 'duplicate-garment-id' | 'quantity-garment-count-mismatch'
  | 'order-total-inconsistency' | 'missing-service-type' | 'missing-intake-date'
  | 'orphan-garment' | 'orphan-photo-reference' | 'invalid-status-transition-history';
export type DataQualityFinding = { orderId: string; garmentId?: string; message: string };
export type DataQualityCheck = {
  key: DataQualityCheckKey;
  label: string;
  count: number;
  affectedRecords: DataQualityFinding[];
};
export type DataQualityReport = { checks: DataQualityCheck[]; totalFindings: number };

export type PickupDeliveryBoardRecord = {
  orderId: string;
  customerName: string;
  customerPhoneLast4: string;
  address: string;
  kind: '수거' | '배달' | '수거·배달';
  requestedDate: string | null;
  requestedTime: string | null;
  itemCount: number;
  readiness: string;
  paymentStatus: string;
  additionalAmount: number | null;
  staffNote: string;
};

export type NextAction = {
  orderId: string;
  garmentId?: string;
  customerName: string;
  itemName?: string;
  currentStatus: string;
  action: string;
};

type Context = { order: ConfirmedOrder; garment?: GarmentRecord };
const active = (order: ConfirmedOrder) => !currentOperations(order).cancelledAt;
const digits = (value: string | undefined) => (value ?? '').replace(/\D/g, '');
const orderGarments = (order: ConfirmedOrder) => Array.isArray(order.garments) ? order.garments : [];
const contexts = (orders: ConfirmedOrder[]): Context[] => orders.flatMap((order) => {
  const garments = orderGarments(order);
  return garments.length ? garments.map((garment) => ({ order, garment })) : [{ order }];
});
const passedHandover = (garment: GarmentRecord) =>
  garment.handoverStatus === 'complete' || garment.processStatus === '반출 완료';
const isReady = (garment: GarmentRecord) =>
  garment.processStatus === '출고 대기' || garment.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER';
function hasSavedPhoto(garment: GarmentRecord, role: 'intake' | 'completion'): boolean {
  if (role === 'intake' && garment.photoStatus === 'saved' && !(garment.unlinkedPhotoIds?.length)) return true;
  return activePhotosOf(garment).some((photo) => photo.role === role && photo.status === 'saved');
}
function hasSimulatedPhoto(garment: GarmentRecord, role: 'intake' | 'completion'): boolean {
  if (role === 'intake' && garment.photoStatus === 'simulated' && !(garment.unlinkedPhotoIds?.length)) return true;
  return activePhotosOf(garment).some((photo) => photo.role === role && photo.status === 'simulated');
}
function rewashEvidence(garment: GarmentRecord): boolean {
  return (garment.rewashCount ?? 0) > 0
    || garment.auditEvents?.some((event) => event.action === '재세탁 등록' || event.rewashCycle !== undefined) === true;
}
const statusOf = (order: ConfirmedOrder, garment?: GarmentRecord) => {
  if (!garment) return orderDisplayStatus(order);
  if (garmentDisplayStatus(order, garment, '') === '인도 완료') return '인도 완료';
  if (garment.processStatus) return garment.processStatus;
  if (passedHandover(garment)) return '반출 완료';
  if (isReady(garment) || garment.completionStatus === 'complete') return '출고 대기';
  if (garment.cleaningStatus === 'in-progress') return '세탁 중';
  if (garment.cleaningStatus === 'complete') return '세탁 완료';
  return order.status;
};
const itemName = (garment?: GarmentRecord) => garment?.itemName;
const toFilter = ({ order, garment }: Context, key?: TodayCardKey): TodayFilterRecord => ({
  orderId: order.id, ...(garment ? { garmentId: garment.garmentId } : {}),
  customerName: order.customerName, ...(itemName(garment) ? { itemName: itemName(garment) } : {}),
  currentStatus: statusOf(order, garment),
  ...(garment && key === 'photo-check' && (hasSimulatedPhoto(garment, 'intake') && !hasSavedPhoto(garment, 'intake')
    || isReady(garment) && hasSimulatedPhoto(garment, 'completion') && !hasSavedPhoto(garment, 'completion'))
    ? { verificationNote: '모의 사진 기록만 있어 실물 사진 저장 여부 확인이 필요합니다.' } : {}),
  ...(garment && key === 'tag-barcode-check' && garment.tagStatus === 'simulated'
    ? { verificationNote: '태그 모의 기록만 있어 실제 출력 확인이 필요합니다.' } : {}),
});
const unique = (values: Array<string | undefined>) => [...new Set(values.filter((value): value is string => Boolean(value)))];
const validCalendarDate = (value: unknown): value is string => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const ts = Date.parse(`${value}T00:00:00.000Z`);
  return Number.isFinite(ts) && new Date(ts).toISOString().slice(0, 10) === value;
};
function asSeoulDate(value: string | Date): string {
  if (typeof value === 'string' && validCalendarDate(value)) return value;
  return koreaCalendarDate(value);
}
function orderDate(order: ConfirmedOrder): string | null {
  try { return order.intakeAt ? koreaCalendarDate(order.intakeAt) : null; } catch { return null; }
}
function historyApprovals(order: ConfirmedOrder): Set<string> {
  return new Set(order.inspection?.response?.decisions ?? []);
}
function approved(order: ConfirmedOrder): boolean {
  return order.status === '세탁 진행 승인' || order.status === '전체 세탁 완료 / 반출 대기';
}
function addWarning(list: AttentionWarning[], warning: AttentionWarning) {
  list.push(warning);
}

const CARD_DEFINITIONS: Array<{ key: TodayCardKey; label: string; select: (c: Context, today: string) => boolean }> = [
  { key: 'today-intake', label: '오늘 접수', select: ({ order }, today) => orderDate(order) === today },
  { key: 'inspection-pending', label: '검수 대기', select: ({ order, garment }) =>
    active(order) && (garment ? garment.inspectionStatus === 'pending' && !order.inspection : !order.inspection) },
  { key: 'customer-approval-pending', label: '고객 승인 대기', select: ({ order }) =>
    active(order) && ['고객 승인 대기', '고객 회신 대기', '보류'].includes(order.status) },
  { key: 'laundry-pending', label: '세탁 대기', select: ({ order, garment }) => active(order) &&
    (garment?.processStatus === '세탁 대기' || garment?.cleaningStatus === 'pending' && order.status === '세탁 진행 승인') },
  { key: 'laundry-in-progress', label: '세탁 중', select: ({ order, garment }) => active(order) &&
    (garment?.processStatus === '세탁 중' || garment?.cleaningStatus === 'in-progress') },
  { key: 'completion-inspection-pending', label: '완성 검수 대기', select: ({ order, garment }) => active(order) &&
    (garment?.processStatus === '완성 검수' || garment?.completionStatus === 'in-progress') },
  { key: 'rewash', label: '재세탁', select: ({ order, garment }) => active(order) && Boolean(garment &&
    !passedHandover(garment) && ['세탁 대기', '세탁 중'].includes(garment.processStatus ?? '') && rewashEvidence(garment)) },
  { key: 'ready-for-handover', label: '출고 대기', select: ({ order, garment }) => active(order) && Boolean(garment && isReady(garment) && !passedHandover(garment)) },
  { key: 'today-pickup-delivery', label: '오늘 수거/배달', select: ({ order }, today) => active(order) &&
    (order.choices.pickupRequested
      && (currentOperations(order).pickupDate || order.choices.requestedPickupDate) === today
      || order.choices.deliveryRequested && currentOperations(order).deliveryDate === today) },
  { key: 'uncollected', label: '미반출', select: ({ order, garment }) => active(order) &&
    (garment ? !passedHandover(garment) : order.status === '전체 세탁 완료 / 반출 대기') },
  { key: 'photo-check', label: '사진 확인 필요', select: ({ order, garment }) => active(order) && Boolean(garment &&
    (!hasSavedPhoto(garment, 'intake')
      || isReady(garment) && !hasSavedPhoto(garment, 'completion'))) },
  { key: 'tag-barcode-check', label: '태그/바코드 확인 필요', select: ({ order, garment }) => active(order) && Boolean(garment &&
    (garment.tagStatus !== 'printed'
      || !garment.garmentId || !garment.barcodeValue || garment.barcodeValue !== garment.garmentId)) },
];

export function todayOperationsSummary(orders: ConfirmedOrder[], asOf: string | Date): TodayOperationsSummary {
  orders = businessOrders(orders);
  const today = asSeoulDate(asOf);
  const all = contexts(orders);
  const cards = CARD_DEFINITIONS.map(({ key, label, select }) => {
    const records = all.filter((context) => select(context, today)).map((context) => toFilter(context, key));
    return { key, label, count: records.length, records,
      orderIds: unique(records.map((record) => record.orderId)),
      garmentIds: unique(records.map((record) => record.garmentId)) };
  });
  return { asOf: today, cards };
}

export function todayAttentionWarnings(orders: ConfirmedOrder[], asOf: string | Date): AttentionWarning[] {
  orders = businessOrders(orders);
  const today = asSeoulDate(asOf);
  const warnings: AttentionWarning[] = [];
  const garmentIdCounts = new Map<string, number>();
  for (const order of orders) for (const garment of orderGarments(order)) {
    if (garment.garmentId) garmentIdCounts.set(garment.garmentId, (garmentIdCounts.get(garment.garmentId) ?? 0) + 1);
  }
  for (const order of orders) {
    const garments = orderGarments(order);
    if (active(order) && !garments.length) addWarning(warnings, {
      type: 'incomplete-garment-record', title: '의류 기록 누락',
      message: '접수 주문에 저장된 의류 기록이 없습니다.', orderId: order.id,
    });
    if ((order.choices.pickupRequested && order.choices.deliveryRequested)
      || order.choices.directPickup && order.choices.deliveryRequested) addWarning(warnings, {
      type: 'pickup-delivery-contradiction', title: '수거·배달 정보 확인',
      message: '수거·배달 선택 정보가 서로 모순됩니다.', orderId: order.id,
    });
    const approvalReq = order.inspection?.approvalRequirements;
    const decisions = historyApprovals(order);
    if (order.inspection?.needsApproval && !approved(order)) {
      const missing: string[] = [];
      if (approvalReq?.price && !decisions.has('추가요금 동의')) missing.push('price');
      if ((approvalReq?.otherPriceChange || approvalReq?.work) && !decisions.has('전체 진행 동의')) missing.push('price');
      if (approvalReq?.method && !decisions.has('변경 세탁방법 동의')) missing.push('method');
      if (approvalReq?.risk && !decisions.has('위험 안내 확인')) missing.push('risk');
      if (approvalReq?.waiver && !decisions.has('면책 동의')) missing.push('waiver');
      const missingChanges = missing.filter((item) => item === 'price' || item === 'method');
      const missingRisk = missing.filter((item) => item === 'risk' || item === 'waiver');
      if (missingChanges.length) addWarning(warnings, {
        type: 'customer-approval-missing', title: '변경 내용 고객 승인 필요',
        message: '변경 세탁방법 또는 금액에 필요한 고객 승인이 확인되지 않았습니다.',
        orderId: order.id, details: { missing: unique(missingChanges).join(',') },
      });
      if (missingRisk.length) addWarning(warnings, {
        type: 'risk-waiver-approval-missing', title: '위험·면책 승인 필요',
        message: '위험 안내 또는 면책에 필요한 고객 승인이 확인되지 않았습니다.',
        orderId: order.id, details: { missing: unique(missingRisk).join(',') },
      });
    }
    if (order.inspection?.customerMessage && !order.inspection.messageReadyAt
      || order.completionMessage?.status === '초안') addWarning(warnings, {
      type: 'message-review-pending', title: '고객 안내 검토 필요',
      message: '고객 안내 문안이 직원 검토 또는 발송 준비를 기다리고 있습니다.', orderId: order.id,
    });
    for (const garment of garments) {
      const ref = { orderId: order.id, garmentId: garment.garmentId };
      const eventDates = (garment.auditEvents ?? []).map((event) => event.at).filter(Boolean);
      const latestAt = garment.processUpdatedAt || eventDates.at(-1);
      if (active(order) && !hasSavedPhoto(garment, 'intake')) addWarning(warnings, {
        type: 'photo-missing', title: '접수 사진 확인 필요',
        message: hasSimulatedPhoto(garment, 'intake')
          ? '모의 세탁 전 사진 기록만 있어 실물 사진 저장 여부를 확인해야 합니다.'
          : '저장된 세탁 전 사진 기록이 없습니다.',
        ...ref, details: { phase: 'intake', ...(hasSimulatedPhoto(garment, 'intake') ? { verification: 'unverified' } : {}) },
      });
      if (active(order) && (garment.tagStatus !== 'printed'
        || !garment.garmentId || !garment.barcodeValue || garment.barcodeValue !== garment.garmentId)) addWarning(warnings, {
        type: 'missing-tag-barcode', title: '태그·바코드 확인 필요',
        message: garment.tagStatus === 'simulated'
          ? '태그 모의 기록만 있어 실제 출력 여부를 확인해야 합니다.'
          : '실제 태그 출력 기록이 없거나 바코드 정보가 확인되지 않습니다.',
        ...ref, ...(garment.tagStatus === 'simulated' ? { details: { verification: 'unverified' } } : {}),
      });
      if (active(order) && !order.inspection) addWarning(warnings, {
        type: 'inspection-incomplete', title: '전문 검수 필요',
        message: '주문에 완료된 전문 검수 기록이 없습니다.', ...ref,
      });
      if (active(order) && latestAt && garment.processStatus && garment.processStatus !== '반출 완료') {
        try {
          if (storageDaysElapsed(koreaCalendarDate(latestAt), today) >= 3) addWarning(warnings, {
            type: 'long-wait-status', title: '상태 장기 대기 확인',
            message: '현재 상태가 3일 이상 유지된 것으로 기록되어 있습니다.', ...ref,
            details: { processStatus: garment.processStatus, days: storageDaysElapsed(koreaCalendarDate(latestAt), today) },
          });
        } catch { /* Invalid timestamps do not establish a wait duration. */ }
      }
      if (active(order) && !passedHandover(garment) && rewashEvidence(garment)
        && ['세탁 대기', '세탁 중'].includes(garment.processStatus ?? '')) addWarning(warnings, {
        type: 'rewash-in-progress', title: '재세탁 진행 중',
        message: '재세탁 이력이 있으며 현재 세탁 대기 또는 진행 상태입니다.', ...ref,
      });
      if (active(order) && garment.cleaningStatus === 'complete'
        && garment.completionStatus !== 'complete' && garment.processStatus !== '출고 대기'
        && garment.processStatus !== '반출 완료') addWarning(warnings, {
        type: 'completion-inspection-missing', title: '완성 검수 필요',
        message: '세탁 완료 기록은 있으나 완성 검수 완료 기록이 없습니다.', ...ref,
      });
      if (active(order) && isReady(garment) && !hasSavedPhoto(garment, 'completion')) addWarning(warnings, {
        type: 'completion-photo-missing', title: '세탁 후 사진 확인 필요',
        message: hasSimulatedPhoto(garment, 'completion')
          ? '모의 세탁 후 사진 기록만 있어 실물 사진 저장 여부를 확인해야 합니다.'
          : '출고 대기 의류의 저장된 세탁 후 사진 기록이 없습니다.',
        ...ref, ...(hasSimulatedPhoto(garment, 'completion') ? { details: { verification: 'unverified' } } : {}),
      });
      if (active(order) && !passedHandover(garment)) {
        addWarning(warnings, { type: 'uncollected', title: '미반출 세탁물',
          message: '반출 완료 기록이 없는 세탁물입니다.', ...ref });
        try {
          const elapsed = storageDaysElapsed(orderDate(order) ?? '', today);
          if (elapsed >= 15) {
            const fee = storageFee(orderDate(order)!, today, 1);
            if (fee > 0) addWarning(warnings, { type: 'storage-fee-applicable', title: '보관료 확인',
              message: '정책상 보관료가 발생할 수 있는 기간입니다.', ...ref, details: { amount: fee } });
          }
        } catch { /* Missing/invalid intake dates do not imply a fee. */ }
      }
      const photoRecords = [
        ...(garment.beforePhoto ? [garment.beforePhoto] : []),
        ...(garment.completionPhoto ? [garment.completionPhoto] : []),
        ...(garment.photoHistory ?? []),
      ];
      if (photoRecords.some((photo) => photo.garmentId !== garment.garmentId)
        || (garment.annotationRevisions ?? []).some((revision) => revision.garmentId !== garment.garmentId)) addWarning(warnings, {
        type: 'photo-association-problem', title: '사진 연결 확인 필요',
        message: '사진 또는 주석 메타데이터의 의류 ID가 해당 기록과 다릅니다.', ...ref,
      });
      if (!garment.garmentId || (garment.garmentId && (garmentIdCounts.get(garment.garmentId) ?? 0) > 1)
        || !garment.garmentId.startsWith(`${order.id}-`)) addWarning(warnings, {
        type: 'invalid-or-duplicate-garment-id', title: '의류 ID 확인 필요',
        message: '의류 ID가 없거나 중복·주문 연결 오류가 있습니다.', ...ref,
      });
      if ((garment.auditEvents ?? []).some((event) => event.type === 'capture-error' || event.type === 'print-error'
        || event.status === 'failed')) addWarning(warnings, {
        type: 'hardware-action-failed', title: '장비 작업 실패 확인',
        message: '촬영 또는 태그 출력 실패로 기록된 이벤트가 있습니다.', ...ref,
      });
    }
  }
  return warnings;
}

const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  '접수 완료': ['촬영/태그 완료'],
  '촬영/태그 완료': ['전문검수 완료'],
  '전문검수 완료': ['세탁 대기'],
  '세탁 대기': ['세탁 중'],
  '세탁 중': ['세탁 완료'],
  '세탁 완료': ['완성 검수'],
  '완성 검수': ['출고 대기', '세탁 대기', '완성 검수'],
  '출고 대기': ['반출 완료', '세탁 대기'],
};
const QUALITY_DEFS: Array<[DataQualityCheckKey, string]> = [
  ['missing-customer-name', '고객명 누락'], ['malformed-phone', '전화번호 형식 오류'],
  ['missing-garment-id', 'garmentId 누락'], ['duplicate-garment-id', 'garmentId 중복'],
  ['quantity-garment-count-mismatch', '수량과 의류 기록 수 불일치'],
  ['order-total-inconsistency', '주문 합계 불일치'], ['missing-service-type', '서비스 종류 누락'],
  ['missing-intake-date', '접수일 누락 또는 형식 오류'], ['orphan-garment', '고아 의류 기록'],
  ['orphan-photo-reference', '고아 사진 참조'], ['invalid-status-transition-history', '상태 전이 이력 오류'],
];

export function todayDataQualityReport(orders: ConfirmedOrder[]): DataQualityReport {
  orders = businessOrders(orders);
  const findings = new Map<DataQualityCheckKey, DataQualityFinding[]>(
    QUALITY_DEFS.map(([key]) => [key, []]));
  const garmentIdCounts = new Map<string, number>();
  for (const order of orders) for (const garment of orderGarments(order)) {
    if (garment.garmentId) garmentIdCounts.set(garment.garmentId, (garmentIdCounts.get(garment.garmentId) ?? 0) + 1);
  }
  for (const order of orders) {
    const garments = orderGarments(order);
    const add = (key: DataQualityCheckKey, message: string, garmentId?: string) =>
      findings.get(key)!.push({ orderId: order.id, ...(garmentId ? { garmentId } : {}), message });
    if (!order.customerName?.trim()) add('missing-customer-name', '고객명이 비어 있습니다.');
    if (!/^01\d{8,9}$/.test(digits(order.customerPhone))) add('malformed-phone', '휴대전화 번호 형식이 유효하지 않습니다.');
    if (!validCalendarDate(orderDate(order))) add('missing-intake-date', '유효한 접수 날짜를 확인할 수 없습니다.');
    const expected = (order.items ?? []).reduce((sum, item) => sum + (Number.isFinite(item.quantity) ? item.quantity : 0), 0);
    if (garments.length !== expected || order.totalQuantity !== expected) add('quantity-garment-count-mismatch',
      `품목 수량 ${expected}개, 주문 수량 ${order.totalQuantity}개, 저장 의류 기록 ${garments.length}개를 확인해 주세요.`);
    for (const garment of garments) {
      if (!garment.garmentId) add('missing-garment-id', '의류 ID가 없습니다.');
      else if ((garmentIdCounts.get(garment.garmentId) ?? 0) > 1)
        add('duplicate-garment-id', '다른 의류 기록과 ID가 중복됩니다.', garment.garmentId);
      if (!garment.serviceType) add('missing-service-type', '서비스 종류가 없습니다.', garment.garmentId);
      if (garment.orderId !== order.id) add('orphan-garment', '의류 기록의 주문 ID가 소속 주문과 다릅니다.', garment.garmentId);
      const photos = [...(garment.beforePhoto ? [garment.beforePhoto] : []),
        ...(garment.completionPhoto ? [garment.completionPhoto] : []), ...(garment.photoHistory ?? [])];
      for (const photo of photos) if (photo.garmentId !== garment.garmentId)
        add('orphan-photo-reference', '사진 메타데이터가 존재하지 않거나 다른 의류 ID를 참조합니다.', garment.garmentId);
      const photoRequestIds = new Set(photos.map((photo) => photo.requestId));
      for (const revision of garment.annotationRevisions ?? []) if (revision.garmentId !== garment.garmentId
        || !photoRequestIds.has(revision.photoRequestId))
        add('orphan-photo-reference', '주석이 다른 의류 ID의 사진을 참조합니다.', garment.garmentId);
      let previous: string | undefined;
      for (const event of garment.auditEvents ?? []) {
        if (!event.previousStatus && !event.newStatus) continue;
        if (!event.previousStatus || !event.newStatus
          || !(ALLOWED_TRANSITIONS[event.previousStatus] ?? []).includes(event.newStatus)
          || previous !== undefined && event.previousStatus !== previous) {
          add('invalid-status-transition-history', '상태 전이 이력이 비어 있거나 허용되지 않는 순서입니다.', garment.garmentId);
          break;
        }
        previous = event.newStatus;
      }
    }
    const expectedTotal = order.laundryTotal + order.serviceFee
      + (order.choices.technicalFee ?? 0) - (order.choices.discount ?? 0);
    if (order.estimatedTotal !== expectedTotal) add('order-total-inconsistency', '예상 합계가 소계·수수료·추가요금·할인 합산과 다릅니다.');
  }
  const checks = QUALITY_DEFS.map(([key, label]) => {
    const affectedRecords = findings.get(key)!;
    return { key, label, count: affectedRecords.length, affectedRecords };
  });
  return { checks, totalFindings: checks.reduce((sum, check) => sum + check.count, 0) };
}

export function todayPickupDeliveryBoard(orders: ConfirmedOrder[], asOf: string | Date): PickupDeliveryBoardRecord[] {
  orders = businessOrders(orders);
  const today = asSeoulDate(asOf);
  return orders.flatMap((order) => {
    if (!active(order)) return [];
    const ops = currentOperations(order);
    const pickupDate = ops.pickupDate || order.choices.requestedPickupDate;
    const deliveryDate = ops.deliveryDate;
    const pickupToday = order.choices.pickupRequested && pickupDate === today;
    const deliveryToday = order.choices.deliveryRequested && deliveryDate === today;
    if (!pickupToday && !deliveryToday) return [];
    const garments = orderGarments(order);
    const ready = garments.length > 0 && garments.every((garment) => isReady(garment));
    const additional = order.inspection?.additionalCharge;
    const kind: PickupDeliveryBoardRecord['kind'] = pickupToday && deliveryToday
      ? '수거·배달' : pickupToday ? '수거' : '배달';
    return [{
      orderId: order.id, customerName: order.customerName,
      customerPhoneLast4: digits(order.customerPhone).slice(-4), address: ops.detailAddress || order.customerAddress,
      kind,
      requestedDate: pickupToday ? pickupDate || null : deliveryDate || null,
      requestedTime: pickupToday ? ops.pickupTime || null : ops.deliveryTime || null,
      itemCount: order.totalQuantity, readiness: ready ? '출고 준비 완료' : '기록상 준비 완료 아님',
      paymentStatus: ops.paymentStatus, additionalAmount: additional ?? null,
      // Customer requests are not staff notes. There is no dedicated staff-note
      // field in the saved logistics record; leave it explicitly unrecorded.
      staffNote: '',
    }];
  });
}

function nextFor({ order, garment }: Context): NextAction {
  const base = { orderId: order.id, ...(garment ? { garmentId: garment.garmentId, itemName: garment.itemName } : {}),
    customerName: order.customerName, currentStatus: statusOf(order, garment) };
  if (!garment) return { ...base, action: order.inspection ? '의류 기록 확인 필요' : '전문 검수 필요' };
  const status = statusOf(order, garment);
  if (passedHandover(garment)) return { ...base, action: '인도 완료' };
  if (garment.completionStatus === 'complete' || garment.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER') {
    if (!hasSavedPhoto(garment, 'completion')) return { ...base, action: '세탁 후 사진 필요' };
    return { ...base, action: '고객 수령 대기' };
  }
  if (!order.inspection) return { ...base, action: '전문 검수 필요' };
  if (order.inspection.needsApproval && !approved(order)) return { ...base, action: '고객 승인 필요' };
  if (rewashEvidence(garment) && !passedHandover(garment)
    && ['세탁 대기', '세탁 중'].includes(garment.processStatus ?? '')) return { ...base, action: '재세탁 진행 중' };
  if (garment.cleaningStatus === 'pending' && order.status === '세탁 진행 승인') return { ...base, action: '세탁 시작 가능' };
  if (garment.cleaningStatus === 'in-progress' || status === '세탁 중') return { ...base, action: '세탁 진행 중' };
  if (garment.cleaningStatus === 'complete') return { ...base, action: '완성 검수 필요' };
  if (isReady(garment) && !garment.completionPhoto
    && !garment.photoHistory?.some((photo) => photo.role === 'completion' && photo.status === 'saved'))
    return { ...base, action: '세탁 후 사진 필요' };
  if (isReady(garment) && !passedHandover(garment)) return { ...base, action: '출고 준비 완료' };
  if (garment.processStatus === '세탁 대기') return { ...base, action: '세탁 시작 가능' };
  return { ...base, action: '현재 상태 확인 필요' };
}

/** Returns one and only one non-mutating next-action recommendation per stored garment, or per legacy order with no garment rows. */
export function recommendedNextActions(orders: ConfirmedOrder[]): NextAction[] {
  orders = businessOrders(orders);
  return contexts(orders).map(nextFor);
}