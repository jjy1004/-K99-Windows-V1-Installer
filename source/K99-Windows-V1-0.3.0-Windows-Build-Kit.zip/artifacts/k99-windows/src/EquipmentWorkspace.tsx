import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import {
  DEFAULT_FOOT_SWITCH_KEY, DEFAULT_PHOTO_ARCHIVE_ROOT,
  equipmentRequest, getEquipmentState,
  type EquipmentConfig, type EquipmentJob, type EquipmentOrder, type EquipmentState,
} from './equipment-client';
import './equipment.css';
import {useFootCapture,FOOT_SWITCH_KEYS} from './camera-capture-controls';
import {iriunDevices} from './iriun-camera';
import {SmartphoneCameraHelp} from './SmartphoneCameraHelp';
import {cameraConnectionAction} from './camera-connection';
import {correctCameraCanvas} from './camera-color';
import {useManualCamera} from './use-manual-camera';
import {useIriunCamera} from './use-iriun-camera';
import {migrateCameraCache} from './camera-cache';
import {useCameraColorPreview} from './use-camera-color-preview';
import {CameraColorSliders} from './CameraColorSliders';
import type { FootSwitchKey } from './desktop-runtime';
import { CustomerImportPanel } from './CustomerDirectory';

type Role = 'intake' | 'completion';
type ScanSource = 'usb-keyboard' | 'manual' | 'mock';
type ScanResult = { found: boolean; order?: EquipmentOrder; garmentId?: string; message: string };

const JOB_LABEL: Record<EquipmentJob['status'], { text: string; cls: string }> = {
  pending: { text: '대기', cls: '' },
  submitting: { text: '전송 중', cls: 'is-warn' },
  simulated: { text: '모의 처리 (실제 출력 아님)', cls: 'is-mock' },
  submitted: { text: '스풀러 접수됨 (물리 출력 미확인)', cls: 'is-ok' },
  failed: { text: '실패', cls: 'is-bad' },
  unknown: { text: '결과 불명 · 확인 필요', cls: 'is-bad' },
};
const won = (n: number) => `${n.toLocaleString('ko-KR')}원`;
const errText = (c: unknown, f: string) => (c instanceof Error && c.message ? c.message : f);

function mockPng(order: EquipmentOrder, garmentId: string, itemName: string, role: Role) {
  const c = document.createElement('canvas');
  c.width = 960; c.height = 720;
  const g = c.getContext('2d');
  if (!g) throw new Error('캔버스를 만들 수 없습니다.');
  g.fillStyle = '#e9e4d6'; g.fillRect(0, 0, 960, 720);
  g.fillStyle = '#2f6f68'; g.fillRect(330, 170, 300, 380);
  g.fillStyle = '#21323d'; g.font = 'bold 30px sans-serif';
  g.fillText(`${itemName} · ${role === 'intake' ? '접수' : '완성'}`, 40, 70);
  g.font = '22px monospace';
  g.fillText(`주문 ${order.id}`, 40, 620); g.fillText(`의류 ${garmentId}`, 40, 655);
  g.fillText(new Date().toLocaleString('ko-KR'), 40, 690);
  g.save(); g.translate(480, 360); g.rotate(-0.4);
  g.fillStyle = 'rgba(176,52,40,.55)'; g.font = 'bold 120px sans-serif'; g.textAlign = 'center';
  g.fillText('모의 촬영', 0, 40); g.restore();
  g.strokeStyle = 'rgba(176,52,40,.8)'; g.lineWidth = 10; g.strokeRect(5, 5, 950, 710);
  return c.toDataURL('image/png');
}

export function EquipmentWorkspace() {
  const [state, setState] = useState<EquipmentState | null>(null);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState('');
  const [orderId, setOrderId] = useState(()=>new URLSearchParams(window.location.search).get('orderId')||'');
  const [garmentId, setGarmentId] = useState(()=>new URLSearchParams(window.location.search).get('garmentId')||'');
  const [role, setRole] = useState<Role>('intake');
  // Every shot is saved immediately while the live preview stays on. Unlimited shots per garment.
  const [lastShot, setLastShot] = useState('');
  const burstBusy = useRef(false);
  const [reprintReason, setReprintReason] = useState('');
  const [barcode, setBarcode] = useState('');
  const [scanSource, setScanSource] = useState<ScanSource>('usb-keyboard');
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [draft, setDraft] = useState<EquipmentConfig | null>(null);
  const [displayId, setDisplayId] = useState(()=>localStorage.getItem('k99-customer-display-id')||'');
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [cameraOn, setCameraOn] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [connecting,setConnecting]=useState(false);
  const [activeDeviceId,setActiveDeviceId]=useState('');
  const camera=useIriunCamera(videoRef,streamRef,s=>{
    setCameraOn(s.phase==='ready');setConnecting(s.phase==='connecting');setCameraError(s.message);
    if(s.deviceId)setActiveDeviceId(s.deviceId);
  });
  const refreshRun = useRef(0);

  const refresh = useCallback(async () => {
    const run=++refreshRun.current;
    try {
      const next = await getEquipmentState();
      if(run!==refreshRun.current)return;
      setState(next); setLoadError('');
      setDisplayId(old=>next.monitors.some(m=>m.id===old)?old:next.display.displayId||next.monitors.find(m=>!m.primary)?.id||'');
      setDraft(old => old ?? next.config);
    } catch (c) { setLoadError(errText(c, '장비 상태를 읽지 못했습니다.')); }
  }, []);

  useEffect(() => {
    try{migrateCameraCache(localStorage);}catch{}
    void refresh();
    const t = window.setInterval(() => void refresh(), 3000);
    const on = () => void refresh();
    window.addEventListener('k99-equipment-changed', on);
    return () => { clearInterval(t); window.removeEventListener('k99-equipment-changed', on); };
  }, [refresh]);

  const stopCamera = useCallback(() => {
    camera.stop();
    setCameraOn(false);
    setConnecting(false);
  }, [camera.stop]);
  useEffect(() => () => {stopCamera();}, [stopCamera]);

  const config = state?.config;
  const realMode = !!state?.native && config?.mode === 'real';
  const cameraDevice = activeDeviceId||cameras[0]?.deviceId||'';
  const [phoneHelp,setPhoneHelp]=useState(false);
  const appearance=useManualCamera(videoRef,streamRef,cameraDevice,cameraOn,cameraOn?'Iriun Webcam':cameras.find(d=>d.deviceId===cameraDevice)?.label);
  const colorPreview=useCameraColorPreview(videoRef,cameraOn,appearance.profile);
  const [cameraError, setCameraError] = useState('');
  // A legacy stored device ID never interrupts Iriun-only reception.
  useEffect(() => {stopCamera();},
    [config?.mode, stopCamera]);

  const order = state?.orders.find(o => o.id === orderId) ?? null;
  const garment = order?.garments.find(g => g.garmentId === garmentId) ?? null;
  useEffect(() => { setLastShot(''); }, [orderId, garmentId, role]);

  const garmentRolePhotos = useMemo(() => (state?.photos ?? []).filter(p => p.orderId === orderId && p.garmentId === garmentId && p.role === role), [state, orderId, garmentId, role]);
  const photos = useMemo(() => (state?.photos ?? []).filter(p => p.orderId === orderId && (!garmentId || p.garmentId === garmentId)), [state, orderId, garmentId]);
  const jobs = useMemo(() => (state?.jobs ?? []).filter(j => !orderId || j.orderId === orderId)
    .slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)), [state, orderId]);

  async function run<T>(label: string, fn: () => Promise<T>, ok?: (r: T) => string) {
    setBusy(label); setMessage(null);
    try { const r = await fn(); if (ok) setMessage({ kind: 'ok', text: ok(r) }); await refresh(); return r; }
    catch (c) { setMessage({ kind: 'error', text: errText(c, `${label} 실패`) }); return undefined; }
    finally { setBusy(''); }
  }

  async function listCameras() {
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      setCameras(iriunDevices(all));
    } catch (c) { setMessage({ kind: 'error', text: errText(c, '카메라 목록을 읽지 못했습니다.') }); }
  }
  async function authorizeCamera() {
    if(!realMode)return;
    await startCamera();
  }
  async function startCamera(requestedDevice = cameraDevice) {
    if (!realMode) return;
    setCameraError('');
    await camera.start();
  }
  function grabFrame(): string {
    if (!order || !garment) throw new Error('의류를 먼저 선택하세요.');
    if (realMode) {
      const v = videoRef.current;
      if (!cameraOn || !v || !v.videoWidth) throw new Error('카메라 영상이 준비되지 않았습니다.');
      const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
      const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
      g.drawImage(v, 0, 0);
      correctCameraCanvas(g,appearance.profile);
      return c.toDataURL('image/jpeg', 0.92);
    }
    return mockPng(order, garment.garmentId, garment.itemName, role);
  }
  async function burstCapture() {
    if (!order || !garment || burstBusy.current) return;
    burstBusy.current = true;
    try {
      const image = grabFrame();
      setLastShot(image);
      const n = garmentRolePhotos.length + 1;
      await run('사진 저장', () => equipmentRequest('capture', {
        orderId: order.id, garmentId: garment.garmentId, role, photo_type: role === 'intake' ? 'intake' : 'compare',
        requestId: crypto.randomUUID(), imageDataUrl: image,
        expectedMode: realMode ? 'real' : 'mock',
      }), () => n === 1 && role === 'intake'
        ? '1번째 사진 저장 · 이 의류의 태그는 첫 사진에서만 1회 자동 발행됩니다.'
        : `${n}번째 사진 저장 · 태그 추가 발행 없음`);
    } catch (c) { setMessage({ kind: 'error', text: errText(c, '촬영 실패') }); }
    finally { burstBusy.current = false; }
  }
  const burstRef = useRef(burstCapture);
  burstRef.current = burstCapture;
  const footKey = config?.footSwitchKey ?? DEFAULT_FOOT_SWITCH_KEY;
  const footReady = realMode && !phoneHelp && cameraOn && !!garment;
  const footError = useFootCapture(footReady, footKey, () => void burstRef.current());
  function capture() {
    if (!order || !garment) return;
    void burstCapture();
  }
  async function reprint() {
    if (!order || !garment || !reprintReason.trim()) return;
    const r = await run('재출력 요청', () => equipmentRequest('reprint', {
      orderId: order.id, garmentId: garment.garmentId, requestId: crypto.randomUUID(), reason: reprintReason.trim(),
    }), () => '재출력 작업을 등록했습니다. 아래 상태에서 결과를 확인하세요.');
    if (r) setReprintReason('');
  }
  async function scan(e: FormEvent) {
    e.preventDefault();
    const code = barcode.trim(); setBarcode('');
    if (!code) return;
    const r = await run('스캔', () => equipmentRequest<ScanResult>('scan', { barcode: code, source: scanSource, requestId: crypto.randomUUID() }));
    if (!r) return;
    setScanResult(r);
    if (r.found && r.order) { setOrderId(r.order.id); setGarmentId(r.garmentId ?? ''); }
  }
  async function saveConfig() {
    if (!draft) return;
    const next: EquipmentConfig = draft.mode === 'real' ? draft : { ...draft, hardwareConfirmed: false, labelVerified: false };
    const r = await run('설정 저장', () => equipmentRequest('configure', { config: next }), () => '설정을 저장했습니다. 서버가 다시 검증한 상태가 아래에 표시됩니다.');
    if (r) { try { const s = await getEquipmentState(); setDraft(s.config); } catch { /* shown by poll */ } }
  }

  const realBlocked = !!draft && draft.mode === 'real' && (!state?.native || !draft.hardwareConfirmed || !draft.labelVerified ||
    !state.printers.some(p => p.name === draft.printerName) || !(draft.labelWidthMm > 0) || !(draft.labelHeightMm > 0));
  const liveMonitor = state?.monitors.find(m => m.id === displayId);

  return (
    <main className="eqw" data-testid="page-equipment">
      <span className="eyebrow">K99 Windows · 2단계</span>
      <h1>장비 연동 작업대</h1>
      <p className="eqw__lead">사진 촬영, 태그 출력, 바코드 스캔, 고객 모니터를 저장된 주문 기준으로만 처리합니다. 접수 화면과 업무 규칙은 바뀌지 않습니다.</p>
      <div className="eq-row" style={{ marginBottom: 12 }}>
        {!state ? <span className="eq-pill">상태 확인 중</span> : <>
          <span className={`eq-pill ${state.native ? 'is-ok' : 'is-warn'}`} data-testid="status-equipment-native">{state.native ? 'Windows 데스크톱 실행' : '브라우저 미리보기 (실장비 불가)'}</span>
          <span className={`eq-pill ${state.config.mode === 'real' ? 'is-ok' : 'is-mock'}`} data-testid="status-equipment-mode">{state.config.mode === 'real' ? '실장비 모드' : '모의 모드'}</span>
          <span className={`eq-pill ${state.config.hardwareConfirmed && state.config.labelVerified ? 'is-ok' : 'is-warn'}`}>
            {state.config.hardwareConfirmed && state.config.labelVerified ? '직원이 장비·라벨 확인함' : '하드웨어 확인 안 됨'}</span>
        </>}
        {busy && <span className="eq-pill is-warn">{busy} 중</span>}
      </div>
      {loadError && <div className="eq-error" role="alert" data-testid="text-equipment-error">{loadError} <button type="button" className="eq-btn" onClick={() => void refresh()}>다시 시도</button></div>}
      {message && <div className={message.kind === 'error' ? 'eq-error' : 'eq-msg'} role={message.kind === 'error' ? 'alert' : 'status'} data-testid="text-equipment-message">{message.text}</div>}

      <div className="eqw__grid">
        <div className="eqw__col">
          <section className="eq-card">
            <h2>바코드 스캔</h2>
            <form onSubmit={scan} className="eq-row">
              <input className="eq-input" style={{ flex: 1 }} value={barcode} onChange={e => setBarcode(e.target.value)} placeholder="스캐너로 읽거나 직접 입력 후 Enter"
                autoComplete="off" data-testid="input-equipment-barcode" />
              <select className="eq-input" value={scanSource} onChange={e => setScanSource(e.target.value as ScanSource)} data-testid="select-scan-source">
                <option value="usb-keyboard">USB 스캐너</option><option value="manual">직접 입력</option><option value="mock">모의</option>
              </select>
              <button className="eq-btn is-primary" type="submit" disabled={!!busy} data-testid="button-equipment-scan">조회</button>
            </form>
            <p style={{ color: 'hsl(var(--muted-foreground))' }}>모르는 태그는 주문을 만들거나 작업 상태를 바꾸지 않습니다.</p>
            {scanResult && <div className={scanResult.found ? 'eq-msg' : 'eq-error'} data-testid="text-scan-result">{scanResult.message}</div>}
          </section>

          <section className="eq-card">
            <h2>저장된 주문 <span className="eq-pill">{state?.orders.length ?? 0}건</span></h2>
            {!state ? <><div className="eq-skel" /><div className="eq-skel short" /></>
              : state.orders.length === 0 ? <div className="eq-empty" data-testid="empty-equipment-orders">저장된 주문이 없습니다. 접수 화면에서 주문을 확정하면 여기에 표시됩니다.</div>
              : <div className="eq-list">{state.orders.map(o => (
                  <button key={o.id} type="button" aria-pressed={o.id === orderId} onClick={() => { setOrderId(o.id); setGarmentId(''); }} data-testid={`button-equipment-order-${o.id}`}>
                    <span><b>{o.customerName || '이름 없음'}</b><br /><small>{o.id}</small></span>
                    <span>{o.garments.length}점 · {won(o.estimatedTotal)}</span>
                  </button>))}</div>}
            {order && <>
              <h2 style={{ marginTop: 16 }}>의류 선택</h2>
              <div className="eq-list">{order.garments.map(g => (
                <button key={g.garmentId} type="button" aria-pressed={g.garmentId === garmentId} onClick={() => setGarmentId(g.garmentId)} data-testid={`button-equipment-garment-${g.garmentId}`}>
                  <span><b>{g.itemName}</b> · {g.serviceType}<br /><small>{g.garmentId}</small></span><small>{g.barcodeValue}</small>
                </button>))}</div>
              <button type="button" className="eq-btn is-accent" style={{ marginTop: 12, width: '100%' }} disabled={!!busy}
                onClick={() => void run('고객 화면 표시', () => equipmentRequest('publish', { orderId: order.id }), () => '고객 화면에 이 주문을 표시했습니다.')}
                data-testid="button-equipment-publish">고객 화면에 이 주문 표시</button>
            </>}
          </section>

          <section className="eq-card">
            <h2>고객 모니터</h2>
            <p>{state?.display.connected ? `열림${state.display.displayId ? ` · ${state.display.displayId}` : ''}` : '닫힘'}{state?.display.note ? ` · ${state.display.note}` : ''}</p>
            <p>고객 화면 열기는 접수 화면에서, 모니터 배치와 장치 선택은 매장 맞춤 설정에서 관리합니다.</p>
          </section>
        </div>

        <div className="eqw__col">
          <section className="eq-card">
            <h2>사진 촬영 <span className={`eq-pill ${realMode ? 'is-ok' : 'is-mock'}`}>{realMode ? '실카메라' : '모의 촬영'}</span></h2>
            {!garment ? <div className="eq-empty">주문과 의류를 먼저 선택하세요.</div> : <>
              <div className="eq-row" style={{ marginBottom: 10 }}>
                {(['intake', 'completion'] as Role[]).map(r => (
                  <button key={r} type="button" className={`eq-btn ${role === r ? 'is-primary' : ''}`} onClick={() => setRole(r)} data-testid={`button-role-${r}`}>
                    {r === 'intake' ? '접수 사진' : '완성 사진'}</button>))}
                <button type="button" className="eq-btn is-primary" style={{fontSize:22,minHeight:54}}
                  onClick={()=>setPhoneHelp(true)}>📱 구형 스마트폰 카메라 연결하기</button>
                {phoneHelp&&<SmartphoneCameraHelp onClose={()=>setPhoneHelp(false)} onAction={cameraConnectionAction}/>}
                {realMode && <>
                  <button type="button" className="eq-btn" onClick={() => {if(cameraOn){stopCamera();}else void startCamera();}} data-testid="button-camera-toggle">{cameraOn ? '카메라 끄기' : '카메라 켜기'}</button>
                </>}
                <button type="button" className="eq-btn is-accent" onClick={capture} disabled={realMode && !cameraOn} data-testid="button-capture">촬영</button>
              </div>
              <div className="eq-row" style={{ marginBottom: 10 }}>
                <span className="eq-pill is-ok" data-testid="text-garment-shot-count">{role === 'intake' ? '접수' : '완성'} 사진 {garmentRolePhotos.length}컷</span>
                {footReady ? <span className="eq-pill is-ok" data-testid="status-foot-switch">풋 스위치 {footKey} 대기 중</span>
                  : realMode && <span className="eq-pill">풋 스위치: 카메라를 켜면 활성</span>}
              </div>
              <div className="eq-stage">
                {realMode && <><video ref={videoRef} muted playsInline/>
                  <canvas ref={colorPreview.canvas} style={{position:'absolute',width:'100%',height:'100%',objectFit:'cover',
                    visibility:cameraOn&&colorPreview.ready&&!colorPreview.error?'visible':'hidden',pointerEvents:'none'}}
                    aria-label="수동 화질 보정된 장비 카메라 미리보기"/></>}
                {appearance.freeze&&<img src={appearance.freeze} alt="" aria-hidden="true"
                  style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover',pointerEvents:'none'}}/>}
                {lastShot && <img src={lastShot} alt="마지막 촬영" data-testid="img-last-shot"
                  style={{ position: 'absolute', right: 8, bottom: 8, width: '24%', height: 'auto', border: '2px solid hsl(var(--card))', borderRadius: 6 }} />}
                {cameraError && realMode ? <div role="alert" style={{position:'absolute',inset:0,display:'grid',placeContent:'center',padding:28,background:'#0f172a',color:'#fee2e2',fontSize:20,fontWeight:800,textAlign:'center',zIndex:2}}>{cameraError}</div> :
                  !cameraOn && realMode && <span>카메라 켜기를 눌러야 영상이 시작됩니다.</span>}
              </div>
              {realMode&&<>{appearance.passthrough?<p role="status">휴대폰 원본 화질 모드 · PC 색감·노출 보정 없이 촬영·확대·저장합니다.</p>:<CameraColorSliders {...appearance}/>}
                {colorPreview.error&&<p role="status">{colorPreview.error}</p>}</>}
            </>}
            {order && <>
              <h2 style={{ marginTop: 16 }}>저장된 사진 <span className="eq-pill">{photos.length}장</span></h2>
              {photos.length === 0 ? <div className="eq-empty">저장된 사진이 없습니다.</div> :
                <div className="eq-photos">{photos.map(p => (
                  <figure key={p.id} data-testid={`img-saved-photo-${p.id}`}>
                    <img src={p.url} alt={`${p.garmentId} ${p.role}`} loading="lazy" />
                    <figcaption><span className={`eq-pill ${p.mode === 'real' ? 'is-ok' : 'is-mock'}`}>{p.mode === 'real' ? '실촬영' : '모의'}</span>
                      <span>{p.role === 'intake' ? '접수' : '완성'}</span><span>{new Date(p.createdAt).toLocaleString('ko-KR')}</span>
                      <span className="eq-mono" title={p.sha256}>{p.sha256.slice(0, 10)}</span></figcaption>
                  </figure>))}</div>}
            </>}
          </section>

          <section className="eq-card">
            <h2>태그 출력 작업</h2>
            <p style={{ color: 'hsl(var(--muted-foreground))' }}>자동 태그는 사진 저장 후 서버가 의류당 1회만 예약합니다. "모의 처리"는 실제 출력이 아니며, "스풀러 접수됨"은 Windows 인쇄 대기열 수락일 뿐 실제 인쇄 완료가 아닙니다.</p>
            {garment && <div className="eq-row" style={{ marginBottom: 10 }}>
              <input className="eq-input" style={{ flex: 1 }} value={reprintReason} onChange={e => setReprintReason(e.target.value)} maxLength={200}
                placeholder="재출력 사유 (필수)" data-testid="input-reprint-reason" />
              <button type="button" className="eq-btn is-primary" disabled={!reprintReason.trim() || !!busy} onClick={() => void reprint()} data-testid="button-reprint">수동 재출력</button>
            </div>}
            {jobs.length === 0 ? <div className="eq-empty">출력 작업이 없습니다.</div> :
              <div style={{ overflowX: 'auto' }}><table className="eq-table"><thead><tr><th>시각</th><th>의류</th><th>종류</th><th>상태</th><th>프린터/사유</th></tr></thead>
                <tbody>{jobs.map(j => (
                  <tr key={j.id} data-testid={`row-job-${j.id}`}>
                    <td>{new Date(j.createdAt).toLocaleString('ko-KR')}</td>
                    <td>{j.payload.itemName}<br /><span className="eq-mono">{j.garmentId}</span></td>
                    <td>{j.kind === 'auto' ? '자동' : '재출력'} · {j.mode === 'real' ? '실장비' : '모의'}</td>
                    <td><span className={`eq-pill ${JOB_LABEL[j.status].cls}`}>{JOB_LABEL[j.status].text}</span>{j.error && <div style={{ color: 'hsl(var(--destructive))' }}>{j.error}</div>}</td>
                    <td>{j.printerName || '-'}{j.reason && <><br />{j.reason}</>}</td>
                  </tr>))}</tbody></table></div>}
          </section>

          <section className="eq-card">
            <h2>매장 장치 설정</h2>
            <p>프린터·영수증 출력기·촬영 카메라·모니터 배치는 매장 맞춤 설정 한곳에서 변경합니다.</p>
            <button type="button" className="eq-btn" onClick={()=>window.dispatchEvent(new Event('k99-open-store-settings'))}>매장 맞춤 설정 열기</button>
          </section>
        </div>
      </div>
      {footError && <p className="eq-error" role="alert">{footError}</p>}
    </main>
  );
}

export default EquipmentWorkspace;
