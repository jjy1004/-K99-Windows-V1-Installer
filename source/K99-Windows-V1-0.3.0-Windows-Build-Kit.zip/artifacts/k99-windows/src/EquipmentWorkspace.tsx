import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import {
  DEFAULT_FOOT_SWITCH_KEY, DEFAULT_PHOTO_ARCHIVE_ROOT,
  equipmentRequest, getEquipmentState,
  type EquipmentConfig, type EquipmentJob, type EquipmentOrder, type EquipmentState,
} from './equipment-client';
import './equipment.css';
import { fullHdCameraConstraints, useFootCapture, FOOT_SWITCH_KEYS } from './camera-capture-controls';
import type { FootSwitchKey } from './desktop-runtime';
import { CustomerImportPanel } from './CustomerDirectory';

type Role = 'intake' | 'completion';
type ScanSource = 'usb-keyboard' | 'manual' | 'mock';
type ScanResult = { found: boolean; order?: EquipmentOrder; garmentId?: string; message: string };

const JOB_LABEL: Record<EquipmentJob['status'], { text: string; cls: string }> = {
  pending: { text: '대기', cls: '' },
  submitting: { text: '전송 중', cls: 'is-warn' },
  simulated: { text: '모의 처리 (실제 출력 아님)', cls: 'is-mock' },
  submitted: { text: '스풀러 접수됨 (물리 출력 미확인)', cls: 'is-ok' },
  failed: { text: '실패', cls: 'is-bad' },
  unknown: { text: '결과 불명 · 확인 필요', cls: 'is-bad' },
};
const won = (n: number) => `${n.toLocaleString('ko-KR')}원`;
const errText = (c: unknown, f: string) => (c instanceof Error && c.message ? c.message : f);

function mockPng(order: EquipmentOrder, garmentId: string, itemName: string, role: Role) {
  const c = document.createElement('canvas');
  c.width = 960; c.height = 720;
  const g = c.getContext('2d');
  if (!g) throw new Error('캔버스를 만들 수 없습니다.');
  g.fillStyle = '#e9e4d6'; g.fillRect(0, 0, 960, 720);
  g.fillStyle = '#2f6f68'; g.fillRect(330, 170, 300, 380);
  g.fillStyle = '#21323d'; g.font = 'bold 30px sans-serif';
  g.fillText(`${itemName} · ${role === 'intake' ? '접수' : '완성'}`, 40, 70);
  g.font = '22px monospace';
  g.fillText(`주문 ${order.id}`, 40, 620); g.fillText(`의류 ${garmentId}`, 40, 655);
  g.fillText(new Date().toLocaleString('ko-KR'), 40, 690);
  g.save(); g.translate(480, 360); g.rotate(-0.4);
  g.fillStyle = 'rgba(176,52,40,.55)'; g.font = 'bold 120px sans-serif'; g.textAlign = 'center';
  g.fillText('모의 촬영', 0, 40); g.restore();
  g.strokeStyle = 'rgba(176,52,40,.8)'; g.lineWidth = 10; g.strokeRect(5, 5, 950, 710);
  return c.toDataURL('image/png');
}

export function EquipmentWorkspace() {
  const [state, setState] = useState<EquipmentState | null>(null);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState('');
  const [orderId, setOrderId] = useState(()=>new URLSearchParams(window.location.search).get('orderId')||'');
  const [garmentId, setGarmentId] = useState(()=>new URLSearchParams(window.location.search).get('garmentId')||'');
  const [role, setRole] = useState<Role>('intake');
  // Every shot is saved immediately while the live preview stays on. Unlimited shots per garment.
  const [lastShot, setLastShot] = useState('');
  const burstBusy = useRef(false);
  const [reprintReason, setReprintReason] = useState('');
  const [barcode, setBarcode] = useState('');
  const [scanSource, setScanSource] = useState<ScanSource>('usb-keyboard');
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [draft, setDraft] = useState<EquipmentConfig | null>(null);
  const [displayId, setDisplayId] = useState(()=>localStorage.getItem('k99-customer-display-id')||'');
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [cameraOn, setCameraOn] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const cameraRun = useRef(0);
  const refreshRun = useRef(0);

  const refresh = useCallback(async () => {
    const run=++refreshRun.current;
    try {
      const next = await getEquipmentState();
      if(run!==refreshRun.current)return;
      setState(next); setLoadError('');
      setDisplayId(old=>next.monitors.some(m=>m.id===old)?old:next.display.displayId||'');
      setDraft(old => old ?? next.config);
    } catch (c) { setLoadError(errText(c, '장비 상태를 읽지 못했습니다.')); }
  }, []);

  useEffect(() => {
    void refresh();
    const t = window.setInterval(() => void refresh(), 3000);
    const on = () => void refresh();
    window.addEventListener('k99-equipment-changed', on);
    return () => { clearInterval(t); window.removeEventListener('k99-equipment-changed', on); };
  }, [refresh]);

  const stopCamera = useCallback(() => {
    cameraRun.current++;
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false);
  }, []);
  useEffect(() => stopCamera, [stopCamera]);

  const config = state?.config;
  const realMode = !!state?.native && config?.mode === 'real';
  const cameraDevice = draft?.cameraDeviceId ?? '';
  // Config change (mode or device) stops any live stream.
  useEffect(() => { stopCamera(); },
    [config?.mode, config?.cameraDeviceId, cameraDevice, stopCamera]);

  const order = state?.orders.find(o => o.id === orderId) ?? null;
  const garment = order?.garments.find(g => g.garmentId === garmentId) ?? null;
  useEffect(() => { setLastShot(''); }, [orderId, garmentId, role]);

  const garmentRolePhotos = useMemo(() => (state?.photos ?? []).filter(p => p.orderId === orderId && p.garmentId === garmentId && p.role === role), [state, orderId, garmentId, role]);
  const photos = useMemo(() => (state?.photos ?? []).filter(p => p.orderId === orderId && (!garmentId || p.garmentId === garmentId)), [state, orderId, garmentId]);
  const jobs = useMemo(() => (state?.jobs ?? []).filter(j => !orderId || j.orderId === orderId)
    .slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)), [state, orderId]);

  async function run<T>(label: string, fn: () => Promise<T>, ok?: (r: T) => string) {
    setBusy(label); setMessage(null);
    try { const r = await fn(); if (ok) setMessage({ kind: 'ok', text: ok(r) }); await refresh(); return r; }
    catch (c) { setMessage({ kind: 'error', text: errText(c, `${label} 실패`) }); return undefined; }
    finally { setBusy(''); }
  }

  async function listCameras() {
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      setCameras(all.filter(d => d.kind === 'videoinput'));
    } catch (c) { setMessage({ kind: 'error', text: errText(c, '카메라 목록을 읽지 못했습니다.') }); }
  }
  async function authorizeCamera() {
    if(!realMode)return;
    let stream:MediaStream|undefined;
    try {
      // Permission is requested only by this explicit button. The transient
      // default stream is NOT captured/saved; staff must select an exact device.
      stream=await navigator.mediaDevices.getUserMedia(fullHdCameraConstraints());
      await listCameras();
      setMessage({kind:'ok',text:'카메라 권한 확인 완료. 정확한 장치를 선택하고 설정을 저장한 뒤 촬영하세요.'});
    }catch(c){setMessage({kind:'error',text:errText(c,'카메라 권한을 확인하지 못했습니다.')});}
    finally{stream?.getTracks().forEach(t=>t.stop());}
  }
  async function startCamera() {
    if (!realMode) return;
    if (!cameraDevice) { setMessage({ kind: 'error', text: '카메라 장치를 먼저 선택해 저장하세요.' }); return; }
    stopCamera();
    const run=cameraRun.current;
    try {
      const s = await navigator.mediaDevices.getUserMedia(fullHdCameraConstraints(cameraDevice));
      if(run!==cameraRun.current){s.getTracks().forEach(t=>t.stop());return;}
      streamRef.current = s;
      if (videoRef.current) { videoRef.current.srcObject = s; await videoRef.current.play(); }
      setCameraOn(true); void listCameras();
    } catch (c) { setMessage({ kind: 'error', text: errText(c, '카메라를 시작하지 못했습니다.') }); stopCamera(); }
  }
  function grabFrame(): string {
    if (!order || !garment) throw new Error('의류를 먼저 선택하세요.');
    if (realMode) {
      const v = videoRef.current;
      if (!cameraOn || !v || !v.videoWidth) throw new Error('카메라 영상이 준비되지 않았습니다.');
      const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
      const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
      g.drawImage(v, 0, 0); return c.toDataURL('image/jpeg', 0.92);
    }
    return mockPng(order, garment.garmentId, garment.itemName, role);
  }
  async function burstCapture() {
    if (!order || !garment || burstBusy.current) return;
    burstBusy.current = true;
    try {
      const image = grabFrame();
      setLastShot(image);
      const n = garmentRolePhotos.length + 1;
      await run('사진 저장', () => equipmentRequest('capture', {
        orderId: order.id, garmentId: garment.garmentId, role, photo_type: role === 'intake' ? 'intake' : 'compare',
        requestId: crypto.randomUUID(), imageDataUrl: image,
        expectedMode: realMode ? 'real' : 'mock',
      }), () => n === 1 && role === 'intake'
        ? '1번째 사진 저장 · 이 의류의 태그는 첫 사진에서만 1회 자동 발행됩니다.'
        : `${n}번째 사진 저장 · 태그 추가 발행 없음`);
    } catch (c) { setMessage({ kind: 'error', text: errText(c, '촬영 실패') }); }
    finally { burstBusy.current = false; }
  }
  const burstRef = useRef(burstCapture);
  burstRef.current = burstCapture;
  const footKey = config?.footSwitchKey ?? DEFAULT_FOOT_SWITCH_KEY;
  const footReady = realMode && cameraOn && !!garment;
  const footError = useFootCapture(footReady, footKey, () => void burstRef.current());
  function capture() {
    if (!order || !garment) return;
    void burstCapture();
  }
  async function reprint() {
    if (!order || !garment || !reprintReason.trim()) return;
    const r = await run('재출력 요청', () => equipmentRequest('reprint', {
      orderId: order.id, garmentId: garment.garmentId, requestId: crypto.randomUUID(), reason: reprintReason.trim(),
    }), () => '재출력 작업을 등록했습니다. 아래 상태에서 결과를 확인하세요.');
    if (r) setReprintReason('');
  }
  async function scan(e: FormEvent) {
    e.preventDefault();
    const code = barcode.trim(); setBarcode('');
    if (!code) return;
    const r = await run('스캔', () => equipmentRequest<ScanResult>('scan', { barcode: code, source: scanSource, requestId: crypto.randomUUID() }));
    if (!r) return;
    setScanResult(r);
    if (r.found && r.order) { setOrderId(r.order.id); setGarmentId(r.garmentId ?? ''); }
  }
  async function saveConfig() {
    if (!draft) return;
    const next: EquipmentConfig = draft.mode === 'real' ? draft : { ...draft, hardwareConfirmed: false, labelVerified: false };
    const r = await run('설정 저장', () => equipmentRequest('configure', { config: next }), () => '설정을 저장했습니다. 서버가 다시 검증한 상태가 아래에 표시됩니다.');
    if (r) { try { const s = await getEquipmentState(); setDraft(s.config); } catch { /* shown by poll */ } }
  }

  const realBlocked = !!draft && draft.mode === 'real' && (!state?.native || !draft.hardwareConfirmed || !draft.labelVerified ||
    !state.printers.some(p => p.name === draft.printerName) || !(draft.labelWidthMm > 0) || !(draft.labelHeightMm > 0));
  const liveMonitor = state?.monitors.find(m => m.id === displayId);

  return (
    <main className="eqw" data-testid="page-equipment">
      <span className="eyebrow">K99 Windows · 2단계</span>
      <h1>장비 연동 작업대</h1>
      <p className="eqw__lead">사진 촬영, 태그 출력, 바코드 스캔, 고객 모니터를 저장된 주문 기준으로만 처리합니다. 접수 화면과 업무 규칙은 바뀌지 않습니다.</p>
      <div className="eq-row" style={{ marginBottom: 12 }}>
        {!state ? <span className="eq-pill">상태 확인 중</span> : <>
          <span className={`eq-pill ${state.native ? 'is-ok' : 'is-warn'}`} data-testid="status-equipment-native">{state.native ? 'Windows 데스크톱 실행' : '브라우저 미리보기 (실장비 불가)'}</span>
          <span className={`eq-pill ${state.config.mode === 'real' ? 'is-ok' : 'is-mock'}`} data-testid="status-equipment-mode">{state.config.mode === 'real' ? '실장비 모드' : '모의 모드'}</span>
          <span className={`eq-pill ${state.config.hardwareConfirmed && state.config.labelVerified ? 'is-ok' : 'is-warn'}`}>
            {state.config.hardwareConfirmed && state.config.labelVerified ? '직원이 장비·라벨 확인함' : '하드웨어 확인 안 됨'}</span>
        </>}
        {busy && <span className="eq-pill is-warn">{busy} 중</span>}
      </div>
      {loadError && <div className="eq-error" role="alert" data-testid="text-equipment-error">{loadError} <button type="button" className="eq-btn" onClick={() => void refresh()}>다시 시도</button></div>}
      {message && <div className={message.kind === 'error' ? 'eq-error' : 'eq-msg'} role={message.kind === 'error' ? 'alert' : 'status'} data-testid="text-equipment-message">{message.text}</div>}

      <div className="eqw__grid">
        <div className="eqw__col">
          <section className="eq-card">
            <h2>바코드 스캔</h2>
            <form onSubmit={scan} className="eq-row">
              <input className="eq-input" style={{ flex: 1 }} value={barcode} onChange={e => setBarcode(e.target.value)} placeholder="스캐너로 읽거나 직접 입력 후 Enter"
                autoComplete="off" data-testid="input-equipment-barcode" />
              <select className="eq-input" value={scanSource} onChange={e => setScanSource(e.target.value as ScanSource)} data-testid="select-scan-source">
                <option value="usb-keyboard">USB 스캐너</option><option value="manual">직접 입력</option><option value="mock">모의</option>
              </select>
              <button className="eq-btn is-primary" type="submit" disabled={!!busy} data-testid="button-equipment-scan">조회</button>
            </form>
            <p style={{ color: 'hsl(var(--muted-foreground))' }}>모르는 태그는 주문을 만들거나 작업 상태를 바꾸지 않습니다.</p>
            {scanResult && <div className={scanResult.found ? 'eq-msg' : 'eq-error'} data-testid="text-scan-result">{scanResult.message}</div>}
          </section>

          <section className="eq-card">
            <h2>저장된 주문 <span className="eq-pill">{state?.orders.length ?? 0}건</span></h2>
            {!state ? <><div className="eq-skel" /><div className="eq-skel short" /></>
              : state.orders.length === 0 ? <div className="eq-empty" data-testid="empty-equipment-orders">저장된 주문이 없습니다. 접수 화면에서 주문을 확정하면 여기에 표시됩니다.</div>
              : <div className="eq-list">{state.orders.map(o => (
                  <button key={o.id} type="button" aria-pressed={o.id === orderId} onClick={() => { setOrderId(o.id); setGarmentId(''); }} data-testid={`button-equipment-order-${o.id}`}>
                    <span><b>{o.customerName || '이름 없음'}</b><br /><small>{o.id}</small></span>
                    <span>{o.garments.length}점 · {won(o.estimatedTotal)}</span>
                  </button>))}</div>}
            {order && <>
              <h2 style={{ marginTop: 16 }}>의류 선택</h2>
              <div className="eq-list">{order.garments.map(g => (
                <button key={g.garmentId} type="button" aria-pressed={g.garmentId === garmentId} onClick={() => setGarmentId(g.garmentId)} data-testid={`button-equipment-garment-${g.garmentId}`}>
                  <span><b>{g.itemName}</b> · {g.serviceType}<br /><small>{g.garmentId}</small></span><small>{g.barcodeValue}</small>
                </button>))}</div>
              <button type="button" className="eq-btn is-accent" style={{ marginTop: 12, width: '100%' }} disabled={!!busy}
                onClick={() => void run('고객 화면 표시', () => equipmentRequest('publish', { orderId: order.id }), () => '고객 화면에 이 주문을 표시했습니다.')}
                data-testid="button-equipment-publish">고객 화면에 이 주문 표시</button>
            </>}
          </section>

          <section className="eq-card">
            <h2>고객 모니터</h2>
            <p>{state?.display.connected ? `열림${state.display.displayId ? ` · ${state.display.displayId}` : ''}` : '닫힘'}{state?.display.note ? ` · ${state.display.note}` : ''}</p>
            {state?.native ? <>
              <select className="eq-input" style={{ width: '100%' }} value={displayId} onChange={e => {
                setDisplayId(e.target.value);localStorage.setItem('k99-customer-display-id',e.target.value);
              }} data-testid="select-customer-monitor">
                <option value="">모니터 선택</option>
                {state.monitors.map(m => <option key={m.id} value={m.id}>{m.label}{m.primary ? ' (주 모니터)' : ''}</option>)}
              </select>
              <div className="eq-row" style={{ marginTop: 8 }}>
                <button type="button" className="eq-btn is-primary" disabled={!liveMonitor || !!busy}
                  onClick={() => void run('고객 화면 열기', () => equipmentRequest('open-customer', { displayId }), () => '고객 화면 열기를 요청했습니다.')} data-testid="button-open-customer-monitor">열기</button>
                <button type="button" className="eq-btn" disabled={!!busy}
                  onClick={() => void run('고객 화면 닫기', () => equipmentRequest('close-customer'), () => '고객 화면을 닫았습니다.')} data-testid="button-close-customer-monitor">닫기</button>
              </div>
            </> : <>
              <p style={{ color: 'hsl(var(--muted-foreground))' }}>브라우저에서는 모니터를 감지할 수 없습니다. 미리보기 창만 열 수 있습니다.</p>
              <button type="button" className="eq-btn" onClick={() => {
                const w = window.open(`${import.meta.env.BASE_URL.replace(/\/$/, '')}/equipment/customer`, 'k99-equipment-customer-preview', 'popup,width=1100,height=720');
                setMessage(w ? { kind: 'ok', text: '미리보기 팝업을 열었습니다. 실제 모니터 감지가 아닙니다.' } : { kind: 'error', text: '팝업이 차단되었습니다.' });
              }} data-testid="button-preview-customer">고객 화면 미리보기 팝업</button>
            </>}
          </section>
        </div>

        <div className="eqw__col">
          <section className="eq-card">
            <h2>사진 촬영 <span className={`eq-pill ${realMode ? 'is-ok' : 'is-mock'}`}>{realMode ? '실카메라' : '모의 촬영'}</span></h2>
            {!garment ? <div className="eq-empty">주문과 의류를 먼저 선택하세요.</div> : <>
              <div className="eq-row" style={{ marginBottom: 10 }}>
                {(['intake', 'completion'] as Role[]).map(r => (
                  <button key={r} type="button" className={`eq-btn ${role === r ? 'is-primary' : ''}`} onClick={() => setRole(r)} data-testid={`button-role-${r}`}>
                    {r === 'intake' ? '접수 사진' : '완성 사진'}</button>))}
                {realMode && <>
                  <button type="button" className="eq-btn" onClick={() => void (cameraOn ? stopCamera() : startCamera())} data-testid="button-camera-toggle">{cameraOn ? '카메라 끄기' : '카메라 켜기'}</button>
                </>}
                <button type="button" className="eq-btn is-accent" onClick={capture} disabled={realMode && !cameraOn} data-testid="button-capture">촬영</button>
              </div>
              <div className="eq-row" style={{ marginBottom: 10 }}>
                <span className="eq-pill is-ok" data-testid="text-garment-shot-count">{role === 'intake' ? '접수' : '완성'} 사진 {garmentRolePhotos.length}컷</span>
                {footReady ? <span className="eq-pill is-ok" data-testid="status-foot-switch">풋 스위치 {footKey} 대기 중</span>
                  : realMode && <span className="eq-pill">풋 스위치: 카메라를 켜면 활성</span>}
              </div>
              <div className="eq-stage">
                {realMode && <video ref={videoRef} muted playsInline hidden={!cameraOn} />}
                {lastShot && <img src={lastShot} alt="마지막 촬영" data-testid="img-last-shot"
                  style={{ position: 'absolute', right: 8, bottom: 8, width: '24%', height: 'auto', border: '2px solid hsl(var(--card))', borderRadius: 6 }} />}
                {!cameraOn && realMode && <span>카메라 켜기를 눌러야 영상이 시작됩니다.</span>}
              </div>
            </>}
            {order && <>
              <h2 style={{ marginTop: 16 }}>저장된 사진 <span className="eq-pill">{photos.length}장</span></h2>
              {photos.length === 0 ? <div className="eq-empty">저장된 사진이 없습니다.</div> :
                <div className="eq-photos">{photos.map(p => (
                  <figure key={p.id} data-testid={`img-saved-photo-${p.id}`}>
                    <img src={p.url} alt={`${p.garmentId} ${p.role}`} loading="lazy" />
                    <figcaption><span className={`eq-pill ${p.mode === 'real' ? 'is-ok' : 'is-mock'}`}>{p.mode === 'real' ? '실촬영' : '모의'}</span>
                      <span>{p.role === 'intake' ? '접수' : '완성'}</span><span>{new Date(p.createdAt).toLocaleString('ko-KR')}</span>
                      <span className="eq-mono" title={p.sha256}>{p.sha256.slice(0, 10)}</span></figcaption>
                  </figure>))}</div>}
            </>}
          </section>

          <section className="eq-card">
            <h2>태그 출력 작업</h2>
            <p style={{ color: 'hsl(var(--muted-foreground))' }}>자동 태그는 사진 저장 후 서버가 의류당 1회만 예약합니다. "모의 처리"는 실제 출력이 아니며, "스풀러 접수됨"은 Windows 인쇄 대기열 수락일 뿐 실제 인쇄 완료가 아닙니다.</p>
            {garment && <div className="eq-row" style={{ marginBottom: 10 }}>
              <input className="eq-input" style={{ flex: 1 }} value={reprintReason} onChange={e => setReprintReason(e.target.value)} maxLength={200}
                placeholder="재출력 사유 (필수)" data-testid="input-reprint-reason" />
              <button type="button" className="eq-btn is-primary" disabled={!reprintReason.trim() || !!busy} onClick={() => void reprint()} data-testid="button-reprint">수동 재출력</button>
            </div>}
            {jobs.length === 0 ? <div className="eq-empty">출력 작업이 없습니다.</div> :
              <div style={{ overflowX: 'auto' }}><table className="eq-table"><thead><tr><th>시각</th><th>의류</th><th>종류</th><th>상태</th><th>프린터/사유</th></tr></thead>
                <tbody>{jobs.map(j => (
                  <tr key={j.id} data-testid={`row-job-${j.id}`}>
                    <td>{new Date(j.createdAt).toLocaleString('ko-KR')}</td>
                    <td>{j.payload.itemName}<br /><span className="eq-mono">{j.garmentId}</span></td>
                    <td>{j.kind === 'auto' ? '자동' : '재출력'} · {j.mode === 'real' ? '실장비' : '모의'}</td>
                    <td><span className={`eq-pill ${JOB_LABEL[j.status].cls}`}>{JOB_LABEL[j.status].text}</span>{j.error && <div style={{ color: 'hsl(var(--destructive))' }}>{j.error}</div>}</td>
                    <td>{j.printerName || '-'}{j.reason && <><br />{j.reason}</>}</td>
                  </tr>))}</tbody></table></div>}
          </section>

          <section className="eq-card">
            <h2>장비 설정</h2>
            {!draft ? <div className="eq-skel" /> : <div style={{ display: 'grid', gap: 10 }}>
              <label className="eq-field">모드
                <select value={draft.mode} onChange={e => setDraft({ ...draft, mode: e.target.value as EquipmentConfig['mode'] })} data-testid="select-equipment-mode">
                  <option value="mock">모의 (기본)</option><option value="real" disabled={!state?.native}>실장비 {state?.native ? '' : '(데스크톱 전용)'}</option>
                </select></label>
              {draft.mode === 'real' && <>
                <label className="eq-field">설치된 프린터
                  <select value={draft.printerName} onChange={e => setDraft({ ...draft, printerName: e.target.value })} data-testid="select-printer">
                    <option value="">선택</option>{(state?.printers ?? []).map(p => <option key={p.name} value={p.name}>{p.displayName}</option>)}
                  </select></label>
                {state?.printers.length === 0 && <p className="eq-error">감지된 프린터가 없습니다.</p>}
                <div className="eq-row">
                  <label className="eq-field">라벨 폭(mm)<input type="number" min={1} value={draft.labelWidthMm} onChange={e => setDraft({ ...draft, labelWidthMm: Number(e.target.value) })} data-testid="input-label-width" /></label>
                  <label className="eq-field">라벨 높이(mm)<input type="number" min={1} value={draft.labelHeightMm} onChange={e => setDraft({ ...draft, labelHeightMm: Number(e.target.value) })} data-testid="input-label-height" /></label>
                </div>
                <p style={{ color: 'hsl(var(--muted-foreground))' }}>기본 라벨 크기는 실측 확인 전 값입니다. 실제 라벨을 재고 수정하세요.</p>
                <label className="eq-field">카메라
                  <button type="button" className="eq-btn" disabled={!realMode||cameraOn||!!busy}
                    onClick={()=>void authorizeCamera()} data-testid="button-authorize-camera">
                    카메라 권한·목록 확인
                  </button>
                  <small>처음에는 실제 장비 모드를 저장한 후 권한을 확인하고, 정확한 카메라를 선택해 다시 저장하세요.</small>
                  <select value={draft.cameraDeviceId} onFocus={() => void listCameras()} onChange={e => setDraft({ ...draft, cameraDeviceId: e.target.value })} data-testid="select-camera">
                    <option value="">선택</option>{cameras.map((c, i) => <option key={c.deviceId || i} value={c.deviceId}>{c.label || `카메라 ${i + 1}`}</option>)}
                    {draft.cameraDeviceId && !cameras.some(c => c.deviceId === draft.cameraDeviceId) && <option value={draft.cameraDeviceId}>저장된 장치</option>}
                  </select></label>
                <label className="eq-check"><input type="checkbox" checked={draft.hardwareConfirmed} onChange={e => setDraft({ ...draft, hardwareConfirmed: e.target.checked })} data-testid="checkbox-hardware-confirmed" />직원이 프린터·카메라·스캐너 실물을 직접 연결·확인했습니다.</label>
                <label className="eq-check"><input type="checkbox" checked={draft.labelVerified} onChange={e => setDraft({ ...draft, labelVerified: e.target.checked })} data-testid="checkbox-label-verified" />라벨 용지 크기를 실측해 확인했습니다.</label>
                <label className="eq-field">사진 보관 폴더(기본 {DEFAULT_PHOTO_ARCHIVE_ROOT})
                  <input value={DEFAULT_PHOTO_ARCHIVE_ROOT} readOnly data-testid="input-photo-archive-root" /></label>
                <label className="eq-field">풋 스위치 촬영 키
                  <select value={draft.footSwitchKey ?? DEFAULT_FOOT_SWITCH_KEY} onChange={e => setDraft({ ...draft, footSwitchKey: e.target.value as FootSwitchKey })} data-testid="select-foot-switch-key">
                    {FOOT_SWITCH_KEYS.map(key => <option key={key} value={key}>{key}</option>)}
                  </select></label>
                <p className="eq-error">촬영 준비 중에는 선택한 키가 입력창에서도 촬영 전용으로 동작합니다. Enter·Space·알파벳 선택 시 일반 입력과 충돌할 수 있습니다.</p>
                {realBlocked && <p className="eq-error">실장비 모드는 데스크톱 실행, 설치된 프린터 선택, 라벨 크기, 두 확인 항목이 모두 필요합니다.</p>}
              </>}
              <div className="eq-row">
                <button type="button" className="eq-btn is-primary" disabled={!!busy || realBlocked} onClick={() => void saveConfig()} data-testid="button-save-config">설정 저장</button>
                <button type="button" className="eq-btn" onClick={() => state && setDraft(state.config)} data-testid="button-reset-config">저장값으로 되돌리기</button>
              </div>
            </div>}
          </section>
        </div>
      </div>
      {footError && <p className="eq-error" role="alert">{footError}</p>}
      <CustomerImportPanel />
    </main>
  );
}

export default EquipmentWorkspace;
