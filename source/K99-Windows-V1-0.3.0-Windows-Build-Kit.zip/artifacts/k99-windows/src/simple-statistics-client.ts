import { directoryRequest } from './customer-directory-client';
export type StatisticsMode = 'day' | 'month' | 'year';
export type StatisticsRow = {
  period: string; orderCount: number; itemCount: number; totalAmount: number;
  datetime?: string; customerName?: string; customerPhone?: string;
};
export type SimpleStatistics = {
  mode: StatisticsMode; period: string;
  summary: { orderCount: number; itemCount: number; totalAmount: number };
  rows: StatisticsRow[];
};
export const fetchSimpleStatistics = (mode: StatisticsMode, period: string) =>
  directoryRequest<SimpleStatistics>('GET', `/api/customers/statistics?mode=${mode}&period=${encodeURIComponent(period)}`);
