import { useEffect, useMemo, useRef, useState } from 'react';
import { FolderOpen, Images, Search, ClipboardList, X } from 'lucide-react';
import { orderDisplayStatus } from './handover-display';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import { garmentProcessStatus } from './laundry-process';
import { openPhotoFolder, type PhotoFolderKind } from './equipment-client';
import { BeforeAfterComposer } from './BeforeAfterComposer';
import './saved-order-lookup.css';
import { ImeTextInput } from './ImeTextInput';

const won = (v: number) => `${v.toLocaleString('ko-KR')}원`;
const digits = (v: string) => v.replace(/\D/g, '');

/** Order id, garment barcode/id, customer name, or the last 4 phone digits. */
export function searchSavedOrders(orders: readonly ConfirmedOrder[], raw: string): ConfirmedOrder[] {
  const q = raw.trim();
  if (!q) return [];
  const qd = digits(q);
  const lower = q.toLowerCase();
  return orders.filter((o) => {
    if (o.id === q || o.id.toLowerCase() === lower) return true;
    if (o.garments?.some((g) => g.barcodeValue === q || g.garmentId === q)) return true;
    if (/^\d{4}$/.test(q) && digits(o.customerPhone).endsWith(qd)) return true;
    if (qd.length >= 7 && qd === q.replace(/[-\s]/g, '') && digits(o.customerPhone).includes(qd)) return true;
    return !/^\d+$/.test(q) && q.length >= 1 && o.customerName.includes(q);
  }).sort((a, b) => b.intakeAt.localeCompare(a.intakeAt));
}

export function garmentStageCounts(order: ConfirmedOrder) {
  const counts = { waiting: 0, progress: 0, ready: 0, handedOver: 0 };
  for (const g of order.garments ?? []) {
    const s = garmentProcessStatus(order, g);
    if (s === '반출 완료') counts.handedOver++;
    else if (s === '출고 대기') counts.ready++;
    else if (s === '접수 완료' || s === '촬영/태그 완료' || s === '전문검수 완료' || s === '세탁 대기') counts.waiting++;
    else counts.progress++;
  }
  return counts;
}

function FolderButtons({ order, onStatus }: { order: ConfirmedOrder; onStatus: (t: { kind: 'ok' | 'error'; text: string }) => void }) {
  async function open(kind: PhotoFolderKind) {
    try {
      const r = await openPhotoFolder(order.id, kind);
      onStatus({ kind: 'ok', text: `탐색기에서 열었습니다 · ${r.folder}` });
    } catch (c) { onStatus({ kind: 'error', text: c instanceof Error ? c.message : '폴더를 열지 못했습니다.' }); }
  }
  return <>
    <button type="button" className="sol-icon" onClick={() => void open('intake')} data-testid={`button-open-intake-folder-${order.id}`}>
      <FolderOpen aria-hidden="true" />세탁 접수 사진 폴더</button>
    <button type="button" className="sol-icon" onClick={() => void open('comparison')} data-testid={`button-open-comparison-folder-${order.id}`}>
      <FolderOpen aria-hidden="true" />세탁 전후 사진 폴더</button>
  </>;
}

function OrderLine({ order }: { order: ConfirmedOrder }) {
  const c = garmentStageCounts(order);
  return <div className="sol-line">
    <span>{order.items.map((i) => `${i.displayNameKo} ${i.quantity}점`).join(' · ')}</span>
    <span className="sol-chips">
      <em>총 {order.totalQuantity}점</em><em>{won(order.estimatedTotal)}</em>
      {c.waiting > 0 && <em>접수·대기 {c.waiting}</em>}
      {c.progress > 0 && <em className="is-progress">진행 {c.progress}</em>}
      {c.ready > 0 && <em className="is-ready">세탁 완료·출고 대기 {c.ready}</em>}
      {c.handedOver > 0 && <em>출고 {c.handedOver}</em>}
    </span>
  </div>;
}

function CustomerOrdersModal({ order, all, onClose, onResume }: {
  order: ConfirmedOrder; all: readonly ConfirmedOrder[]; onClose: () => void; onResume: (id: string) => void;
}) {
  const ref = useRef<HTMLDialogElement | null>(null);
  useEffect(() => { ref.current?.showModal(); }, []);
  const phone = digits(order.customerPhone);
  const mine = all.filter((o) => (phone ? digits(o.customerPhone) === phone : o.customerName === order.customerName))
    .sort((a, b) => b.intakeAt.localeCompare(a.intakeAt));
  const totals = mine.reduce((t, o) => { const c = garmentStageCounts(o);
    return { progress: t.progress + c.waiting + c.progress, ready: t.ready + c.ready, out: t.out + c.handedOver }; }, { progress: 0, ready: 0, out: 0 });
  return <dialog ref={ref} className="k99-modal" onClose={onClose} aria-labelledby="sol-modal-title" data-testid="dialog-customer-orders">
    <header className="k99-modal__head">
      <div><h2 id="sol-modal-title">{order.customerName} 고객 접수 요약</h2><p>{order.customerPhone} · 주문 {mine.length}건</p></div>
      <button type="button" className="k99-modal__close" onClick={() => ref.current?.close()} data-testid="button-close-customer-orders"><X aria-hidden="true" />닫기</button>
    </header>
    <div className="sol-modal-stats">
      <div><span>세탁 진행</span><strong data-testid="text-modal-progress">{totals.progress}점</strong></div>
      <div><span>완료·출고 대기</span><strong data-testid="text-modal-ready">{totals.ready}점</strong></div>
      <div><span>출고 완료</span><strong data-testid="text-modal-out">{totals.out}점</strong></div>
    </div>
    <div className="sol-modal-list">
      {mine.map((o) => <article key={o.id} data-testid={`row-modal-order-${o.id}`}>
        <div className="sol-modal-row-head"><strong>{new Date(o.intakeAt).toLocaleDateString('ko-KR')} · {orderDisplayStatus(o)}</strong>
          <button type="button" onClick={() => { ref.current?.close(); onResume(o.id); }} data-testid={`button-modal-open-${o.id}`}>주문 열기</button></div>
        <OrderLine order={o} />
      </article>)}
    </div>
  </dialog>;
}

export function SavedOrderLookup({ onResume }: { onResume: (id: string) => void; onOpenOperations?: () => void }) {
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [modalOrder, setModalOrder] = useState<ConfirmedOrder | null>(null);
  const [composeOrder, setComposeOrder] = useState<ConfirmedOrder | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const r = () => setTick((t) => t + 1);
    window.addEventListener('storage', r);
    return () => window.removeEventListener('storage', r);
  }, []);
  const { all, storageError } = useMemo(() => {
    try { return { all: readConfirmedOrders(), storageError: '' }; }
    catch (c) { return { all: [] as ConfirmedOrder[], storageError: c instanceof Error ? c.message : '저장 주문을 읽지 못했습니다.' }; }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick]);
  const waiting = all.filter((o) => o.status === '고객 승인 대기' || o.status === '고객 회신 대기' || o.status === '보류');
  const results = useMemo(() => searchSavedOrders(all, submitted), [all, submitted]);

  function resume(id: string) {
    try { onResume(id); setError(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '주문을 불러오지 못했습니다.'); }
  }

  return (
    <section className="saved-order-lookup" aria-label="주문 찾기">
      <div className="saved-order-lookup__inner">
        <strong className="sol-title">주문 찾기 · 의류 검색</strong>
        <form onSubmit={(e) => { e.preventDefault(); setSubmitted(query); setStatus(null); }}>
          <label htmlFor="saved-order-query">바코드 스캔, 고객 이름, 휴대폰 뒷자리 4자리 또는 주문번호</label>
          <div><ImeTextInput koreanFirst="search" data-scanner-input id="saved-order-query" value={query} onValue={setQuery}
            placeholder="예: 홍길동 / 5678 / 바코드" autoComplete="off" data-testid="input-resume-order-id" />
            <button type="submit" data-testid="button-resume-order"><Search aria-hidden="true" />검색</button></div>
        </form>
        {submitted && <div className="sol-results" data-testid="list-search-results">
          {results.length === 0 ? <p className="sol-empty" data-testid="empty-search-results">"{submitted}"에 해당하는 주문이 없습니다. 이름 일부, 휴대폰 뒷자리 4자리, 바코드를 다시 확인해 주세요.</p>
            : <p className="sol-count">{results.length}건 · 최근 접수 순</p>}
          {results.slice(0, 30).map((o) => <article key={o.id} className="sol-card" data-testid={`card-search-order-${o.id}`}>
            <div className="sol-card-head">
              <div><strong>{o.customerName}</strong> <small>{o.customerPhone} · {new Date(o.intakeAt).toLocaleString('ko-KR')}</small></div>
              <span className="sol-status">{orderDisplayStatus(o)}</span>
            </div>
            <OrderLine order={o} />
            <div className="sol-actions">
              <button type="button" onClick={() => resume(o.id)} data-testid={`button-open-order-${o.id}`}>주문 열기</button>
              <button type="button" className="sol-icon" onClick={() => setModalOrder(o)} data-testid={`button-customer-summary-${o.id}`}>
                <ClipboardList aria-hidden="true" />주문·수거·배달 요약</button>
              <FolderButtons order={o} onStatus={setStatus} />
              <button type="button" className="sol-icon" onClick={() => setComposeOrder(o)} data-testid={`button-before-after-${o.id}`}>
                <Images aria-hidden="true" />세탁 전·후 사진 만들기</button>
            </div>
          </article>)}
        </div>}
        {status && <p role="status" className={status.kind === 'ok' ? 'sol-ok' : 'saved-order-lookup__error'} data-testid="status-folder">{status.text}</p>}
        {waiting.length > 0 && <details className="saved-order-lookup__waiting">
          <summary>고객 회신 대기 · {waiting.length}건</summary>
          {waiting.map((order) => <div className="saved-order-lookup__row" key={order.id}>
            <span><strong>{order.customerName}</strong> · {orderDisplayStatus(order)}</span>
            <button type="button" onClick={() => resume(order.id)}>검수 이어보기</button>
          </div>)}
        </details>}
        {error && <p role="alert" className="saved-order-lookup__error">{error}</p>}
        {storageError && <p role="alert" className="saved-order-lookup__error">{storageError}</p>}
      </div>
      {modalOrder && <CustomerOrdersModal order={modalOrder} all={all} onClose={() => setModalOrder(null)} onResume={resume} />}
      {composeOrder && <BeforeAfterComposer order={composeOrder} onClose={() => setComposeOrder(null)} />}
    </section>
  );
}
