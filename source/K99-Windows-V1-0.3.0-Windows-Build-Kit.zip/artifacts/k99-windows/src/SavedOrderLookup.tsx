import { useState } from 'react';
import { orderDisplayStatus } from './handover-display';
import { readConfirmedOrders } from './order-record';
import './saved-order-lookup.css';

export function SavedOrderLookup({ onResume, onOpenOperations }: { onResume: (id: string) => void; onOpenOperations: () => void }) {
  const [orderId, setOrderId] = useState('');
  const [error, setError] = useState('');
  let waiting: ReturnType<typeof readConfirmedOrders> = [];
  let storageError = '';
  try {
    waiting = readConfirmedOrders().filter((order) =>
      order.status === '고객 승인 대기' || order.status === '고객 회신 대기' || order.status === '보류');
  } catch (cause) {
    storageError = cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.';
  }
  function resume(id: string) {
    try {
      onResume(id);
      setError('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '주문을 불러오지 못했습니다.');
    }
  }
  return (
    <section className="saved-order-lookup" aria-label="저장된 주문 이어보기">
      <div className="saved-order-lookup__inner">
        <strong>저장 주문 찾기</strong>
        <button type="button" onClick={onOpenOperations} data-testid="button-open-operations">주문·수거·배달 관리</button>
        <form onSubmit={(event) => { event.preventDefault(); resume(orderId.trim()); }}>
          <label htmlFor="saved-order-id">주문번호</label>
          <div><input data-scanner-input id="saved-order-id" value={orderId} onChange={(event) => setOrderId(event.target.value)}
            placeholder="저장된 주문번호 입력" data-testid="input-resume-order-id" />
            <button type="submit" data-testid="button-resume-order">주문 찾기</button></div>
        </form>
        {waiting.length > 0 && <details className="saved-order-lookup__waiting">
          <summary>고객 회신 대기 · {waiting.length}건</summary>
          {waiting.map((order) => <div className="saved-order-lookup__row" key={order.id}>
            <span><strong>{order.customerName}</strong> · {orderDisplayStatus(order)}</span>
            <button type="button" onClick={() => resume(order.id)}>검수 이어보기</button>
          </div>)}
        </details>}
        {error && <p role="alert" className="saved-order-lookup__error">{error}</p>}
        {storageError && <p role="alert" className="saved-order-lookup__error">{storageError}</p>}
      </div>
    </section>
  );
}