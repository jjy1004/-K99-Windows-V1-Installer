import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { IMPORT_PRIVACY_NOTICE } from './CustomerPrivacySettings';
import {
  commitCustomerImport, customerHistory, previewCustomerFile, searchCustomers, ledgerStatus, ledgerReview,
  type DirectoryCustomer, type CustomerVisit, type ImportPreview, type VisitHistory, type LedgerStatus, type ReviewRow,
} from './customer-directory-client';
import './customer-directory.css';
import { CustomerPhotoFolders } from './CustomerPhotoFolders';
import { customerQuery, uniquePhoneCustomer, customerOptionIndex, customerPhoneDisplay, type CustomerSearchField } from './customer-autofill';
import { CustomerSpecialNote } from './CustomerSpecialNote';

export type { DirectoryCustomer };

const won = (v: number) => `${v.toLocaleString('ko-KR')}원`;
const digits = (s: string) => s.replace(/\D/g, '');
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);

export function ReceptionCustomerLookup({ name, phone, selectedId, onSelect, activeField = 'name' }: {
  name: string; phone: string; onSelect: (customer: DirectoryCustomer) => void;
  selectedId?: string; activeField?: CustomerSearchField;
}) {
  const [results, setResults] = useState<DirectoryCustomer[]>([]);
  const [resultsKey, setResultsKey] = useState('');
  const [highlighted, setHighlighted] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<DirectoryCustomer | null>(null);
  useEffect(() => {
    if (!selectedId) return;
    let live = true;
    customerHistory(selectedId).then(h => {
      if (live && h.customer.name === name.trim() && digits(h.customer.phone) === digits(phone)) setSelected(h.customer);
    }).catch(e => { if(live) setError(errText(e,'선택 고객 복원 실패')); });
    return () => { live = false; };
  }, [selectedId, name, phone]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [composing, setComposing] = useState(false);
  const seq = useRef(0);
  const [tick, setTick] = useState(0);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  useEffect(() => {
    const relevant = (event: Event) => ['input-customer-name', 'input-customer-phone'].includes((event.target as HTMLElement)?.getAttribute('data-testid') || '');
    const onStart = (event: Event) => { if (relevant(event)) setComposing(true); };
    const onEnd = (event: Event) => { if (relevant(event)) setComposing(false); };
    document.addEventListener('compositionstart', onStart);
    document.addEventListener('compositionend', onEnd);
    return () => { document.removeEventListener('compositionstart', onStart); document.removeEventListener('compositionend', onEnd); };
  }, []);

  useEffect(() => {
    const refresh = () => setTick((t) => t + 1);
    window.addEventListener('k99-equipment-changed', refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('k99-equipment-changed', refresh); window.removeEventListener('storage', refresh); };
  }, []);

  // Clear selection when fields drift away from the selected customer.
  useEffect(() => {
    if (selected && (name.trim() !== selected.name.trim() || digits(phone) !== digits(selected.phone))) setSelected(null);
  }, [name, phone, selected]);

  const query = customerQuery(name, phone, activeField);
  const q = query?.keyword || '';
  const kind = query?.kind;
  const currentKey = `${activeField}|${q}|${name}|${phone}|${composing}`;
  const latestKey = useRef(currentKey);
  latestKey.current = currentKey;
  const clearKeyboardSelection = () => document.querySelectorAll('[data-k99-customer-selection]')
    .forEach(input => input.removeAttribute('data-k99-customer-selection'));
  useEffect(() => { clearKeyboardSelection(); return clearKeyboardSelection; }, [currentKey, selected]);
  function choose(c: DirectoryCustomer) {
    seq.current++;
    clearKeyboardSelection();
    setResults([]); setLoading(false);
    setSelected(c); onSelectRef.current(c);
  }
  useEffect(() => {
    const id = ++seq.current;
    let live = true;
    const key = currentKey;
    if (!q || (selected && name.trim() === selected.name.trim() && digits(phone) === digits(selected.phone))) {
      setResults([]); setError(''); setLoading(false); return;
    }
    setResults([]); setLoading(true); setError(''); setHighlighted(0);
    const timer = setTimeout(() => {
      searchCustomers(q).then((r) => {
        if (!live || id !== seq.current || latestKey.current !== key) return;
        const seen = new Set<string>();
        const list = r.customers.filter((c) => !seen.has(c.id) && (seen.add(c.id), true));
        setResults(list); setResultsKey(key); setError('');
        const unique = uniquePhoneCustomer({ keyword: q, kind: kind! }, list);
        const focusedField = document.activeElement?.getAttribute('data-testid');
        if (unique && !composing && ['input-customer-name', 'input-customer-phone'].includes(focusedField || '')) choose(unique);
      }).catch((e) => { if (live && id === seq.current && latestKey.current === key) { setResults([]); setError(errText(e, '고객 검색에 실패했습니다.')); } })
        .finally(() => { if (live && id === seq.current) setLoading(false); });
    }, 150);
    return () => { live = false; clearTimeout(timer); };
  }, [q, kind, composing, tick, selected, name, phone, activeField]);

  useEffect(() => {
    const onKey = (event: globalThis.KeyboardEvent) => {
      const field = (event.target as HTMLElement)?.getAttribute('data-testid');
      if (!['input-customer-name', 'input-customer-phone'].includes(field || '') ||
          event.isComposing || event.keyCode === 229 || composing || loading || selected) return;
      if (!results.length || !q || resultsKey !== currentKey) return;
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        (event.target as HTMLElement).setAttribute('data-k99-customer-selection', q);
        setHighlighted(i => customerOptionIndex(i, event.key, results.length));
      } else if (event.key === 'Enter') {
        event.preventDefault();
        const customer = results[highlighted] || results[0];
        if (customer) choose(customer);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [results, highlighted, composing, loading, selected, q, resultsKey, currentKey]);

  const [lastVisit, setLastVisit] = useState<{ state: 'loading' | 'ready' | 'error'; visit?: CustomerVisit; error?: string; history?: VisitHistory }>({ state: 'loading' });
  const [histAttempt, setHistAttempt] = useState(0);
  const histSeq = useRef(0);
  const selectedKey = selected ? `${selected.id}|${selected.name}|${digits(selected.phone)}|${selected.nextVisit}|${selected.totalVisits}` : '';
  const selectedIdNow = selected?.id;
  useEffect(() => {
    if (!selectedIdNow) return;
    let live = true;
    const id = ++histSeq.current;
    const ok = () => live && id === histSeq.current;
    setLastVisit({ state: 'loading' });
    customerHistory(selectedIdNow).then((h) => { if (ok()) setLastVisit({ state: 'ready', visit: h.visits[0], history: h }); })
      .catch((e) => { if (ok()) setLastVisit({ state: 'error', error: errText(e, '이력을 불러오지 못했습니다.') }); });
    return () => { live = false; };
  }, [selectedIdNow, selectedKey, tick, histAttempt]);

  return (
    <section className="cdir-lookup" aria-label="기존 고객 조회">
      {selected ? (
        <div className="cdir-mini" data-testid="card-customer-mini">
          <CustomerSpecialNote customer={selected} onSaved={note=>{setSelected(old=>old?.id===selected.id?{...old,specialNote:note}:old);setTick(t=>t+1);}}/>
          <div className="cdir-row">
            <span className="cdir-badge" data-testid="text-selected-customer">✨ {selected.name} 님 ({selected.nextVisit}번째 방문)</span>
            <button type="button" className="cdir-btn" onClick={() => setHistoryOpen(true)} data-testid="button-open-history">이전 내역 확인</button>
          </div>
          <p className="cdir-hint" style={{ marginTop: 6 }} data-testid="text-last-visit">
            {lastVisit.state === 'loading' ? '직전 방문 확인 중...'
              : lastVisit.state === 'error' ? `직전 방문 조회 실패: ${lastVisit.error}`
                : lastVisit.visit ? `직전 방문일: ${lastVisit.visit.visitDate} (세탁물 ${lastVisit.visit.itemCount}건 / ${won(lastVisit.visit.laundryAmount ?? lastVisit.visit.totalAmount)})`
                  : '직전 방문 기록 없음'}
          </p>
          <RecentYearBlock state={lastVisit.state} history={lastVisit.history} error={lastVisit.error} onRetry={() => setHistAttempt((a) => a + 1)} />
          <CustomerPhotoFolders key={selected.id} customerId={selected.id} />
        </div>
      ) : (
        <p className="cdir-hint">고객명 2글자 이상 또는 전화 끝4자리로 검색합니다. 끝4자리 일치 고객이 한 명이면 자동 기입됩니다.</p>
      )}
      {error && <p className="cdir-error" role="alert">{error}</p>}
      {!selected && q && (
        loading || resultsKey !== currentKey ? (
          <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /></div>
        ) : !error && (
          results.length ? (
            <ul className="cdir-list" id="k99-customer-suggestions" role="listbox" aria-label="검색된 고객 · 위아래 방향키 후 Enter로 선택">
              {results.map((c, i) => (
                <li key={c.id}>
                  <button type="button" role="option" aria-selected={i === highlighted} onMouseEnter={() => setHighlighted(i)} onClick={() => choose(c)}>
                    <span><strong>{c.name}</strong>{c.specialNote&&<strong style={{color:'#dc2626',background:'#fef2f2',marginLeft:8,padding:4,borderRadius:4}}>🚨 특이사항</strong>} <small>{customerPhoneDisplay(c.phone)}</small>{c.address && <small style={{ display: 'block' }}>{c.address}</small>}</span>
                  <small>최근 방문 {c.lastVisitDate || '기록 없음'} · 최근 1년 {c.recentYear?.visitCount ?? 0}회
                    {c.recentYear ? ` / ${c.recentYear.itemCount}점 / ${won(c.recentYear.totalAmount)}` : ''}
                    {c.sourceCustomerId ? ` · 고객ID ${c.sourceCustomerId}` : ''}{c.needsReview ? ' · 확인 필요' : ''}</small>
                  </button>
                  {c.specialNote&&<p role="alert" data-testid="customer-search-special-note"
                    style={{margin:'4px 0 8px',padding:12,color:'#991b1b',background:'#fef2f2',border:'2px solid #dc2626',borderRadius:8,fontSize:20,fontWeight:800,lineHeight:1.4,whiteSpace:'pre-wrap'}}>
                    ⚠️ 고객 특이사항: {c.specialNote}
                  </p>}
                </li>
              ))}
            </ul>
          ) : <p className="cdir-hint" style={{ marginTop: 8 }}>일치하는 기존 고객이 없습니다. 신규 고객으로 접수됩니다.</p>
        )
      )}
      {historyOpen && selected && <HistoryDialog key={`${selectedKey}|${tick}`} customer={selected} onClose={() => setHistoryOpen(false)} />}
    </section>
  );
}

const itemsText = (v: CustomerVisit) => {
  if (v.items && v.items.length) {
    const head = v.items.slice(0, 3).map((it) => `${it.label}${it.quantity > 1 ? ` ×${it.quantity}` : ''}`).join(', ');
    return `${head}${v.items.length > 3 ? ` 외 ${v.items.length - 3}` : ''} · ${v.itemCount}점`;
  }
  return `${v.itemCount}점`;
};

function RecentYearBlock({ state, history, error, onRetry }: {
  state: 'loading' | 'ready' | 'error'; history?: VisitHistory; error?: string; onRetry: () => void;
}) {
  if (state === 'loading') return (
    <div className="cdir-ry" aria-busy="true" data-testid="status-recent-loading">
      <div className="cdir-ry-cards"><div className="cdir-skel" /><div className="cdir-skel" /><div className="cdir-skel" /></div>
      <div className="cdir-skel" style={{ height: 90, marginTop: 8 }} />
    </div>
  );
  if (state === 'error') return (
    <div className="cdir-error" role="alert" data-testid="status-recent-error">최근 1년 이력 조회 실패: {error}
      <div style={{ marginTop: 8 }}><button type="button" className="cdir-btn" onClick={onRetry} data-testid="button-retry-recent">다시 시도</button></div>
    </div>
  );
  const ry = history?.recentYear;
  const rv = history?.recentVisits ?? [];
  return (
    <div className="cdir-ry" data-testid="section-recent-year">
      <div className="cdir-ry-head">
        <strong>최근 1년</strong>
        {ry && <small data-testid="text-recent-range">{ry.startDate} ~ {ry.endDate}</small>}
      </div>
      <div className="cdir-ry-cards">
        <div className="cdir-ry-card"><span>방문횟수</span><b data-testid="text-recent-visits">{(ry?.visitCount ?? 0).toLocaleString('ko-KR')}<em>회</em></b></div>
        <div className="cdir-ry-card"><span>세탁물</span><b data-testid="text-recent-items">{(ry?.itemCount ?? 0).toLocaleString('ko-KR')}<em>점</em></b></div>
        <div className="cdir-ry-card accent"><span>누적 세탁비</span><b data-testid="text-recent-amount">{(ry?.totalAmount ?? 0).toLocaleString('ko-KR')}<em>원</em></b></div>
      </div>
      {rv.length === 0 ? (
        <p className="cdir-ry-empty" data-testid="text-recent-empty">최근 1년간 방문 기록이 없습니다.</p>
      ) : (
        <div className="cdir-ry-scroll">
          <table className="cdir-table cdir-ry-table" data-testid="table-recent-visits">
            <thead><tr><th>방문일자</th><th>품목/수량</th><th className="num">금액</th></tr></thead>
            <tbody>
              {rv.map((v, i) => (
                <tr key={v.id} data-testid={`row-recent-${i}`}>
                  <td className="date">{v.visitDate}</td>
                  <td>{itemsText(v)}</td>
                  <td className="num">{won(v.laundryAmount ?? v.totalAmount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function HistoryDialog({ customer, onClose }: { customer: DirectoryCustomer; onClose: () => void }) {
  const [data, setData] = useState<VisitHistory | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    return () => prev?.focus?.();
  }, []);

  useEffect(() => {
    let live = true;
    setData(null); setError('');
    customerHistory(customer.id).then((h) => live && setData(h))
      .catch((e) => live && setError(errText(e, '방문 이력을 불러오지 못했습니다.')));
    return () => { live = false; };
  }, [customer.id, attempt]);

  const onKey = useCallback((e: KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); onCloseRef.current(); return; }
    if (e.key === 'Enter' && !(e.target instanceof HTMLButtonElement)) e.preventDefault();
    if (e.key === 'Tab' && ref.current) {
      const f = ref.current.querySelectorAll<HTMLElement>('button');
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }, []);

  return (
    <div className="cdir-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={onKey} onKeyUp={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); e.stopPropagation(); }}>
      <div ref={ref} className="cdir-dialog" role="dialog" aria-modal="true" aria-labelledby="cdir-history-title">
        <div className="cdir-row" style={{ justifyContent: 'space-between' }}>
          <h2 id="cdir-history-title">{customer.name} 고객 이전 내역</h2>
          <button ref={closeRef} type="button" className="cdir-btn" onClick={onClose}>닫기</button>
        </div>
        <p className="cdir-hint">{customer.phone}{customer.address ? ` · ${customer.address}` : ''}</p>
        {error ? (
          <div className="cdir-error" role="alert">{error}
            <div style={{ marginTop: 8 }}><button type="button" className="cdir-btn" onClick={() => setAttempt((a) => a + 1)}>다시 시도</button></div>
          </div>
        ) : !data ? (
          <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /><div className="cdir-skel" /></div>
        ) : data.visits.length === 0 ? (
          <p className="cdir-hint" style={{ marginTop: 14 }}>저장된 방문 기록이 없습니다.</p>
        ) : (
          <table className="cdir-table" data-testid="table-customer-history">
            <thead><tr><th>방문일자</th><th>품목/수량</th><th className="num">금액</th></tr></thead>
            <tbody>
              {data.visits.map((v, i) => (
                <tr key={v.id} data-testid={`row-history-${i}`}>
                  <td>{v.visitDate}</td>
                  <td>{itemsText(v)}</td>
                  <td className="num">{won(v.laundryAmount ?? v.totalAmount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

const MAP_FIELDS: [string, string][] = [
  ['name', '이름'], ['phone', '전화번호'], ['address', '주소'], ['total_visits', '총 방문수'],
  ['visit_date', '방문일'], ['item_count', '수량'], ['total_amount', '금액'], ['memo', '메모'], ['order_id', '주문번호'],
];

export function CustomerImportPanel() {
  const [ledger, setLedger] = useState<LedgerStatus | null>(null);
  const [reviewRows, setReviewRows] = useState<ReviewRow[] | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [busy, setBusy] = useState<'' | 'preview' | 'commit'>('');
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [result, setResult] = useState<{ customers: number; histories: number; duplicates: number; backup: string } | null>(null);
  const reqId = useRef(0);
  useEffect(() => {
    if (!window.k99Desktop) return;
    let live = true;
    ledgerStatus().then(r => { if (live) setLedger(r); }).catch(e => { if(live) setError(errText(e, '접수대장 상태 조회 실패')); });
    setReviewRows(null);
    return () => { live = false; };
  }, [result]);

  const invalidate = () => { reqId.current++; setPreview(null); setConfirmed(false); setError(''); setBusy(''); };

  const runPreview = async () => {
    if (!file) return;
    const id = ++reqId.current;
    setBusy('preview'); setError(''); setResult(null);
    const clean = Object.fromEntries(Object.entries(mapping).filter(([, v]) => v.trim()).map(([k, v]) => [k, v.trim()]));
    try {
      const p = await previewCustomerFile(file, clean);
      if (id === reqId.current) setPreview(p);
    } catch (e) { if (id === reqId.current) setError(errText(e, '미리보기에 실패했습니다.')); }
    finally { if (id === reqId.current) setBusy(''); }
  };

  const runCommit = async () => {
    if (!preview || !confirmed) return;
    const id = ++reqId.current;
    setBusy('commit'); setError('');
    try {
      const r = await commitCustomerImport(preview.token);
      if (id === reqId.current) { setResult(r); setPreview(null); setConfirmed(false);
        window.dispatchEvent(new Event('k99-equipment-changed')); window.alert(IMPORT_PRIVACY_NOTICE); }
    } catch (e) { if (id === reqId.current) setError(errText(e, '가져오기 저장에 실패했습니다.')); }
    finally { if (id === reqId.current) setBusy(''); }
  };

  const sampleCols = preview ? Array.from(new Set(preview.sample.flatMap((r) => Object.keys(r)))) : [];

  return (
    <section className="cdir-import" aria-labelledby="cdir-import-title">
      <div>
        <h2 id="cdir-import-title" className="section-title">고객 명단 가져오기</h2>
        <p className="section-caption">엑셀(xlsx) 또는 CSV 파일을 미리 확인한 뒤 직접 확정해야 저장됩니다. 저장 전 기존 DB를 자동 백업합니다.</p>
      </div>
      <label className="field-label">파일 선택
        <input className="field-input" type="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
          style={{ paddingTop: 10 }} onChange={(e) => { setFile(e.target.files?.[0] ?? null); setResult(null); invalidate(); }} />
      </label>
      <details>
        <summary className="field-label" style={{ cursor: 'pointer' }}>열 이름 지정 (선택, 비우면 자동 인식)</summary>
        <div className="cdir-map">
          {MAP_FIELDS.map(([key, label]) => (
            <label key={key}>{label}
              <input className="field-input" value={mapping[key] ?? ''} placeholder={key}
                onChange={(e) => { setMapping((m) => ({ ...m, [key]: e.target.value })); invalidate(); }} />
            </label>
          ))}
        </div>
      </details>
      <div className="cdir-row">
        <button type="button" className="cdir-btn primary" disabled={!file || !!busy} onClick={runPreview}>
          {busy === 'preview' ? '확인 중...' : '미리보기'}
        </button>
      </div>
      {error && <p className="cdir-error" role="alert">{error}</p>}
      {busy === 'preview' && <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /></div>}
      {preview && (
        <div style={{ display: 'grid', gap: 12 }}>
          <div className="cdir-stats">
            <span>전체 행 {preview.rowCount}</span><span>고객 {preview.customerCount}명</span>
            <span>방문 이력 {preview.historyCount}건</span><span>중복 {preview.duplicateCount}건</span>
          </div>
          <p className="cdir-hint">인식된 열: {preview.headers.join(', ') || '없음'}</p>
          {preview.format === 'k99-v5' && <p className="cdir-hint">K99 V5 전용 변환 · 원본 고객 {preview.summary?.masterCustomers}행 · 추가 확인 고객 {preview.summary?.additionalCustomers}명 · 의류 {preview.summary?.garmentRows}행 · 원본 보존 {preview.summary?.preservedRows}행 · 검토 {preview.summary?.reviewRows}행</p>}
          {preview.warnings.length > 0 && (
            <ul className="cdir-error" style={{ paddingLeft: 28 }}>{preview.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>
          )}
          {preview.sample.length > 0 ? (
            <div className="cdir-sample">
              <table className="cdir-table">
                <thead><tr>{sampleCols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
                <tbody>{preview.sample.map((r, i) => (
                  <tr key={i}>{sampleCols.map((c) => <td key={c}>{r[c] == null ? '' : String(r[c])}</td>)}</tr>
                ))}</tbody>
              </table>
            </div>
          ) : <p className="cdir-hint">표시할 샘플 행이 없습니다.</p>}
          <label className="cdir-row" style={{ fontSize: 13 }}>
            <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            위 내용을 확인했으며 고객 DB에 저장합니다.
          </label>
          <div className="cdir-row">
            <button type="button" className="cdir-btn danger" disabled={!confirmed || !!busy} onClick={runCommit}>
              {busy === 'commit' ? '저장 중...' : '가져오기 확정'}
            </button>
            <button type="button" className="cdir-btn" disabled={!!busy} onClick={invalidate}>취소</button>
          </div>
        </div>
      )}
      {ledger && ledger.sources.length > 0 && <div className="cdir-ok" data-testid="ledger-import-status">
        접수대장 원본 {ledger.preservedRows}행 보존 · 확인 필요 {ledger.reviewRows}행
        <button type="button" className="cdir-btn" onClick={() => void ledgerReview().then(r => setReviewRows(r.rows)).catch(e=>setError(errText(e,'검토 행 조회 실패')))}>확인 필요 행 보기</button>
        {reviewRows && <details open><summary>원본 시트·행 번호 (고객값 비노출)</summary><ul>{reviewRows.map((r,i)=><li key={i}>{r.sheet} {r.row}행: {r.issues.join(' · ')}</li>)}</ul></details>}
      </div>}
      {result && (
        <div className="cdir-ok" role="status">
          가져오기 완료: 고객 {result.customers}명, 방문 이력 {result.histories}건, 중복 {result.duplicates}건.<br />백업 파일: {result.backup}
        </div>
      )}
    </section>
  );
}
