import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from 'react';
import {
  commitCustomerImport, customerHistory, previewCustomerFile, searchCustomers, ledgerStatus, ledgerReview,
  type DirectoryCustomer, type CustomerVisit, type ImportPreview, type VisitHistory, type LedgerStatus, type ReviewRow,
} from './customer-directory-client';
import './customer-directory.css';

export type { DirectoryCustomer };

const won = (v: number) => `${v.toLocaleString('ko-KR')}원`;
const digits = (s: string) => s.replace(/\D/g, '');
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);

function queryFrom(name: string, phone: string, field: 'name' | 'phone') {
  const p = digits(phone);
  if (field === 'name' && name.trim()) return name.trim();
  if (p.length === 4) return p;
  const n = name.trim();
  return n.length >= 1 ? n : '';
}

export function ReceptionCustomerLookup({ name, phone, selectedId, onSelect }: {
  name: string; phone: string; onSelect: (customer: DirectoryCustomer) => void;
  selectedId?: string;
}) {
  const [searchField, setSearchField] = useState<'name' | 'phone'>('name');
  useEffect(() => {
    const active = (event: Event) => {
      const id = (event.target as HTMLElement)?.getAttribute('data-testid');
      if (id === 'input-customer-name') setSearchField('name');
      if (id === 'input-customer-phone') setSearchField('phone');
    };
    document.addEventListener('input', active, true);
    document.addEventListener('focusin', active);
    return () => {
      document.removeEventListener('input', active, true);
      document.removeEventListener('focusin', active);
    };
  }, []);
  const [results, setResults] = useState<DirectoryCustomer[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<DirectoryCustomer | null>(null);
  useEffect(() => {
    if (!selectedId) return;
    let live = true;
    customerHistory(selectedId).then(h => {
      if (live && h.customer.name === name.trim() && digits(h.customer.phone) === digits(phone)) setSelected(h.customer);
    }).catch(e => { if(live) setError(errText(e,'선택 고객 복원 실패')); });
    return () => { live = false; };
  }, [selectedId, name, phone]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [composing, setComposing] = useState(false);
  const seq = useRef(0);
  const [tick, setTick] = useState(0);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  useEffect(() => {
    const onStart = () => setComposing(true);
    const onEnd = () => setComposing(false);
    document.addEventListener('compositionstart', onStart);
    document.addEventListener('compositionend', onEnd);
    return () => { document.removeEventListener('compositionstart', onStart); document.removeEventListener('compositionend', onEnd); };
  }, []);

  useEffect(() => {
    const refresh = () => setTick((t) => t + 1);
    window.addEventListener('k99-equipment-changed', refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('k99-equipment-changed', refresh); window.removeEventListener('storage', refresh); };
  }, []);

  // Clear selection when fields drift away from the selected customer.
  useEffect(() => {
    if (selected && (name.trim() !== selected.name.trim() || digits(phone) !== digits(selected.phone))) setSelected(null);
  }, [name, phone, selected]);

  const q = queryFrom(name, phone, searchField);
  useEffect(() => {
    if (composing) return;
    const id = ++seq.current;
    if (!q) { setResults([]); setError(''); setLoading(false); return; }
    setLoading(true);
    const timer = setTimeout(() => {
      searchCustomers(q).then((r) => {
        if (id !== seq.current) return;
        const seen = new Set<string>();
        const list = r.customers.filter((c) => !seen.has(c.id) && (seen.add(c.id), true));
        setResults(list); setError('');
        setSelected((cur) => (cur ? list.find((c) => c.id === cur.id) ?? cur : cur));
      }).catch((e) => { if (id === seq.current) { setResults([]); setError(errText(e, '고객 검색에 실패했습니다.')); } })
        .finally(() => { if (id === seq.current) setLoading(false); });
    }, 300);
    return () => clearTimeout(timer);
  }, [q, composing, tick]);

  const [lastVisit, setLastVisit] = useState<{ state: 'loading' | 'ready' | 'error'; visit?: CustomerVisit; error?: string }>({ state: 'loading' });
  const selectedKey = selected ? `${selected.id}|${selected.name}|${digits(selected.phone)}|${selected.nextVisit}|${selected.totalVisits}` : '';
  const selectedIdNow = selected?.id;
  useEffect(() => {
    if (!selectedIdNow) return;
    let live = true;
    setLastVisit({ state: 'loading' });
    customerHistory(selectedIdNow).then((h) => { if (live) setLastVisit({ state: 'ready', visit: h.visits[0] }); })
      .catch((e) => { if (live) setLastVisit({ state: 'error', error: errText(e, '이력을 불러오지 못했습니다.') }); });
    return () => { live = false; };
  }, [selectedIdNow, selectedKey, tick]);

  const choose = (c: DirectoryCustomer) => { setSelected(c); onSelectRef.current(c); };

  return (
    <section className="cdir-lookup" aria-label="기존 고객 조회">
      {selected ? (
        <div className="cdir-mini" data-testid="card-customer-mini">
          <div className="cdir-row">
            <span className="cdir-badge" data-testid="text-selected-customer">✨ {selected.name} 님 ({selected.nextVisit}번째 방문)</span>
            <button type="button" className="cdir-btn" onClick={() => setHistoryOpen(true)} data-testid="button-open-history">이전 내역 확인</button>
          </div>
          <p className="cdir-hint" style={{ marginTop: 6 }} data-testid="text-last-visit">
            {lastVisit.state === 'loading' ? '직전 방문 확인 중...'
              : lastVisit.state === 'error' ? `직전 방문 조회 실패: ${lastVisit.error}`
                : lastVisit.visit ? `직전 방문일: ${lastVisit.visit.visitDate} (세탁물 ${lastVisit.visit.itemCount}건 / ${won(lastVisit.visit.laundryAmount ?? lastVisit.visit.totalAmount)})`
                  : '직전 방문 기록 없음'}
          </p>
        </div>
      ) : (
        <p className="cdir-hint">이름 또는 전화번호 뒤 4자리로 기존 고객을 찾습니다.</p>
      )}
      {error && <p className="cdir-error" role="alert">{error}</p>}
      {!selected && q && (
        loading ? (
          <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /></div>
        ) : !error && (
          results.length ? (
            <ul className="cdir-list" aria-label="검색된 고객">
              {results.map((c) => (
                <li key={c.id}>
                  <button type="button" onClick={() => choose(c)}>
                    <span><strong>{c.name}</strong> <small>{c.phone}</small>{c.address && <small style={{ display: 'block' }}>{c.address}</small>}</span>
                  <small>방문 {c.totalVisits}회{c.sourceCustomerId ? ` · 고객ID ${c.sourceCustomerId}` : ''}{c.needsReview ? ' · 확인 필요' : ''}</small>
                  </button>
                </li>
              ))}
            </ul>
          ) : <p className="cdir-hint" style={{ marginTop: 8 }}>일치하는 기존 고객이 없습니다. 신규 고객으로 접수됩니다.</p>
        )
      )}
      {historyOpen && selected && <HistoryDialog key={`${selectedKey}|${tick}`} customer={selected} onClose={() => setHistoryOpen(false)} />}
    </section>
  );
}

function HistoryDialog({ customer, onClose }: { customer: DirectoryCustomer; onClose: () => void }) {
  const [data, setData] = useState<VisitHistory | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    return () => prev?.focus?.();
  }, []);

  useEffect(() => {
    let live = true;
    setData(null); setError('');
    customerHistory(customer.id).then((h) => live && setData(h))
      .catch((e) => live && setError(errText(e, '방문 이력을 불러오지 못했습니다.')));
    return () => { live = false; };
  }, [customer.id, attempt]);

  const onKey = useCallback((e: KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); onCloseRef.current(); return; }
    if (e.key === 'Enter' && !(e.target instanceof HTMLButtonElement)) e.preventDefault();
    if (e.key === 'Tab' && ref.current) {
      const f = ref.current.querySelectorAll<HTMLElement>('button');
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }, []);

  return (
    <div className="cdir-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={onKey} onKeyUp={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); e.stopPropagation(); }}>
      <div ref={ref} className="cdir-dialog" role="dialog" aria-modal="true" aria-labelledby="cdir-history-title">
        <div className="cdir-row" style={{ justifyContent: 'space-between' }}>
          <h2 id="cdir-history-title">{customer.name} 고객 이전 내역</h2>
          <button ref={closeRef} type="button" className="cdir-btn" onClick={onClose}>닫기</button>
        </div>
        <p className="cdir-hint">{customer.phone}{customer.address ? ` · ${customer.address}` : ''}</p>
        {error ? (
          <div className="cdir-error" role="alert">{error}
            <div style={{ marginTop: 8 }}><button type="button" className="cdir-btn" onClick={() => setAttempt((a) => a + 1)}>다시 시도</button></div>
          </div>
        ) : !data ? (
          <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /><div className="cdir-skel" /></div>
        ) : data.visits.length === 0 ? (
          <p className="cdir-hint" style={{ marginTop: 14 }}>저장된 방문 기록이 없습니다.</p>
        ) : (
          <table className="cdir-table" data-testid="table-customer-history">
            <thead><tr><th>방문일</th><th className="num">건수</th><th className="num">세탁비</th></tr></thead>
            <tbody>
              {data.visits.map((v, i) => (
                <tr key={v.id} data-testid={`row-history-${i}`}>
                  <td>{v.visitDate}</td>
                  <td className="num">{v.itemCount}점</td>
                  <td className="num">{won(v.laundryAmount ?? v.totalAmount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

const MAP_FIELDS: [string, string][] = [
  ['name', '이름'], ['phone', '전화번호'], ['address', '주소'], ['total_visits', '총 방문수'],
  ['visit_date', '방문일'], ['item_count', '수량'], ['total_amount', '금액'], ['memo', '메모'], ['order_id', '주문번호'],
];

export function CustomerImportPanel() {
  const [ledger, setLedger] = useState<LedgerStatus | null>(null);
  const [reviewRows, setReviewRows] = useState<ReviewRow[] | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [busy, setBusy] = useState<'' | 'preview' | 'commit'>('');
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [result, setResult] = useState<{ customers: number; histories: number; duplicates: number; backup: string } | null>(null);
  const reqId = useRef(0);
  useEffect(() => {
    if (!window.k99Desktop) return;
    let live = true;
    ledgerStatus().then(r => { if (live) setLedger(r); }).catch(e => { if(live) setError(errText(e, '접수대장 상태 조회 실패')); });
    setReviewRows(null);
    return () => { live = false; };
  }, [result]);

  const invalidate = () => { reqId.current++; setPreview(null); setConfirmed(false); setError(''); setBusy(''); };

  const runPreview = async () => {
    if (!file || !password) return;
    const id = ++reqId.current;
    setBusy('preview'); setError(''); setResult(null);
    const clean = Object.fromEntries(Object.entries(mapping).filter(([, v]) => v.trim()).map(([k, v]) => [k, v.trim()]));
    try {
      const p = await previewCustomerFile(file, password, clean);
      if (id === reqId.current) setPreview(p);
    } catch (e) { if (id === reqId.current) setError(errText(e, '미리보기에 실패했습니다.')); }
    finally { if (id === reqId.current) setBusy(''); }
  };

  const runCommit = async () => {
    if (!preview || !confirmed) return;
    const id = ++reqId.current;
    setBusy('commit'); setError('');
    try {
      const r = await commitCustomerImport(preview.token, password);
      if (id === reqId.current) { setResult(r); setPreview(null); setConfirmed(false); setPassword(''); }
    } catch (e) { if (id === reqId.current) setError(errText(e, '가져오기 저장에 실패했습니다.')); }
    finally { if (id === reqId.current) setBusy(''); }
  };

  const sampleCols = preview ? Array.from(new Set(preview.sample.flatMap((r) => Object.keys(r)))) : [];

  return (
    <section className="cdir-import" aria-labelledby="cdir-import-title">
      <div>
        <h2 id="cdir-import-title" className="section-title">고객 명단 가져오기</h2>
        <p className="section-caption">엑셀(xlsx) 또는 CSV 파일을 미리 확인한 뒤 직접 확정해야 저장됩니다. 저장 전 기존 DB를 자동 백업합니다.</p>
      </div>
      <label className="field-label">파일 선택
        <input className="field-input" type="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
          style={{ paddingTop: 10 }} onChange={(e) => { setFile(e.target.files?.[0] ?? null); setResult(null); invalidate(); }} />
      </label>
      <label className="field-label">관리자 비밀번호
        <input className="field-input" type="password" autoComplete="off" value={password}
          onChange={(e) => { setPassword(e.target.value); invalidate(); }} />
      </label>
      <details>
        <summary className="field-label" style={{ cursor: 'pointer' }}>열 이름 지정 (선택, 비우면 자동 인식)</summary>
        <div className="cdir-map">
          {MAP_FIELDS.map(([key, label]) => (
            <label key={key}>{label}
              <input className="field-input" value={mapping[key] ?? ''} placeholder={key}
                onChange={(e) => { setMapping((m) => ({ ...m, [key]: e.target.value })); invalidate(); }} />
            </label>
          ))}
        </div>
      </details>
      <div className="cdir-row">
        <button type="button" className="cdir-btn primary" disabled={!file || !password || !!busy} onClick={runPreview}>
          {busy === 'preview' ? '확인 중...' : '미리보기'}
        </button>
      </div>
      {error && <p className="cdir-error" role="alert">{error}</p>}
      {busy === 'preview' && <div className="cdir-list" aria-busy="true"><div className="cdir-skel" /><div className="cdir-skel" /></div>}
      {preview && (
        <div style={{ display: 'grid', gap: 12 }}>
          <div className="cdir-stats">
            <span>전체 행 {preview.rowCount}</span><span>고객 {preview.customerCount}명</span>
            <span>방문 이력 {preview.historyCount}건</span><span>중복 {preview.duplicateCount}건</span>
          </div>
          <p className="cdir-hint">인식된 열: {preview.headers.join(', ') || '없음'}</p>
          {preview.format === 'k99-v5' && <p className="cdir-hint">K99 V5 전용 변환 · 원본 고객 {preview.summary?.masterCustomers}행 · 추가 확인 고객 {preview.summary?.additionalCustomers}명 · 의류 {preview.summary?.garmentRows}행 · 원본 보존 {preview.summary?.preservedRows}행 · 검토 {preview.summary?.reviewRows}행</p>}
          {preview.warnings.length > 0 && (
            <ul className="cdir-error" style={{ paddingLeft: 28 }}>{preview.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>
          )}
          {preview.sample.length > 0 ? (
            <div className="cdir-sample">
              <table className="cdir-table">
                <thead><tr>{sampleCols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
                <tbody>{preview.sample.map((r, i) => (
                  <tr key={i}>{sampleCols.map((c) => <td key={c}>{r[c] == null ? '' : String(r[c])}</td>)}</tr>
                ))}</tbody>
              </table>
            </div>
          ) : <p className="cdir-hint">표시할 샘플 행이 없습니다.</p>}
          <label className="cdir-row" style={{ fontSize: 13 }}>
            <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            위 내용을 확인했으며 고객 DB에 저장합니다.
          </label>
          <div className="cdir-row">
            <button type="button" className="cdir-btn danger" disabled={!confirmed || !!busy} onClick={runCommit}>
              {busy === 'commit' ? '저장 중...' : '가져오기 확정'}
            </button>
            <button type="button" className="cdir-btn" disabled={!!busy} onClick={invalidate}>취소</button>
          </div>
        </div>
      )}
      {ledger && ledger.sources.length > 0 && <div className="cdir-ok" data-testid="ledger-import-status">
        접수대장 원본 {ledger.preservedRows}행 보존 · 확인 필요 {ledger.reviewRows}행
        <button type="button" className="cdir-btn" onClick={() => void ledgerReview().then(r => setReviewRows(r.rows)).catch(e=>setError(errText(e,'검토 행 조회 실패')))}>확인 필요 행 보기</button>
        {reviewRows && <details open><summary>원본 시트·행 번호 (고객값 비노출)</summary><ul>{reviewRows.map((r,i)=><li key={i}>{r.sheet} {r.row}행: {r.issues.join(' · ')}</li>)}</ul></details>}
      </div>}
      {result && (
        <div className="cdir-ok" role="status">
          가져오기 완료: 고객 {result.customers}명, 방문 이력 {result.histories}건, 중복 {result.duplicates}건.<br />백업 파일: {result.backup}
        </div>
      )}
    </section>
  );
}
