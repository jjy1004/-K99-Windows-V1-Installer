import type { ConfirmedOrder } from './order-record';
import {inspectionPaymentLabel} from './inspection-payment';
import {paymentInfo} from './order-payment';

export type CustomerJobSort = 'date' | 'name';
export type CustomerJobStage = 'inspection' | 'release';
const korean = new Intl.Collator('ko-KR', {numeric:true, sensitivity:'base'});
const timestamp = (value?:string) => {
  const parsed = Date.parse(value ?? '');
  return Number.isFinite(parsed) ? parsed : 0;
};

/** 완료일이 있으면 단순 결제 변경 시각보다 우선한다. 원본 주문·저장 순서는 바꾸지 않는다. */
export function customerJobTimestamp(order:ConfirmedOrder, stage:CustomerJobStage):number {
  if(stage === 'release'){
    const completed = Math.max(0, ...(order.garments ?? []).map(g => timestamp(g.completedAt)));
    if(completed) return completed;
    return timestamp(order.operations?.updatedAt) || timestamp(order.intakeAt);
  }
  return timestamp(order.intakeAt);
}

export function sortCustomerJobs(orders:readonly ConfirmedOrder[], sort:CustomerJobSort = 'date',
  stage:CustomerJobStage = 'inspection'):ConfirmedOrder[] {
  return [...orders].sort((a,b) => {
    const name = korean.compare(a.customerName.trim(), b.customerName.trim());
    const recent = customerJobTimestamp(b,stage) - customerJobTimestamp(a,stage);
    return (sort === 'name' ? name || recent : recent || name) || korean.compare(a.id,b.id);
  });
}

export function manualJobTags(order:ConfirmedOrder):string[] {
  return [...new Set((order.garments ?? []).filter(g=>g.tagMode === 'roll' && g.tagNumber)
    .map(g=>g.tagNumber!))];
}

/** 기존 결제 해석을 재사용한다. 이미 수금된 후불 이력에는 미수금 경고를 붙이지 않는다. */
export function isUnpaidCustomerJob(order:ConfirmedOrder):boolean {
  return inspectionPaymentLabel(order) === '후불' &&
    paymentInfo({...order,payment_type:'POSTPAID'}).status === 'UNPAID';
}
