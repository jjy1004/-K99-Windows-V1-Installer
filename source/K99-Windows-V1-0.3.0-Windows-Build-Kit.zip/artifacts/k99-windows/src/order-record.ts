import type { InspectionRecord, OrderHistoryEvent } from './inspection-record';
import { DEFAULT_DELIVERY_POLICY, type DeliveryPolicy } from './delivery-policy.ts';
import type { DeliveryStage, OrderOperations } from './order-operations';
import type { GarmentRecord } from './garment-record';
import type { ScanAuditEvent } from './garment-scanner';
import { createGarmentRecords } from './garment-record.ts';
import type { CustomerNotification } from './notification-workflow';
import { itemTotal, validateUnitServices } from './unit-service';
import { isDeletedOrder, type OrderAdminAudit, type OrderDeletion } from './order-deletion-policy';

export type ServiceLevel = 'general' | 'premium';

export type OrderItem = {
  itemId: string;
  displayNameKo: string;
  quantity: number;
  generalPrice: number;
  premiumPrice: number;
  isSneaker: boolean;
  plannedCleaningMethod?: '물세탁' | '드라이세탁';
  intakeDetails?: ItemIntakeDetails;
};

export type ItemIntakeDetails = {
  brand?: string;
  purchasePrice?: number;
  material?: string;
  color?: string;
  stain?: string;
  damage?: string;
  staffRiskOverride?: '확인 필요' | '일반 접수';
};

export type FinalIntakeChoices = {
  paymentType?: import('./order-payment').PaymentType;
  serviceLevel: ServiceLevel;
  unitServiceLevels?: ServiceLevel[][];
  technicalFee?: number;
  discount?: number;
  pickupRequested: boolean;
  deliveryRequested: boolean;
  directPickup: boolean;
  requestedPickupDate: string;
  waiver: 'agreed' | 'declined' | 'not-requested';
  luxuryItem: boolean;
  customerRequests: string;
  /** Staff-entered final total (discount/event). laundryTotal is derived from it so revenue uses the confirmed amount. */
  totalOverride?: number;
  /** Catalog-computed laundry subtotal before the staff override, kept for audit. */
  computedLaundryTotal?: number;
};

export type ConfirmedOrder = {
  payment_type?: import('./order-payment').PaymentType;
  payment_status?: import('./order-payment').PaymentState;
  orderDeletion?: OrderDeletion;
  orderDeletionAudit?: OrderAdminAudit[];
  normalGarmentApprovals?: Record<string, {
    at: string; method: '물세탁' | '드라이세탁'; cycle: number; signature: string;
  }>;
  id: string;
  status: '접수 확정' | '고객 승인 대기' | '고객 회신 대기' | '세탁 진행 승인' | '세탁 진행 거절' | '보류' | '전체 세탁 완료 / 반출 대기';
  intakeAt: string;
  customerFolderName: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  directoryCustomerId?: string;
  items: OrderItem[];
  totalQuantity: number;
  choices: FinalIntakeChoices;
  laundryTotal: number;
  serviceFee: number;
  estimatedTotal: number;
  feePolicy?: DeliveryPolicy;
  operations?: OrderOperations;
  inspection?: InspectionRecord;
  history?: OrderHistoryEvent[];
  garments?: GarmentRecord[];
  scanAuditEvents?: ScanAuditEvent[];
  customerNotifications?: CustomerNotification[];
  orderCompletedAt?: string;
  /** Staff-confirmed sends of pickup/delivery/storage reminders (see customer-pickup-notices). Never a handover record. */
  pickupNoticeLog?: import('./customer-pickup-notices').PickupNoticeLogEntry[];
  preCompletionStage?: DeliveryStage;
  /** Four-step process tab progression shown on the inspection desk. */
  processStage?: ProcessStageRecord;
  /** Native camera shots taken before confirmation (1-based indexes into items/units). Backend promotes them on save. */
  nativeDraftUnits?: NativeDraftUnit[];
  /** One-step customer notice draft. Staff send it outside the app; actuallySent is always false. */
  processNotice?: ProcessNoticeRecord;
  /** Notice technical fee applied only after an explicit 동의 완료. base* are the immutable pre-fee totals. */
  feeAdjustment?: FeeAdjustment;
  completionMessage?: {
    message: string;
    generatedAt: string;
    status: '초안' | '발송 준비' | '취소됨';
    reviewedAt?: string;
    actuallySent: false;
  };
};

export type FeeAdjustment = {
  baseEstimatedTotal: number;
  baseLaundryTotal: number;
  baseChoices: { totalOverride?: number; computedLaundryTotal?: number };
  approvedFee: number;
  approvedAt: string;
  consentRecordedAt: string;
  message: string;
  history: { at: string; previousFee: number; approvedFee: number; estimatedTotal: number; consentRecordedAt: string }[];
};
export type NativeDraftUnit = { itemIndex: number; unitIndex: number; garment: GarmentRecord };
export const PROCESS_STAGES = ['접수', '세탁 전', '세탁 후', '완료 검수'] as const;
export type ProcessStage = typeof PROCESS_STAGES[number];
export type ProcessStageRecord = {
  current: ProcessStage;
  /** Furthest stage confirmed with the bottom button. */
  reached: ProcessStage;
  updatedAt: string;
  history: { stage: ProcessStage; at: string; via: 'next' | 'tab' }[];
};
export type ProcessNoticeKind = 'waiver' | 'fee' | 'both';
export type ProcessNoticeRecord = {
  kind: ProcessNoticeKind;
  message: string;
  technicalFee: number;
  consent: '동의 완료' | '미동의' | null;
  savedAt: string;
  actuallySent: false;
};

const ORDERS_STORAGE_KEY = 'k99-confirmed-orders-v1';
const ACTIVE_ORDER_KEY = 'k99-active-confirmed-order';

export function pickupDeliveryFee(quantity: number, pickup: boolean, delivery: boolean, policy: DeliveryPolicy = DEFAULT_DELIVERY_POLICY): number {
  return quantity > 0 && quantity < policy.freeFromQuantity && (pickup || delivery) ? policy.feeBelowThreshold : 0;
}

export function customerFolderName(date: Date, name: string, phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (!name.trim() || digits.length < 4 || digits.length > 11) throw new Error('고객명과 전화번호(최소 뒷자리 4자리)를 확인해 주세요.');
  if (/[\\/:*?"<>|]/.test(name)) throw new Error('고객명에 폴더명으로 사용할 수 없는 문자가 있습니다.');
  const datePart = [String(date.getFullYear() % 100).padStart(2, '0'),
    String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('');
  return `${datePart} ${name.trim()} ${digits.slice(-4)}`;
}

export function photoFileName(folder: string, phase: '접수' | '완성', sequence: number): string {
  if (!Number.isInteger(sequence) || sequence < 1) throw new Error('사진 번호는 1 이상이어야 합니다.');
  return `${folder}_${phase}_${String(sequence).padStart(2, '0')}.jpg`;
}

export function createConfirmedOrder(
  input: { id: string; customerName: string; customerPhone: string; customerAddress: string; directoryCustomerId?: string; items: OrderItem[] },
  choices: FinalIntakeChoices,
  date = new Date(),
  feePolicy: DeliveryPolicy = DEFAULT_DELIVERY_POLICY,
): ConfirmedOrder {
  if (!input.id || ((choices.pickupRequested || choices.deliveryRequested) && !input.customerAddress.trim()) || !input.items.length ||
      input.items.some((item) => !Number.isInteger(item.quantity) || item.quantity < 1
        || (item.intakeDetails?.purchasePrice !== undefined &&
          (!Number.isSafeInteger(item.intakeDetails.purchasePrice) || item.intakeDetails.purchasePrice < 0
            || item.intakeDetails.purchasePrice > 100000000)))) {
    throw new Error('수거·배달 주소와 세탁물 품목·수량을 확인해 주세요.');
  }
  const folder = customerFolderName(date, input.customerName, input.customerPhone);
  if (choices.deliveryRequested && choices.directPickup) throw new Error('배달과 직접 수령을 동시에 선택할 수 없습니다.');
  if (choices.paymentType !== undefined && !['PREPAID', 'POSTPAID'].includes(choices.paymentType))
    throw new Error('선불 또는 후불을 선택해 주세요.');
  if (!choices.deliveryRequested && !choices.directPickup) throw new Error('배달 또는 직접 수령을 선택해 주세요.');
  if (choices.pickupRequested && !choices.requestedPickupDate) throw new Error('세탁물 수거 희망일을 입력해 주세요.');
  if (!['agreed', 'declined', 'not-requested'].includes(choices.waiver)) throw new Error('면책 동의 여부를 확인해 주세요.');
  if (typeof choices.luxuryItem !== 'boolean') throw new Error('명품 여부를 확인해 주세요.');
  if (choices.serviceLevel !== 'general' && choices.serviceLevel !== 'premium') throw new Error('세탁 서비스 등급을 확인해 주세요.');
  if (![choices.technicalFee ?? 0, choices.discount ?? 0].every((amount) =>
    Number.isSafeInteger(amount) && amount >= 0 && amount <= 100000000))
    throw new Error('추가기술료와 할인금액을 0~1억 원 사이의 정수로 입력해 주세요.');
  const items = input.items.map((item) => ({ ...item, ...(item.intakeDetails && { intakeDetails: { ...item.intakeDetails } }) }));
  const totalQuantity = items.reduce((total, item) => total + item.quantity, 0);
  validateUnitServices(items, choices);
  const computedLaundryTotal = items.reduce((total, item, index) => total + itemTotal(item, choices, index), 0);
  const serviceFee = pickupDeliveryFee(totalQuantity, choices.pickupRequested, choices.deliveryRequested, feePolicy);
  const override = choices.totalOverride;
  if (override !== undefined && (!Number.isSafeInteger(override) || override < 0 || override > 100000000))
    throw new Error('수정한 총 금액은 0~1억 원 사이의 정수여야 합니다.');
  const laundryTotal = override === undefined ? computedLaundryTotal
    : override - serviceFee - (choices.technicalFee ?? 0) + (choices.discount ?? 0);
  if (laundryTotal < 0) throw new Error('수정한 총 금액이 수거·배달비와 추가기술료보다 작을 수 없습니다.');
  if ((choices.discount ?? 0) > laundryTotal + serviceFee + (choices.technicalFee ?? 0))
    throw new Error('할인금액이 세탁 소계와 추가기술료·수거비의 합계를 초과할 수 없습니다.');
  return {
    id: input.id,
    payment_type: choices.paymentType ?? 'PREPAID',
    payment_status: choices.paymentType === 'POSTPAID' ? 'UNPAID' : 'PAID',
    status: '접수 확정',
    intakeAt: date.toISOString(),
    customerFolderName: folder,
    customerName: input.customerName.trim(),
    customerPhone: input.customerPhone.trim(),
    customerAddress: input.customerAddress.trim(),
    ...(input.directoryCustomerId && /^[a-f0-9]{64}$/.test(input.directoryCustomerId) ? { directoryCustomerId: input.directoryCustomerId } : {}),
    items,
    totalQuantity,
    choices: { ...choices, ...(override !== undefined ? { computedLaundryTotal } : {}), ...(choices.unitServiceLevels && { unitServiceLevels: choices.unitServiceLevels.map(row => [...row]) }),
      customerRequests: choices.customerRequests.trim() },
    laundryTotal,
    serviceFee,
    estimatedTotal: laundryTotal + serviceFee + (choices.technicalFee ?? 0) - (choices.discount ?? 0),
    feePolicy: { ...feePolicy },
  };
}

// The original synchronous contract is backed by SQLite via desktop-runtime.
export function readAllConfirmedOrders(): ConfirmedOrder[] {
  const raw = window.localStorage.getItem(ORDERS_STORAGE_KEY);
  const parsed: unknown = raw ? JSON.parse(raw) : [];
  if (!Array.isArray(parsed) || !parsed.every((item) => item && typeof item === 'object'
    && typeof item.id === 'string' && typeof item.customerFolderName === 'string'
    && typeof item.choices?.customerRequests === 'string')) {
    throw new Error('저장된 접수 기록을 읽을 수 없습니다.');
  }
  const orders = parsed as ConfirmedOrder[];
  let migrated = false;
  const materialized = orders.map((order) => {
    if (Array.isArray(order.garments) && order.garments.length > 0) return order;
    migrated = true;
    return { ...order, garments: createGarmentRecords(order) };
  });
  if (migrated) window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(materialized));
  return materialized;
}

/** All ordinary workflows share the same logical-delete boundary. */
export function readConfirmedOrders(): ConfirmedOrder[] {
  return readAllConfirmedOrders().filter(order => !isDeletedOrder(order));
}

export function readActiveConfirmedOrder(): ConfirmedOrder | null {
  const id = window.localStorage.getItem(ACTIVE_ORDER_KEY);
  return id ? readConfirmedOrders().find((order) => order.id === id) ?? null : null;
}

export function clearActiveConfirmedOrder(): void {
  window.localStorage.removeItem(ACTIVE_ORDER_KEY);
}

function ensureUnchanged(orders: ConfirmedOrder[], id: string, expected: ConfirmedOrder): void {
  if (expected.id !== id)
    throw new Error('수정 대상 주문 ID가 원본 주문과 다릅니다. 기록을 저장하지 않았습니다.');
  const stored = orders.find((item) => item.id === id);
  // A legacy snapshot may predate the one-time creation of deterministic garment records.
  // Only that precise migration is ignored; any real garment/order edit remains a conflict.
  const comparable = expected.garments?.length ? expected
    : { ...expected, garments: createGarmentRecords(expected) };
  if (!stored || (JSON.stringify(stored) !== JSON.stringify(expected) &&
      JSON.stringify(stored) !== JSON.stringify(comparable)))
    throw new Error('다른 화면에서 주문이 변경되었습니다. 새로 불러온 뒤 다시 확인해 주세요. 이전 기록은 덮어쓰지 않았습니다.');
}

function assertOrderOwnership(order: ConfirmedOrder, orders: ConfirmedOrder[]): void {
  const ids = new Set<string>();
  for (const garment of order.garments ?? []) {
    if (garment.orderId !== order.id || !garment.garmentId || ids.has(garment.garmentId)
      || garment.barcodeValue !== garment.garmentId
      || orders.some((other) => other.id !== order.id
        && other.garments?.some((item) => item.garmentId === garment.garmentId || item.barcodeValue === garment.barcodeValue)))
      throw new Error('주문·의류·바코드 ID 연결이 일치하지 않거나 다른 주문과 중복됩니다. 기존 기록은 변경하지 않았습니다.');
    ids.add(garment.garmentId);
    const photos = [...(garment.photoHistory ?? []), garment.beforePhoto, garment.completionPhoto].filter(Boolean);
    if (photos.some((photo) => photo!.garmentId !== garment.garmentId)
      || (garment.auditEvents ?? []).some((event) =>
        event.orderId && event.orderId !== order.id || event.garmentId && event.garmentId !== garment.garmentId))
      throw new Error('다른 주문 또는 의류의 사진·작업 이력이 연결되어 저장을 중지했습니다. 원본 기록은 보존했습니다.');
  }
  if ((order.scanAuditEvents ?? []).some((event) =>
    event.orderId && event.orderId !== order.id || event.garmentId && !ids.has(event.garmentId)))
    throw new Error('스캔 이력의 주문·의류 ID가 일치하지 않습니다. 원본 기록은 보존했습니다.');
}

function prepareOrderWrite(order: ConfirmedOrder, orders: ConfirmedOrder[], expected?: ConfirmedOrder): ConfirmedOrder {
  const stored = orders.filter((item) => item.id === order.id);
  if (stored.some(isDeletedOrder) || isDeletedOrder(order) ||
      JSON.stringify(order.orderDeletionAudit) !== JSON.stringify(stored[0]?.orderDeletionAudit))
    throw new Error('삭제 주문이나 관리자 감사 기록은 일반 업무에서 수정할 수 없습니다. 관리자 복구 메뉴를 이용하세요.');
  if (stored.length > 1) throw new Error('같은 주문 ID가 여러 기록에 있어 저장을 중지했습니다.');
  if (stored.length && !expected)
    throw new Error('기존 주문 수정에는 원본 주문 확인이 필요합니다. 새 접수로 덮어쓰지 않았습니다.');
  if (expected) {
    ensureUnchanged(orders, order.id, expected);
    if (order.intakeAt !== expected.intakeAt || order.customerFolderName !== expected.customerFolderName)
      throw new Error('기존 주문의 접수일시·원본 폴더는 새 접수로 변경할 수 없습니다.');
  }
  const saved = order.garments?.length ? order : { ...order, garments: createGarmentRecords(order) };
  assertOrderOwnership(saved, orders);
  return saved;
}

export function saveConfirmedOrder(order: ConfirmedOrder, expected?: ConfirmedOrder): void {
  const orders = readAllConfirmedOrders();
  const saved = prepareOrderWrite(order, orders, expected);
  window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders.some((item) => item.id === order.id)
    ? orders.map((item) => item.id === order.id ? saved : item) : [...orders, saved]));
  window.localStorage.setItem(ACTIVE_ORDER_KEY, order.id);
}

export function insertConfirmedOrder(order: ConfirmedOrder): void {
  if (readAllConfirmedOrders().some((item) => item.id === order.id))
    throw new Error('같은 접수번호가 이미 저장되어 있습니다. 접수를 새로 시작해 주세요.');
  saveConfirmedOrder(order);
}

export function updateSavedOrder(order: ConfirmedOrder, expected?: ConfirmedOrder): void {
  const orders = readAllConfirmedOrders();
  if (!orders.some((item) => item.id === order.id)) throw new Error('수정할 저장 주문을 찾지 못했습니다.');
  const saved = prepareOrderWrite(order, orders, expected);
  window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders.map((item) => item.id === order.id ? saved : item)));
}

export function resumeConfirmedOrder(id: string): ConfirmedOrder {
  const matches = readConfirmedOrders().filter((item) => item.id === id);
  if (matches.length !== 1) throw new Error('해당 주문번호의 저장된 접수 내역을 하나로 확인하지 못했습니다.');
  const order = matches[0];
  window.localStorage.setItem(ACTIVE_ORDER_KEY, order.id);
  return order;
}