import {
  createTagData, type GarmentAuditEvent, type GarmentPhotoMetadata, type GarmentRecord,
} from './garment-record.ts';
import type { ConfirmedOrder } from './order-record';
import type { PrinterOperationResult, TagPrinterAdapter } from './tag-printer';

export type CaptureProvider = {
  capture(
    orderId: string,
    garmentId: string,
    requestId: string,
  ): Promise<{ status: 'simulated' | 'saved'; photoPath?: string; photoTimestamp?: string }>;
};

export type GarmentAutomationResult = {
  status: 'completed' | 'debounced' | 'busy' | 'failed';
  garment?: GarmentRecord;
  error?: string;
};

export type GarmentAutomationOptions = {
  order: ConfirmedOrder;
  getGarments: () => GarmentRecord[];
  saveGarments: (updated: GarmentRecord[], previous: GarmentRecord[]) => void;
  capture: CaptureProvider;
  printer: TagPrinterAdapter;
  clock?: () => Date;
  idFactory?: () => string;
  debounceMs?: number;
  operator?: string;
};

function cloneGarment(garment: GarmentRecord): GarmentRecord {
  return {
    ...garment,
    beforePhoto: garment.beforePhoto ? { ...garment.beforePhoto,
      ...(garment.beforePhoto.annotations && { annotations: { ...garment.beforePhoto.annotations } }) } : undefined,
    completionPhoto: garment.completionPhoto ? { ...garment.completionPhoto,
      ...(garment.completionPhoto.annotations && { annotations: { ...garment.completionPhoto.annotations } }) } : undefined,
    photoHistory: garment.photoHistory?.map((photo) => ({ ...photo,
      ...(photo.annotations && { annotations: { ...photo.annotations } }) })),
    auditEvents: garment.auditEvents.map((event) => ({ ...event })),
  };
}

function photoMetadata(
  garment: GarmentRecord,
  role: 'intake' | 'completion',
  status: 'simulated' | 'saved',
  requestId: string,
  timestamp: string,
  path?: string,
): GarmentPhotoMetadata {
  return {
    garmentId: garment.garmentId,
    requestId,
    role,
    status,
    timestamp,
    origin: status === 'simulated' ? 'simulation' : 'bridge',
    ...(status === 'saved' && path ? { path } : {}),
  };
}

function legacyBeforePhoto(garment: GarmentRecord): GarmentPhotoMetadata | undefined {
  if (garment.photoStatus !== 'saved' && garment.photoStatus !== 'simulated') return undefined;
  return {
    garmentId: garment.garmentId,
    requestId: garment.captureRequestId ?? `legacy-${garment.garmentId}`,
    role: 'intake',
    status: garment.photoStatus,
    timestamp: garment.photoTimestamp ?? '',
    origin: 'legacy',
    ...(garment.photoStatus === 'saved' && garment.photoPath ? { path: garment.photoPath } : {}),
  };
}

function retainIntakePhoto(
  garment: GarmentRecord,
  status: 'simulated' | 'saved',
  requestId: string,
  timestamp: string,
  path?: string,
): void {
  const metadata = photoMetadata(garment, 'intake', status, requestId, timestamp, path);
  garment.beforePhoto ??= legacyBeforePhoto(garment) ?? metadata;
  garment.photoHistory = [...(garment.photoHistory ?? []), metadata];
}

export type SimulatedCompletionPhotoOptions = {
  at?: Date;
  requestId?: string;
  operator?: string;
};

/** Adds simulation-only after-photo metadata for one eligible permanent garment ID. */
export function recordSimulatedCompletionPhoto(
  garments: GarmentRecord[],
  garmentId: string,
  options: SimulatedCompletionPhotoOptions = {},
): GarmentRecord[] {
  const target = garments.find((garment) => garment.garmentId === garmentId);
  if (!target) throw new Error('완성 사진을 기록할 의류를 찾을 수 없습니다.');
  const processStatus = target.processStatus ??
    (target.completionStatus === 'complete' || target.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER'
      ? '출고 대기' : '');
  if (!['세탁 완료', '완성 검수', '출고 대기', '반출 완료'].includes(processStatus)) {
    throw new Error('세탁 완료 이후 상태의 의류만 완성 사진을 기록할 수 있습니다.');
  }
  const timestamp = (options.at ?? new Date()).toISOString();
  const requestId = options.requestId?.trim() ||
    globalThis.crypto?.randomUUID?.() || `${target.garmentId}-completion-${Date.parse(timestamp)}`;
  const photo: GarmentPhotoMetadata = {
    garmentId: target.garmentId,
    requestId,
    role: 'completion',
    status: 'simulated',
    timestamp,
    origin: 'simulation',
    path: `mock://k99/photos/${encodeURIComponent(target.garmentId)}/completion/${encodeURIComponent(requestId)}`,
  };
  const operator = options.operator?.trim() || '미지정 직원';
  return garments.map((garment) => garment.garmentId !== garmentId ? garment : {
    ...garment,
    completionPhoto: photo,
    photoHistory: [...(garment.photoHistory ?? []), photo],
    auditEvents: [...(garment.auditEvents ?? []), {
      at: timestamp,
      type: 'completion-photo',
      status: 'simulated',
      orderId: garment.orderId,
      garmentId: garment.garmentId,
      details: `${operator}: 완성 사진 시뮬레이션 기록 (실제 사진 파일 저장 안 함)`,
    }],
  });
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export class GarmentAutomation {
  private readonly order: ConfirmedOrder;
  private readonly getGarments: () => GarmentRecord[];
  private readonly saveGarments: (updated: GarmentRecord[], previous: GarmentRecord[]) => void;
  private readonly capture: CaptureProvider;
  private readonly printer: TagPrinterAdapter;
  private readonly clock: () => Date;
  private readonly idFactory: () => string;
  private readonly debounceMs: number;
  private readonly operator: string;
  private busy = false;
  private lastCaptureTriggerAt: number | undefined;

  constructor(options: GarmentAutomationOptions) {
    this.order = options.order;
    this.getGarments = options.getGarments;
    this.saveGarments = options.saveGarments;
    this.capture = options.capture;
    this.printer = options.printer;
    this.clock = options.clock ?? (() => new Date());
    this.idFactory = options.idFactory ?? (() => globalThis.crypto?.randomUUID?.()
      ?? `${this.order.id}-${this.clock().getTime()}-${Math.random().toString(36).slice(2)}`);
    this.debounceMs = options.debounceMs ?? 750;
    this.operator = options.operator?.trim() || '미지정 직원';
  }

  isBusy(): boolean {
    return this.busy;
  }

  async captureAndPrint(garmentId: string): Promise<GarmentAutomationResult> {
    if (this.busy) return { status: 'busy', error: '다른 촬영 또는 인쇄 작업이 진행 중입니다.' };
    const now = this.clock().getTime();
    if (this.lastCaptureTriggerAt !== undefined && now - this.lastCaptureTriggerAt < this.debounceMs) {
      return { status: 'debounced', error: '촬영 요청이 너무 빠릅니다. 잠시 후 다시 시도해 주세요.' };
    }

    this.busy = true;
    this.lastCaptureTriggerAt = now;
    try {
      const garments = this.getGarments();
      const current = garments.find((garment) => garment.tagStatus !== 'simulated' && garment.tagStatus !== 'printed');
      if (!current) return { status: 'failed', error: '촬영할 미처리 의류가 없습니다.' };

      // An earlier photo with a failed or pending print blocks the next garment; retry it instead.
      if (current.garmentId !== garmentId) {
        return {
          status: 'failed',
          garment: current,
          error: '현재 처리 순서의 의류 ID와 일치하지 않습니다.',
        };
      }

      if (current.photoStatus === 'saved' || current.photoStatus === 'simulated') {
        if (current.printRequestId &&
            (current.tagStatus === 'failed' || current.tagStatus === 'print-requested')) {
          return {
            status: 'failed',
            garment: current,
            error: '기존 인쇄 요청을 유지하려면 새 촬영 대신 인쇄 재시도를 사용해 주세요.',
          };
        }
        return await this.generateAndPrint(current, false);
      }

      // Reuse the same ID after an ambiguous failure. The Windows bridge must
      // deduplicate this ID rather than taking a second physical photo.
      const captureRequestId = current.photoStatus === 'failed' && current.captureRequestId
        ? current.captureRequestId : this.requireNewRequestId();
      this.persist(current.garmentId, (garment) => {
        garment.captureRequestId = captureRequestId;
        delete garment.lastError;
      });

      let captureResult: Awaited<ReturnType<CaptureProvider['capture']>>;
      try {
        captureResult = await this.capture.capture(this.order.id, current.garmentId, captureRequestId);
        if (!captureResult || (captureResult.status !== 'saved' && captureResult.status !== 'simulated') ||
            (captureResult.photoPath !== undefined && typeof captureResult.photoPath !== 'string') ||
            (captureResult.photoTimestamp !== undefined && typeof captureResult.photoTimestamp !== 'string')) {
          throw new Error('촬영 결과의 상태 또는 사진 정보가 올바르지 않습니다.');
        }
      } catch (error) {
        const message = errorMessage(error);
        const failed = this.persist(current.garmentId, (garment) => {
          garment.photoStatus = 'failed';
          garment.lastError = message;
          this.addAudit(garment, 'capture-error', 'failed', `${this.operator}: ${message}`);
        });
        return { status: 'failed', garment: failed, error: message };
      }

      const photoTime = captureResult.photoTimestamp ?? this.clock().toISOString();
      const captured = this.persist(current.garmentId, (garment) => {
        garment.photoStatus = captureResult.status;
        if (captureResult.status === 'saved' && captureResult.photoPath) {
          garment.photoPath = captureResult.photoPath;
        } else {
          delete garment.photoPath;
        }
        garment.photoTimestamp = photoTime;
        retainIntakePhoto(garment, captureResult.status, captureRequestId, photoTime, captureResult.photoPath);
        delete garment.lastError;
        this.addAudit(garment, 'photo-captured', captureResult.status,
          captureResult.status === 'simulated'
            ? `${this.operator}: 촬영 시뮬레이션 완료 (실제 사진 저장 안 함)`
            : `${this.operator}: 사진 저장 완료`);
      });
      return await this.generateAndPrint(captured, false);
    } catch (error) {
      return { status: 'failed', error: errorMessage(error) };
    } finally {
      this.busy = false;
    }
  }

  async retryPrint(garmentId: string): Promise<GarmentAutomationResult> {
    if (this.busy) return { status: 'busy', error: '다른 촬영 또는 인쇄 작업이 진행 중입니다.' };
    this.busy = true;
    try {
      const garment = this.getGarments().find((item) => item.garmentId === garmentId);
      if (!garment) return { status: 'failed', error: '다시 인쇄할 의류를 찾을 수 없습니다.' };
      if (garment.photoStatus !== 'saved' && garment.photoStatus !== 'simulated') {
        return { status: 'failed', garment, error: '저장 또는 시뮬레이션된 접수 사진이 없어 인쇄를 재시도할 수 없습니다.' };
      }
      if (!garment.printRequestId || !garment.tagGeneratedAt ||
          (garment.tagStatus !== 'failed' && garment.tagStatus !== 'print-requested')) {
        return { status: 'failed', garment, error: '재시도할 미완료 인쇄 요청이 없습니다.' };
      }
      const isReprint = garment.auditEvents.some((event) =>
        event.type === 'reprint' && event.details?.includes(`requestId=${garment.printRequestId}`));
      const requestId = garment.printRequestId;
      const requested = this.persist(garmentId, (record) => {
        record.tagStatus = 'print-requested';
        record.tagPrintRequestedAt = this.clock().toISOString();
        delete record.lastError;
        this.addAudit(record, 'print-requested', 'retry-requested',
          `${this.operator}: 기존 요청 재시도; requestId=${requestId}`);
      });
      return await this.submitPrint(requested, requestId, isReprint, true);
    } catch (error) {
      return { status: 'failed', error: errorMessage(error) };
    } finally {
      this.busy = false;
    }
  }

  async retakePhoto(garmentId: string): Promise<GarmentAutomationResult> {
    if (this.busy) return { status: 'busy', error: '다른 촬영 또는 인쇄 작업이 진행 중입니다.' };
    this.busy = true;
    try {
      const garment = this.getGarments().find((item) => item.garmentId === garmentId);
      if (!garment) return { status: 'failed', error: '사진을 다시 촬영할 의류를 찾을 수 없습니다.' };
      if (garment.photoStatus !== 'saved' && garment.photoStatus !== 'simulated') {
        return { status: 'failed', garment, error: '기존 접수 사진이 있는 의류만 다시 촬영할 수 있습니다.' };
      }

      const requestId = this.requireNewRequestId();
      this.persist(garmentId, (record) => {
        record.beforePhoto ??= legacyBeforePhoto(record);
        record.captureRequestId = requestId;
        delete record.lastError;
      });

      let captureResult: Awaited<ReturnType<CaptureProvider['capture']>>;
      try {
        captureResult = await this.capture.capture(this.order.id, garmentId, requestId);
        if (!captureResult || (captureResult.status !== 'saved' && captureResult.status !== 'simulated') ||
            (captureResult.photoPath !== undefined && typeof captureResult.photoPath !== 'string') ||
            (captureResult.photoTimestamp !== undefined && typeof captureResult.photoTimestamp !== 'string')) {
          throw new Error('촬영 결과의 상태 또는 사진 정보가 올바르지 않습니다.');
        }
      } catch (error) {
        const message = errorMessage(error);
        const failed = this.persist(garmentId, (record) => {
          record.lastError = message;
          this.addAudit(record, 'capture-error', 'retake-failed', `${this.operator}: ${message}`);
        });
        return { status: 'failed', garment: failed, error: message };
      }

      const retaken = this.persist(garmentId, (record) => {
        record.photoStatus = captureResult.status;
        if (captureResult.status === 'saved' && captureResult.photoPath) {
          record.photoPath = captureResult.photoPath;
        } else {
          delete record.photoPath;
        }
        const timestamp = captureResult.photoTimestamp ?? this.clock().toISOString();
        record.photoTimestamp = timestamp;
        retainIntakePhoto(record, captureResult.status, requestId, timestamp, captureResult.photoPath);
        delete record.lastError;
        this.addAudit(record, 'photo-captured', captureResult.status,
          captureResult.status === 'simulated'
            ? `${this.operator}: 재촬영 시뮬레이션 완료 (실제 사진 저장 안 함)`
            : `${this.operator}: 접수 사진 재촬영 및 저장 완료`);
      });
      return { status: 'completed', garment: retaken };
    } catch (error) {
      return { status: 'failed', error: errorMessage(error) };
    } finally {
      this.busy = false;
    }
  }

  async reprint(garmentId: string): Promise<GarmentAutomationResult> {
    if (this.busy) return { status: 'busy', error: '다른 촬영 또는 인쇄 작업이 진행 중입니다.' };
    this.busy = true;
    try {
      const garment = this.getGarments().find((item) => item.garmentId === garmentId);
      if (!garment) return { status: 'failed', error: '다시 인쇄할 의류를 찾을 수 없습니다.' };
      if (garment.tagStatus !== 'printed' && garment.tagStatus !== 'simulated') {
        return { status: 'failed', garment, error: '인쇄 완료된 태그만 재인쇄할 수 있습니다.' };
      }
      const requestId = this.requireNewRequestId();
      const requestedAt = this.clock().toISOString();
      const ready = this.persist(garmentId, (record) => {
        record.printRequestId = requestId;
        record.tagPrintRequestedAt = requestedAt;
        record.tagStatus = 'print-requested';
        delete record.lastError;
        this.addAudit(record, 'reprint', 'requested',
          `${this.operator}: requestId=${requestId}; garmentId=${garmentId}`);
      });
      return await this.submitPrint(ready, requestId, true, false);
    } catch (error) {
      return { status: 'failed', error: errorMessage(error) };
    } finally {
      this.busy = false;
    }
  }

  private async generateAndPrint(
    garment: GarmentRecord,
    _isReprint: boolean,
  ): Promise<GarmentAutomationResult> {
    let prepared = garment;
    if (!prepared.tagGeneratedAt) {
      try {
        createTagData(this.order, prepared);
        const generatedAt = this.clock().toISOString();
        prepared = this.persist(prepared.garmentId, (record) => {
          record.tagStatus = 'generated';
          record.tagGeneratedAt = generatedAt;
          delete record.lastError;
          this.addAudit(record, 'tag-generated', 'generated', `${this.operator}: 태그 데이터 생성`);
        });
      } catch (error) {
        const message = errorMessage(error);
        const failed = this.persist(prepared.garmentId, (record) => {
          record.tagStatus = 'failed';
          record.lastError = message;
          this.addAudit(record, 'print-error', 'tag-generation-failed', `${this.operator}: ${message}`);
        });
        return { status: 'failed', garment: failed, error: message };
      }
    }

    const requestId = this.requireNewRequestId();
    const requestedAt = this.clock().toISOString();
    const requested = this.persist(prepared.garmentId, (record) => {
      record.printRequestId = requestId;
      record.tagPrintRequestedAt = requestedAt;
      record.tagStatus = 'print-requested';
      delete record.lastError;
      this.addAudit(record, 'print-requested', 'requested',
        `${this.operator}: requestId=${requestId}`);
    });
    return this.submitPrint(requested, requestId, false, false);
  }

  private async submitPrint(
    garment: GarmentRecord,
    requestId: string,
    reprint: boolean,
    retry: boolean,
  ): Promise<GarmentAutomationResult> {
    try {
      const tagData = createTagData(this.order, garment);
      // Local Bridge must deduplicate every ambiguous print failure using this same requestId.
      const response = reprint
        ? await this.printer.reprintGarmentTag(tagData, requestId)
        : await this.printer.printGarmentTag(tagData, requestId);
      this.validatePrintResponse(response, requestId, garment);
      const completed = this.persist(garment.garmentId, (record) => {
        record.tagStatus = response.status === 'printed' ? 'printed' : 'simulated';
        if (response.status === 'printed') {
          record.tagPrintedAt = this.clock().toISOString();
          record.tagPrintCount += 1;
        }
        delete record.lastError;
        this.addAudit(record, 'tag-printed', response.status,
          response.status === 'simulated'
            ? `${this.operator}: 인쇄 시뮬레이션 완료 (실제 태그 인쇄 안 함); requestId=${requestId}`
            : `${this.operator}: 태그 인쇄 완료; requestId=${requestId}`);
      });
      return { status: 'completed', garment: completed };
    } catch (error) {
      const message = errorMessage(error);
      const failed = this.persist(garment.garmentId, (record) => {
        record.tagStatus = 'failed';
        record.lastError = message;
        this.addAudit(record, 'print-error', 'failed',
          `${this.operator}: ${retry ? '인쇄 재시도' : reprint ? '재인쇄' : '인쇄'} 실패; requestId=${requestId}; ${message}`);
      });
      return { status: 'failed', garment: failed, error: message };
    }
  }

  private validatePrintResponse(
    response: PrinterOperationResult,
    requestId: string,
    garment: GarmentRecord,
  ): void {
    if (!response || (response.status !== 'printed' && response.status !== 'simulated') ||
        response.requestId !== requestId ||
        (response.orderId !== undefined && response.orderId !== this.order.id) ||
        (response.garmentId !== undefined && response.garmentId !== garment.garmentId)) {
      throw new Error('프린터 응답의 상태 또는 요청 식별자가 일치하지 않습니다.');
    }
  }

  private persist(garmentId: string, update: (garment: GarmentRecord) => void): GarmentRecord {
    const previous = this.getGarments().map(cloneGarment);
    let updatedGarment: GarmentRecord | undefined;
    const updated = previous.map((garment) => {
      if (garment.garmentId !== garmentId) return garment;
      const next = cloneGarment(garment);
      update(next);
      updatedGarment = next;
      return next;
    });
    if (!updatedGarment) throw new Error(`의류 기록을 찾을 수 없습니다: ${garmentId}`);
    this.saveGarments(updated, previous.map(cloneGarment));
    return cloneGarment(updatedGarment);
  }

  private addAudit(
    garment: GarmentRecord,
    type: GarmentAuditEvent['type'],
    status: string,
    details: string,
  ): void {
    garment.auditEvents.push({ at: this.clock().toISOString(), type, status, details });
  }

  private requireNewRequestId(): string {
    const requestId = this.idFactory();
    if (typeof requestId !== 'string' || !requestId.trim()) {
      throw new Error('요청 식별자를 만들 수 없습니다.');
    }
    return requestId.trim();
  }
}