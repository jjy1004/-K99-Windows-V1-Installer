import { useEffect, useRef, useState, type KeyboardEvent, type MouseEvent } from 'react';
import { openIntegration, readIntegrationSettings, subscribeLuxuryResult, type IntegrationSettings, type LuxuryResult } from './program-integrations';
import { LaundryDiary } from './LaundryDiary';
import './program-launchers.css';

type Props = { material: string; color: string; onApply: (result: LuxuryResult) => void; locked?: boolean };
type Notice = { kind: 'info' | 'error'; text: string; recovery?: boolean } | null;

const safeRead = (): IntegrationSettings => {
  try { return readIntegrationSettings(); } catch { return { luxuryTarget: '', prescriptionUrl: '' }; }
};
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);

export function ProgramLaunchers({ material, color, onApply, locked = false }: Props) {
  const [settings, setSettings] = useState<IntegrationSettings>(safeRead);
  const [notice, setNotice] = useState<Notice>(null);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<{ itemName: string; price: string; source: 'auto' | 'manual' } | null>(null);
  const [formError, setFormError] = useState('');
  const [diaryOpen, setDiaryOpen] = useState(false);
  const lockedRef = useRef(locked);
  lockedRef.current = locked;
  const firstInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const on = () => setSettings(safeRead());
    window.addEventListener('k99:program-integrations-changed', on);
    return () => window.removeEventListener('k99:program-integrations-changed', on);
  }, []);

  useEffect(() => {
    const unsub = subscribeLuxuryResult(result => {
      if (lockedRef.current) {
        setNotice({ kind: 'error', text: '세탁비 결과를 받았지만 지금은 접수에 추가할 수 없습니다. 접수 화면을 확인한 뒤 수동 입력하세요.' });
        return;
      }
      setFormError('');
      setDraft({ itemName: result.itemName ?? '', price: String(result.finalPrice ?? ''), source: 'auto' });
    });
    return () => unsub();
  }, []);

  useEffect(() => { if (draft) firstInput.current?.focus(); }, [draft]);

  const aiReady = settings.prescriptionUrl.trim() !== '';
  const label = { material, color };

  async function launchLuxury() {
    if (busy) return;
    setNotice(null);
    if (!settings.luxuryTarget.trim()&&!window.k99Desktop?.openProgram) {
      setNotice({ kind: 'error', text: '명품 세탁비 산정 프로그램 경로가 설정되지 않았습니다.', recovery: true });
      return;
    }
    setBusy(true);
    try {
      await openIntegration('luxury', label);
      setNotice({ kind: 'info', text: '명품 세탁비 산정 프로그램 실행을 요청했습니다. 결과가 오면 확인 창이 열립니다.' });
    } catch (e) {
      setNotice({ kind: 'error', text: `실행 실패: ${errText(e, '프로그램을 열 수 없습니다.')}`, recovery: true });
    } finally { setBusy(false); }
  }

  async function launchAi() {
    setNotice(null);
    if (!aiReady) { setNotice({ kind: 'info', text: 'AI 세탁 처방은 추후 연동 예정입니다.' }); return; }
    try { await openIntegration('prescription', label); }
    catch (e) { setNotice({ kind: 'error', text: `AI 세탁 처방 열기 실패: ${errText(e, '주소를 열 수 없습니다.')}` }); }
  }

  function openManual() {
    if (locked) { setNotice({ kind: 'error', text: '지금은 접수에 결과를 추가할 수 없습니다.' }); return; }
    setFormError(''); setDraft({ itemName: '', price: '', source: 'manual' });
  }

  function close(e?: MouseEvent | KeyboardEvent) { e?.stopPropagation(); setDraft(null); setFormError(''); }

  function confirm() {
    if (!draft) return;
    if (locked) { setFormError('지금은 접수에 추가할 수 없습니다.'); return; }
    const itemName = draft.itemName.trim();
    const p = draft.price.trim();
    if (!itemName || itemName.length > 100 || /[\u0000-\u001f]/.test(itemName)) { setFormError('품목명을 100자 이내로 입력하세요.'); return; }
    if (!/^\d+$/.test(p)) { setFormError('최종 세탁비는 정수(원)로 입력하세요.'); return; }
    const finalPrice = Number(p);
    if (!Number.isSafeInteger(finalPrice) || finalPrice < 1 || finalPrice > 100000000) { setFormError('기존 접수 규격에 맞게 1원~1억 원의 정수로 입력하세요.'); return; }
    try { onApply({ itemName, finalPrice }); }
    catch (error) { setFormError(errText(error, '접수에 추가하지 못했습니다.')); return; }
    setDraft(null);
    setNotice({ kind: 'info', text: `${itemName} · ${finalPrice.toLocaleString('ko-KR')}원을 접수에 추가했습니다.` });
  }

  return (
    <div className="pgl-wrap" data-testid="program-launchers">
      <div className="pgl-grid">
        <button type="button" className="pgl-btn pgl-luxury" onClick={() => void launchLuxury()} aria-busy={busy} data-testid="button-luxury-launch">
          <span className="pgl-ico" aria-hidden="true">💎</span>
          <span className="pgl-txt">명품 세탁비 산정<span className="pgl-sub">{busy ? '실행 중…' : settings.luxuryTarget ? '계산기 열기' : window.k99Desktop?.openProgram?'폴더 자동 탐색':'경로 미설정'}</span></span>
        </button>
        <button type="button" className="pgl-btn pgl-ai" aria-disabled={!aiReady} onClick={() => void launchAi()} data-testid="button-ai-prescription">
          <span className="pgl-ico" aria-hidden="true">🧪</span>
          <span className="pgl-txt">AI 세탁 처방<span className="pgl-sub">{aiReady ? '처방 열기' : '준비 중'}</span></span>
        </button>
        <button type="button" className="pgl-btn pgl-diary" onClick={() => setDiaryOpen(true)} aria-haspopup="dialog" data-testid="button-laundry-diary">
          <span className="pgl-ico pgl-diary-mark" aria-hidden="true" />
          <span className="pgl-txt">나의 세탁 일기<span className="pgl-sub">쓰기 · 찾기</span></span>
        </button>
      </div>
      {diaryOpen && <LaundryDiary onClose={() => setDiaryOpen(false)} />}
      <div className="pgl-actions">
        <button type="button" className="pgl-mini" disabled={locked} onClick={openManual} data-testid="button-luxury-result-entry">계산 결과 입력</button>
      </div>
      {notice && (
        <div className={`pgl-note${notice.kind === 'error' ? ' is-error' : ''}`} role={notice.kind === 'error' ? 'alert' : 'status'} data-testid="text-launcher-notice">
          {notice.text}
          {notice.recovery && <div className="pgl-actions">
            <span>유지보수 화면의 ‘외부 프로그램 연동’에서 경로를 설정하세요.</span>
            <button type="button" className="pgl-mini is-primary" disabled={locked} onClick={openManual} data-testid="button-luxury-manual">수동 결과 입력</button>
          </div>}
        </div>
      )}
      {draft && (
        <div className="pgl-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) close(e); }}>
          <div className="pgl-modal" role="dialog" aria-modal="true" aria-labelledby="pgl-dlg-title"
            onKeyDown={e => { if (e.key === 'Escape') { e.preventDefault(); close(e); } }} data-testid="dialog-luxury-confirm">
            <h2 id="pgl-dlg-title">세탁비 결과 확인</h2>
            <p>{draft.source === 'auto' ? '계산기에서 받은 결과입니다. 확인 후 접수에 추가하세요.' : '계산 결과를 직접 입력하세요.'}</p>
            <label className="pgl-field">품목명
              <input ref={firstInput} maxLength={100} value={draft.itemName} onChange={e => setDraft({ ...draft, itemName: e.target.value })} data-testid="input-luxury-item" />
            </label>
            <label className="pgl-field">최종 세탁비(원)
              <input inputMode="numeric" value={draft.price} onChange={e => setDraft({ ...draft, price: e.target.value.replace(/[^\d]/g, '') })}
                onKeyDown={e => { if (e.key === 'Enter') confirm(); }} data-testid="input-luxury-price" />
            </label>
            {formError && <div className="pgl-err" role="alert">{formError}</div>}
            <div className="pgl-modal-actions">
              <button type="button" className="pgl-mini" onClick={e => close(e)} data-testid="button-luxury-cancel">닫기</button>
              <button type="button" className="pgl-mini is-primary" disabled={locked} onClick={confirm} data-testid="button-luxury-apply">접수에 추가</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProgramLaunchers;
