import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';

export type ManagementExportSnapshot = {
  format: 'k99-management-backup';
  schemaVersion: 1;
  orders: ConfirmedOrder[];
};

export type ManagementExport = {
  snapshot: ManagementExportSnapshot;
  json: string;
  csv: {
    customers: string;
    orders: string;
    garments: string;
  };
};

type CsvValue = string | number | boolean | null | undefined | object;

function jsonCell(value: unknown): string {
  if (value === null || value === undefined) return '';
  return typeof value === 'string' ? value : JSON.stringify(value) ?? '';
}

function protectFormula(value: string): string {
  // Spreadsheet applications may ignore leading whitespace before formula markers.
  return /^[\s\uFEFF]*[=+\-@]/u.test(value) ? `'${value}` : value;
}

function csvCell(value: CsvValue): string {
  const safe = protectFormula(jsonCell(value));
  return /[",\r\n]/u.test(safe) ? `"${safe.replace(/"/gu, '""')}"` : safe;
}

function csv(headers: string[], rows: CsvValue[][]): string {
  return [headers, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
}

function customerCsv(orders: readonly ConfirmedOrder[]): string {
  const customers = new Map<string, {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    orders: string[];
  }>();

  for (const order of orders) {
    const digits = (order.customerPhone ?? '').replace(/\D/gu, '');
    const key = digits || `order:${order.id}`;
    const customer = customers.get(key) ?? {
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerAddress: order.customerAddress,
      orders: [],
    };
    customer.orders.push(order.id);
    customers.set(key, customer);
  }

  return csv(
    ['customerId', 'customerName', 'customerPhone', 'customerAddress', 'orderCount', 'orderIds'],
    [...customers].map(([customerId, customer]) => [
      customerId, customer.customerName, customer.customerPhone, customer.customerAddress,
      customer.orders.length, customer.orders,
    ]),
  );
}

function orderCsv(orders: readonly ConfirmedOrder[]): string {
  const headers = [
    'orderId', 'status', 'intakeAt', 'customerFolderName', 'customerName', 'customerPhone',
    'customerAddress', 'totalQuantity', 'serviceLevel', 'items',
    'laundryTotal', 'serviceFee', 'technicalFee', 'discount', 'estimatedTotal',
    'paymentStatus', 'actualPaidAmount', 'paidAt',
    'inspection', 'approvals', 'laundryAndRewashHistory', 'pickupDelivery', 'handover',
    'photos', 'annotations', 'auditHistory', 'orderHistory',
  ];
  return csv(headers, orders.map((order) => {
    const garments = order.garments ?? [];
    const photoRecords = garments.map((garment) => ({
      garmentId: garment.garmentId,
      photoStatus: garment.photoStatus,
      captureRequestId: garment.captureRequestId,
      photoPath: garment.photoPath,
      photoTimestamp: garment.photoTimestamp,
      beforePhoto: garment.beforePhoto,
      completionPhoto: garment.completionPhoto,
      photoHistory: garment.photoHistory,
      representativeBeforePhotoId: garment.representativeBeforePhotoId,
    }));
    const annotationRecords = garments.map((garment) => ({
      garmentId: garment.garmentId,
      photoAnnotations: (garment.photoHistory ?? []).flatMap((photo) =>
        photo.annotations ? [{ requestId: photo.requestId, annotations: photo.annotations }] : []),
      annotationRevisions: garment.annotationRevisions,
    }));
    const auditRecords = garments.flatMap((garment) => garment.auditEvents ?? []);
    const operations = order.operations;
    return [
      order.id, order.status, order.intakeAt, order.customerFolderName, order.customerName,
      order.customerPhone, order.customerAddress, order.totalQuantity, order.choices.serviceLevel,
      order.items, order.laundryTotal, order.serviceFee, order.choices.technicalFee ?? 0,
      order.choices.discount ?? 0, order.estimatedTotal,
      operations?.paymentStatus, operations?.paidAmount, operations?.paidAt,
      order.inspection,
      order.inspection ? {
        requirements: order.inspection.approvalRequirements,
        response: order.inspection.response,
        stagedApproval: order.inspection.stagedApproval,
        itemNotice: order.inspection.itemNotice,
      } : null,
      garments.map((garment) => ({
        garmentId: garment.garmentId,
        processStatus: garment.processStatus,
        processUpdatedAt: garment.processUpdatedAt,
        cleaningStatus: garment.cleaningStatus,
        rewashCount: garment.rewashCount,
        careProcesses: garment.careProcesses,
        auditEvents: garment.auditEvents?.filter((event) =>
          event.type === 'laundry-process' || /rewash|재세탁/iu.test(`${event.type} ${event.action ?? ''} ${event.details ?? ''}`)),
      })),
      operations ? {
        requested: {
          pickup: order.choices.pickupRequested,
          delivery: order.choices.deliveryRequested,
          directPickup: order.choices.directPickup,
          requestedPickupDate: order.choices.requestedPickupDate,
        },
        ...operations,
      } : {
        pickup: order.choices.pickupRequested,
        delivery: order.choices.deliveryRequested,
        directPickup: order.choices.directPickup,
        requestedPickupDate: order.choices.requestedPickupDate,
      },
      garments.map((garment) => ({
        garmentId: garment.garmentId,
        handoverStatus: garment.handoverStatus,
        processStatus: garment.processStatus,
        completedAt: garment.completedAt,
        orderStage: operations?.stage,
        auditEvents: garment.auditEvents?.filter((event) => event.type === 'handover'),
      })),
      photoRecords, annotationRecords, auditRecords, order.history,
    ];
  }));
}

function garmentCsv(orders: readonly ConfirmedOrder[]): string {
  const headers = [
    'orderId', 'customerName', 'customerPhone', 'intakeAt', 'orderStatus', 'orderEstimatedTotal',
    'orderActualPaidAmount', 'orderPaymentStatus', 'garmentId', 'sequence', 'itemIndex',
    'itemType', 'itemName', 'serviceType', 'unitPriceAtIntake', 'photoStatus', 'beforePhoto',
    'completionPhoto', 'photoHistory', 'annotationRevisions', 'tagStatus', 'barcodeValue',
    'inspectionStatus', 'cleaningStatus', 'processStatus', 'processUpdatedAt', 'rewashCount',
    'completionStatus', 'completedAt', 'handoverStatus', 'pickupDelivery', 'auditEvents',
  ];

  const rows: CsvValue[][] = [];
  for (const order of orders) {
    for (const garment of order.garments ?? []) {
      const item = order.items[garment.itemIndex - 1];
      const premiumService = garment.serviceType === 'premium' || garment.serviceType === 'sneaker-premium';
      const unitPriceAtIntake = item ? (premiumService ? item.premiumPrice : item.generalPrice) : undefined;
      rows.push([
        order.id, order.customerName, order.customerPhone, order.intakeAt, order.status,
        order.estimatedTotal, order.operations?.paidAmount, order.operations?.paymentStatus,
        garment.garmentId, garment.sequence, garment.itemIndex, garment.itemType, garment.itemName,
        garment.serviceType, unitPriceAtIntake, garment.photoStatus, garment.beforePhoto,
        garment.completionPhoto, garment.photoHistory, garment.annotationRevisions, garment.tagStatus,
        garment.barcodeValue, garment.inspectionStatus, garment.cleaningStatus, garment.processStatus,
        garment.processUpdatedAt, garment.rewashCount, garment.completionStatus, garment.completedAt,
        garment.handoverStatus, order.operations ? {
          stage: order.operations.stage,
          pickupDate: order.operations.pickupDate,
          pickupTime: order.operations.pickupTime,
          deliveryDate: order.operations.deliveryDate,
          deliveryTime: order.operations.deliveryTime,
        } : {
          requestedPickupDate: order.choices.requestedPickupDate,
          pickupRequested: order.choices.pickupRequested,
          deliveryRequested: order.choices.deliveryRequested,
          directPickup: order.choices.directPickup,
        }, garment.auditEvents,
      ]);
    }
  }
  return csv(headers, rows);
}

/**
 * Build a browser-local portable export representation. This function only reads its
 * input; it does not access storage, perform network requests, or write files.
 */
export function createManagementExport(orders: ConfirmedOrder[]): ManagementExport {
  const snapshot: ManagementExportSnapshot = {
    format: 'k99-management-backup',
    schemaVersion: 1,
    orders: JSON.parse(JSON.stringify(orders)) as ConfirmedOrder[],
  };
  return {
    snapshot,
    json: JSON.stringify(snapshot, null, 2),
    csv: {
      customers: customerCsv(orders),
      orders: orderCsv(orders),
      garments: garmentCsv(orders),
    },
  };
}