export type CameraView = { zoom: number; cx: number; cy: number };
export const INITIAL_CAMERA_VIEW: CameraView = { zoom: 1, cx: 0.5, cy: 0.5 };
export const clampZoom = (zoom: number) => Math.min(3.5, Math.max(1, zoom));
const bound = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));

/** The same object-fit:cover rectangle drives BOTH live video and saved pixels. */
export function cameraCrop(sw: number, sh: number, vw: number, vh: number, view: CameraView) {
  if (!(sw > 0 && sh > 0 && vw > 0 && vh > 0)) throw new Error('카메라 영상 크기가 준비되지 않았습니다.');
  const zoom = clampZoom(view.zoom), aspect = vw / vh;
  const baseWidth = Math.min(sw, sh * aspect), baseHeight = baseWidth / aspect;
  const width = baseWidth / zoom, height = baseHeight / zoom;
  const cx = zoom === 1 ? sw / 2 : bound(view.cx * sw, width / 2, sw - width / 2);
  const cy = zoom === 1 ? sh / 2 : bound(view.cy * sh, height / 2, sh - height / 2);
  return { x: cx - width / 2, y: cy - height / 2, width, height, baseWidth, baseHeight };
}
export function panCamera(view: CameraView, dx: number, dy: number, sw: number, sh: number, vw: number, vh: number): CameraView {
  if (view.zoom <= 1) return { ...INITIAL_CAMERA_VIEW };
  const crop = cameraCrop(sw, sh, vw, vh, view);
  const moved = cameraCrop(sw, sh, vw, vh, { ...view,
    cx: (crop.x + crop.width / 2 - dx * crop.width / vw) / sw,
    cy: (crop.y + crop.height / 2 - dy * crop.height / vh) / sh });
  return { zoom: view.zoom, cx: (moved.x + moved.width / 2) / sw, cy: (moved.y + moved.height / 2) / sh };
}
export function drawCameraView(context: CanvasRenderingContext2D, video: HTMLVideoElement,
  vw: number, vh: number, view: CameraView) {
  const crop = cameraCrop(video.videoWidth, video.videoHeight, vw, vh, view);
  context.canvas.width = Math.max(1, Math.round(crop.baseWidth));
  context.canvas.height = Math.max(1, Math.round(crop.baseHeight));
  context.imageSmoothingEnabled = true; context.imageSmoothingQuality = 'high';
  context.drawImage(video, crop.x, crop.y, crop.width, crop.height, 0, 0, context.canvas.width, context.canvas.height);
}
/** Independent of OS key-repeat. Every input source shares one hold interval. */
export function createZoomHold(options: {
  now: () => number; request: (callback: FrameRequestCallback) => number; cancel: (id: number) => void;
  increase: (delta: number) => void; tap: () => void;
}) {
  const sources = new Set<string>();
  let began = 0, last = 0, frame: number | null = null;
  const tick = () => {
    if (!sources.size) return;
    const now = options.now();
    if (now > began + 200) {
      options.increase(Math.max(0, now - Math.max(last, began + 200)) / 1000);
    }
    last = now; frame = options.request(tick);
  };
  const cancel = () => {
    if (frame !== null) options.cancel(frame);
    frame = null; sources.clear();
  };
  return {
    start(source: string) {
      if (sources.has(source)) return;
      if (!sources.size) { began = options.now(); last = began; frame = options.request(tick); }
      sources.add(source);
    },
    end(source: string) {
      if (!sources.delete(source) || sources.size) return;
      const short = options.now() - began < 200;
      cancel(); if (short) options.tap();
    },
    cancel,
  };
}
