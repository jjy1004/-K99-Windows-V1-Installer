import { useCallback, useEffect, useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { CATALOG_DEFAULTS, groupByCategory, premiumFor, PREMIUM_SURCHARGE, SHIRT_PREMIUM_PRICE, type CatalogEntry } from './price-catalog';
import { readSharedCatalog, saveSharedCatalog, sharedPriceRevision } from './shared-price-catalog';
import { Modal } from './PickupNoticeActions';
import './management-directory.css';

type Phase = 'loading' | 'ready' | 'error' | 'saving' | 'saveFailed';
const editable = (e: CatalogEntry) => !e.legacy && !e.derivedFrom && !e.custom;
const won = (v: number | null) => (v === null || !Number.isFinite(v) ? '-' : `${v.toLocaleString('ko-KR')}원`);
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);

/** Parses a draft price; returns null for anything that is not a valid whole-won amount. */
function parsePrice(id: string, raw: string): { value: number | null; error: string } {
  const t = raw.replace(/[,\s원]/g, '');
  if (!t) return { value: null, error: '금액을 입력하세요.' };
  if (!/^\d+$/.test(t)) return { value: null, error: '숫자만 입력하세요.' };
  const n = Number(t);
  if (!Number.isSafeInteger(n) || n < 1 || n > 100_000_000) return { value: null, error: '1원 ~ 1억 원' };
  if (id === 'shirt_dress' && n > SHIRT_PREMIUM_PRICE) return { value: null, error: '9,000원 이하' };
  return { value: n, error: '' };
}

export function ManagementPriceEditor({ onClose }: { onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>('loading');
  const [catalog, setCatalog] = useState<CatalogEntry[]>([]);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');
  const [okMsg, setOkMsg] = useState('');
  const [loadedRevision, setLoadedRevision] = useState<number | null>(null);
  const seq = useRef(0);
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const load = useCallback(() => {
    const id = ++seq.current;
    setPhase('loading'); setMsg(''); setOkMsg('');
    readSharedCatalog(CATALOG_DEFAULTS).then((c) => {
      if (!alive.current || id !== seq.current) return;
      setCatalog(c);
      setLoadedRevision(sharedPriceRevision());
      setDrafts(Object.fromEntries(c.filter(editable).map((e) => [e.id, String(e.generalPrice)])));
      setPhase('ready');
    }).catch((e) => {
      if (!alive.current || id !== seq.current) return;
      setCatalog([]); setLoadedRevision(null); setPhase('error'); setMsg(errText(e, '가격표를 불러오지 못했습니다.'));
    });
  }, []);
  useEffect(() => { load(); }, [load]);

  const parsed = Object.fromEntries(catalog.filter(editable).map((e) => [e.id, parsePrice(e.id, drafts[e.id] ?? '')]));
  const invalid = Object.values(parsed).filter((p) => p.error).length;
  const changed = catalog.filter(editable).filter((e) => parsed[e.id]?.value !== e.generalPrice).length;
  const canSave = phase === 'ready' && invalid === 0 && changed > 0 && loadedRevision !== null;
  const dirty = changed > 0 && phase !== 'loading';

  const save = async () => {
    if (!canSave) return;
    // Use the revision belonging to THIS draft, not a newer global cache revision.
    const rev = loadedRevision;
    const entries = catalog.map((e) => (editable(e) && parsed[e.id]?.value != null
      ? { ...e, generalPrice: parsed[e.id].value as number, premiumPrice: premiumFor(e.id, parsed[e.id].value as number) } : e));
    setPhase('saving'); setMsg(''); setOkMsg('');
    try {
      const c = await saveSharedCatalog(CATALOG_DEFAULTS, entries, '', rev);
      if (!alive.current) return;
      setCatalog(c);
      setLoadedRevision(sharedPriceRevision());
      setDrafts(Object.fromEntries(c.filter(editable).map((e) => [e.id, String(e.generalPrice)])));
      setPhase('ready'); setOkMsg(`저장했습니다. 새 접수 화면에 바로 반영됩니다. (가격표 버전 ${sharedPriceRevision() ?? '-'})`);
    } catch (e) {
      if (!alive.current) return;
      // No automatic retry: the server may hold a newer revision (another PC saved). Staff must reload and re-check.
      setPhase('saveFailed'); setMsg(errText(e, '저장하지 못했습니다.'));
    }
  };
  const tryClose = () => {
    if (phase === 'saving') return;
    if (dirty && phase !== 'error' && !window.confirm('저장하지 않은 세탁비 변경이 있습니다. 닫을까요?')) return;
    onClose();
  };
  const reload = () => {
    if (dirty && !window.confirm('입력 중인 변경을 버리고 최신 가격표를 다시 불러올까요?')) return;
    load();
  };
  const derivedPrice = (e: CatalogEntry) => {
    const base = e.derivedFrom ? parsed[e.derivedFrom]?.value : null;
    return base == null ? null : base + PREMIUM_SURCHARGE;
  };
  const locked = phase !== 'ready';

  return <Modal title="세탁비 설정 · 수정" onClose={tryClose} testId="price-editor" wide
    footer={<>
      <p className="pn-warn">일반 세탁비만 수정합니다. 프리미엄은 일반 + {PREMIUM_SURCHARGE.toLocaleString('ko-KR')}원(와이셔츠는 {SHIRT_PREMIUM_PRICE.toLocaleString('ko-KR')}원 고정)으로 자동 계산됩니다. 이미 접수된 주문 금액은 바뀌지 않습니다.</p>
      <div className="pn-foot-actions">
        <span className="md-foot-note" data-testid="text-price-dirty">{phase === 'loading' ? '불러오는 중' : invalid ? `확인 필요 ${invalid}개` : changed ? `변경 ${changed}개` : '변경 없음'}</span>
        <button type="button" onClick={tryClose} disabled={phase === 'saving'} data-testid="button-back-price-editor">통계로 돌아가기</button>
        <button type="button" className="pn-primary" onClick={save} disabled={!canSave} data-testid="button-save-prices">
          {phase === 'saving' ? '저장 중…' : '세탁비 저장'}</button>
      </div>
    </>}>
    {msg && <div className="pn-alert" role="alert" data-testid="status-price-error">
      <span>{phase === 'saveFailed' ? `저장 실패: ${msg} 다른 PC에서 먼저 저장했을 수 있습니다. 최신 가격표를 다시 불러와 확인한 뒤 저장하세요.` : `가격표 조회 실패: ${msg}`}</span>
      <button type="button" onClick={reload} data-testid="button-reload-prices"><RefreshCw /> 최신 가격 다시 불러오기</button>
    </div>}
    {okMsg && <p className="pn-alert ok" role="status" data-testid="status-price-saved">{okMsg}</p>}
    {phase === 'loading' ? <div aria-busy="true" className="md-skels">{[0, 1, 2, 3, 4].map((i) => <i key={i} className="pn-skel md-skel" />)}</div>
      : phase === 'error' ? <p className="pn-empty">가격표를 불러오지 못해 수정할 수 없습니다. 저장은 잠겨 있습니다.</p>
        : groupByCategory(catalog).map((g) => <section key={g.category} className="md-price-group" aria-label={g.label}>
          <h3>{g.label}<small>{g.items.filter(editable).length}개 수정 가능</small></h3>
          <table className="md-price-table">
            <thead><tr><th>품목</th><th className="num">일반 세탁비</th><th className="num">프리미엄(자동)</th><th>구분</th></tr></thead>
            <tbody>{g.items.map((e) => {
              if (editable(e)) {
                const p = parsed[e.id];
                const changedRow = p?.value !== e.generalPrice;
                return <tr key={e.id} className={changedRow ? 'changed' : ''} data-testid={`row-price-${e.id}`}>
                  <td>{e.displayNameKo}{e.unit === 'pair' && <small> (켤레)</small>}</td>
                  <td className="num"><input inputMode="numeric" value={drafts[e.id] ?? ''} disabled={locked} aria-invalid={!!p?.error}
                    aria-label={`${e.displayNameKo} 일반 세탁비`} onChange={(ev) => { const v = ev.target.value; setOkMsg(''); setDrafts((d) => ({ ...d, [e.id]: v })); }}
                    data-testid={`input-price-${e.id}`} />{p?.error && <em className="md-err">{p.error}</em>}</td>
                  <td className="num md-ro">{won(p?.value == null ? null : premiumFor(e.id, p.value))}</td>
                  <td><span className="pn-badge">{changedRow ? `기존 ${won(e.generalPrice)}` : '수정 가능'}</span></td>
                </tr>;
              }
              return <tr key={e.id} className="ro" data-testid={`row-price-${e.id}`}>
                <td>{e.displayNameKo}</td>
                <td className="num md-ro">{e.custom ? '접수 시 직접 입력' : e.derivedFrom ? won(derivedPrice(e)) : won(e.generalPrice)}</td>
                <td className="num md-ro">{e.custom ? '-' : e.derivedFrom ? won(derivedPrice(e)) : won(e.premiumPrice)}</td>
                <td><span className="pn-badge off">{e.custom ? '기타 · 접수마다 직접 입력' : e.derivedFrom ? '자동 계산 · 운동화 + 9,000원' : '과거 기록용 · 수정 불가'}</span></td>
              </tr>;
            })}</tbody>
          </table>
        </section>)}
  </Modal>;
}
