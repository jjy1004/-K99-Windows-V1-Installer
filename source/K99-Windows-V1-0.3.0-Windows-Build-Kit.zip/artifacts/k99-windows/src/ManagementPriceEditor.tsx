import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { CATALOG_DEFAULTS, CATEGORY_LABELS, CATEGORY_ORDER, effectiveCategory, groupByCategory, itemFamily, premiumFor, PREMIUM_SURCHARGE,
  SHIRT_PREMIUM_PRICE, type CatalogCategory, type CatalogEntry } from './price-catalog';
import { ImeTextInput } from './ImeTextInput';
import { readSharedCatalog, saveSharedCatalog, sharedPriceRevision, sharedPriceWarning } from './shared-price-catalog';
import { Modal } from './PickupNoticeActions';
import './management-directory.css';
import './management-price-items.css';
import { NumUnit } from './NumUnit';

type Phase = 'loading' | 'ready' | 'error' | 'saving' | 'saveFailed';
const editable = (e: CatalogEntry) => !e.legacy && !e.derivedFrom && !e.custom;
const won = (v: number | null) => (v === null || !Number.isFinite(v) ? '-' : `${v.toLocaleString('ko-KR')}원`);
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);

/** Parses a draft price; returns null for anything that is not a valid whole-won amount. */
function parsePrice(id: string, raw: string): { value: number | null; error: string } {
  const t = raw.replace(/[,\s원]/g, '');
  if (!t) return { value: null, error: '금액을 입력하세요.' };
  if (!/^\d+$/.test(t)) return { value: null, error: '숫자만 입력하세요.' };
  const n = Number(t);
  if (!Number.isSafeInteger(n) || n < 1 || n > 100_000_000) return { value: null, error: '1원 ~ 1억 원' };
  if (id === 'shirt_dress' && n > SHIRT_PREMIUM_PRICE) return { value: null, error: '9,000원 이하' };
  return { value: n, error: '' };
}

const normName = (v: string) => v.replace(/\s+/g, '').toLowerCase();
const famKey = (e: CatalogEntry) => `${effectiveCategory(e)}::${String(itemFamily(e))}`;

export function ManagementPriceEditor({ onClose }: { onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>('loading');
  const [catalog, setCatalog] = useState<CatalogEntry[]>([]);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');
  const [okMsg, setOkMsg] = useState('');
  const [loadedRevision, setLoadedRevision] = useState<number | null>(null);
  const [working, setWorking] = useState<CatalogEntry[]>([]);
  const [newCat, setNewCat] = useState<CatalogCategory>('top');
  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [addErr, setAddErr] = useState('');
  const seq = useRef(0);
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const load = useCallback(() => {
    const id = ++seq.current;
    setPhase('loading'); setMsg(''); setOkMsg('');
    readSharedCatalog(CATALOG_DEFAULTS).then((c) => {
      if (!alive.current || id !== seq.current) return;
      setCatalog(c); setWorking(c);
      setLoadedRevision(sharedPriceRevision());
      setDrafts(Object.fromEntries(c.filter(editable).map((e) => [e.id, String(e.generalPrice)])));
      setPhase('ready'); setAddErr('');
    }).catch((e) => {
      if (!alive.current || id !== seq.current) return;
      setCatalog([]); setWorking([]); setLoadedRevision(null); setPhase('error'); setMsg(errText(e, '가격표를 불러오지 못했습니다.'));
    });
  }, []);
  useEffect(() => { load(); }, [load]);

  const parsed = Object.fromEntries(working.filter(editable).map((e) => [e.id, parsePrice(e.id, drafts[e.id] ?? '')]));
  const invalid = Object.values(parsed).filter((p) => p.error).length;
  const orig = new Map(catalog.map((e) => [e.id, e]));
  const added = working.filter((e) => !orig.has(e.id)).length;
  const removed = working.filter((e) => orig.has(e.id) && e.legacy && !orig.get(e.id)?.legacy).length;
  const moved = working.filter((e) => orig.has(e.id) && !e.legacy && (e.sortOrder ?? null) !== (orig.get(e.id)?.sortOrder ?? null)).length;
  const priceChanged = working.filter(editable).filter((e) => orig.has(e.id) && parsed[e.id]?.value !== orig.get(e.id)?.generalPrice).length;
  const changed = priceChanged + added + removed + moved;
  const canSave = phase === 'ready' && invalid === 0 && changed > 0 && loadedRevision !== null;
  const dirty = changed > 0 && phase !== 'loading';

  const save = async () => {
    if (!canSave) return;
    // Use the revision belonging to THIS draft, not a newer global cache revision.
    const rev = loadedRevision;
    const entries = working.map((e) => (editable(e) && parsed[e.id]?.value != null
      ? { ...e, generalPrice: parsed[e.id].value as number, premiumPrice: premiumFor(e.id, parsed[e.id].value as number) } : e));
    setPhase('saving'); setMsg(''); setOkMsg('');
    try {
      const c = await saveSharedCatalog(CATALOG_DEFAULTS, entries, '', rev);
      if (!alive.current) return;
      setCatalog(c); setWorking(c);
      setLoadedRevision(sharedPriceRevision());
      setDrafts(Object.fromEntries(c.filter(editable).map((e) => [e.id, String(e.generalPrice)])));
      setPhase('ready'); setOkMsg(`저장했습니다. 새 접수 화면에 바로 반영됩니다. (가격표 버전 ${sharedPriceRevision() ?? '-'})${sharedPriceWarning() ? ` · 주의: ${sharedPriceWarning()}` : ''}`);
    } catch (e) {
      if (!alive.current) return;
      // No automatic retry: the server may hold a newer revision (another PC saved). Staff must reload and re-check.
      setPhase('saveFailed'); setMsg(errText(e, '저장하지 못했습니다.'));
    }
  };
  const tryClose = () => {
    if (phase === 'saving') return;
    if (dirty && phase !== 'error' && !window.confirm('저장하지 않은 세탁비 변경이 있습니다. 닫을까요?')) return;
    onClose();
  };
  const reload = () => {
    if (dirty && !window.confirm('입력 중인 변경을 버리고 최신 가격표를 다시 불러올까요?')) return;
    load();
  };
  const derivedPrice = (e: CatalogEntry) => {
    const base = e.derivedFrom ? parsed[e.derivedFrom]?.value : null;
    return base == null ? null : base + PREMIUM_SURCHARGE;
  };
  const locked = phase !== 'ready';
  const groups = groupByCategory(working);

  const addItem = () => {
    if (locked) return;
    const name = newName.trim();
    if (!name) { setAddErr('품목 이름을 입력하세요.'); return; }
    if (name.length > 30) { setAddErr('품목 이름은 30자 이하로 입력하세요.'); return; }
    if (working.some((e) => !e.legacy && normName(e.displayNameKo) === normName(name))) { setAddErr(`이미 있는 품목입니다: ${name}`); return; }
    const p = parsePrice('', newPrice);
    if (p.value == null) { setAddErr(`기본 금액: ${p.error}`); return; }
    const id = `user_${crypto.randomUUID()}`;
    const draft: CatalogEntry = { id, displayNameKo: name, category: newCat, generalPrice: p.value, premiumPrice: premiumFor(id, p.value), userAdded: true };
    // No sortOrder: new items follow the shared automatic (가나다) order until manually moved.
    const entry = draft;
    // Insert after the last entry of the same category so category/family auto-ordering is preserved.
    const lastIdx = working.reduce((li, e, i) => (effectiveCategory(e) === newCat ? i : li), -1);
    setWorking((w) => (lastIdx < 0 ? [...w, entry] : [...w.slice(0, lastIdx + 1), entry, ...w.slice(lastIdx + 1)]));
    setDrafts((d) => ({ ...d, [id]: String(p.value) }));
    setNewName(''); setNewPrice(''); setAddErr(''); setOkMsg('');
  };
  const removeItem = (e: CatalogEntry) => {
    if (locked || !e.userAdded) return;
    if (!window.confirm(`'${e.displayNameKo}' 품목을 삭제할까요?\n새 접수 목록에서 사라지며, 이미 접수된 주문 기록은 그대로 남습니다.\n'세탁비 저장'을 눌러야 확정됩니다.`)) return;
    setOkMsg('');
    if (!orig.has(e.id)) {
      setWorking((w) => w.filter((x) => x.id !== e.id));
      setDrafts((d) => { const n = { ...d }; delete n[e.id]; return n; });
    } else setWorking((w) => w.map((x) => (x.id === e.id ? { ...x, legacy: true } : x)));
  };
  const siblings = (e: CatalogEntry) => groups.flatMap((g) => g.items).filter((x) => x.userAdded && !x.legacy && famKey(x) === famKey(e));
  const moveItem = (e: CatalogEntry, dir: -1 | 1) => {
    if (locked) return;
    const sib = siblings(e);
    const i = sib.findIndex((x) => x.id === e.id), j = i + dir;
    if (i < 0 || j < 0 || j >= sib.length) return;
    [sib[i], sib[j]] = [sib[j], sib[i]];
    const order = new Map(sib.map((x, n) => [x.id, n + 1]));
    setOkMsg('');
    setWorking((w) => w.map((x) => (order.has(x.id) ? { ...x, sortOrder: order.get(x.id) } : x)));
  };

  return <Modal title="세탁비 설정 · 수정" onClose={tryClose} testId="price-editor" wide
    footer={<>
      <p className="pn-warn">일반 세탁비만 수정합니다. 프리미엄은 일반 <NumUnit>+ {PREMIUM_SURCHARGE.toLocaleString('ko-KR')}원</NumUnit>(와이셔츠는 <NumUnit>{SHIRT_PREMIUM_PRICE.toLocaleString('ko-KR')}원</NumUnit> 고정)으로 자동 계산됩니다. 이미 접수된 주문 금액은 바뀌지 않습니다.</p>
      <div className="pn-foot-actions">
        <span className="md-foot-note" data-testid="text-price-dirty">{phase === 'loading' ? '불러오는 중' : invalid ? `확인 필요 ${invalid}개` : changed ? `변경 ${changed}개` : '변경 없음'}</span>
        <button type="button" onClick={tryClose} disabled={phase === 'saving'} data-testid="button-back-price-editor">통계로 돌아가기</button>
        <button type="button" className="pn-primary" onClick={save} disabled={!canSave} data-testid="button-save-prices">
          {phase === 'saving' ? '저장 중…' : '세탁비 저장'}</button>
      </div>
    </>}>
    {msg && <div className="pn-alert" role="alert" data-testid="status-price-error">
      <span>{phase === 'saveFailed' ? `저장 실패: ${msg} 다른 PC에서 먼저 저장했을 수 있습니다. 최신 가격표를 다시 불러와 확인한 뒤 저장하세요.` : `가격표 조회 실패: ${msg}`}</span>
      <button type="button" onClick={reload} data-testid="button-reload-prices"><RefreshCw /> 최신 가격 다시 불러오기</button>
    </div>}
    {okMsg && <p className="pn-alert ok" role="status" data-testid="status-price-saved">{okMsg}</p>}
    {phase === 'loading' ? <div aria-busy="true" className="md-skels">{[0, 1, 2, 3, 4].map((i) => <i key={i} className="pn-skel md-skel" />)}</div>
      : phase === 'error' ? <p className="pn-empty">가격표를 불러오지 못해 수정할 수 없습니다. 저장은 잠겨 있습니다.</p>
        : <>
        <section className="mpi-add" aria-label="신규 세탁물 품목 추가" data-testid="section-add-item">
          <h3>신규 세탁물 품목 추가</h3>
          <div className="mpi-add-row">
            <label>카테고리
              <select value={newCat} disabled={locked} onChange={(ev) => { setNewCat(ev.target.value as CatalogCategory); setAddErr(''); }} data-testid="select-new-category">
                {CATEGORY_ORDER.map((c) => <option key={c} value={c}>{CATEGORY_LABELS[c]}</option>)}
              </select></label>
            <label className="mpi-name">한글 품목명
              <ImeTextInput value={newName} disabled={locked} maxLength={30} placeholder="예: 패딩 조끼" aria-invalid={!!addErr}
                onValue={(v) => { setNewName(v); setAddErr(''); }}
                onKeyDown={(ev) => { if (ev.key === 'Enter' && !ev.nativeEvent.isComposing && ev.keyCode !== 229) { ev.preventDefault(); addItem(); } }}
                data-testid="input-new-name" /></label>
            <label>기본 금액(일반)
              <input inputMode="numeric" value={newPrice} disabled={locked} placeholder="예: 15000" aria-invalid={!!addErr}
                onChange={(ev) => { setNewPrice(ev.target.value); setAddErr(''); }}
                onKeyDown={(ev) => { if (ev.key === 'Enter' && !ev.nativeEvent.isComposing && ev.keyCode !== 229) { ev.preventDefault(); addItem(); } }}
                data-testid="input-new-price" /></label>
            <button type="button" className="pn-primary mpi-add-btn" onClick={addItem} disabled={locked} data-testid="button-add-item">
              <Plus /> 신규 세탁물 품목 추가</button>
          </div>
          {addErr ? <p className="mpi-add-err" role="alert" data-testid="text-add-error">{addErr}</p>
            : <p className="mpi-add-hint">추가한 품목은 '세탁비 저장'을 눌러야 새 접수 화면에 나타납니다. 기본은 가나다순이며, 위·아래 이동은 같은 카테고리·품목군의 추가 품목이 <NumUnit>2개</NumUnit> 이상일 때 가능합니다.</p>}
        </section>
        {groups.map((g) => <section key={g.category} className="md-price-group" aria-label={g.label}>
          <h3>{g.label}<small>{g.items.filter(editable).length}개 수정 가능</small></h3>
          <div className="mpi-table-wrap">
          <table className="md-price-table">
            <thead><tr><th>품목</th><th className="num">일반 세탁비</th><th className="num">프리미엄(자동)</th><th>구분</th></tr></thead>
            <tbody>{g.items.map((e) => {
              if (editable(e)) {
                const p = parsed[e.id];
                const isNew = !orig.has(e.id);
                const changedRow = isNew || p?.value !== e.generalPrice || (e.sortOrder ?? null) !== (orig.get(e.id)?.sortOrder ?? null);
                const sib = e.userAdded ? siblings(e) : [];
                const si = sib.findIndex((x) => x.id === e.id);
                return <tr key={e.id} className={changedRow ? 'changed' : ''} data-testid={`row-price-${e.id}`}>
                  <td>{e.displayNameKo}{e.unit === 'pair' && <small> (켤레)</small>}</td>
                  <td className="num"><input inputMode="numeric" value={drafts[e.id] ?? ''} disabled={locked} aria-invalid={!!p?.error}
                    aria-label={`${e.displayNameKo} 일반 세탁비`} onChange={(ev) => { const v = ev.target.value; setOkMsg(''); setDrafts((d) => ({ ...d, [e.id]: v })); }}
                    data-testid={`input-price-${e.id}`} />{p?.error && <em className="md-err">{p.error}</em>}</td>
                  <td className="num md-ro">{won(p?.value == null ? null : premiumFor(e.id, p.value))}</td>
                  <td><div className="mpi-cell">
                    <span className="pn-badge">{isNew ? '새 품목 · 저장 전' : p?.value !== e.generalPrice ? `기존 ${won(e.generalPrice)}` : e.userAdded ? '직접 추가' : '수정 가능'}</span>
                    {e.userAdded && <span className="mpi-acts">
                      <button type="button" disabled={locked || si <= 0} onClick={() => moveItem(e, -1)} aria-label={`${e.displayNameKo} 위로`} title="위로" data-testid={`button-up-${e.id}`}><ArrowUp /></button>
                      <button type="button" disabled={locked || si < 0 || si >= sib.length - 1} onClick={() => moveItem(e, 1)} aria-label={`${e.displayNameKo} 아래로`} title="아래로" data-testid={`button-down-${e.id}`}><ArrowDown /></button>
                      <button type="button" className="mpi-del" disabled={locked} onClick={() => removeItem(e)} data-testid={`button-delete-${e.id}`}><Trash2 /> 삭제</button>
                    </span>}
                  </div></td>
                </tr>;
              }
              return <tr key={e.id} className="ro" data-testid={`row-price-${e.id}`}>
                <td>{e.displayNameKo}</td>
                <td className="num md-ro">{e.custom ? '접수 시 직접 입력' : e.derivedFrom ? won(derivedPrice(e)) : won(e.generalPrice)}</td>
                <td className="num md-ro">{e.custom ? '-' : e.derivedFrom ? won(derivedPrice(e)) : won(e.premiumPrice)}</td>
                <td><span className="pn-badge off">{e.userAdded && e.legacy ? (orig.get(e.id)?.legacy ? '삭제됨 · 과거 기록용' : '삭제 예정 · 저장 시 확정') : e.custom ? '기타 · 접수마다 직접 입력' : e.derivedFrom ? '자동 계산 · 운동화 + 9,000원' : '과거 기록용 · 수정 불가'}</span></td>
              </tr>;
            })}</tbody>
          </table>
          </div>
        </section>)}
        </>}
  </Modal>;
}
