import type { ConfirmedOrder } from './order-record';
import { currentOperations } from './order-operations';
import { pickupNoticeText } from './customer-pickup-notices.ts';

const schedule = (date: string, time: string) =>
  date ? `${date}${time ? ` ${time}` : ' (시간 확인 예정)'}` : '일정 확인 후 별도 안내';
const itemsText = (order: ConfirmedOrder) => order.items.map((i) => `${i.displayNameKo} ${i.quantity}점`).join(', ');
const header = (order: ConfirmedOrder) =>
  `[K99 품격세탁소 과천점]\n${order.customerName} 고객님, 맡기신 ${itemsText(order)}`;
/** Matches storage-policy.ts: 15 free days counting the intake day, then 1000원 per garment per day. */
export const STORAGE_POLICY_TEXT = '접수일 포함 15일까지 무료 보관되며, 16일째부터 의류 1점당 하루 1,000원의 보관료가 발생합니다.';

export function completionNoticeText(order: ConfirmedOrder): string {
  const ops = currentOperations(order);
  return `${header(order)}의 세탁이 완료되어 ${order.choices.deliveryRequested ? '배달 준비 중입니다' : '수령 가능합니다'}.\n${order.choices.deliveryRequested
    ? `배달 예정 안내입니다. 배달 일정: ${schedule(ops.deliveryDate, ops.deliveryTime)}.\n배달 장소: ${ops.detailAddress || order.customerAddress || '주소 확인 필요'}`
    : `매장에서 직접 수령해 주세요.\n${STORAGE_POLICY_TEXT}`}`;
}

export function logisticsNoticeText(order: ConfirmedOrder, purpose: 'pickup' | 'delivery'): string {
  const ops = currentOperations(order);
  const label = purpose === 'pickup' ? '수거' : '배달';
  return `${header(order)}의 ${label} 예정 안내입니다.\n${label} 일정: ${schedule(
    purpose === 'pickup' ? ops.pickupDate : ops.deliveryDate,
    purpose === 'pickup' ? ops.pickupTime : ops.deliveryTime,
  )}.\n${label} 장소: ${ops.detailAddress || order.customerAddress || '주소 확인 필요'}`;
}

/** Exact V1 day-9 / day-13 uncollected templates (shared with the Today notice stage). */
export function storageReminderText(order: ConfirmedOrder, day: 9 | 13): string {
  return pickupNoticeText(order, day === 9 ? 'day9' : 'day13');
}
