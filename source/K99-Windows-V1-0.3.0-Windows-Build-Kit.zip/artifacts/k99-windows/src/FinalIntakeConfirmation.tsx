import { useEffect, useRef, useState } from 'react';
import { orderPhotoEligible } from './workflow-gates';
import { currentInspectionStatus } from './inspection-status';
import type { ConfirmedOrder, FinalIntakeChoices, OrderItem, ServiceLevel } from './order-record';
import { pickupDeliveryFee } from './order-record';
import { DEFAULT_DELIVERY_POLICY, readDeliveryPolicy, type DeliveryPolicy } from './delivery-policy';
import { reviewClassification } from './item-intake-details';
import { requiredIntakeIdentity } from './customer-input';
import './final-intake.css';
import { itemTotal, unitService } from './unit-service';
import CustomerIdentityEditor, { type CustomerIdentity } from './CustomerIdentityEditor';
import { canEditCustomer } from './customer-identity-update';

type Props = {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: OrderItem[];
  orderId: string;
  onBack: () => void;
  onNewIntake?: () => void;
  onConfirm: (choices: FinalIntakeChoices, feePolicy: DeliveryPolicy) => boolean;
  beforeConfirm?: () => Promise<void>;
  confirmedOrder?: ConfirmedOrder | null;
  saveError?: string;
  photoFolderStatus?: string;
  onStartInspection?: () => void;
  onStartGarmentCapture?: () => void;
  onStartScanner?: () => void;
  onStartLaundry?: () => void;
  onOpenWorkspace?: () => void;
  onCustomerSave?: (value: CustomerIdentity) => void;
  onUnitServicesChange?: (levels: ServiceLevel[][]) => void;
  initialUnitServices?: ServiceLevel[][];
  /** Previously entered final-step choices, restored when staff navigate back and forward. */
  initialChoices?: Partial<FinalIntakeChoices>;
  onChoicesChange?: (choices: Partial<FinalIntakeChoices>) => void;
};

type DraftChoices = Omit<FinalIntakeChoices, 'serviceLevel' | 'waiver' | 'luxuryItem'> & {
  serviceLevel: ServiceLevel | null;
  waiver: FinalIntakeChoices['waiver'] | null;
  luxuryItem: boolean | null;
};

const won = (value: number) => `${value.toLocaleString('ko-KR')}원`;
const yesNo = (value: boolean) => value ? '예' : '아니요';

function ChoiceField<T extends string>({
  title, name, value, options, onChange, hint,
}: {
  title: string;
  name: string;
  value: T | null;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  hint?: string;
}) {
  return (
    <fieldset className="final-intake__field">
      <legend>{title}</legend>
      {hint && <span className="final-intake__hint">{hint}</span>}
      <div className="final-intake__options">
        {options.map((option) => (
          <label className="final-intake__option" key={option.value}>
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
              data-testid={`input-${name}-${option.value}`}
            />
            {option.label}
          </label>
        ))}
      </div>
    </fieldset>
  );
}

function Detail({ label, value, testId }: { label: string; value: string; testId?: string }) {
  return <div className="final-intake__detail"><span>{label}</span><strong data-testid={testId}>{value}</strong></div>;
}

function IntakeSummary({
  customerName, customerPhone, customerAddress, items, orderId, choices, saved, activePolicy, onTotalOverride,
}: {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: OrderItem[];
  orderId: string;
  choices: DraftChoices;
  saved?: ConfirmedOrder;
  activePolicy?: DeliveryPolicy;
  onTotalOverride?: (value: number | undefined) => void;
}) {
  const totalQuantity = saved?.totalQuantity ?? items.reduce((sum, item) => sum + item.quantity, 0);
  const hasGarments = items.some((item) => !item.isSneaker);
  const canPrice = !hasGarments || choices.serviceLevel !== null;
  const pricedChoices = { ...choices, serviceLevel: choices.serviceLevel ?? 'general' } as FinalIntakeChoices;
  const laundryTotal = saved?.laundryTotal ?? items.reduce((sum, item, i) => sum + itemTotal(item, pricedChoices, i), 0);
  const policy = saved?.feePolicy ?? (saved ? DEFAULT_DELIVERY_POLICY : activePolicy ?? DEFAULT_DELIVERY_POLICY);
  const serviceFee = saved?.serviceFee ?? pickupDeliveryFee(totalQuantity, choices.pickupRequested, choices.deliveryRequested, policy);
  const computedTotal = laundryTotal + serviceFee + (choices.technicalFee ?? 0) - (choices.discount ?? 0);
  const estimatedTotal = saved?.estimatedTotal ?? choices.totalOverride ?? computedTotal;
  const [editingTotal, setEditingTotal] = useState(false);
  const [totalText, setTotalText] = useState('');

  return (
    <section className="final-intake__summary" aria-label={saved ? '저장된 접수 내역' : '최종 접수 실시간 요약'} data-testid="section-final-intake-summary">
      <div className="final-intake__section-head">
        <h2>{saved ? '저장된 접수 내역' : '최종 접수 내역'}</h2>
        <span>{saved ? '접수 완료' : '확인 중'}</span>
      </div>
      <div className="final-intake__group">
        <span className="final-intake__group-title">고객 정보</span>
        <Detail label="고객명" value={customerName || '미입력'} testId="text-final-customer-name" />
        <Detail label="결제 구분" value={choices.paymentType === 'POSTPAID' ? '후불 · 수령 시 결제' : '선불'} testId="text-final-payment-type" />
        <Detail label="연락처" value={customerPhone || '미입력'} testId="text-final-customer-phone" />
        <Detail label="주소" value={customerAddress || '미입력'} testId="text-final-customer-address" />
        <Detail label="주문 번호" value={orderId} testId="text-final-order-id" />
        {saved && <>
          <Detail label="접수 일시" value={new Date(saved.intakeAt).toLocaleString('ko-KR')} testId="text-final-intake-date" />
        </>}
      </div>
      <div className="final-intake__group">
        <span className="final-intake__group-title">품목 · 총 {totalQuantity}점</span>
        {items.map((item, index) => {
          const rowTotal = itemTotal(item, pricedChoices, index);
          const services = Array.from({ length: item.quantity }, (_, u) => unitService(pricedChoices, index, u) === 'premium' ? '프리미엄' : '일반');
          const sneakerKind = item.displayNameKo.includes('프리미엄') ? '프리미엄' : item.displayNameKo.includes('일반') ? '일반' : '품목별';
          return (
            <div className="final-intake__item" key={`${item.itemId}-${index}`} data-testid={`row-final-item-${index}`}>
              <div>
                <strong>{item.displayNameKo} × {item.quantity}</strong>
                <small>{item.isSneaker ? `운동화 · ${sneakerKind} 고정가` : services.map((s, u) => `${u + 1}번 ${s}`).join(' · ')}</small>
                {item.intakeDetails && <small>접수 시 상태: {[
                  item.intakeDetails.brand && `브랜드 ${item.intakeDetails.brand}`,
                  item.intakeDetails.material && `소재 ${item.intakeDetails.material}`,
                  item.intakeDetails.color && `색상 ${item.intakeDetails.color}`,
                  item.intakeDetails.stain && `오염 ${item.intakeDetails.stain}`,
                  item.intakeDetails.damage && `훼손 ${item.intakeDetails.damage}`,
                ].filter(Boolean).join(' · ') || '추가 설명 없음'}
                  {reviewClassification(item.itemId, item.intakeDetails).requiresReview && ' · 별도 확인 필요'}</small>}
              </div>
              <div className="final-intake__item-price">{won(rowTotal)}</div>
            </div>
          );
        })}
        <Detail label="의류 서비스" value={hasGarments ? choices.unitServiceLevels ? '세탁물별 선택 · 위 순번 확인' : choices.serviceLevel === 'premium' ? '프리미엄' : '일반' : '해당 없음 · 운동화 고정가'} testId="text-final-service-level" />
        <Detail label="세탁 소계" value={canPrice ? won(laundryTotal) : '서비스 선택 후 표시'} testId="text-final-laundry-subtotal" />
        {(choices.technicalFee ?? 0) > 0 && <Detail label="추가기술료 (기존 기록)" value={won(choices.technicalFee ?? 0)} testId="text-final-technical-fee" />}
        <Detail label="할인금액" value={won(choices.discount ?? 0)} testId="text-final-discount" />
      </div>
      <div className="final-intake__group">
        <span className="final-intake__group-title">수거 · 수령</span>
        <Detail label="수거 신청" value={yesNo(choices.pickupRequested)} testId="text-final-pickup" />
        {choices.pickupRequested && <Detail label="수거 희망일" value={choices.requestedPickupDate || '날짜 선택 필요'} testId="text-final-pickup-date" />}
        <Detail label="배달 신청" value={yesNo(choices.deliveryRequested)} testId="text-final-delivery" />
        <Detail label="직접 수령" value={yesNo(choices.directPickup)} testId="text-final-direct-pickup" />
        <Detail label="수거·배달비 (주문당)" value={won(serviceFee)} testId="text-final-service-fee" />
        <span className="final-intake__hint" style={{ margin: '9px 0 0' }}>{policy.freeFromQuantity}점 이상 무료 수거·배달 · 기준 미만 수거 또는 배달 시 주문당 {won(policy.feeBelowThreshold)}</span>
      </div>
      <div className="final-intake__group">
        <span className="final-intake__group-title">확인 사항</span>
        <Detail label="배상 책임 동의" value={choices.waiver === 'agreed' ? '동의' : choices.waiver === 'declined' ? '동의하지 않음' : '미확인 · 선택 항목'} testId="text-final-waiver" />
        <Detail label="명품 여부" value={choices.luxuryItem === null ? '선택 필요' : yesNo(choices.luxuryItem)} testId="text-final-luxury" />
        <div className="final-intake__detail final-intake__detail--requests">
          <span>고객 요청사항</span>
          <strong data-testid="text-final-customer-requests">{choices.customerRequests.trim() || '특별 요청사항 없음'}</strong>
        </div>
      </div>
      <div className="final-intake__total">
        <span>{saved ? '확정 세탁비' : '총 예상 금액'}{!saved && choices.totalOverride !== undefined && <small className="final-intake__override-tag" data-testid="status-total-overridden">직원 수정 · 계산 금액 {won(computedTotal)}</small>}
          {saved?.choices.totalOverride !== undefined && saved.choices.computedLaundryTotal !== undefined &&
            <small className="final-intake__override-tag">직원 수정 금액 · 계산 세탁 소계 {won(saved.choices.computedLaundryTotal)}</small>}</span>
        {!saved && onTotalOverride && canPrice && editingTotal ? (
          <form className="final-intake__total-edit" onSubmit={(event) => {
            event.preventDefault();
            const value = Number(totalText.replace(/[^\d]/g, ''));
            if (totalText.trim() === '' || !Number.isSafeInteger(value)) return;
            onTotalOverride(value === computedTotal ? undefined : value);
            setEditingTotal(false);
          }}>
            <input autoFocus inputMode="numeric" aria-label="수정할 총 금액" value={totalText}
              onChange={(event) => setTotalText(event.target.value.replace(/[^\d]/g, ''))} data-testid="input-total-override" />
            <span>원</span>
            <button type="submit" data-testid="button-total-override-apply">적용</button>
            <button type="button" onClick={() => setEditingTotal(false)} data-testid="button-total-override-cancel">취소</button>
          </form>
        ) : !saved && onTotalOverride && canPrice ? (
          <span className="final-intake__total-actions">
            <button type="button" className="final-intake__total-value" title="클릭하여 할인·이벤트 금액으로 수정"
              onClick={() => { setTotalText(String(estimatedTotal)); setEditingTotal(true); }} data-testid="text-final-estimated-total">
              {won(estimatedTotal)} <small>수정</small>
            </button>
            {choices.totalOverride !== undefined && <button type="button" className="final-intake__total-reset"
              onClick={() => onTotalOverride(undefined)} data-testid="button-total-override-reset">계산 금액으로 되돌리기</button>}
          </span>
        ) : <strong data-testid="text-final-estimated-total">{canPrice ? won(estimatedTotal) : '서비스 선택 후 표시'}</strong>}
      </div>
      <p className="final-intake__notice">현재 금액과 처리 방식은 최초 예상 안내입니다. 전문가의 실물 검품 후 오염·소재·상태에 따라 금액과 세탁 방법이 변경될 수 있습니다.</p>
      {saved && <p className="final-intake__storage" data-testid="text-final-storage">이 접수 기록은 매장 PC의 로컬 데이터베이스에 저장되었습니다.</p>}
    </section>
  );
}

export function FinalIntakeConfirmation({
  customerName, customerPhone, customerAddress, items, orderId, onBack, onNewIntake, onConfirm, beforeConfirm, confirmedOrder, saveError, photoFolderStatus, onStartInspection, onStartGarmentCapture, onStartScanner, onStartLaundry, onOpenWorkspace,
  onCustomerSave, onUnitServicesChange, initialUnitServices, initialChoices, onChoicesChange,
}: Props) {
  const init = initialChoices ?? {};
  const hasGarments = items.some((item) => !item.isSneaker);
  const serviceLevel: ServiceLevel = 'general';
  const [unitServiceLevels, setUnitServiceLevels] = useState<ServiceLevel[][]>(() =>
    initialUnitServices ?? items.map(item => Array.from({ length: item.quantity }, () => 'general' as const)));
  const [pickupRequested, setPickupRequested] = useState(init.pickupRequested ?? false);
  const [deliveryRequested, setDeliveryRequested] = useState(init.deliveryRequested ?? false);
  const [directPickup, setDirectPickup] = useState(init.directPickup ?? true);
  const [requestedPickupDate, setRequestedPickupDate] = useState(init.requestedPickupDate ?? '');
  const [waiver, setWaiver] = useState<FinalIntakeChoices['waiver'] | null>(init.waiver ?? 'declined');
  const [luxuryItem, setLuxuryItem] = useState<boolean | null>(init.luxuryItem ?? false);
  const [customerRequests, setCustomerRequests] = useState(init.customerRequests ?? '없음');
  // New intakes never add a technical surcharge here; professional inspection owns it.
  const technicalFee = 0;
  const [discount, setDiscount] = useState(init.discount ?? 0);
  const [paymentType, setPaymentType] = useState<FinalIntakeChoices['paymentType']>(init.paymentType ?? 'PREPAID');
  const [totalOverride, setTotalOverride] = useState<number | undefined>(init.totalOverride);
  const [submitting, setSubmitting] = useState(false);
  const [policyResult] = useState(() => {
    try { return { policy: readDeliveryPolicy(), error: '' }; }
    catch { return { policy: DEFAULT_DELIVERY_POLICY, error: '저장된 수거·배달 정책을 읽을 수 없습니다. 운영 관리에서 정책을 다시 저장해 주세요.' }; }
  });

  const draft: DraftChoices = {
    paymentType,
    serviceLevel, pickupRequested, deliveryRequested, directPickup, requestedPickupDate, waiver, luxuryItem, customerRequests,
    technicalFee, discount, unitServiceLevels, ...(totalOverride !== undefined ? { totalOverride } : {}),
  };
  const choicesChangeRef = useRef(onChoicesChange);
  choicesChangeRef.current = onChoicesChange;
  useEffect(() => {
    if (confirmedOrder) return;
    choicesChangeRef.current?.({ pickupRequested, deliveryRequested, directPickup, requestedPickupDate,
      paymentType,
      waiver: waiver ?? 'declined', luxuryItem: luxuryItem ?? false, customerRequests, discount,
      ...(totalOverride !== undefined ? { totalOverride } : {}) });
  }, [confirmedOrder, pickupRequested, deliveryRequested, directPickup, requestedPickupDate, waiver, luxuryItem,
    customerRequests, discount, totalOverride, paymentType]);
  const laundryEstimate = items.reduce((sum, item, i) => sum + itemTotal(item, { serviceLevel, unitServiceLevels }, i), 0);
  const feeEstimate = pickupDeliveryFee(items.reduce((sum, item) => sum + item.quantity, 0),
    pickupRequested, deliveryRequested, policyResult.policy);
  const missing = [
    ...(policyResult.error ? [policyResult.error] : []),
    ...(!requiredIntakeIdentity(customerName, customerPhone) ? ['고객명과 유효한 휴대전화번호를 확인해 주세요.'] : []),
    ...(!items.length ? ['접수 품목을 확인해 주세요.'] : []),
    ...(items.some((item) => !Number.isInteger(item.quantity) || item.quantity < 1) ? ['의류 수량을 확인해 주세요.'] : []),
    ...(hasGarments && !serviceLevel ? ['의류 서비스 등급을 선택해 주세요.'] : []),
    ...(pickupRequested && !requestedPickupDate ? ['수거 희망일을 선택해 주세요.'] : []),
    ...((pickupRequested || deliveryRequested) && !customerAddress.trim() ? ['수거·배달 주소를 입력해 주세요.'] : []),
    ...(!Number.isSafeInteger(technicalFee) || technicalFee < 0 || technicalFee > 100000000
      ? ['추가기술료는 0~1억 원 사이의 정수여야 합니다.'] : []),
    ...(!Number.isSafeInteger(discount) || discount < 0 || discount > laundryEstimate + feeEstimate + technicalFee
      ? ['할인금액이 올바른지 확인해 주세요.'] : []),
    ...(totalOverride !== undefined && (!Number.isSafeInteger(totalOverride) || totalOverride > 100000000
      || totalOverride - feeEstimate - technicalFee + discount < 0)
      ? ['수정한 총 금액은 수거·배달비 이상, 1억 원 이하로 입력해 주세요.'] : []),
  ];

  const submitLock=useRef(false),mounted=useRef(true);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  async function confirm() {
    if (missing.length || submitting || submitLock.current) return;
    submitLock.current=true;
    setSubmitting(true);
    try {
    await beforeConfirm?.();
    if(!mounted.current)return;
    const saved = onConfirm({
      paymentType,
      serviceLevel: serviceLevel ?? 'general',
      unitServiceLevels,
      pickupRequested,
      deliveryRequested,
      directPickup,
      requestedPickupDate: pickupRequested ? requestedPickupDate : '',
      waiver: waiver ?? 'declined',
      luxuryItem: luxuryItem ?? false,
      customerRequests: customerRequests.trim() || '없음',
      technicalFee, discount, ...(totalOverride !== undefined ? { totalOverride } : {}),
    }, policyResult.policy);
    if (!saved) setSubmitting(false);
    } catch {
      if(mounted.current)setSubmitting(false);
    } finally {submitLock.current=false;}
  }

  return (
    <main className="final-intake">
      <div className="final-intake__wrap">
        <div className="final-intake__topline">
          <div className="final-intake__brand">K99 품격세탁소 <small>과천점 · 직원 접수</small></div>
          <span className="final-intake__serial">접수 확인</span>
        </div>
        {onCustomerSave && (!confirmedOrder || canEditCustomer(confirmedOrder)) &&
          <CustomerIdentityEditor value={{ customerName, customerPhone, customerAddress }} onSave={onCustomerSave} />}
        {confirmedOrder ? (
          <div className="final-intake__saved" data-testid="section-final-intake-saved">
            <header className="final-intake__header">
              <span className="final-intake__saved-stamp" data-testid="status-final-intake-saved">{currentInspectionStatus(confirmedOrder).status}</span>
              <h1>접수 내역을 저장했습니다.</h1>
              <p>고객님과 확인한 내용을 아래에 그대로 남겼습니다. 검품 전 예상 안내이며, 이후 변경 사항은 별도로 안내해 주세요.</p>
            </header>
            <IntakeSummary
              customerName={confirmedOrder.customerName}
              customerPhone={confirmedOrder.customerPhone}
              customerAddress={confirmedOrder.customerAddress}
              items={confirmedOrder.items}
              orderId={confirmedOrder.id}
              choices={confirmedOrder.choices}
              saved={confirmedOrder}
            />
            <div className="final-intake__actions">
              {!confirmedOrder.inspection && onStartInspection
                ? <button type="button" className="final-intake__confirm" onClick={onStartInspection}
                  data-testid="button-start-inspection">검수·세탁 작업 열기</button>
                : onStartLaundry ? <button type="button" className="final-intake__confirm" onClick={onStartLaundry} data-testid="button-start-laundry-process">세탁·완성 검수</button>
                  : onStartInspection && <button type="button" className="final-intake__confirm" onClick={onStartInspection} data-testid="button-start-inspection">검수 결과·고객 동의 확인</button>}
              {onStartGarmentCapture && orderPhotoEligible(confirmedOrder)
                ? <button type="button" className="final-intake__back" onClick={onStartGarmentCapture} data-testid="button-start-garment-capture">세탁물 촬영 및 태그 발행</button>
                : <p className="final-intake__hint" data-testid="text-capture-locked">사진·태그는 전문검수와 필요한 고객 동의가 끝난 뒤 진행합니다.</p>}
              {onOpenWorkspace && <button type="button" className="final-intake__back" onClick={onOpenWorkspace}
                data-testid="button-open-order-workspace">주문 전체 보기</button>}
              <button type="button" className="final-intake__back" onClick={onBack} data-testid="button-saved-intake-back">해당 주문으로 돌아가기</button>
              {onNewIntake && <button type="button" className="final-intake__back" onClick={onNewIntake} data-testid="button-new-intake">새 접수 시작</button>}
            </div>
          </div>
        ) : (
          <>
            <header className="final-intake__header">
              
              <nav className="final-intake__stepnav" aria-label="접수 단계 이동">
                <button type="button" onClick={onBack} data-testid="button-final-intake-back-top">뒤로 가기 · 고객·품목 입력</button>
                <span>2 / 2 · 최종 확인</span>
                <button type="button" disabled={missing.length > 0 || submitting} onClick={confirm} data-testid="button-final-intake-forward-top">앞으로 가기 · 접수 확정</button>
              </nav>
              <h1>최종 접수 확인</h1>
              <p>고객님과 품목, 수거·수령 방식, 요청사항을 함께 확인해 주세요. 총 예상 금액을 누르면 할인·이벤트 금액으로 직접 수정할 수 있으며, 고객 화면에도 즉시 반영됩니다. 뒤로 가도 입력한 내용은 보존됩니다.</p>
            </header>
            <div className="final-intake__layout">
              <div className="final-intake__form">
                <section className="final-intake__panel" aria-labelledby="fi-service-heading">
                  <div className="final-intake__section-head"><h2 id="fi-service-heading">01 · 세탁 서비스</h2></div>
                  {items.map((item, i) => item.isSneaker ? <p key={i}>{item.displayNameKo} · 선택한 운동화 고정가</p> :
                    Array.from({ length: item.quantity }, (_, u) => <ChoiceField key={`${i}-${u}`}
                      title={`${item.displayNameKo} · ${u + 1}번 세탁물`} name={`unit-service-${i}-${u}`}
                      value={unitServiceLevels[i]?.[u] ?? 'general'}
                      options={[{ value: 'general', label: `일반 세탁 ${won(item.generalPrice)}` },
                        { value: 'premium', label: `프리미엄 세탁 ${won(item.premiumPrice)}` }]}
                      onChange={value => {
                        const next = items.map((row, ri) => Array.from({ length: row.quantity }, (_, ru) =>
                          ri === i && ru === u ? value : unitServiceLevels[ri]?.[ru] ?? 'general'));
                        setUnitServiceLevels(next); onUnitServicesChange?.(next);
                      }} />))}
                  <div className="final-intake__field">
                    <label className="final-intake__label" htmlFor="fi-discount">할인금액 · 원</label>
                    <input className="final-intake__date" id="fi-discount" type="number" inputMode="numeric" min="0" max="100000000" step="1"
                      value={discount} onChange={(event) => setDiscount(Number(event.target.value))} data-testid="input-discount" />
                  </div>
                </section>
                <section className="final-intake__panel" aria-labelledby="fi-logistics-heading">
                  <div className="final-intake__section-head"><h2 id="fi-logistics-heading">02 · 수거와 수령</h2></div>
                  <ChoiceField
                    title="세탁물 수거 신청" name="pickup-requested" value={String(pickupRequested)}
                    options={[{ value: 'true', label: '예 · 방문 수거' }, { value: 'false', label: '아니요' }]}
                    onChange={(value) => { setPickupRequested(value === 'true'); if (value === 'false') setRequestedPickupDate(''); }}
                  />
                  {pickupRequested && (
                    <div className="final-intake__field">
                      <label className="final-intake__label" htmlFor="fi-pickup-date">수거 희망일</label>
                      <input className="final-intake__date" id="fi-pickup-date" type="date" value={requestedPickupDate} onChange={(event) => setRequestedPickupDate(event.target.value)} data-testid="input-requested-pickup-date" />
                    </div>
                  )}
                  <ChoiceField
                    title="완료 후 배달 신청" name="delivery-requested" value={String(deliveryRequested)}
                    options={[{ value: 'true', label: '예 · 배달' }, { value: 'false', label: '아니요' }]}
                    onChange={(value) => { const next = value === 'true'; setDeliveryRequested(next); setDirectPickup(!next); }}
                    hint="배달을 선택하면 직접 수령은 자동으로 해제됩니다."
                  />
                  <ChoiceField
                    title="완료 후 매장 직접 수령" name="direct-pickup" value={String(directPickup)}
                    options={[{ value: 'true', label: '예 · 직접 수령' }, { value: 'false', label: '아니요 · 배달' }]}
                    onChange={(value) => { const next = value === 'true'; setDirectPickup(next); setDeliveryRequested(!next); }}
                  />
                </section>
                <section className="final-intake__panel final-intake__panel--warm" aria-labelledby="fi-care-heading">
                  <div className="final-intake__section-head"><h2 id="fi-care-heading">03 · 고객 확인 사항</h2></div>
                   <ChoiceField
                    title="배상 책임 안내 및 동의" name="liability-waiver" value={waiver}
                    options={[{ value: 'agreed', label: '동의' }, { value: 'declined', label: '동의하지 않음' }]}
                     onChange={(value) => setWaiver(value === 'agreed' ? 'agreed' : 'declined')}
                    hint="고객님의 의사를 명확히 확인해 주세요."
                  />
                  <ChoiceField
                    title="명품 품목 포함 여부" name="luxury-item" value={luxuryItem === null ? null : String(luxuryItem)}
                    options={[{ value: 'true', label: '예 · 명품 포함' }, { value: 'false', label: '아니요' }]}
                    onChange={(value) => setLuxuryItem(value === 'true')}
                  />
                  <div>
                    <label className="final-intake__label" htmlFor="fi-requests">고객 요청사항</label>
                    <span className="final-intake__hint">세탁 시 유의할 점, 선호하는 처리 방식 등을 그대로 남겨 주세요.</span>
                    <textarea className="final-intake__textarea" id="fi-requests" value={customerRequests} onChange={(event) => setCustomerRequests(event.target.value)} placeholder="예: 목 부분 얼룩을 중점적으로 확인해 주세요." data-testid="input-customer-requests" />
                  </div>
                </section>
              </div>
              <div>
                <IntakeSummary customerName={customerName} customerPhone={customerPhone} customerAddress={customerAddress} items={items} orderId={orderId} choices={draft} activePolicy={policyResult.policy} onTotalOverride={setTotalOverride} />
                <fieldset style={{ padding: 12, marginTop: 12, borderRadius: 10,
                  border: `2px solid ${paymentType === 'POSTPAID' ? '#f97316' : '#86efac'}` }}>
                  <legend>결제 구분</legend>
                  <label><input type="radio" name="payment-type" checked={paymentType === 'PREPAID'}
                    onChange={() => setPaymentType('PREPAID')} /> 선불</label>{'　'}
                  <label><input type="radio" name="payment-type" checked={paymentType === 'POSTPAID'}
                    onChange={() => setPaymentType('POSTPAID')} /> 후불</label>
                  <p>{paymentType === 'POSTPAID' ? '미납 · 수령 시 결제 필요' : '선불 결제 완료 건으로 접수합니다.'}</p>
                </fieldset>
                {missing.length > 0 && <div className="final-intake__validation" role="status" data-testid="status-final-intake-validation"><strong>확인 후 접수할 수 있습니다</strong><ul>{missing.map((message) => <li key={message}>{message}</li>)}</ul></div>}
                {saveError && <p className="final-intake__error" role="alert" data-testid="status-final-intake-error">{saveError}</p>}
                <div className="final-intake__actions">
                  <button type="button" className="final-intake__back" onClick={onBack} data-testid="button-final-intake-back">뒤로 가기</button>
                  <button type="button" className="final-intake__confirm" onClick={confirm} disabled={missing.length > 0 || submitting} data-testid="button-final-intake-confirm">최종 접수 확인</button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </main>
  );
}

export default FinalIntakeConfirmation;