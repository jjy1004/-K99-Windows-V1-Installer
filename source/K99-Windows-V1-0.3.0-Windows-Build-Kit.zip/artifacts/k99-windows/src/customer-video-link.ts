export const CUSTOMER_VIDEO_PROTOCOL = 1;
export const CUSTOMER_VIDEO_PING = 'k99-customer-video-ping';
export const CUSTOMER_VIDEO_PONG = 'k99-customer-video-pong';
export const CUSTOMER_VIDEO_LINK_TTL = 6000;

export type VideoProbe = { id: string; sourceId: string; at: number };
export type VideoHeartbeat = { sourceId: string; at: number };
export type VideoLinkState = 'closed' | 'checking' | 'connected' | 'stale' | 'legacy';

export function validVideoPong(data: unknown, probe: VideoProbe | undefined, now = Date.now()): boolean {
  if (!data || typeof data !== 'object' || !probe) return false;
  const reply = data as Record<string, unknown>;
  return reply.type === CUSTOMER_VIDEO_PONG && reply.videoProtocol === CUSTOMER_VIDEO_PROTOCOL &&
    reply.probeId === probe.id && reply.sourceId === probe.sourceId &&
    now >= probe.at && now - probe.at <= CUSTOMER_VIDEO_LINK_TTL;
}

export function videoLinkState(open: boolean, protocol: number | undefined,
  heartbeat: VideoHeartbeat | undefined, sourceId: string, now = Date.now()): VideoLinkState {
  if (!open) return 'closed';
  if (protocol !== undefined && protocol !== CUSTOMER_VIDEO_PROTOCOL) return 'legacy';
  if (!heartbeat || heartbeat.sourceId !== sourceId) return 'checking';
  return now >= heartbeat.at && now - heartbeat.at <= CUSTOMER_VIDEO_LINK_TTL ? 'connected' : 'stale';
}

export const VIDEO_LINK_LABELS: Record<VideoLinkState, string> = {
  closed: '고객 화면 연결 없음 — 기존 고객 화면이 열려 있는지 확인해 주세요.',
  checking: '고객 화면 응답 확인 중',
  connected: '고객 화면 연결 확인됨',
  stale: '고객 화면 응답 없음 — 고객 화면의 주소와 연결을 확인해 주세요.',
  legacy: '고객 화면이 이전 버전입니다. 이미 열린 고객 화면만 새로고침해 주세요.',
};
