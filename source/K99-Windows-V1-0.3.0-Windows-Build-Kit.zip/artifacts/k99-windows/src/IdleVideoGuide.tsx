import { useState } from 'react';
import './notice-center.css';
import './release-settings.css';

type VideoFile = { name: string; url: string; kind?: 'image'; durationMs?: number };
const N = '#13252c', G = '#c9a55a', L = '#f5e9c8', B = '#3c5b63';

const art = [
  <svg key="1" viewBox="0 0 200 120" role="img" aria-label="폴더 열기 그림"><rect x="40" y="30" width="120" height="74" rx="8" fill={G} /><path d="M40 38h50l8-12h-58z" fill="#e8c76d" /><text x="100" y="76" textAnchor="middle" fontSize="16" fill={N} fontWeight="800">홍보 영상 폴더</text></svg>,
  <svg key="2" viewBox="0 0 200 120" role="img" aria-label="영상 끌어다 놓기 그림"><rect x="8" y="30" width="70" height="56" rx="6" fill={B} /><text x="43" y="62" textAnchor="middle" fontSize="13" fill={L}>MP4 영상</text><path d="M84 58h30" stroke={G} strokeWidth="5" markerEnd="url(#a)" /><defs><marker id="a" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto"><path d="M0 0L6 3L0 6z" fill={G} /></marker></defs><rect x="124" y="30" width="68" height="56" rx="6" fill={G} /><text x="158" y="62" textAnchor="middle" fontSize="13" fill={N} fontWeight="800">폴더</text></svg>,
  <svg key="3" viewBox="0 0 200 120" role="img" aria-label="파일 이름 앞에 번호 붙이기 그림"><rect x="20" y="22" width="160" height="32" rx="6" fill={B} /><text x="32" y="44" fontSize="15" fill={L}><tspan fill="#e8c76d" fontWeight="800">01_</tspan>가을할인</text><rect x="20" y="64" width="160" height="32" rx="6" fill={B} /><text x="32" y="86" fontSize="15" fill={L}><tspan fill="#e8c76d" fontWeight="800">02_</tspan>운동화세탁</text></svg>,
  <svg key="4" viewBox="0 0 200 120" role="img" aria-label="고객 화면 재생 그림"><rect x="30" y="16" width="140" height="80" rx="8" fill={B} /><polygon points="88,38 88,74 120,56" fill={G} /><rect x="90" y="96" width="20" height="10" fill={B} /><rect x="70" y="106" width="60" height="6" rx="3" fill={B} /><text x="100" y="32" textAnchor="middle" fontSize="11" fill={L}>고객 화면</text></svg>,
];
const steps = [
  ['폴더 열기', '아래 1번 버튼을 누르면 홍보 영상 폴더가 열립니다.'],
  ['영상 복사', 'MP4 영상을 마우스로 끌어 폴더 안에 놓습니다.'],
  ['순서 정하기', '이름 앞에 01_, 02_ 를 붙이면 그 순서대로 나옵니다.'],
  ['새로고침', '2번 버튼을 누르면 고객 화면에서 재생됩니다.'],
];

export function IdleVideoGuide() {
  const api = typeof window !== 'undefined' ? window.k99Desktop?.idleVideos : undefined;
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [files, setFiles] = useState<VideoFile[] | null>(null);

  async function run(action: 'open' | 'refresh') {
    if (!api || busy) return;
    setBusy(true); setMsg(null);
    try {
      const r = await api(action);
      if (!r.success) { setMsg({ ok: false, text: r.error || '처리하지 못했습니다.' }); return; }
      if (action === 'refresh') {
        const list = r.files ?? [];
        setFiles(list);
        setMsg({ ok: true, text: list.length ? `영상 ${list.length}개를 찾았습니다. 고객 화면에 차례대로 나옵니다.` : '폴더가 비어 있어 기본 영상이 나옵니다.' });
      } else setMsg({ ok: true, text: '홍보 영상 폴더를 열었습니다.' });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : '처리하지 못했습니다.' }); }
    finally { setBusy(false); }
  }

  return <section className="nc-section rs-panel" aria-label="고객 화면 홍보 영상 안내" data-testid="idle-video-guide">
    <h3>고객 화면 홍보 영상 넣는 방법</h3>
    <ol className="rs-steps">{steps.map(([t, d], i) => <li className="rs-step" key={t} data-testid={`step-idle-video-${i + 1}`}>
      {art[i]}<strong>{i + 1}단계 · {t}</strong><span>{d}</span></li>)}</ol>
    <p>그림은 이해를 돕기 위한 설명 그림이며 실제 화면과 모양이 다를 수 있습니다.</p>
    <div className="nc-msg info"><span>폴더에 영상이 하나도 없으면 기본 영상이 나옵니다. 파일 이름 뒤의 .mp4 는 따로 적지 않아도 됩니다. Windows에서 확장자가 숨겨져 있으면 이름을 바꿀 때 .mp4 를 지우지 않도록 주의하세요.</span></div>
    {!api && <div className="nc-msg warn" role="alert" data-testid="text-idle-video-native">이 기능은 매장 PC에 설치된 Windows 앱에서만 사용할 수 있습니다.</div>}
    <div className="nc-toolbar" style={{ marginTop: 16 }}>
      <button className="nc-big gold" type="button" disabled={!api || busy} onClick={() => void run('open')} data-testid="button-idle-video-open">1. 홍보 영상 폴더 열기</button>
      <button className="nc-big" type="button" disabled={!api || busy} onClick={() => void run('refresh')} data-testid="button-idle-video-refresh">2. 영상 목록 새로고침</button>
    </div>
    {msg && <div className={`nc-msg ${msg.ok ? 'ok' : 'err'}`} role={msg.ok ? 'status' : 'alert'} data-testid="text-idle-video-message">{msg.text}</div>}
    {files && files.length > 0 && <ol className="rs-files" data-testid="list-idle-videos">{files.map((f, i) => <li key={f.url} data-testid={`text-idle-video-${i}`}>{f.name}</li>)}</ol>}
  </section>;
}
export default IdleVideoGuide;
