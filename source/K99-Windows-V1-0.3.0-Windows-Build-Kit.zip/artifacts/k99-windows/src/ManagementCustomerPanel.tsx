import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, RefreshCw, Search, X } from 'lucide-react';
import { listCustomerDirectory, type MasterCustomer } from './customer-directory-client';
import { downloadCustomerDirectory, filterCustomerDirectory } from './customer-directory-export';
import { CustomerPhotoFolders } from './CustomerPhotoFolders';
import { directoryRequest } from './customer-directory-client';
import { CustomerPrivacySettings, maskCustomerPhone, PRIVACY_CHANGED } from './CustomerPrivacySettings';
import './notice-center.css';
import './management-directory.css';

const PAGE = 50;
type DesktopEvents = { k99Desktop?: { onChanged?: (cb: () => void) => (() => void) | void } };
const num = (v: number) => (Number.isFinite(v) ? v.toLocaleString('ko-KR') : '-');
const won = (v: number) => (Number.isFinite(v) ? `${v.toLocaleString('ko-KR')}원` : '-');
const errText = (e: unknown) => (e instanceof Error && e.message ? e.message : '고객 명부를 불러오지 못했습니다.');
const when = (v: string) => {
  if (!v) return '-';
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return `${v} (시각 미기록)`;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', dateStyle: 'short', timeStyle: 'short', hour12: false });
};

export function ManagementCustomerPanel() {
  const native = typeof window !== 'undefined' && !!window.k99Desktop;
  const [list, setList] = useState<MasterCustomer[] | null>(null);
  const [loading, setLoading] = useState(native);
  const [error, setError] = useState(native ? '' : '고객 명부는 Windows 앱에서만 열립니다. 브라우저 미리보기는 SQLite 고객 DB에 연결하지 않습니다.');
  const [stale, setStale] = useState(false);
  const [loadedAt, setLoadedAt] = useState<Date | null>(null);
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [exportMsg, setExportMsg] = useState('');
  const [exporting, setExporting] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [maskPhones, setMaskPhones] = useState(true);
  const exportPassword = useRef<HTMLInputElement>(null);
  const composing = useRef(false);
  const seq = useRef(0);
  const alive = useRef(true);
  const detailRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let active = true;
    const privacy = () => directoryRequest<{ maskPhones: boolean }>('GET', '/api/admin/privacy')
      .then(p => { if (active) setMaskPhones(p.maskPhones); })
      .catch(() => { if (active) setMaskPhones(true); });
    if (native) void privacy();
    window.addEventListener(PRIVACY_CHANGED, privacy);
    return () => { active = false; window.removeEventListener(PRIVACY_CHANGED, privacy); };
  }, [native]);

  const load = useCallback(() => {
    if (!window.k99Desktop) return;
    const id = ++seq.current;
    setLoading(true);
    listCustomerDirectory().then((r) => {
      if (!alive.current || id !== seq.current) return;
      if (!Array.isArray(r?.customers)) throw new Error('고객 명부 응답 형식을 확인할 수 없습니다.');
      setList(r.customers); setError(''); setStale(false); setLoadedAt(new Date());
    }).catch((e) => {
      if (!alive.current || id !== seq.current) return;
      setError(errText(e)); setStale(true);
    }).finally(() => { if (alive.current && id === seq.current) setLoading(false); });
  }, []);

  useEffect(() => {
    alive.current = true;
    if (!native) return () => { alive.current = false; };
    load();
    const onVis = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onVis);
    window.addEventListener('storage', onVis);
    let off: (() => void) | void = undefined;
    try { off = (window as unknown as DesktopEvents).k99Desktop?.onChanged?.(load); } catch { off = undefined; }
    return () => {
      alive.current = false; seq.current++;
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', onVis);
      window.removeEventListener('storage', onVis);
      if (typeof off === 'function') off();
    };
  }, [load, native]);

  const filtered = useMemo(() => (list ? filterCustomerDirectory(list, q) : []), [list, q]);
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const cur = Math.min(page, pages - 1);
  const rows = filtered.slice(cur * PAGE, cur * PAGE + PAGE);
  const selected = list?.find((c) => c.id === selectedId) ?? null;
  const exportReady = native && !!list && !loading && !error && !stale && !exporting && filtered.length > 0;

  const pick = (id: string) => {
    setSelectedId(id);
    window.requestAnimationFrame(() => detailRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }));
  };
  const doExport = async () => {
    if (!exportReady || composing.current) return;
    const password = exportPassword.current?.value ?? '';
    setExporting(true);setExportMsg('관리자 비밀번호 확인 후 저장 위치를 선택합니다.');
    try {
      const result=await downloadCustomerDirectory(filtered, password);
      if (alive.current) setExportOpen(false);
      if(alive.current)setExportMsg(result.cancelled?'CSV 저장을 취소했습니다.':result.saved
        ?`고객 ${num(filtered.length)}명 · 접수 이력 CSV 저장 완료: ${result.filePath}`:'CSV 다운로드를 요청했습니다.');
    } catch (e) { if(alive.current)setExportMsg(`CSV 저장 실패: ${errText(e)}`); }
    finally {
      if (exportPassword.current) exportPassword.current.value = '';
      if(alive.current)setExporting(false);
    }
  };

  return <section className="md-panel" aria-label="고객 명부 및 접수 이력" data-testid="panel-customer-directory">
    <header className="md-head">
      <div>
        <h2>고객 명부 · 접수 이력</h2>
        <p data-testid="text-directory-total">{!native ? 'Windows 앱 전용' : list ? `전체 ${num(list.length)}명${q.trim() ? ` · 검색 결과 ${num(filtered.length)}명` : ''}${stale ? ' · 갱신 실패' : ''}` : loading ? '불러오는 중' : '자료 없음'}
          {loadedAt && !stale && <span className="md-time"> · {loadedAt.toLocaleTimeString('ko-KR', { hour12: false })} 기준</span>}</p>
      </div>
      <button type="button" className="md-export" onClick={() => { setExportMsg(''); setExportOpen(true); }} disabled={!exportReady} data-testid="button-export-customers"
        title={exportReady ? '검색 결과의 모든 고객과 전체 접수 이력을 내려받습니다' : '명부를 정상적으로 불러온 뒤 사용할 수 있습니다'}>
        <Download /> 고객 명부 엑셀(CSV) 다운로드</button>
    </header>
    {exportOpen && createPortal(<div className="nc-backdrop" data-notice-modal="true"
      onKeyDown={e => {
        e.stopPropagation();
        if (e.key === 'Escape' && !e.nativeEvent.isComposing && !composing.current && !exporting) setExportOpen(false);
        if(e.key === 'Tab'){
          const nodes=Array.from(e.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),summary'))
            .filter(el=>el.getClientRects().length>0);
          const first=nodes[0],last=nodes.at(-1);
          if(e.shiftKey && document.activeElement===first){e.preventDefault();last?.focus();}
          else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first?.focus();}
        }
      }}
      onKeyUp={e => e.stopPropagation()}>
      <section className="nc-modal narrow" role="dialog" aria-modal="true" aria-labelledby="customer-export-title">
        <h2 id="customer-export-title">고객 명부 내보내기 · 관리자 확인</h2>
        <p>화면의 전화번호 가림 설정과 관계없이 CSV에는 원본 연락처가 포함됩니다. 저장한 파일을 안전하게 보관하세요.</p>
        <form onSubmit={e => { e.preventDefault(); void doExport(); }}
          onCompositionStart={() => { composing.current = true; }} onCompositionEnd={() => { composing.current = false; }}>
          <label className="nc-label">이 PC의 관리자 비밀번호
            <input ref={exportPassword} autoFocus type="password" autoComplete="current-password" maxLength={1024}
              className="nc-input" data-testid="input-export-password" /></label>
          <button className="nc-close" type="submit" disabled={exporting}>확인 후 CSV 저장</button>
          <button className="nc-close" type="button" disabled={exporting} onClick={() => setExportOpen(false)}>취소</button>
        </form>
        {exportMsg && <p role="status">{exportMsg}</p>}
        <details><summary>비밀번호 미설정 · 변경 · 전화번호 가림 설정</summary><CustomerPrivacySettings /></details>
      </section>
    </div>, document.body)}

    <div className="md-tools">
      <label className="md-search"><Search aria-hidden="true" />
        <input type="search" value={q} placeholder="고객명 또는 전화번호 끝자리" aria-label="고객명 또는 전화번호 끝자리 검색"
          onChange={(e) => { setQ(e.target.value); setPage(0); setExportMsg(''); }} disabled={!native} data-testid="input-directory-search" />
        {q && <button type="button" aria-label="검색어 지우기" className="md-clear" onClick={() => { setQ(''); setPage(0); }} data-testid="button-clear-directory-search"><X /></button>}
      </label>
      <button type="button" onClick={load} disabled={!native || loading} data-testid="button-refresh-directory"><RefreshCw className={loading ? 'spin' : ''} /> 새로고침</button>
    </div>

    {exportMsg && <p className="md-note" role="status" data-testid="status-export">{exportMsg}</p>}
    {error && <div className="ss-alert" role="alert" data-testid="status-directory-error">
      <span>{native ? `고객 명부 조회 실패: ${error}${list ? ' · 아래 목록은 이전에 받은 자료이며 최신이 아닐 수 있습니다. 내보내기는 잠겼습니다.' : ''}` : error}</span>
      {native && <button type="button" onClick={load} data-testid="button-retry-directory">다시 시도</button>}
    </div>}

    <div className={`md-table-wrap${stale ? ' stale' : ''}`}>
      {!native ? <p className="ss-empty" data-testid="status-directory-unavailable">브라우저에서는 고객 명부를 표시하지 않습니다.</p>
        : !list && loading ? <div aria-busy="true">{[0, 1, 2, 3, 4].map((i) => <i key={i} className="ss-skel row" />)}</div>
          : !list ? <p className="ss-empty">고객 명부를 불러오지 못했습니다.</p>
            : list.length === 0 ? <p className="ss-empty" data-testid="status-directory-empty">등록된 고객이 없습니다.</p>
              : filtered.length === 0 ? <p className="ss-empty" data-testid="status-directory-noresult">"{q.trim()}"에 맞는 고객이 없습니다.</p>
                : <table className="ss-table md-table">
                  <thead><tr><th>고객명</th><th>연락처</th><th>주소</th><th>최근 접수일</th><th className="num">총 이용</th><th className="num">세탁비 누계</th><th /></tr></thead>
                  <tbody>{rows.map((c) => <tr key={c.id} className={c.id === selectedId ? 'sel' : ''} onClick={() => pick(c.id)} data-testid={`row-customer-${c.id}`}>
                    <td><strong>{c.name || '-'}</strong></td><td className="md-mono">{maskCustomerPhone(c.phone, maskPhones) || '-'}</td>
                    <td className="md-addr" title={c.address}>{c.address || '-'}</td><td>{c.lastVisitDate || '-'}</td>
                    <td className="num">{num(c.totalVisits)}회</td><td className="num">{won(c.totalAmount)}</td>
                    <td><button type="button" className="md-mini" onClick={(e) => { e.stopPropagation(); pick(c.id); }} aria-pressed={c.id === selectedId}
                      data-testid={`button-customer-detail-${c.id}`}>이력 보기</button></td>
                  </tr>)}</tbody>
                </table>}
    </div>

    {list && filtered.length > PAGE && <nav className="md-pager" aria-label="고객 명부 페이지">
      <button type="button" onClick={() => setPage(0)} disabled={cur === 0} data-testid="button-page-first">처음</button>
      <button type="button" onClick={() => setPage(cur - 1)} disabled={cur === 0} data-testid="button-page-prev">이전</button>
      <span data-testid="text-page">{cur + 1} / {pages} 페이지 · {num(cur * PAGE + 1)}–{num(Math.min(filtered.length, cur * PAGE + PAGE))}번째</span>
      <button type="button" onClick={() => setPage(cur + 1)} disabled={cur >= pages - 1} data-testid="button-page-next">다음</button>
      <button type="button" onClick={() => setPage(pages - 1)} disabled={cur >= pages - 1} data-testid="button-page-last">끝</button>
    </nav>}

    <div ref={detailRef}>
      {selectedId && !selected && list && <p className="md-note">선택한 고객이 최신 명부에 없습니다. <button type="button" className="md-mini" onClick={() => setSelectedId(null)}>선택 해제</button></p>}
      {selected && <article className="md-detail" aria-label={`${selected.name} 접수 이력`} data-testid="panel-customer-detail">
        <header>
          <div><h3>{selected.name || '-'} <span className="md-mono">{maskCustomerPhone(selected.phone, maskPhones) || '-'}</span></h3>
            <p>{selected.address || '주소 미기록'}</p></div>
          <button type="button" onClick={() => setSelectedId(null)} data-testid="button-close-customer-detail"><X /> 닫기</button>
        </header>
        <dl className="md-facts">
          <div><dt>총 이용</dt><dd>{num(selected.totalVisits)}회</dd></div>
          <div><dt>총 세탁물</dt><dd>{num(selected.totalItems)}점</dd></div>
          <div><dt>세탁비 누계</dt><dd>{won(selected.totalAmount)}</dd></div>
          <div><dt>최근 접수일</dt><dd>{selected.lastVisitDate || '-'}</dd></div>
        </dl>
        <p className="md-caption">세탁비 누계는 접수 금액 합계이며 실제 수납 확인 금액이 아닙니다.{stale ? ' 현재 표시는 갱신 실패 전 자료입니다.' : ''}</p>
        <CustomerPhotoFolders key={selected.id} customerId={selected.id} />
        {selected.visits.length === 0 ? <p className="ss-empty">접수 이력이 없습니다.</p>
          : <div className="md-table-wrap"><table className="ss-table md-table">
            <thead><tr><th>접수일시</th><th>주문번호</th><th>품목</th><th className="num">수량</th><th className="num">세탁비</th><th>상태</th><th>출처</th></tr></thead>
            <tbody>{selected.visits.map((v) => <tr key={v.id} data-testid={`row-visit-${v.id}`}>
              <td>{when(v.receiptAt || v.visitDate)}</td><td className="md-mono">{v.orderNumber || '-'}</td>
              <td className="md-items">{v.items.length ? v.items.map((i) => `${i.label} × ${i.quantity}`).join(' / ') : '-'}</td>
              <td className="num">{num(v.itemCount)}점</td><td className="num">{won(v.totalAmount)}</td>
              <td>{v.status || '-'}</td>
              <td><span className={`md-src ${v.source}`}>{v.source === 'import' ? '과거 장부(일자별 합산)' : '신규 접수'}</span></td>
            </tr>)}</tbody>
          </table></div>}
      </article>}
    </div>
  </section>;
}
