import { useState } from 'react';
import { ReceptionCustomerLookup } from './CustomerDirectory';
import { customerPhoneDisplay } from './customer-autofill';

export function ManagementCustomerPanel() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const [activeField, setActiveField] = useState<'name' | 'phone'>('name');
  return <section className="ss-table-wrap" aria-label="고객 검색 및 최근 1년 이력" style={{ padding: 20, marginBottom: 20 }}>
    <h2>고객 검색 · 최근 1년 이력</h2>
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginBottom: 12 }}>
      <label>고객명<input className="field-input" value={name} data-testid="input-customer-name"
        placeholder="고객명 2글자 이상" onFocus={() => setActiveField('name')}
        onChange={e => { setActiveField('name'); setName(e.target.value); setSelectedId(''); setAddress(''); }} /></label>
      <label>전화번호 또는 끝4자리<input className="field-input" value={phone} inputMode="tel" data-testid="input-customer-phone"
        placeholder="전화 끝4자리" onFocus={() => setActiveField('phone')}
        onChange={e => { setActiveField('phone'); setPhone(e.target.value); setSelectedId(''); setAddress(''); }} /></label>
      <label style={{ flex: 1 }}>주소<input className="field-input" value={address} readOnly data-testid="input-management-customer-address" /></label>
      <button type="button" className="cdir-btn" onClick={() => { setName(''); setPhone(''); setAddress(''); setSelectedId(''); }}>고객 선택 지우기</button>
    </div>
    <ReceptionCustomerLookup name={name} phone={phone} activeField={activeField} selectedId={selectedId} onSelect={c => {
      setName(c.name); setPhone(customerPhoneDisplay(c.phone)); setAddress(c.address); setSelectedId(c.id);
    }} />
  </section>;
}
