import type { ConfirmedOrder } from './order-record';
import { currentOperations } from './order-operations';
import {
  createCustomerNotification, ensureStorageReminderDrafts, STORAGE_NOTICE_POLICY,
  type CustomerNotification,
} from './notification-workflow';
import { completionNoticeText, logisticsNoticeText } from './customer-notice-text.ts';
import { STORAGE_REMINDER_DAYS } from './storage-policy.ts';

export type PendingNotice = {
  orderId: string; customerName: string; customerPhone: string; notification: CustomerNotification;
  label: string;
};
type NoticeSpec = { key: string; purpose: 'completion' | 'pickup' | 'delivery'; text: string };

function active(order: ConfirmedOrder): boolean {
  const ops = currentOperations(order);
  return !ops.cancelledAt && !ops.completedAt && !['매장수령완료', '배달완료'].includes(ops.stage) &&
    !(order.garments?.length && order.garments.every((g) =>
      g.handoverStatus === 'complete' || g.processStatus === '반출 완료'));
}

function specs(order: ConfirmedOrder): NoticeSpec[] {
  if (!active(order)) return [];
  const ops = currentOperations(order);
  const result: NoticeSpec[] = [];
  const completed = order.status === '전체 세탁 완료 / 반출 대기' && !!order.completionMessage &&
    order.completionMessage.status !== '취소됨' &&
    (!order.garments?.length || order.garments.every((g) =>
      g.completionStatus === 'complete' || g.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER'));
  const cycle = order.orderCompletedAt || order.completionMessage?.generatedAt || '';
  const address = ops.detailAddress || order.customerAddress || '';
  const deliverySignature = JSON.stringify([cycle, ops.deliveryDate, ops.deliveryTime, address]);
  if (completed) result.push({
    key: `completion:${order.choices.deliveryRequested ? deliverySignature : JSON.stringify([cycle, 'store-pickup'])}`,
    purpose: 'completion', text: completionNoticeText(order),
  });
  if (ops.stage === '수거예약' && order.choices.pickupRequested) result.push({
    key: `pickup:${JSON.stringify([ops.pickupDate, ops.pickupTime, address])}`,
    purpose: 'pickup', text: logisticsNoticeText(order, 'pickup'),
  });
  if (order.choices.deliveryRequested && ['배달대기', '배달중'].includes(ops.stage)) result.push({
    key: `delivery:${deliverySignature}`, purpose: 'delivery', text: logisticsNoticeText(order, 'delivery'),
  });
  return result;
}

/** Adds drafts only, preserving all legacy records, approvals, photos and IDs. */
export function ensureOperationalNoticeDrafts(order: ConfirmedOrder, asOf = new Date()): ConfirmedOrder {
  let revised = ensureStorageReminderDrafts(order, asOf);
  for (const spec of specs(order)) {
    if (revised.customerNotifications?.some((notice) => notice.sourceKey === spec.key)) continue;
    const created = createCustomerNotification(revised, spec.purpose === 'completion' ? '세탁 완료' : '수거/배달 안내',
      undefined, spec.text, asOf);
    revised = { ...created, customerNotifications: created.customerNotifications!.map((notice, index, all) =>
      index === all.length - 1 ? { ...notice, sourceKey: spec.key, purpose: spec.purpose } : notice) };
  }
  return revised;
}

/** Called only after the staff explicitly chooses to prepare a previewed notice.
 * Pure: the caller persists with the untouched original as concurrency evidence. */
export function prepareOperationalNoticeReview(order: ConfirmedOrder, preview: CustomerNotification, asOf = new Date()) {
  const revised = ensureOperationalNoticeDrafts(order, asOf);
  const target = revised.customerNotifications?.find(notice =>
    notice.id === preview.id || (!!preview.sourceKey && notice.sourceKey === preview.sourceKey));
  if (!target || !isCurrentOperationalNotice(revised, target))
    throw new Error('안내 대상이나 일정이 변경되었습니다. 기록을 새로고침해 주세요.');
  return { order: revised, noticeId: target.id };
}

export function isCurrentOperationalNotice(order: ConfirmedOrder, notice: CustomerNotification): boolean {
  if (!active(order)) return false;
  if (notice.type === '장기 미수령 알림')
    return notice.storagePolicy === STORAGE_NOTICE_POLICY && (STORAGE_REMINDER_DAYS as readonly number[]).includes(notice.reminderDay ?? 0);
  return !!notice.sourceKey && specs(order).some((spec) => spec.key === notice.sourceKey);
}

/** Derives overdue reminders too, so not opening Operations cannot hide a due customer. */
export function pendingCustomerNotices(orders: ConfirmedOrder[], asOf = new Date()): PendingNotice[] {
  return orders.flatMap((original) => {
    const order = ensureOperationalNoticeDrafts(original, asOf);
    // Completion and day-9/day-13 storage reminders are queued once, latest stage only, by
    // customer-pickup-notices (Today > 고객 안내 단계); they are excluded here to avoid a duplicate queue.
    return (order.customerNotifications ?? []).filter((notice) =>
      isCurrentOperationalNotice(order, notice) && !notice.externalSendConfirmation
      && notice.type !== '장기 미수령 알림' && notice.purpose !== 'completion').map((notification) => ({
      orderId: order.id, customerName: order.customerName, customerPhone: order.customerPhone, notification,
      label: notification.type === '장기 미수령 알림' ? `${notification.reminderDay}일차 보관료 사전 안내`
        : notification.purpose === 'pickup' ? '수거 예정'
        : notification.purpose === 'delivery' ? '배달 예정'
        : `완성 · ${order.choices.deliveryRequested ? '배달 예정' : '매장 수령'}`,
    }));
  });
}
