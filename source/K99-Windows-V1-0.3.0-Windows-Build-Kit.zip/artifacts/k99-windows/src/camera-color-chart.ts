import {makeColorTransform,type CameraColorProfile} from './camera-color';
// Classic 6×4 ColorChecker nominal sRGB references, row-major, white patch
// bottom-left. Other charts/printed copies need their own measured references.
export const CLASSIC_24_RGB=[
  [115,82,68],[194,150,130],[98,122,157],[87,108,67],[133,128,177],[103,189,170],
  [214,126,44],[80,91,166],[193,90,99],[94,60,108],[157,188,64],[224,163,46],
  [56,61,150],[70,148,73],[175,54,60],[231,199,31],[187,86,149],[8,133,161],
  [243,243,242],[200,200,200],[160,160,160],[122,122,121],[85,85,85],[52,52,52],
] as const;
export const CHART_GUIDE={x:.2,y:.15,width:.6,height:.7};
function solve(matrix:number[][],right:number[]){
  const a=matrix.map((row,i)=>[...row,right[i]]);
  for(let c=0;c<4;c++){
    let pivot=c;
    for(let r=c+1;r<4;r++)if(Math.abs(a[r][c])>Math.abs(a[pivot][c]))pivot=r;
    if(Math.abs(a[pivot][c])<1e-8)throw Error('컬러차트 색상 구분이 부족합니다.');
    [a[c],a[pivot]]=[a[pivot],a[c]];
    const scale=a[c][c];for(let j=c;j<5;j++)a[c][j]/=scale;
    for(let r=0;r<4;r++)if(r!==c){
      const factor=a[r][c];for(let j=c;j<5;j++)a[r][j]-=factor*a[c][j];
    }
  }
  return a.map(row=>row[4]);
}
export function calibrateClassic24(frame:{width:number;height:number;data:Uint8ClampedArray},profile:CameraColorProfile){
  const {width:w,height:h,data}=frame,observed:number[][]=[];
  const base={...profile,chartMatrix:undefined},transform=makeColorTransform(base);
  for(let index=0;index<24;index++){
    const col=index%6,row=Math.floor(index/6),rgb=[0,0,0];let count=0,sumSquare=0;
    // Use only the patch centers, not the card's black cell borders.
    const x0=Math.floor(w*(CHART_GUIDE.x+CHART_GUIDE.width*(col+.3)/6));
    const x1=Math.ceil(w*(CHART_GUIDE.x+CHART_GUIDE.width*(col+.7)/6));
    const y0=Math.floor(h*(CHART_GUIDE.y+CHART_GUIDE.height*(row+.3)/4));
    const y1=Math.ceil(h*(CHART_GUIDE.y+CHART_GUIDE.height*(row+.7)/4));
    for(let y=y0;y<y1;y+=2)for(let x=x0;x<x1;x+=2){
      const i=(y*w+x)*4;
      for(let c=0;c<3;c++)rgb[c]+=data[i+c];
      const luminance=(data[i]+data[i+1]+data[i+2])/3;sumSquare+=luminance*luminance;count++;
    }
    if(!count)throw Error('컬러차트 프레임이 너무 작습니다.');
    const mean=rgb.map(v=>v/count),l=mean.reduce((a,b)=>a+b)/3;
    if(Math.sqrt(Math.max(0,sumSquare/count-l*l))>25)throw Error('차트 칸과 안내 격자가 맞지 않습니다.');
    const pixel=new Uint8ClampedArray([...mean,255]);transform(pixel);
    observed.push([pixel[0],pixel[1],pixel[2],1]);
  }
  for(let i=18;i<23;i++){
    const l=(v:number[])=>v.slice(0,3).reduce((a,b)=>a+b)/3;
    if(l(observed[i])-l(observed[i+1])<8)throw Error('표준 24색 차트를 맞춰 주세요. 흰색 칸은 왼쪽 아래입니다.');
  }
  // Small ridge regularization discourages extreme corrections from noise.
  const normal=Array.from({length:4},()=>Array(4).fill(0) as number[]);
  for(const sample of observed)for(let i=0;i<4;i++)for(let j=0;j<4;j++)normal[i][j]+=sample[i]*sample[j];
  for(let i=0;i<3;i++)normal[i][i]+=50;
  const chartMatrix=[0,1,2].map(channel=>{
    const right=Array(4).fill(0) as number[];
    observed.forEach((sample,index)=>sample.forEach((v,i)=>right[i]+=v*CLASSIC_24_RGB[index][channel]));
    right[channel]+=50;
    return solve(normal,right);
  });
  const rmse=Math.sqrt(observed.reduce((sum,sample,index)=>sum+chartMatrix.reduce((a,m,c)=>a+
    Math.pow(m.reduce((v,k,j)=>v+k*sample[j],0)-CLASSIC_24_RGB[index][c],2),0),0)/72);
  if(!Number.isFinite(rmse)||rmse>25||chartMatrix.some(row=>row.some((v,i)=>Math.abs(v)>(i===3?100:3))))
    throw Error('컬러차트의 색상을 신뢰하기 어렵습니다. 반사·그림자·차트 종류를 확인해 주세요.');
  return {...base,chartMatrix};
}
