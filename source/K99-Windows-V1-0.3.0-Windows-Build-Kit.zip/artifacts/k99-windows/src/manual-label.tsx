export const MANUAL_MATERIALS=['폴리에스테르','식물성 섬유','울/실크','나일론'] as const;
export type LabelSelection={manualMaterial:typeof MANUAL_MATERIALS[number];manualColor:'유색'|'흰색'};
export function normalizeLabelSelection(value?:Partial<LabelSelection>):LabelSelection{
  return {manualMaterial:MANUAL_MATERIALS.includes(value?.manualMaterial as LabelSelection['manualMaterial'])
    ?value!.manualMaterial!:'폴리에스테르',manualColor:value?.manualColor==='흰색'?'흰색':'유색'};
}
