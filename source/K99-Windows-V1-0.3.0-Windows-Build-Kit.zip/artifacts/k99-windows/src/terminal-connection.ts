import './desktop-runtime';
/** Discovery is not approval; never gates or changes staff-entered payments. */
export async function refreshTerminalConnection(){
  if(!window.k99Desktop?.hardwareSettings)return {connected:false,message:'단말기 연결 확인은 Windows 설치 앱에서 사용할 수 있습니다.'};
  try{
    const result=await window.k99Desktop.hardwareSettings({action:'terminal-check'});
    return result.terminal??{connected:false,message:'단말기 연결 결과를 확인하지 못했습니다.'};
  }catch{
    return {connected:false,message:'단말기 연결을 확인하지 못했습니다. 수동 설정과 실제 카드 단말기를 확인하세요.'};
  }
}
