export type NoticeDateBinding={start:number;end:number;token:string;value:string};
const OFFSETS:Record<string,number>={오늘날짜:0,수거기한:5,보관료시작일:7,'발송일+5일':5,'발송일+7일':7,'기준일+5일':5,'기준일+7일':7};
/** A direct edit within a generated date makes that date manual; edits elsewhere only shift its range. */
export function editDateBindings(previous:string,next:string,bindings:readonly NoticeDateBinding[]):NoticeDateBinding[]{
  let a=0;while(a<previous.length&&a<next.length&&previous[a]===next[a])a++;
  let b=previous.length,c=next.length;while(b>a&&c>a&&previous[b-1]===next[c-1]){b--;c--;}
  const delta=(c-a)-(b-a);
  return bindings.flatMap(binding=>{
    if(previous.slice(binding.start,binding.end)!==binding.value)return [];
    if(binding.end<=a)return [{...binding}];
    if(binding.start>=b)return [{...binding,start:binding.start+delta,end:binding.end+delta}];
    return [];
  });
}
/** Called synchronously on the send click, before saving/copying/snapshotting the message. */
export function refreshDateBindings(body:string,bindings:readonly NoticeDateBinding[],now=new Date()){
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
  const n=(key:string)=>Number(parts.find(p=>p.type===key)!.value);
  let result='',cursor=0;const next:NoticeDateBinding[]=[];
  for(const binding of [...bindings].sort((a,b)=>a.start-b.start)){
    if(!Object.hasOwn(OFFSETS,binding.token)||!Number.isSafeInteger(binding.start)||!Number.isSafeInteger(binding.end)||
      binding.start<cursor||binding.end<=binding.start||binding.end>body.length||body.slice(binding.start,binding.end)!==binding.value)continue;
    result+=body.slice(cursor,binding.start);
    const date=new Date(Date.UTC(n('year'),n('month')-1,n('day')+OFFSETS[binding.token]));
    const value=`${date.getUTCMonth()+1}월 ${date.getUTCDate()}일`,start=result.length;
    result+=value;next.push({...binding,start,end:result.length,value});cursor=binding.end;
  }
  return {body:result+body.slice(cursor),dateBindings:next};
}
