import {useEffect,useRef,useState,type RefObject} from 'react';
import {CameraHardware,type HardwareField,type HardwarePreferences} from './camera-hardware';
export function useCameraHardware(stream:RefObject<MediaStream|null>,device:string,enabled:boolean,
  preferences:()=>HardwarePreferences|undefined,onApplied:(p:HardwarePreferences)=>boolean,onManual:()=>void){
  const controller=useRef<CameraHardware|null>(null),callbacks=useRef({preferences,onApplied,onManual});
  callbacks.current={preferences,onApplied,onManual};
  const [state,setState]=useState<ReturnType<CameraHardware['read']>|null>(null);
  const [busy,setBusy]=useState(false),[ready,setReady]=useState(false),[identity,setIdentity]=useState(0),[note,setNote]=useState('');
  const debounce=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  useEffect(()=>{
    let active=true,last:MediaStreamTrack|undefined;
    setState(null);setReady(false);setNote('');setBusy(false);controller.current=null;
    const inspect=()=>{
      const track=stream.current?.getVideoTracks()[0];
      if(!track||track.readyState!=='live'||track===last)return;
      last=track;setReady(false);setBusy(true);clearTimeout(debounce.current);
      const c:CameraHardware=new CameraHardware(track,():boolean=>active&&controller.current===c&&stream.current?.getVideoTracks()[0]===track);
      controller.current=c;setIdentity(n=>n+1);setState(c.read());
      void(async()=>{
        const notes=await c.automatic();
        if(!c.busy)notes.push(...await c.restore(callbacks.current.preferences()));
        if(active&&controller.current===c){
          setState(c.read());setNote(notes.join(' '));setBusy(false);setReady(true);
        }
      })().catch(()=>{if(active&&controller.current===c){setBusy(false);setReady(true);setNote('자동 장치 설정에 실패했지만 영상·촬영은 유지합니다.');}});
    };
    const poll=enabled?setInterval(inspect,250):undefined;
    if(enabled)inspect();
    return()=>{active=false;controller.current=null;clearInterval(poll);clearTimeout(debounce.current);};
  },[stream,device,enabled]);
  const same=(c:CameraHardware)=>controller.current===c&&c.active;
  async function automatic(){
    const c=controller.current;if(!c?.active)throw Error('카메라 영상이 켜진 뒤 사용해 주세요.');
    clearTimeout(debounce.current);setBusy(true);
    try{
      const notes=await c.automatic();
      if(!same(c))throw Error('카메라가 변경되었습니다.');
      setState(c.read());setNote(notes.join(' '));
      if(c.busy)throw Error('장치 설정 응답을 기다리고 있습니다. 기존 영상은 유지합니다.');
      if(!callbacks.current.onApplied(c.preferences()))setNote('장치에는 적용했지만 설정을 저장하지 못했습니다.');
      return c;
    }finally{if(same(c))setBusy(false);}
  }
  function onValue(key:HardwareField,value:number){
    const c=controller.current;if(!c?.active)return;
    callbacks.current.onManual();
    setState(s=>s?.controls[key]?{...s,controls:{...s.controls,[key]:{...s.controls[key]!,value}}}:s);
    clearTimeout(debounce.current);
    debounce.current=setTimeout(()=>{setBusy(true);void c.set(key,value).then(p=>{
      if(same(c))setNote(callbacks.current.onApplied(p)?'실제 장치 적용값을 확인하고 저장했습니다.':'장치에는 적용했지만 설정을 저장하지 못했습니다.');
    }).catch(e=>{if(same(c))setNote(e instanceof Error?e.message:'장치 설정 실패');})
      .finally(()=>{if(same(c)){setState(c.read());setBusy(false);}});},180);
  }
  const active=!!controller.current?.active;
  return {state:active?state:null,busy:busy||!active,ready:ready&&active,identity,note,onValue,automatic,current:()=>controller.current?.active?controller.current:null,
    refresh:(c:CameraHardware)=>{if(same(c))setState(c.read());}};
}
