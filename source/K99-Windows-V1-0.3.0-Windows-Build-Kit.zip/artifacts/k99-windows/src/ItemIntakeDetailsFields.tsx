import type { ItemIntakeDetails } from './order-record';
import { reviewClassification } from './item-intake-details';
import './item-intake-details.css';

export function ItemIntakeDetailsFields({ itemId, value, onChange }: {
  itemId: string;
  value: ItemIntakeDetails;
  onChange: (value: ItemIntakeDetails) => void;
}) {
  const review = reviewClassification(itemId, value);
  return (
    <details className="item-intake-details">
      <summary>브랜드 · 소재 · 상태 기록 <small>선택 입력</small></summary>
      <div className="item-intake-details__fields">
        {([
          ['brand', '브랜드', '브랜드명'], ['material', '소재', '예: 실크, 면'],
          ['color', '색상·이염 우려', '예: 검정, 이염 가능'],
          ['stain', '오염·얼룩', '예: 소매 얼룩'],
          ['damage', '기존 훼손', '예: 단추 파손'],
        ] as const).map(([key, label, placeholder]) => (
          <label key={key}>{label}<input value={value[key] ?? ''} maxLength={200} placeholder={placeholder}
            onChange={(event) => onChange({ ...value, [key]: event.target.value })} /></label>
        ))}
        <label>의류 구입가격 · 원
          <input type="number" min="0" max="100000000" step="1" value={value.purchasePrice ?? ''}
            onChange={(event) => onChange({ ...value, purchasePrice: event.target.value ? Number(event.target.value) : undefined })} />
        </label>
        <label>직원 최종 분류
          <select value={value.staffRiskOverride ?? ''} onChange={(event) =>
            onChange({ ...value, staffRiskOverride: event.target.value
              ? event.target.value as ItemIntakeDetails['staffRiskOverride'] : undefined })}>
            <option value="">자동 제안 유지</option>
            <option value="확인 필요">별도 확인 필요</option>
            <option value="일반 접수">일반 접수</option>
          </select>
        </label>
      </div>
      {review.reasons.length > 0 && <p className="item-intake-details__reason">자동 확인 제안: {review.reasons.join(' · ')}</p>}
      {review.requiresReview && <p className="item-intake-details__warning" role="status">별도 확인 필요 · 직원이 전문 검수에서 최종 판단해 주세요.</p>}
      {value.staffRiskOverride === '일반 접수' && review.reasons.length > 0
        && <p className="item-intake-details__reason">직원이 일반 접수로 분류했습니다. 자동 제안 사유는 기록에 남습니다.</p>}
    </details>
  );
}