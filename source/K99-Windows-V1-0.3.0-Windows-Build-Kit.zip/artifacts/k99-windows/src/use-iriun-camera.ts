import {useCallback, useEffect, useRef, type RefObject} from 'react';
import {iriunCameraManager, type CameraState} from './iriun-manager';
import {migrateCameraCache} from './camera-cache';
import {checkCameraEnvironment} from './camera-health';

/** React only subscribes. All acquisition/retry/watchdog/ownership lives in
 * one manager, shared by prereceipt and legacy equipment capture. */
export function useIriunCamera(
  video: RefObject<HTMLVideoElement | null>,
  stream: RefObject<MediaStream | null>,
  onState: (state: CameraState) => void,
  receiver?: {mode?: 'wifi' | 'usb'; change?: (state: {installed?: boolean; warning?: string}) => void},
) {
  const owner = useRef({});
  const callback = useRef(onState); callback.current = onState;
  const receiverOptions = useRef(receiver); receiverOptions.current = receiver;
  const requestId = useRef(0);
  const mounted = useRef(true);
  const receiverSession = useCallback((active: boolean) => {
    if(active)void checkCameraEnvironment();
    const id = ++requestId.current;
    const failed = () => {
      if (active && mounted.current && id === requestId.current)
        receiverOptions.current?.change?.({warning:'PC 수신기를 확인해 주세요. 휴대폰 절전·깨우기는 연결 환경에 따라 다릅니다.'});
    };
    try {
      let savedMode:'wifi'|'usb'='wifi';
      try{if(localStorage.getItem('k99.iriun-connection')==='usb')savedMode='usb';}catch{/* Optional cache cannot block the receiver. */}
      const mode = receiverOptions.current?.mode ?? savedMode;
      const result = window.k99Desktop?.iriunSession?.({active, mode});
      if (result) void result.then(state => {
        if (active && mounted.current && id === requestId.current) receiverOptions.current?.change?.(state);
      }).catch(failed);
    } catch {failed();}
  }, []);
  useEffect(() => {
    mounted.current = true;
    try {migrateCameraCache(localStorage);} catch {}
    return () => {mounted.current = false; iriunCameraManager.stop(owner.current); stream.current = null;};
  }, [stream]);
  const start = useCallback(() => iriunCameraManager.start(owner.current, {
    video: () => video.current,
    prepare: () => receiverSession(true),
    released: () => receiverSession(false),
    change: state => {
      stream.current = state.stream;
      if (mounted.current) callback.current(state);
    },
  }), [video, stream, receiverSession]);
  const stop = useCallback(() => iriunCameraManager.stop(owner.current), []);
  const ensureFresh = useCallback(() => iriunCameraManager.ensureFresh(owner.current), []);
  return {start, stop, ensureFresh};
}
