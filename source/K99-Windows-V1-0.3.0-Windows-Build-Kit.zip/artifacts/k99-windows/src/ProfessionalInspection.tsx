import { IntakePhotoStrip } from './IntakePhotoStrip';
import { orderHandedOver } from './handover-display';
import { useEffect, useRef, useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import { reviewClassification } from './item-intake-details';
import { fillUnselectedInspectionChecks } from './inspection-checklist';
import {
  ADDITIONAL_WORK, CARE_LABEL_METHODS, CLEANING_METHODS, CUSTOMER_DECISIONS, INSPECTION_FIELDS, RISK_FACTORS,
  actualCleaningMethodChanged, approveInspectionCleaning, careLabelConflict, completeInspection,
  generateInspectionMessage, generateShortInspectionMessage, inspectionApprovalRequirements,
  inspectionFindings, inspectionMethodChanged, inspectionNeedsApproval, missingInspectionApprovals,
  originalCleaningMethod, originalMethod, recordInspectionResponse, updateInspectionMessage,
  type AdditionalWork, type InspectionDraft, type InspectionItem, type InspectionRating,
  type InspectionField, type CleaningMethod, type ActualCleaningMethod, type CareLabelMethod, type RiskFactor,
  type CustomerDecision,
} from './inspection-record';
import { StagedApprovalPanel } from './StagedApprovalPanel';
import { ItemNoticePanel } from './ItemNoticePanel';
import { usesTechnicalFeeTemplate } from './technical-fee-notice';
import { previewItemNotice, updateItemNotice, type ItemNotice } from './item-notice';
import './professional-inspection.css';
import { GUIDANCE_LABELS, type GuidanceKind } from './inspection-guidance';
import { ConsentDraftComposer } from './ConsentDraftComposer';
import { readInspectionDraft, writeInspectionDraft, clearInspectionDraft } from './inspection-draft';
import { currentInspectionStatus } from './inspection-status';
import { advanceGarmentInOrder, garmentProcessStatus } from './laundry-process';
import { hasIntakeConcern } from './normal-inspection-policy';

type Props = { order: ConfirmedOrder; onBack: () => void; onSave: (order: ConfirmedOrder) => void; onProceedCleaning?: () => void; onProceedCapture?: () => void; cleaningError?: string };
const won = (value: number) => `${value.toLocaleString('ko-KR')}원`;
const ratings: InspectionRating[] = ['정상', '주의', '문제 있음', '해당 없음'];
const makeDraft = (order: ConfirmedOrder): InspectionDraft => ({
  items: order.items.map((item, index) => ({
    index, itemId: item.itemId,
    checks: Object.fromEntries(INSPECTION_FIELDS.map(field => [field, '정상'])) as Record<InspectionField, InspectionRating>,
    plannedCleaningMethod: item.plannedCleaningMethod ?? '물세탁',
    actualCleaningMethod: item.plannedCleaningMethod ?? '물세탁',
    memo: '', method: '기존 방법 유지',
    customMethod: '', additionalWork: ['추가 작업 없음'], additionalWorkDescription: '',
  })),
  revisedPrice: order.estimatedTotal, additionalCharge: 0, riskRequired: false, riskNotice: '',
  waiverRequired: false, waiverNotice: '',
});

export function ProfessionalInspection({ order, onBack, onSave, onProceedCleaning, onProceedCapture, cleaningError }: Props) {
  // Next eligible step after inspection is photo + first tag (washing starts afterwards).
  const proceedNext = onProceedCapture ?? onProceedCleaning;
  const [initialDraft] = useState(() => {
    try { return { draft: readInspectionDraft(sessionStorage, order) ?? makeDraft(order), error: '' }; }
    catch (cause) { return { draft: makeDraft(order), error: cause instanceof Error ? cause.message : '검수 초안을 읽지 못했습니다.' }; }
  });
  const [draft, setDraft] = useState<InspectionDraft>(initialDraft.draft);
  const [reviewing, setReviewing] = useState(false);
  const saving = useRef(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [error, setError] = useState(initialDraft.error);
  const [draftSaveError, setDraftSaveError] = useState('');
  const [responseChoice, setResponseChoice] = useState<'세탁 진행 동의' | '세탁 진행 거절' | '보류' | ''>('');
  const [decisions, setDecisions] = useState<CustomerDecision[]>([]);
  const [respondedAt, setRespondedAt] = useState('');
  const [responseContent, setResponseContent] = useState('');
  const [staffName, setStaffName] = useState('');
  const [showMethodErrors, setShowMethodErrors] = useState(false);
  const [confirmFillAll, setConfirmFillAll] = useState(false);
  const [pendingNoticeEdit, setPendingNoticeEdit] = useState<{ source: string; text: string } | null>(null);
  const fillAllDialog = useRef<HTMLDialogElement>(null);
  const inspection = order.inspection;
  const currentStatus = currentInspectionStatus(order);
  // Risk-labelled / material-sensitive items must be inspected item by item, never one-click defaults.
  const reviewIndexes = order.items.flatMap((item, index) => item.intakeDetails
    && reviewClassification(item.itemId, item.intakeDetails).requiresReview ? [index] : []);
  useEffect(() => {
    if (inspection || initialDraft.error) return;
    try { writeInspectionDraft(sessionStorage, order, draft); setDraftSaveError(''); }
    catch { setDraftSaveError('전문검수 초안을 보관하지 못했습니다. 새로고침 전에 검수를 완료해 주세요.'); }
  }, [draft, inspection, order, initialDraft.error]);
  const noticePreview = !inspection ? previewItemNotice(order, draft) : undefined;
  const changed = inspectionNeedsApproval(order, draft);
  const priceDifference = draft.revisedPrice - order.estimatedTotal;
  const findings = inspectionFindings(order, draft);
  const methodChanged = inspectionMethodChanged(order, draft);
  const savedFindings = inspection ? inspectionFindings(order, inspection) : [];
  const savedMethodChanged = inspection ? inspectionMethodChanged(order, inspection) : false;
  const requirements = inspectionApprovalRequirements(order, draft);
  const previewOrder = { ...order, inspection: { ...order.inspection, approvalRequirements: requirements } } as ConfirmedOrder;
  const previewMissing = missingInspectionApprovals(previewOrder, []);
  const confirmedDecisions = inspection?.response?.decisions ?? [];
  const missing = missingInspectionApprovals(order, confirmedDecisions);
  const blockingDecision = confirmedDecisions.some((decision) =>
    ['면책 동의하지 않음', '세탁 취소', '기존 방법 유지 요청', '문의 있음', '연락 안 됨'].includes(decision));

  useEffect(() => {
    const dialog = fillAllDialog.current;
    if (!dialog) return;
    if (confirmFillAll && !dialog.open) dialog.showModal();
    if (!confirmFillAll && dialog.open) dialog.close();
  }, [confirmFillAll]);

  function updateItem(index: number, patch: Partial<InspectionItem>) {
    setDraft((current) => ({ ...current, items: current.items.map((item, i) => i === index ? { ...item, ...patch } : item) }));
    setReviewing(false);
  }

  function chooseGuidance(kind: GuidanceKind | undefined) {
    // Staff guidance selection only. Customer consent is recorded separately from the actual reply.
    setDraft((current) => {
      if (!kind) return { ...current, guidanceKind: undefined };
      const risk = kind !== 'fee';
      const charge = kind === 'waiver' ? 0 : Number.isFinite(current.additionalCharge) ? current.additionalCharge ?? 0 : 0;
      return { ...current, guidanceKind: kind, riskRequired: risk, waiverRequired: risk,
        waiverNotice: risk ? current.riskNotice : current.waiverNotice,
        additionalCharge: charge, revisedPrice: order.estimatedTotal + charge };
    });
    setReviewing(false);
  }

  function fillUnselected(index?: number) {
    setDraft((current) => fillUnselectedInspectionChecks(current, index));
    setReviewing(false);
  }

  function review() {
    try {
      // Validate using the same rules as final save, without persisting a draft.
      completeInspection(order, draft);
      setError('');
      setReviewing(true);
      document.getElementById('inspection-review')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '검수 내용을 확인해 주세요.');
      setReviewing(false);
      const firstMissing = draft.items.findIndex((item, index) =>
        !order.items[index].isSneaker && !item.actualCleaningMethod);
      if (firstMissing !== -1) {
        setShowMethodErrors(true);
        document.getElementById(`inspection-item-${firstMissing}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }

  function finish() {
    if (saving.current) return;
    saving.current = true;
    try {
      let updated = completeInspection(order, draft);
      if (!onProceedCapture && !updated.inspection?.needsApproval) {
        for (const garment of updated.garments ?? []) {
          if (garmentProcessStatus(updated, garment) === '세탁 대기')
            updated = advanceGarmentInOrder(updated, garment.garmentId, 'start');
        }
      }
      if (updated.inspection?.itemNotice && pendingNoticeEdit
        && pendingNoticeEdit.source === noticePreview?.steps[1]?.message
        && pendingNoticeEdit.text.trim() !== updated.inspection.itemNotice.steps[1]?.message) {
        updated = updateItemNotice(updated, 1, 'edit', pendingNoticeEdit.text, '');
      } else if (updated.inspection?.needsApproval && !updated.inspection.itemNotice
        && !updated.inspection.stagedApproval && !pendingNoticeEdit && noticePreview?.steps[1]?.message
        && usesTechnicalFeeTemplate(draft.additionalCharge)) {
        // Persist the auto-generated technical-fee stage-1 draft as the short customer message.
        updated = updateInspectionMessage(updated, noticePreview.steps[1].message, 'edit', new Date(), 'short');
      } else if (updated.inspection?.needsApproval && !updated.inspection.itemNotice
        && !updated.inspection.stagedApproval && pendingNoticeEdit
        && pendingNoticeEdit.source === noticePreview?.steps[1]?.message) {
        const text = pendingNoticeEdit.text.trim();
        if (draft.guidanceKind) {
          if (!guidanceNamesIncluded(order, draft, noticePreview.itemIndexes, text)
            || (draft.guidanceKind !== 'waiver' && (!text.includes(won(draft.additionalCharge ?? 0))
              || !text.includes(won(order.estimatedTotal + (draft.additionalCharge ?? 0))))))
            throw new Error('고객 안내 문안에 대상 품목과 기술료·최종 금액을 포함해 주세요.');
        } else if (usesTechnicalFeeTemplate(draft.additionalCharge)) {
          if (!text.includes(`${(draft.additionalCharge ?? 0).toLocaleString('ko-KR')}원`))
            throw new Error('고객 안내 문안에 입력한 추가 기술료를 포함해 주세요.');
        } else if (noticePreview.itemIndexes.some((index) => !text.includes(order.items[index].displayNameKo))
          || (draft.revisedPrice !== order.estimatedTotal
            && !draft.items.some((item) => item.method !== '기존 방법 유지'
              || item.actualCleaningMethod && item.actualCleaningMethod !== order.items[item.index].plannedCleaningMethod)
            && (!text.includes(won(order.estimatedTotal)) || !text.includes(won(draft.revisedPrice)))))
          throw new Error('고객 안내 문안에 대상 품목과 안내할 금액을 포함해 주세요.');
        if (text !== updated.inspection.shortCustomerMessage)
          updated = updateInspectionMessage(updated, text, 'edit', new Date(), 'short');
      }
      onSave(updated);
      try { clearInspectionDraft(sessionStorage, order); } catch { /* Saved inspection is authoritative. */ }
      setError('');
      if (!updated.inspection?.needsApproval) proceedNext?.();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '검수 기록을 저장하지 못했습니다.');
      const firstMissing = draft.items.findIndex((item, index) =>
        !order.items[index].isSneaker && !item.actualCleaningMethod);
      if (firstMissing !== -1) {
        setShowMethodErrors(true);
        document.getElementById(`inspection-item-${firstMissing}`)?.scrollIntoView({ block: 'center' });
      }
      saving.current = false;
    }
  }

  function confirmResponse() {
    if (!responseChoice) { setError('고객 회신을 선택해 주세요.'); return; }
    try {
      onSave(recordInspectionResponse(order, { choice: responseChoice, content: responseContent, staffName }));
      setError('');
      setResponseChoice('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '고객 회신을 기록하지 못했습니다.'); }
  }

  function recordDecisions() {
    try {
      const updated = recordInspectionResponse(order, {
        decisions, content: responseContent, staffName,
        ...(respondedAt ? { respondedAt: new Date(respondedAt).toISOString() } : {}),
      });
      onSave(updated);
      setDecisions([]);
      setError('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '고객 회신을 기록하지 못했습니다.'); }
  }

  function approve() {
    try { saveApproved(approveInspectionCleaning(order, staffName)); setError(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '세탁 진행을 승인하지 못했습니다.'); }
  }

  function saveApproved(updated: ConfirmedOrder) {
    if (!onProceedCapture && updated.status === '세탁 진행 승인') {
      for (const garment of updated.garments ?? []) {
        if (garmentProcessStatus(updated, garment) === '세탁 대기')
          updated = advanceGarmentInOrder(updated, garment.garmentId, 'start');
      }
    }
    onSave(updated);
    if (updated.status === '세탁 진행 승인') proceedNext?.();
  }

  if (noticeOpen && inspection && !inspection.stagedApproval && !inspection.itemNotice) return <InspectionNoticeReview order={order} onSave={onSave}
    onBack={() => setNoticeOpen(false)} />;

  return (
    <main className="professional-inspection" data-testid="screen-professional-inspection">
      <div className="professional-inspection__wrap">
        <header className="professional-inspection__header">
          <div className="professional-inspection__eyebrow">K99 품격세탁소 · 과천점</div>
          <h1>전문 검수</h1>
          <p>접수된 세탁물의 상태와 세탁 방법을 확인합니다.</p>
          <button type="button" className="professional-inspection__back" onClick={onBack}>저장된 접수 내역으로 돌아가기</button>
          {draftSaveError && <p role="alert">{draftSaveError}</p>}
        </header>
        <section className="professional-inspection__panel" aria-label="접수 원본">
          <div className="professional-inspection__section-heading"><h2>고객 · 접수 품목</h2></div>
          <div className="professional-inspection__facts">
            <div><span>고객명</span><strong>{order.customerName}</strong></div>
            <div><span>전화번호</span><strong>{order.customerPhone}</strong></div>
            <div><span>주소</span><strong>{order.customerAddress}</strong></div>
            <div><span>접수일시</span><strong data-testid="inspection-intake-date">{new Date(order.intakeAt).toLocaleString('ko-KR')}</strong></div>
            <div hidden><strong data-testid="inspection-order-id">{order.id}</strong></div>
            
            <div><span>품목 및 수량</span><strong>{order.items.map((item) => `${item.displayNameKo} × ${item.quantity}`).join(', ')} · 총 {order.totalQuantity}점</strong></div>
            <div><span>최초 예상금액</span><strong data-testid="inspection-original-price">{won(order.estimatedTotal)}</strong></div>
            <div><span>고객 요청사항 · 읽기 전용</span><strong data-testid="inspection-original-request">{order.choices.customerRequests || '특별 요청사항 없음'}</strong></div>
          </div>
          <IntakePhotoStrip garments={order.garments ?? []} />
        </section>

        {!inspection ? (
          <>
            <div className="professional-inspection__bulk-actions">
              <button type="button" className="professional-inspection__primary"
                disabled={changed || findings.length > 0 || order.choices.luxuryItem ||
                  hasIntakeConcern(order.choices.customerRequests) ||
                  order.items.some(item => hasIntakeConcern(item.intakeDetails?.stain) || hasIntakeConcern(item.intakeDetails?.damage))
                  || reviewIndexes.length > 0}
                onClick={finish} data-testid="button-inspection-normal-start">
                전문검수 완료
              </button>
              <button type="button" className="professional-inspection__back"
                onClick={() => setConfirmFillAll(true)} data-testid="button-inspection-fill-all-unselected">
                모든 품목 정상 확인
              </button>
            </div>
            <dialog ref={fillAllDialog} className="professional-inspection__confirm-dialog"
              aria-labelledby="inspection-fill-all-title" onClose={() => setConfirmFillAll(false)}>
              <h2 id="inspection-fill-all-title">전체 품목 검수 항목 확인</h2>
              <p>모든 품목의 미선택 검수 항목을 정상으로 처리하시겠습니까?</p>
              <div className="professional-inspection__confirm-actions">
                <button type="button" onClick={() => setConfirmFillAll(false)}>취소</button>
                <button type="button" onClick={() => { fillUnselected(); setConfirmFillAll(false); }}
                  data-testid="button-inspection-confirm-fill-all">정상 처리</button>
              </div>
            </dialog>
            {draft.items.map((item, index) => (
              <details className={`professional-inspection__panel${showMethodErrors && !order.items[index].isSneaker && !item.actualCleaningMethod
                ? ' professional-inspection__panel--method-missing' : ''}`} key={`${item.itemId}-${index}`}
                id={`inspection-item-${index}`} data-testid={`inspection-item-${index}`} open={reviewIndexes.includes(index)}>
                <summary>{order.items[index].displayNameKo} × {order.items[index].quantity} · {reviewIndexes.includes(index) ? '소재·위험 표시 확인 필요' : '정상 기본값'} · 상세 확인 ▾</summary>
                <div className="professional-inspection__section-heading">
                  <h2>{String(index + 1).padStart(2, '0')} · {order.items[index].displayNameKo} × {order.items[index].quantity}</h2>
                  <span>접수 서비스: {originalMethod(order, order.items[index])}</span>
                </div>
                {order.items[index].intakeDetails && <p className="professional-inspection__intake-observation">
                  접수 시 상태 기록: {([
                    ['브랜드', order.items[index].intakeDetails?.brand],
                    ['구입가격', order.items[index].intakeDetails?.purchasePrice
                      ? `${order.items[index].intakeDetails.purchasePrice?.toLocaleString('ko-KR')}원` : ''],
                    ['소재', order.items[index].intakeDetails?.material],
                    ['색상', order.items[index].intakeDetails?.color],
                    ['오염', order.items[index].intakeDetails?.stain],
                    ['훼손', order.items[index].intakeDetails?.damage],
                    ['직원 분류', order.items[index].intakeDetails?.staffRiskOverride],
                  ] as const).filter(([, value]) => value).map(([label, value]) => `${label} ${value}`).join(' · ') || '추가 설명 없음'}
                  {reviewClassification(item.itemId, order.items[index].intakeDetails!).requiresReview && ' · 별도 확인 제안'}
                </p>}
                <div className="professional-inspection__item-actions">
                  <button type="button" className="professional-inspection__back"
                    onClick={() => updateItem(index, {
                      checks: Object.fromEntries(INSPECTION_FIELDS.map((field) => [field, '정상'])) as Record<InspectionField, InspectionRating>,
                    })}
                    data-testid={`button-inspection-all-normal-${index}`} hidden>이 품목 전체 정상으로 표시</button>
                  <button type="button" className="professional-inspection__back professional-inspection__fill-unselected"
                    onClick={() => fillUnselected(index)}
                    data-testid={`button-inspection-fill-unselected-${index}`}>이 품목 정상 확인</button>
                </div>
                <div className="professional-inspection__check-grid">
                  {INSPECTION_FIELDS.map((field) => (
                    <fieldset key={field} className="professional-inspection__check">
                      <legend>{field}</legend>
                      <div className="professional-inspection__ratings">
                        {ratings.map((rating) => (
                          <label key={rating}><input type="radio" name={`inspection-${index}-${field}`}
                            checked={item.checks[field] === rating}
                            onChange={() => updateItem(index, { checks: { ...item.checks, [field]: rating } })} />{rating}</label>
                        ))}
                      </div>
                    </fieldset>
                  ))}
                </div>
                <label className="professional-inspection__field">상세 검수 메모
                  <textarea value={item.memo} onChange={(event) => updateItem(index, { memo: event.target.value })}
                    placeholder="확인한 사실만 기록해 주세요." data-testid={`inspection-memo-${index}`} />
                </label>
                {!order.items[index].isSneaker && (
                  <>
                   {!order.items[index].plannedCleaningMethod && (
                     <fieldset className="professional-inspection__actual-method">
                       <legend>접수 당시 요청 세탁방법 <span>선택 · 직원이 고객 요청을 확인한 경우에만 기록</span></legend>
                       <p>접수 기록에 예정 방법이 없습니다. 유추하지 말고 확인한 내용만 선택해 주세요.</p>
                       <div className="professional-inspection__actual-options">
                         {(['물세탁', '드라이세탁'] as const).map((method) => (
                           <label key={method}><input type="radio" name={`inspection-original-${index}`}
                             checked={item.plannedCleaningMethod === method}
                             onChange={() => updateItem(index, { plannedCleaningMethod: method })} />{method}</label>
                         ))}
                         <label><input type="radio" name={`inspection-original-${index}`}
                           checked={!item.plannedCleaningMethod}
                           onChange={() => updateItem(index, { plannedCleaningMethod: undefined })} />확인되지 않음</label>
                       </div>
                     </fieldset>
                   )}
                  <fieldset className={`professional-inspection__actual-method${showMethodErrors && !item.actualCleaningMethod
                    ? ' professional-inspection__actual-method--missing' : ''}`} data-testid={`inspection-actual-method-${index}`}>
                    <legend>세탁 방법 <span>필수 · 전문가가 결정한 실제 작업 방법</span></legend>
                     {originalCleaningMethod(order, draft, index) && <p>최초 예정 세탁방법: {originalCleaningMethod(order, draft, index)}</p>}
                    <div className="professional-inspection__actual-options">
                      {(['물세탁', '드라이세탁'] as const).map((method) => (
                        <label key={method}>
                          <input type="radio" name={`inspection-actual-method-${index}`}
                            checked={item.actualCleaningMethod === method}
                            onChange={() => updateItem(index, { actualCleaningMethod: method as ActualCleaningMethod })} />
                          {method}
                        </label>
                      ))}
                    </div>
                    {showMethodErrors && !item.actualCleaningMethod && <p role="alert">세탁 방법을 선택해 주세요.</p>}
                  </fieldset>
                   <div className="professional-inspection__item-bottom">
                     <label className="professional-inspection__field">세탁표시 · 케어라벨
                       <select value={item.careLabelMethod ?? ''} onChange={(event) =>
                         updateItem(index, { careLabelMethod: event.target.value as CareLabelMethod || undefined })}>
                         <option value="">선택하지 않음</option>
                         {CARE_LABEL_METHODS.map((method) => <option key={method} value={method}>{method}</option>)}
                       </select>
                     </label>
                     {item.careLabelMethod === '기타' && <label className="professional-inspection__field">기타 세탁표시 내용
                       <input value={item.careLabelOther ?? ''} onChange={(event) => updateItem(index, { careLabelOther: event.target.value })} />
                     </label>}
                   </div>
                   {careLabelConflict(item) && <p className="professional-inspection__warning" role="alert">
                     세탁표시와 실제 세탁방법이 다릅니다. 위험 사항과 고객 확인 내용을 구체적으로 기록해 주세요.
                   </p>}
                   {actualCleaningMethodChanged(order, draft, index) && <label className="professional-inspection__field">
                     세탁방법 변경 사유 · 필수
                     <textarea value={item.methodChangeReason ?? ''} onChange={(event) => updateItem(index, { methodChangeReason: event.target.value })}
                       placeholder="원래 방법과 다른 작업을 선택한 이유" />
                   </label>}
                   <fieldset className="professional-inspection__work">
                     <legend>품목별 위험 요소 · 여러 개 선택 가능</legend>
                     <div className="professional-inspection__work-options">
                       {RISK_FACTORS.map((factor) => <label key={factor}><input type="checkbox"
                         checked={(item.riskFactors ?? []).includes(factor)}
                         onChange={() => updateItem(index, { riskFactors: (item.riskFactors ?? []).includes(factor)
                           ? (item.riskFactors ?? []).filter((entry) => entry !== factor)
                           : [...(item.riskFactors ?? []), factor] as RiskFactor[] })} />{factor}</label>)}
                     </div>
                   </fieldset>
                   <label className="professional-inspection__field">품목별 위험 안내 상세
                     <textarea value={item.riskDetails ?? ''} onChange={(event) => updateItem(index, { riskDetails: event.target.value })}
                       placeholder="예상되는 변화, 해당 부위와 근거를 기록해 주세요." />
                   </label>
                  </>
                )}
                <div className="professional-inspection__item-bottom">
                  <label className="professional-inspection__field">권장 세탁 방법
                    <select value={item.method} onChange={(event) => updateItem(index, { method: event.target.value as CleaningMethod })}
                      data-testid={`inspection-method-${index}`}>
                      {CLEANING_METHODS.map((method) => <option key={method}>{method}</option>)}
                    </select>
                  </label>
                  {item.method === '기타' && <label className="professional-inspection__field">기타 세탁 방법
                    <input value={item.customMethod} onChange={(event) => updateItem(index, { customMethod: event.target.value })} />
                  </label>}
                </div>
                <fieldset className="professional-inspection__work">
                  <legend>추가 작업 · 여러 개 선택 가능</legend>
                  <div className="professional-inspection__work-options">
                    {ADDITIONAL_WORK.map((work) => (
                      <label key={work}><input type="checkbox" checked={item.additionalWork.includes(work)}
                        onChange={() => {
                          const next: AdditionalWork[] = work === '추가 작업 없음'
                            ? ['추가 작업 없음'] : item.additionalWork.includes(work)
                              ? item.additionalWork.filter((entry) => entry !== work)
                              : [...item.additionalWork.filter((entry) => entry !== '추가 작업 없음'), work];
                          updateItem(index, { additionalWork: next.length ? next : ['추가 작업 없음'] });
                        }} />{work}</label>
                    ))}
                  </div>
                </fieldset>
                {item.additionalWork.some((work) => work !== '추가 작업 없음') && (
                  <label className="professional-inspection__field">추가 작업 설명
                    <textarea value={item.additionalWorkDescription}
                      onChange={(event) => updateItem(index, { additionalWorkDescription: event.target.value })}
                      data-testid={`inspection-work-description-${index}`} />
                  </label>
                )}
              </details>
            ))}
            <details className="professional-inspection__panel professional-inspection__fee-panel">
              <summary className="professional-inspection__fee-summary" data-testid="button-open-fee-risk-detail">
                <span className="professional-inspection__fee-trigger">이상 의류 추가 요금·위험 안내 상세 확인</span>
                <span className="professional-inspection__fee-caption" data-testid="text-fee-risk-caption">추가 기술료 또는 세탁 위험이 있는 의류는 반드시 확인하세요.</span>
              </summary>
              <label className="professional-inspection__field">세탁물명
                <input type="text" maxLength={80} value={draft.feeItemName ?? ''} data-testid="input-fee-item-name"
                  placeholder={order.items.map((item) => item.displayNameKo).join('·')}
                  onChange={(event) => { setDraft((current) => ({ ...current, feeItemName: event.target.value })); setReviewing(false); }} />
              </label>
              <div className="professional-inspection__section-heading"><h2>금액 및 위험 안내</h2><span>원본 예상금액은 변경되지 않습니다</span></div>
              <div className="professional-inspection__price">
                <div><span>최초 예상금액</span><strong>{won(order.estimatedTotal)}</strong></div>
                 <label className="professional-inspection__field">기술료 합계 · 기존 접수 기술료 {won(order.choices.technicalFee ?? 0)} 포함
                   <input type="number" disabled={draft.guidanceKind === 'waiver'} min={order.choices.technicalFee ?? 0} step="1" value={Number.isFinite(draft.additionalCharge) ? (order.choices.technicalFee ?? 0) + (draft.additionalCharge ?? 0) : ''}
                     onChange={(event) => { const charge = event.target.value === '' ? NaN : Number(event.target.value) - (order.choices.technicalFee ?? 0);
                       setDraft((current) => ({ ...current, additionalCharge: charge, revisedPrice: order.estimatedTotal + charge }));
                       setReviewing(false); }} data-testid="inspection-additional-charge" />
                 </label>
                <label className="professional-inspection__field">검수 후 예상금액
                  <input type="number" min="0" step="1" value={Number.isFinite(draft.revisedPrice) ? draft.revisedPrice : ''}
                    onChange={(event) => { setDraft({ ...draft, revisedPrice: event.target.value === '' ? NaN : Number(event.target.value) }); setReviewing(false); }}
                    data-testid="inspection-revised-price" />
                </label>
                <div><span>변동금액</span><strong data-testid="inspection-price-difference">{Number.isFinite(priceDifference) ? `${priceDifference > 0 ? '+' : ''}${won(priceDifference)}` : '금액을 입력해 주세요'}</strong></div>
              </div>
              <fieldset className="professional-inspection__guidance" data-testid="fieldset-guidance-kind">
                <legend>고객 안내 유형 · 하나만 선택</legend>
                <div className="professional-inspection__guidance-options" role="radiogroup" aria-label="고객 안내 유형">
                  {(['waiver', 'fee', 'both'] as GuidanceKind[]).map((kind) => (
                    <button type="button" key={kind} role="radio" aria-checked={draft.guidanceKind === kind}
                      className={`professional-inspection__guidance-option${draft.guidanceKind === kind ? ' is-selected' : ''}`}
                      data-testid={`button-guidance-${kind}`} onClick={() => chooseGuidance(kind)}>
                      <strong>{GUIDANCE_LABELS[kind]}</strong>
                      <span>{kind === 'waiver' ? '위험 안내 · 추가 금액 없음' : kind === 'fee' ? '추가 작업 · 기술료 안내' : '위험 안내와 기술료 함께'}</span>
                    </button>
                  ))}
                </div>
                {draft.guidanceKind && <button type="button" className="professional-inspection__guidance-clear"
                  data-testid="button-guidance-clear" onClick={() => chooseGuidance(undefined)}>안내 유형 선택 해제</button>}
              </fieldset>
              {!draft.guidanceKind && draft.riskRequired && <p className="professional-inspection__warning" role="status" data-testid="text-legacy-risk">
                이전 방식으로 위험 안내가 설정된 초안입니다. 위 세 가지 중 하나를 선택해 주세요.
              </p>}
              {(draft.guidanceKind === 'fee' || draft.guidanceKind === 'both') && <label className="professional-inspection__field">필요한 추가 작업 내용 · 필수
                <textarea maxLength={500} value={draft.guidanceWorkDescription ?? ''} data-testid="inspection-guidance-work"
                  onChange={(event) => { const guidanceWorkDescription = event.target.value;
                    setDraft((current) => ({ ...current, guidanceWorkDescription })); setReviewing(false); }}
                  placeholder="예: 소매 부분 특수 얼룩 제거 전처리 2회" />
              </label>}
              {(draft.riskRequired || draft.guidanceKind === 'waiver' || draft.guidanceKind === 'both') && <label className="professional-inspection__field">예상 위험 내용 · 필수
                <textarea maxLength={500} value={draft.riskNotice} onChange={(event) => { const riskNotice = event.target.value;
                  setDraft((current) => ({ ...current, riskNotice, ...(current.waiverRequired ? { waiverNotice: riskNotice } : {}) })); setReviewing(false); }}
                  data-testid="inspection-risk-notice" placeholder="예: 원단 수축, 이염, 코팅 박리 (실제 확인한 위험만 입력)" />
              </label>}
              <p className="professional-inspection__consent-note" data-testid="text-customer-consent-status">
                위 설정은 직원 안내 설정입니다. 고객 동의는 고객의 실제 회신(댓글 ‘동의합니다’)을 확인한 뒤 고객 회신 기록에서 별도로 저장됩니다. 현재 고객 동의: 미기록
              </p>

               <div className="professional-inspection__staged-opt-in">
                 <label className="professional-inspection__inline-check">
                   <input type="checkbox" checked={draft.stagedStainRemoval ?? false}
                     onChange={(event) => { setDraft((current) => ({ ...current, stagedStainRemoval: event.target.checked })); setReviewing(false); }}
                     data-testid="inspection-staged-opt-in" />
                   얼룩 제거 단계별 고객 확인 사용
                 </label>
                 <p>선택한 경우에만 적용됩니다. 의류의 얼룩 특이사항(주의 또는 문제 있음), 케어라벨과 다른 세탁방법, 변경 사유와 구체적 위험 요소·설명, 직접 입력한 추가요금 및 일치하는 최종 예상금액이 필요합니다.</p>
                 <p>먼저 얼룩 제거 의사를 묻고, 동의한 경우에만 위험을 안내합니다. 위험 동의 후에만 추가요금을 안내합니다. 각 회신은 직원이 직접 확인합니다.</p>
               </div>
            </details>
            <section id="inspection-review" className="professional-inspection__panel professional-inspection__decision">
              <h2>{changed ? '고객 재확인 필요' : findings.length ? '검수 특이사항 있음' : '변경사항 없음'}</h2>
              <p>{changed
                ? '가격, 세탁 방법, 추가 작업 또는 위험 안내가 변경되었습니다. 검수 완료 후 고객 승인 전에는 변경된 세탁을 진행할 수 없습니다.'
                : findings.length ? '세탁 전 확인된 상태를 기록하고 고객에게 안내할 수 있습니다. 세탁방법과 금액의 변경 여부는 아래에서 확인해 주세요.'
                  : '검수 결과 변경사항이 없습니다. 기존 접수 내용으로 세탁을 진행할 수 있습니다.'}</p>
              {changed && !!order.garments?.length && <fieldset className="professional-inspection__approval-scope">
                <legend>예외·고객 동의 대상 의류</legend>
                <p>해당 의류만 선택하면 나머지 정상 의류는 별도로 진행할 수 있습니다. 선택하지 않으면 주문 전체에 동의 절차를 적용합니다.</p>
                {order.garments.map(g => <label key={g.garmentId} className="professional-inspection__inline-check">
                  <input type="checkbox" checked={draft.affectedGarmentIds?.includes(g.garmentId) ?? false}
                    data-testid={`inspection-scope-${g.garmentId}`}
                    onChange={event => setDraft(current => {
                      const ids = event.target.checked ? [...(current.affectedGarmentIds ?? []), g.garmentId]
                        : (current.affectedGarmentIds ?? []).filter(id => id !== g.garmentId);
                      return { ...current, affectedGarmentIds: ids.length ? ids : undefined };
                    })} />
                  {g.itemName} · {g.sequence}/{g.totalSequence}
                </label>)}
              </fieldset>}
               {noticePreview && <DraftItemNoticePanel
                 key={JSON.stringify([noticePreview.steps[1]?.message, noticePreview.riskConsent,
                   noticePreview.priceConsent, noticePreview.waiverConsent])}
                 order={order} draft={draft} notice={noticePreview}
                 onEdit={(text) => setPendingNoticeEdit(text === null ? null : {
                   source: noticePreview.steps[1]!.message, text,
                 })} />}
               {draft.stagedStainRemoval ? <div className="professional-inspection__approval-preview" role="status">
                 <strong>단계별 확인 선택됨</strong>
                 <p>검수 저장 후 1단계 얼룩 제거 의사만 안내 문안에 표시됩니다. 다음 단계는 이전 고객 회신을 직원이 확인한 뒤 열립니다.</p>
               </div> : <div className="professional-inspection__approval-preview">
                 <strong>독립 확인 항목</strong>
                 <p>{Object.entries(requirements).filter(([, required]) => required).map(([key]) =>
                   ({ method: '세탁방법 변경', price: '추가요금', risk: '위험 안내', waiver: '면책 동의',
                     work: '추가 작업', otherPriceChange: '금액 변경' } as Record<string, string>)[key]).join(' · ') || '추가 승인 항목 없음'}</p>
                 {previewMissing.length > 0 && <ul>{previewMissing.map((condition) => <li key={condition}>{condition}</li>)}</ul>}
                </div>}
              {findings.length > 0 && <div className="professional-inspection__findings" data-testid="inspection-review-findings">
                 <strong>검수 특이사항 · 세탁 전 확인한 상태</strong>
                <ul>{findings.map((finding) => <li key={`${finding.index}-${finding.category}`}>
                  <strong>{finding.itemName} × {finding.quantity}</strong> — {finding.category}: {finding.result}
                  {finding.memo && ` · 메모: ${finding.memo}`}
                </li>)}</ul>
              </div>}
               <div className="professional-inspection__change-summary" data-testid="inspection-review-changes">
                 <strong>세탁방법 · 금액 · 위험 판단</strong>
                 <p>{methodChanged ? '세탁방법 변경 있음' : '세탁방법 변경 없음'} · {priceDifference ? '금액 변경 있음' : '금액 변경 없음'}</p>
                 <p>기존 예상금액 {won(order.estimatedTotal)} → 검수 후 {Number.isFinite(draft.revisedPrice) ? won(draft.revisedPrice) : '확인 필요'}</p>
                 <p>위험 안내 {draft.riskRequired || draft.items.some((item) => item.riskFactors?.length) ? '기록됨' : '없음'}</p>
               </div>
              <div className="professional-inspection__actions">
                {changed && <button type="button" onClick={review} data-testid="button-review-inspection">변경·동의사항 미리 보기</button>}
                <button type="button" className="professional-inspection__primary" onClick={finish}
                  data-testid="button-complete-inspection">전문 검수 완료</button>
              </div>
              {reviewing && <p role="status">필수 항목을 확인했습니다. 전문 검수 완료 후 실제 고객 동의가 필요한 항목만 승인 대기합니다.</p>}
            </section>
          </>
        ) : (
          <>
            <section className="professional-inspection__panel professional-inspection__decision" data-testid="inspection-result">
              <div className="professional-inspection__section-heading"><h2>{orderHandedOver(order) ? '인도 완료' : order.status === '고객 회신 대기' || order.status === '고객 승인 대기' ? '사전 동의 요청 · 작업 전' : order.status === '세탁 진행 승인' ? '전문검수 완료 · 작업 진행 가능' : `검수 결과 · ${currentStatus.status}`}</h2><span>{new Date(inspection.inspectedAt).toLocaleString('ko-KR')}</span></div>
               <strong>{orderHandedOver(order) ? '인도 완료' : currentStatus.message ? currentStatus.status
                 : inspection.stagedApproval?.outcome === 'approved' ? '고객 승인 완료 / 세탁 진행 가능'
                 : order.status === '고객 승인 대기' || order.status === '고객 회신 대기' ? '고객 재확인 필요'
                : order.status === '세탁 진행 승인' ? inspection.needsApproval ? '고객 동의 확인 완료'
                  : savedFindings.length ? '검수 특이사항 있음' : '변경사항 없음'
                  : order.status}</strong>
                <p>{currentStatus.message ?? (inspection.stagedApproval || inspection.itemNotice ? '단계별 고객 안내 기록을 아래에서 확인해 주세요. 필요한 회신이 확인되기 전에는 변경된 세탁을 진행하지 않습니다.'
                 : order.status === '고객 승인 대기' || order.status === '고객 회신 대기'
                ? '고객 승인 대기 중에는 변경된 세탁 작업을 진행할 수 없습니다. 직원이 고객 회신을 직접 확인해 기록해야 합니다.'
                : order.status === '세탁 진행 승인'
                  ? inspection.needsApproval ? '직원이 고객 동의를 확인해 기록했습니다. 변경된 세탁을 진행할 수 있습니다.'
                     : savedFindings.length ? '세탁 전 확인된 상태를 기록했습니다. 고객 안내 메시지는 직원이 검토할 수 있으며 자동 발송되지 않습니다.'
                       : '검수 결과 변경사항이 없습니다. 기존 접수 내용으로 세탁을 진행할 수 있습니다.'
                  : '고객 회신 상태를 확인해 주세요. 세탁 작업을 진행할 수 없습니다.')}</p>
              <div className="professional-inspection__facts">
                <div><span>최초 예상금액</span><strong>{won(inspection.originalPrice)}</strong></div>
                <div><span>추가요금</span><strong>{won(inspection.additionalCharge ?? 0)}</strong></div>
                <div><span>검수 후 예상금액</span><strong>{won(inspection.revisedPrice)}</strong></div>
                <div><span>변동금액</span><strong>{`${inspection.priceDifference > 0 ? '+' : ''}${won(inspection.priceDifference)}`}</strong></div>
              </div>
              {savedFindings.length > 0 && <div className="professional-inspection__findings" data-testid="inspection-result-findings">
                <strong>검수 특이사항 · 세탁 전 확인한 상태</strong>
                <ul>{savedFindings.map((finding) => <li key={`${finding.index}-${finding.category}`}>
                  <strong>{finding.itemName} × {finding.quantity}</strong> — {finding.category}: {finding.result}
                  {finding.memo && ` · 메모: ${finding.memo}`}
                </li>)}</ul>
              </div>}
              <div className="professional-inspection__change-summary" data-testid="inspection-result-changes">
                <strong>세탁방법 · 금액 · 위험 판단</strong>
                <p>{savedMethodChanged ? '세탁방법 변경 있음' : '세탁방법 변경 없음'} · {inspection.priceDifference ? '금액 변경 있음' : '금액 변경 없음'}</p>
                <p>위험 안내 {inspection.riskRequired || inspection.items.some((item) => item.riskFactors?.length) ? '기록됨' : '없음'}</p>
              </div>
              {inspection.items.map((item, index) => (
                <details key={`${item.itemId}-${index}`} className="professional-inspection__saved-item">
                  <summary>{order.items[index].displayNameKo} × {order.items[index].quantity} · {item.method === '기존 방법 유지' ? inspection.originalMethods[index] : item.method === '기타' ? item.customMethod : item.method}</summary>
                  {item.actualCleaningMethod && <p>세탁 방법: {item.actualCleaningMethod}
                    {item.plannedCleaningMethod && ` · 최초 예정 세탁방법: ${item.plannedCleaningMethod}`}</p>}
                  {item.careLabelMethod && <p>세탁표시: {item.careLabelMethod === '기타' ? item.careLabelOther : item.careLabelMethod}
                    {careLabelConflict(item) && ' · 세탁표시와 작업방법 불일치'}</p>}
                  {item.methodChangeReason && <p>세탁방법 변경 사유: {item.methodChangeReason}</p>}
                  {!!item.riskFactors?.length && <p>위험 요소: {item.riskFactors.join(', ')}</p>}
                  {item.riskDetails && <p>위험 안내 상세: {item.riskDetails}</p>}
                  <p>{INSPECTION_FIELDS.map((field) => `${field}: ${item.checks[field]}`).join(' · ')}</p>
                  {item.memo && <p>상세 검수 메모: {item.memo}</p>}
                  <p>추가 작업: {item.additionalWork.join(', ')} {item.additionalWorkDescription}</p>
                </details>
              ))}
              {inspection.riskRequired && <p>면책 및 위험 안내: {inspection.riskNotice}</p>}
              {inspection.waiverRequired && <p>면책 동의 범위: {inspection.waiverNotice}</p>}
              {order.status === '세탁 진행 승인' && <>
                <button type="button" className="professional-inspection__primary" onClick={proceedNext}
                  data-testid="button-proceed-cleaning">{onProceedCapture ? '사진·최초 태그 단계로 이동' : '세탁 진행 단계로 이동'}</button>
                {cleaningError && <p role="alert" className="professional-inspection__warning">{cleaningError}</p>}
              </>}
              {(order.status === '고객 승인 대기' || order.status === '고객 회신 대기') &&
                <p className="professional-inspection__warning" role="status">{order.status} · 세탁 진행 불가</p>}
              {order.status === '세탁 진행 거절' && <p className="professional-inspection__warning">세탁 진행 거절 · 세탁 진행 불가</p>}
              {order.status === '보류' && <p className="professional-inspection__warning">보류 · 세탁 진행 불가</p>}
            </section>
            {inspection.stagedApproval && <StagedApprovalPanel order={order} onSave={saveApproved} />}
            {inspection.itemNotice && <ItemNoticePanel order={order} onSave={saveApproved} />}
            {!inspection.stagedApproval && !inspection.itemNotice && (inspection.needsApproval || savedFindings.length > 0) && (
              <section className="professional-inspection__panel">
                <div className="professional-inspection__section-heading"><h2>고객 안내 검토</h2><span>상세 · 짧은 SNS 안내</span></div>
                <p>고객에게 안내할 내용을 주문 정보와 함께 확인하고, 발송 전 문안을 각각 검토합니다.</p>
                <button type="button" className="professional-inspection__primary" onClick={() => setNoticeOpen(true)}
                  data-testid="button-open-inspection-notice">고객 안내 검토 화면 열기</button>
              </section>
            )}
            {!inspection.stagedApproval && !inspection.itemNotice && inspection.needsApproval && (
              <section className="professional-inspection__panel">
                <div className="professional-inspection__section-heading"><h2>고객 회신 확인</h2><span>직원 직접 기록</span></div>
                <ConsentDraftComposer order={order} onSave={onSave} />
                {inspection.response && <p>마지막 확인: {inspection.response.decisions?.join(', ') || inspection.response.choice} · {inspection.response.staffName} · {new Date(inspection.response.confirmedAt).toLocaleString('ko-KR')}<br />{inspection.response.content}</p>}
                {inspection.approvalRequirements ? <>
                  <fieldset className="professional-inspection__work">
                    <legend>고객 회신 항목 · 확인된 내용만 복수 선택</legend>
                    <div className="professional-inspection__work-options">
                      {CUSTOMER_DECISIONS.map((decision) => <label key={decision}><input type="checkbox"
                        checked={decisions.includes(decision)} onChange={() => setDecisions((current) =>
                          current.includes(decision) ? current.filter((entry) => entry !== decision) : [...current, decision])} />{decision}</label>)}
                    </div>
                  </fieldset>
                  <label className="professional-inspection__field">실제 고객 회신 일시
                    <input type="datetime-local" value={respondedAt} onChange={(event) => setRespondedAt(event.target.value)} />
                  </label>
                  <label className="professional-inspection__field">고객 회신 내용
                    <textarea value={responseContent} onChange={(event) => setResponseContent(event.target.value)}
                      data-testid="inspection-response-content" />
                  </label>
                  <label className="professional-inspection__field">확인 직원 · 필수
                    <input value={staffName} onChange={(event) => setStaffName(event.target.value)}
                      data-testid="inspection-staff-name" />
                  </label>
                  <div className="professional-inspection__actions">
                    <button type="button" onClick={recordDecisions} data-testid="button-confirm-response">고객 회신 기록</button>
                    <button type="button" className="professional-inspection__primary" onClick={approve}
                      disabled={order.status !== '고객 회신 대기' || !inspection.response || !staffName.trim() || missing.length > 0 || blockingDecision}
                      data-testid="button-approve-inspection-cleaning">세탁 진행 승인</button>
                  </div>
                  {missing.length > 0 && <div className="professional-inspection__approval-preview" role="status">
                    <strong>승인 전 필요한 확인</strong><ul>{missing.map((condition) => <li key={condition}>{condition}</li>)}</ul>
                  </div>}
                  {blockingDecision && <p className="professional-inspection__warning">거절 또는 보류 회신이 기록되어 세탁 진행을 승인할 수 없습니다.</p>}
                  <p>회신을 먼저 기록한 뒤, 모든 필요한 동의를 확인하고 별도로 세탁 진행을 승인해 주세요.</p>
                </> : <>
                <fieldset className="professional-inspection__work">
                  <legend>고객 회신 선택</legend>
                  <div className="professional-inspection__work-options">
                    {(['세탁 진행 동의', '세탁 진행 거절', '보류'] as const).map((choice) => (
                      <label key={choice}><input type="radio" name="customer-response" checked={responseChoice === choice}
                        onChange={() => setResponseChoice(choice)} />{choice}</label>
                    ))}
                  </div>
                </fieldset>
                <label className="professional-inspection__field">고객 회신 내용
                  <textarea value={responseContent} onChange={(event) => setResponseContent(event.target.value)}
                    data-testid="inspection-response-content" />
                </label>
                <label className="professional-inspection__field">확인 직원 · 필수
                  <input value={staffName} onChange={(event) => setStaffName(event.target.value)}
                    data-testid="inspection-staff-name" />
                </label>
                <button type="button" className="professional-inspection__primary" onClick={confirmResponse}
                  data-testid="button-confirm-response">고객 회신 기록</button>
                <p>확인 일시는 기록 버튼을 누른 시각으로 저장됩니다. 고객의 실제 의사를 확인한 후에만 기록해 주세요.</p>
                </>}
              </section>
            )}
            <section className="professional-inspection__panel">
              <details><summary>관리용 기록 보기</summary>
              <div className="professional-inspection__section-heading"><h2>주문 이력</h2></div>
              <ol className="professional-inspection__history" data-testid="inspection-history">
                {order.history?.map((event, index) => (
                  <li key={index}><time>{new Date(event.at).toLocaleString('ko-KR')}</time>
                    <strong>{({
                      'original-intake': '최초 접수', inspection: '전문 검수', 'inspection-finding': '검수 특이사항',
                      'price-change': '금액 변경',
                      'method-change': '세탁 방법 변경', 'additional-work': '추가 작업',
                      'risk-notice': '면책 및 위험 안내', 'generated-message': '고객 메시지 생성',
                      'staff-message-review': '직원 메시지 검토', 'customer-response': '고객 회신',
                      'approval-status': '진행 상태',
                      'inspection-start': '검수 시작', 'care-label-conflict': '세탁표시 불일치',
                      'customer-consent': '고객 동의 확인', 'send-preparation': '발송 준비',
                      'staged-message-draft': '단계별 안내 문안 생성', 'staged-message-prepared': '단계별 발송 준비',
                      'staged-customer-response': '단계별 고객 회신 확인', 'staged-care-label-request': '케어라벨 기준 세탁 요청',
                       'item-notice-draft': '품목별 안내 초안', 'item-notice-review': '품목별 안내 직원 확인',
                       'item-notice-prepared': '품목별 안내 발송 준비', 'item-notice-response': '품목별 고객 회신',
                    } as Record<string, string>)[event.kind]}</strong>
                    <details><summary>기록 보기</summary><pre>{JSON.stringify(event.details, null, 2)}</pre></details>
                  </li>
                ))}
              </ol></details>
            </section>
          </>
        )}
        {error && <p className="professional-inspection__error" role="alert">{error}</p>}
      </div>
    </main>
  );
}

function DraftItemNoticePanel({ order, draft, notice, onEdit }: {
  order: ConfirmedOrder; draft: InspectionDraft; notice: ItemNotice;
  onEdit: (text: string | null) => void;
}) {
  const generated = notice.steps[1]!.message;
  const [message, setMessage] = useState(generated);
  const [staffName, setStaffName] = useState('');
  const [reviewedMessage, setReviewedMessage] = useState('');
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const affected = notice.itemIndexes.map((index) => ({
    name: order.items[index].displayNameKo,
    item: draft.items[index],
    work: draft.items[index].additionalWork.filter((entry) => entry !== '추가 작업 없음'),
  }));
  function reviewDraft() {
    if (!staffName.trim()) { setError('확인 직원을 입력해 주세요.'); return; }
    if (draft.guidanceKind) {
      const fee = draft.additionalCharge ?? 0;
      if (!guidanceNamesIncluded(order, draft, notice.itemIndexes, message)
        || (draft.guidanceKind !== 'waiver' && (!message.includes(won(fee)) || !message.includes(won(order.estimatedTotal + fee))))) {
        setError('문안에 대상 품목과 기술료·최종 금액을 포함해 주세요.'); return;
      }
    } else if (affected.some(({ name, work }) => !message.includes(name) || work.some((entry) => !message.includes(entry)))) {
      setError('문안에 대상 품목과 추가 작업을 포함해 주세요.'); return;
    }
    setReviewedMessage(message);
    setError('');
    setFeedback('임시 문안을 확인했습니다. 검수 완료 후 최종 문안을 다시 확인해 주세요.');
  }
  return <section className="professional-inspection__panel" data-testid="inspection-draft-item-notice">
    <div className="professional-inspection__section-heading"><h2>고객 안내 및 동의</h2><span>검수 중 · 1단계 초안</span></div>
    <p>메시지 초안 · 실제 발송 아님. 검수 완료 전에는 고객 회신을 기록하거나 다음 단계를 열지 않습니다.</p>
    {affected.map(({ name, item, work }, index) => <div className="professional-inspection__notice-item" key={`${item.itemId}-${index}`}>
      <strong>대상 품목: {name}</strong>
       <p>안내 사유: {work.length ? `${work.join('·')}${item.additionalWorkDescription.trim()
         ? ` · ${item.additionalWorkDescription.trim()}` : ''}`
         : item.riskFactors?.join('·') || (careLabelConflict(item) ? '케어라벨과 다른 세탁방법'
           : item.method !== '기존 방법 유지' || actualCleaningMethodChanged(order, draft, item.index)
             ? '세탁방법 변경' : draft.revisedPrice !== order.estimatedTotal ? '예상금액 변경' : '위험 안내')}</p>
    </div>)}
    <p>현재 단계: 1단계 · 세탁 필요 확인{notice.outcome === 'informational' ? ' (위험 정보 안내만)' : ''}</p>
    <label className="professional-inspection__field">1단계 메시지 초안 · 수정 가능
      <textarea rows={6} value={message} onChange={(event) => {
        setMessage(event.target.value); onEdit(event.target.value);
        setReviewedMessage(''); setFeedback(''); setError('');
      }} data-testid="inspection-draft-item-message" />
    </label>
    <label className="professional-inspection__field">확인 직원
      <input value={staffName} onChange={(event) => {
        setStaffName(event.target.value); setReviewedMessage(''); setFeedback('');
      }} data-testid="inspection-draft-item-staff" />
    </label>
    <div className="professional-inspection__actions">
      <button type="button" onClick={() => {
        setMessage(generated); onEdit(null);
        setReviewedMessage(''); setFeedback('초안을 다시 생성했습니다.'); setError('');
      }}>초안 다시 생성</button>
      <button type="button" onClick={reviewDraft}>직원 확인 완료</button>
      <button type="button" className="professional-inspection__primary" onClick={() => {
        if (!reviewedMessage || reviewedMessage !== message) {
          setError('현재 문안을 직원이 먼저 확인해 주세요.'); return;
        }
        setError('');
        setFeedback('임시 발송 준비 표시만 했습니다. 실제 발송되지 않았으며 검수 완료 후 최종 문안의 준비를 기록해야 합니다.');
      }}>고객에게 발송 준비</button>
    </div>
    {notice.outcome !== 'informational' && <>
      <div className="professional-inspection__actions">
        <button type="button" disabled title="전문 검수 완료 후 고객 응답을 기록할 수 있습니다.">동의</button>
        <button type="button" disabled title="전문 검수 완료 후 고객 응답을 기록할 수 있습니다.">동의하지 않음</button>
        <button type="button" disabled title="전문 검수 완료 후 고객 응답을 기록할 수 있습니다.">고객 문의</button>
        <button type="button" disabled title="전문 검수 완료 후 고객 응답을 기록할 수 있습니다.">직접 입력</button>
      </div>
      <button type="button" disabled title="전문 검수 완료 후 고객 응답을 기록할 수 있습니다.">고객 응답 기록</button>
      <p>고객 응답은 전문 검수를 저장한 뒤 직원이 직접 확인해 기록합니다. 저장만으로 변경된 작업이 승인되지는 않습니다.</p>
    </>}
    {feedback && <p role="status">{feedback}</p>}
    {error && <p className="professional-inspection__error" role="alert">{error}</p>}
  </section>;
}

function InspectionNoticeReview({ order, onSave, onBack }: Props) {
  const inspection = order.inspection!;
  const [tab, setTab] = useState<'detail' | 'short'>('detail');
  const [detail, setDetail] = useState(inspection.customerMessage);
  const [short, setShort] = useState(inspection.shortCustomerMessage ?? generateShortInspectionMessage(order, inspection));
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const text = tab === 'detail' ? detail : short;
  const setText = tab === 'detail' ? setDetail : setShort;

  function changeMessage(action: 'edit' | 'regenerate' | 'ready', channel: 'kakao' | 'sms' = 'kakao') {
    try {
      const next = action === 'regenerate'
        ? tab === 'detail' ? generateInspectionMessage(order, inspection) : generateShortInspectionMessage(order, inspection)
        : text;
      const updated = updateInspectionMessage(order, next, action, new Date(), tab, channel);
      onSave(updated);
      setText(next);
      setError('');
      setFeedback(action === 'ready' ? `${channel === 'kakao' ? '카카오톡' : '문자'} 발송 준비만 기록했습니다. 실제 전송은 되지 않았습니다.`
        : action === 'regenerate' ? '현재 검수 내용으로 문안을 다시 생성하고 기록했습니다.' : '문안을 저장했습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '안내 문안을 기록하지 못했습니다.'); }
  }

  async function copyMessage() {
    try { await navigator.clipboard.writeText(text); setFeedback('문안을 복사했습니다. 실제 전송은 되지 않았습니다.'); }
    catch { setFeedback('복사할 수 없습니다. 문안을 직접 선택해 복사해 주세요.'); }
  }

  return <main className="professional-inspection" data-testid="screen-inspection-notice-review">
    <div className="professional-inspection__wrap">
      <header className="professional-inspection__header">
        <div className="professional-inspection__eyebrow">K99 품격세탁소 · 과천점</div>
        <h1>고객 안내 검토</h1>
        <p>검수 사실과 고객에게 보낼 문안을 대조합니다. 카카오톡과 문자 발송 준비는 실제 발송이 아닙니다.</p>
        <button type="button" className="professional-inspection__back" onClick={onBack}>검수 결과로 돌아가기</button>
      </header>
      <section className="professional-inspection__panel">
        <div className="professional-inspection__section-heading"><h2>안내 대상</h2><span>접수 원본</span></div>
        <div className="professional-inspection__facts">
          <div><span>고객</span><strong>{order.customerName}</strong></div>
          <div><span>전화번호</span><strong>{order.customerPhone}</strong></div>
        </div>
      </section>
      <section className="professional-inspection__panel">
        <div className="professional-inspection__section-heading"><h2>안내 내용 대조</h2><span>검수 기록 기준</span></div>
        {inspection.items.map((item, index) => {
          const findings = inspectionFindings(order, inspection).filter((finding) => finding.index === index);
          const original = originalCleaningMethod(order, inspection, index);
          return <div className="professional-inspection__notice-item" key={`${item.itemId}-${index}`}>
            <strong>{String(index + 1).padStart(2, '0')} · {order.items[index].displayNameKo} × {order.items[index].quantity}</strong>
            <dl>
              <div><dt>검수 특이사항</dt><dd>{findings.map((finding) => `${finding.category} ${finding.result}`).join(' · ') || '없음'}{item.memo && ` · ${item.memo}`}</dd></div>
              <div><dt>세탁방법</dt><dd>{order.items[index].isSneaker
                ? `${inspection.originalMethods[index]} → ${item.method === '기존 방법 유지' ? '기존 방법 유지' : item.method === '기타' ? item.customMethod : item.method}`
                : `${original ?? '접수 당시 방법 확인되지 않음'} → ${item.actualCleaningMethod ?? '미기록'}`}
                {item.methodChangeReason && ` · 변경 사유: ${item.methodChangeReason}`}</dd></div>
              <div><dt>세탁표시</dt><dd>{item.careLabelMethod === '기타' ? item.careLabelOther : item.careLabelMethod || '미기록'}
                {careLabelConflict(item) && ' · 세탁표시와 세탁방법 불일치'}</dd></div>
              <div><dt>추가 작업</dt><dd>{item.additionalWork.join(', ')}{item.additionalWorkDescription && ` · ${item.additionalWorkDescription}`}</dd></div>
              <div><dt>위험 안내</dt><dd>{item.riskFactors?.join(', ') || '선택 없음'}{item.riskDetails && ` · ${item.riskDetails}`}</dd></div>
            </dl>
          </div>;
        })}
        {inspection.riskRequired && <p>공통 위험 안내: {inspection.riskNotice}</p>}
        {inspection.waiverRequired && <p>면책 동의 범위: {inspection.waiverNotice}</p>}
        <div className="professional-inspection__price">
          <div><span>최초 예상금액</span><strong>{won(inspection.originalPrice)}</strong></div>
          <div><span>추가요금</span><strong>{won(inspection.additionalCharge ?? 0)}</strong></div>
          <div><span>검수 후 예상금액</span><strong>{won(inspection.revisedPrice)}</strong></div>
        </div>
      </section>
      <section className="professional-inspection__panel professional-inspection__decision">
        <div className="professional-inspection__section-heading"><h2>발송 전 문안</h2><span>직원 직접 검토</span></div>
        <div className="professional-inspection__tabs" role="tablist" aria-label="안내 문안 종류">
          <button type="button" role="tab" aria-selected={tab === 'detail'} onClick={() => setTab('detail')}>상세 안내</button>
          <button type="button" role="tab" aria-selected={tab === 'short'} onClick={() => setTab('short')}>짧은 SNS 안내</button>
        </div>
        <label className="professional-inspection__field">{tab === 'detail' ? '상세 안내 문안' : '짧은 SNS 문안'} · 수정 가능
          <textarea rows={14} value={text} onChange={(event) => setText(event.target.value)}
            data-testid="inspection-customer-message" />
        </label>
        <div className="professional-inspection__actions">
          <button type="button" onClick={() => changeMessage('regenerate')}>문안 다시 생성</button>
          <button type="button" onClick={() => changeMessage('edit')}>문안 저장</button>
          <button type="button" onClick={copyMessage}>문안 복사</button>
          <button type="button" className="professional-inspection__primary" onClick={() => changeMessage('ready', 'kakao')}>카카오톡 발송 준비</button>
          <button type="button" onClick={() => changeMessage('ready', 'sms')}>문자 발송 준비</button>
        </div>
        {(tab === 'detail' ? inspection.messageReadyAt : inspection.shortMessageReadyAt) &&
          <p>발송 준비 기록: {new Date((tab === 'detail' ? inspection.messageReadyAt : inspection.shortMessageReadyAt)!).toLocaleString('ko-KR')} · 실제 발송 아님</p>}
        {feedback && <p role="status">{feedback}</p>}
        {error && <p className="professional-inspection__error" role="alert">{error}</p>}
        <p>발송 준비는 문안 검토 이력입니다. 외부 서비스로 실제 전송되지 않으며 고객 회신도 자동 해석되지 않습니다.</p>
      </section>
    </div>
  </main>;
}
function guidanceNamesIncluded(order: ConfirmedOrder, draft: InspectionDraft, indexes: number[], text: string) {
  const custom = draft.feeItemName?.trim();
  if (custom) return text.includes(custom);
  const list = indexes.length ? indexes : order.items.map((_, index) => index);
  return list.every((index) => !order.items[index] || text.includes(order.items[index].displayNameKo));
}
