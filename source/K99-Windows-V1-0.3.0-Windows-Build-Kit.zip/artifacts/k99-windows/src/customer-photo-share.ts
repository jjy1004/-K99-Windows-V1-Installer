import type { ConfirmedOrder } from './order-record.ts';
import { activePhotosOf } from './manual-photo-link.ts';

export type CustomerPhotoShareChannel = 'sms' | 'sns' | 'kakao';
export type CustomerPhotoSharePlan = Readonly<{
  status: 'prepared-not-sent';
  channel: CustomerPhotoShareChannel;
  orderId: string;
  garmentId: string;
  recipientPhoneMasked: string;
  attachments: readonly Readonly<{
    role: 'intake' | 'completion';
    sourcePhotoId: string;
    timestamp: string;
  }>[];
  requiresStaffApproval: true;
  /** No transport is implemented. Callers must not interpret this as a sent message. */
  deliveryAvailable: false;
}>;

/**
 * Prepare references only. Does not read image bytes, contact a provider,
 * generate public URLs, enqueue a message, or persist contact details.
 */
export function prepareCustomerPhotoShare(
  order: ConfirmedOrder,
  garmentId: string,
  channel: CustomerPhotoShareChannel,
): CustomerPhotoSharePlan {
  if (!['sms', 'sns', 'kakao'].includes(channel)) throw new Error('고객 사진 공유 채널을 확인해 주세요.');
  const garment = order.garments?.find((item) => item.garmentId === garmentId && item.orderId === order.id);
  if (!garment) throw new Error('저장 주문에 연결된 의류 ID를 찾지 못했습니다.');
  const digits = order.customerPhone?.replace(/\D/g, '') ?? '';
  if (digits.length < 4) throw new Error('고객 전화번호를 확인해 주세요.');
  const photos = activePhotosOf(garment).filter((photo) =>
    photo.status === 'saved' && photo.origin === 'bridge' && photo.sourcePhotoId);
  const before = photos.find((photo) => photo.role === 'intake' &&
    photo.requestId === garment.representativeBeforePhotoId)
    ?? photos.find((photo) => photo.role === 'intake');
  const after = photos.filter((photo) => photo.role === 'completion').at(-1);
  if (!before || !after) throw new Error('실제 파일이 확인된 세탁 전·후 사진이 모두 있어야 공유 준비를 할 수 있습니다.');
  return {
    status: 'prepared-not-sent',
    channel,
    orderId: order.id,
    garmentId,
    recipientPhoneMasked: `***-****-${digits.slice(-4)}`,
    attachments: [before, after].map((photo) => ({
      role: photo.role, sourcePhotoId: photo.sourcePhotoId!, timestamp: photo.timestamp,
    })),
    requiresStaffApproval: true,
    deliveryAvailable: false,
  };
}