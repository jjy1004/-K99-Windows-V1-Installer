type PollTimers<Handle> = {
  setTimeout: (callback: () => void, delayMs: number) => Handle;
  clearTimeout: (handle: Handle) => void;
};

/** Runs one poll at a time and coalesces any triggers received while it is busy. */
export function createSerializedPoller<Handle = ReturnType<typeof setTimeout>>(
  task: () => Promise<unknown> | unknown,
  intervalMs: number,
  timers?: PollTimers<Handle>,
): { start: () => void; trigger: () => void; stop: () => void } {
  const setTimer = timers?.setTimeout ??
    ((callback: () => void, delayMs: number) => globalThis.setTimeout(callback, delayMs) as Handle);
  const clearTimer = timers?.clearTimeout ??
    ((handle: Handle) => globalThis.clearTimeout(handle as ReturnType<typeof setTimeout>));
  let running = false;
  let busy = false;
  let queued = false;
  let timer: Handle | undefined;

  const schedule = (delayMs: number) => {
    if (!running) return;
    if (timer !== undefined) clearTimer(timer);
    timer = setTimer(() => {
      timer = undefined;
      void run();
    }, delayMs);
  };

  const run = async () => {
    if (!running) return;
    if (busy) {
      queued = true;
      return;
    }
    busy = true;
    try {
      await task();
    } finally {
      busy = false;
      if (running) {
        const delay = queued ? 0 : intervalMs;
        queued = false;
        schedule(delay);
      }
    }
  };

  return {
    start() {
      if (running) return;
      running = true;
      schedule(0);
    },
    trigger() {
      if (!running) return;
      if (busy) {
        queued = true;
        return;
      }
      schedule(0);
    },
    stop() {
      running = false;
      queued = false;
      if (timer !== undefined) {
        clearTimer(timer);
        timer = undefined;
      }
    },
  };
}