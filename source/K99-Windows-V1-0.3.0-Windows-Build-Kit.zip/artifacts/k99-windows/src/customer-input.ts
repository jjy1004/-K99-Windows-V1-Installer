/** Display formatting only; saved-order identity and barcode generation are unchanged. */
export function formatCustomerPhone(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 7) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  const middleEnd = digits.length === 11 ? 7 : 6;
  return `${digits.slice(0, 3)}-${digits.slice(3, middleEnd)}-${digits.slice(middleEnd)}`;
}

export function requiredIntakeIdentity(name: string, phone: string): boolean {
  const digits = phone.replace(/\D/g, '');
  // Walk-in friendly: any phone with at least the last 4 digits is accepted.
  return Boolean(name.trim()) && digits.length >= 4 && digits.length <= 11;
}
