/** Display formatting only; saved-order identity and barcode generation are unchanged. */
export function formatCustomerPhone(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 7) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  const middleEnd = digits.length === 11 ? 7 : 6;
  return `${digits.slice(0, 3)}-${digits.slice(3, middleEnd)}-${digits.slice(middleEnd)}`;
}

export function requiredIntakeIdentity(name: string, phone: string): boolean {
  return Boolean(name.trim()) && /^01\d{8,9}$/.test(phone.replace(/\D/g, ''));
}
