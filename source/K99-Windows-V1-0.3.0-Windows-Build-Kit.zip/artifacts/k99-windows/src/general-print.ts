import './desktop-runtime';
let printing=false;
/** Scope print-only visibility to this card; never enable global label print. */
export async function printCareCard(){
  if(printing)throw Error('인쇄 응답을 기다리는 중입니다.');
  const cards=document.querySelectorAll<HTMLElement>('.crc');
  if(cards.length!==1)throw Error('인쇄할 고객 안내 화면을 하나만 열어 주세요.');
  const ancestors:HTMLElement[]=[];
  for(let parent=cards[0].parentElement;parent&&parent!==document.body;parent=parent.parentElement){
    if(!parent.classList.contains('k99-print-ancestor'))ancestors.push(parent);
  }
  printing=true;
  ancestors.forEach(el=>el.classList.add('k99-print-ancestor'));
  document.body.classList.add('k99-care-print');
  try{
    if(window.k99Desktop?.hardwareSettings)await window.k99Desktop.hardwareSettings({action:'general-print'});
    else window.print();
  }finally{
    printing=false;document.body.classList.remove('k99-care-print');
    ancestors.forEach(el=>el.classList.remove('k99-print-ancestor'));
  }
}
