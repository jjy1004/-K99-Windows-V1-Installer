import { type ReactNode, type RefObject } from 'react';
import type { ConfirmedOrder } from './order-record';
import { tagAction } from './tag-action-policy';
import { photoEligibility, tagIssuance } from './workflow-gates';
import type { GarmentRecord } from './garment-record';
import type { TagPrinterSettings } from './tag-printer';
import './garment-capture.css';
import { batchGarmentState, batchTagComplete, batchTagSubmission } from './capture-batch-policy';
import { StoreName } from './StoreName';

type PhotoBridgeTagMode = 'DEV' | 'TEST' | 'STORE';

export type GarmentCaptureViewProps = {
  order: ConfirmedOrder;
  garments: GarmentRecord[];
  currentIndex: number;
  mode: 'simulation' | 'bridge' | 'passive';
  passiveStatus: string;
  passiveReady: boolean;
  passivePendingGarmentId?: string;
  passivePollEnabled: boolean;
  verifiedPassivePhoto?: { photoPath: string; photoTimestamp: string; garmentId: string };
  hardware: { camera: string; footSwitch: string; printer: string };
  busy: boolean;
  error: string;
  notice?: string;
  photoBridgeTagMode?: PhotoBridgeTagMode | null;
  photoBridgeTagTemplateSource?: 'sample' | 'live' | 'unavailable';
  photoBridgeTagTemplateNotice?: string;
  photoBridgeTagJobNotice?: string;
  tagStatusChecking?: boolean;
  footSwitchCode: string;
  bridgeUrl: string;
  settings: TagPrinterSettings;
  photoPreviewUrl?: string;
  tagPreview: ReactNode;
  cameraVideoRef: RefObject<HTMLVideoElement | null>;
  onCapture: () => void;
  onConfirmPassivePhotoIdentity: (confirmed: boolean) => void;
  onRetry: () => void;
  onReprint: () => void;
  onTestPrint: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSelect: (index: number) => void;
  onConfirmBatchTags: () => void;
  onBack: () => void;
  onToggleTagPreview: () => void;
  onFootSwitchCode: (value: string) => void;
  onBridgeUrl: (value: string) => void;
  onSettings: (value: TagPrinterSettings) => void;
};

const deviceState = (value: string): 'connected' | 'offline' | 'unknown' => {
  const status = value.trim();
  if (/^(connected|online|ready|연결됨|정상|사용 가능)(?:\s|$)/i.test(status)) return 'connected';
  if (/^(disconnected|offline|not connected|unavailable|연결 끊김|연결 안 됨|미연결|오프라인)(?:\s|$)/i.test(status)) return 'offline';
  return 'unknown';
};

function DeviceStatus({ label, value, testId }: { label: string; value: string; testId: string }) {
  const state = deviceState(value);
  return (
    <div className="garment-capture__device" data-testid={testId}>
      <span className="garment-capture__device-dot" data-state={state} aria-hidden="true" />
      <span>{label}</span>
      <strong>{state === 'connected' ? '연결됨' : state === 'offline' ? '오프라인' : '상태 미확인'}</strong>
       <small hidden>{value || '상태 확인 안 됨'}</small>
    </div>
  );
}

export default function GarmentCaptureView({
  order, garments, currentIndex, mode, hardware, passiveStatus, passiveReady, passivePendingGarmentId, passivePollEnabled,
  verifiedPassivePhoto, busy, error, notice, photoBridgeTagMode, photoBridgeTagTemplateSource,
  photoBridgeTagTemplateNotice, photoBridgeTagJobNotice, tagStatusChecking, footSwitchCode, bridgeUrl, settings,
  photoPreviewUrl, tagPreview, cameraVideoRef, onCapture, onRetry, onReprint, onTestPrint,
  onPrev, onNext, onSelect, onConfirmBatchTags, onBack, onToggleTagPreview, onFootSwitchCode, onBridgeUrl, onSettings,
}: GarmentCaptureViewProps) {
  const garment = garments[currentIndex];
  const archiveEvidence = garment?.photoHistory?.find((entry) => entry.requestId === garment.captureRequestId)
    ?? (garment?.beforePhoto?.requestId === garment?.captureRequestId ? garment?.beforePhoto : undefined);
  const total = garments.length;
  const photoComplete = garments.filter(item => item.photoStatus === 'saved').length;
  const tagCompleteForMode = (item: GarmentRecord) => batchTagComplete(item, photoBridgeTagMode);
  const tagComplete = garments.filter(tagCompleteForMode).length;
  const remaining = garments.filter(item => batchGarmentState(item, photoBridgeTagMode) !== 'done').length;
  const allComplete = total > 0 && remaining === 0;
  const staffTagChecks = photoBridgeTagMode === 'STORE'
    ? garments.filter(item => batchTagSubmission(item) && !tagCompleteForMode(item)).length : 0;
  const isSimulation = mode === 'simulation';
  const isPassive = mode === 'passive';
  const hasPassiveRequest = Boolean(passivePendingGarmentId);
  const passiveGarmentMatches = !hasPassiveRequest || passivePendingGarmentId === garment?.garmentId;
  const isPhotoBridgeTagFlow = Boolean(photoBridgeTagMode);
  const hasPhotoIntakeProof = Boolean(garment?.captureRequestId &&
    (garment.photoStatus === 'saved' || garment.photoStatus === 'simulated'));
  const isTagStatusAction = tagIssuance(order, garment, true).kind === 'status';
  const canPhotoBridgeReprint = Boolean(isPhotoBridgeTagFlow && !busy && !tagStatusChecking && garment &&
    (isTagStatusAction || photoBridgeTagTemplateSource === 'live'));
  const currentTagStatus = garment?.photoBridgeReprintRequestId
    ? garment.photoBridgeReprintStatus : garment?.photoBridgeAutoTagStatus;
  const currentTagReason = garment?.photoBridgeReprintRequestId
    ? garment.photoBridgeReprintReason : garment?.photoBridgeAutoTagReason;
  const currentTagMode = garment?.photoBridgeReprintRequestId
    ? garment.photoBridgeReprintMode : garment?.photoBridgeAutoTagMode;
  const tagJobLabel = currentTagStatus
    ? currentTagStatus === 'failed' || currentTagStatus === 'unknown' ? '출력 확인 필요'
      : currentTagStatus === 'submitted' ? '출력 요청 전달됨 · 실물 확인'
        : currentTagStatus === 'pending' ? '출력 요청 중'
          : currentTagStatus === 'printed' && currentTagMode === 'STORE' && currentTagReason?.includes('1장 완료 응답 확인')
            ? '출력 완료 확인됨' : '기존 출력 기록 · 실물 확인'
    : null;
  const update = <K extends keyof TagPrinterSettings>(key: K, value: TagPrinterSettings[K]) =>
    onSettings({ ...settings, [key]: value });
  const numberField = (key: keyof Pick<TagPrinterSettings, 'labelWidthMm' | 'labelHeightMm' | 'gapMm' | 'speed' | 'density' | 'barcodeWidthMm' | 'barcodeHeightMm' | 'labelMarginMm' | 'qrSizeMm' | 'fontSizePt'>, label: string, unit = '') => (
    <label className="garment-capture__field" key={key}>
      <span>{label}{unit && <small> {unit}</small>}</span>
      <input type="number" min="0" step="any" value={settings[key] ?? ''} placeholder="미확인" onChange={(event) => update(key, event.target.value === '' ? undefined : Number(event.target.value))} data-testid={`input-${key}`} />
    </label>
  );

  return (
    <main className="garment-capture">
      <div className="garment-capture__wrap">
        <header className="garment-capture__topline">
          <div className="garment-capture__brand"><StoreName /> <small>직원 접수</small></div>
          <span className="garment-capture__serial" data-testid="text-capture-order-id" hidden>{order.id}</span>
        </header>

        <div className="garment-capture__intro">
          <div>
            
            <h1>의류 촬영 및 태그 확인</h1>
            <p>접수된 의류를 순서대로 촬영하고 태그 상태를 확인합니다. 고객 정보와 태그 내용은 저장된 주문에서 가져옵니다.</p>
          </div>
          <div className="garment-capture__customer" data-testid="section-capture-customer">
            <span>현재 접수 고객</span>
            <strong data-testid="text-capture-customer-name">{order.customerName}</strong>
            <small data-testid="text-capture-customer-phone">{order.customerPhone}</small>
          </div>
        </div>

        <div className="garment-capture__metrics" aria-label="작업 현황">
          <div><span>전체 의류</span><strong data-testid="count-garments-total">{total}</strong><small>벌</small></div>
          <div><span>사진 완료</span><strong data-testid="count-photos-complete">{photoComplete}</strong><small>벌</small></div>
          <div><span>태그 완료</span><strong data-testid="count-tags-complete">{tagComplete}</strong><small>벌</small></div>
          <div className="garment-capture__metrics-accent"><span>남은 작업</span><strong data-testid="count-garments-remaining">{remaining}</strong><small>벌</small></div>
        </div>

        <section className="garment-capture__panel" aria-label="전체 의류 촬영·태그 순서">
          <h2>의류별 촬영·태그 진행</h2>
          <ol className="garment-capture__batch-list" data-testid="capture-batch-list">
            {garments.map((item, index) => {
              const state = batchGarmentState(item, photoBridgeTagMode);
              return <li key={item.garmentId}>
                <button type="button" onClick={() => onSelect(index)} disabled={busy || hasPassiveRequest}
                  aria-current={index === currentIndex ? 'step' : undefined}
                  data-testid={`capture-batch-garment-${index + 1}`}>
                  <strong>{index + 1}. {item.itemName}</strong>
                  <span>{item.photoStatus === 'saved' ? '사진 완료' : item.photoStatus === 'failed' ? '사진 확인 필요' : '사진 대기'}</span>
                  {item.photoHistory?.some((entry) => entry.requestId === item.captureRequestId && entry.archiveError) &&
                    <span>D드라이브 사본 확인 필요</span>}
                  <span>{tagCompleteForMode(item) ? '태그 완료' : '태그 대기 / 실물 확인'}</span>
                  <b>{state === 'done' ? '✓ 완료' : state === 'attention' ? '확인 필요' : index === currentIndex ? '현재 의류' : '대기'}</b>
                  {state === 'attention' && <small>{item.lastError || item.photoBridgeReprintReason || item.photoBridgeAutoTagReason || '사진·태그를 확인하세요.'}</small>}
                </button>
              </li>;
            })}
          </ol>
          {staffTagChecks > 0 && <div>
            <p>프린터에 요청이 전달된 태그는 실물을 확인해야 완료됩니다. 자동 재인쇄하지 않습니다.</p>
            <button type="button" onClick={onConfirmBatchTags} disabled={busy || hasPassiveRequest}
              data-testid="button-confirm-batch-tags">출력된 태그 {staffTagChecks}벌 실물 확인</button>
          </div>}
          {allComplete ? <div role="status" data-testid="capture-batch-complete">
            <strong>전체 촬영·태그 완료</strong>
            <button type="button" onClick={onBack} disabled={busy || hasPassiveRequest} data-testid="button-capture-batch-finish">촬영 완료</button>
          </div> : photoComplete === total && total > 0
            ? <p role="status">전체 사진 완료 · 태그 출력 결과 확인 중. 확인 필요 의류는 개별 처리하세요.</p> : null}
        </section>

        <div className="garment-capture__layout">
          <section className="garment-capture__main" aria-label="현재 의류 촬영">
            <div className="garment-capture__section-top">
              <div>
                
                <h2 data-testid="text-current-garment">{garment ? garment.itemName : '처리할 의류가 없습니다'}</h2>
                {garment && <p data-testid="text-current-garment-id">{garment.sequence} / {total}번째 세탁물 · 번호 {garment.garmentId} · 저장 사진 {new Set((garment.photoHistory ?? []).filter(p => p.status === 'saved' && !(garment.unlinkedPhotoIds ?? []).includes(p.requestId)).map(p => p.requestId)).size}장</p>}
              </div>
              {garment && <span className="garment-capture__sequence">{String(garment.sequence).padStart(2, '0')} <i>/</i> {String(total).padStart(2, '0')}</span>}
            </div>

            <div className="garment-capture__viewport" data-testid="section-camera-preview">
              <video ref={cameraVideoRef} autoPlay muted playsInline aria-label="의류 촬영 카메라" className={photoPreviewUrl ? 'garment-capture__video garment-capture__video--covered' : 'garment-capture__video'} data-testid="video-garment-camera" />
              {photoPreviewUrl && <img src={photoPreviewUrl} alt={`${garment?.itemName ?? '의류'} 촬영 사진`} className="garment-capture__photo" data-testid="image-garment-photo" />}
              {!photoPreviewUrl && <div className="garment-capture__viewport-guide" aria-hidden="true"><span /><span /><span /><span /></div>}
              <div className="garment-capture__viewport-caption">
                <span className="garment-capture__live-dot" />
                {photoPreviewUrl ? '사진 확인' : isPassive ? '사진 연결 대기' : '카메라 화면'}
              </div>
              {isPassive && !photoPreviewUrl && <div className="garment-capture__empty" data-testid="status-passive-photo">
                <strong>사진 연결 대기</strong>
                <p>아래 ‘사진 촬영 대기’를 누른 뒤 평소처럼 촬영하세요. 새 사진을 선택한 의류에 자동으로 연결합니다.</p>
                {hasPassiveRequest && <p data-testid="text-passive-pending-garment">촬영 대기 중인 의류가 있습니다. 확인을 마칠 때까지 다른 의류 전환을 차단합니다.</p>}
              </div>}
              {!garment && <div className="garment-capture__empty">접수된 의류 기록이 없습니다. 주문 내용을 확인해 주세요.</div>}
            </div>

            <div className="garment-capture__capture-row">
              <p role="status">{!garment ? '의류 선택 필요' : verifiedPassivePhoto ? '사진 감지됨 · 의류 연결 중' :
                hasPassiveRequest ? '풋스위치 촬영 대기 · 사진 저장 확인 중' :
                garment.photoStatus === 'failed' ? '사진 확인 실패 · 다시 촬영 필요' :
                garment.photoStatus === 'saved' ? `의류 연결 완료 · ${tagAction(garment)}` : '촬영 시작 필요'}</p>
              <button type="button" className="garment-capture__primary" onClick={onCapture} disabled={isSimulation || busy || !garment ||
                (isPassive ? hasPassiveRequest
                  ? !passiveGarmentMatches || passivePollEnabled || Boolean(verifiedPassivePhoto)
                  : !passiveReady
                  : false)}
                data-testid="button-capture-garment">{busy ? '처리 중…' : isPassive
                  ? hasPassiveRequest ? verifiedPassivePhoto ? '사진 연결 중…' : passivePollEnabled ? '사진 저장 확인 중…' : '사진 연결 다시 확인'
                    : garment?.photoStatus === 'saved' ? '같은 세탁물 추가 촬영 대기' : '첫 사진 촬영·태그 시작'
                  : isSimulation ? '매장 사진 연결 필요' : '사진 촬영'}</button>
              <span>{isPassive ? '추가 사진은 같은 세탁물에 연결되며 자동 태그를 추가 발행하지 않습니다. 다른 세탁물은 다음 세탁물 버튼으로 전환하세요.' : isSimulation ? '매장 PC의 사진 연결을 확인해 주세요.' : '평소 사용하는 풋스위치로도 촬영할 수 있습니다.'}</span>
            </div>
            {isPassive && verifiedPassivePhoto && <section className="garment-capture__panel" data-testid="section-passive-photo-identity">
              <h3>사진 연결 중</h3>
              <p>선택한 의류의 사진 저장을 확인하고 있습니다.</p>
              <dl>
                <dt>촬영 시각</dt><dd>{verifiedPassivePhoto.photoTimestamp}</dd><dd hidden><code data-testid="text-passive-photo-path">{verifiedPassivePhoto.photoPath}</code></dd>
              </dl>
            </section>}
            {isPassive && hasPassiveRequest && !passiveGarmentMatches && <p role="alert">
              촬영 대기한 의류와 현재 의류가 다릅니다. 사진을 잘못 연결하지 않도록 중지했습니다. 원래 의류로 돌아가세요.
            </p>}
            <div className="garment-capture__action-row">
               <button type="button" onClick={onRetry} disabled={busy || hasPassiveRequest || !garment ||
                 (isPassive ? !passiveReady || !['saved','failed'].includes(garment.photoStatus) :
                   garment.photoStatus !== 'failed' && garment.photoStatus !== 'saved' && garment.photoStatus !== 'simulated')}
                 data-testid="button-recapture-garment">{isPassive && garment?.photoStatus === 'saved' ? '추가 사진 요청' : '사진 다시 촬영'}</button>
              <button type="button" onClick={onPrev} disabled={busy || hasPassiveRequest || currentIndex <= 0} data-testid="button-previous-garment">이전 의류</button>
              <button type="button" onClick={onNext} disabled={busy || hasPassiveRequest || currentIndex >= total - 1} data-testid="button-next-garment">다음 세탁물</button>
            </div>
          </section>

          <aside className="garment-capture__side">
            <section className="garment-capture__panel">
              <div className="garment-capture__panel-heading"><h2>사진과 태그</h2></div>
              <div className="garment-capture__state"><span>사진 기록</span><strong data-testid="status-garment-photo">{garment?.photoStatus === 'saved' ? isPassive ? '사진 완료' : '저장됨' : garment?.photoStatus === 'simulated' ? '미촬영 (연습 기록)' : !garment || garment.photoStatus === 'not-captured' ? '미촬영' : `확인 필요 · ${garment.photoStatus}`}</strong></div>
              {archiveEvidence?.archivePath && <p data-testid="text-customer-photo-archive" style={{ overflowWrap: 'anywhere' }}>
                고객별 사본 저장 완료 · 상세 경로는 관리자 진단에서 확인하세요.
              </p>}
              {archiveEvidence?.archiveError && <p role="alert" data-testid="error-customer-photo-archive">
                {archiveEvidence.archiveError}
              </p>}
               <div className="garment-capture__state"><span>태그</span><strong data-testid="status-garment-tag">{tagJobLabel ?? (!garment || ['not-generated', 'simulated'].includes(garment.tagStatus) ? '출력 전' : '실물 태그 확인 필요')}</strong></div>
              {garment && <details data-testid="tag-issuance-diagnostics" style={{ overflowWrap: 'anywhere' }}>
                <summary>태그번호·발행 기록 확인 (읽기 전용)</summary>
                <p>의류 ID: <code>{garment.garmentId}</code></p>
                <p>저장 바코드: <code data-testid="text-garment-barcode">{garment.barcodeValue}</code></p>
                <p>자동 요청: {garment.photoBridgeAutoTagRequestId || '없음'}<br />
                  작업 번호: {garment.photoBridgeAutoTagJobId || '없음'}<br />
                  모드 / 상태: {garment.photoBridgeAutoTagMode || '없음'} / {garment.photoBridgeAutoTagStatus || '없음'}</p>
                <p>재출력 요청: {garment.photoBridgeReprintRequestId || '없음'}<br />
                  작업 번호: {garment.photoBridgeReprintJobId || '없음'}<br />
                  모드 / 상태: {garment.photoBridgeReprintMode || '없음'} / {garment.photoBridgeReprintStatus || '없음'}</p>
                <p>출력 요청 전달은 실제 인쇄 완료의 증거가 아닙니다. 번호를 수정하거나 태그를 다시 발행하지 않고 실물 코드와 비교하세요.</p>
              </details>}
              <button className="garment-capture__text-button" type="button" onClick={onToggleTagPreview} disabled={!garment} data-testid="button-toggle-tag-preview">태그 미리보기 열기 / 닫기</button>
              {tagPreview && <div className="garment-capture__tag-preview" data-testid="section-tag-preview">{tagPreview}</div>}
              <div className="garment-capture__action-row garment-capture__action-row--side">
                  <button type="button" onClick={onReprint}
                    disabled={isPhotoBridgeTagFlow ? !canPhotoBridgeReprint : isPassive || busy || !garment ||
                      (garment.tagStatus !== 'failed' && garment.tagStatus !== 'print-requested' && garment.tagStatus !== 'printed' && garment.tagStatus !== 'simulated')}
                    aria-busy={!!tagStatusChecking}
                    data-testid="button-reprint-tag">{tagStatusChecking ? '출력 상태 조회 중…' : isPhotoBridgeTagFlow ? (garment ? tagIssuance(order, garment, true).label : tagAction(garment)) :
                      garment?.tagStatus === 'failed' || garment?.tagStatus === 'print-requested' ? '태그 출력 재시도' : '태그 재출력'}</button>
                  {garment && !photoEligibility(order, garment.garmentId).ok && <p role="status" data-testid="text-tag-gate-reason">
                    {(photoEligibility(order, garment.garmentId) as { reason: string }).reason}</p>}
                  {isPhotoBridgeTagFlow && !canPhotoBridgeReprint && <p role="status">
                    {busy ? '촬영·출력 요청 처리 중입니다. 중복 요청하지 마세요.'
                      : !hasPhotoIntakeProof ? '이 의류의 저장 사진을 먼저 확인하세요. 사진이 없으면 풋스위치 촬영부터 진행하세요.'
                      : '연결과 출력 양식 확인이 필요합니다. 기존 K99 연결을 다시 확인하세요. 기존 의류 ID는 유지됩니다.'}
                  </p>}
                  {false && !isPhotoBridgeTagFlow && <button type="button" onClick={onTestPrint} disabled={isPassive || busy} data-testid="button-test-print">테스트 인쇄</button>}
              </div>
              {photoBridgeTagJobNotice && <p role="status" aria-live="polite" data-testid="status-photo-bridge-tag-job">{photoBridgeTagJobNotice}</p>}
            </section>

            <section className="garment-capture__panel garment-capture__panel--devices">
              <div className="garment-capture__panel-heading"><h2>연결 상태</h2></div>
              <p className="garment-capture__mode" data-testid="status-capture-mode">{isPassive
                ? '평소처럼 촬영하세요. 사진 연결 후 실물 태그를 확인해 주세요.'
                : isSimulation ? '연결 상태를 확인한 뒤 촬영해 주세요.'
                  : '연결 상태와 실제 저장·인쇄 결과를 각각 확인해 주세요.'}</p>
              <details><summary>장비 연결 상세 (관리용)</summary>
              <div className="garment-capture__device-list">
                <DeviceStatus label="카메라" value={hardware.camera} testId="status-device-camera" />
                <DeviceStatus label="풋스위치" value={hardware.footSwitch} testId="status-device-foot-switch" />
                <DeviceStatus label="태그 프린터" value={hardware.printer} testId="status-device-printer" />
              </div></details>
              {error && <div className="garment-capture__error" role="alert" data-testid="status-capture-error"><strong>작업을 완료하지 못했습니다.</strong>{error}</div>}
              {notice && !/시뮬레이션|테스트|TEST|DEV|PENDING/i.test(notice) && <p role="status" data-testid="status-capture-notice">{notice}</p>}
              {isPhotoBridgeTagFlow && photoBridgeTagTemplateSource !== 'live' &&
                <p role={photoBridgeTagTemplateSource === 'unavailable' ? 'alert' : 'status'} data-testid="status-tag-template">
                  {photoBridgeTagTemplateNotice || '인쇄 서식 확인 필요 · 실제 출력 완료는 확인되지 않았습니다.'}
                </p>}
              {isPhotoBridgeTagFlow && photoBridgeTagTemplateSource === 'live' &&
                <p role="status" data-testid="status-tag-template">{photoBridgeTagMode === 'STORE'
                  ? '태그 출력 요청 후 실물 태그를 확인해 주세요.'
                  : '매장 인쇄 연결을 확인해 주세요.'}</p>}
            </section>
          </aside>
        </div>

        <button type="button" className="garment-capture__settings" onClick={()=>window.dispatchEvent(new Event('k99-open-store-settings'))}>
          프린터 · 카메라 설정은 매장 맞춤 설정에서 변경
        </button>
        <footer className="garment-capture__footer"><button type="button" onClick={onBack} disabled={busy} data-testid="button-back-from-capture">← 접수 내역으로 돌아가기</button><span><StoreName /></span></footer>
      </div>
    </main>
  );
}