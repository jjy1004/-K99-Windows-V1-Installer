/** Optional UVC controls, applied only AFTER a decoded stream exists.
 * Never owns/stops a track and never negotiates a new stream. */
export type HardwareField='exposureTime'|'gain'|'iso'|'exposureCompensation';
export type HardwarePreferences={exposureMode?:'continuous'|'manual';exposureTime?:number;gain?:number;iso?:number;exposureCompensation?:number};
export type HardwareRange={min:number;max:number;step:number;value:number;enabled:boolean;reason:string};
type Values=Record<string,unknown>;
const fields:HardwareField[]=['exposureTime','gain','iso','exposureCompensation'];
const numeric=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
export class CameraHardware {
  private caps:Values={};
  private pending:Promise<void>|null=null;
  constructor(private track:MediaStreamTrack,private current:()=>boolean=()=>true,private timeoutMs=1800){
    try{this.caps=track.getCapabilities() as unknown as Values;}catch{/* Original video is still usable. */}
  }
  get busy(){return this.pending!==null;}
  get active(){return this.current()&&this.track.readyState==='live';}
  private settings():Values{try{return this.track.getSettings() as unknown as Values;}catch{return {};}}
  private modes(key:string){const v=this.caps[key];return Array.isArray(v)?v.filter(x=>typeof x==='string') as string[]:[];}
  read(){
    const s=this.settings(),controls={} as Record<HardwareField,HardwareRange|null>;
    for(const key of fields){
      const r=this.caps[key] as {min?:number;max?:number;step?:number}|undefined;
      if(!r||!numeric(r.min)||!numeric(r.max)||r.max<=r.min){controls[key]=null;continue;}
      const readable=numeric(s[key]),manual=key==='exposureCompensation'||this.modes('exposureMode').includes('manual');
      controls[key]={min:r.min,max:r.max,step:numeric(r.step)&&r.step>0?r.step:Math.max((r.max-r.min)/100,0.001),
        value:readable?s[key] as number:r.min,enabled:readable&&manual,
        reason:!readable?'장치가 실제 적용값을 제공하지 않습니다.':!manual?'장치가 수동 노출 모드를 제공하지 않습니다.':''};
    }
    return {controls,modes:{exposureMode:s.exposureMode,whiteBalanceMode:s.whiteBalanceMode,focusMode:s.focusMode},
      supported:{exposureMode:this.modes('exposureMode').includes('continuous'),
        whiteBalanceMode:this.modes('whiteBalanceMode').includes('continuous'),focusMode:this.modes('focusMode').includes('continuous')}};
  }
  preferences():HardwarePreferences{
    const s=this.settings(),p:HardwarePreferences={};
    if(s.exposureMode==='manual'||s.exposureMode==='continuous')p.exposureMode=s.exposureMode;
    for(const key of fields)if(numeric(s[key])&&this.read().controls[key]?.enabled)p[key]=s[key] as number;
    return p;
  }
  private async write(patch:Values){
    if(!this.current()||this.track.readyState==='ended')throw Error('카메라가 변경되어 설정을 취소했습니다.');
    if(this.pending)throw Error('장치 설정 응답을 기다리고 있습니다. 영상·촬영은 계속 사용할 수 있습니다.');
    if(typeof this.track.applyConstraints!=='function')throw Error('이 장치는 브라우저 하드웨어 제어를 지원하지 않습니다.');
    const op=Promise.resolve().then(()=>this.track.applyConstraints({advanced:[patch as MediaTrackConstraintSet]}));
    this.pending=op;
    // Keep the lock if the native call outlives the deadline: a late native
    // write must never race another setting. Preview/capture are independent.
    const clear=()=>{if(this.pending===op)this.pending=null;};
    void op.then(clear,clear);
    let timer:ReturnType<typeof setTimeout>|undefined;
    try{
      await Promise.race([op,new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('카메라 설정 응답이 늦습니다. 기존 영상은 유지합니다.')),this.timeoutMs);})]);
      if(!this.current())throw Error('카메라가 변경되어 설정 확인을 취소했습니다.');
      const actual=this.settings();
      for(const [k,v] of Object.entries(patch)){
        const tolerance=this.read().controls[k as HardwareField]?.step??0;
        if(typeof v==='number'?!numeric(actual[k])||Math.abs((actual[k] as number)-v)>Math.max(tolerance/2,0.00001):actual[k]!==v)
          throw Error(`장치가 ${k} 적용값을 확인해 주지 않았습니다. 저장하지 않았습니다.`);
      }
    }finally{clearTimeout(timer);}
  }
  async automatic(){
    const notes:string[]=[];
    for(const key of ['exposureMode','whiteBalanceMode','focusMode']){
      if(!this.modes(key).includes('continuous'))continue;
      try{await this.write({[key]:'continuous'});}catch(e){notes.push(e instanceof Error?e.message:'자동 설정 실패');}
      if(this.pending||!this.current())break;
    }
    const ev=this.read().controls.exposureCompensation;
    if(!this.pending&&this.current()&&ev?.enabled&&ev.min<=0&&ev.max>=0&&ev.value!==0){
      try{await this.set('exposureCompensation',0);}catch(e){notes.push(e instanceof Error?e.message:'노출 보정 초기화 실패');}
    }
    return notes;
  }
  async set(key:HardwareField,value:number){
    const r=this.read().controls[key];
    if(!r?.enabled||!Number.isFinite(value)||value<r.min||value>r.max)throw Error('해당 하드웨어 조절을 지원하지 않거나 허용 범위를 벗어났습니다.');
    const v=Math.max(r.min,Math.min(r.max,r.min+Math.round((value-r.min)/r.step)*r.step));
    const patch:Values={[key]:v};
    if(key!=='exposureCompensation'){
      patch.exposureMode='manual';
      // Switching gain/ISO must not silently reset the existing shutter time.
      const time=this.settings().exposureTime;
      if(key!=='exposureTime'&&numeric(time)&&this.read().controls.exposureTime?.enabled)patch.exposureTime=time;
    }
    await this.write(patch);return this.preferences();
  }
  async restore(p:HardwarePreferences|undefined){
    if(!p)return [];
    const notes:string[]=[];
    const restore:HardwareField[]=p.exposureMode==='manual'?['exposureTime','gain','iso','exposureCompensation']:['exposureCompensation'];
    for(const key of restore){
      if(!numeric(p[key]))continue;
      try{await this.set(key,p[key] as number);}catch(e){notes.push(e instanceof Error?e.message:'저장된 장치 설정 복원 실패');}
      if(this.pending||!this.current())break;
    }
    return notes;
  }
  async brightenWhite(luma:number){
    const r=this.read().controls.exposureCompensation;
    if(!r?.enabled||luma>=220||luma<60)return false;
    const wanted=Math.min(r.max,r.value+Math.min(1.5,Math.log2(240/luma)));
    if(wanted<=r.value)return false;
    await this.set('exposureCompensation',wanted);return true;
  }
}
