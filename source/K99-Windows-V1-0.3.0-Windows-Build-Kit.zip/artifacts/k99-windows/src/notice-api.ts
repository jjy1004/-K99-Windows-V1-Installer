/** Local SQLite APIs; the Electron fetch adapter supplies the native boundary. */
export type StoreProfile = {
  smsMode?:'MS'|'KDE';
  storeName:string; introduction:string; staff:string[]; defaultStaff:string; ownerPhone:string; bankAccount?:string;
  bankName?:string;bankNumber?:string;bankHolder?:string;
  discounts:{firstThreshold:number;firstRate:number;secondThreshold:number;secondRate:number;reviewThreshold:number;reviewDiscount:number};
};
export type NoticeTemplate = {id:string;title:string;stage:'before'|'after'|'advert';text:string;revision:number};
export type NoticeContext = {
  orderId:string; customerName:string;customerPhone:string;customerAddress:string;
  items:{name:string;quantity:number;amount:number}[];total:number;paymentType:string;
  reviewConfirmed?:boolean;
};
export type NoticeQuote = {subtotal:number;rate:number;discount:number;reviewDiscount:number;total:number};
export type CustomerNotice = {
  advertConsentConfirmed?:boolean;
  id:string;orderId:string;customerName:string;customerPhone:string;body:string;theme:string;
  templateId:string;source:'staff'|'mobile';revision:number;updatedAt:string;
};
export type NoticePrepared = {noticeId: string; revision: number};
export type NoticeDeliveryState = {
  orderId: string; templateId: string; preparedAt: string; sentAt: string | null;
  channel: string; summaryOnly: boolean; completionSource?: 'button-click';
};
export const NOTICE_DELIVERY_CHANGED = 'k99-notice-delivery-changed';
export function noticeDeliveryChanged() { window.dispatchEvent(new Event(NOTICE_DELIVERY_CHANGED)); }
export type NoticeCase = {id:string;theme:string;body:string;updatedAt:string;kind?:'before'|'after'|'advert'};
export function calculateStoreQuote(subtotal:number,p:StoreProfile,review=false):NoticeQuote{
  const d=p.discounts;
  let rate=d.firstThreshold>0&&d.firstRate>0&&subtotal>=d.firstThreshold?d.firstRate:0;
  if(d.secondThreshold>0&&d.secondRate>0&&subtotal>=d.secondThreshold)rate=d.secondRate;
  const discount=Math.floor(subtotal*rate/100);
  const reviewDiscount=review&&d.reviewThreshold>0&&d.reviewDiscount>0&&subtotal>=d.reviewThreshold?Math.min(d.reviewDiscount,subtotal-discount):0;
  return {subtotal,rate,discount,reviewDiscount,total:subtotal-discount-reviewDiscount};
}
export type MessengerResult = {
  success:boolean;status?:'opened'|'prepared'|'send_requested'|'unconfirmed'|'failed';
  channel?:string;detail?:string;error?:string;attemptId?:string;manualRequired?:boolean;
  connected?:boolean;verified?:boolean;copied?:boolean;searchPrepared?:boolean;focused?:boolean;bodyVerified?:boolean;
};
export type MessengerCommand =
  {action:'kde-share';source:'order'|'file';orderId?:string;expectedSmsMode:'KDE'}|
  {action:'kakao'}|{action:'kakao-compose'|'sms-compose';body:string;recipient?:string;customerName?:string;expectedSmsMode?:'MS'|'KDE'}|{action:'test';phone:string;channel?:'sms'|'kakao'}|
  {action:'dispatch';noticeId:string;revision:number;mode:'confirm'|'immediate';requestId:string};
export async function noticeApi<T>(method:string,path:string,body?:unknown):Promise<T>{
  const r=await fetch('/api/notices'+path,{method,headers:{'Content-Type':'application/json'},
    ...(body===undefined?{}:{body:JSON.stringify(body)})});
  const result=await r.json();if(!r.ok)throw Error(result.error||'고객 안내 정보를 처리하지 못했습니다.');
  if(method==='PUT'&&path==='/profile')window.dispatchEvent(new Event('k99-store-profile-changed'));
  if(method==='PUT'&&path.startsWith('/templates/'))window.dispatchEvent(new Event('k99-notice-templates-changed'));
  return result as T;
}
export async function messenger(input:MessengerCommand):Promise<MessengerResult>{
  if(!window.k99Desktop?.messenger)return {success:false,manualRequired:true,error:'휴대폰·카톡 실행은 Windows 설치형 프로그램에서 사용할 수 있습니다. 문안 편집·저장은 가능합니다.'};
  return window.k99Desktop.messenger(input);
}
export const OPEN_CUSTOMER_NOTICE='k99:open-customer-notice';
export type NoticeOpenOptions={
  showOrderDetails?:boolean;
  onHandover?:()=>{success:boolean;message:string};
};
export function openCustomerNotice(orderId:string,templateId?:string,options?:NoticeOpenOptions){
  window.dispatchEvent(new CustomEvent(OPEN_CUSTOMER_NOTICE,{detail:{orderId,templateId,...options}}));
}
