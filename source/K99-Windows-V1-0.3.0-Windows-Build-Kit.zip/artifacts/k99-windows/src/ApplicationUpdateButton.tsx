import { useEffect, useRef, useState } from 'react';

type UpdateReply = { phase: string; percent?: number; error?: string; version?: string };
type UpdateApi = (action: 'check' | 'status') => Promise<UpdateReply>;
const api = (): UpdateApi | undefined =>
  (window as unknown as { k99Desktop?: { applicationUpdate?: UpdateApi } }).k99Desktop?.applicationUpdate;
const DONE = /^(idle|none|latest|current|up-to-date|not-available|ready|done|installed|error|failed)$/i;
const PHASE_TEXT: Record<string, string> = {
  current:'이미 최신 버전입니다',verifying:'설치 파일 확인 · 안전 백업 중',
  checking: '새 버전 확인 중', downloading: '내려받는 중', saving: '업무 저장 중', backup: '백업 중', 'backing-up': '백업 중',
  installing: '설치 준비 중', ready: '설치 준비 완료', latest: '최신 버전입니다', 'up-to-date': '최신 버전입니다',
  'not-available': '최신 버전입니다', none: '최신 버전입니다', idle: '대기', error: '업데이트 실패', failed: '업데이트 실패',
};

/** 수동 업데이트 시작 + 진행 상태 표시. 강제 종료 UI는 두지 않는다. */
export function ApplicationUpdateButton() {
  const [state, setState] = useState<UpdateReply | null>(null);
  const [polling, setPolling] = useState(false);
  const alive = useRef(true);
  useEffect(() => {alive.current=true;return () => { alive.current = false; };}, []);
  useEffect(() => {
    if (!polling) return;
    let inflight = false;
    const id = window.setInterval(async () => {
      const fn = api(); if (!fn || inflight) return; inflight = true;
      try {
        const r = await fn('status');
        if (!alive.current) return;
        setState(r);
        if (r.error || DONE.test(r.phase)) setPolling(false);
      } catch (e) { if (alive.current) { setState({ phase: 'error', error: e instanceof Error ? e.message : '상태를 확인하지 못했습니다.' }); setPolling(false); } }
      finally { inflight = false; }
    }, 1000);
    return () => window.clearInterval(id);
  }, [polling]);
  const start = async () => {
    const fn = api();
    if (!fn) { setState({ phase: 'error', error: '업데이트는 매장 PC의 Windows 설치 프로그램에서만 할 수 있습니다.' }); return; }
    setState({ phase: 'checking' });
    try {
      const r = await fn('check');
      if (!alive.current) return;
      setState(r);
      if (!r.error && !DONE.test(r.phase)) setPolling(true);
    } catch (e) { if (alive.current) setState({ phase: 'error', error: e instanceof Error ? e.message : '업데이트를 시작하지 못했습니다.' }); }
  };
  const busy = polling || state?.phase === 'checking';
  const pct = typeof state?.percent === 'number' ? Math.max(0, Math.min(100, Math.round(state.percent))) : null;
  return <span className="dstrip__update" data-testid="area-app-update">
    <button type="button" className="dstrip__toggle" disabled={busy} onClick={() => void start()} data-testid="button-app-update">
      {busy ? '업데이트 진행 중' : '업데이트'}</button>
    {state && !state.error && <span className="dstrip__sync" role="status" data-testid="status-app-update">
      {PHASE_TEXT[state.phase] ?? '업데이트 확인 중'}{state.version ? ` · ${state.version}` : ''}
      {pct !== null && <><span className="dstrip__bar" aria-hidden><i style={{ transform: `scaleX(${pct / 100})` }} /></span>{pct}%</>}
    </span>}
    {state?.error && <span className="dstrip__err" role="alert" data-testid="text-app-update-error">업데이트 실패: {state.error}</span>}
  </span>;
}
export default ApplicationUpdateButton;
