import { ImeTextInput } from './ImeTextInput';
import { useEffect, useMemo, useState } from 'react';
import { readSharedCatalog, saveSharedCatalog, sharedPriceRevision } from './shared-price-catalog';
import { orderDisplayStatus } from './handover-display';
import { useSearch } from 'wouter';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { DEFAULT_DELIVERY_POLICY, readDeliveryPolicy, saveDeliveryPolicy } from './delivery-policy';
import { PRICE_STORAGE_KEY, groupByCategory, premiumFor, readManagedCatalog, saveManagedCatalog, selectableEntries, type CatalogEntry } from './price-catalog';
import {
  approveCustomerNotification, createCustomerNotification, CUSTOMER_NOTIFICATION_TYPES,
  editCustomerNotification, prepareCustomerNotification, recordManualCustomerReply,
  type CustomerNotificationType,
} from './notification-workflow';
import {
  advanceOrderStage, currentOperations, customerHistory, nextStage, operationsSummary,
  cancelOrder, recordOrderPayment, searchOrders, updateOperationsDetails, type OperationsDetails, type PaymentStatus,
  revenueByPeriod,
} from './order-operations';
import { currentStorageFee, daysSinceIntake, koreaCalendarDate } from './storage-policy';
import { ensureOperationalNoticeDrafts, isCurrentOperationalNotice } from './notification-queue';
import { ExternalSendConfirmation } from './ExternalSendConfirmation';
import AdminOrderMaintenance from './AdminOrderMaintenance';
import AdminPasswordPanel from './AdminPasswordPanel';
import './operations-dashboard.css';
import { paymentInfo } from './order-payment';

const won = (value: number) => `${value.toLocaleString('ko-KR')}원`;
const getOrders = () => {
  try { return { orders: readConfirmedOrders(), error: '' }; }
  catch (cause) { return { orders: [] as ConfirmedOrder[], error: cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.' }; }
};

export function OperationsDashboard({ onBack, onResume, catalog, defaults, onCatalogSaved }: {
  onBack: () => void; onResume: (id: string) => void;
  catalog: readonly CatalogEntry[]; defaults: readonly CatalogEntry[]; onCatalogSaved: () => void;
}) {
  const search = useSearch();
  const requestedOrderId = new URLSearchParams(search).get('orderId');
  const requestedNoticeId = new URLSearchParams(search).get('noticeId');
  const [initial] = useState(getOrders);
  const [orders, setOrders] = useState(initial.orders);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(requestedOrderId);
  const [error, setError] = useState(initial.error);
  const [notice, setNotice] = useState('');
  useEffect(() => {
    const refresh = () => {
      const result = getOrders(); setOrders(result.orders); setError(result.error);
    };
    window.addEventListener('storage', refresh);
    window.addEventListener('focus', refresh);
    return () => { window.removeEventListener('storage', refresh); window.removeEventListener('focus', refresh); };
  }, []);
  const [policy, setPolicy] = useState(() => {
    try { return readDeliveryPolicy(); } catch { return DEFAULT_DELIVERY_POLICY; }
  });
  const [policyWarning, setPolicyWarning] = useState(() => {
    try { readDeliveryPolicy(); return ''; } catch { return '저장된 수거·배달 정책을 읽을 수 없습니다. 값을 확인하고 다시 저장해 주세요.'; }
  });
  const [policyDraft, setPolicyDraft] = useState(policy);
  const toPriceDraft = (entries: readonly CatalogEntry[]) => selectableEntries(entries).filter(entry => !entry.custom).map((entry) => ({ ...entry }));
  const [priceDraft, setPriceDraft] = useState(() => toPriceDraft(catalog));
  const [priceStatus, setPriceStatus] = useState<{ kind: 'idle' | 'dirty' | 'saved' | 'error'; message: string }>({ kind: 'idle', message: '' });
  const [savingPrice, setSavingPrice] = useState(false);
  const [priceRevision, setPriceRevision] = useState<number | null>(sharedPriceRevision());
  useEffect(() => {
    if (priceStatus.kind === 'dirty' || priceStatus.kind === 'error' || savingPrice) return;
    setPriceDraft(toPriceDraft(catalog));
    setPriceRevision(sharedPriceRevision());
  }, [catalog]);
  const [detailDraft, setDetailDraft] = useState<OperationsDetails | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('미결제');
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [cancelReason, setCancelReason] = useState('');
  const [notificationType, setNotificationType] = useState<CustomerNotificationType>(CUSTOMER_NOTIFICATION_TYPES[0]);
  const [notificationGarmentId, setNotificationGarmentId] = useState('');
  const [notificationDrafts, setNotificationDrafts] = useState<Record<string, string>>({});
  const [notificationReplies, setNotificationReplies] = useState<Record<string, string>>({});
  const results = useMemo(() => searchOrders(orders, query), [orders, query]);
  const stats = useMemo(() => operationsSummary(orders), [orders]);
  const daily = useMemo(() => revenueByPeriod(orders, 'day'), [orders]);
  const monthly = useMemo(() => revenueByPeriod(orders, 'month'), [orders]);
  const selected = orders.find((order) => order.id === selectedId);
  const ops = selected ? currentOperations(selected) : null;
  const history = selected ? customerHistory(orders, selected.customerPhone) : null;

  useEffect(() => {
    if (requestedOrderId && orders.some((order) => order.id === requestedOrderId)) {
      const order = orders.find((item) => item.id === requestedOrderId)!;
      select(order);
    }
  }, [requestedOrderId, requestedNoticeId]);

  useEffect(() => {
    if (requestedNoticeId && selectedId === requestedOrderId)
      document.getElementById(`notice-${requestedNoticeId}`)?.scrollIntoView({ block: 'center' });
  }, [requestedNoticeId, requestedOrderId, selectedId, orders]);

  const storedItemCount = (order: ConfirmedOrder) => {
    const operations = currentOperations(order);
    if (operations.completedAt || ['매장수령완료', '배달완료'].includes(operations.stage)) return 0;
    return order.garments?.length
      ? order.garments.filter((garment) => garment.handoverStatus !== 'complete' && garment.processStatus !== '반출 완료').length
      : order.totalQuantity;
  };
  const storageAmount = (order: ConfirmedOrder) => currentStorageFee({
    intakeAt: order.intakeAt, totalQuantity: storedItemCount(order),
  }, new Date());

  function select(order: ConfirmedOrder) {
    const current = currentOperations(order);
    setSelectedId(order.id);
    setDetailDraft({ detailAddress: current.detailAddress, pickupDate: current.pickupDate,
      pickupTime: current.pickupTime, deliveryDate: current.deliveryDate, deliveryTime: current.deliveryTime });
    setPaymentStatus(current.paymentStatus);
    setPaymentAmount(current.paidAmount);
    setCancelReason('');
    setNotificationDrafts({});
    setNotificationReplies({});
    setError('');
    setNotice('');
  }

  function persist(update: () => ConfirmedOrder, message: string) {
    try {
      const revised = update();
      if (!selected) throw new Error('먼저 주문을 선택해 주세요.');
      updateSavedOrder(revised, selected);
      setOrders((current) => current.map((order) => order.id === revised.id ? revised : order));
      setNotice(message);
      setError('');
    } catch (cause) {
      try { setOrders(readConfirmedOrders()); } catch { /* Keep the stored error visible below. */ }
      setSelectedId(null);
      setDetailDraft(null);
      setError(cause instanceof Error ? cause.message : '주문을 저장하지 못했습니다.');
    }
  }

  function savePolicy() {
    try {
      const revised = saveDeliveryPolicy(policyDraft);
      setPolicy(revised);
      setPolicyWarning('');
      setNotice('새 수거·배달 정책을 저장했습니다. 기존 주문의 요금은 바뀌지 않습니다.');
      setError('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '정책을 저장하지 못했습니다.'); }
  }

  async function savePrices() {
    if (savingPrice) return;
    setSavingPrice(true);
    try {
      const saved = await saveSharedCatalog(defaults, priceDraft, '', priceRevision);
      setPriceDraft(toPriceDraft(saved));
      setPriceRevision(sharedPriceRevision());
      onCatalogSaved();
      setPriceStatus({ kind: 'saved', message: `가격표를 저장했습니다 (${new Date().toLocaleTimeString('ko-KR')}). 새로 접수하는 세탁물부터 적용되며, 이미 접수된 주문 금액은 바뀌지 않습니다.` });
    } catch (cause) {
      setPriceStatus({ kind: 'error', message: `저장 확인 실패: ${cause instanceof Error ? cause.message : '가격표를 저장하지 못했습니다.'} 서버 가격 다시 불러오기로 결과를 확인하세요. 자동 재저장은 하지 않습니다.` });
    } finally { setSavingPrice(false); }
  }
  function updatePrice(id: string, value: number) {
    setPriceDraft((current) => current.map((item) => item.id === id
      ? { ...item, generalPrice: value, premiumPrice: premiumFor(id, value) } : item));
    setPriceStatus({ kind: 'dirty', message: '저장하지 않은 변경이 있습니다.' });
  }

  return (
    <main className="operations-dashboard" data-testid="operations-dashboard">
      <div className="operations-dashboard__inner">
        <header className="operations-dashboard__header">
          <div><span>이 브라우저에 저장된 기록</span><h1>주문·수거·배달 관리</h1>
            <p>예상금액은 매출이 아닙니다. 아래 매출은 직원이 결제완료로 기록한 금액만 합산합니다.</p>
            <p className="operations-dashboard__warning">직원 로그인·접근권한과 서버 백업이 아직 없습니다. 실제 고객정보 운영 및 고객용 PC 공개 전 보호 저장소와 권한 분리가 필요합니다.</p></div>
          <button type="button" onClick={onBack}>접수 화면으로 돌아가기</button>
        </header>
        <div className="operations-dashboard__metrics">
          <div><button type="button" className="operations-dashboard__orders-shortcut"
            data-testid="button-open-saved-orders" onClick={() => {
              setQuery('');
              document.getElementById('saved-orders-list')?.scrollIntoView({block:'start'});
              document.querySelector<HTMLInputElement>('[data-testid="input-operations-search"]')?.focus({preventScroll:true});
            }}><span>저장 주문 / 고객</span><strong>{stats.orderCount}건 / {stats.customerCount}명</strong>
            <small>저장 주문 목록 열기</small></button></div>
          <div><span>재방문 / 3회 이상</span><strong>{stats.returningCustomers}명 / {stats.frequentCustomers}명</strong></div>
          <div><span>총 세탁물</span><strong>{stats.itemCount}점</strong></div>
          <div><span>기록된 실제 결제액</span><strong>{won(stats.actualRevenue)}</strong></div>
          <div><span>수거 / 배달 이용</span><strong>{stats.pickupCount}건 / {stats.deliveryCount}건</strong></div>
        </div>
        <section className="operations-dashboard__policy">
          <h2>실제 결제액 추이</h2>
          <p>현금·카드 승인 연동 없이 직원이 결제완료로 기록한 주문만 표시합니다. 예상금액은 제외합니다.</p>
          <div className="operations-dashboard__form-grid">
            <div><h3>일별</h3>{daily.length ? daily.map(([date, amount]) =>
              <p key={date}>{date} · {won(amount.amount)} · {amount.visits}건 (일반 {won(amount.general)} / 프리미엄 {won(amount.premium)})</p>)
              : <p>기록된 결제가 없습니다.</p>}</div>
            <div><h3>월별</h3>{monthly.length ? monthly.map(([month, amount]) =>
              <p key={month}>{month} · {won(amount.amount)} · {amount.visits}건</p>)
              : <p>기록된 결제가 없습니다.</p>}</div>
          </div>
        </section>
        <details className="operations-dashboard__policy operations-dashboard__prices" data-testid="admin-price-editor">
          <summary>관리자 세탁 가격표 · {priceDraft.length}개 품목</summary>
          <p>일반 세탁비만 입력합니다. 프리미엄은 일반가 +9,000원으로 자동 계산되며 와이셔츠 프리미엄은 9,000원입니다. 프리미엄 운동화 서비스는 운동화 일반가 +9,000원입니다. 저장한 가격은 새 접수부터 적용됩니다.</p>
          <div className="operations-dashboard__price-list">
            {groupByCategory(priceDraft).map((group) => <div key={group.category} data-testid={`price-group-${group.category}`}>
              <h3 className="operations-dashboard__price-group">{group.label}</h3>
              {group.items.map((item) => <div className="operations-dashboard__price-row" key={item.id}>
                <strong>{item.displayNameKo}</strong>
                <label>일반 세탁비 <input type="number" min="1" max="100000000" step="1000" data-testid={`input-general-price-${item.id}`}
                  value={Number.isFinite(item.generalPrice) ? item.generalPrice : ''} onChange={(event) => updatePrice(item.id, event.target.value === '' ? Number.NaN : Number(event.target.value))} /></label>
                <span data-testid={`text-premium-price-${item.id}`}>프리미엄 <b>{Number.isFinite(item.premiumPrice) ? won(item.premiumPrice) : '-'}</b></span>
              </div>)}
            </div>)}
          </div>
          <p>이 Windows PC의 SQLite 가격표를 비밀번호 없이 저장합니다. 기존 접수 금액은 변경하지 않습니다.</p>
          <button type="button" disabled={savingPrice || priceRevision === null} data-testid="button-save-prices" onClick={() => void savePrices()}>{savingPrice ? '로컬 저장 중…' : '가격표 저장'}</button>
          <button type="button" disabled={savingPrice} onClick={() => {
            if (priceStatus.kind === 'dirty' && !window.confirm('저장하지 않은 가격 변경을 버리고 서버 가격을 다시 불러올까요?')) return;
            void readSharedCatalog(defaults).then(values => {
              setPriceDraft(toPriceDraft(values)); setPriceRevision(sharedPriceRevision());
              setPriceStatus({kind: 'idle', message: '서버 공통 가격표를 불러왔습니다.'});
            }).catch(() => setPriceStatus({kind:'error',message:'서버 가격표 불러오기 실패. 다시 확인하세요.'}));
          }}>서버 가격 다시 불러오기</button>
          {priceStatus.message && <p data-testid="status-price-save" role={priceStatus.kind === 'error' ? 'alert' : 'status'}
            className={`operations-dashboard__price-status is-${priceStatus.kind}`}>{priceStatus.message}</p>}
        </details>
        <details data-testid="admin-order-maintenance-menu">
          <summary>관리자 메뉴 · 주문 백업·복구 및 삭제 감사 기록</summary>
          <AdminOrderMaintenance />
        </details>
        <details data-testid="admin-password-menu">
          <summary>매장 PC · Zero-Auth 설정</summary>
          <AdminPasswordPanel />
        </details>
        <section className="operations-dashboard__policy">
          <div><h2>수거·배달비 설정</h2><p>현재 기본값: {policy.freeFromQuantity}점 이상 무료 · 미만 수거 또는 배달 시 주문당 {won(policy.feeBelowThreshold)}</p></div>
          {policyWarning && <p role="alert" className="operations-dashboard__warning">{policyWarning}</p>}
          <label>무료 기준 수량
            <input type="number" min="1" max="999" step="1" value={policyDraft.freeFromQuantity}
              onChange={(event) => setPolicyDraft({ ...policyDraft, freeFromQuantity: Number(event.target.value) })} />
          </label>
          <label>기준 미만 요금
            <input type="number" min="0" max="1000000" step="1" value={policyDraft.feeBelowThreshold}
              onChange={(event) => setPolicyDraft({ ...policyDraft, feeBelowThreshold: Number(event.target.value) })} />
          </label>
          <button type="button" onClick={savePolicy}>정책 저장</button>
          <p>새로 확정하는 주문부터 적용됩니다. 21개 품목의 세탁 가격표는 변경하지 않습니다.</p>
        </section>
        <section className="operations-dashboard__search" id="saved-orders-list">
          <h2>저장 주문 검색</h2>
          <label>고객명, 전화번호, 주문번호, 의류 수량, 품목, 접수일 검색
            <ImeTextInput koreanFirst="search" data-scanner-input type="search" value={query} onValue={setQuery}
              placeholder="검색어를 입력하세요" data-testid="input-operations-search" />
          </label>
          <p>{results.length}건 · 현재 브라우저에 저장된 기록만 검색합니다.</p>
          <div className="operations-dashboard__results">
            {results.map((order) => (
              <button type="button" key={order.id} onClick={() => select(order)} aria-pressed={selectedId === order.id}
                data-testid={`button-operations-order-${order.id}`}>
                <strong>{order.customerName} · {order.items.map((item) => item.displayNameKo).join(', ')}</strong>
                <span>{order.customerPhone} · {order.intakeAt.slice(0, 10)} · {order.totalQuantity}벌 · {currentOperations(order).cancelledAt ? '접수 취소' : orderDisplayStatus(order, currentOperations(order).stage)}</span>
                <small>주문번호 {order.id}</small>
                <small>{orderDisplayStatus(order)} · 보관료 {won(storageAmount(order))} · 저장 알림 {(order.customerNotifications ?? []).length}건</small>
              </button>
            ))}
            {!results.length && <p>검색 결과가 없습니다.</p>}
          </div>
        </section>
        {selected && ops && history && detailDraft && (
          <section className="operations-dashboard__detail" data-testid="operations-selected-order">
            <div className="operations-dashboard__detail-header"><div><h2>{selected.customerName}</h2>
              <p>{selected.customerAddress} · 총 {selected.totalQuantity}점 · 최초 예상 {won(selected.estimatedTotal)}</p></div>
              <button type="button" onClick={() => onResume(selected.id)} data-testid="button-open-order-workspace">주문 전체 처리 열기</button></div>
            <div className="operations-dashboard__profile">
              <div><span>최초 / 최근 방문</span><strong>{history.firstVisit?.slice(0, 10)} / {history.recentVisit?.slice(0, 10)}</strong></div>
              <div><span>방문 / 총 수량</span><strong>{history.visitCount}회 / {history.itemCount}점</strong></div>
              <div><span>실제 결제액</span><strong>{won(history.paidTotal)}</strong></div>
              <div><span>일반 / 프리미엄</span><strong>{history.generalCount}회 / {history.premiumCount}회</strong></div>
              <div><span>수거 / 배달</span><strong>{history.pickupCount}회 / {history.deliveryCount}회</strong></div>
            </div>
            <div className="operations-dashboard__profile" data-testid="operations-storage-summary">
              <div><span>보관 경과</span><strong>{daysSinceIntake(selected, new Date()) + 1}일 · 무료 15일</strong></div>
              <div><span>현재 보관료</span><strong>{won(storageAmount(selected))}</strong></div>
              <div><span>장기 미수령 알림 초안 · 전송 안 함</span><strong>{(selected.customerNotifications ?? [])
                .filter((notice) => notice.type === '장기 미수령 알림')
                .map((notice) => notice.reminderDay ? `${notice.reminderDay}일차` : '직원 생성').join(' · ') || '없음'}</strong></div>
              <div><span>기준일</span><strong>{koreaCalendarDate(new Date())}</strong></div>
            </div>
            <p className="operations-dashboard__warning">보관료 기준: 접수일 포함 15일 무료, 16일차부터 미출고 의류 1벌당 하루 1,000원. 접수 후 7일·12일 경과 시 안내를 준비합니다. 발송 대상은 오늘의 할 일에서 최신 단계 하나만 권장합니다. 직원 확인 전 자동 발송하지 않습니다.</p>
            {ops.cancelledAt && <p role="status" className="operations-dashboard__warning">접수 취소 · {ops.cancelReason} ({ops.cancelledAt.slice(0, 10)}) · 기록은 보존됩니다.</p>}
            <h3>일정과 상세주소</h3>
            <div className="operations-dashboard__form-grid">
              {([
                ['detailAddress', '상세주소', 'text'], ['pickupDate', '수거 요청일', 'date'],
                ['pickupTime', '수거시간', 'time'], ['deliveryDate', '배달 예정일', 'date'],
                ['deliveryTime', '배달시간', 'time'],
              ] as const).map(([key, label, type]) => (
                <label key={key}>{label}
                  <input type={type} value={detailDraft[key]} onChange={(event) => setDetailDraft({ ...detailDraft, [key]: event.target.value })} />
                </label>
              ))}
            </div>
            {!ops.cancelledAt && <button type="button" onClick={() => persist(() => updateOperationsDetails(selected, detailDraft), '일정·상세주소를 기록했습니다.')} data-testid="button-save-operations-details">일정 저장</button>}
            <h3>수거·세탁·배달 단계</h3>
            <p>현재 단계: <strong data-testid="operations-current-stage">{ops.cancelledAt ? '접수 취소' : orderDisplayStatus(selected, ops.stage)}</strong> · 마지막 기록: {new Date(ops.updatedAt).toLocaleString('ko-KR')}</p>
            {nextStage(selected) && <button type="button" className="operations-dashboard__primary"
              onClick={() => {
                const stage = nextStage(selected)!;
                const unpaid = ['매장수령완료', '배달중', '배달완료'].includes(stage) &&
                  paymentInfo(selected).type === 'POSTPAID' && paymentInfo(selected).status === 'UNPAID';
                if (unpaid && !window.confirm(`결제 완료 후 출고하시겠습니까?\n미납금액: ${paymentInfo(selected).due.toLocaleString('ko-KR')}원\n실제 결제 확인 후 진행하세요.`)) return;
                persist(() => advanceOrderStage(unpaid
                  ? recordOrderPayment(selected, '결제완료', selected.estimatedTotal) : selected, stage), '다음 단계를 기록했습니다.');
              }}
              data-testid="button-advance-order-stage">다음 단계: {nextStage(selected)}</button>}
            {!ops.cancelledAt && ops.stage === '매장입고' && selected.status !== '세탁 진행 승인' && selected.status !== '전체 세탁 완료 / 반출 대기' && <p className="operations-dashboard__warning">세탁중으로 이동하려면 전문 검수 및 필요한 고객 동의를 먼저 완료해 주세요.</p>}
            <h3>결제 기록 · 실제 결제 처리 아님</h3>
            <div className="operations-dashboard__form-grid">
              <label>결제상태
                <select value={paymentStatus} onChange={(event) => setPaymentStatus(event.target.value as PaymentStatus)}>
                  <option>미결제</option><option>결제완료</option><option>환불</option>
                </select>
              </label>
              <label>실제 결제금액
                <input type="number" min="0" step="1" value={paymentAmount}
                  onChange={(event) => setPaymentAmount(Number(event.target.value))} />
              </label>
            </div>
            <button type="button" onClick={() => persist(() => recordOrderPayment(selected, paymentStatus, paymentAmount), '직원이 결제상태를 기록했습니다. 실제 결제는 처리하지 않았습니다.')}>결제 기록 저장</button>
            {!ops.cancelledAt && <div className="operations-dashboard__cancel">
              <label>접수 취소 사유 <input value={cancelReason} maxLength={200}
                onChange={(event) => setCancelReason(event.target.value)} placeholder="취소 사유를 입력하세요" /></label>
              <button type="button" onClick={() => {
                if (!window.confirm('접수를 취소 기록하시겠습니까? 주문과 고객 기록은 삭제되지 않습니다.')) return;
                persist(() => cancelOrder(selected, cancelReason), '접수 취소를 기록했습니다. 기존 데이터는 삭제하지 않았습니다.');
              }}>접수 취소 기록</button>
            </div>}
            <h3>고객 알림 워크플로 · 직원 확인 전용</h3>
            <p className="operations-dashboard__warning">이 시스템은 문자·카카오톡을 전송하지 않습니다. 승인·발송 준비만으로는 미발송 상태가 해제되지 않습니다. 외부 발송을 확인한 직원이 별도로 확인 근거를 기록해야 합니다. 고객 회신 입력은 승인이나 발송 확인이 아닙니다.</p>
            <div className="operations-dashboard__notification-create">
              <button type="button" onClick={() => {
                const revised = ensureOperationalNoticeDrafts(selected);
                if (revised === selected) { setNotice('추가로 준비할 예정 알림이 없습니다.'); return; }
                persist(() => revised, '예정 알림 초안을 저장했습니다. 직원 확인 전이며 전송하지 않았습니다.');
              }}>예정 알림 초안 준비 · 전송 안 함</button>
              <label>알림 종류
                <select value={notificationType} onChange={(event) => setNotificationType(event.target.value as CustomerNotificationType)}
                  data-testid="select-customer-notification-type">
                  {CUSTOMER_NOTIFICATION_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}
                </select>
              </label>
              <label>대상 세탁물
                <select value={notificationGarmentId} onChange={(event) => setNotificationGarmentId(event.target.value)}
                  data-testid="select-customer-notification-garment">
                  <option value="">주문 전체</option>
                  {(selected.garments ?? []).map((garment) => <option key={garment.garmentId} value={garment.garmentId}>
                    {garment.itemName} {garment.sequence}/{garment.totalSequence}
                  </option>)}
                </select>
              </label>
              <button type="button" className="operations-dashboard__primary" data-testid="button-create-customer-notification"
                onClick={() => persist(() => createCustomerNotification(selected, notificationType, notificationGarmentId || undefined),
                  '고객 알림 초안을 주문에 저장했습니다. 실제 전송은 되지 않았습니다.')}>초안 생성</button>
            </div>
            {(selected.customerNotifications ?? []).length ? (selected.customerNotifications ?? []).map((notification) => (
              <div className="operations-dashboard__notification" key={notification.id} id={`notice-${notification.id}`} data-testid={`customer-notification-${notification.id}`}>
                <strong>{notification.type} · {notification.garmentId
                  ? `${selected.garments?.find((item) => item.garmentId === notification.garmentId)?.itemName ?? '의류'}` : '주문 전체'}</strong>
                <p>생성 {new Date(notification.createdAt).toLocaleString('ko-KR')} · 승인 {notification.approvalAt
                  ? new Date(notification.approvalAt).toLocaleString('ko-KR') : '미승인'} · 발송 준비 {notification.sendPreparationAt
                    ? new Date(notification.sendPreparationAt).toLocaleString('ko-KR') : '미준비'} · {notification.externalSendConfirmation ? '외부 발송 직원 확인 기록 있음' : '미발송 · 실제 발송 확인 없음'}</p>
                {(notification.sourceKey || notification.reminderDay) && !isCurrentOperationalNotice(selected, notification) &&
                  <p>이전 일정·완성 주기·보관 정책 또는 출고 전 안내 이력입니다. 현재 미발송 목록의 대상이 아닙니다. 기록은 보존됩니다.</p>}
                <label>직원 검토용 문안
                  <textarea value={notificationDrafts[notification.id] ?? notification.draftText}
                    disabled={!!notification.approvalAt}
                    onChange={(event) => setNotificationDrafts({ ...notificationDrafts, [notification.id]: event.target.value })}
                    data-testid={`textarea-customer-notification-draft-${notification.id}`} />
                </label>
                {!notification.approvalAt && <button type="button" data-testid={`button-save-customer-notification-${notification.id}`}
                  onClick={() => persist(() => editCustomerNotification(selected, notification.id,
                    notificationDrafts[notification.id] ?? notification.draftText), '알림 초안을 수정했습니다.')}>초안 수정 저장</button>}
                {!notification.approvalAt && <button type="button" data-testid={`button-approve-customer-notification-${notification.id}`}
                  onClick={() => persist(() => approveCustomerNotification(
                    editCustomerNotification(selected, notification.id, notificationDrafts[notification.id] ?? notification.draftText),
                    notification.id), '화면의 문안을 저장하고 직원 명시 승인을 기록했습니다. 메시지는 전송하지 않았습니다.')}>직원 명시 승인</button>}
                <button type="button" data-testid={`button-copy-customer-notification-${notification.id}`}
                  onClick={() => { void navigator.clipboard.writeText(notificationDrafts[notification.id] ?? notification.draftText)
                    .then(() => setNotice('문안을 복사했습니다. 발송되지는 않았습니다.'))
                    .catch(() => setError('문안 복사에 실패했습니다. 문안을 직접 선택해 복사해 주세요.')); }}>문안 복사 · 발송 아님</button>
                {notification.approvalAt && !notification.sendPreparationAt && <button type="button" data-testid={`button-prepare-customer-notification-${notification.id}`}
                  onClick={() => persist(() => prepareCustomerNotification(selected, notification.id), '발송 준비 기록을 저장했습니다. 실제 전송은 되지 않았습니다.')}>발송 준비 기록</button>}
                {(!(notification.sourceKey || notification.reminderDay) || isCurrentOperationalNotice(selected, notification) ||
                    notification.externalSendConfirmation) &&
                  <ExternalSendConfirmation order={selected} notification={notification}
                    onConfirm={(update) => persist(update, '외부 실제 발송에 대한 직원 확인 기록을 저장했습니다. 이 시스템은 전송하지 않았습니다.')} />}
                {notification.inspectionSnapshot && <details className="operations-dashboard__notification-snapshot">
                  <summary>검수 당시 원본·변경 내용 보기</summary>
                  <p>세탁방법 원본: {notification.inspectionSnapshot.originalCleaningMethods.map((item) => `${selected.garments?.find((g) => g.garmentId === item.garmentId)?.itemName ?? '의류'} ${item.method}`).join(' · ')}</p>
                  <p>세탁방법 변경: {notification.inspectionSnapshot.revisedCleaningMethods.map((item) => `${selected.garments?.find((g) => g.garmentId === item.garmentId)?.itemName ?? '의류'} ${item.method}`).join(' · ')}</p>
                  <p>예상금액: {won(notification.inspectionSnapshot.originalPrice)} → {won(notification.inspectionSnapshot.revisedPrice)}</p>
                  <p>위험 안내: {notification.inspectionSnapshot.riskExplanation || '없음'}</p>
                  <p>면책/동의 상태(검수 스냅샷): {notification.inspectionSnapshot.waiverConsentStatus}</p>
                </details>}
                <label>고객 회신 수동 기록 · 회신은 승인으로 간주하지 않음
                  <textarea value={notificationReplies[notification.id] ?? notification.manualReply?.text ?? ''}
                    onChange={(event) => setNotificationReplies({ ...notificationReplies, [notification.id]: event.target.value })}
                    data-testid={`textarea-customer-notification-reply-${notification.id}`} />
                </label>
                <button type="button" data-testid={`button-record-customer-reply-${notification.id}`}
                  onClick={() => persist(() => recordManualCustomerReply(selected, notification.id,
                    notificationReplies[notification.id] ?? notification.manualReply?.text ?? ''), '고객 회신을 수동 기록했습니다. 주문 승인 상태는 변경하지 않았습니다.')}>회신 수동 기록</button>
                {notification.manualReply && <p>수동 회신 ({new Date(notification.manualReply.recordedAt).toLocaleString('ko-KR')}): {notification.manualReply.text}</p>}
              </div>
            )) : <p>고객 알림 초안이 없습니다. 종류를 선택해 직원 검토용 문안을 생성하세요.</p>}
            <h3>기존 운영 단계 알림 초안 · 변경 없음</h3>
            {ops.notifications.length ? ops.notifications.map((notification) => (
              <div className="operations-dashboard__notification" key={notification.id}>
                <strong>{notification.trigger} · {notification.status}</strong><p>{notification.message}</p>
              </div>
            )) : <p>아직 생성된 초안이 없습니다. 문자·카카오톡은 전송하지 않습니다.</p>}
            <p>알림 API가 연결되지 않았습니다. 초안은 저장하지만 실제 고객에게 메시지를 보내지 않습니다.</p>
          </section>
        )}
        {error && <p className="operations-dashboard__error" role="alert">{error}</p>}
        {notice && <p className="operations-dashboard__notice" role="status">{notice}</p>}
      </div>
    </main>
  );
}