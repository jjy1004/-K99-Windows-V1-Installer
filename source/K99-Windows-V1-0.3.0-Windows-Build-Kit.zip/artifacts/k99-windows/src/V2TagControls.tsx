import { useEffect, useState } from 'react';
import { Printer, Tags } from 'lucide-react';
import './v2-controls.css';

export type PrinterKind = "tsc" | "xprinter";
export type TagPolicy = { mode: "printer" | "roll" | "none"; lastNumber: string; printerKind?: PrinterKind; numbering?: "customer" | "legacy"; nextCustomer?: number };

const PRINTER_LABEL: Record<PrinterKind, string> = { tsc: 'TSC 라벨 프린터', xprinter: 'Xprinter 라벨 프린터' };

export function V2TagControls({ policy, onMode, onPrinterKind, onNumber, currentNumber, error, numberOnly=false }: {
  policy: TagPolicy;
  onMode: (mode: TagPolicy["mode"]) => void;
  onPrinterKind?: (kind: PrinterKind) => void;
  onNumber: (number: string) => void;
  currentNumber: string;
  error?: string;
  numberOnly?: boolean;
}) {
  const [draft, setDraft] = useState(currentNumber);
  useEffect(() => { setDraft(currentNumber); }, [currentNumber]);
  const commit = () => { if (draft.trim() !== currentNumber) onNumber(draft.trim()); };
  const roll = policy.mode === 'roll';
  const kind: PrinterKind = policy.printerKind ?? 'tsc';
  const pickPrinter = (k: PrinterKind) => { if (onPrinterKind) onPrinterKind(k); else onMode('printer'); };
  const none = policy.mode === 'none';
  const customer = roll && policy.numbering === 'customer';
  if(none)return (
    <section className="v2t" aria-label="태그 방식" data-testid="v2-tag-controls">
      <div className="v2t-hint v2t-pad" data-testid="status-tag-none"><b>택 미사용</b> · 사진만 저장합니다.</div>
    </section>
  );
  if(numberOnly&&!roll)return null;

  return (
    <section className="v2t" aria-label="태그 방식" data-testid="v2-tag-controls">
      {!numberOnly&&<div className="v2t-modes" role="group" aria-label="태그 방식 선택">
        {(['tsc', 'xprinter'] as const).map(k => (
          <button key={k} type="button" className="v2t-mode" aria-pressed={!roll && kind === k}
            aria-label={`${PRINTER_LABEL[k]} 출력`} data-testid={`button-tag-printer-${k}`}
            onClick={() => pickPrinter(k)}>
            <Printer size={14} aria-hidden /> {k === 'tsc' ? 'TSC' : 'Xprinter'}
          </button>
        ))}
        <button type="button" className="v2t-mode" aria-pressed={roll} aria-label="기성 롤태그 표시"
          data-testid="button-tag-roll" onClick={() => onMode('roll')}>
          <Tags size={14} aria-hidden /> 롤태그
        </button>
      </div>}
      {customer ? (
        <div className="v2t-roll" data-testid="status-tag-customer">
          <div className="v2t-field">
            <span>현재 품목 수기택 번호</span>
            <output className="v2t-input" aria-label="현재 품목 수기택 번호 (읽기 전용)" data-testid="text-manual-tag-number">{currentNumber || '번호 준비 중'}</output>
          </div>
          <div className="v2t-hint">
            {error ? <span className="v2t-err" role="alert">{error}</span>
              : <>번호는 자동으로 이어집니다 (예 1-1, 1-2 → 다음 고객 2-1). 시작 번호는 설정 › 하드웨어 › 라벨·수기택에서 바꿉니다.</>}
          </div>
        </div>
      ) : roll ? (
        <div className="v2t-roll">
          <label className="v2t-field">
            <span>품목 번호</span>
            <input type="text" inputMode="numeric" className="v2t-input" aria-label="현재 품목 롤태그 번호"
              placeholder="2-101" value={draft} aria-invalid={!!error}
              onChange={(e) => setDraft(e.target.value)} onBlur={commit}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); commit(); } }} />
          </label>
          <div className="v2t-hint">
            {error ? <span className="v2t-err" role="alert">{error}</span>
              : <>마지막 확정: <b>{policy.lastNumber || '없음'}</b> · 예 2-101</>}
          </div>
        </div>
      ) : (
        <div className="v2t-hint v2t-pad">
          {error ? <span className="v2t-err" role="alert">{error}</span>
            : <>접수 시 <b>{PRINTER_LABEL[kind]}</b>로 태그가 자동 출력됩니다.</>}
        </div>
      )}
    </section>
  );
}

export default V2TagControls;
