import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { BookOpen, X } from 'lucide-react';

const SRC = `${import.meta.env.BASE_URL}images/manual-tag-guide/manual-tag-numbering.svg`;

/** 수기택 번호 전용 큰 그림 설명. 일반 도움말과 별개. */
export function ManualTagGuideButton() {
  const [open, setOpen] = useState(false);
  return <>
    <button type="button" className="sh-btn ghost" onClick={() => setOpen(true)} data-testid="button-guide-manualtag"><BookOpen aria-hidden />수기택 그림 설명</button>
    {open && <ManualTagGuideModal onClose={() => setOpen(false)} />}
  </>;
}

function ManualTagGuideModal({ onClose }: { onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const prev = document.activeElement as HTMLElement | null; ref.current?.focus(); return () => { if (prev?.isConnected) prev.focus(); }; }, []);
  return createPortal(
    <div className="nc-backdrop" data-notice-modal="true" onKeyDown={e => { e.stopPropagation(); if (e.key === 'Escape') onClose(); }} onKeyUp={e => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className="nc-modal" role="dialog" aria-modal="true" aria-label="수기택 그림 설명" data-testid="modal-manual-tag-guide">
        <div className="nc-head">
          <div><h2>수기택 그림 설명</h2><p>1-1, 1-2, 1-3 다음 고객은 2-1, 2-2 · 고객번호 1~10000</p></div>
          <button type="button" className="nc-close" onClick={onClose} aria-label="수기택 그림 설명 닫기" data-testid="button-close-manual-tag-guide"><X size={22} aria-hidden />닫기</button>
        </div>
        <img src={SRC} alt="수기택 번호: 첫 고객 1-1, 1-2, 1-3, 다음 고객 2-1, 2-2. 고객번호는 1부터 10000까지" style={{ display: 'block', width: '100%', height: 'auto' }} data-testid="img-manual-tag-guide" />
      </div>
    </div>, document.body);
}
