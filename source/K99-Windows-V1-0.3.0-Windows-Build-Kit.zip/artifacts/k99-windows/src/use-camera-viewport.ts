import { useCallback, useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from 'react';
import { cameraCrop, clampZoom, createZoomHold, drawCameraView, INITIAL_CAMERA_VIEW, panCamera, type CameraView } from './camera-viewport';

export function useCameraViewport(enabled: boolean, resetKey: string) {
  const [view, setView] = useState<CameraView>({ ...INITIAL_CAMERA_VIEW });
  const current = useRef(view);
  const [stage, setStage] = useState<HTMLDivElement | null>(null);
  const stageRef = useCallback((node: HTMLDivElement | null) => setStage(node), []);
  const [size, setSize] = useState({ w: 16, h: 9, sw: 1920, sh: 1080 });
  const drag = useRef<{ id: number; x: number; y: number } | null>(null);
  const update = useCallback((next: CameraView) => { current.current = next; setView(next); }, []);
  const reset = useCallback(() => { update({ ...INITIAL_CAMERA_VIEW }); drag.current = null; }, [update]);
  const zoomBy = useCallback((delta: number) => {
    const zoom = clampZoom(current.current.zoom + delta);
    update(zoom === 1 ? { ...INITIAL_CAMERA_VIEW } : { ...current.current, zoom });
  }, [update]);
  const [hold] = useState(() => createZoomHold({
    now: () => performance.now(), request: cb => requestAnimationFrame(cb), cancel: id => cancelAnimationFrame(id),
    increase: zoomBy, tap: reset,
  }));
  useEffect(() => { hold.cancel(); reset(); }, [enabled, resetKey, hold, reset]);
  useEffect(() => {
    const cancel = () => { hold.cancel(); drag.current = null; };
    const visibility = () => { if (document.hidden) cancel(); };
    window.addEventListener('blur', cancel); document.addEventListener('visibilitychange', visibility);
    return () => { cancel(); window.removeEventListener('blur', cancel); document.removeEventListener('visibilitychange', visibility); };
  }, [hold]);
  useEffect(() => {
    if (!stage) return;
    const measure = () => {
      const rect = stage.getBoundingClientRect();
      if (rect.width && rect.height) setSize(s => ({ ...s, w: rect.width, h: rect.height }));
    };
    measure(); const observer = new ResizeObserver(measure); observer.observe(stage);
    const wheel = (event: WheelEvent) => {
      if (!enabled) return;
      event.preventDefault(); hold.cancel();
      const pixels = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? stage.clientHeight : 1);
      zoomBy(-pixels * 0.002);
    };
    stage.addEventListener('wheel', wheel, { passive: false });
    return () => { observer.disconnect(); stage.removeEventListener('wheel', wheel); };
  }, [stage, enabled, hold, zoomBy]);
  const crop = cameraCrop(size.sw, size.sh, size.w, size.h, view);
  const videoStyle: CSSProperties = {
    position: 'absolute', maxWidth: 'none', width: `${size.sw / crop.width * 100}%`,
    height: `${size.sh / crop.height * 100}%`, left: `${-crop.x / crop.width * 100}%`,
    top: `${-crop.y / crop.height * 100}%`, objectFit: 'fill', pointerEvents: 'none',
  };
  const endPan = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (drag.current?.id === event.pointerId) drag.current = null;
  };
  return {
    stageRef, view, hold, reset, videoStyle,
    onMetadata: (video: HTMLVideoElement) => setSize(s => ({ ...s, sw: video.videoWidth || 1920, sh: video.videoHeight || 1080 })),
    stageEvents: {
      onPointerDown: (event: ReactPointerEvent<HTMLDivElement>) => {
        if (!enabled || current.current.zoom <= 1 || event.button !== 0) return;
        event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY };
      },
      onPointerMove: (event: ReactPointerEvent<HTMLDivElement>) => {
        const from = drag.current;
        if (!from || from.id !== event.pointerId) return;
        const rect = event.currentTarget.getBoundingClientRect();
        update(panCamera(current.current, event.clientX - from.x, event.clientY - from.y, size.sw, size.sh, rect.width, rect.height));
        drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY };
      },
      onPointerUp: endPan, onPointerCancel: endPan, onLostPointerCapture: endPan,
    },
    capture: (context: CanvasRenderingContext2D, video: HTMLVideoElement) => {
      const rect = stage?.getBoundingClientRect();
      drawCameraView(context, video, rect?.width || video.videoWidth, rect?.height || video.videoHeight, current.current);
    },
  };
}
