/** Optional user-selected resolution, isolated from the restored camera opener. */
const stop=(s:MediaStream)=>s.getTracks().forEach(t=>t.stop());
async function decoded(video:HTMLVideoElement,current:()=>boolean,ms:number){
  let timer:ReturnType<typeof setTimeout>|undefined,interval:ReturnType<typeof setInterval>|undefined;
  try{
    await new Promise<void>((resolve,reject)=>{
      const check=()=>{
        if(!current())reject(Error('카메라 설정 변경이 취소되었습니다.'));
        else if(video.readyState>=2&&video.videoWidth>0&&video.videoHeight>0)resolve();
      };
      timer=setTimeout(()=>reject(Error('선택한 해상도의 영상이 준비되지 않았습니다.')),ms);
      interval=setInterval(check,25);
      try{Promise.resolve(video.play()).then(check,reject);}catch(error){reject(error);}
      queueMicrotask(check);
    });
  }finally{clearInterval(interval);clearTimeout(timer);}
}
export async function changeCameraResolution({
  media,video,oldStream,deviceId,width,height,current,commit,freeze=()=>()=>{},
  createVideo=()=>document.createElement('video'),timeoutMs=4000,
}:{
  media:Pick<MediaDevices,'getUserMedia'>;video:HTMLVideoElement;oldStream:MediaStream;
  deviceId:string;width:number;height:number;current:()=>boolean;commit:(s:MediaStream)=>void;
  freeze?:()=>()=>void;createVideo?:()=>HTMLVideoElement;timeoutMs?:number;
}):Promise<void>{
  if(!deviceId||!Number.isSafeInteger(width)||!Number.isSafeInteger(height)||width<1||height<1)
    throw Error('현재 카메라와 해상도를 먼저 확인하세요.');
  let candidate:MediaStream|undefined,probe:HTMLVideoElement|undefined,unfreeze:()=>void=()=>{};
  let committed=false,attached=false,expired=false,timer:ReturnType<typeof setTimeout>|undefined;
  try{
    candidate=await new Promise<MediaStream>((resolve,reject)=>{
      timer=setTimeout(()=>{expired=true;reject(Error('해상도 변경 응답이 없어 기존 화면을 유지합니다.'));},timeoutMs);
      // No manual UVC exposure/WB, frame-rate, minimum or exact resolution.
      Promise.resolve(media.getUserMedia({audio:false,video:{
        deviceId,width:{ideal:width},height:{ideal:height},
      }})).then(s=>{
        if(expired||!current()){stop(s);reject(Error('카메라 설정 변경이 취소되었습니다.'));return;}
        clearTimeout(timer);resolve(s);
      },reject);
    });
    const track=candidate.getVideoTracks()[0],actual=track?.getSettings?.().deviceId;
    if(!track||(actual&&actual!==deviceId))throw Error('다른 카메라의 영상은 사용하지 않습니다.');
    probe=createVideo();probe.muted=true;probe.autoplay=true;probe.playsInline=true;probe.srcObject=candidate;
    await decoded(probe,current,timeoutMs);
    if(probe.videoWidth!==width||probe.videoHeight!==height)
      throw Error(`요청 ${width}×${height}를 지원하지 않습니다. 기존 정상 화면을 유지합니다.`);
    if(!current())throw Error('카메라 설정 변경이 취소되었습니다.');
    unfreeze=freeze();attached=true;video.srcObject=candidate;
    await decoded(video,current,timeoutMs);
    if(video.videoWidth!==width||video.videoHeight!==height)throw Error('영상 해상도를 확인하지 못했습니다.');
    commit(candidate);committed=true;stop(oldStream);
  }catch(error){
    if(attached&&video.srcObject===candidate&&oldStream.getVideoTracks().some(t=>t.readyState==='live')){
      video.srcObject=oldStream;
      try{await decoded(video,()=>video.srcObject===oldStream,timeoutMs);}catch{/* Existing stream was never stopped. */}
    }
    throw error;
  }finally{
    expired=true;clearTimeout(timer);unfreeze();
    if(probe){probe.pause();probe.srcObject=null;}
    if(candidate&&!committed)stop(candidate);
  }
}
