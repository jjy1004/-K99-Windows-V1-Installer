import { useCallback, useEffect, useRef, useState } from 'react';
import { garmentDisplayStatus } from './handover-display';
import { useLocation, useSearch, Redirect } from 'wouter';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import type { ActualCleaningMethod } from './inspection-record';
import { listGarments } from './garment-scanner';
import { garmentProcessStatus, loadLaundryOrder } from './laundry-process';
import { InspectionStageDesk } from './InspectionStageDesk';
import LaundryProcessWorkspace from './LaundryProcessWorkspace';
import { GarmentCaptureWorkspace } from './GarmentCaptureWorkspace';
import GarmentScannerWorkspace from './GarmentScannerWorkspace';
import { PhotoWorkspaceRoute } from './Phase8Routes';
import OrderWorkflowView from './OrderWorkflowView';
import { applyWorkflowBatch, applyWorkflowReview, persistWorkflowUpdate } from './order-workflow';
import { orderWorkspaceUrl } from './order-entry';
import { savedIntakeUrl } from './order-entry';
import { openCustomerNotice } from './notice-api';

export default function OrderWorkspace({orderId}: {orderId:string}) {
  return <><div style={{padding:'10px 24px',textAlign:'right'}}>
    <button type="button" style={{fontSize:20,padding:12}} onClick={()=>openCustomerNotice(orderId)}>고객 알림 메시지 편집·발송</button>
  </div><OrderWorkspaceContent orderId={orderId}/></>;
}
function OrderWorkspaceContent({orderId}: {orderId:string}) {
  const [,navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const work = params.get('work') ?? '';
  const garmentId = params.get('garment') ?? undefined;
  const [order,setOrder] = useState<ConfirmedOrder|null>(null);
  const [methods,setMethods] = useState<Record<number,ActualCleaningMethod>>({});
  const [error,setError] = useState('');
  const [notice,setNotice] = useState('');
  const [busy,setBusy] = useState(false);
  const working = useRef(false);
  const refresh = useCallback(() => {
    try {
      const matches = readConfirmedOrders().filter((o) => o.id === orderId);
      if (matches.length !== 1) throw new Error('이 주문번호의 원본 기록을 하나로 확인하지 못했습니다.');
      if (matches[0].garments?.some((g) => g.orderId !== orderId)) throw new Error('의류의 주문 연결을 확인해 주세요.');
      // Reuse the existing guarded one-time legacy garment migration.
      setOrder(loadLaundryOrder(orderId, { allowIntakeOverview: true })); setError('');
    } catch (cause) {
      setOrder(null); setError(cause instanceof Error ? cause.message : '주문을 불러오지 못했습니다.');
    }
  },[orderId]);
  useEffect(() => {refresh();},[refresh,work]);
  useEffect(() => {
    window.addEventListener('storage',refresh);
    window.addEventListener('focus',refresh);
    return () => {window.removeEventListener('storage',refresh);window.removeEventListener('focus',refresh);};
  },[refresh]);
  const open = (mode:string, id?:string) => {
    setError(''); setNotice('');
    navigate(orderWorkspaceUrl(orderId,mode,id));
  };
  const back = () => {refresh();navigate(orderWorkspaceUrl(orderId));};
  const save = (apply:(o:ConfirmedOrder)=>ConfirmedOrder) => {
    if (!order || working.current) return false;
    working.current = true;setBusy(true);
    try {
      setOrder(persistWorkflowUpdate(order,apply));setError('');
      setNotice('원본 주문번호와 의류별 이력을 유지하여 저장했습니다.');
      return true;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '저장하지 못했습니다. 원본은 보존했습니다.');
      // Do not silently retry a stale mutation against new data.
      try {setOrder(readConfirmedOrders().find((o)=>o.id===orderId) ?? null);} catch { /* Keep failure visible. */ }
      return false;
    } finally {working.current=false;setBusy(false);}
  };
  if (!order) return <main className="owf"><button onClick={()=>navigate('/management')}>관리센터로</button>
    <p role="alert">{error || '원본 주문을 불러오는 중입니다.'}</p><button onClick={refresh}>다시 불러오기</button></main>;
  if (garmentId && !listGarments(order).some((g)=>g.garmentId===garmentId))
    return <main className="owf"><p role="alert">이 주문에 속하지 않은 의류입니다. 작업을 중지했습니다.</p><button onClick={back}>주문 전체로</button></main>;
  const banner = <section className="owf owf-work-banner">
    <button onClick={back} data-testid="button-workspace-overview">주문 전체로</button>
    <strong>{order.customerName} · {order.totalQuantity}벌</strong>
    <p>{listGarments(order).map((g)=>`${g.itemName} ${g.sequence}번${g.tagNumber?` · 태그 ${g.tagNumber}`:''} · ${g.serviceType.includes('premium') ? '프리미엄' : '일반'}: ${garmentDisplayStatus(order,g,garmentProcessStatus(order,g))}`).join(' / ')}</p>
    {error && <p role="alert">{error}</p>}
  </section>;
  if (work === 'stages') return <InspectionStageDesk key={orderId} order={order} onSaved={setOrder}
    onBack={() => navigate('/laundry')} onCompleted={() => navigate('/scan')} />;
  if (work === 'laundry') return <LaundryProcessWorkspace orderId={orderId} onBack={back} />;
  if(work==='capture')return <Redirect to={`/equipment?orderId=${encodeURIComponent(orderId)}${garmentId?`&garmentId=${encodeURIComponent(garmentId)}`:''}`} />;
  if (work === 'photos') return <>{banner}<PhotoWorkspaceRoute orderId={orderId}
    garmentId={garmentId} onBack={back}/></>;
  if (work === 'inspection') return <Redirect to={orderWorkspaceUrl(orderId,'stages')} />;
  if (work === 'scan') return <>{banner}<GarmentScannerWorkspace initialOrderId={orderId}
    initialGarmentId={garmentId} onBack={back} onOrderChange={setOrder} onOpenCapture={(id,gid)=> {
      navigate(orderWorkspaceUrl(id,'capture',gid));
    }}/></>;
  return <OrderWorkflowView order={order} busy={busy} error={error} notice={notice}
    methods={methods} onMethod={(index,method)=>setMethods((old)=>({...old,[index]:method}))}
    onBatch={(action)=>save((o)=>applyWorkflowBatch(o,action,methods))}
    onReview={(id,stage,selected,note,resolved)=>save((o)=>applyWorkflowReview(o,id,stage,selected,note,resolved))}
    onCapture={(id)=>open(id && ['세탁 완료','완성 검수','출고 대기'].includes(
      garmentProcessStatus(order,listGarments(order).find((g)=>g.garmentId===id)!)) ? 'photos' : 'capture',id)}
    onInspection={()=>open('stages')} onScanner={()=>open('scan')}
    onBack={()=>navigate(savedIntakeUrl(orderId))} onLegacy={()=>navigate(`/laundry-process/${encodeURIComponent(orderId)}`)}/>;
}
