export const STORE_PHOTO_HELPER_FILENAME = 'K99_STORE_PHOTO_DETECT_20261009.cmd';

/** Fetch the helper as data, refusing preview/error pages masquerading as a download. */
export async function fetchStorePhotoHelper(
  url: string,
  fetchImpl: typeof fetch = fetch,
  timeoutMs = 15_000,
): Promise<Blob> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let response: Response;
    try {
      response = await fetchImpl(url, {
        method: 'GET', cache: 'no-store', credentials: 'same-origin', signal: controller.signal,
      });
    } catch {
      if (controller.signal.aborted) throw new Error('Photo Bridge 도우미 다운로드 시간이 초과되었습니다. 네트워크 연결 후 다시 시도해 주세요.');
      throw new Error('매장 Photo Bridge 도우미를 가져오지 못했습니다. 페이지 주소와 네트워크 연결을 확인해 주세요.');
    }
    if (!response.ok) {
      throw new Error(`매장 Photo Bridge 도우미 다운로드 실패 (HTTP ${response.status}). 다시 시도해 주세요.`);
    }

    let bytes: ArrayBuffer;
    try {
      bytes = await response.arrayBuffer();
    } catch {
      if (controller.signal.aborted) throw new Error('Photo Bridge 도우미 다운로드 시간이 초과되었습니다. 네트워크 연결 후 다시 시도해 주세요.');
      throw new Error('Photo Bridge 도우미 응답을 끝까지 읽지 못했습니다. 네트워크 연결 후 다시 시도해 주세요.');
    }
    if (!bytes.byteLength) {
      throw new Error('다운로드 응답이 비어 있어 Photo Bridge 도우미 파일을 저장하지 않았습니다.');
    }
    const contentType = response.headers.get('content-type') ?? '';
    const content = new TextDecoder().decode(bytes).replace(/^\uFEFF/, '');
    const prefix = content.trimStart();
    if (/text\/html/i.test(contentType) || /^<(?:!doctype\s+html|html|head|body)\b/i.test(prefix)) {
      throw new Error('다운로드 주소에서 실행 파일 대신 HTML 미리보기/오류 페이지가 반환되었습니다. 관리자에게 파일 제공 경로를 알려 주세요.');
    }
    if (!/^@echo\s+off(?:\r?\n|$)/i.test(prefix)) {
      throw new Error('다운로드 응답이 매장 최종 CMD 배치 파일 형식이 아닙니다. 파일을 저장하지 않았습니다.');
    }
    if (!/:K99_EMBEDDED_PAYLOAD(?:\r?\n|$)/i.test(content)) {
      throw new Error('다운로드 응답에 내장 Photo Bridge payload marker가 없습니다. 파일을 저장하지 않았습니다.');
    }
    return new Blob([bytes], { type: 'application/octet-stream' });
  } finally {
    clearTimeout(timer);
  }
}