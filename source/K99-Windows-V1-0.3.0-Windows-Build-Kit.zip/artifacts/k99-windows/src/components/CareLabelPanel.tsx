import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation } from 'wouter';
import { careLabelResults, type CareLabelResult } from '../care-label-client';
import { BasketPopup, type BasketPopupInfo } from './BasketPopup';
import './care-label-panel.css';

/** Staff-only advisory UI. No camera/IME/ESC/footswitch handlers are added. */
export function CareLabelPanel() {
  const [location] = useLocation();
  const native=!!window.k99Desktop;
  const [records,setRecords]=useState<CareLabelResult[]>([]);
  const [popup,setPopup]=useState<BasketPopupInfo|null>(null);
  const [selected,setSelected]=useState('');
  const [message,setMessage]=useState('');
  const [loadError,setLoadError]=useState('');
  const [busy,setBusy]=useState(false);
  const busyRef=useRef(false), first=useRef(true), seen=useRef(new Set<string>()), seq=useRef(0);
  const [hidden,setHidden]=useState(false);
  const staff=!/\/customer\/?$/.test(location);
  const load=useCallback(async()=>{
    const id=++seq.current;
    try{
      const entries=await careLabelResults();
      if(id!==seq.current)return;
      setLoadError('');
      setRecords(entries);
      for(const entry of [...entries].reverse()){
        const signature=`${entry.photoId}:${entry.completedAt||entry.status}`;
        if(!first.current&&!seen.current.has(signature)&&entry.status==='success'&&entry.basket){
          setPopup({id:signature,basketNo:entry.basket.no,basketName:`${entry.itemName} · ${entry.basket.name}`,
            basketColor:entry.basket.color,materialTag:entry.materialTag});
          setHidden(false);
        }
        seen.current.add(signature);
      }
      first.current=false;
    }catch{if(id===seq.current)setLoadError('케어라벨 결과 조회 실패 · 기존 접수와 기본 태그 출력은 계속 사용할 수 있습니다.');}
  },[]);
  useEffect(()=>{
    if(!native||!staff)return;
    void load();
    const off=window.k99Desktop?.onChanged?.(()=>void load());
    const timer=window.setInterval(()=>void load(),3000);
    return()=>{off?.();window.clearInterval(timer);seq.current++;};
  },[native,staff,load]);
  const entry=records.find(r=>r.id===selected)||records[0];
  const pending=entry?.status==='pending';
  async function reanalyze(){
    if(!entry||busyRef.current)return;
    busyRef.current=true;setBusy(true);setMessage('');
    try{
      if(!window.k99Desktop?.analyzeCareLabel)throw Error('케어라벨 IPC가 없습니다.');
      await window.k99Desktop.analyzeCareLabel(entry.photoId);await load();
    }
    catch{setMessage('다시 분석하지 못했습니다. 소재: 일반으로 접수를 계속할 수 있습니다.');}
    finally{busyRef.current=false;setBusy(false);}
  }
  if(!native||!staff)return null;
  if(!entry)return loadError?<aside className="k99-care-panel" role="status">{loadError}</aside>:null;
  return <>
    {!hidden?<aside className="k99-care-panel" aria-label="케어라벨 분석 결과">
      <div><strong>케어라벨 AI · 직원 확인용</strong><button type="button" onClick={()=>setHidden(true)} aria-label="분석 안내 접기">접기</button></div>
      <select aria-label="분석한 의류 사진 선택" value={entry.id} onChange={e=>{setSelected(e.target.value);setMessage('');}}>
        {records.map(r=><option key={r.id} value={r.id}>{r.itemName} · {r.unitKey} · {new Date(r.createdAt).toLocaleTimeString('ko-KR')} · {r.status==='success'?'분석 완료':r.status==='pending'?'분석 중':'확인 필요'}</option>)}
      </select>
      <p role="status">{pending?'사진 저장 완료 · 케어라벨 분석 중 (접수는 계속할 수 있습니다)':`소재: ${entry.materialTag||'일반'}${entry.basket?` · ${entry.basket.no} ${entry.basket.name}`:''}`}</p>
      {entry.error&&<p className="k99-care-panel__warning">{entry.error}</p>}
      {loadError&&<p className="k99-care-panel__warning">{loadError}</p>}
      {entry.status==='interrupted'&&<p>이전 분석이 중단되었습니다. 필요하면 다시 분석하세요.</p>}
      {entry.raw_composition&&<small>라벨 원문: {entry.raw_composition}</small>}
      <div>
        <button type="button" onClick={()=>void reanalyze()} disabled={busy||pending||entry.status==='success'}>다시 분석</button>
        <span role="status" data-testid="status-automatic-material-tag">
          {entry.autoTag?.isTagPrinted?`태그 자동 제출 완료 · 소재: ${entry.autoTag.materialTag||'일반'} · 실물 확인 필요`
            :['failed','unknown','submitting'].includes(entry.autoTag?.status||'')?`태그 ${entry.autoTag?.status} · ${entry.autoTag?.error||'실물과 장비 이력을 확인하세요.'}`
              :'분석 완료 시 태그 자동 발행'}</span>
      </div>
      <small>의류별 최초 태그 1회 자동 발행 · 라벨 생략 시 다음 의류 촬영 또는 접수 마감에 불명확으로 발행합니다.</small>
      {message&&<p role="status">{message}</p>}
    </aside>:<button className="k99-care-panel__reopen" type="button" onClick={()=>setHidden(false)}>케어라벨 분석 결과 보기</button>}
    <BasketPopup info={popup} onClose={()=>setPopup(null)} />
  </>;
}
