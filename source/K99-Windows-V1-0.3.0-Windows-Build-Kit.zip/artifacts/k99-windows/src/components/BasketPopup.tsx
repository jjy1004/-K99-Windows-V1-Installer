import { useEffect, useRef } from 'react';
import './basket-popup.css';

export interface BasketPopupInfo {
  id: string;
  basketNo: string;
  basketName: string;
  basketColor: string;
  materialTag: string;
}

interface BasketPopupProps {
  info: BasketPopupInfo | null;
  onClose: () => void;
}

const DISMISS_MS = 3500;

export function BasketPopup({ info, onClose }: BasketPopupProps) {
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const id = info?.id ?? null;

  useEffect(() => {
    if (id === null) return;
    const timer = window.setTimeout(() => onCloseRef.current(), DISMISS_MS);
    return () => window.clearTimeout(timer);
  }, [id]);

  const open = info !== null;
  const material = info?.materialTag?.trim() || '일반';

  return (
    <div
      className="k99-basket-popup"
      data-open={open ? 'true' : 'false'}
      role="status"
      aria-live="polite"
      aria-atomic="true"
      data-testid="status-basket-popup"
      onPointerDown={open ? (e) => { e.preventDefault(); onCloseRef.current(); } : undefined}
    >
      {info && (
        <div key={info.id} className="k99-basket-popup__card" style={{ background: info.basketColor }}>
          <p className="k99-basket-popup__notice">AI 안내 · 세탁 전 직원 확인 필요</p>
          <p className="k99-basket-popup__label">바구니</p>
          <strong className="k99-basket-popup__number" data-testid="text-basket-no">{info.basketNo}</strong>
          <span className="k99-basket-popup__name" data-testid="text-basket-name">{info.basketName}</span>
          <div>
            <p className="k99-basket-popup__material" data-testid="text-basket-material">
              <span>소재</span>{material}
            </p>
          </div>
          <p className="k99-basket-popup__hint">화면을 누르면 바로 닫힙니다</p>
          <div className="k99-basket-popup__timer" aria-hidden="true" />
        </div>
      )}
    </div>
  );
}
