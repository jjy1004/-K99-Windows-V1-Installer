import {useEffect,useState} from 'react';
import {nativePhotoSource,analyzeLoadedCareLabel,type NativePhotoInput,type NativePhotoSource} from '../native-photo-client';
export function LocalGarmentPhoto({photoId,pathHint,orderId,garmentId,alt,className}:
  NativePhotoInput&{alt:string;className?:string}){
  const [source,setSource]=useState<NativePhotoSource|null>(null),[error,setError]=useState(''),[retry,setRetry]=useState(0);
  const [analysisError,setAnalysisError]=useState('');
  useEffect(()=>{
    let alive=true;setSource(null);setError('');setAnalysisError('');
    nativePhotoSource({photoId,pathHint,orderId,garmentId}).then(s=>{if(alive)setSource(s);})
      .catch(e=>{if(alive)setError(e instanceof Error?e.message:'사진 연결 실패');});
    return()=>{alive=false;};
  },[photoId,pathHint,orderId,garmentId,retry]);
  return <span className="native-local-photo">
    {source&&!error?<img key={source.url} className={className} src={source.url} alt={alt}
      onLoad={()=>{void analyzeLoadedCareLabel(source).catch(e=>setAnalysisError(e instanceof Error?e.message:'중앙 분석 연결 실패'));}}
      onError={()=>setError('등록된 사진을 읽지 못했습니다. 원본 파일·드라이브·접근 권한을 확인하세요.')} />
      :<span role="status">{error||'사진 원본 연결 중…'}{error&&<button type="button" onClick={()=>setRetry(n=>n+1)}>사진 다시 읽기</button>}</span>}
    {analysisError&&<small role="status">사진 로드 완료 · {analysisError}</small>}
  </span>;
}
