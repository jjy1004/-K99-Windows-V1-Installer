import type { ConfirmedOrder } from './order-record';
import {
  completeInspection, INSPECTION_FIELDS, type ActualCleaningMethod, type CustomerDecision, type FieldConsentRecord,
  type InspectionDraft, type InspectionField, type InspectionRating,
} from './inspection-record';
import { reviewClassification } from './item-intake-details';

export type FieldItemResult = '이상 없음' | '주의 필요';
export type FieldItemReview = { method?: ActualCleaningMethod; result?: FieldItemResult; confirmed: boolean; memo: string };
export type FieldReviewNeed = { index: number; reasons: string[]; needsMethod: boolean };
export function defaultFieldReview(order: ConfirmedOrder, index: number): FieldItemReview {
  return { method: order.items[index]?.plannedCleaningMethod ?? '물세탁', result: '이상 없음', confirmed: true, memo: '' };
}

/** Items that must be individually reviewed by staff before the field inspection can be recorded. */
export function fieldReviewNeeds(order: ConfirmedOrder): FieldReviewNeed[] {
  return order.items.flatMap((item, index) => {
    const reasons: string[] = [];
    if (item.intakeDetails) {
      const c = reviewClassification(item.itemId, item.intakeDetails);
      if (c.requiresReview) reasons.push(...(c.reasons.length ? c.reasons : ['직원 확인 필요 표시']));
    }
    if (!item.isSneaker && order.choices.serviceLevel === 'premium') reasons.push('프리미엄 세탁');
    const needsMethod = !item.isSneaker && !item.plannedCleaningMethod;
    if (needsMethod) reasons.push('세탁 방법 미지정');
    return reasons.length ? [{ index, reasons, needsMethod }] : [];
  });
}

const checks = (rating: InspectionRating) =>
  Object.fromEntries(INSPECTION_FIELDS.map((f) => [f, rating])) as Record<InspectionField, InspectionRating>;

/** New field reviews start WET/NORMAL/confirmed; explicit edits and existing planned methods win. */
export function buildFieldInspectionDraft(order: ConfirmedOrder, reviews: Record<number, FieldItemReview>): InspectionDraft {
  const needs = new Map(fieldReviewNeeds(order).map((n) => [n.index, n]));
  const changedNotes: string[] = [];
  const items = order.items.map((item, index) => {
    const need = needs.get(index);
    const review = { ...defaultFieldReview(order, index), ...reviews[index] };
    if (need) {
      if (!review?.confirmed) throw new Error(`${item.displayNameKo}: 실물을 확인한 뒤 '확인함'을 눌러 주세요.`);
      if (!review.result) throw new Error(`${item.displayNameKo}: 검수 결과(이상 없음/주의 필요)를 선택해 주세요.`);
      if (review.result === '주의 필요' && !review.memo.trim()) throw new Error(`${item.displayNameKo}: 주의 내용을 메모에 적어 주세요.`);
    }
    const actual = item.isSneaker ? undefined : review?.method ?? item.plannedCleaningMethod ?? '물세탁';
    if (!item.isSneaker && !actual) throw new Error(`${item.displayNameKo}: 세탁 방법을 선택해 주세요.`);
    const changed = !item.isSneaker && !!item.plannedCleaningMethod && actual !== item.plannedCleaningMethod;
    const memo = review?.memo.trim() ?? '';
    if (changed) changedNotes.push(`${item.displayNameKo} ${item.plannedCleaningMethod} → ${actual}`);
    return {
      index, itemId: item.itemId,
      checks: checks(review?.result === '주의 필요' ? '주의' : '정상'),
      ...(item.plannedCleaningMethod ? { plannedCleaningMethod: item.plannedCleaningMethod } : {}),
      ...(actual ? { actualCleaningMethod: actual } : {}),
      memo, method: '기존 방법 유지' as const, customMethod: '', additionalWork: ['추가 작업 없음' as const], additionalWorkDescription: '',
      ...(changed ? { methodChangeReason: memo || '현장 검수에서 세탁 방법 변경', riskDetails: memo || '현장 검수에서 세탁 방법 변경' } : {}),
    };
  });
  return {
    items,
    // Staff-typed final total stays authoritative; inspection never recalculates it.
    revisedPrice: order.estimatedTotal, additionalCharge: 0,
    riskRequired: false, riskNotice: changedNotes.length ? `세탁 방법 변경: ${changedNotes.join(', ')}` : '',
    waiverRequired: false, waiverNotice: '',
  };
}

export function completeFieldInspection(order: ConfirmedOrder, reviews: Record<number, FieldItemReview>, at = new Date()) {
  return completeInspection(order, buildFieldInspectionDraft(order, reviews), at);
}

/** Every acknowledgement the existing approval requirements would need, mapped from one explicit yes. */
export function requiredAcknowledgements(order: ConfirmedOrder): CustomerDecision[] {
  const r = order.inspection?.approvalRequirements;
  const fromNotice: CustomerDecision[] = order.processNotice
    ? [...(order.processNotice.kind !== 'fee' ? ['위험 안내 확인', '면책 동의'] as CustomerDecision[] : []),
       ...(order.processNotice.kind !== 'waiver' && order.processNotice.technicalFee > 0 ? ['추가요금 동의'] as CustomerDecision[] : [])] : [];
  const base: CustomerDecision[] = r ? [
    ...(r.method ? ['변경 세탁방법 동의'] as const : []), ...(r.price ? ['추가요금 동의'] as const : []),
    ...(r.risk ? ['위험 안내 확인'] as const : []), ...(r.waiver ? ['면책 동의'] as const : []),
  ] : [];
  return [...new Set<CustomerDecision>([...base, ...fromNotice, '전체 진행 동의'])];
}

export function fieldConsentPending(order: ConfirmedOrder): boolean {
  return !!order.inspection?.needsApproval && order.status !== '세탁 진행 승인';
}

/**
 * Records ONE explicit staff selection (동의 완료 / 미동의) with the exact notice text. Prior staged/item-notice
 * records and responses are kept verbatim; only status changes and an append-only record is added.
 */
export function recordFieldConsent(order: ConfirmedOrder, input: { consent: '동의 완료' | '미동의' | null | undefined; message: string; staff?: string }, at = new Date()): ConfirmedOrder {
  if (!order.inspection) throw new Error('검수 기록이 없는 주문입니다.');
  if (!fieldConsentPending(order)) throw new Error('고객 동의가 필요한 주문이 아니거나 이미 승인되었습니다.');
  if (order.operations?.cancelledAt) throw new Error('취소된 주문입니다.');
  if (input.consent !== '동의 완료' && input.consent !== '미동의') throw new Error('동의 완료 또는 미동의를 직접 선택해 주세요.');
  const message = input.message.trim();
  if (!message) throw new Error('고객에게 안내한 문안을 입력해 주세요.');
  const staff = (input.staff ?? '매장 직원').trim() || '매장 직원';
  const recordedAt = at.toISOString();
  const yes = input.consent === '동의 완료';
  const record: FieldConsentRecord = {
    mode: 'field-simplified', consent: input.consent, message, recordedAt, recordedBy: staff,
    staffAssertion: yes ? '매장 직원이 위 안내에 대한 고객의 동의를 직접 확인했다고 기록함' : '매장 직원이 고객의 미동의를 직접 확인했다고 기록함',
    acknowledged: yes ? requiredAcknowledgements(order) : [], previousStatus: order.status ?? '',
    actuallySent: false, customerSignature: false,
  };
  record.noticeFee = noticeFeeOf(order);
  const status = yes ? '세탁 진행 승인' : '세탁 진행 거절';
  const next: ConfirmedOrder = {
    ...order, status,
    inspection: { ...order.inspection, fieldConsents: [...(order.inspection.fieldConsents ?? []), record] },
    history: [...(order.history ?? []),
      { at: recordedAt, kind: 'customer-consent', details: { ...record } },
      { at: recordedAt, kind: 'approval-status', details: { status, mode: 'field-simplified', staffName: staff } }],
  };
  return yes ? applyApprovedNoticeFee(next, record) : next;
}

/** Technical fee carried by the saved notice (0 for waiver-only or no notice). */
export function noticeFeeOf(order: ConfirmedOrder): number {
  const n = order.processNotice;
  return n && n.kind !== 'waiver' && Number.isSafeInteger(n.technicalFee) && n.technicalFee > 0 ? n.technicalFee : 0;
}

/**
 * Sets totals to immutable base + approved notice fee. Re-approval replaces the previous fee, never stacks.
 * Only called after an explicit 동의 완료 record.
 */
export function applyApprovedNoticeFee(order: ConfirmedOrder, consent: FieldConsentRecord): ConfirmedOrder {
  if (consent.consent !== '동의 완료') throw new Error('동의 완료 기록이 있어야 추가 기술료를 반영할 수 있습니다.');
  const fee = consent.noticeFee ?? 0;
  const prev = order.feeAdjustment;
  if (!prev && fee === 0) return order;
  const baseEstimatedTotal = prev?.baseEstimatedTotal ?? order.estimatedTotal;
  const baseLaundryTotal = prev?.baseLaundryTotal ?? order.laundryTotal;
  const estimatedTotal = baseEstimatedTotal + fee;
  const laundryTotal = baseLaundryTotal + fee;
  return {
    ...order, estimatedTotal, laundryTotal,
    feeAdjustment: {
      baseEstimatedTotal, baseLaundryTotal,
      baseChoices: prev?.baseChoices ?? { totalOverride: order.choices.totalOverride, computedLaundryTotal: order.choices.computedLaundryTotal },
      approvedFee: fee, approvedAt: consent.recordedAt, consentRecordedAt: consent.recordedAt, message: consent.message,
      history: [...(prev?.history ?? []), { at: consent.recordedAt, previousFee: prev?.approvedFee ?? 0, approvedFee: fee, estimatedTotal, consentRecordedAt: consent.recordedAt }],
    },
    history: [...(order.history ?? []), { at: consent.recordedAt, kind: 'price-change', details: {
      mode: 'notice-fee-approved', baseEstimatedTotal, previousFee: prev?.approvedFee ?? 0, approvedFee: fee,
      estimatedTotal, laundryTotal, consentRecordedAt: consent.recordedAt } }],
  };
}

/**
 * Fee consent for orders already approved (work may be in progress). Appends a new consent record;
 * never rewrites earlier consents, status or garment progress.
 */
export function recordFeeConsent(order: ConfirmedOrder, input: { consent: '동의 완료' | '미동의' | null | undefined; message: string; staff?: string }, at = new Date()): ConfirmedOrder {
  if (fieldConsentPending(order)) throw new Error('먼저 세탁 진행 동의를 기록해 주세요.');
  if (order.operations?.cancelledAt) throw new Error('취소된 주문입니다.');
  if (input.consent !== '동의 완료' && input.consent !== '미동의') throw new Error('동의 완료 또는 미동의를 직접 선택해 주세요.');
  const message = input.message.trim();
  if (!message) throw new Error('고객에게 안내한 문안을 입력해 주세요.');
  const fee = noticeFeeOf(order);
  if (fee === 0 && !order.feeAdjustment) throw new Error('추가 기술료가 있는 안내 문안을 먼저 저장해 주세요.');
  const staff = (input.staff ?? '매장 직원').trim() || '매장 직원';
  const recordedAt = at.toISOString();
  const yes = input.consent === '동의 완료';
  const record: FieldConsentRecord = {
    mode: 'field-fee', noticeFee: fee, consent: input.consent, message, recordedAt, recordedBy: staff,
    staffAssertion: yes ? '매장 직원이 추가 기술료에 대한 고객의 동의를 직접 확인했다고 기록함' : '매장 직원이 추가 기술료 미동의를 직접 확인했다고 기록함',
    acknowledged: yes ? ['추가요금 동의'] : [], previousStatus: order.status ?? '', actuallySent: false, customerSignature: false,
  };
  const inspection = order.inspection ? { ...order.inspection, fieldConsents: [...(order.inspection.fieldConsents ?? []), record] } : order.inspection;
  const next: ConfirmedOrder = { ...order, ...(inspection ? { inspection } : {}),
    history: [...(order.history ?? []), { at: recordedAt, kind: 'customer-consent', details: { ...record } }] };
  return yes ? applyApprovedNoticeFee(next, record) : next;
}
