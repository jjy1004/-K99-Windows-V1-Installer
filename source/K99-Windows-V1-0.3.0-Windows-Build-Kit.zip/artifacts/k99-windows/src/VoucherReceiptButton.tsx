import { useState } from 'react';
import { ReceiptText } from 'lucide-react';
import type { VoucherReceipt } from './vouchers';
import { directoryRequest } from './customer-directory-client';

const isReceipt = (v: Record<string, unknown>): v is VoucherReceipt & Record<string, unknown> =>
  typeof v.id === 'string' && typeof v.plan === 'string' && typeof v.label === 'string'
  && Number.isSafeInteger(v.balanceAfter) && Number.isSafeInteger(v.paidAmount) && typeof v.createdAt === 'string';

/** 현재 고객의 최신 정액권 영수증을 찾아 기존 영수증 출력창으로 넘긴다. */
export function VoucherReceiptButton({ customerId, onReceipt }: { customerId: string; onReceipt: (r: VoucherReceipt,items:{name:string;quantity:number;amount:number}[]) => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const run = async () => {
    if (!customerId || busy) return;
    setBusy(true); setError('');
    try {
      const {receipt,items}=await directoryRequest<{receipt:VoucherReceipt;items:{name:string;quantity:number;amount:number}[]}>('GET','/api/vouchers/receipt?customerId='+encodeURIComponent(customerId));
      if (!isReceipt(receipt as unknown as Record<string,unknown>)) throw Error('정액권 영수증을 확인하지 못했습니다.');
      onReceipt(receipt,items);
    } catch (e) { setError(e instanceof Error ? e.message : '정액권 영수증을 불러오지 못했습니다.'); }
    finally { setBusy(false); }
  };
  return <div className="k99-receipt-half">
    <button type="button" className="k99-receipt-button" disabled={!customerId || busy} onClick={() => void run()}
      title={!customerId ? '고객을 먼저 선택하세요.' : undefined} data-testid="button-open-voucher-receipt">
      <ReceiptText aria-hidden="true" />{busy ? '불러오는 중…' : '정액권 영수증 출력'}</button>
    {error && <p className="voucher-warn" role="alert" data-testid="text-voucher-receipt-error">{error}</p>}
  </div>;
}
