import type { ConfirmedOrder } from './order-record';
import type { InspectionDraft } from './inspection-record';
import { careNoticeTemplate } from './care-notice-templates';

export type GuidanceKind = 'waiver' | 'fee' | 'both';
export const GUIDANCE_LABELS: Record<GuidanceKind, string> = {
  waiver: '면책동의', fee: '추가 기술료', both: '면책동의 + 추가 기술료',
};
export function guidanceMessage(order: ConfirmedOrder, draft: InspectionDraft, indexes?: number[]) {
  const names = draft.feeItemName?.trim() || (indexes?.length ? indexes : order.items.map((_, i) => i))
    .map(i => order.items[i]?.displayNameKo).filter(Boolean).join('·');
  return careNoticeTemplate(draft.guidanceKind ?? 'both', order.customerName, names, draft.additionalCharge ?? 0);
}
