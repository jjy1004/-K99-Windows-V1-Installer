import type { ConfirmedOrder } from './order-record';
import type { InspectionDraft } from './inspection-record';

export type GuidanceKind = 'waiver' | 'fee' | 'both';
export const GUIDANCE_LABELS: Record<GuidanceKind, string> = {
  waiver: '면책동의', fee: '추가 기술료', both: '면책동의 + 추가 기술료',
};
export function guidanceMessage(order: ConfirmedOrder, draft: InspectionDraft, indexes?: number[]) {
  const names = draft.feeItemName?.trim() || (indexes?.length ? indexes : order.items.map((_, i) => i))
    .map(i => order.items[i]?.displayNameKo).filter(Boolean).join('·');
  const risk = draft.riskNotice.trim() || '[직원이 입력한 위험 내용]';
  const work = draft.guidanceWorkDescription?.trim() || draft.items.map(i => i.additionalWorkDescription.trim()
    || i.additionalWork.filter(w => w !== '추가 작업 없음').join('·')).filter(Boolean).join(' / ') || '[직원이 입력한 추가 작업 내용]';
  const money = (n: number) => `${n.toLocaleString('ko-KR')}원`;
  const fee = draft.additionalCharge ?? 0;
  const prices = ['■ 세탁비 안내', `기존 세탁비: ${money(order.estimatedTotal)}`,
    `추가 기술료: ${money(fee)}`, `최종 예상 세탁비: ${money(order.estimatedTotal + fee)}`].join('\n');
  if (draft.guidanceKind === 'waiver') return [
    '[K99 품격세탁소]', '', `고객님께서 의뢰하신 ${names}의 정밀 검수 결과, 세탁 과정에서 주의가 필요한 사항이 확인되었습니다.`,
    '', '■ 예상 위험 사항', risk, '',
    'K99는 세탁물의 소재와 상태를 고려하여 위험을 최소화하도록 세탁하겠습니다. 다만 안내드린 변색·이염·수축·형태 변형 등의 위험은 완전히 방지하기 어려울 수 있습니다.',
    '', "위 내용을 확인하고 세탁 진행에 동의하시면 '동의합니다'라고 회신해 주시기 바랍니다.",
    '', '고객님의 동의를 확인한 후 작업을 진행하겠습니다.',
  ].join('\n');
  if (draft.guidanceKind === 'fee') return [
    '[K99 품격세탁소]', '', `고객님께서 의뢰하신 ${names}의 정밀 검수 결과, 추가 작업이 필요한 것으로 확인되었습니다.`,
    '', '■ 추가 작업 내용', work, '', prices, '',
    "추가 작업과 변경된 금액에 동의하시면 '동의합니다'라고 회신해 주시기 바랍니다.",
    '', '고객님의 동의를 확인한 후 추가 작업을 진행하겠습니다.',
  ].join('\n');
  return [
    '[K99 품격세탁소]', '', `고객님께서 의뢰하신 ${names}의 정밀 검수 결과, 세탁 과정의 위험 사항과 추가 작업 필요성이 함께 확인되었습니다.`,
    '', '■ 예상 위험 사항', risk, '', '■ 추가 작업 내용', work, '', prices, '',
    'K99는 세탁물의 손상을 최소화하도록 작업하겠습니다. 다만 안내드린 위험은 완전히 방지하기 어려울 수 있습니다.',
    '', "위험 사항과 추가 세탁비를 모두 확인하고 동의하시면 '동의합니다'라고 회신해 주시기 바랍니다.",
    '', '고객님의 동의를 확인한 후 작업을 진행하겠습니다.',
  ].join('\n');
}
