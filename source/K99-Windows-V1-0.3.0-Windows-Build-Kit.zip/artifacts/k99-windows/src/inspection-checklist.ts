import { INSPECTION_FIELDS, type InspectionDraft, type InspectionItem } from './inspection-record.ts';

function fillUnselectedItem(item: InspectionItem): InspectionItem {
  const checks = { ...item.checks };
  for (const field of INSPECTION_FIELDS) {
    if (!checks[field]) checks[field] = '정상';
  }
  return { ...item, checks };
}

export function fillUnselectedInspectionChecks(draft: InspectionDraft, index?: number): InspectionDraft {
  return {
    ...draft,
    items: draft.items.map((item, itemIndex) =>
      index === undefined || itemIndex === index ? fillUnselectedItem(item) : item),
  };
}