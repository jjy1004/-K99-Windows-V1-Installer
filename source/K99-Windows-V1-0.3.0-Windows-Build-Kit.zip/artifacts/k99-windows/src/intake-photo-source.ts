import type { GarmentRecord } from './garment-record';
import type { PhotoSourceItem } from './photo-source';

/** Read-only identity resolution; never guesses from a basename or captures/reassigns images. */
export function intakePhotoSourceId(item: GarmentRecord, recent: PhotoSourceItem[] = []): string | null {
  const before = item.beforePhoto;
  if (before?.status === 'saved' && before.origin === 'bridge' &&
      before.garmentId === item.garmentId && before.sourcePhotoId) return before.sourcePhotoId;
  if (item.photoStatus !== 'saved' || !item.photoPath || !item.photoTimestamp) return null;
  return recent.find(photo => photo.origin === 'bridge' &&
    photo.sourcePath === item.photoPath && photo.timestamp === item.photoTimestamp)?.id ?? null;
}
