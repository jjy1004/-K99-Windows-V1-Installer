/** Pure geometry helpers for Before/After markings. All shape coordinates are normalized (0..1) to the image itself. */
export type MarkKind = 'circle' | 'rect';
export type MarkColor = 'red' | 'blue';
export type Corner = 'nw' | 'ne' | 'sw' | 'se';
export type Mark = { id: string; kind: MarkKind; color: MarkColor; x: number; y: number; w: number; h: number };
export type Box = { x: number; y: number; w: number; h: number };
export type Pt = { x: number; y: number };

export const MIN_MARK = 0.02;
export const MARK_HEX: Record<MarkColor, string> = { red: '#e0322b', blue: '#1f63d6' };

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Rect where an image of iw×ih is drawn with object-fit: contain inside box. */
export function containRect(iw: number, ih: number, box: Box): Box {
  if (!(iw > 0 && ih > 0 && box.w > 0 && box.h > 0)) return { x: box.x, y: box.y, w: 0, h: 0 };
  const s = Math.min(box.w / iw, box.h / ih);
  const w = iw * s, h = ih * s;
  return { x: box.x + (box.w - w) / 2, y: box.y + (box.h - h) / 2, w, h };
}

/** Full-bleed centered image transform shared by editor, composite preview and JPEG. */
export function coverRect(iw:number,ih:number,box:Box):Box{
  if(!(iw>0&&ih>0&&box.w>0&&box.h>0))return {x:box.x,y:box.y,w:0,h:0};
  const scale=Math.max(box.w/iw,box.h/ih),w=iw*scale,h=ih*scale;
  return {x:box.x+(box.w-w)/2,y:box.y+(box.h-h)/2,w,h};
}

/** Screen/canvas point → normalized image point (clamped). */
export function toNormalized(p: Pt, area: Box): Pt {
  if (!area.w || !area.h) return { x: 0, y: 0 };
  return { x: clamp01((p.x - area.x) / area.w), y: clamp01((p.y - area.y) / area.h) };
}

/** Normalized mark → absolute rect in the given contain area (same transform for editor, preview and JPEG). */
export function toAreaRect(m: Pick<Mark, 'x' | 'y' | 'w' | 'h'>, area: Box): Box {
  return { x: area.x + m.x * area.w, y: area.y + m.y * area.h, w: m.w * area.w, h: m.h * area.h };
}

export function rectFromPoints(a: Pt, b: Pt): Box {
  const x1 = clamp01(Math.min(a.x, b.x)), y1 = clamp01(Math.min(a.y, b.y));
  const x2 = clamp01(Math.max(a.x, b.x)), y2 = clamp01(Math.max(a.y, b.y));
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

export function moveMark<T extends Box>(m: T, dx: number, dy: number): T {
  return { ...m, x: Math.min(1 - m.w, Math.max(0, m.x + dx)), y: Math.min(1 - m.h, Math.max(0, m.y + dy)) };
}

export function oppositeCorner(m: Box, c: Corner): Pt {
  return { x: c === 'nw' || c === 'sw' ? m.x + m.w : m.x, y: c === 'nw' || c === 'ne' ? m.y + m.h : m.y };
}

export function resizeMark<T extends Box>(m: T, corner: Corner, p: Pt): T {
  return { ...m, ...rectFromPoints(oppositeCorner(m, corner), p) };
}

export const isUsableMark = (b: Box) => b.w >= MIN_MARK && b.h >= MIN_MARK;

/** Fixed readable 3–4px outline in the exported image; never fill the stain. */
export const strokeFor = (area: Box) => Math.min(4, Math.max(3, Math.round(Math.min(area.w, area.h) / 140)));

export function drawMarks(g: CanvasRenderingContext2D, marks: Mark[], area: Box) {
  const lw = strokeFor(area);
  for (const m of marks) {
    const r = toAreaRect(m, area);
    g.save(); g.lineWidth = lw; g.strokeStyle = MARK_HEX[m.color]; g.beginPath();
    if (m.kind === 'circle') g.ellipse(r.x + r.w / 2, r.y + r.h / 2, Math.max(1, r.w / 2), Math.max(1, r.h / 2), 0, 0, Math.PI * 2);
    else g.rect(r.x, r.y, r.w, r.h);
    g.stroke(); g.restore();
  }
}
