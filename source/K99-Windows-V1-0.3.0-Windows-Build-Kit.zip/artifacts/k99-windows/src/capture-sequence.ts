import type { GarmentRecord } from './garment-record';

/** Select another uncaptured garment, never depend on printer acknowledgement. */
export function nextUncapturedGarmentIndex(garments: GarmentRecord[], from: number): number {
  for (let offset = 1; offset < garments.length; offset++) {
    const index = (from + offset) % garments.length;
    if (!['saved','simulated'].includes(garments[index].photoStatus)) return index;
  }
  return -1;
}
