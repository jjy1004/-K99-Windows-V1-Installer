/** Decode validation, not auto exposure/colour control. Never inspect RGB. */
export async function showCameraVideo(video:HTMLVideoElement,stream:MediaStream,timeoutMs=5000){
  video.hidden=false;video.muted=true;video.autoplay=true;video.playsInline=true;video.srcObject=stream;
  let interval:ReturnType<typeof setInterval>|undefined,timer:ReturnType<typeof setTimeout>|undefined;
  try{
    await new Promise<void>((resolve,reject)=>{
      const check=()=>{
        if(video.srcObject!==stream)reject(Error('카메라 연결이 취소되었습니다.'));
        else if(video.readyState>=2&&video.videoWidth>0&&video.videoHeight>0)resolve();
      };
      interval=setInterval(check,25);
      timer=setTimeout(()=>reject(Error('카메라에서 영상 프레임을 받지 못했습니다. USB 연결과 다른 앱의 점유를 확인하세요.')),timeoutMs);
      try{Promise.resolve(video.play()).then(check,reject);}catch(error){reject(error);}
      queueMicrotask(check);
    });
  }finally{clearInterval(interval);clearTimeout(timer);}
}
export async function inspectCameraStream(stream:MediaStream){
  if(typeof document==='undefined')return; // Node tests inject their own decoder.
  const video=document.createElement('video');
  try{await showCameraVideo(video,stream);}
  finally{video.pause();video.srcObject=null;}
}
