/** 모바일 글은 기존 본문을 지우지 않는다. DOM 커서는 UTF-16 위치이므로 slice와 같은 좌표다. */
export function appendMobileNotice(body:string,incoming:string,cursor:number|null=null){
  if(!incoming.trim())return {body,cursor:cursor??body.length};
  const at=cursor===null?body.length:Math.max(0,Math.min(body.length,cursor));
  const left=body.slice(0,at),right=body.slice(at);
  const added=(left&&!left.endsWith('\n')?'\n':'')+incoming+(right&&!right.startsWith('\n')?'\n':'');
  const next=left+added+right;
  if(next.length>12000)throw Error('휴대폰 글을 더하면 12,000자를 넘습니다. 보낼 글을 줄이면 다시 받아 추가합니다. 휴대폰 원문은 저장되어 있습니다.');
  return {body:next,cursor:at+added.length};
}
