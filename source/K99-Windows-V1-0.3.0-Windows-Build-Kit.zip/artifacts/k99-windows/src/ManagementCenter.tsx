import { ImeTextInput } from './ImeTextInput';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import { AdminTagDiagnostics } from './AdminTagDiagnostics';
import { ArrowLeft, ArrowRight, Camera, ClipboardList, RefreshCw, ScanLine, Search, Shirt } from 'lucide-react';
import {
  customerManagementProfile, managementSummary, periodComparison, managementOrdersByDate, managementIntakeDate,
  searchManagementCustomers, uncollectedGarments,
  type ManagementCustomerSearchResult, type ManagementPeriodMode, type ManagementMetrics,
} from './management-data';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import { getHardwareStatus } from './local-bridge';
import { koreaCalendarDate } from './storage-policy';
import { activePhotosOf } from './manual-photo-link';
import type { GarmentPhotoMetadata, GarmentRecord } from './garment-record';
import { loadPhotoPreview } from './photo-source';
import './management-center.css';

export type ManagementCenterProps = {
  onBack: () => void;
  onNewIntake: () => void;
  onOpenOrder: (id: string) => void;
  onOpenLaundry: (id: string) => void;
  onOpenScanner: () => void;
  onOpenCapture: (orderId: string, garmentId?: string) => void;
  onOpenPhoto: (orderId: string, garmentId: string) => void;
  onOpenOperations: () => void;
  onOpenToday: () => void;
  onOpenStoreTest: () => void;
  onOpenPhotoSettings?: () => void;
};

type Tab = 'overview' | 'uncollected';
type Hardware = Record<string, unknown> | null;
const waiting = '기록 미확인';
const won = (value: number | null | undefined) => value == null || !Number.isFinite(value)
  ? waiting : `${Math.round(value).toLocaleString('ko-KR')}원`;
const count = (value: number | null | undefined, suffix = '건') => value == null || !Number.isFinite(value)
  ? waiting : `${value.toLocaleString('ko-KR')}${suffix}`;
const text = (value: unknown) => typeof value === 'string' && value.trim() ? value : waiting;
const date = (value: string | null | undefined) => {
  if (!value) return waiting;
  if (/^\d{4}-\d{2}-\d{2}$/.test(value) && managementIntakeDate(value)) return `${value} · 시각 기록 없음`;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? waiting : parsed.toLocaleString('ko-KR', {
    timeZone: 'Asia/Seoul', dateStyle: 'medium', timeStyle: 'medium', hour12: false,
  });
};
const workflow = (value: string | undefined, before: string, active: string, complete: string) =>
  value === 'complete' ? complete : value === 'in-progress' ? active : value === 'pending' ? before : '기록 없음';
const tagLabel = (garment: GarmentRecord) => {
  const job = garment.photoBridgeReprintRequestId ? garment.photoBridgeReprintStatus : garment.photoBridgeAutoTagStatus;
  if (job === 'submitted') return '출력 요청 전달됨 · 실물 확인 필요';
  if (job === 'pending') return '출력 요청 중';
  if (job === 'failed' || job === 'unknown') return '출력 확인 필요';
  return garment.tagStatus === 'printed' ? '저장된 출력 기록 있음 · 실물 확인'
    : garment.tagStatus === 'generated' ? '태그 생성 기록 있음'
      : garment.tagStatus === 'print-requested' ? '출력 요청 기록 있음'
        : garment.tagStatus === 'failed' ? '출력 실패 기록 있음'
          : garment.tagStatus === 'simulated' ? '실물 출력 기록 없음'
            : garment.tagStatus === 'not-generated' ? '태그 생성 전' : '기록 없음';
};
const message = (cause: unknown) => cause instanceof Error ? cause.message : '기록을 읽지 못했습니다.';
const comparisonMetrics: Array<{ key: keyof ManagementMetrics; label: string; format: (value: number | null) => string }> = [
  { key: 'actualRevenue', label: '실제 결제액', format: won },
  { key: 'customerVisits', label: '방문 접수', format: (v) => count(v) },
  { key: 'newCustomers', label: '신규 고객', format: (v) => count(v, '명') },
  { key: 'returningCustomers', label: '재방문 고객', format: (v) => count(v, '명') },
  { key: 'intakeGarments', label: '접수 세탁물', format: (v) => count(v, '점') },
  { key: 'averageTicket', label: '결제 주문 평균', format: won },
  { key: 'generalRevenue', label: '일반 실제 결제', format: won },
  { key: 'premiumRevenue', label: '프리미엄 실제 결제', format: won },
  { key: 'rewashCases', label: '재세탁', format: (v) => count(v) },
  { key: 'uncollectedGarments', label: '기간 접수분 미수령', format: (v) => count(v, '점') },
  { key: 'pickupDeliveryOrders', label: '수거·배달 이용', format: (v) => count(v) },
];

function Fact({ label, value }: { label: string; value: string }) {
  return <div><span>{label}</span><strong>{value}</strong></div>;
}

function PreviewTile({ photo, label }: { photo?: GarmentPhotoMetadata; label: string }) {
  const [preview, setPreview] = useState<{ source: string; status: 'loading' | 'loaded' | 'error'; url?: string }>({
    source: '', status: 'loading',
  });
  const source = photo?.sourcePhotoId && (photo.origin === 'simulation' || photo.origin === 'bridge')
    ? `${photo.origin}:${photo.sourcePhotoId}` : '';

  useEffect(() => {
    let current = true;
    setPreview({ source, status: source ? 'loading' : 'error' });
    if (photo?.sourcePhotoId && source && photo.origin === 'bridge') {
      void loadPhotoPreview(photo.sourcePhotoId, photo.origin).then((url) => {
        if (current) setPreview({ source, status: 'loaded', url });
      }).catch(() => {
        if (current) setPreview({ source, status: 'error' });
      });
    }
    return () => { current = false; };
  }, [photo?.sourcePhotoId, photo?.origin, source]);

  const isSample = photo?.origin === 'simulation';
  let placeholder = '사진 없음';
  if (photo && !photo.sourcePhotoId) placeholder = '기존 메타데이터 · 미리보기 없음';
  else if (photo?.origin === 'bridge' && preview.source === source && preview.status === 'error')
    placeholder = '태그 미리보기';
  else if (photo && !source) placeholder = '미리보기 지원 안 함';
  else if (photo && preview.status === 'loading') placeholder = '미리보기 불러오는 중';
  else if (photo && preview.status === 'error') placeholder = isSample ? 'sample · 미리보기 없음' : '미리보기 불러오기 실패';

  return <div className="mc-preview-tile" aria-label={`${label} 사진 미리보기`}>
    <span className="mc-preview-label">{label}{isSample ? '' : ''}</span>
    {preview.status === 'loaded' && preview.source === source && preview.url && !isSample
      ? <img src={preview.url} alt={`${label}${isSample ? ' sample' : ''} 미리보기`} />
      : <span className={`mc-preview-placeholder${photo?.origin === 'bridge' && preview.status === 'error' ? ' bridge-pending' : ''}`}>
        {isSample ? '실제 사진 없음' : placeholder}
      </span>}
  </div>;
}

function GarmentPhotoPreviews({ garment }: { garment?: GarmentRecord }) {
  const photos = garment ? activePhotosOf(garment).filter((photo) => photo.garmentId === garment.garmentId) : [];
  const before = photos.find((photo) => photo.requestId === garment?.representativeBeforePhotoId)
    ?? photos.filter((photo) => photo.role === 'intake')
      .sort((left, right) => Date.parse(left.timestamp) - Date.parse(right.timestamp))[0];
  const after = photos.filter((photo) => photo.role === 'completion')
    .sort((left, right) => Date.parse(right.timestamp) - Date.parse(left.timestamp))[0];
  return <div className="mc-photo-previews">
    <PreviewTile photo={before} label="접수 전" />
    <PreviewTile photo={after} label="완성 후" />
  </div>;
}

function GarmentDetail({ garment, order, actions }: {
  garment: GarmentRecord; order: ConfirmedOrder; actions: ManagementCenterProps;
}) {
  const inspection = order.inspection?.items.find((item) => item.index === garment.itemIndex - 1);
  const sourceItem = order.items[garment.itemIndex - 1];
  const photos = (garment.photoHistory ?? []).filter((photo) => photo.garmentId === garment.garmentId);
  const audit = (garment.auditEvents ?? []).filter((event) =>
    (!event.orderId || event.orderId === order.id) && (!event.garmentId || event.garmentId === garment.garmentId));
  const notification = (order.customerNotifications ?? []).filter((entry) =>
    !entry.garmentId || entry.garmentId === garment.garmentId);
  return <article className="mc-garment" data-testid={`garment-detail-${garment.garmentId}`}>
    <div className="mc-garment-main">
      <div><strong>{garment.itemName} · {garment.sequence}/{garment.totalSequence}</strong>
        <small>연락처 끝 {order.customerPhone.replace(/\D/g, '').slice(-4)}</small></div>
      <strong>{garmentDisplayStatus(order, garment, garment.processStatus || '진행 기록 없음')}</strong>
    </div>
    <GarmentPhotoPreviews garment={garment} />
    <div className="mc-garment-grid">
      <Fact label="접수일" value={date(order.intakeAt)} />
      <Fact label="의류 바코드" value={garment.barcodeValue || '저장 기록 없음'} />
      <Fact label="태그" value={tagLabel(garment)} />
      <Fact label="검수 상태" value={workflow(garment.inspectionStatus, '검수 전', '검수 중', '검수 완료')} />
      <Fact label="완성 확인" value={workflow(garment.completionStatus, '완성 확인 전', '완성 확인 중', '완성 확인 완료')} />
      <Fact label="서비스 / 순번" value={`${garment.serviceType.includes('premium') ? '프리미엄' : '일반'} / ${garment.sequence}/${garment.totalSequence}`} />
      <Fact label="접수 단가" value={sourceItem
        ? won(garment.serviceType === 'premium' || garment.serviceType === 'sneaker-premium'
          ? sourceItem.premiumPrice : sourceItem.generalPrice) : waiting} />
      <Fact label="의류별 검수 변경 단가" value={order.inspection?.revisedPrice !== order.inspection?.originalPrice
        ? '의류별 금액 미기록 · 주문 전체 변경금액 참조' : '변경 없음'} />
      <Fact label="접수 / 브랜드" value={`${text(sourceItem?.displayNameKo)} / ${text(sourceItem?.intakeDetails?.brand)}`} />
      <Fact label="검수" value={inspection ? `${inspection.method} · ${text(inspection.actualCleaningMethod || inspection.careLabelMethod)}` : '검수 기록 없음'} />
      <Fact label="상태 / 손상" value={sourceItem?.intakeDetails?.damage || inspection?.memo || '기록 없음'} />
      <Fact label="가격 / 변경" value={order.inspection ? `${won(order.inspection.originalPrice)} → ${won(order.inspection.revisedPrice)} (주문 전체)` : `${won(order.estimatedTotal)} (주문 예상)`} />
      <Fact label="위험 안내" value={inspection?.riskFactors?.length ? inspection.riskFactors.join(', ') : order.inspection?.riskNotice || '기록 없음'} />
      <Fact label="동의 / 회신" value={order.inspection?.response ? `${order.inspection.response.choice || waiting} · ${order.inspection.response.decisions?.join(', ') || '결정 기록 없음'}` : `접수 면책 ${order.choices.waiver === 'agreed' ? '동의' : order.choices.waiver === 'declined' ? '미동의' : '미확인'} · 검수 회신 기록 없음`} />
      <Fact label="세탁 / 재세탁" value={`${workflow(garment.cleaningStatus, '세탁 전', '세탁 중', '세탁 완료')} · ${garment.rewashCount == null ? '재세탁 기록 없음' : `${garment.rewashCount}회`}${garment.qcHoldReason ? ` · 보류: ${garment.qcHoldReason}` : ''}`} />
      <Fact label="사진 연결" value={`접수 ${garment.photoStatus === 'saved' ? '연결 기록 있음' : '연결 기록 없음'} / 완성 ${garment.completionPhoto?.status === 'saved' && garment.completionPhoto.garmentId === garment.garmentId ? '연결 기록 있음' : '연결 기록 없음'}`} />
      <Fact label="인도" value={`${workflow(garment.handoverStatus, '출고 전', '출고 중', '출고 완료')} · ${order.choices.deliveryRequested ? '배달' : '매장 수령'}`} />
      <Fact label="검수 항목" value={inspection && Object.keys(inspection.checks).length ? Object.entries(inspection.checks).map(([key, value]) => `${key} ${value}`).join(' · ') : '기록 없음'} />
      <Fact label="위험 상세 / 세탁 방법 변경" value={inspection?.riskDetails || inspection?.methodChangeReason || '기록 없음'} />
      <Fact label="세탁 진행 기록" value={garment.careProcesses?.length ? garment.careProcesses.map((item) => item.process).join(' → ')
        : audit.filter((event) => event.type === 'laundry-process').map((event) => event.status).join(' → ') || '진행 기록 없음'} />
    </div>
    <div className="mc-inline-actions">
      <button type="button" onClick={() => actions.onOpenLaundry(order.id)} data-testid={`button-laundry-${garment.garmentId}`}>세탁 과정 <ArrowRight /></button>
      <button type="button" onClick={() => actions.onOpenCapture(order.id, garment.garmentId)} data-testid={`button-capture-${garment.garmentId}`}>의류 기록·촬영 <Camera /></button>
      <button type="button" onClick={() => actions.onOpenPhoto(order.id, garment.garmentId)} data-testid={`button-photo-${garment.garmentId}`}>사진 보기 <ArrowRight /></button>
    </div>
    <details className="mc-audit">
      <summary>감사 이력 {count(audit.length)} · 사진 {count(photos.length)} · 알림 {count(notification.length)}</summary>
      {audit.length ? <ul>{[...audit].reverse().map((event, i) =>
        <li key={`${event.at}-${i}`}>{date(event.at)} · {event.action || event.type} · {event.status}{event.details || event.detail || event.reason ? ` · ${event.details || event.detail || event.reason}` : ''}{event.source ? ` · ${event.source}` : ''}</li>)}</ul> : <p>의류별 감사 기록 없음</p>}
      {photos.length > 0 && <ul>{photos.map((photo) => <li key={photo.requestId}>{date(photo.timestamp)} · {photo.role === 'intake' ? '접수' : '완성'} 사진 · {photo.status === 'simulated' ? '연결 미확인' : photo.status} · {photo.origin} · 요청 {photo.requestId} · 주석 {garment.annotationRevisions?.filter((revision) => revision.photoRequestId === photo.requestId).length ?? 0}개</li>)}</ul>}
      {notification.length > 0 && <ul>{notification.map((entry) => <li key={entry.id}>{entry.type} · {date(entry.createdAt)} · {entry.approvalAt ? '직원 승인' : '미승인'} · 실제 전송 안 함</li>)}</ul>}
    </details>
  </article>;
}

function OrderTimeline({ order, actions }: { order: ConfirmedOrder; actions: ManagementCenterProps }) {
  const garments = (order.garments ?? []).filter((garment) => garment.orderId === order.id);
  return <article className="mc-order" data-testid={`order-timeline-${order.id}`}>
    <div className="mc-order-main">
      <div><strong>접수일시 {date(order.intakeAt)} · {order.items.map((item) => `${item.displayNameKo} ${item.quantity}점`).join(', ') || waiting}</strong>
        <small>주문번호 {order.id} · {order.totalQuantity}점</small></div>
      <strong>{orderDisplayStatus(order, order.operations?.stage === '배달중' ? '배달 출고 완료' : order.status)}</strong>
    </div>
    <div className="mc-meta">
      <span>고객 {order.customerName} · {order.customerPhone}</span>
      <span>접수 상태 {orderDisplayStatus(order)}</span>
      <span>작업·출고 상태 {orderDisplayStatus(order, order.operations?.stage || '기록 없음')}</span>
      <span>출고 완료 시각 {order.operations?.completedAt ? date(order.operations.completedAt) : '완료 기록 없음'}</span>
      <span>실제 결제 {order.operations?.paymentStatus === '결제완료' && order.operations.paidAt ? won(order.operations.paidAmount) : waiting}</span>
      <span>수거 {order.choices.pickupRequested ? '요청' : '미요청'}</span>
      <span>배달 {order.choices.deliveryRequested ? '요청' : '미요청'}</span>
      <span>검수 {order.inspection ? date(order.inspection.inspectedAt) : '기록 없음'}</span>
    </div>
    {order.choices.customerRequests?.trim() && <p className="mc-note">이 주문의 요청: {order.choices.customerRequests}</p>}
    <div className="mc-inline-actions">
      <button type="button" onClick={() => actions.onOpenOrder(order.id)} data-testid={`button-open-order-${order.id}`}>주문·검수 열기</button>
      <button type="button" onClick={() => actions.onOpenLaundry(order.id)} data-testid={`button-open-laundry-${order.id}`}>세탁 진행</button>
      <button type="button" onClick={() => actions.onOpenCapture(order.id)} data-testid={`button-open-capture-${order.id}`}>의류 촬영·태그</button>
    </div>
    {garments.length ? garments.map((garment) => <GarmentDetail key={garment.garmentId} garment={garment} order={order} actions={actions} />)
      : <p className="mc-empty">의류별 기록 없음 · 주문 화면에서 확인해 주세요.</p>}
    {garments.length !== (order.garments?.length ?? 0) && <p role="alert" className="mc-note">다른 주문번호가 연결된 의류 기록은 표시하지 않았습니다. 원본 연결을 확인해 주세요.</p>}
    {!!order.history?.length && <details className="mc-audit"><summary>주문 이력 {count(order.history.length)}</summary>
      <ul>{[...order.history].reverse().map((event, i) =>
        <li key={`${event.at}-${i}`}>{date(event.at)} · {event.kind}</li>)}</ul></details>}
  </article>;
}

export function ManagementCenter(props: ManagementCenterProps) {
  const [orders, setOrders] = useState<ConfirmedOrder[] | null>(null);
  const [error, setError] = useState('');
  const [hardware, setHardware] = useState<Hardware>(null);
  const [hardwareError, setHardwareError] = useState('');
  const [tab, setTab] = useState<Tab>('overview');
  const [mode, setMode] = useState<ManagementPeriodMode>('day');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [appliedRange, setAppliedRange] = useState<{ from: string; to: string } | null>(null);
  const [query, setQuery] = useState(() => new URLSearchParams(window.location.search).get('orderId') ?? '');
  const [selectedPhone, setSelectedPhone] = useState<string | null>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('orderId'));
  const [asOf, setAsOf] = useState(() => koreaCalendarDate(new Date()));
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);

  const refresh = useCallback(() => {
    try {
      const next = readConfirmedOrders();
      setOrders(next);
      setError('');
      setAsOf(koreaCalendarDate(new Date()));
      setUpdatedAt(new Date().toISOString());
    } catch (cause) {
      // Keep last known good records visible, but never conceal a failed read.
      setError(message(cause));
    }
  }, []);
  const refreshHardware = useCallback(async () => {
    try {
      const result = await getHardwareStatus();
      setHardware(result);
      setHardwareError('');
    } catch (cause) {
      setHardwareError(message(cause));
      setHardware(null);
    }
  }, []);
  useEffect(() => {
    refresh();
    // Do not probe an absent Windows loopback bridge on every focus or page load.
    // A store operator may request a status check explicitly below.
    const onFocus = () => { refresh(); };
    const onStorage = () => refresh();
    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    window.addEventListener('focus', onFocus);
    window.addEventListener('storage', onStorage);
    window.addEventListener('pageshow', onFocus);
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('pageshow', onFocus);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [refresh]);
  const summary = useMemo(() => orders === null ? null : managementSummary(orders, asOf), [orders, asOf]);
  const comparison = useMemo(() => {
    if (!orders || (mode === 'custom' && !appliedRange)) return null;
    try { return periodComparison(orders, mode, asOf, appliedRange?.from, appliedRange?.to); }
    catch { return null; }
  }, [orders, mode, asOf, appliedRange]);
  const results = useMemo(() => orders === null ? [] : searchManagementCustomers(orders, query), [orders, query]);
  const profile = useMemo(() => {
    if (!orders || !selectedPhone) return null;
    return customerManagementProfile(orders, selectedPhone);
  }, [orders, selectedPhone]);
  const selectedResult = results.find((result) =>
    selectedPhone ? result.normalizedPhone === selectedPhone : selectedOrderId ? result.matchedOrderIds.includes(selectedOrderId) : false)
    ?? (results.length === 1 ? results[0] : null);
  const selected: ManagementCustomerSearchResult | null = profile
    ? { ...profile, matchedOrderIds: selectedResult?.matchedOrderIds ?? profile.orderHistory.map((order) => order.id) }
    : selectedResult ?? null;
  const orderDates = useMemo(() => managementOrdersByDate(selected?.orderHistory ?? []), [selected]);
  const outstanding = useMemo(() => orders === null ? [] : uncollectedGarments(orders, asOf), [orders, asOf]);
  const kpis = summary ? [
    ['오늘 매출', won(summary.todayConfirmedSales), '확정 세탁비 기준 (직원 수정 금액 포함)'],
    ['이번 달 매출', won(summary.monthConfirmedSales), '확정 세탁비 기준 (직원 수정 금액 포함)'],
    ['오늘 방문 고객수', count(summary.today.customerVisits, '명'), '오늘 접수 기준'],
    ['신규 고객수', count(summary.month.newCustomers, '명'), '이번 달 첫 방문'],
    ['접수 의류수', count(summary.acceptedGarments, '점'), '전체 접수'],
    ['세탁 진행 중', count(summary.inProgressGarments, '점'), '완료 전 의류'],
    ['출고 대기 (세탁 완료)', count(summary.readyForHandoverGarments, '점'), '인도 전'],
    ['미수령 의류', count(summary.uncollectedGarments, '점'), '전체 미인도'],
  ] : [];
  const hardwareMode = hardware?.status === 'simulated' || hardware?.mode === 'simulation'
    ? '연결 미확인' : hardware?.online === true && hardware?.status !== 'offline' && hardware?.status !== 'error'
      ? '브리지 응답 · 장치별 확인 필요' : '연결 미확인';
  const device = (key: string) => {
    const value = hardware?.[key];
    if (typeof value === 'string') return value;
    if (value && typeof value === 'object') {
      const record = value as Record<string, unknown>;
      return text(record.status || record.message);
    }
    return '상태 알 수 없음';
  };

  return <main className="management-center" data-testid="management-center">
    <div className="mc-wrap">
      <header className="mc-top">
        <div className="mc-brand"><span className="mc-monogram">K99</span><div><strong>품격세탁소 · 과천점</strong><small>직원 관리</small></div></div>
        <div className="mc-top-right">
          <span className="mc-time" data-testid="text-management-updated">{updatedAt ? `마지막 확인 ${date(updatedAt)}` : '기록 확인 중'}</span>
          <button type="button" onClick={() => { refresh(); void refreshHardware(); }} data-testid="button-refresh-management"><RefreshCw /> 새로고침</button>
          <button type="button" onClick={props.onBack} data-testid="button-back-management"><ArrowLeft /> 돌아가기</button>
        </div>
      </header>
      <div className="mc-heading"><div><h1>통합관리센터</h1><p>고객을 찾고, 의류 한 점의 현재 위치까지 확인합니다.</p></div><span className="mc-time">기준일 {asOf} · 이 브라우저의 저장 기록</span></div>
      {error && <div className="mc-alert" role="alert" data-testid="status-management-error">저장 기록 읽기 실패: {error} · {orders ? '이전에 읽은 자료를 유지하고 있습니다.' : '현재 표시할 자료가 없습니다.'}<button type="button" onClick={refresh} data-testid="button-retry-management">다시 시도</button></div>}
      <nav className="mc-nav" aria-label="관리센터 화면">
        <div className="mc-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={tab === 'overview'} onClick={() => setTab('overview')} data-testid="button-management-overview">전체 현황</button>
          <button type="button" role="tab" aria-selected={tab === 'uncollected'} onClick={() => setTab('uncollected')} data-testid="button-management-uncollected">미수령 의류 {summary ? count(summary.uncollectedGarments, '점') : ''}</button>
        </div>
        <div className="mc-actions">
          <button type="button" onClick={() => window.location.assign(`${import.meta.env.BASE_URL}maintenance#program-integrations`)}
            data-testid="button-management-program-settings">프로그램 연동 설정</button>
          <button type="button" className="mc-primary" onClick={props.onNewIntake} data-testid="button-management-new-intake"><Shirt /> 새 접수</button>
          <button type="button" hidden onClick={props.onOpenScanner} data-testid="button-management-scanner"><ScanLine /> 바코드 스캔</button>
          <button type="button" onClick={props.onOpenOperations} data-testid="button-management-operations"><ClipboardList /> 운영 관리</button>
        </div>
      </nav>
      <div className="mc-grid">
        <div className="mc-stack">
          {tab === 'overview' ? <>
            <section className="mc-panel" aria-label="전체 핵심 지표">
              <div className="mc-section-head"><div><h2>매장 핵심 지표</h2><p>실제 결제액만 매출로 표시합니다. 예상금액은 합산하지 않습니다.</p></div><span className="mc-kicker">15 INDICATORS</span></div>
              {summary ? <div className="mc-metrics">{kpis.map(([label, value, note], i) => <div className="mc-metric" key={label} data-testid={`metric-management-${i}`}><span>{label}</span><strong className={i === 5 ? 'mc-gold' : i === 7 ? 'mc-teal' : ''}>{value}</strong><small>{note}</small></div>)}</div>
                : <div className="mc-empty">{orders === null ? '저장 기록을 읽는 중입니다.' : waiting}</div>}
            </section>
            <section className="mc-panel">
              <div className="mc-section-head"><div><h2>기간 비교</h2><p>현재 기간과 바로 이전 기간 · 결제일 기준 실제 결제액</p></div>
                <div className="mc-period" aria-label="비교 기간">
                  {([['day', '오늘'], ['month', '이달'], ['year', '올해'], ['custom', '직접 지정']] as const).map(([key, label]) =>
                    <button type="button" key={key} aria-pressed={mode === key} onClick={() => setMode(key)} data-testid={`button-period-${key}`}>{label}</button>)}
                </div>
              </div>
              {mode === 'custom' && <form className="mc-date-range" onSubmit={(event) => {
                event.preventDefault();
                if (from && to && from <= to) setAppliedRange({ from, to });
              }}><label>시작일<input type="date" required value={from} onChange={(event) => setFrom(event.target.value)} data-testid="input-period-from" /></label>
                <label>종료일<input type="date" required min={from || undefined} value={to} onChange={(event) => setTo(event.target.value)} data-testid="input-period-to" /></label>
                <button type="submit" data-testid="button-apply-period">비교 적용</button></form>}
              {comparison ? <>
                <p className="mc-note">{comparison.currentPeriod.from} ~ {comparison.currentPeriod.to} ↔ {comparison.previousPeriod.from} ~ {comparison.previousPeriod.to}</p>
                <div className="mc-compare">{comparisonMetrics.map(({ key, label, format }) => {
                  const current = comparison.current[key] as number | null;
                  const previous = comparison.previous[key] as number | null;
                  const change = comparison.change[key] as number | null;
                  return <div className="mc-compare-item" key={key} data-testid={`compare-${key}`}><span>{label}</span><strong>{format(current)}</strong>
                    <small>이전 {format(previous)} · 변화 <b className={change !== null && change < 0 ? 'negative' : ''}>{change == null ? waiting : `${change > 0 ? '+' : ''}${format(change)}`}</b></small></div>;
                })}</div>
                <div className="mc-chart" role="img" aria-label={`실제 결제액 비교: 이전 ${won(comparison.previous.actualRevenue)}, 현재 ${won(comparison.current.actualRevenue)}`}>
                  {([['이전 기간', comparison.previous.actualRevenue], ['현재 기간', comparison.current.actualRevenue]] as const).map(([label, value]) => {
                    const max = Math.max(comparison.current.actualRevenue ?? 0, comparison.previous.actualRevenue ?? 0, 1);
                    return <div className="mc-chart-col" key={label}><strong>{won(value)}</strong><div className="mc-chart-bar" style={{ height: value === null ? 2 : Math.max(2, value / max * 77) }} /><span>{label}</span></div>;
                  })}
                </div>
                {comparison.current.itemQuantities && Object.keys(comparison.current.itemQuantities).length > 0 &&
                  <p className="mc-note">품목별 접수 · {Object.entries(comparison.current.itemQuantities).sort((a, b) => b[1] - a[1]).map(([name, quantity]) => `${name} ${quantity}점`).join(' / ')}</p>}
                <p className="mc-note">자료가 없는 기간은 0으로 가정하지 않습니다. 방문은 접수 주문 수 기준입니다.</p>
              </> : <div className="mc-empty">{mode === 'custom' && !appliedRange ? '시작일과 종료일을 선택한 뒤 비교 적용을 눌러 주세요.' : waiting}</div>}
            </section>
          </> : <section className="mc-panel" data-testid="section-uncollected">
            <div className="mc-section-head"><div><h2>미반출 세탁물 관리</h2><p>인도되지 않은 모든 의류를 상태별로 표시 · 출고 대기만 별도로 집계</p></div><strong>{orders ? count(outstanding.length, '점') : waiting}</strong></div>
            <div className="mc-uncollected">{outstanding.length ? outstanding.map((item) => <article className="mc-uncollected-row" key={item.garmentId} data-testid={`uncollected-${item.garmentId}`}>
              {(() => {
                const related = orders?.find((order) => order.id === item.orderId);
                const garment = related?.garments?.find((record) => record.garmentId === item.garmentId);
                const activePhotoCount = garment ? activePhotosOf(garment).length : 0;
                return <>
                  <p className="mc-note">접수일 {item.intakeAt ?? waiting} · 주문 세탁물 {related?.totalQuantity ?? waiting}점 · 활성 사진 메타데이터 {activePhotoCount}건</p>
                  <GarmentPhotoPreviews garment={garment} />
                </>;
              })()}
              <div className="mc-order-main"><div><strong>{item.customerName} · {item.itemName}</strong><small>{item.customerPhoneLast4 || waiting}</small></div><strong>{item.elapsedDays == null ? waiting : `접수 ${item.elapsedDays + 1}일차`}</strong></div>
              <div className="mc-meta"><span>바코드 {text(item.barcodeValue)}</span><span>상태 {item.processStatus}</span><span>완료 {date(item.completedAt)}</span><span>인도 {item.handoverMethod === 'delivery' ? '배달' : item.handoverMethod === 'store-pickup' ? '매장 수령' : waiting}</span><span>의류별 보관료 {won(item.storageFee)}</span></div>
              <div className="mc-reminders">{item.reminders.map((reminder) => <span key={reminder.day} className={reminder.status !== 'not-due' ? 'due' : ''}>{reminder.day}일차 · {item.elapsedDays === null ? '기준일 확인 필요 · 미전송' : reminder.status === 'externally-confirmed-by-staff' ? '외부 발송 직원 확인' : reminder.status === 'draft-prepared-not-sent' ? '초안 준비 · 미전송' : reminder.status === 'due-not-prepared' ? '초안 필요 · 미전송' : '아직 해당 없음'}</span>)}</div>
              <div className="mc-inline-actions"><button type="button" onClick={() => { setTab('overview'); setQuery(item.garmentId); setSelectedPhone(null); setSelectedOrderId(item.orderId); }} data-testid={`button-find-uncollected-${item.garmentId}`}>상세 찾기</button>
                <button type="button" onClick={() => props.onOpenLaundry(item.orderId)} data-testid={`button-laundry-uncollected-${item.garmentId}`}>세탁·인도 화면</button>
                <button type="button" onClick={() => props.onOpenPhoto(item.orderId, item.garmentId)}>전후 사진·케어 기록</button>
                <button type="button" onClick={() => props.onOpenOrder(item.orderId)} data-testid={`button-order-uncollected-${item.garmentId}`}>주문 열기</button></div>
            </article>) : <div className="mc-empty">{orders === null ? '기록을 읽는 중입니다.' : '현재 기록된 미수령 의류가 없습니다.'}</div>}</div>
            <p className="mc-note">알림은 직원 검토용 초안이며 실제 문자·카카오톡 전송이 아닙니다. 보관료는 저장된 기준으로 계산된 표시값입니다.</p>
          </section>}
          <section className="mc-panel">
            <div className="mc-section-head"><div><h2>고객 · 의류 찾기</h2><p>고객명, 연락처 또는 바코드로 찾으세요.</p></div></div>
            <div className="mc-search-line"><Search size={19} /><ImeTextInput koreanFirst="search" data-scanner-input autoComplete="off" type="search" value={query} onValue={(value) => {
              refresh();
              setQuery(value); setSelectedPhone(null); setSelectedOrderId(null);
            }} placeholder="고객명 / 전화번호 / 끝 4자리 / 주문번호 / 의류 바코드" aria-label="고객, 전화번호, 주문 또는 의류 검색" data-testid="input-management-search" /></div>
            <p className="mc-note">{orders === null ? '기록을 읽는 중입니다.' : `${results.length}명의 고객 · 동일한 이름은 전화번호와 주문을 확인해 선택하세요.`}</p>
            <div className="mc-results">{results.length ? results.map((result, index) => <button type="button" className="mc-result" key={result.normalizedPhone || result.orderHistory[0]?.id || index}
              aria-pressed={selectedOrderId === result.orderHistory[0]?.id && selectedPhone === (result.normalizedPhone || null)}
              onClick={() => { setSelectedPhone(result.normalizedPhone || null); setSelectedOrderId(result.orderHistory[0]?.id || null); }}
              data-testid={`button-customer-result-${index}`}>
              <strong>{result.customerName || waiting}</strong><span>{result.customerPhone || '전화번호 미기록'} · 최근 {date(result.recentVisit)}</span><small>{count(result.orderCount)} 주문 · 일치 {count(result.matchedOrderIds.length)}</small>
            </button>) : <div className="mc-empty">{orders === null ? '기록을 읽는 중입니다.' : query ? '일치하는 고객·주문·의류가 없습니다. 번호 또는 ID를 다시 확인해 주세요.' : '저장된 고객 기록이 없습니다. 새 접수 후 여기에서 검색할 수 있습니다.'}</div>}</div>
          </section>
          {selected && <section className="mc-panel" data-testid="section-management-customer">
            <div className="mc-detail-head"><div><span className="mc-kicker">CUSTOMER RECORD</span><h2>{selected.customerName || waiting} · {selected.customerPhone || '전화번호 미기록'}</h2><p>{selected.customerAddress || '주소 기록 없음'}</p></div><strong>전체 이력 · 주문 {count(selected.orderCount)} · 누적 의류 {count(selected.garmentCount, '점')}</strong></div>
            <div className="mc-facts">
              <Fact label="첫 방문" value={date(selected.firstVisit)} /><Fact label="최근 방문" value={date(selected.recentVisit)} />
              <Fact label="방문 / 진행 주문" value={`${count(selected.visitCount)} / ${count(selected.activeOrders.length)}`} />
              <Fact label="기록된 실제 결제" value={won(selected.paidTotal)} />
              <Fact label="완료 주문" value={count(selected.completedOrders.length)} /><Fact label="미수령 포함 주문" value={count(selected.uncollectedOrders.length)} />
              <Fact label="수거 이용" value={count(selected.pickupDeliveryHistory.filter((item) => item.pickupRequested).length)} />
              <Fact label="배달 이용" value={count(selected.pickupDeliveryHistory.filter((item) => item.deliveryRequested).length)} />
            </div>
            <h3 className="mc-subhead">날짜별 주문 이력 · 최신순</h3>
            {orderDates.map((group) => <section key={group.intakeDate ?? 'undated'} data-testid={`management-orders-date-${group.intakeDate ?? 'undated'}`}>
              <h3 className="mc-subhead">{group.intakeDate ?? '접수일 기록 없음'} 접수 · {group.orders.length}개 주문</h3>
              {group.orders.map((order) => <div key={`${order.id}:${order.intakeAt}`}>
                {query && selected.matchedOrderIds.includes(order.id) && <span className="mc-kicker">검색 일치</span>}
                {selectedOrderId === order.id && <span className="mc-kicker"> · 선택 주문</span>}
                <OrderTimeline order={order} actions={props} />
              </div>)}
            </section>)}
          </section>}
        </div>
        <aside className="mc-side mc-stack">
          <section className="mc-panel"><div className="mc-section-head"><div><h2>바로 이동</h2><p>카운터에서 자주 쓰는 경로</p></div></div>
            <div className="mc-side-actions">
              <button type="button" onClick={props.onOpenToday} data-testid="button-management-today">오늘의 업무 · 확인 필요 <ArrowRight /></button>
              
              
              <button type="button" onClick={props.onNewIntake} data-testid="button-quick-new-intake">새 고객 접수 <ArrowRight /></button>
              <button type="button" onClick={props.onOpenScanner} data-testid="button-quick-scanner">의류 바코드 검색 <ArrowRight /></button>
              <button type="button" onClick={() => setTab('uncollected')} data-testid="button-quick-uncollected">미수령 의류 확인 <ArrowRight /></button>
              <button type="button" onClick={props.onOpenOperations} data-testid="button-quick-operations">결제·알림·정책 관리 <ArrowRight /></button>
            </div>
          </section>
          <details className="mc-panel mc-manager-only" data-testid="section-manager-only"><summary>관리자 전용 · 장비와 설정</summary>{orders !== null && <AdminTagDiagnostics orders={orders} />}<div className="mc-side-actions"><button type="button" onClick={props.onOpenStoreTest} data-testid="button-management-store-test">매장 장비 점검 <ArrowRight /></button>{props.onOpenPhotoSettings && <button type="button" onClick={props.onOpenPhotoSettings} data-testid="button-management-photo-settings">사진 연결 설정 <ArrowRight /></button>}</div><div className="mc-section-head"><div><h2>장비 연결 상태</h2><p>연결 응답만 확인하며 실제 동작을 보증하지 않습니다.</p></div></div>
            <div className="mc-hardware">
              <div className="mc-hardware-row"><span>사진 연결 프로그램</span><strong data-testid="status-hardware-mode">{hardwareError ? '연결 미확인' : hardware ? hardwareMode : '연결 미확인'}</strong></div>
              <div className="mc-hardware-row"><span>카메라</span><strong>{device('camera')}</strong></div>
              <div className="mc-hardware-row"><span>USB 풋스위치</span><strong>{device('footSwitch')}</strong></div>
              <div className="mc-hardware-row"><span>태그 프린터</span><strong>{device('printer')}</strong></div>
              <div className="mc-hardware-row"><span>스캐너</span><strong>{device('scanner')}</strong></div>
              <div className="mc-hardware-row"><span>사진 저장소</span><strong>{device('storage')}</strong></div>
            </div>
            <p className="mc-hardware-message" data-testid="status-hardware-message">{hardwareError || (typeof hardware?.message === 'string' ? hardware.message : '장치별 검증 정보가 없으면 실제 연결 상태는 알 수 없습니다.')}</p>
            <button type="button" onClick={() => void refreshHardware()} data-testid="button-refresh-hardware"><RefreshCw /> 장비 상태 확인</button>
          </details>
          <section className="mc-panel"><h2>기록 범위</h2><p>이 화면은 이 브라우저에 저장된 주문만 읽습니다. 직원 로그인·서버 백업·실제 메시지 전송·장비 동작을 대신하지 않습니다.</p></section>
        </aside>
      </div>
    </div>
  </main>;
}

export default ManagementCenter;