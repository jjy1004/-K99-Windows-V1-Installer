import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X, ChevronRight, ChevronLeft, Info, Loader2, Settings, CameraOff, Camera } from 'lucide-react';
import './camera-setup-guide.css';

function useModal(open: boolean, onClose: () => void) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const t = window.setTimeout(() => panelRef.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus(), 0);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.stopPropagation(); closeRef.current(); return; }
      if (e.key === 'Tab' && panelRef.current) {
        const f = Array.from(panelRef.current.querySelectorAll<HTMLElement>('button:not([disabled]),[href],[tabindex]:not([tabindex="-1"])')).filter(el => el.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => { window.clearTimeout(t); document.removeEventListener('keydown', onKey, true); if (prev && document.contains(prev)) prev.focus(); };
  }, [open]);
  return panelRef;
}

function Phone({ children, screen = '#1d3a46' }: { children?: ReactNode; screen?: string }) {
  return <>
    <rect x="70" y="10" width="120" height="230" rx="20" fill="#24343b" />
    <rect x="78" y="26" width="104" height="198" rx="8" fill={screen} />
    <circle cx="130" cy="18" r="3" fill="#6b7d83" />
    <rect x="190" y="70" width="4" height="30" rx="2" fill="#24343b" />
    {children}
  </>;
}

function Touch({ x, y }: { x: number; y: number }) {
  return <g aria-hidden="true">
    <circle className="csg-pulse" cx={x} cy={y} r="15" fill="none" stroke="#e0281a" strokeWidth="4" />
    <circle cx={x} cy={y} r="6" fill="#e0281a" />
  </g>;
}

function ArtCharge() {
  return <svg viewBox="0 0 260 300" role="img" aria-label="휴대폰 아래쪽 충전 구멍에 충전기 선을 꽂는 그림">
    <Phone>
      <rect x="100" y="110" width="60" height="34" rx="6" fill="none" stroke="#9fe0b0" strokeWidth="4" />
      <rect x="160" y="120" width="6" height="14" rx="2" fill="#9fe0b0" />
      <rect x="104" y="114" width="36" height="26" rx="3" fill="#9fe0b0" />
      <path d="M124 116 l-8 12 h8 l-6 12" stroke="#1d3a46" strokeWidth="3" fill="none" />
    </Phone>
    <rect x="120" y="236" width="20" height="8" rx="2" fill="#11191d" />
    <rect x="122" y="244" width="16" height="22" rx="3" fill="#f2f2ee" stroke="#24343b" strokeWidth="2" />
    <path d="M130 266 C130 290 200 280 230 296" stroke="#f2f2ee" strokeWidth="7" fill="none" strokeLinecap="round" />
    <path d="M130 266 C130 290 200 280 230 296" stroke="#24343b" strokeWidth="1.5" fill="none" />
    <Touch x={130} y={252} />
  </svg>;
}

function ArtWifi() {
  return <svg viewBox="0 0 260 260" role="img" aria-label="휴대폰 와이파이를 매장 공유기에 연결하고 Iriun 앱 아이콘을 누르는 그림">
    <Phone screen="#eef3f1">
      <rect x="84" y="36" width="92" height="40" rx="8" fill="#ffffff" stroke="#b9c7c3" />
      <path d="M100 52 a16 16 0 0 1 22 0 M104 57 a10 10 0 0 1 14 0" stroke="#1f6fb2" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="111" cy="62" r="2.5" fill="#1f6fb2" />
      <text x="128" y="62" fontSize="12" fontWeight="700" fill="#172a31">매장</text>
      <rect x="156" y="48" width="14" height="14" rx="7" fill="#2f9a55" />
      <rect x="104" y="120" width="52" height="52" rx="14" fill="#1b2a31" />
      <circle cx="130" cy="146" r="14" fill="none" stroke="#ffffff" strokeWidth="4" />
      <circle cx="130" cy="146" r="5" fill="#ffffff" />
      <text x="130" y="192" fontSize="13" fontWeight="700" fill="#172a31" textAnchor="middle">Iriun</text>
    </Phone>
    <Touch x={146} y={160} />
  </svg>;
}

function ArtScreen() {
  return <svg viewBox="0 0 260 260" role="img" aria-label="휴대폰 설정의 디스플레이 메뉴에서 화면 자동 꺼짐 시간을 가장 길게 고르는 그림">
    <Phone screen="#eef3f1">
      <text x="88" y="46" fontSize="13" fontWeight="800" fill="#172a31">화면 자동 꺼짐</text>
      {['15초', '1분', '5분', '10분'].map((t, i) => (
        <g key={t}>
          <rect x="86" y={58 + i * 38} width="88" height="30" rx="6" fill={i === 3 ? '#ffe2dd' : '#ffffff'} stroke={i === 3 ? '#e0281a' : '#c8d3d0'} strokeWidth={i === 3 ? 2.5 : 1} />
          <circle cx="100" cy={73 + i * 38} r="6" fill="none" stroke="#172a31" strokeWidth="2" />
          {i === 3 && <circle cx="100" cy={73 + i * 38} r="3" fill="#e0281a" />}
          <text x="114" y={78 + i * 38} fontSize="13" fontWeight="700" fill="#172a31">{t}</text>
        </g>
      ))}
    </Phone>
    <Touch x={150} y={187} />
  </svg>;
}

const STEPS = [
  { title: '충전기 선 꽂기', body: '촬영용 휴대폰에 충전기 선을 꽂아 두세요.', art: <ArtCharge /> },
  { title: '와이파이 맞추고 Iriun 켜기', body: '휴대폰 와이파이를 매장 공유기에 맞추고 Iriun 앱을 켜세요.', art: <ArtWifi /> },
  { title: '화면 꺼짐 시간 길게', body: '휴대폰 화면이 쉽게 꺼지지 않도록 가장 긴 시간을 고르세요.', art: <ArtScreen />, path: ['설정', '디스플레이', '화면 자동 꺼짐 시간'] },
];

export function CameraSetupGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const panelRef = useModal(open, onClose);
  const [idx, setIdx] = useState(0);
  useEffect(() => { if (open) setIdx(0); }, [open]);
  if (!open) return null;
  return createPortal(
    <div className="csg-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={panelRef} className="csg-panel" role="dialog" aria-modal="true" aria-label="촬영용 휴대폰 준비 안내" aria-labelledby="csg-guide-title" data-testid="dialog-camera-setup-guide">
        <div className="csg-head">
          <div>
            <h2 id="csg-guide-title">촬영용 휴대폰 준비 3단계</h2>
            <p>아침에 한 번만 해 두시면 됩니다.</p>
          </div>
          <button type="button" className="csg-close" onClick={onClose} data-autofocus aria-label="안내 닫기" data-testid="button-camera-guide-close"><X aria-hidden="true" />닫기</button>
        </div>
        <div className="csg-cards">
          {STEPS.map((s, i) => (
            <article key={s.title} className="csg-card" data-active={i === idx} aria-label={`${i + 1}단계 ${s.title}`} data-testid={`card-camera-guide-${i + 1}`}>
              <span className="csg-step"><b>{i + 1}</b>{i + 1}단계</span>
              <h3>{s.title}</h3>
              <div className="csg-art">{s.art}</div>
              <p>{s.body}</p>
              {s.path && <div className="csg-path" aria-label={`휴대폰 ${s.path.join(', ')}`}>
                {s.path.map((p, j) => <span key={p} style={{ display: 'contents' }}>{j > 0 && <ChevronRight aria-hidden="true" />}<span>{p}</span></span>)}
              </div>}
            </article>
          ))}
        </div>
        <div className="csg-nav" aria-label="단계 이동">
          <button type="button" disabled={idx === 0} onClick={() => setIdx(i => i - 1)} data-testid="button-camera-guide-prev"><ChevronLeft aria-hidden="true" />이전</button>
          <span aria-live="polite">{idx + 1} / 3단계</span>
          <button type="button" disabled={idx === 2} onClick={() => setIdx(i => i + 1)} data-testid="button-camera-guide-next">다음<ChevronRight aria-hidden="true" /></button>
        </div>
        <div className="csg-note">
          <Info aria-hidden="true" />
          <p>휴대폰 기종마다 메뉴 이름과 가장 긴 시간이 다릅니다. 충전 중이어도 화면이 꺼지는 휴대폰이 있으니, Iriun 앱 설정에서 화면 켜짐 유지 기능이 있는지도 확인해 주세요. 영업 중 화면이 꺼지면 휴대폰을 한 번 눌러 깨워 주세요.</p>
        </div>
      </div>
    </div>, document.body);
}

export function CameraConnectionBadge({ connected, connecting, mock }: { connected: boolean; connecting?: boolean; mock?: boolean }) {
  if (mock) return <span className="csg-badge is-mock" role="status" data-testid="status-camera-connection"><span className="csg-badge__dot" aria-hidden="true" />모의 촬영 · 실제 연결 아님</span>;
  if (connected) return <span className="csg-badge is-ok" role="status" data-testid="status-camera-connection"><span className="csg-badge__dot" aria-hidden="true" /><Camera aria-hidden="true" />카메라 정상 연결됨</span>;
  return <span className="csg-badge is-bad" role="status" data-testid="status-camera-connection">
    <span className="csg-badge__dot" aria-hidden="true" />휴대폰 Iriun 앱 확인 필요
    {connecting && <small><Loader2 className="csg-spin" aria-hidden="true" style={{ display: 'inline', verticalAlign: '-4px' }} /> 연결 확인 중</small>}
  </span>;
}

export function CameraPermissionDialog({ open, onClose, onOpenSettings, opening, error }: { open: boolean; onClose: () => void; onOpenSettings: () => void; opening: boolean; error?: string }) {
  const panelRef = useModal(open, onClose);
  if (!open) return null;
  return createPortal(
    <div className="csg-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={panelRef} className="csg-panel csg-perm" role="dialog" aria-modal="true" aria-label="카메라 사용이 꺼져 있어요" data-testid="dialog-camera-permission">
        <div className="csg-head">
          <div>
            <h2><CameraOff aria-hidden="true" style={{ width: 36, height: 36, verticalAlign: '-6px', marginRight: 10, color: '#ff8a73' }} />카메라 사용이 꺼져 있어요</h2>
            <p>Windows 설정에서 카메라 사용을 켜야 사진을 찍을 수 있습니다.</p>
          </div>
        </div>
        <ol>
          <li>아래 노란 버튼을 누르세요.</li>
          <li><b>카메라 액세스</b>를 <b>켬</b>으로 바꾸세요.</li>
          <li><b>데스크톱 앱이 카메라에 액세스하도록 허용</b>을 <b>켬</b>으로 바꾸세요.</li>
          <li>이 창으로 돌아와 다시 연결을 누르세요.</li>
        </ol>
        {opening && <p className="csg-status" role="status"><Loader2 className="csg-spin" aria-hidden="true" style={{ display: 'inline', width: 22, verticalAlign: '-5px' }} /> 설정 창을 여는 중입니다…</p>}
        {error && <p className="csg-error" role="alert" data-testid="error-camera-permission">{error}</p>}
        <div className="csg-actions">
          <button type="button" className="csg-btn csg-btn--primary" disabled={opening} onClick={onOpenSettings} data-autofocus data-testid="button-open-camera-settings"><Settings aria-hidden="true" />카메라 권한 설정 바로 열기</button>
          <button type="button" className="csg-btn csg-btn--ghost" onClick={onClose} data-testid="button-camera-permission-close"><X aria-hidden="true" />닫기</button>
        </div>
      </div>
    </div>, document.body);
}
