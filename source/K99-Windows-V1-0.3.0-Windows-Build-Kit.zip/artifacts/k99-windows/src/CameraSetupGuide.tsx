import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X, Info, Loader2, Settings, CameraOff, Camera } from 'lucide-react';
import { IriunUsbGuide } from './IriunUsbGuide';
import { OriginalGuideImages } from './OriginalGuideImages';
import './camera-setup-guide.css';

function useModal(open: boolean, onClose: () => void) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const t = window.setTimeout(() => panelRef.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus(), 0);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.stopPropagation(); closeRef.current(); return; }
      if (e.key === 'Tab' && panelRef.current) {
        const f = Array.from(panelRef.current.querySelectorAll<HTMLElement>('button:not([disabled]),[href],[tabindex]:not([tabindex="-1"])')).filter(el => el.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => { window.clearTimeout(t); document.removeEventListener('keydown', onKey, true); if (prev && document.contains(prev)) prev.focus(); };
  }, [open]);
  return panelRef;
}

export function CameraSetupGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const panelRef = useModal(open, onClose);
  if (!open) return null;
  return createPortal(
    <div className="csg-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={panelRef} className="csg-panel" role="dialog" aria-modal="true" aria-label="촬영용 휴대폰 준비 안내" aria-labelledby="csg-guide-title" data-testid="dialog-camera-setup-guide">
        <div className="csg-head">
          <div>
            <h2 id="csg-guide-title">촬영 준비 그림 안내 (딱 1번만)</h2>
            <p>첨부한 실제 안내 이미지와 기존 USB 표준 7단계</p>
          </div>
          <button type="button" className="csg-close" onClick={onClose} data-autofocus aria-label="안내 닫기" data-testid="button-camera-guide-close"><X aria-hidden="true" />닫기</button>
        </div>
        <OriginalGuideImages />
        <details>
          <summary className="ius-button">촬영용 휴대폰 · USB 표준 7단계 보기</summary>
          <IriunUsbGuide slides />
        </details>
        <div className="csg-note">
          <Info aria-hidden="true" />
          <p>기종별 메뉴 이름은 다를 수 있습니다. 화면을 어둡게 해도 발열·케이블 불량까지 없어지거나 종일 연결이 보장되지는 않습니다.</p>
        </div>
        <button type="button" className="csg-btn csg-btn--primary csg-confirm" onClick={onClose} data-testid="button-camera-guide-confirm">확인 (닫기)</button>
      </div>
    </div>, document.body);
}

export function CameraConnectionBadge({ connected, connecting, mock }: { connected: boolean; connecting?: boolean; mock?: boolean }) {
  if (mock) return <span className="csg-badge is-mock" role="status" data-testid="status-camera-connection"><span className="csg-badge__dot" aria-hidden="true" />모의 촬영 · 실제 연결 아님</span>;
  if (connected) return <span className="csg-badge is-ok" role="status" data-testid="status-camera-connection"><span className="csg-badge__dot" aria-hidden="true" /><Camera aria-hidden="true" />카메라 정상 연결됨</span>;
  return <span className="csg-badge is-bad" role="status" data-testid="status-camera-connection">
    <span className="csg-badge__dot" aria-hidden="true" />휴대폰 Iriun 앱 확인 필요
    {connecting && <small><Loader2 className="csg-spin" aria-hidden="true" style={{ display: 'inline', verticalAlign: '-4px' }} /> 연결 확인 중</small>}
  </span>;
}

export function CameraPermissionDialog({ open, onClose, onOpenSettings, opening, error }: { open: boolean; onClose: () => void; onOpenSettings: () => void; opening: boolean; error?: string }) {
  const panelRef = useModal(open, onClose);
  if (!open) return null;
  return createPortal(
    <div className="csg-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={panelRef} className="csg-panel csg-perm" role="dialog" aria-modal="true" aria-label="카메라 사용이 꺼져 있어요" data-testid="dialog-camera-permission">
        <div className="csg-head">
          <div>
            <h2><CameraOff aria-hidden="true" style={{ width: 36, height: 36, verticalAlign: '-6px', marginRight: 10, color: '#ff8a73' }} />카메라 사용이 꺼져 있어요</h2>
            <p>Windows 설정에서 카메라 사용을 켜야 사진을 찍을 수 있습니다.</p>
          </div>
        </div>
        <ol>
          <li>아래 노란 버튼을 누르세요.</li>
          <li><b>카메라 액세스</b>를 <b>켬</b>으로 바꾸세요.</li>
          <li><b>데스크톱 앱이 카메라에 액세스하도록 허용</b>을 <b>켬</b>으로 바꾸세요.</li>
          <li>이 창으로 돌아와 다시 연결을 누르세요.</li>
        </ol>
        {opening && <p className="csg-status" role="status"><Loader2 className="csg-spin" aria-hidden="true" style={{ display: 'inline', width: 22, verticalAlign: '-5px' }} /> 설정 창을 여는 중입니다…</p>}
        {error && <p className="csg-error" role="alert" data-testid="error-camera-permission">{error}</p>}
        <div className="csg-actions">
          <button type="button" className="csg-btn csg-btn--primary" disabled={opening} onClick={onOpenSettings} data-autofocus data-testid="button-open-camera-settings"><Settings aria-hidden="true" />카메라 권한 켜기</button>
          <button type="button" className="csg-btn csg-btn--ghost" onClick={onClose} data-testid="button-camera-permission-close"><X aria-hidden="true" />닫기</button>
        </div>
      </div>
    </div>, document.body);
}
