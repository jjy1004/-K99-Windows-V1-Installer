export type NativePhotoSource={photoId:string;url:string;careLabelEligible:boolean};
export type NativePhotoInput={photoId?:string;pathHint?:string;orderId?:string;garmentId?:string};
export async function nativePhotoSource(input:NativePhotoInput):Promise<NativePhotoSource>{
  if(!window.k99Desktop?.photoSource)throw Error('Windows 사진 연결 기능을 포함한 최신 설치본이 필요합니다.');
  const source=await window.k99Desktop.photoSource(input);
  if(Array.isArray(source)||!source||typeof source.careLabelEligible!=='boolean'||
    !/^[A-Za-z0-9_-]{8,100}$/.test(source.photoId)||
    !/^k99:\/\/app\/(?:api\/equipment\/photos\/|local-photos\/)[A-Za-z0-9_-]{8,100}$/.test(source.url)||
    source.url.split('/').at(-1)!==source.photoId)
    throw Error('Windows 사진 연결 응답이 올바르지 않습니다.');
  return source;
}
export async function analyzeLoadedCareLabel(source:NativePhotoSource){
  if(source.careLabelEligible)await window.k99Desktop?.analyzeCareLabel?.(source.photoId,{automatic:true});
}
