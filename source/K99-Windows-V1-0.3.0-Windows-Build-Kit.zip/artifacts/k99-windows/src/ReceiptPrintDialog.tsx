import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, Info, Loader2, Printer, ReceiptText, X } from 'lucide-react';
import { equipmentRequest } from './equipment-client';
import './settings-hub.css';

export type ReceiptInput = {
  customerName: string; customerPhone: string; paymentType: 'PREPAID' | 'POSTPAID';
  items: { name: string; quantity: number; amount: number }[]; manualTagNumbers?: string[]; totalAmount?:number;
  discountAmount?:number;discountRate?:number;tierDiscountAmount?:number;
};
export type ReceiptConfig = { receiptPrinterName: string; receiptType: 'easycheck' | 'windows' | 'thermal' | 'none'; receiptWidth: 58 | 80; receiptPromo: string; receiptPort: string;
  receiptBaudRate?:9600|19200|38400|115200;receiptTransport?:'windows'|'serial';receiptEncoding?:'cp949'|'euc-kr';receiptCut?:boolean;receiptEscPosVerified?:boolean };

// 합의된 window.k99Desktop.hardwareSettings 확장 API를 느슨하게 호출한다 (타입은 메인 담당).
type HwApi = (req: Record<string, unknown>) => Promise<unknown>;
export const hwApi = (): HwApi | undefined =>
  (window as unknown as { k99Desktop?: { hardwareSettings?: HwApi } }).k99Desktop?.hardwareSettings;
export const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');
const NO_NATIVE = '실제 인쇄는 PC에 설치된 K99 프로그램에서만 됩니다. 지금 화면에서는 인쇄되지 않았습니다.';

/** 미리보기(srcDoc 샌드박스) + 58/80 선택 + 실제 인쇄 버튼 분리 */
export function ReceiptPreviewPane({ receipt, config, allowPrint }: { receipt?: ReceiptInput; config?: Partial<ReceiptConfig>; allowPrint: boolean }) {
  const [width, setWidth] = useState<58 | 80>(config?.receiptWidth ?? 80);
  const [widthReady,setWidthReady]=useState(config?.receiptWidth!==undefined);
  const previewSequence=useRef(0);
  const widthSelected=useRef(false);
  const [html, setHtml] = useState('');
  const [busy, setBusy] = useState<'preview' | 'print' | null>(null);
  const [line, setLine] = useState<{ tone: 'info' | 'err' | 'warn'; text: string } | null>(null);
  const cfgKey = JSON.stringify(config ?? {});
  const recKey = JSON.stringify(receipt ?? null);
  useEffect(()=>{
    if(config?.receiptWidth!==undefined){setWidth(config.receiptWidth);setWidthReady(true);return;}
    let live=true;
    const fn=hwApi();
    void (fn?fn({action:'receipt-preferences'}):equipmentRequest('receipt-preferences')).then(result=>{
      const saved=result as {config?:{receiptWidth?:number}};
      if(saved.config?.receiptWidth!==58&&saved.config?.receiptWidth!==80)throw Error('용지 폭 정보가 없습니다.');
      if(live&&!widthSelected.current){setWidth(saved.config.receiptWidth);setWidthReady(true);}
    }).catch(()=>{if(live&&!widthSelected.current)setLine({tone:'warn',text:'저장된 용지 폭을 확인하지 못했습니다. 아래에서 58mm 또는 80mm를 직접 선택해 주세요.'});});
    return()=>{live=false;};
  },[config?.receiptWidth]);
  const preview = useCallback(async () => {
    if(!widthReady)return;
    const sequence=++previewSequence.current;
    const fn = hwApi();
    setBusy('preview'); setLine(null);
    try {
      const input = { ...(receipt ? { receipt } : {}), config: { ...JSON.parse(cfgKey), receiptWidth: width } };
      // 설치형은 네이티브 브리지, 브라우저는 기존 equipmentRequest 경로로 같은 표준 양식을 받는다.
      const r = (fn ? await fn({ action: 'receipt-preview', ...input }) : await equipmentRequest<{ html?: string; message?: string }>('receipt-preview', input)) as { html?: string; message?: string };
      if(sequence===previewSequence.current){setHtml(r.html || ''); if (r.message) setLine({ tone: 'info', text: r.message });}
    } catch (e) { if(sequence===previewSequence.current){setHtml(''); setLine({ tone: 'err', text: `미리보기를 만들지 못했습니다: ${errText(e)}` });} }
    finally { if(sequence===previewSequence.current)setBusy(null); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recKey, cfgKey, width,widthReady]);
  useEffect(() => { void preview();return()=>{previewSequence.current++;}; }, [preview]);
  const print = async () => {
    const fn = hwApi();
    if (!fn) { setLine({ tone: 'warn', text: NO_NATIVE }); return; }
    if (!window.confirm(`실제 종이로 ${width}mm 접수증을 인쇄할까요?`)) return;
    setBusy('print'); setLine(null);
    try {
      const r = await fn({ action: 'receipt-print', ...(receipt ? { receipt } : {}), config: { ...JSON.parse(cfgKey), receiptWidth: width } }) as { message?: string };
      setLine({ tone: 'info', text: r.message || '인쇄 요청을 보냈습니다. 종이가 나왔는지 직접 확인해 주세요.' });
    } catch (e) { setLine({ tone: 'err', text: `인쇄하지 못했습니다: ${errText(e)} 하드웨어 > 카드단말기·영수증에서 프린터를 확인해 주세요.` }); }
    finally { setBusy(null); }
  };
  return (
    <div className="rp-pane">
      <div className="rp-controls">
        <div className="sh-seg" role="group" aria-label="용지 폭">
          {([58, 80] as const).map(w => <button key={w} type="button" aria-pressed={widthReady&&width === w} onClick={() => {widthSelected.current=true;setWidth(w);setWidthReady(true);}} data-testid={`button-receipt-width-${w}`}>{w}mm</button>)}
        </div>
        {allowPrint && <button type="button" className="sh-btn gold" disabled={!!busy||!widthReady||!html} onClick={() => void print()} data-testid="button-receipt-print-real">
          {busy === 'print' ? <Loader2 className="animate-spin" aria-hidden /> : <Printer aria-hidden />}실제 종이로 인쇄
        </button>}
      </div>
      <div className="rp-paper" data-width={width}>
        {busy === 'preview' && <div className="rp-skel" aria-label="미리보기 만드는 중"><i /><i /><i /><i /></div>}
        {!busy && html && <iframe title="접수증 미리보기" sandbox="" srcDoc={html} className="rp-frame" data-testid="frame-receipt-preview" />}
        {!busy && !html && <div className="rp-empty"><ReceiptText aria-hidden /><p>미리보기를 표시할 수 없습니다.</p></div>}
      </div>
      {line && <p className={`sh-line ${line.tone}`} role="status">{line.tone === 'info' ? <Info aria-hidden /> : <AlertTriangle aria-hidden />}{line.text}</p>}
    </div>
  );
}

export function ReceiptPrintDialog({ receipt, onClose }: { receipt: ReceiptInput; onClose: () => void }) {
  return createPortal(
    <div className="nc-backdrop" onKeyDown={e => { e.stopPropagation(); if (e.key === 'Escape') onClose(); }}>
      <div className="nc-modal narrow" role="dialog" aria-modal="true" aria-label="접수증 미리보기">
        <div className="nc-head">
          <div><h2>접수증 미리보기</h2><p>{receipt.customerName} 고객 · {receipt.paymentType === 'PREPAID' ? '선불' : '후불'} · {receipt.items.length}개 품목</p></div>
          <button type="button" className="nc-close" onClick={onClose}><X size={22} aria-hidden />닫기</button>
        </div>
        <p className="sh-line warn"><AlertTriangle aria-hidden />카드 승인 연동: 현장 연결 확인 대기 (이지체크 POS 세부 모델 확인 전). 이 접수증은 결제 승인 기록이 아니며, 카드 결제는 단말기에서 직접 확인해 주세요.</p>
        <ReceiptPreviewPane receipt={receipt} allowPrint />
      </div>
    </div>, document.body);
}
