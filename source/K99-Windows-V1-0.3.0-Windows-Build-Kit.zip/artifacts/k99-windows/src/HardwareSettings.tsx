import { useCallback, useEffect, useState, type JSX } from 'react';
import { AlertTriangle, BookOpen, Camera, CheckCircle2, ChevronLeft, CreditCard, Info, Loader2, Monitor, Printer, RefreshCw, Save, Tags } from 'lucide-react';
import { iriunDevices } from './iriun-camera';
import { openGuide } from './guide-data';
import { ReceiptPreviewPane, errText, hwApi } from './ReceiptPrintDialog';
import { ManualTagGuideButton } from './ManualTagGuide';
import { NumUnit } from './NumUnit';
import './hardware-settings.css';
import './settings-hub.css';

type TagMode = 'tsc' | 'xprinter' | 'roll' | 'none';
type ReceiptType = 'easycheck' | 'windows' | 'thermal' | 'none';
type HwConfig = {
  receiptVendor?: 'easycheck' | 'kis' | 'nice' | '';
  labelPrinterName: string; receiptPrinterName: string; cameraDeviceId: string; tagMode: TagMode; labelVerified?: boolean;
  receiptType: ReceiptType; receiptWidth: 58 | 80; receiptPromo: string; receiptPort: string;
  receiptBaudRate:9600|19200|38400|115200;receiptTransport:'windows'|'serial';receiptEncoding:'cp949'|'euc-kr';receiptCut:boolean;receiptEscPosVerified:boolean;
  manualTagNumbering?: 'customer' | 'legacy'; manualTagNextCustomer: number;
};
type HwStatus = { config: Partial<HwConfig>; printers?: { name: string; displayName?: string; port?: string }[]; ports?: { name: string }[]; native?: boolean; terminal?: { connected: boolean; message: string }; selection?: { state: 'configured' | 'disabled' | 'missing' | 'ambiguous'; message: string } };
type Tone = 'info' | 'ok' | 'warn' | 'err';
type Section = 'tag' | 'receipt' | 'camera' | 'monitor';

const EMPTY: HwConfig = { labelPrinterName: '', receiptPrinterName: '', cameraDeviceId: '', tagMode: 'tsc', receiptType: 'none', receiptWidth: 80, receiptPromo: '', receiptPort: '',
  receiptBaudRate:9600,receiptTransport:'windows',receiptEncoding:'cp949',receiptCut:false,receiptEscPosVerified:false,manualTagNextCustomer: 1 };
const TAG_MODES: [TagMode, string, string][] = [
  ['tsc', '라벨 프린터', '접수 시 라벨 자동 출력 · 택 번호 표시 안 함'],
  ['roll', '수기택', '고객번호-품목번호 (예 1-1, 1-2)'],
  ['none', '택 미사용', '택 번호를 쓰지 않음'],
];
const RECEIPT_TYPES: [ReceiptType, string, string][] = [
  ['easycheck', '이지체크 POS', '카드단말기 연결 출력기'],
  ['windows', 'Windows 드라이버', 'KIS · 스마트로 · 나이스 · 토스 등'],
  ['thermal', '일반 영수증 프린터', '58mm / 80mm 감열'],
  ['none', '미사용', '접수증을 출력하지 않음'],
];
const RECEIPT_VENDORS = [
  ['easycheck', '이지체크 / KICC'],
  ['kis', 'KIS정보통신'],
  ['nice', 'NICE / 스마트로'],
] as const;
const SECTIONS: [Section, string, string, typeof Tags][] = [
  ['tag', '세탁물 태그(라벨)', '택 방식과 번호', Tags],
  ['receipt', '카드 단말기·영수증 출력기', '접수증 출력기', CreditCard],
  ['camera', '촬영 카메라', 'Iriun Webcam 자동 연결', Camera],
  ['monitor', '고객용 보조 모니터', '고객용 화면 배치', Monitor],
];

function Line({ tone, text }: { tone: Tone; text: string }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle;
  return <div className={`nc-msg ${tone}`} role={tone === 'err' ? 'alert' : 'status'}><Icon size={22} aria-hidden /><div>{text}</div></div>;
}

export function HardwareSettings({ initialSection }: { initialSection?: Section } = {}): JSX.Element {
  const [section, setSection] = useState<Section | null>(initialSection ?? null);
  const [cfg, setCfg] = useState<HwConfig>(EMPTY);
  const [printers, setPrinters] = useState<NonNullable<HwStatus['printers']>>([]);
  const [ports, setPorts] = useState<NonNullable<HwStatus['ports']>>([]);
  const [terminal, setTerminal] = useState<HwStatus['terminal']>();
  const [native, setNative] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [tagNumberText, setTagNumberText] = useState('1');
  const [tagNumberEdited, setTagNumberEdited] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [receiptDetails, setReceiptDetails] = useState(false);
  const available = !!hwApi() && native;

  const apply = (s: HwStatus) => {
    const next = { ...EMPTY, ...s.config } as HwConfig;
    setCfg(next); setTagNumberText(String(next.manualTagNextCustomer || 1)); setTagNumberEdited(false);
    setPrinters(s.printers || []); setPorts(s.ports || []); setTerminal(s.terminal); setNative(!!s.native);
    if(s.selection)setLine({tone:s.selection.state==='configured'?'info':'warn',text:s.selection.message});
    else if('printerMessage' in s&&s.printerMessage)setLine({tone:'warn',text:String(s.printerMessage)});
  };
  const load = useCallback(async () => {
    const fn = hwApi(); setLoading(true); setLine(null);
    if (!fn) { setNative(false); setLoading(false); return; }
    try { apply(await fn({ action: 'status' }) as HwStatus); }
    catch (e) { setLine({ tone: 'err', text: `장치 정보를 불러오지 못했습니다: ${errText(e)}` }); }
    finally { setLoading(false); }
  }, []);
  const listCams = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try { setCams(iriunDevices(await navigator.mediaDevices.enumerateDevices())); } catch { /* 목록 없음 */ }
  }, []);
  useEffect(() => { void load(); void listCams(); }, [load, listCams]);
  useEffect(() => { setLine(null); setShowPreview(false); setReceiptDetails(false); }, [section]);

  const savePart = async (action: string, config: Record<string, unknown>, done: string) => {
    const fn = hwApi();
    if (!fn || !available) { setLine({ tone: 'warn', text: '저장은 PC에 설치된 K99 프로그램에서만 됩니다. 지금은 저장되지 않았습니다.' }); return; }
    if (busy) return; setBusy(action); setLine(null);
    try {
      apply(await fn({ action, config }) as HwStatus);
      window.dispatchEvent(new Event('k99-hardware-settings-changed'));
      window.dispatchEvent(new Event('k99-equipment-changed'));
      setLine({ tone: 'ok', text: done });
    } catch (e) { setLine({ tone: 'err', text: `저장하지 못했습니다: ${errText(e)}` }); }
    finally { setBusy(null); }
  };

  const saveTag = () => {
    const n = Number(tagNumberText);
    if (cfg.tagMode === 'roll' && tagNumberEdited && (!Number.isInteger(n) || n < 1 || n > 10000)) {
      setLine({ tone: 'err', text: '시작 고객 번호는 1부터 10000 사이 숫자로 적어 주세요.' }); return;
    }
    void savePart('save-tag', {
      tagMode: cfg.tagMode, labelPrinterName: cfg.labelPrinterName, labelVerified: cfg.labelVerified === true,
      manualTagNumbering: 'customer', manualTagNextCustomer: tagNumberEdited ? n : cfg.manualTagNextCustomer,
      ...(tagNumberEdited ? { manualTagReset: true } : {}),
    }, '택 설정을 저장했습니다. 이미 쓴 번호는 바뀌지 않습니다.');
  };
  const receiptConfig = { receiptVendor: cfg.receiptVendor, receiptPrinterName: cfg.receiptPrinterName, receiptType: cfg.receiptType, receiptWidth: cfg.receiptWidth, receiptPromo: cfg.receiptPromo, receiptPort: cfg.receiptPort,
    receiptBaudRate:cfg.receiptBaudRate,receiptTransport:cfg.receiptTransport,receiptEncoding:cfg.receiptEncoding,receiptCut:cfg.receiptCut,receiptEscPosVerified:cfg.receiptEscPosVerified };
  const selectedVendor = cfg.receiptType === 'none' ? '' : cfg.receiptVendor || (cfg.receiptType === 'easycheck' ? 'easycheck' : '');
  const selectVendor = async (vendor: 'easycheck' | 'kis' | 'nice') => {
    if (busy) return;
    const fn = hwApi();
    if (!fn || !available) { setLine({ tone: 'warn', text: '장치 자동 선택은 Windows에 설치된 K99 프로그램에서 사용할 수 있습니다. 지금은 설정이 바뀌지 않았습니다.' }); return; }
    setBusy('select-vendor'); setLine(null);
    try {
      const r = await fn({ action: 'select-receipt-vendor', vendor }) as HwStatus;
      apply(r);
      window.dispatchEvent(new Event('k99-hardware-settings-changed'));
      setLine({ tone: r.selection?.state === 'configured' || r.selection?.state === 'disabled' ? 'ok' : 'warn',
        text: r.selection?.message || '설정을 확인해 주세요.' });
    } catch (e) { setLine({ tone: 'err', text: `기존 설정은 유지했습니다: ${errText(e)}` }); }
    finally { setBusy(null); }
  };

  const test = async (kind: 'label' | 'receipt') => {
    const fn = hwApi();
    if (!fn || !available) { setLine({ tone: 'warn', text: '테스트 인쇄는 PC에 설치된 K99 프로그램에서만 됩니다. 인쇄되지 않았습니다.' }); return; }
    const printerName = kind === 'label' ? cfg.labelPrinterName : cfg.receiptPrinterName;
    if (kind==='label'&&!printerName) { setLine({ tone: 'err', text: '라벨 프린터를 먼저 골라 주세요.' }); return; }
    if (!window.confirm('저장된 설정으로 실제 종이 한 장이 인쇄됩니다. 변경한 영수증 설정은 먼저 저장하세요. 테스트 인쇄는 결제·선불 처리가 아닙니다. 진행할까요?')) return;
    setBusy(kind); setLine(null);
    try {
      const r = await fn({ action: 'test', kind, ...(kind === 'label' ? { printerName } : {}) }) as { message?: string };
      setLine({ tone: 'info', text: r.message || '인쇄 요청을 보냈습니다. 종이가 나왔는지 확인해 주세요.' });
    } catch (e) { setLine({ tone: 'err', text: `테스트 인쇄 실패: ${errText(e)}` }); }
    finally { setBusy(null); }
  };
  const display = async () => {
    const fn = hwApi();
    if (!fn || !available) { setLine({ tone: 'warn', text: 'Windows 디스플레이 설정은 설치된 K99 프로그램에서 열 수 있습니다.' }); return; }
    setBusy('display');
    try { const r = await fn({ action: 'display-settings' }) as { message?: string }; setLine({ tone: 'info', text: r.message || 'Windows 디스플레이 설정을 열었습니다.' }); }
    catch (e) { setLine({ tone: 'err', text: `디스플레이 설정 열기 실패: ${errText(e)}` }); }
    finally { setBusy(null); }
  };
  const printerSelect = (id: string, label: string, key: 'labelPrinterName' | 'receiptPrinterName') => {
    const v = cfg[key]; const missing = v && !printers.some(p => p.name === v);
    return <div>
      <label className="nc-label" htmlFor={id}>{label}</label>
      <select id={id} className="nc-input" value={v} disabled={!!busy} data-testid={`select-${id}`}
        onChange={e => setCfg({ ...cfg, [key]: e.target.value, ...(key === 'labelPrinterName' ? { labelVerified: false, ...(cfg.tagMode === 'tsc' || cfg.tagMode === 'xprinter' ? { tagMode: /xprinter|^xp[- ]/i.test(e.target.value) ? 'xprinter' as const : 'tsc' as const } : {}) } : {}) })}>
        <option value="">선택 안 함</option>
        {missing && <option value={v}>{v} (현재 연결 안 됨)</option>}
        {printers.map(p => <option key={p.name} value={p.name}>{p.displayName || p.name}{p.port ? ` · ${p.port}` : ''}</option>)}
      </select>
      {available && !printers.length && <p className="nc-hint">이 PC에 설치된 프린터가 없습니다. 드라이버 설치 후 [다시 불러오기]를 눌러 주세요.</p>}
    </div>;
  };
  const guideBtn = (topic: string, text: string) =>
    <button type="button" className="sh-btn ghost" onClick={() => openGuide('setup', topic)} data-testid={`button-guide-${topic}`}><BookOpen aria-hidden />{text}</button>;

  const head = !loading && !available
    ? <Line tone="warn" text="프린터·카메라 저장과 실제 인쇄는 PC에 설치된 K99 프로그램에서만 됩니다. 이 화면에서는 확인과 그림 설명서만 볼 수 있습니다." /> : null;

  if (!section) return (
    <section className="sh-sub" aria-label="하드웨어 설정">
      {head}{loading && <Line tone="info" text="장치 정보를 불러오는 중입니다…" />}
      <div className="sh-tiles four">
        {SECTIONS.map(([id, t, s, Icon], i) => <button key={id} type="button" className={`sh-tile c${i + 6}`} onClick={() => setSection(id)} data-testid={`button-hw-${id}`}>
          <Icon aria-hidden /><b>{t}</b><small>{s}</small></button>)}
      </div>
    </section>
  );

  const title = SECTIONS.find(s => s[0] === section)![1];
  return (
    <section className="sh-sub" aria-label={title}>
      <div className="sh-subhead">
        <button type="button" className="sh-back" onClick={() => setSection(null)} data-testid="button-hw-back"><ChevronLeft aria-hidden />하드웨어 메뉴로</button>
        <h3>{title}</h3>
        <button type="button" className="sh-btn ghost" disabled={!!busy} onClick={() => void load()}><RefreshCw aria-hidden />다시 불러오기</button>
      </div>
      {head}

      {section === 'tag' && <div className="sh-body">
        <div className="sh-choice" role="group" aria-label="택 방식">
          {TAG_MODES.map(([m, t, s]) => <button key={m} type="button" data-testid={`button-tag-mode-${m}`}
            aria-pressed={m === 'tsc' ? cfg.tagMode === 'tsc' || cfg.tagMode === 'xprinter' : cfg.tagMode === m}
            onClick={() => setCfg({ ...cfg, tagMode: m === 'tsc' && /xprinter|^xp[- ]/i.test(cfg.labelPrinterName) ? 'xprinter' : m })}><b>{t}</b><small>{s}</small></button>)}
        </div>
        {(cfg.tagMode === 'tsc' || cfg.tagMode === 'xprinter') && <>
          {printerSelect('hw-label', '라벨 프린터', 'labelPrinterName')}
          <label className="sh-check"><input type="checkbox" checked={cfg.labelVerified === true} disabled={!cfg.labelPrinterName}
            onChange={e => setCfg({ ...cfg, labelVerified: e.target.checked })} /> 30mm 라벨 글씨·바코드가 정상으로 나오는 것을 직접 확인했습니다.</label>
          <p className="nc-hint">라벨 프린터를 쓰면 접수 화면에 택 번호를 따로 표시하지 않습니다.</p>
        </>}
        {cfg.tagMode === 'roll' && <div className="sh-manual">
          <label className="nc-label" htmlFor="hw-tag-next">다음 신규 고객 번호 (1~10000)</label>
          <input id="hw-tag-next" className="nc-input sh-num" inputMode="numeric"
            value={cfg.manualTagNumbering==='legacy'&&!tagNumberEdited?'':tagNumberText}
            placeholder="기존 번호와 겹치지 않게 자동 선택" data-testid="input-manual-tag-next"
            onChange={e => { setTagNumberText(e.target.value.replace(/\D/g, '').slice(0, 5)); setTagNumberEdited(true); }} />
          {cfg.manualTagNumbering==='legacy'&&!tagNumberEdited
            ?<p className="sh-example">기존 묶음형 택 번호는 그대로 보존합니다. 새 고객 번호는 기존 번호와 겹치지 않도록 자동 선택합니다. 원하는 시작 번호가 있으면 직접 입력하세요.</p>
            :<p className="sh-example">예) 이 번호가 <b>{tagNumberText || '1'}</b>이면 새 고객 택은 <b>{tagNumberText || '1'}-1, {tagNumberText || '1'}-2</b>, 다음 고객은 <b>{(Number(tagNumberText) || 1) + 1}-1</b>입니다.</p>}
          <p className="nc-hint">{tagNumberEdited ? '번호를 바꾸셨습니다. 저장하면 다음 신규 고객부터 이 번호로 시작합니다.' : '번호를 고치지 않고 저장하면 지금 이어지는 번호를 그대로 씁니다.'} 이미 접수된 번호는 바뀌지 않습니다.</p>
        </div>}
        <div className="sh-actions">
          <button type="button" className="sh-btn gold" disabled={!!busy} onClick={saveTag} data-testid="button-save-tag">{busy === 'save-tag' ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}택 설정 저장</button>
          {(cfg.tagMode === 'tsc' || cfg.tagMode === 'xprinter') && <button type="button" className="sh-btn ghost" disabled={!!busy} onClick={() => void test('label')}><Printer aria-hidden />라벨 테스트 인쇄</button>}
          <ManualTagGuideButton />
        </div>
      </div>}

      {section === 'receipt' && <div className="sh-body">
        <div className="sh-choice" role="group" aria-label="단말기 회사 자동 선택">
          {RECEIPT_VENDORS.map(([id, name]) => <button key={id} type="button"
            data-testid={`button-receipt-vendor-${id}`} aria-pressed={selectedVendor === id} disabled={!!busy}
            onClick={() => void selectVendor(id)}><b>{name}</b><small>설치된 출력기 자동 선택</small></button>)}
        </div>
        <p className="sh-big" data-testid="receipt-selection-status">{cfg.receiptType === 'none' ? '미사용' :
          cfg.receiptTransport === 'serial' ? '저장된 단말기 출력 설정 사용 중' :
          cfg.receiptPrinterName ? `선택된 출력기: ${cfg.receiptPrinterName}` : '출력기 연결 확인 필요'}</p>
        <p className="nc-hint">연결 여부와 관계없이 회사를 선택할 수 있습니다. 장치가 명확하면 선택·저장하고, 미연결·여러 대이면 회사 기본값을 채웁니다. 상세 설정을 확인하고 저장하세요. 같은 회사 재선택과 자동 감지는 저장한 세부 설정을 덮어쓰지 않습니다. 카드 승인과 실제 출력은 별도로 확인해 주세요.</p>
        <button type="button" className="sh-btn ghost" aria-expanded={receiptDetails} aria-controls="receipt-advanced-settings"
          data-testid="button-receipt-details" onClick={() => setReceiptDetails(v => !v)}>
          <Printer aria-hidden />일반 영수증 프린터 상세 설정{receiptDetails ? ' 닫기' : ''}
        </button>
        {receiptDetails && <section id="receipt-advanced-settings" aria-label="일반 영수증 프린터 상세 설정" className="sh-body">
        <div className="sh-choice four" role="group" aria-label="영수증 출력기 유형">
          {RECEIPT_TYPES.map(([t, n, s]) => <button key={t} type="button" aria-pressed={cfg.receiptType === t} data-testid={`button-receipt-type-${t}`}
            onClick={() => setCfg({ ...cfg, receiptType: t, receiptVendor: '' })}><b>{n}</b><small>{s}</small></button>)}
        </div>
        <p className="sh-line warn"><AlertTriangle aria-hidden />접수증 출력은 카드 승인과 다릅니다. 기존에 저장한 출력 방식·통신 설정은 직접 바꾸기 전까지 유지됩니다.</p>
        <p className="nc-hint" data-testid="status-card-terminal">카드단말기 상태: {terminal?.connected ? terminal.message : `현장 연결 확인 대기${terminal?.message ? ` — ${terminal.message}` : ''}`}</p>
        {cfg.receiptType !== 'none' && <div className="nc-grid2">
          <div>
            <label className="nc-label" htmlFor="hw-transport">접수증 전송 방식</label>
            <select id="hw-transport" className="nc-input" value={cfg.receiptTransport} data-testid="select-receipt-transport"
              onChange={e=>setCfg({...cfg,receiptTransport:e.target.value as HwConfig['receiptTransport'],receiptEscPosVerified:false})}>
              <option value="windows">Windows 프린터 드라이버 (기존 방식)</option>
              <option value="serial">COM 포트 직접 출력 (ESC/POS 호환 확인 필요)</option>
            </select>
          </div>
          {cfg.receiptTransport==='windows'&&printerSelect('hw-receipt', '영수증 프린터', 'receiptPrinterName')}
          <div>
            <label className="nc-label" htmlFor="hw-port">연결 포트</label>
            <select id="hw-port" className="nc-input" value={cfg.receiptPort} onChange={e => setCfg({ ...cfg, receiptPort: e.target.value,receiptEscPosVerified:false })} data-testid="select-receipt-port">
              <option value="">{cfg.receiptTransport==='serial'?'COM 포트를 선택하세요':'자동 (프린터 기본)'}</option>
              {cfg.receiptPort && !ports.some(p => p.name === cfg.receiptPort) && <option value={cfg.receiptPort}>{cfg.receiptPort} (현재 없음)</option>}
              {ports.map(p => <option key={p.name} value={p.name}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="nc-label" htmlFor="hw-baud">통신 속도 (기본 9600 bps)</label>
            <select id="hw-baud" className="nc-input" value={cfg.receiptBaudRate} data-testid="select-receipt-baud"
              onChange={e=>setCfg({...cfg,receiptBaudRate:Number(e.target.value) as HwConfig['receiptBaudRate']})}>
              {[9600,19200,38400,115200].map(n=><option key={n} value={n}>{n} bps{n===9600?' (출고 기본값)':''}</option>)}
            </select>
          </div>
          <div>
            <label className="nc-label" htmlFor="hw-encoding">한글 인코딩</label>
            <select id="hw-encoding" className="nc-input" value={cfg.receiptEncoding} data-testid="select-receipt-encoding"
              onChange={e=>setCfg({...cfg,receiptEncoding:e.target.value as HwConfig['receiptEncoding'],receiptEscPosVerified:false})}>
              <option value="cp949">CP949 (한글 기본)</option><option value="euc-kr">EUC-KR</option>
            </select>
          </div>
          <p className="nc-hint">신규 시리얼 설정은 9600 bps(8비트·패리티 없음·정지 1비트)가 기본입니다. 직접 시리얼 모드는 저장한 속도를 실제 포트에 적용합니다. Windows 드라이버 모드는 드라이버가 통신 속도를 관리하므로 Windows 프린터 포트 설정도 별도로 확인해 9600으로 맞춰 주세요. 기존에 저장한 다른 정상 속도는 유지됩니다. 카드 승인과 접수증 인쇄는 다릅니다.</p>
          {cfg.receiptTransport==='serial'&&<div data-testid="receipt-serial-safety">
            <p className="nc-hint">TS-167 등 카드단말기는 전용 연동 프로그램이 필요할 수 있습니다. 제조사에 ESC/POS·한글 모드 지원을 확인하기 전에는 직접 출력하지 마세요.</p>
            <label><input type="checkbox" checked={cfg.receiptEscPosVerified} onChange={e=>setCfg({...cfg,receiptEscPosVerified:e.target.checked})}/>이 포트의 기기가 ESC/POS·선택한 한글 인코딩을 지원함을 확인했습니다.</label>
            <label><input type="checkbox" checked={cfg.receiptCut} onChange={e=>setCfg({...cfg,receiptCut:e.target.checked})}/>자동 절단 지원 기기에서만 용지 절단 사용</label>
          </div>}
          <div>
            <span className="nc-label">용지 폭</span>
            <div className="sh-seg" role="group" aria-label="용지 폭">
              {([58, 80] as const).map(w => <button key={w} type="button" aria-pressed={cfg.receiptWidth === w} onClick={() => setCfg({ ...cfg, receiptWidth: w })}>{w}mm</button>)}
            </div>
          </div>
        </div>}
        </section>}
        <div style={{padding:16,border:'2px solid #eab308',borderRadius:12,margin:'16px 0'}}>
          <label className="nc-label" htmlFor="hw-promo">접수증 최상단 홍보 문구 (최대 2줄)</label>
          <textarea id="hw-promo" className="nc-input sh-promo" lang="ko" rows={2} value={cfg.receiptPromo}
            placeholder={'첫째 줄 홍보 문구를 적으세요\n둘째 줄 홍보 문구를 적으세요 (선택)'}
            data-testid="input-receipt-promo"
            onChange={e=>setCfg({...cfg,receiptPromo:e.target.value.replace(/\r\n?/g,'\n').split('\n').slice(0,2).map(l=>l.slice(0,40)).join('\n')})}/>
          <p>저장하면 접수증 미리보기와 실제 인쇄물 맨 위에 같은 문구가 표시됩니다. 비워 두면 빈 여백 없이 매장명부터 출력합니다.</p>
        </div>
        <div className="sh-actions">
          <button type="button" className="sh-btn gold" disabled={!!busy} onClick={() => void savePart('save-receipt', receiptConfig, '영수증 설정을 저장했습니다.')} data-testid="button-save-receipt">
            {busy === 'save-receipt' ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}설정 저장</button>
          <button type="button" className="sh-btn" onClick={() => setShowPreview(v => !v)} data-testid="button-receipt-preview">{showPreview ? '미리보기 닫기' : '미리보기'}</button>
          {cfg.receiptType !== 'none' && <button type="button" className="sh-btn ghost" disabled={!!busy} onClick={() => void test('receipt')} data-testid="button-receipt-test"><Printer aria-hidden />실제 테스트 인쇄</button>}
          {guideBtn('receipt', '영수증 그림 설명')}
        </div>
        {showPreview && <ReceiptPreviewPane config={receiptConfig} allowPrint={false} />}
      </div>}

      {section === 'camera' && <div className="sh-body">
        <h3 className="nc-label">Iriun Webcam 전용 자동 연결</h3>
        <p className="sh-big" data-testid="iriun-auto-status">{cams.length ? <>Iriun 수신기 <NumUnit>{cams.length}개</NumUnit> 감지됨</> : '휴대폰과 PC에서 Iriun Webcam을 켜 주세요.'}</p>
        <p className="nc-hint">휴대폰의 Wi-Fi를 끄고 USB 데이터 케이블을 PC 본체 뒷면에 직접 연결해 주세요. 장치를 고르거나 저장할 필요가 없습니다. 촬영 창을 열면 자동 연결하고, 신호가 없으면 실패 확인 후 1초 간격으로 계속 다시 찾습니다. 응답이 멈추면 촬영 환경만 다시 준비하며 접수 내용은 유지됩니다.</p>
        <div className="sh-actions">
          <button type="button" className="sh-btn ghost" onClick={() => void listCams()}><RefreshCw aria-hidden />Iriun 연결 상태 확인</button>
          {guideBtn('usb', '촬영 휴대폰 연결 그림')}
        </div>
      </div>}

      {section === 'monitor' && <div className="sh-body">
        <p className="sh-big">고객용 보조 모니터의 위치·확장·해상도는 Windows 디스플레이 설정에서 바꿉니다.</p>
        <div className="sh-actions">
          <button type="button" className="sh-btn gold" disabled={!!busy} onClick={() => void display()} data-testid="button-display-settings"><Monitor aria-hidden />모니터 배치 설정 열기</button>
          {guideBtn('menu', '설정 메뉴 그림')}
        </div>
      </div>}
      {line && <Line tone={line.tone} text={line.text} />}
    </section>
  );
}

export default HardwareSettings;
