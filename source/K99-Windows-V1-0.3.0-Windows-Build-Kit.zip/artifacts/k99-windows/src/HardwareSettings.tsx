import { useCallback, useEffect, useState, type JSX } from 'react';
import { AlertTriangle, Camera, CheckCircle2, Info, Loader2, Monitor, Printer, RefreshCw, Save } from 'lucide-react';
import { selectableCameras } from './camera-device';
import './hardware-settings.css';

type TagMode = 'tsc' | 'xprinter' | 'roll';
type HwConfig = { labelPrinterName: string; receiptPrinterName: string; cameraDeviceId: string; tagMode: TagMode; labelVerified?:boolean };
type HwStatus = { config: HwConfig; printers: { name: string; displayName: string }[]; native: boolean };
type Tone = 'info' | 'ok' | 'warn' | 'err';

const EMPTY: HwConfig = { labelPrinterName: '', receiptPrinterName: '', cameraDeviceId: '', tagMode: 'tsc' };
const MODES: [TagMode, string, string][] = [
  ['tsc', '라벨 프린터 자동 출력', '선택한 프린터로 라벨 출력'],
  ['roll', '기성 롤태그', '프린터 없이 기존 연번 채번 사용'],
];
const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');

function Line({ tone, text }: { tone: Tone; text: string }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle;
  return <div className={`nc-msg ${tone}`} role={tone === 'err' ? 'alert' : 'status'}><Icon size={22} aria-hidden /><div>{text}</div></div>;
}

// API 타입은 desktop-runtime.ts에 선언되어 있으나, 이 파일은 느슨하게 접근한다.
type HwApi = (req: Record<string, unknown>) => Promise<unknown>;
const api = (): HwApi | undefined =>
  (window as unknown as { k99Desktop?: { hardwareSettings?: HwApi } }).k99Desktop?.hardwareSettings;

export function HardwareSettings(): JSX.Element {
  const [cfg, setCfg] = useState<HwConfig>(EMPTY);
  const [printers, setPrinters] = useState<HwStatus['printers']>([]);
  const [native, setNative] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [camLine, setCamLine] = useState<{ tone: Tone; text: string } | null>(null);
  const available = !!api() && native;

  const apply = (s: HwStatus) => { setCfg({ ...EMPTY, ...s.config }); setPrinters(s.printers || []); setNative(!!s.native); };

  const load = useCallback(async () => {
    const fn = api(); setLoading(true); setLine(null);
    if (!fn) { setNative(false); setLoading(false); return; }
    try { apply(await fn({ action: 'status' }) as HwStatus); }
    catch (e) { setLine({ tone: 'err', text: `하드웨어 설정을 불러오지 못했습니다: ${errText(e)}` }); }
    finally { setLoading(false); }
  }, []);

  const listCams = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) { setCamLine({ tone: 'warn', text: '이 환경에서는 카메라 목록을 확인할 수 없습니다.' }); return; }
    try { setCams(selectableCameras(await navigator.mediaDevices.enumerateDevices())); }
    catch (e) { setCamLine({ tone: 'err', text: `카메라 목록 확인 실패: ${errText(e)}` }); }
  }, []);

  useEffect(() => { void load(); void listCams(); }, [load, listCams]);

  const askPermission = async () => {
    if (busy) return; setBusy('cam'); setCamLine(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      s.getTracks().forEach(t => t.stop());
      await listCams();
      setCamLine({ tone: 'ok', text: '카메라 이름을 불러왔습니다. 목록에서 골라 주세요.' });
    } catch (e) { setCamLine({ tone: 'err', text: `카메라 권한을 얻지 못했습니다: ${errText(e)} Windows 개인정보 설정의 카메라 권한을 확인하세요.` }); }
    finally { setBusy(null); }
  };

  const save = async () => {
    const fn = api(); if (!fn || !available || busy) return;
    setBusy('save'); setLine(null);
    try {
      apply(await fn({ action: 'save', config: cfg }) as HwStatus);
      window.dispatchEvent(new Event('k99-hardware-settings-changed'));
      window.dispatchEvent(new Event('k99-equipment-changed'));
      setLine({ tone: 'ok', text: '하드웨어 설정을 저장했습니다. 접수 화면에 바로 적용됩니다.' });
    } catch (e) { setLine({ tone: 'err', text: `하드웨어 저장 실패: ${errText(e)}` }); }
    finally { setBusy(null); }
  };

  const test = async (kind: 'label' | 'receipt') => {
    const fn = api(); if (!fn || !available || busy) return;
    const printerName = kind === 'label' ? cfg.labelPrinterName : cfg.receiptPrinterName;
    if (!printerName) { setLine({ tone: 'err', text: `${kind === 'label' ? '라벨' : '영수증'} 프린터를 먼저 골라 주세요.` }); return; }
    if (!window.confirm(`실제로 종이 한 장이 인쇄됩니다. ${kind === 'label' ? '라벨' : '영수증'} 테스트 인쇄를 할까요?`)) return;
    setBusy(kind); setLine(null);
    try { const r = await fn({ action: 'test', kind, printerName }) as { message: string }; setLine({ tone: 'info', text: r.message || '인쇄 요청을 보냈습니다. 종이가 나왔는지 확인해 주세요.' }); }
    catch (e) { setLine({ tone: 'err', text: `테스트 인쇄 실패: ${errText(e)}` }); }
    finally { setBusy(null); }
  };

  const display = async () => {
    const fn = api(); if (!fn || !available || busy) return;
    setBusy('display'); setLine(null);
    try { const r = await fn({ action: 'display-settings' }) as { message: string }; setLine({ tone: 'info', text: r.message || 'Windows 디스플레이 설정을 열었습니다.' }); }
    catch (e) { setLine({ tone: 'err', text: `디스플레이 설정 열기 실패: ${errText(e)}` }); }
    finally { setBusy(null); }
  };

  const printerSelect = (id: string, label: string, key: 'labelPrinterName' | 'receiptPrinterName') => {
    const v = cfg[key];
    const missing = v && !printers.some(p => p.name === v);
    return <>
      <label className="nc-label" htmlFor={id}>{label}</label>
      <select id={id} className="nc-input" value={v} disabled={!available || !!busy} onChange={e => setCfg({ ...cfg, [key]: e.target.value,...(key==='labelPrinterName'?{labelVerified:false,...(cfg.tagMode!=='roll'?{tagMode:/xprinter|^xp[- ]/i.test(e.target.value)?'xprinter' as const:'tsc' as const}:{})}:{}) })}>
        <option value="">선택 안 함</option>
        {missing && <option value={v}>{v} (현재 연결 안 됨)</option>}
        {printers.map(p => <option key={p.name} value={p.name}>{p.displayName || p.name}</option>)}
      </select>
    </>;
  };

  const camMissing = cfg.cameraDeviceId && !cams.some(c => c.deviceId === cfg.cameraDeviceId);

  return (
    <section className="hw-panel" aria-label="하드웨어 · 인쇄기 · 모니터 일괄 설정">
      <h3>하드웨어 · 인쇄기 · 모니터 일괄 설정</h3>
      <p className="hw-sub">이 칸은 위의 매장 설정 [저장하기]와 따로 저장됩니다. 아래 [하드웨어 설정 저장] 버튼을 눌러 주세요.</p>
      {!loading && !available && <Line tone="warn" text="프린터·카메라 저장과 테스트 인쇄는 PC에 설치된 K99 프로그램에서만 가능합니다. 지금 화면에서는 확인만 할 수 있습니다." />}
      {loading && <Line tone="info" text="장치 정보를 불러오는 중입니다…" />}

      <div className="hw-block">
        <h4><Printer size={20} aria-hidden /> 라벨(택) 프린터</h4>
        {printerSelect('hw-label', '라벨 프린터 선택', 'labelPrinterName')}
        <div className="hw-modes" role="group" aria-label="라벨 출력 방식">
          {MODES.map(([m, t, s]) => (
            <button key={m} type="button" className="hw-mode" aria-pressed={m==='tsc'?cfg.tagMode!=='roll':cfg.tagMode === m} disabled={!available || !!busy} onClick={() => setCfg({ ...cfg, tagMode: m==='tsc'&&/xprinter|^xp[- ]/i.test(cfg.labelPrinterName)?'xprinter':m })}>
              {t}<small>{s}</small>
            </button>
          ))}
        </div>
        <div className="nc-row">
          <button type="button" className="nc-big ghost" disabled={!available || !!busy} onClick={() => test('label')}>
            {busy === 'label' ? <Loader2 className="animate-spin" aria-hidden /> : <Printer aria-hidden />}라벨 테스트 인쇄
          </button>
        </div>
        <p className="hw-warn">테스트 인쇄를 누르면 실제로 라벨 한 장이 출력됩니다.</p>
        <label className="nc-label"><input type="checkbox" checked={cfg.labelVerified===true}
          disabled={!available||!!busy||cfg.tagMode==='roll'||!cfg.labelPrinterName}
          onChange={e=>setCfg({...cfg,labelVerified:e.target.checked})}/> 30mm 라벨의 글씨·바코드 출력이 정상인 것을 직접 확인했습니다.</label>
      </div>

      <div className="hw-block">
        <h4><Printer size={20} aria-hidden /> 고객 접수증 · 영수증 출력기 (별도 지정)</h4>
        <p className="nc-hint">신용카드 단말기는 Windows 프린터로 등록된 경우에만 목록에서 선택할 수 있습니다.</p>
        {printerSelect('hw-receipt', '영수증 프린터 선택', 'receiptPrinterName')}
        <div className="nc-row">
          <button type="button" className="nc-big ghost" disabled={!available || !!busy} onClick={() => test('receipt')}>
            {busy === 'receipt' ? <Loader2 className="animate-spin" aria-hidden /> : <Printer aria-hidden />}영수증 테스트 인쇄
          </button>
        </div>
        <p className="hw-warn">테스트 인쇄를 누르면 실제로 영수증 한 장이 출력됩니다.</p>
      </div>

      <div className="hw-block">
        <h4><Camera size={20} aria-hidden /> 촬영 카메라</h4>
        <label className="nc-label" htmlFor="hw-cam">카메라 선택</label>
        <select id="hw-cam" className="nc-input" value={cfg.cameraDeviceId} disabled={!available || !!busy} onChange={e => setCfg({ ...cfg, cameraDeviceId: e.target.value })}>
          <option value="">자동 (연결된 휴대폰·외장 카메라)</option>
          {camMissing && <option value={cfg.cameraDeviceId}>저장된 카메라 (현재 연결 안 됨)</option>}
          {cams.map(c => <option key={c.deviceId} value={c.deviceId}>{c.label}</option>)}
        </select>
        <p className="nc-hint">이 PC에 연결된 휴대폰 카메라와 외장 USB 카메라 목록입니다. 가상 영상 출력 장치는 제외합니다.</p>
        <p className="nc-hint">기본 카메라 변경은 다음 촬영 창 열기부터 적용됩니다. 현재 촬영 중인 영상은 끊지 않습니다.</p>
        <div className="nc-row">
          <button type="button" className="nc-big ghost" disabled={!!busy} onClick={askPermission}>
            {busy === 'cam' ? <Loader2 className="animate-spin" aria-hidden /> : <Camera aria-hidden />}카메라 이름 불러오기 (권한 허용)
          </button>
          <button type="button" className="nc-big ghost" disabled={!!busy} onClick={() => void listCams()}><RefreshCw aria-hidden />목록 새로고침</button>
        </div>
        {camLine && <Line tone={camLine.tone} text={camLine.text} />}
      </div>

      <div className="hw-block">
        <h4><Monitor size={20} aria-hidden /> 모니터 (고객용 화면)</h4>
        <p className="nc-hint">모니터 배치·확장·해상도는 Windows 디스플레이 설정에서 바꿉니다.</p>
        <div className="nc-row">
          <button type="button" className="nc-big ghost" disabled={!available || !!busy} onClick={display} aria-label="모니터 배치 설정 · Windows 디스플레이 설정 열기">
            {busy === 'display' ? <Loader2 className="animate-spin" aria-hidden /> : <Monitor aria-hidden />}모니터 배치 설정
          </button>
        </div>
      </div>

      <div className="hw-save-bar">
        <p>프린터·라벨 방식·카메라 선택은 이 버튼으로만 저장됩니다.</p>
        <div className="nc-row">
          <button type="button" className="nc-big gold" disabled={!available || !!busy} onClick={save} aria-label="하드웨어 설정 저장">
            {busy === 'save' ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}하드웨어 설정 저장
          </button>
          <button type="button" className="nc-big ghost" disabled={!!busy} onClick={() => void load()}><RefreshCw aria-hidden />다시 불러오기</button>
        </div>
      </div>
      {line && <Line tone={line.tone} text={line.text} />}
    </section>
  );
}

export default HardwareSettings;
