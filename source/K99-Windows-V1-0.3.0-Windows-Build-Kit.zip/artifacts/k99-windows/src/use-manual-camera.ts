import {useEffect,useRef,useState,type RefObject} from 'react';
import {CAMERA_RESOLUTIONS,correctCameraCanvas,DEFAULT_CAMERA_COLOR,loadCameraColor,saveCameraColor,naturalCameraProfile,
  type CameraColorProfile,type CameraResolution} from './camera-color';
import {changeCameraResolution} from './manual-camera-resolution';
import {useCameraHardware} from './use-camera-hardware';
import {isSmartphoneCamera} from './camera-device';
/** Hardware adjustment is optional and independent of opening/capturing video. */
export function useManualCamera(video:RefObject<HTMLVideoElement|null>,stream:RefObject<MediaStream|null>,
  device:string,enabled:boolean,sourceLabel=''){
  const passthrough=isSmartphoneCamera(sourceLabel||stream.current?.getVideoTracks()[0]?.label||'');
  const [profile,setProfile]=useState<CameraColorProfile>(()=>loadCameraColor(device||'default'));
  const [note,setNote]=useState(''),[changing,setChanging]=useState(false),[freeze,setFreeze]=useState('');
  const [dimensions,setDimensions]=useState('');
  const [calibrating,setCalibrating]=useState(false);
  const profileRef=useRef(profile);profileRef.current=profile;
  const live=useRef({device,enabled,passthrough});live.current={device,enabled,passthrough};
  const sequence=useRef(0);
  const calibrationEpoch=useRef(0),attempted=useRef(new WeakSet<MediaStreamTrack>());
  useEffect(()=>{
    sequence.current++;
    calibrationEpoch.current++;setCalibrating(false);
    const saved=loadCameraColor(device||'default');profileRef.current=saved;
    setProfile(saved);setNote('');setChanging(false);setFreeze('');
    return()=>{sequence.current++;calibrationEpoch.current++;};
  },[device,enabled,passthrough]);
  function save(next:CameraColorProfile){
    setProfile(next);profileRef.current=next;
    try{saveCameraColor(device||'default',next);setNote('수동 화질 설정을 저장했습니다.');return true;}
    catch{setNote('화질은 현재 화면에 적용했지만 저장하지 못했습니다. 저장 공간·권한을 확인하세요.');return false;}
  }
  const hardware=useCameraHardware(stream,device,enabled&&!passthrough,()=>profileRef.current.hardware,
    p=>save({...profileRef.current,hardware:p,calibrationMode:profileRef.current.calibrationMode??'standard'}),
    ()=>{calibrationEpoch.current++;setCalibrating(false);});
  async function natural(resetHardware=true){
    const v=video.current,s=stream.current,key=device,ticket=++calibrationEpoch.current;
    if(passthrough||!enabled||!v||!s||v.readyState<2){setNote('카메라 화면이 켜진 뒤 사용해 주세요.');return;}
    const current=()=>ticket===calibrationEpoch.current&&live.current.enabled&&!live.current.passthrough&&live.current.device===key&&stream.current===s;
    const sample=()=>{
      const c=document.createElement('canvas');c.width=320;c.height=Math.max(24,Math.round(320*v.videoHeight/v.videoWidth));
      const g=c.getContext('2d',{willReadFrequently:true});if(!g)throw Error('보정용 화면을 읽지 못했습니다.');
      g.drawImage(v,0,0,c.width,c.height);
      return naturalCameraProfile(g.getImageData(0,0,c.width,c.height),profileRef.current);
    };
    setCalibrating(true);setNote('흰 배경과 장치 노출을 확인합니다. 촬영은 계속 사용할 수 있습니다.');
    try{
      const c=resetHardware?await hardware.automatic():hardware.current();
      if(c?.busy)throw Error('장치 설정 응답을 확인한 뒤 다시 눌러 주세요.');
      await new Promise(resolve=>setTimeout(resolve,1000));
      if(!current())return;
      let measured=sample(),sensorNote='';
      if(c){
        try{
          if(await c.brightenWhite(measured.whiteLuma)){
            await new Promise(resolve=>setTimeout(resolve,700));
            if(!current())return;
            measured=sample();
          }
        }catch{sensorNote=' 센서 노출 보정은 지원·응답을 확인하지 못해 건너뛰었습니다.';}
        if(current())hardware.refresh(c);
      }
      if(!current())return;
      const persisted=save({...measured.profile,hardware:c?.preferences()??profileRef.current.hardware});
      setNote(`${persisted?'흰 배경 기준 색감·부드러운 선명도를 저장했습니다.':'보정은 적용했지만 저장하지 못했습니다. 저장 공간·권한을 확인해 주세요.'}${sensorNote}${measured.limited?' 입력 영상이 많이 어둡습니다. 센서 노출·조명을 높인 후 다시 맞춰 주세요.':''}`);
    }catch(e){if(current())setNote(`${e instanceof Error?e.message:'색감 맞춤 실패'} 기존 보정값과 영상은 유지합니다.`);}
    finally{if(ticket===calibrationEpoch.current)setCalibrating(false);}
  }
  useEffect(()=>{
    const track=stream.current?.getVideoTracks()[0];
    if(passthrough||!enabled||changing||!hardware.ready||!track||profileRef.current.calibrationMode!==undefined||attempted.current.has(track))return;
    attempted.current.add(track);void natural(false);
  },[enabled,device,changing,hardware.ready,hardware.identity,passthrough]);
  async function resolution(value:CameraResolution,reset=false){
    const old=stream.current,v=video.current;
    if(changing)return;
    const previous=profileRef.current;
    const target=CAMERA_RESOLUTIONS[value];
    if(!old||!v||!enabled||!target){
      if(reset)save({...DEFAULT_CAMERA_COLOR,calibrationMode:'standard'});
      else setNote('카메라 화면이 켜진 뒤 해상도를 선택하세요. 기존 설정은 유지됩니다.');
      return;
    }
    const standard={...DEFAULT_CAMERA_COLOR,calibrationMode:'standard' as const};
    const next={...(reset?standard:previous),resolution:value};
    if(v.videoWidth===target[0]&&v.videoHeight===target[1]){save(next);return;}
    const ticket=++sequence.current,key=device;
    const current=()=>ticket===sequence.current&&live.current.enabled&&live.current.device===key&&
      stream.current===old&&old.getVideoTracks().some(t=>t.readyState==='live');
    setChanging(true);setNote('선택한 해상도를 확인하는 동안 기존 화면은 유지됩니다.');
    try{
      await changeCameraResolution({media:navigator.mediaDevices,video:v,oldStream:old,
        deviceId:old.getVideoTracks()[0]?.getSettings().deviceId||device,
        width:target[0],height:target[1],current,
        commit:s=>{stream.current=s;},
        freeze:()=>{
          try{
            const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;
            const ctx=canvas.getContext('2d');
            if(ctx){ctx.drawImage(v,0,0);correctCameraCanvas(ctx,profileRef.current);setFreeze(canvas.toDataURL('image/jpeg',.9));}
          }catch{/* The still-live original stream remains the fallback. */}
          return()=>{if(ticket===sequence.current)setFreeze('');};
        }});
      if(ticket===sequence.current){
        save({...profileRef.current,...(reset?standard:{}),resolution:value});
        setDimensions(`${v.videoWidth}×${v.videoHeight}`);
      }
    }catch(error){
      if(ticket===sequence.current){
        save({...profileRef.current,...(reset?standard:{}),resolution:previous.resolution});
        setNote(`${error instanceof Error?error.message:'해상도 변경 실패'} 기존 정상 화면을 유지했습니다.`);
      }
    }finally{if(ticket===sequence.current)setChanging(false);}
  }
  useEffect(()=>{
    if(!enabled)return;
    let timer:ReturnType<typeof setTimeout>|undefined;
    const read=()=>{
      const v=video.current;
      if(!v||!v.videoWidth){timer=setTimeout(read,100);return;}
      setDimensions(`${v.videoWidth}×${v.videoHeight}`);
    };
    read();return()=>clearTimeout(timer);
  },[enabled,device,video]);
  return {profile:passthrough?{...DEFAULT_CAMERA_COLOR}:profile,passthrough,onChange:(p:CameraColorProfile)=>{
      calibrationEpoch.current++;setCalibrating(false);
      save({...p,calibrationMode:p.calibrationMode??'standard'});
    },onResolution:(r:CameraResolution)=>{calibrationEpoch.current++;setCalibrating(false);void resolution(r);},
    onReset:()=>{
      calibrationEpoch.current++;setCalibrating(false);
      save({...DEFAULT_CAMERA_COLOR,calibrationMode:'standard',resolution:profileRef.current.resolution});
      void hardware.automatic().catch(e=>setNote(e instanceof Error?e.message:'장치 자동 모드 복원 실패'));
      void resolution('FHD',true);
    },
    onNatural:()=>void natural(),calibrating,hardware,
    note:[note,hardware.note].filter(Boolean).join(' '),changing,freeze,dimensions};
}
