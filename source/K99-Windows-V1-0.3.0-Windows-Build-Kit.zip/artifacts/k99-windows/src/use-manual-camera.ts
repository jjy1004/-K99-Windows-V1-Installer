import {useEffect,useRef,useState,type RefObject} from 'react';
import {CAMERA_RESOLUTIONS,correctCameraCanvas,DEFAULT_CAMERA_COLOR,loadCameraColor,saveCameraColor,
  type CameraColorProfile,type CameraResolution} from './camera-color';
import {changeCameraResolution} from './manual-camera-resolution';
/** User choices only: never sample the background or write UVC hardware controls. */
export function useManualCamera(video:RefObject<HTMLVideoElement|null>,stream:RefObject<MediaStream|null>,
  device:string,enabled:boolean){
  const [profile,setProfile]=useState<CameraColorProfile>(()=>loadCameraColor(device||'default'));
  const [note,setNote]=useState(''),[changing,setChanging]=useState(false),[freeze,setFreeze]=useState('');
  const [dimensions,setDimensions]=useState('');
  const profileRef=useRef(profile);profileRef.current=profile;
  const live=useRef({device,enabled});live.current={device,enabled};
  const sequence=useRef(0);
  useEffect(()=>{
    sequence.current++;
    const saved=loadCameraColor(device||'default');profileRef.current=saved;
    setProfile(saved);setNote('');setChanging(false);setFreeze('');
    return()=>{sequence.current++;};
  },[device,enabled]);
  function save(next:CameraColorProfile){
    setProfile(next);profileRef.current=next;
    try{saveCameraColor(device||'default',next);setNote('수동 화질 설정을 저장했습니다.');}
    catch{setNote('화질은 현재 화면에 적용했지만 저장하지 못했습니다. 저장 공간·권한을 확인하세요.');}
  }
  async function resolution(value:CameraResolution,reset=false){
    const old=stream.current,v=video.current;
    if(changing)return;
    const previous=profileRef.current;
    const target=CAMERA_RESOLUTIONS[value];
    if(!old||!v||!enabled||!target){
      if(reset)save({...DEFAULT_CAMERA_COLOR});
      else setNote('카메라 화면이 켜진 뒤 해상도를 선택하세요. 기존 설정은 유지됩니다.');
      return;
    }
    const next={...(reset?DEFAULT_CAMERA_COLOR:previous),resolution:value};
    if(v.videoWidth===target[0]&&v.videoHeight===target[1]){save(next);return;}
    const ticket=++sequence.current,key=device;
    const current=()=>ticket===sequence.current&&live.current.enabled&&live.current.device===key&&
      stream.current===old&&old.getVideoTracks().some(t=>t.readyState==='live');
    setChanging(true);setNote('선택한 해상도를 확인하는 동안 기존 화면은 유지됩니다.');
    try{
      await changeCameraResolution({media:navigator.mediaDevices,video:v,oldStream:old,
        deviceId:old.getVideoTracks()[0]?.getSettings().deviceId||device,
        width:target[0],height:target[1],current,
        commit:s=>{stream.current=s;},
        freeze:()=>{
          try{
            const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;
            const ctx=canvas.getContext('2d');
            if(ctx){ctx.drawImage(v,0,0);correctCameraCanvas(ctx,profileRef.current);setFreeze(canvas.toDataURL('image/jpeg',.9));}
          }catch{/* The still-live original stream remains the fallback. */}
          return()=>{if(ticket===sequence.current)setFreeze('');};
        }});
      if(ticket===sequence.current){
        save({...profileRef.current,...(reset?DEFAULT_CAMERA_COLOR:{}),resolution:value});
        setDimensions(`${v.videoWidth}×${v.videoHeight}`);
      }
    }catch(error){
      if(ticket===sequence.current){
        save({...profileRef.current,...(reset?DEFAULT_CAMERA_COLOR:{}),resolution:previous.resolution});
        setNote(`${error instanceof Error?error.message:'해상도 변경 실패'} 기존 정상 화면을 유지했습니다.`);
      }
    }finally{if(ticket===sequence.current)setChanging(false);}
  }
  useEffect(()=>{
    if(!enabled)return;
    let timer:ReturnType<typeof setTimeout>|undefined;
    const read=()=>{
      const v=video.current;
      if(!v||!v.videoWidth){timer=setTimeout(read,100);return;}
      setDimensions(`${v.videoWidth}×${v.videoHeight}`);
    };
    read();return()=>clearTimeout(timer);
  },[enabled,device,video]);
  return {profile,onChange:save,onResolution:(r:CameraResolution)=>void resolution(r),
    onReset:()=>{save({...DEFAULT_CAMERA_COLOR,resolution:profileRef.current.resolution});void resolution('FHD',true);},
    note,changing,freeze,dimensions};
}
