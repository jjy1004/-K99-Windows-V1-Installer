import { authorizeCleanup } from '@workspace/api-client-react';
import { readAllConfirmedOrders, type ConfirmedOrder } from './order-record';
import { isDeletedOrder, settlementBlockReason, type OrderAdminAudit } from './order-deletion-policy';
import { restoreCleanupBackup } from './test-history-cleanup';

export { settlementBlockReason } from './order-deletion-policy';
const key = 'k99-confirmed-orders-v1';
const activeKey = 'k99-active-confirmed-order';
type Action = 'soft-delete' | 'restore' | 'backup-import';
const digest = async (value: string) => Array.from(new Uint8Array(
  await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))),
  byte => byte.toString(16).padStart(2, '0')).join('');

/** This is server authentication for browser-local records, not a central order migration. */
async function permission(action: Action, orderId: string, snapshot: string, password: string) {
  if (!password) throw new Error('관리자 비밀번호를 입력하세요.');
  const scope = { action, orderId, snapshotHash: await digest(snapshot) };
  const grant = await authorizeCleanup({ password, scope });
  if (!grant.authorized || grant.expiresAt <= Date.now() || grant.scope?.action !== action ||
      grant.scope.orderId !== orderId || grant.scope.snapshotHash !== scope.snapshotHash ||
      grant.adminId !== 'shared-password-admin' || !grant.adminLabel || !grant.authorizationId ||
      !grant.authorizedAt || !Number.isFinite(Date.parse(grant.authorizedAt)))
    throw new Error('주문별 관리자 인증을 확인하지 못했습니다. 저장하지 않았습니다.');
  return grant;
}
const notify = () => window.dispatchEvent(new StorageEvent('storage', { key }));

async function changeOrder(original: ConfirmedOrder, password: string, action: 'soft-delete' | 'restore', staffDelete = false) {
  const orders = readAllConfirmedOrders();
  const matches = orders.filter(o => o.id === original.id);
  if (matches.length !== 1 || JSON.stringify(matches[0]) !== JSON.stringify(original))
    throw new Error('주문이 변경되었습니다. 최신 주문을 다시 확인하세요.');
  if (action === 'soft-delete') {
    if (isDeletedOrder(original)) throw new Error('이미 삭제된 주문입니다.');
    const reason = settlementBlockReason(original);
    if (reason) throw new Error(reason);
  } else if (!isDeletedOrder(original)) throw new Error('삭제된 주문만 복구할 수 있습니다.');
  const before = window.localStorage.getItem(key);
  if (staffDelete && action !== 'soft-delete') throw new Error('복구는 관리자 인증이 필요합니다.');
  const grant = staffDelete ? { authorizedAt: new Date().toISOString(), adminId: 'staff-local',
    adminLabel: '직원 (이 브라우저)', authorizationId: `local:${crypto.randomUUID()}` }
    : await permission(action, original.id, JSON.stringify(original), password);
  // No other tab/payment/photo update may be overwritten during authentication.
  if (window.localStorage.getItem(key) !== before)
    throw new Error('다른 화면에서 주문이 변경되었습니다. 삭제·복구하지 않았습니다.');
  const event: OrderAdminAudit = { action, orderId: original.id, at: grant.authorizedAt!,
    adminId: grant.adminId!, adminLabel: grant.adminLabel!, authorizationId: grant.authorizationId! };
  const revised = { ...original, orderDeletionAudit: [...(original.orderDeletionAudit ?? []), event] };
  if (action === 'soft-delete') revised.orderDeletion = { deletedAt: event.at, adminId: event.adminId,
    adminLabel: event.adminLabel, authorizationId: event.authorizationId };
  else delete revised.orderDeletion;
  window.localStorage.setItem(key, JSON.stringify(orders.map(o => o.id === original.id ? revised : o)));
  if (action === 'soft-delete' && window.localStorage.getItem(activeKey) === original.id)
    window.localStorage.removeItem(activeKey);
  notify();
}
export const deleteOrderWithAdmin = (original: ConfirmedOrder, password: string) => changeOrder(original, password, 'soft-delete');
export const deleteOrderAsStaff = (original: ConfirmedOrder) => changeOrder(original, '', 'soft-delete', true);
export const restoreOrderWithAdmin = (original: ConfirmedOrder, password: string) => changeOrder(original, password, 'restore');

export async function restoreOrdersBackupWithAdmin(text: string, password: string): Promise<number> {
  const before = window.localStorage.getItem(key);
  await permission('backup-import', 'backup-import', text, password);
  if (window.localStorage.getItem(key) !== before) throw new Error('주문이 변경되었습니다. 백업을 덮어쓰지 않았습니다.');
  const count = restoreCleanupBackup(window.localStorage, text);
  notify();
  return count;
}
