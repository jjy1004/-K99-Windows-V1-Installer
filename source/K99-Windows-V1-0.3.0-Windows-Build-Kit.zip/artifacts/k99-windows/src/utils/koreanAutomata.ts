const CHO = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const JUNG = ['ㅏ','ㅐ','ㅑ','ㅒ','ㅓ','ㅔ','ㅕ','ㅖ','ㅗ','ㅘ','ㅙ','ㅚ','ㅛ','ㅜ','ㅝ','ㅞ','ㅟ','ㅠ','ㅡ','ㅢ','ㅣ'];
const JONG = ['', 'ㄱ','ㄲ','ㄳ','ㄴ','ㄵ','ㄶ','ㄷ','ㄹ','ㄺ','ㄻ','ㄼ','ㄽ','ㄾ','ㄿ','ㅀ','ㅁ','ㅂ','ㅄ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];

const KEY_MAP: { [key: string]: string } = {
  q:'ㅂ', Q:'ㅃ', w:'ㅈ', W:'ㅉ', e:'ㄷ', E:'ㄸ', r:'ㄱ', R:'ㄲ', t:'ㅅ', T:'ㅆ',
  y:'ㅛ', u:'ㅕ', i:'ㅑ', o:'ㅐ', O:'ㅒ', p:'ㅔ', P:'ㅖ',
  a:'ㅁ', s:'ㄴ', d:'ㅇ', f:'ㄹ', g:'ㅎ',
  h:'ㅗ', j:'ㅓ', k:'ㅏ', l:'ㅣ',
  z:'ㅋ', x:'ㅌ', c:'ㅊ', v:'ㅍ', b:'ㅠ', n:'ㅜ', m:'ㅡ'
};
const DOUBLE_MOUM: { [key: string]: string } = {
  'ㅗㅏ': 'ㅘ', 'ㅗㅐ': 'ㅙ', 'ㅗㅣ': 'ㅚ',
  'ㅜㅓ': 'ㅝ', 'ㅜㅔ': 'ㅞ', 'ㅜㅣ': 'ㅟ', 'ㅡㅣ': 'ㅢ'
};
const DOUBLE_JAUM: { [key: string]: string } = {
  'ㄱㅅ': 'ㄳ', 'ㄴㅈ': 'ㄵ', 'ㄴㅎ': 'ㄶ', 'ㄹㄱ': 'ㄺ', 'ㄹㅁ': 'ㄻ',
  'ㄹㅂ': 'ㄼ', 'ㄹㅅ': 'ㄽ', 'ㄹㅌ': 'ㄾ', 'ㄹㅍ': 'ㄿ', 'ㄹㅎ': 'ㅀ', 'ㅂㅅ': 'ㅄ'
};

export function convertEngToKor(text: string): string {
  if (!text) return '';
  let jamoStr = '';
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    jamoStr += KEY_MAP[ch] || ch;
  }
  let result = '';
  let cho = -1, jung = -1, jong = -1;
  const makeChar = () => {
    if (cho !== -1 && jung !== -1) {
      result += String.fromCharCode(0xac00 + cho * 588 + jung * 28 + (jong === -1 ? 0 : jong));
    } else if (cho !== -1) {
      result += CHO[cho];
    } else if (jung !== -1) {
      result += JUNG[jung];
    }
    cho = -1; jung = -1; jong = -1;
  };
  for (let i = 0; i < jamoStr.length; i++) {
    const ch = jamoStr[i];
    const choIdx = CHO.indexOf(ch);
    const jungIdx = JUNG.indexOf(ch);
    if (choIdx !== -1 && jungIdx === -1) {
      if (cho === -1) { cho = choIdx; }
      else if (jung === -1) { makeChar(); cho = choIdx; }
      else if (jong === -1) {
        const jongIdx = JONG.indexOf(ch);
        if (jongIdx !== -1) jong = jongIdx;
        else { makeChar(); cho = choIdx; }
      } else {
        const doubleKey = JONG[jong] + ch;
        if (DOUBLE_JAUM[doubleKey]) jong = JONG.indexOf(DOUBLE_JAUM[doubleKey]);
        else { makeChar(); cho = choIdx; }
      }
    } else if (jungIdx !== -1) {
      if (cho !== -1 && jung !== -1 && jong !== -1) {
        const curJongChar = JONG[jong];
        makeChar();
        cho = CHO.indexOf(curJongChar); jung = jungIdx;
      } else if (cho !== -1 && jung !== -1 && jong === -1) {
        const doubleKey = JUNG[jung] + ch;
        if (DOUBLE_MOUM[doubleKey]) jung = JUNG.indexOf(DOUBLE_MOUM[doubleKey]);
        else { makeChar(); jung = jungIdx; }
      } else { jung = jungIdx; }
    } else { makeChar(); result += ch; }
  }
  makeChar();
  return result;
}
