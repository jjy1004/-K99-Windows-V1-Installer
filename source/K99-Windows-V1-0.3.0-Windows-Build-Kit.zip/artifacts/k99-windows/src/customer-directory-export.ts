import type { MasterCustomer } from './customer-directory-client';
import { directoryRequest } from './customer-directory-client';

/** Excel-compatible CSV: BOM + CRLF, quoting, and spreadsheet-formula neutralisation. */
export function csvCell(value: unknown): string {
  let text = String(value ?? '');
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}
export function filterCustomerDirectory(customers: readonly MasterCustomer[], keyword: string) {
  const raw = keyword.normalize('NFC').trim();
  if (!raw) return [...customers];
  const numeric = /^[\d\s()+.-]+$/.test(raw);
  const q = numeric ? raw.replace(/\D/g, '') : raw.toLocaleLowerCase('ko-KR');
  return customers.filter(c => numeric
    ? c.phone.replace(/\D/g, '').endsWith(q)
    : c.name.normalize('NFC').toLocaleLowerCase('ko-KR').includes(q));
}
export function customerDirectoryCsv(customers: readonly MasterCustomer[]): string {
  const rows: unknown[][] = [['고객명', '연락처', '주소', '최근 접수일', '총 이용 횟수', '총 세탁물 수',
    '누적 세탁비(수납 증빙 아님)', '접수일시', '주문번호', '품목 및 수량', '접수 수량', '세탁비', '진행 상태', '기록 출처']];
  for (const c of customers) {
    const summary = [c.name, c.phone, c.address, c.lastVisitDate ?? '', c.totalVisits, c.totalItems, c.totalAmount];
    if (!c.visits.length) rows.push([...summary, '', '', '', '', '', '', '접수 이력 없음']);
    for (const v of c.visits) rows.push([...summary, v.receiptAt, v.orderNumber,
      v.items.map(i => `${i.label} × ${i.quantity}`).join(' / '), v.itemCount, v.totalAmount, v.status,
      v.source === 'import' ? '과거 장부(일자별 합산)' : '신규 접수']);
  }
  return '\uFEFF' + rows.map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
}
export function customerDirectoryFilename(at = new Date()): string {
  const day = new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(at).replace(/-/g, '');
  return `K99_고객명부_접수이력_${day}.csv`;
}
export async function downloadCustomerDirectory(customers: readonly MasterCustomer[]):Promise<{
  saved:boolean;cancelled:boolean;filePath?:string;bytes?:number;
}> {
  const csv=customerDirectoryCsv(customers),fileName=customerDirectoryFilename();
  if(window.k99Desktop){
    const result=await directoryRequest<{saved:boolean;cancelled:boolean;filePath?:string;bytes?:number}>(
      'POST','/api/customer-directory/export',{csv,fileName});
    if(!result.cancelled&&(!result.saved||!result.filePath))throw new Error('CSV 파일의 실제 저장 결과를 확인하지 못했습니다.');
    return result;
  }
  const url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = fileName; document.body.append(anchor);
  try { anchor.click(); } finally { anchor.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 60000); }
  return {saved:false,cancelled:false};
}
