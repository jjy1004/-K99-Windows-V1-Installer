import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, Loader2, RefreshCw, RotateCcw, Save } from 'lucide-react';
import { noticeApi } from './notice-api';
import './settings-hub.css';
import './notice-center.css';
import './default-message-settings.css';

type Tpl = {
  id: string; title: string; stage: 'before' | 'after' | 'advert'; text: string; revision: number;
  defaultTitle: string; defaultText: string; placeholders: string[]; requiredTokens: string[]; configured: boolean;
};
type Draft = { title: string; text: string };
type Line = { tone: 'ok' | 'err' | 'info'; text: string };

const TITLE_MAX = 100;
const TEXT_MAX = 12000;
const BASE_TOKENS = ['고객명', '세탁금액', '은행명', '계좌번호', '예금주명', '고객휴대폰번호', '오늘날짜', '수거기한', '보관료시작일', '발송일+5일', '발송일+7일', '기준일+5일', '기준일+7일'];
const STAGES: ['before' | 'after', string][] = [['before', '세탁 전 · 기본 안내'], ['after', '세탁 후 · 특별 안내']];
const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');
const strip = (t: string) => t.replace(/^\{+|\}+$/g, '').replace(/^\[|\]$/g, '');
const wrap = (t: string) => (/^[{[]/.test(t) ? t : `{${t}}`);

export function DefaultMessageSettings() {
  const [tpls, setTpls] = useState<Tpl[] | null>(null);
  const [loadErr, setLoadErr] = useState('');
  const [sel, setSel] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [saving, setSaving] = useState(false);
  const [line, setLine] = useState<Line | null>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  const load = useCallback(() => {
    setLoadErr(''); setTpls(null);
    noticeApi<{ templates: Tpl[] }>('GET', '/templates')
      .then((r) => {
        const list = (r.templates || []).filter((t) => t.stage !== 'advert');
        setTpls(list);
        setSel((cur) => (cur && list.some((t) => t.id === cur) ? cur : list[0]?.id ?? null));
      })
      .catch((e) => setLoadErr(`불러오기 실패: ${errText(e)}`));
  }, []);
  useEffect(load, [load]);

  const cur = tpls?.find((t) => t.id === sel) ?? null;
  const draft: Draft | null = cur ? drafts[cur.id] ?? { title: cur.title, text: cur.text } : null;
  const dirty = (t: Tpl) => { const d = drafts[t.id]; return !!d && (d.title !== t.title || d.text !== t.text); };

  const edit = (patch: Partial<Draft>) => {
    if (!cur || !draft || saving) return;
    setDrafts((m) => ({ ...m, [cur.id]: { ...draft, ...patch } }));
  };
  const applySaved = (t: Tpl) => {
    setTpls((list) => list?.map((x) => (x.id === t.id ? { ...x, ...t } : x)) ?? list);
    setDrafts((m) => { const n = { ...m }; delete n[t.id]; return n; });
  };

  const tokens = Array.from(new Set([...BASE_TOKENS, ...(cur?.placeholders ?? []).map(strip)])).filter(Boolean);
  const insert = (tok: string) => {
    if (!draft || saving) return;
    const el = bodyRef.current; const v = wrap(tok);
    const s = el?.selectionStart ?? draft.text.length; const e = el?.selectionEnd ?? s;
    const next = draft.text.slice(0, s) + v + draft.text.slice(e);
    if (next.length > TEXT_MAX) { setLine({ tone: 'err', text: `본문은 ${TEXT_MAX.toLocaleString('ko-KR')}자까지입니다.` }); return; }
    edit({ text: next });
    requestAnimationFrame(() => { el?.focus(); el?.setSelectionRange(s + v.length, s + v.length); });
  };

  const save = async () => {
    if (!cur || !draft || saving) return;
    const title = draft.title.trim();
    if (!title) { setLine({ tone: 'err', text: '버튼 표시명(제목)을 넣어 주세요.' }); return; }
    if (!draft.text.trim()) { setLine({ tone: 'err', text: '본문을 비워 둘 수 없습니다.' }); return; }
    if (title.length > TITLE_MAX || draft.text.length > TEXT_MAX) { setLine({ tone: 'err', text: '글자 수 제한을 넘었습니다.' }); return; }
    setSaving(true); setLine(null);
    try {
      const r = await noticeApi<{ template: Tpl }>('PUT', `/templates/${encodeURIComponent(cur.id)}`, { title, text: draft.text, revision: cur.revision });
      applySaved(r.template); setLine({ tone: 'ok', text: '저장되었습니다.' });
    } catch (e) {
      setLine({ tone: 'err', text: `저장 실패: ${errText(e)} 고친 내용은 그대로 남아 있습니다. 다른 곳에서 바뀌었다면 “다시 불러오기” 후 수정해 주세요.` });
    } finally { setSaving(false); }
  };
  const reset = async () => {
    if (!cur || saving) return;
    setSaving(true); setLine(null);
    try {
      const r = await noticeApi<{ template: Tpl }>('PUT', `/templates/${encodeURIComponent(cur.id)}`, { reset: true, revision: cur.revision });
      applySaved(r.template); setLine({ tone: 'ok', text: '원래 기본 문안으로 되돌려 저장했습니다.' });
    } catch (e) {
      setLine({ tone: 'err', text: `되돌리기 실패: ${errText(e)} 고친 내용은 그대로 남아 있습니다.` });
    } finally { setSaving(false); }
  };
  const reload = () => {
    if (saving) return;
    setLine({tone:'info',text:'저장하지 않은 글은 보존하고 최신 저장 내용을 불러옵니다.'});load();
  };

  const LineIcon = line?.tone === 'ok' ? CheckCircle2 : line?.tone === 'info' ? Info : AlertTriangle;
  return (
    <section className="dms-root" data-testid="section-default-messages" aria-busy={saving}>
      <p className="dms-intro">고객에게 보내는 기본 메시지를 고칩니다. 위에서 항목을 고르고, 제목과 본문을 고친 뒤 <b>저장하기</b>를 누르세요.</p>
      {loadErr && <div className="nc-msg err" role="alert" data-testid="status-dms-load-error"><AlertTriangle size={22} aria-hidden /><div>{loadErr} <button type="button" className="nc-close" onClick={load} data-testid="button-dms-retry"><RefreshCw size={18} aria-hidden />다시 시도</button></div></div>}
      {!tpls && !loadErr && <div className="sh-skel" aria-label="불러오는 중"><i /><i /><i /></div>}
      {tpls && tpls.length === 0 && <div className="nc-msg info" role="status"><Info size={22} aria-hidden /><div>설정할 메시지가 없습니다.</div></div>}
      {tpls && tpls.length > 0 && <>
        {STAGES.map(([stage, label]) => {
          const list = tpls.filter((t) => t.stage === stage);
          if (!list.length) return null;
          return (
            <div className="dms-group" key={stage} role="group" aria-label={label}>
              <h3>{label}</h3>
              <div className="dms-list">
                {list.map((t) => (
                  <button key={t.id} type="button" className="dms-item" aria-pressed={t.id === sel} disabled={saving}
                    onClick={() => { setSel(t.id); setLine(null); }} data-testid={`button-dms-item-${t.id}`}>
                    {drafts[t.id]?.title || t.title}
                    {dirty(t) && <small>저장 안 됨</small>}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
        {cur && draft && <div className="nc-section" data-testid="section-dms-editor">
          <h3>{STAGES.find(([s]) => s === cur.stage)?.[1]} · 편집</h3>
          <label className="nc-label" htmlFor="dms-title">버튼 표시명 (제목)</label>
          <input id="dms-title" lang="ko" className="nc-input" maxLength={TITLE_MAX} value={draft.title} disabled={saving}
            onChange={(e) => edit({ title: e.target.value })} data-testid="input-dms-title" />
          <p className={`dms-count${draft.title.length > TITLE_MAX ? ' over' : ''}`}>{draft.title.length} / {TITLE_MAX}자</p>
          <p className="nc-label" id="dms-tokens-label">자동으로 바뀌는 글자 (누르면 본문 커서 자리에 넣습니다)</p>
          <div className="dms-chips" role="group" aria-labelledby="dms-tokens-label">
            {tokens.map((t) => <button key={t} type="button" className="dms-chip" disabled={saving} onClick={() => insert(t)} data-testid={`button-dms-token-${t}`}>{wrap(t)}</button>)}
          </div>
          <p className="nc-hint" data-testid="text-dms-date-hint">날짜는 직접 쓰지 말고 배지를 넣어 주세요. {'{오늘날짜}'}는 한국 기준 오늘(예: 5월 3일), {'{수거기한}'}은 기준일+5일, {'{보관료시작일}'}은 기준일+7일로 고객 창 열기·항목 선택·발송 때 자동 계산됩니다.</p>
          <label className="nc-label" htmlFor="dms-body">본문</label>
          <textarea id="dms-body" ref={bodyRef} lang="ko" className="nc-input nc-body" maxLength={TEXT_MAX} value={draft.text} disabled={saving}
            onChange={(e) => edit({ text: e.target.value })} data-testid="input-dms-body" />
          <p className={`dms-count${draft.text.length > TEXT_MAX ? ' over' : ''}`}>{draft.text.length.toLocaleString('ko-KR')} / {TEXT_MAX.toLocaleString('ko-KR')}자</p>
          {cur.requiredTokens?.length > 0 && <p className="nc-hint" data-testid="text-dms-required">꼭 남겨야 하는 글자: {cur.requiredTokens.map(wrap).join(', ')}</p>}
          {line && <div className={`nc-msg ${line.tone}`} role={line.tone === 'err' ? 'alert' : 'status'} data-testid="status-dms"><LineIcon size={22} aria-hidden /><div>{line.text}</div></div>}
          <div className="sh-actions" style={{ marginTop: 14 }}>
            <button type="button" className="sh-btn gold" disabled={saving} onClick={save} aria-label="기본 메시지 저장하기" data-testid="button-dms-save">{saving ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}{saving ? '저장 중…' : '저장하기'}</button>
            <button type="button" className="sh-btn ghost" disabled={saving} onClick={reset} aria-label="원래 기본 문안으로 되돌리기" data-testid="button-dms-reset"><RotateCcw aria-hidden />원래 기본 문안으로 되돌리기</button>
            <button type="button" className="sh-btn ghost" disabled={saving} onClick={reload} aria-label="기본 메시지 다시 불러오기" data-testid="button-dms-reload"><RefreshCw aria-hidden />다시 불러오기</button>
          </div>
        </div>}
      </>}
    </section>
  );
}

export default DefaultMessageSettings;
