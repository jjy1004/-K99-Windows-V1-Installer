import type { ConfirmedOrder } from './order-record';
import {
  ADDITIONAL_WORK, CLEANING_METHODS, INSPECTION_FIELDS, RISK_FACTORS,
  type InspectionDraft,
} from './inspection-record';

const key = (order: ConfirmedOrder) => `k99-inspection-draft:${order.id}`;
const signature = (order: ConfirmedOrder) => JSON.stringify([order.id, order.intakeAt, order.items, order.choices]);
type DraftStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;
export function readInspectionDraft(storage: DraftStorage, order: ConfirmedOrder): InspectionDraft | null {
  const raw = storage.getItem(key(order));
  if (!raw || order.inspection) return null;
  const saved = JSON.parse(raw);
  if (saved.signature !== signature(order)) throw new Error('접수 원본이 변경되어 이전 검수 초안을 자동 적용하지 않았습니다.');
  const draft = saved.draft;
  if (!draft || !Array.isArray(draft.items) || draft.items.length !== order.items.length ||
      typeof draft.riskRequired !== 'boolean' || typeof draft.riskNotice !== 'string' ||
      ![draft.revisedPrice, draft.additionalCharge ?? 0].every(n => n === null || (Number.isFinite(n) && n >= 0)) ||
      !draft.items.every((item: InspectionDraft['items'][number], index: number) =>
        item?.index === index && item.itemId === order.items[index].itemId &&
        item.checks && typeof item.checks === 'object' &&
        Object.entries(item.checks).every(([field, value]) => INSPECTION_FIELDS.includes(field as typeof INSPECTION_FIELDS[number]) &&
          ['정상', '주의', '문제 있음', '해당 없음'].includes(value!)) &&
        CLEANING_METHODS.includes(item.method) && Array.isArray(item.additionalWork) &&
        item.additionalWork.every(work => ADDITIONAL_WORK.includes(work)) &&
        (!item.riskFactors || Array.isArray(item.riskFactors) && item.riskFactors.every(risk => RISK_FACTORS.includes(risk))) &&
        ['memo', 'customMethod', 'additionalWorkDescription'].every(field =>
          typeof item[field as 'memo'] === 'string')) ||
      (draft.affectedGarmentIds !== undefined && (!Array.isArray(draft.affectedGarmentIds) ||
        draft.affectedGarmentIds.some((id: string) => !order.garments?.some(g => g.garmentId === id && g.orderId === order.id)))))
    throw new Error('저장된 전문검수 초안의 형식을 확인하지 못했습니다. 원본 주문은 변경하지 않았습니다.');
  return { ...draft, revisedPrice: draft.revisedPrice ?? NaN, additionalCharge: draft.additionalCharge === null ? NaN : draft.additionalCharge };
}
export function writeInspectionDraft(storage: DraftStorage, order: ConfirmedOrder, draft: InspectionDraft): void {
  storage.setItem(key(order), JSON.stringify({ signature: signature(order), draft }));
}
export function clearInspectionDraft(storage: DraftStorage, order: ConfirmedOrder): void {
  storage.removeItem(key(order));
}
