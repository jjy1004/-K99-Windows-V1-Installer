import type { ConfirmedOrder } from './order-record';
import { normalGarmentApproved } from './normal-inspection-policy';
import { businessOrders } from './order-deletion-policy';

export const DELIVERY_STAGES = [
  '수거예약', '수거완료', '매장입고', '세탁중', '세탁완료', '포장완료', '배달대기', '배달중', '배달완료',
] as const;
export type DeliveryStage = typeof DELIVERY_STAGES[number] | '매장수령완료';
export type PaymentStatus = '미결제' | '결제완료' | '환불';
export type NotificationDraft = {
  id: string;
  at: string;
  trigger: string;
  message: string;
  mode: 'test';
  status: '발송 안 함';
};
export type OrderOperations = {
  stage: DeliveryStage;
  updatedAt: string;
  detailAddress: string;
  pickupDate: string;
  pickupTime: string;
  deliveryDate: string;
  deliveryTime: string;
  paymentStatus: PaymentStatus;
  paidAmount: number;
  paidAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancelReason?: string;
  notifications: NotificationDraft[];
};
export type OperationsDetails = Pick<OrderOperations, 'detailAddress' | 'pickupDate' | 'pickupTime' | 'deliveryDate' | 'deliveryTime'>;

export function initialOperations(order: ConfirmedOrder): OrderOperations {
  return {
    stage: order.choices.pickupRequested ? '수거예약' : '매장입고',
    updatedAt: order.intakeAt, detailAddress: '', pickupDate: order.choices.requestedPickupDate,
    pickupTime: '', deliveryDate: '', deliveryTime: '',
    paymentStatus: '미결제', paidAmount: 0, notifications: [],
  };
}
export function currentOperations(order: ConfirmedOrder): OrderOperations {
  return order.operations ?? initialOperations(order);
}
export function nextStage(order: ConfirmedOrder): DeliveryStage | null {
  const operations = currentOperations(order);
  if (operations.cancelledAt) return null;
  const stage = operations.stage;
  if (stage === '매장수령완료' || stage === '배달완료') return null;
  if (stage === '포장완료' && !order.choices.deliveryRequested) return '매장수령완료';
  return DELIVERY_STAGES[DELIVERY_STAGES.indexOf(stage as typeof DELIVERY_STAGES[number]) + 1] ?? null;
}
const toDate = (value: string, label: string) => {
  if (!value) return;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00Z`))
    || new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) !== value)
    throw new Error(`${label} 형식을 확인해 주세요.`);
};
const toTime = (value: string, label: string) => {
  if (value && !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new Error(`${label} 형식을 확인해 주세요.`);
};

export function updateOperationsDetails(order: ConfirmedOrder, details: OperationsDetails, at = new Date()): ConfirmedOrder {
  if (currentOperations(order).cancelledAt) throw new Error('취소된 주문의 일정을 변경할 수 없습니다.');
  toDate(details.pickupDate, '수거 날짜');
  toDate(details.deliveryDate, '배달 날짜');
  toTime(details.pickupTime, '수거 시간');
  toTime(details.deliveryTime, '배달 시간');
  const timestamp = at.toISOString();
  const before = currentOperations(order);
  const after = { ...before, ...details, detailAddress: details.detailAddress.trim(), updatedAt: timestamp };
  if (Object.keys(details).every((key) => before[key as keyof OperationsDetails] === after[key as keyof OperationsDetails])) return order;
  return { ...order, operations: after,
    history: [...(order.history ?? []), { at: timestamp, kind: 'operations-update', details: { action: 'schedule', previous: {
      detailAddress: before.detailAddress, pickupDate: before.pickupDate, pickupTime: before.pickupTime,
      deliveryDate: before.deliveryDate, deliveryTime: before.deliveryTime,
    }, revised: details } }] };
}

const notificationForStage = (order: ConfirmedOrder, stage: DeliveryStage, at: string): NotificationDraft | null => {
  const trigger: Partial<Record<DeliveryStage, string>> = {
    '세탁완료': '세탁완료', '배달대기': '배달예정', '배달완료': '배달완료', '수거예약': '수거예정',
  };
  const name = trigger[stage];
  if (!name) return null;
  return {
    id: `${order.id}-${at}-${stage}`, at, trigger: name,
    message: `K99 품격세탁소 과천점입니다. ${order.customerName} 고객님, 주문 ${order.id.slice(0, 8)}의 ${name} 안내가 준비되었습니다. 자세한 일정은 매장에 확인해 주세요.`,
    mode: 'test', status: '발송 안 함',
  };
};

// A garment scan happens only after the final wash/iron. It may move the order from
// store receipt directly to laundry complete without inventing intermediate scans.
export function completeLaundryByScan(order: ConfirmedOrder, message: string, at = new Date(), issuedTagReady = false): ConfirmedOrder {
  const before = currentOperations(order);
  if (before.cancelledAt || before.completedAt ||
      (!issuedTagReady && !(['매장입고', '세탁중', '세탁완료'] as DeliveryStage[]).includes(before.stage)))
    throw new Error('매장에 입고되어 세탁 작업 중인 주문만 완료할 수 있습니다.');
  if (before.stage === '세탁완료') return order;
  const timestamp = at.toISOString();
  const notification: NotificationDraft = {
    id: `${order.id}-${timestamp}-scanner-completion`, at: timestamp,
    trigger: '세탁완료', message, mode: 'test', status: '발송 안 함',
  };
  return { ...order,
    operations: { ...before, stage: '세탁완료', updatedAt: timestamp,
      notifications: [...before.notifications, notification] },
    history: [...(order.history ?? []),
      { at: timestamp, kind: 'operations-update',
        details: { action: 'scanner-completion', previous: before.stage, revised: '세탁완료' } },
      { at: timestamp, kind: 'notification-draft',
        details: { trigger: notification.trigger, message, mode: 'test',
          status: '발송 안 함', actuallySent: false } }],
  };
}

export function advanceOrderStage(order: ConfirmedOrder, stage: DeliveryStage, at = new Date()): ConfirmedOrder {
  if (stage !== nextStage(order)) throw new Error('현재 단계에서 다음 단계로만 이동할 수 있습니다.');
  if (DELIVERY_STAGES.indexOf(stage as typeof DELIVERY_STAGES[number]) >= DELIVERY_STAGES.indexOf('세탁중')
      && order.status !== '세탁 진행 승인' && order.status !== '전체 세탁 완료 / 반출 대기'
      && !(stage === '세탁중' && order.garments?.some(garment => normalGarmentApproved(order, garment))))
    throw new Error('전문 검수와 고객 승인이 완료되어야 세탁을 진행할 수 있습니다.');
  if (stage === '매장수령완료' && order.status !== '세탁 진행 승인' && order.status !== '전체 세탁 완료 / 반출 대기')
    throw new Error('고객 승인 전에는 완료 처리할 수 없습니다.');
  const before = currentOperations(order);
  const timestamp = at.toISOString();
  const notification = notificationForStage(order, stage, timestamp);
  return { ...order,
    operations: { ...before, stage, updatedAt: timestamp,
      ...(stage === '배달완료' || stage === '매장수령완료' ? { completedAt: timestamp } : {}),
      notifications: [...before.notifications, ...(notification ? [notification] : [])] },
    history: [...(order.history ?? []),
      { at: timestamp, kind: 'operations-update', details: { action: 'stage', previous: before.stage, revised: stage } },
      ...(notification ? [{ at: timestamp, kind: 'notification-draft' as const,
        details: { trigger: notification.trigger, message: notification.message, mode: 'test', status: '발송 안 함' } }] : [])],
  };
}

export function recordOrderPayment(order: ConfirmedOrder, status: PaymentStatus, amount: number, at = new Date()): ConfirmedOrder {
  if (currentOperations(order).cancelledAt && status === '결제완료')
    throw new Error('취소된 주문을 결제완료로 표시할 수 없습니다.');
  if (!Number.isSafeInteger(amount) || amount < 0 || amount > 100000000)
    throw new Error('결제금액을 0~1억 원 사이의 정수로 입력해 주세요.');
  const before = currentOperations(order);
  const timestamp = at.toISOString();
  const paidAt = status === '결제완료'
    ? before.paymentStatus === '결제완료' && before.paidAmount === amount && before.paidAt
      ? before.paidAt
      : timestamp
    : before.paidAt;
  return { ...order, operations: { ...before, paymentStatus: status, paidAmount: amount,
    paidAt, updatedAt: timestamp },
    history: [...(order.history ?? []), { at: timestamp, kind: 'operations-update',
      details: { action: 'payment-record', previous: before.paymentStatus, revised: status, amount,
        note: '실제 결제 처리 아님 · 직원 기록' } }] };
}

export function cancelOrder(order: ConfirmedOrder, reason: string, at = new Date()): ConfirmedOrder {
  const before = currentOperations(order);
  if (before.cancelledAt) throw new Error('이미 취소된 주문입니다.');
  if (!reason.trim()) throw new Error('취소 사유를 기록해 주세요.');
  if (DELIVERY_STAGES.indexOf(before.stage as typeof DELIVERY_STAGES[number]) >= DELIVERY_STAGES.indexOf('세탁중')
      || before.stage === '매장수령완료')
    throw new Error('세탁 작업이 시작된 주문은 이 화면에서 취소할 수 없습니다.');
  const timestamp = at.toISOString();
  return { ...order, operations: { ...before, cancelledAt: timestamp, cancelReason: reason.trim(), updatedAt: timestamp },
    history: [...(order.history ?? []), { at: timestamp, kind: 'operations-update',
      details: { action: 'cancel', previous: before.stage, revised: '접수 취소', reason: reason.trim() } }] };
}

export function searchOrders(orders: ConfirmedOrder[], query: string): ConfirmedOrder[] {
  orders = businessOrders(orders);
  const term = query.trim().toLocaleLowerCase('ko-KR');
  if (!term) return [...orders].sort((a, b) => b.intakeAt.localeCompare(a.intakeAt));
  const normalizedDigits = term.replace(/\D/g, '');
  const digitSearch = /^[\d\s-]+$/.test(term) && normalizedDigits.length >= 3;
  return orders.filter((order) => [
    order.id, order.customerName, order.customerPhone.replace(/\D/g, ''), `${order.totalQuantity}벌`, `${order.totalQuantity}점`,
    order.intakeAt.slice(0, 10), currentOperations(order).completedAt?.slice(0, 10) ?? '',
    ...order.items.flatMap((item) => [item.displayNameKo, item.intakeDetails?.brand ?? '']),
  ].some((value) => value.toLocaleLowerCase('ko-KR').includes(term)
    || digitSearch && value.replace(/\D/g, '').includes(normalizedDigits)))
    .sort((a, b) => b.intakeAt.localeCompare(a.intakeAt));
}

export function customerHistory(orders: ConfirmedOrder[], phone: string) {
  orders = businessOrders(orders);
  const normalized = phone.replace(/\D/g, '');
  const visits = orders.filter((order) => order.customerPhone.replace(/\D/g, '') === normalized)
    .sort((a, b) => a.intakeAt.localeCompare(b.intakeAt));
  return {
    visits, firstVisit: visits[0]?.intakeAt ?? null, recentVisit: visits.at(-1)?.intakeAt ?? null,
    visitCount: visits.length, itemCount: visits.reduce((sum, order) => sum + order.totalQuantity, 0),
    paidTotal: visits.reduce((sum, order) => sum + (currentOperations(order).paymentStatus === '결제완료'
      ? currentOperations(order).paidAmount : 0), 0),
    generalCount: visits.filter((order) => order.choices.serviceLevel === 'general').length,
    premiumCount: visits.filter((order) => order.choices.serviceLevel === 'premium').length,
    pickupCount: visits.filter((order) => order.choices.pickupRequested).length,
    deliveryCount: visits.filter((order) => order.choices.deliveryRequested).length,
  };
}

export function operationsSummary(orders: ConfirmedOrder[]) {
  orders = businessOrders(orders);
  const phones = orders.map((order) => order.customerPhone.replace(/\D/g, ''));
  const counts = new Map<string, number>();
  phones.forEach((phone) => counts.set(phone, (counts.get(phone) ?? 0) + 1));
  const paid = orders.filter((order) => currentOperations(order).paymentStatus === '결제완료');
  return {
    orderCount: orders.length, customerCount: counts.size,
    returningCustomers: [...counts.values()].filter((count) => count > 1).length,
    frequentCustomers: [...counts.values()].filter((count) => count >= 3).length,
    itemCount: orders.reduce((sum, order) => sum + order.totalQuantity, 0),
    actualRevenue: paid.reduce((sum, order) => sum + currentOperations(order).paidAmount, 0),
    pickupCount: orders.filter((order) => order.choices.pickupRequested).length,
    deliveryCount: orders.filter((order) => order.choices.deliveryRequested).length,
  };
}

export function revenueByPeriod(orders: ConfirmedOrder[], period: 'day' | 'month') {
  orders = businessOrders(orders);
  const result = new Map<string, { amount: number; visits: number; general: number; premium: number }>();
  for (const order of orders) {
    const operations = currentOperations(order);
    if (operations.paymentStatus !== '결제완료' || !operations.paidAt) continue;
    const key = operations.paidAt.slice(0, period === 'day' ? 10 : 7);
    const current = result.get(key) ?? { amount: 0, visits: 0, general: 0, premium: 0 };
    current.amount += operations.paidAmount;
    current.visits += 1;
    current[order.choices.serviceLevel] += operations.paidAmount;
    result.set(key, current);
  }
  return [...result].sort(([a], [b]) => b.localeCompare(a));
}