import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { scanIssuedTagForHandover } from './garment-scanner';
import { installKeyboardTagReader } from './keyboard-tag-reader';
import { readAllConfirmedOrders } from './order-record';

export default function GlobalTagScanner() {
  const [path] = useLocation();
  const [notice, setNotice] = useState<{ message: string; error: boolean }>();
  useEffect(() => {
    if (path === '/customer' || path === '/customer-result' || path.startsWith('/equipment') || path.startsWith('/maintenance')) return;
    let timer: ReturnType<typeof setTimeout>;
    const stop = installKeyboardTagReader(barcode => {
      try {
        const result = scanIssuedTagForHandover(barcode);
        setNotice({ message: result.outcome === 'completed'
          ? `${result.garment?.itemName} · 출고 준비 완료 (인도 전)` : result.message,
          error: ['unknown', 'blocked'].includes(result.outcome) });
        window.dispatchEvent(new StorageEvent('storage', { key: 'k99-confirmed-orders-v1' }));
      } catch (e) { setNotice({ message: e instanceof Error ? e.message : '스캔 저장 실패', error: true }); }
      clearTimeout(timer); timer = setTimeout(() => setNotice(undefined), 4500);
    }, window, barcode => {
      try { return readAllConfirmedOrders().some(order => order.garments?.some(g =>
        g.barcodeValue === barcode || g.garmentId === barcode)); } catch { return false; }
    }, message => {
      setNotice({ message, error: true });
      clearTimeout(timer); timer = setTimeout(() => setNotice(undefined), 4500);
    });
    return () => { stop(); clearTimeout(timer); };
  }, [path]);
  return notice ? <div role={notice.error ? 'alert' : 'status'} data-testid="global-scan-notice"
    style={{ position: 'fixed', top: 84, right: 20, zIndex: 10000, maxWidth: 500,
      padding: '16px 24px', border: `2px solid ${notice.error ? '#b91c1c' : '#0f766e'}`,
      background: 'white', color: '#183038', boxShadow: '0 4px 20px #0003' }}>{notice.message}</div> : null;
}
