import type { ConfirmedOrder } from './order-record.ts';
import { businessOrders } from './order-deletion-policy';
import { garmentDisplayStatus } from './handover-display';
import { STORAGE_NOTICE_POLICY } from './notification-workflow';
import { currentOperations } from './order-operations.ts';
import type { GarmentRecord } from './garment-record.ts';
import {
  FREE_STORAGE_DAYS,
  STORAGE_FEE_PER_ITEM_PER_DAY,
  STORAGE_REMINDER_DAYS,
  daysSinceIntake,
  intakeCalendarDate,
  koreaCalendarDate,
} from './storage-policy.ts';

export type ManagementPeriodMode = 'day' | 'month' | 'year' | 'custom';
export type ManagementDateInput = string | Date;

export type ManagementPeriod = {
  from: string;
  to: string;
};

/** A null metric means the stored records do not support a reliable value. */
export type ManagementMetrics = {
  actualRevenue: number | null;
  customerVisits: number | null;
  newCustomers: number | null;
  returningCustomers: number | null;
  intakeGarments: number | null;
  averageTicket: number | null;
  generalRevenue: number | null;
  premiumRevenue: number | null;
  itemQuantities: Record<string, number> | null;
  rewashCases: number | null;
  uncollectedGarments: number | null;
  pickupDeliveryOrders: number | null;
};

export type ManagementSummary = {
  asOf: string;
  today: ManagementMetrics;
  month: ManagementMetrics;
  year: ManagementMetrics;
  totalOrders: number;
  uniqueCustomers: number;
  acceptedGarments: number;
  completedGarments: number;
  readyForHandoverGarments: number;
  uncollectedGarments: number;
  pickupDeliveryOrders: number;
  rewashCases: number;
  actualRevenueAllTime: number | null;
  generalRevenueAllTime: number | null;
  premiumRevenueAllTime: number | null;
  /** Confirmed laundry fees (staff-edited final totals) of non-cancelled orders received in the period. */
  todayConfirmedSales: number;
  monthConfirmedSales: number;
  inProgressGarments: number;
};

export type ManagementPeriodComparison = {
  mode: ManagementPeriodMode;
  currentPeriod: ManagementPeriod;
  previousPeriod: ManagementPeriod;
  current: ManagementMetrics;
  previous: ManagementMetrics;
  change: ManagementMetrics;
};

export type ReminderDayStatus = {
  day: typeof STORAGE_REMINDER_DAYS[number];
  status: 'not-due' | 'due-not-prepared' | 'draft-prepared-not-sent' | 'externally-confirmed-by-staff';
  actuallySent: false;
};

export type UncollectedGarment = {
  orderId: string;
  garmentId: string;
  barcodeValue: string;
  customerName: string;
  customerPhoneLast4: string;
  intakeAt: string | null;
  elapsedDays: number | null;
  storageFee: number | null;
  itemName: string;
  processStatus: string;
  completedAt: string | null;
  handoverMethod: 'delivery' | 'store-pickup' | 'unknown';
  reminders: ReminderDayStatus[];
};

export type CustomerManagementProfile = {
  customerName: string;
  customerPhone: string;
  normalizedPhone: string;
  customerAddress: string;
  firstVisit: string | null;
  recentVisit: string | null;
  visitCount: number;
  orderCount: number;
  garmentCount: number;
  paidTotal: number | null;
  activeOrders: ConfirmedOrder[];
  completedOrders: ConfirmedOrder[];
  uncollectedOrders: ConfirmedOrder[];
  pickupDeliveryHistory: Array<{
    orderId: string;
    intakeAt: string;
    pickupRequested: boolean;
    deliveryRequested: boolean;
    pickupDate: string | null;
    deliveryDate: string | null;
  }>;
  customerRequests: Array<{ orderId: string; request: string }>;
  orderHistory: ConfirmedOrder[];
};

export type ManagementCustomerSearchResult = CustomerManagementProfile & {
  matchedOrderIds: string[];
};

type CustomerGroup = { key: string; phone: string; orders: ConfirmedOrder[] };

const DAY_MS = 86_400_000;
const READY_PROCESS_STATES = new Set(['세탁 완료', '완성 검수', '출고 대기', '반출 완료']);
function validDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const timestamp = Date.parse(`${value}T00:00:00.000Z`);
  return Number.isFinite(timestamp) && new Date(timestamp).toISOString().slice(0, 10) === value;
}

function asCalendarDate(value: ManagementDateInput, label: string): string {
  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) throw new Error(`${label} 날짜를 확인해 주세요.`);
    return koreaCalendarDate(value);
  }
  if (typeof value !== 'string' || !value) throw new Error(`${label} 날짜를 확인해 주세요.`);
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    if (!validDate(value)) throw new Error(`${label} 날짜를 확인해 주세요.`);
    return value;
  }
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) throw new Error(`${label} 날짜를 확인해 주세요.`);
  return koreaCalendarDate(parsed);
}

function orderCalendarDate(order: ConfirmedOrder): string | null {
  return managementIntakeDate(order.intakeAt);
}

export function managementIntakeDate(intakeAt: string): string | null {
  if (typeof intakeAt !== 'string' || !intakeAt) return null;
  try {
    const date = /^\d{4}-\d{2}-\d{2}$/.test(intakeAt)
      ? intakeAt
      : koreaCalendarDate(intakeAt);
    return validDate(date) ? date : null;
  } catch {
    return null;
  }
}

function paidCalendarDate(order: ConfirmedOrder): string | null {
  const operations = currentOperations(order);
  if (operations.paymentStatus !== '결제완료' || !operations.paidAt
    || !Number.isSafeInteger(operations.paidAmount) || operations.paidAmount < 0
    || hasAmbiguousPaidDate(order)) return null;
  try {
    return asCalendarDate(operations.paidAt, '결제');
  } catch {
    return null;
  }
}

function hasAmbiguousPaidDate(order: ConfirmedOrder): boolean {
  const payments = (order.history ?? []).filter((event) => event.kind === 'operations-update'
    && event.details.action === 'payment-record');
  const latestPaidAmounts: number[] = [];
  for (let index = payments.length - 1; index >= 0; index -= 1) {
    const details = payments[index].details;
    if (details.revised !== '결제완료') break;
    if (typeof details.amount !== 'number' || !Number.isSafeInteger(details.amount)) return true;
    latestPaidAmounts.push(details.amount);
  }
  return latestPaidAmounts.some((amount) => amount !== latestPaidAmounts[0]);
}

type ServiceRevenueTier = 'general' | 'premium';

function serviceTierFromGarment(garment: GarmentRecord): ServiceRevenueTier | null {
  if (garment.serviceType === 'general' || garment.serviceType === 'sneaker-general') return 'general';
  if (garment.serviceType === 'premium' || garment.serviceType === 'sneaker-premium') return 'premium';
  return null;
}

function serviceTierFromItem(order: ConfirmedOrder, itemIndex: number): ServiceRevenueTier | null {
  const item = order.items?.[itemIndex];
  if (!item) return null;
  if (item.isSneaker) return item.itemId === 'sneakers_premium' ? 'premium' : 'general';
  return order.choices.serviceLevel;
}

/** A whole-order payment can be split only when every garment belongs to one tier. */
function orderServiceRevenueTier(order: ConfirmedOrder): ServiceRevenueTier | null {
  const expectedQuantity = (order.items ?? []).reduce((sum, item) => sum + item.quantity, 0);
  const garments = orderGarments(order);
  if (expectedQuantity < 1 || garments.length !== expectedQuantity) return null;
  const tiers = new Set<ServiceRevenueTier>();
  for (const garment of garments) {
    const tier = serviceTierFromGarment(garment);
    const itemTier = serviceTierFromItem(order, garment.itemIndex - 1);
    if (!tier || !itemTier || tier !== itemTier) return null;
    tiers.add(tier);
  }
  return tiers.size === 1 ? [...tiers][0] : null;
}

function digits(phone: string): string {
  return phone.replace(/\D/g, '');
}

function customerKey(order: ConfirmedOrder): string {
  return digits(order.customerPhone ?? '') || `unidentified:${order.id}`;
}

function orderGarments(order: ConfirmedOrder): GarmentRecord[] {
  // Legacy records may not yet have materialized per-garment rows. Derive only
  // the deterministic intake garments; never infer workflow/re-wash history.
  if (Array.isArray(order.garments) && order.garments.length > 0) return order.garments;
  const records: GarmentRecord[] = [];
  let sequence = 0;
  for (const item of order.items ?? []) {
    for (let unitIndex = 1; unitIndex <= item.quantity; unitIndex += 1) {
      sequence += 1;
      const garmentId = `${order.id}-${String(sequence).padStart(2, '0')}`;
      records.push({
        garmentId, orderId: order.id, sequence, totalSequence: order.totalQuantity,
        itemIndex: order.items.indexOf(item) + 1, unitIndex, itemType: item.itemId,
        itemName: item.displayNameKo,
        serviceType: item.isSneaker
          ? item.itemId === 'sneakers_premium' ? 'sneaker-premium' : 'sneaker-general'
          : order.choices.serviceLevel,
        photoStatus: 'not-captured', tagStatus: 'not-generated', tagPrintCount: 0,
        barcodeValue: garmentId, inspectionStatus: 'pending', cleaningStatus: 'pending',
        completionStatus: 'pending', handoverStatus: 'pending', auditEvents: [],
      });
    }
  }
  return records;
}

function hasBeenHandedOver(garment: GarmentRecord): boolean {
  return garment.handoverStatus === 'complete' || garment.processStatus === '반출 완료';
}

function isCompleted(garment: GarmentRecord): boolean {
  return garment.completionStatus === 'complete'
    || garment.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER'
    || READY_PROCESS_STATES.has(garment.processStatus ?? '');
}

function isReadyForHandover(garment: GarmentRecord): boolean {
  return garment.processStatus === '출고 대기'
    || garment.status === 'LAUNDRY_COMPLETED_READY_FOR_HANDOVER';
}

function currentGarmentStatus(order: ConfirmedOrder, garment: GarmentRecord): string {
  if (garmentDisplayStatus(order, garment, '') === '인도 완료') return '인도 완료';
  if (garment.processStatus) return garment.processStatus;
  if (isReadyForHandover(garment) || garment.completionStatus === 'complete') return '출고 대기';
  if (garment.cleaningStatus === 'in-progress') return '세탁 중';
  if (garment.cleaningStatus === 'complete') return '세탁 완료';
  if (order.inspection && order.status === '세탁 진행 승인'
    && ['매장입고', '세탁중', '세탁완료'].includes(currentOperations(order).stage)) return '세탁 대기';
  if (order.inspection) return '전문검수 완료';
  if (['simulated', 'printed'].includes(garment.tagStatus)) return '촬영/태그 완료';
  return '접수 완료';
}

function rewashCount(garment: GarmentRecord): number {
  const auditCount = (garment.auditEvents ?? []).filter((event) =>
    event.action === '재세탁 등록' || event.rewashCycle !== undefined).length;
  return Math.max(garment.rewashCount ?? 0, auditCount);
}

function periodContains(date: string, period: ManagementPeriod): boolean {
  return date >= period.from && date <= period.to;
}

function shiftDays(date: string, amount: number): string {
  return new Date(Date.parse(`${date}T00:00:00.000Z`) + amount * DAY_MS).toISOString().slice(0, 10);
}

function periodFor(mode: ManagementPeriodMode, asOf: string, from?: string, to?: string): {
  current: ManagementPeriod; previous: ManagementPeriod;
} {
  if (mode === 'custom') {
    if (!from || !to || !validDate(from) || !validDate(to) || from > to)
      throw new Error('사용자 지정 기간의 시작일과 종료일을 확인해 주세요.');
    const length = (Date.parse(`${to}T00:00:00.000Z`) - Date.parse(`${from}T00:00:00.000Z`)) / DAY_MS + 1;
    return {
      current: { from, to },
      previous: { from: shiftDays(from, -length), to: shiftDays(from, -1) },
    };
  }
  if (mode === 'day') {
    const previous = shiftDays(asOf, -1);
    return { current: { from: asOf, to: asOf }, previous: { from: previous, to: previous } };
  }
  if (mode === 'month') {
    const [year, month] = asOf.split('-').map(Number);
    const start = `${year}-${String(month).padStart(2, '0')}-01`;
    const end = new Date(Date.UTC(year, month, 0)).toISOString().slice(0, 10);
    const priorDate = new Date(Date.parse(`${start}T00:00:00.000Z`) - DAY_MS);
    const priorYear = priorDate.getUTCFullYear();
    const priorMonth = priorDate.getUTCMonth() + 1;
    const priorStart = `${priorYear}-${String(priorMonth).padStart(2, '0')}-01`;
    const priorEnd = shiftDays(start, -1);
    return { current: { from: start, to: end }, previous: { from: priorStart, to: priorEnd } };
  }
  if (mode === 'year') {
    const year = Number(asOf.slice(0, 4));
    return {
      current: { from: `${year}-01-01`, to: `${year}-12-31` },
      previous: { from: `${year - 1}-01-01`, to: `${year - 1}-12-31` },
    };
  }
  throw new Error('분석 기간을 확인해 주세요.');
}

function profileGroups(orders: ConfirmedOrder[]): CustomerGroup[] {
  orders = businessOrders(orders);
  const groups = new Map<string, CustomerGroup>();
  for (const order of orders) {
    const phone = digits(order.customerPhone ?? '');
    // Missing numbers are not evidence that two records are the same person.
    const key = customerKey(order);
    const group = groups.get(key) ?? { key, phone, orders: [] };
    group.orders.push(order);
    groups.set(key, group);
  }
  return [...groups.values()];
}

function metricsForPeriod(orders: ConfirmedOrder[], period: ManagementPeriod, asOf: string): ManagementMetrics {
  orders = businessOrders(orders);
  const selected = orders.filter((order) => {
    const date = orderCalendarDate(order);
    return date !== null && periodContains(date, period);
  });
  const revenueOrders = orders.filter((order) => {
    const paidDate = paidCalendarDate(order);
    return paidDate !== null && periodContains(paidDate, period);
  });
  const uncertainPaymentDate = orders.some((order) => currentOperations(order).paymentStatus === '결제완료'
    && !paidCalendarDate(order));
  // This is a successfully loaded saved-order dataset, not a pending request.
  // An empty period has zero activity; ambiguous payments still remain unknown.
  const revenueKnown = !uncertainPaymentDate;
  const revenue = revenueKnown
    ? revenueOrders.reduce((sum, order) => sum + currentOperations(order).paidAmount, 0)
    : null;
  const splitIsKnown = revenueKnown && !revenueOrders.some((order) => orderServiceRevenueTier(order) === null);
  const generalRevenue = splitIsKnown
    ? revenueOrders.filter((order) => orderServiceRevenueTier(order) === 'general')
      .reduce((sum, order) => sum + currentOperations(order).paidAmount, 0)
    : null;
  const premiumRevenue = splitIsKnown
    ? revenueOrders.filter((order) => orderServiceRevenueTier(order) === 'premium')
      .reduce((sum, order) => sum + currentOperations(order).paidAmount, 0)
    : null;
  const paidOrderCount = revenueOrders.length;
  const visitors = selected.length;
  const selectedGroups = profileGroups(selected);
  const allGroupsByKey = new Map(profileGroups(orders).map((group) => [group.key, group]));
  const newCustomers = selectedGroups.filter((group) => {
    const knownDates = (allGroupsByKey.get(group.key)?.orders ?? [])
      .map(orderCalendarDate).filter((date): date is string => date !== null);
    return knownDates.length > 0 && Math.min(...knownDates.map((date) => Date.parse(`${date}T00:00:00Z`)))
      >= Date.parse(`${period.from}T00:00:00Z`);
  }).length;
  const returningCustomers = selectedGroups.filter((group) => {
    const allCustomerOrders = allGroupsByKey.get(group.key)?.orders ?? [];
    const selectedVisits = allCustomerOrders.filter((order) => {
      const date = orderCalendarDate(order);
      return date !== null && periodContains(date, period);
    }).length;
    return selectedVisits > 0 && allCustomerOrders.some((order) => {
      const date = orderCalendarDate(order);
      return date !== null && date < period.from;
    });
  }).length;
  const itemQuantities: Record<string, number> = {};
  for (const order of selected) {
    for (const item of order.items ?? []) {
      itemQuantities[item.displayNameKo] = (itemQuantities[item.displayNameKo] ?? 0) + item.quantity;
    }
  }
  const garments = selected.flatMap(orderGarments);
  const uncollected = selected.filter((order) => !currentOperations(order).cancelledAt)
    .flatMap((order) => orderGarments(order).filter((garment) => !hasBeenHandedOver(garment)));
  const rewash = garments.reduce((sum, garment) => sum + rewashCount(garment), 0);
  return {
    actualRevenue: revenue,
    customerVisits: visitors,
    newCustomers,
    returningCustomers,
    intakeGarments: selected.reduce((sum, order) => sum + order.totalQuantity, 0),
    averageTicket: revenue !== null && paidOrderCount > 0 ? revenue / paidOrderCount : revenue === 0 ? 0 : null,
    generalRevenue,
    premiumRevenue,
    itemQuantities,
    rewashCases: rewash,
    uncollectedGarments: uncollected.length,
    pickupDeliveryOrders: selected.filter((order) =>
      order.choices.pickupRequested || order.choices.deliveryRequested).length,
  };
}

function sumQualifiedRevenue(orders: ConfirmedOrder[], level?: 'general' | 'premium'): number | null {
  const hasUnqualifiedPaidOrder = orders.some((order) => currentOperations(order).paymentStatus === '결제완료'
    && !paidCalendarDate(order)
    && (!level || orderServiceRevenueTier(order) === level || orderServiceRevenueTier(order) === null));
  if (hasUnqualifiedPaidOrder) return null;
  const paid = orders.filter((order) => paidCalendarDate(order) !== null);
  if (!level && paid.length) return paid.reduce((sum, order) => sum + currentOperations(order).paidAmount, 0);
  if (level && paid.some((order) => orderServiceRevenueTier(order) === null)) return null;
  if (level && paid.length) return paid.filter((order) => orderServiceRevenueTier(order) === level)
    .reduce((sum, order) => sum + currentOperations(order).paidAmount, 0);
  return 0;
}

function metricChanges(current: ManagementMetrics, previous: ManagementMetrics): ManagementMetrics {
  const difference = (a: number | null, b: number | null): number | null =>
    a === null || b === null ? null : a - b;
  const itemQuantities = current.itemQuantities && previous.itemQuantities
    ? Object.fromEntries([...new Set([...Object.keys(current.itemQuantities), ...Object.keys(previous.itemQuantities)])]
      .map((key) => [key, (current.itemQuantities![key] ?? 0) - (previous.itemQuantities![key] ?? 0)]))
    : null;
  return {
    actualRevenue: difference(current.actualRevenue, previous.actualRevenue),
    customerVisits: difference(current.customerVisits, previous.customerVisits),
    newCustomers: difference(current.newCustomers, previous.newCustomers),
    returningCustomers: difference(current.returningCustomers, previous.returningCustomers),
    intakeGarments: difference(current.intakeGarments, previous.intakeGarments),
    averageTicket: difference(current.averageTicket, previous.averageTicket),
    generalRevenue: difference(current.generalRevenue, previous.generalRevenue),
    premiumRevenue: difference(current.premiumRevenue, previous.premiumRevenue),
    itemQuantities,
    rewashCases: difference(current.rewashCases, previous.rewashCases),
    uncollectedGarments: difference(current.uncollectedGarments, previous.uncollectedGarments),
    pickupDeliveryOrders: difference(current.pickupDeliveryOrders, previous.pickupDeliveryOrders),
  };
}

export function managementSummary(orders: ConfirmedOrder[], asOf: ManagementDateInput): ManagementSummary {
  orders = businessOrders(orders);
  const date = asCalendarDate(asOf, '기준');
  const todayPeriod = { from: date, to: date };
  const monthPeriod = periodFor('month', date).current;
  const yearPeriod = periodFor('year', date).current;
  const garments = orders.flatMap(orderGarments);
  const activeGarments = orders.filter((order) => !currentOperations(order).cancelledAt)
    .flatMap(orderGarments);
  const uncollected = activeGarments.filter((garment) => !hasBeenHandedOver(garment));
  const rewashCases = garments.reduce((sum, garment) => sum + rewashCount(garment), 0);
  const allKnownPhones = new Set(orders.map((order) => digits(order.customerPhone ?? '') || `unidentified:${order.id}`));
  const completedGarments = activeGarments.filter(isCompleted).length;
  const readyForHandoverGarments = activeGarments.filter((garment) =>
    isReadyForHandover(garment) && !hasBeenHandedOver(garment)).length;
  return {
    asOf: date,
    today: metricsForPeriod(orders, todayPeriod, date),
    month: metricsForPeriod(orders, monthPeriod, date),
    year: metricsForPeriod(orders, yearPeriod, date),
    totalOrders: orders.length,
    uniqueCustomers: allKnownPhones.size,
    acceptedGarments: orders.reduce((sum, order) => sum + order.totalQuantity, 0),
    completedGarments,
    readyForHandoverGarments,
    uncollectedGarments: uncollected.length,
    pickupDeliveryOrders: orders.filter((order) =>
      order.choices.pickupRequested || order.choices.deliveryRequested).length,
    rewashCases,
    actualRevenueAllTime: sumQualifiedRevenue(orders),
    generalRevenueAllTime: sumQualifiedRevenue(orders, 'general'),
    premiumRevenueAllTime: sumQualifiedRevenue(orders, 'premium'),
    todayConfirmedSales: confirmedSales(orders, todayPeriod),
    monthConfirmedSales: confirmedSales(orders, monthPeriod),
    inProgressGarments: activeGarments.filter((garment) => !isCompleted(garment)
      && !isReadyForHandover(garment) && !hasBeenHandedOver(garment)).length,
  };
}

function confirmedSales(orders: ConfirmedOrder[], period: ManagementPeriod): number {
  return orders.filter((order) => {
    if (currentOperations(order).cancelledAt) return false;
    const date = orderCalendarDate(order);
    return date !== null && periodContains(date, period);
  }).reduce((sum, order) => sum + (Number.isSafeInteger(order.estimatedTotal) ? order.estimatedTotal : 0), 0);
}

export function periodComparison(
  orders: ConfirmedOrder[],
  mode: ManagementPeriodMode,
  asOf: ManagementDateInput,
  from?: string,
  to?: string,
): ManagementPeriodComparison {
  const date = asCalendarDate(asOf, '기준');
  const periods = periodFor(mode, date, from, to);
  const current = metricsForPeriod(orders, periods.current, date);
  const previous = metricsForPeriod(orders, periods.previous, date);
  return { mode, currentPeriod: periods.current, previousPeriod: periods.previous,
    current, previous, change: metricChanges(current, previous) };
}

function sortOrders(orders: ConfirmedOrder[]): ConfirmedOrder[] {
  return businessOrders(orders).sort((a, b) => (orderCalendarDate(a) ?? '').localeCompare(orderCalendarDate(b) ?? '')
    || (Date.parse(a.intakeAt) - Date.parse(b.intakeAt) || 0) || a.id.localeCompare(b.id));
}

/** Group original orders for display only. Never merge orders or inherit another visit's records. */
export function managementOrdersByDate(orders: readonly ConfirmedOrder[]): Array<{
  intakeDate: string | null; orders: ConfirmedOrder[];
}> {
  const groups = new Map<string | null, ConfirmedOrder[]>();
  for (const order of sortOrders([...orders]).reverse()) {
    const intakeDate = orderCalendarDate(order);
    const group = groups.get(intakeDate) ?? [];
    group.push(order);
    groups.set(intakeDate, group);
  }
  return [...groups].map(([intakeDate, orders]) => ({ intakeDate, orders }));
}

function buildCustomerProfile(group: CustomerGroup): CustomerManagementProfile {
  const history = sortOrders(group.orders);
  const latest = history.at(-1);
  const uncollectedOrders = history.filter((order) => !currentOperations(order).cancelledAt
    && orderGarments(order).some((garment) => !hasBeenHandedOver(garment)));
  const completedOrders = history.filter((order) => {
    const operations = currentOperations(order);
    const garments = orderGarments(order);
    return garments.length > 0 && garments.every(hasBeenHandedOver)
      || Boolean(operations.completedAt && !uncollectedOrders.includes(order)
        && garments.every(isCompleted));
  });
  const activeOrders = history.filter((order) => !currentOperations(order).cancelledAt
    && !completedOrders.includes(order));
  const paidOrders = history.filter((order) => paidCalendarDate(order) !== null);
  const hasUnqualifiedPaidOrder = history.some((order) => currentOperations(order).paymentStatus === '결제완료'
    && !paidCalendarDate(order));
  const paidTotal = hasUnqualifiedPaidOrder ? null : paidOrders.length
    ? paidOrders.reduce((sum, order) => sum + currentOperations(order).paidAmount, 0)
    : history.length ? 0 : null;
  return {
    customerName: latest?.customerName ?? '',
    customerPhone: latest?.customerPhone ?? '',
    normalizedPhone: group.phone,
    customerAddress: latest?.customerAddress ?? '',
    firstVisit: history.find((order) => orderCalendarDate(order) !== null)?.intakeAt ?? null,
    recentVisit: history.slice().reverse().find((order) => orderCalendarDate(order) !== null)?.intakeAt ?? null,
    visitCount: history.length,
    orderCount: history.length,
    garmentCount: history.reduce((sum, order) => sum + order.totalQuantity, 0),
    paidTotal,
    activeOrders,
    completedOrders,
    uncollectedOrders,
    pickupDeliveryHistory: history.map((order) => ({
      orderId: order.id,
      intakeAt: order.intakeAt,
      pickupRequested: order.choices.pickupRequested,
      deliveryRequested: order.choices.deliveryRequested,
      pickupDate: order.operations?.pickupDate || null,
      deliveryDate: order.operations?.deliveryDate || null,
    })),
    customerRequests: history.filter((order) => Boolean(order.choices.customerRequests?.trim())
      ).map((order) => ({ orderId: order.id, request: order.choices.customerRequests })),
    orderHistory: history,
  };
}

export function searchManagementCustomers(orders: ConfirmedOrder[], query: string): ManagementCustomerSearchResult[] {
  const term = query.trim().toLocaleLowerCase('ko-KR');
  const normalizedDigits = digits(term);
  const digitSearch = normalizedDigits.length >= 3 && /^[\d\s()+-]+$/.test(term);
  const results: ManagementCustomerSearchResult[] = [];
  for (const group of profileGroups(orders)) {
    const matchedOrderIds = group.orders.filter((order) => {
      const phoneDigits = digits(order.customerPhone ?? '');
      const garmentFields = orderGarments(order).flatMap((garment) => [garment.garmentId, garment.barcodeValue]);
      const values = [
        order.id, order.customerName, order.customerPhone, phoneDigits,
        ...(order.items ?? []).flatMap((item) => [item.displayNameKo, item.itemId]),
        ...garmentFields,
      ];
      if (!term) return true;
      return values.some((value) => value.toLocaleLowerCase('ko-KR').includes(term)
        || digitSearch && digits(value).includes(normalizedDigits));
    }).map((order) => order.id);
    if (term && matchedOrderIds.length === 0) continue;
    const profile = buildCustomerProfile(group);
    results.push({ ...profile, matchedOrderIds: [...new Set(matchedOrderIds)] });
  }
  return results.sort((a, b) => (orderCalendarDate(b.orderHistory.at(-1)!) ?? '')
    .localeCompare(orderCalendarDate(a.orderHistory.at(-1)!) ?? '')
    || a.normalizedPhone.localeCompare(b.normalizedPhone));
}

export function customerManagementProfile(
  orders: ConfirmedOrder[],
  phone: string,
): CustomerManagementProfile | null {
  const normalized = digits(phone);
  if (!normalized) return null;
  const group = profileGroups(orders).find((entry) => entry.phone === normalized);
  return group ? buildCustomerProfile(group) : null;
}

function reminderStatuses(order: ConfirmedOrder, elapsed: number | null): ReminderDayStatus[] {
  const storedReminders = order.customerNotifications ?? [];
  return STORAGE_REMINDER_DAYS.map((day) => {
    const current = storedReminders.filter((notice) =>
      notice.type === '장기 미수령 알림' && notice.reminderDay === day && notice.storagePolicy === STORAGE_NOTICE_POLICY);
    const prepared = current.length > 0;
    const confirmed = current.some((notice) => !!notice.externalSendConfirmation);
    return {
      day,
      status: elapsed === null || elapsed < day ? 'not-due'
        : confirmed ? 'externally-confirmed-by-staff' : prepared ? 'draft-prepared-not-sent' : 'due-not-prepared',
      actuallySent: false,
    };
  });
}

export function uncollectedGarments(orders: ConfirmedOrder[], asOf: ManagementDateInput): UncollectedGarment[] {
  orders = businessOrders(orders);
  const date = asCalendarDate(asOf, '기준');
  const results: UncollectedGarment[] = [];
  for (const order of orders) {
    if (currentOperations(order).cancelledAt) continue;
    const garments = orderGarments(order);
    const unhanded = garments.filter((garment) => !hasBeenHandedOver(garment));
    if (!unhanded.length) continue;
    let intakeDate: string | null = null;
    let elapsed: number | null = null;
    try {
      intakeDate = intakeCalendarDate(order);
      elapsed = daysSinceIntake(order, date);
    } catch {
      // An invalid/missing intake date remains explicitly unavailable.
    }
    const perGarmentFee = elapsed !== null
      ? Math.max(0, elapsed - (FREE_STORAGE_DAYS - 1)) * STORAGE_FEE_PER_ITEM_PER_DAY
      : null;
    const reminderState = reminderStatuses(order, elapsed);
    for (const garment of unhanded) {
      results.push({
        orderId: order.id,
        garmentId: garment.garmentId,
        barcodeValue: garment.barcodeValue,
        customerName: order.customerName,
        customerPhoneLast4: digits(order.customerPhone).slice(-4),
        intakeAt: intakeDate,
        elapsedDays: elapsed,
        storageFee: perGarmentFee,
        itemName: garment.itemName,
        processStatus: currentGarmentStatus(order, garment),
        completedAt: garment.completedAt ?? order.orderCompletedAt ?? null,
        handoverMethod: order.choices.deliveryRequested ? 'delivery'
          : order.choices.directPickup ? 'store-pickup' : 'unknown',
        reminders: reminderState,
      });
    }
  }
  return results.sort((a, b) => (b.elapsedDays ?? -1) - (a.elapsedDays ?? -1)
    || a.orderId.localeCompare(b.orderId) || a.garmentId.localeCompare(b.garmentId));
}