/** Bound read-only requests, including their response bodies. Never retry writes. */
export async function withPhotoReadDeadline<T>(
  read: (signal: AbortSignal) => Promise<T>,
  timeoutMs = 3000,
): Promise<T> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new Error('사진 읽기 응답 시간이 초과되었습니다. 자동으로 다시 확인합니다.'));
    }, timeoutMs);
  });
  try {
    // A broken fetch implementation must not prevent the poller from settling.
    return await Promise.race([read(controller.signal), deadline]);
  } finally {
    clearTimeout(timer);
  }
}