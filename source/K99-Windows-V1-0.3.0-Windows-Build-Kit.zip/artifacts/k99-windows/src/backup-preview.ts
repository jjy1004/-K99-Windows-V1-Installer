import type { ConfirmedOrder } from './order-record';

const canonical = (value: unknown): string => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
    .map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(',')}}`;
  return JSON.stringify(value);
};

/** Pure inspection only: never calls the legacy reader (which can migrate storage). */
export function previewBackup(text: string, current: readonly ConfirmedOrder[]) {
  if (text.length > 10_000_000) throw new Error('백업은 10MB 이하로 선택하세요.');
  const value = JSON.parse(text);
  if (value?.format !== 'k99-management-backup' || value.schemaVersion !== 1 || !Array.isArray(value.orders))
    throw new Error('지원하는 K99 주문 백업 형식이 아닙니다.');
  const ids = new Set<string>(), garments = new Set<string>(), barcodes = new Set<string>();
  return value.orders.map((order: ConfirmedOrder) => {
    if (!order || typeof order.id !== 'string' || !order.id || ids.has(order.id) ||
      !Array.isArray(order.items) || !order.choices || typeof order.customerName !== 'string' ||
      typeof order.customerFolderName !== 'string' || typeof order.choices.customerRequests !== 'string')
      throw new Error('주문 구조 또는 중복 ID를 확인하세요.');
    ids.add(order.id);
    if (order.garments !== undefined && !Array.isArray(order.garments)) throw new Error('의류 목록 형식 오류');
    for (const garment of order.garments ?? []) {
      if (!garment || garment.orderId !== order.id || typeof garment.garmentId !== 'string' ||
        typeof garment.barcodeValue !== 'string' || !garment.garmentId || !garment.barcodeValue ||
        garments.has(garment.garmentId) || barcodes.has(garment.barcodeValue))
        throw new Error('의류 연결 또는 바코드 중복 오류');
      garments.add(garment.garmentId); barcodes.add(garment.barcodeValue);
    }
    const matches = current.filter(item => item.id === order.id);
    const crossConflict = (order.garments ?? []).some(g => current.some(o => o.id !== order.id &&
      o.garments?.some(existing => existing.garmentId === g.garmentId || existing.barcodeValue === g.barcodeValue)));
    return { id: order.id, status: crossConflict || matches.length > 1 ? '충돌' :
      !matches.length ? '신규' : canonical(matches[0]) === canonical(order) ? '동일' : '충돌',
      garments: order.garments?.length ?? 0 };
  }) as { id: string; status: string; garments: number }[];
}
