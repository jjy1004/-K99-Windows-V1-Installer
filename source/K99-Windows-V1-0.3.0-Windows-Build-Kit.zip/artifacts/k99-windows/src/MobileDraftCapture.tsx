import { useCallback, useEffect, useRef, useState } from 'react';
import { Smartphone, X } from 'lucide-react';
import bwipjs from 'bwip-js/browser';
import type { GarmentRecord } from './garment-record';
import { mobilePhotoStatus, startMobilePhotos, stopMobilePhotos, type MobilePhotoSession, type MobilePhotoTarget } from './mobile-photo-client';
import './mobile-draft-capture.css';

type DesktopEvents = { k99Desktop?: { onChanged?: (cb: () => void) => (() => void) | void } };
const errText = (c: unknown, f: string) => (c instanceof Error && c.message ? c.message : f);
const jobLabel = (s?: string) => {
  if (!s) return '';
  if (s === 'printed' || s === 'submitted' || s === 'skipped' || s === 'pending') return `태그 작업 상태: ${s}`;
  if (s === 'failed') return '태그 작업 실패 - PC 화면에서 확인해 주세요.';
  return `태그 작업 상태 확인 안 됨 (${s}) - 출력 여부를 직접 확인해 주세요.`;
};

/** Phone close-up capture (care label / stain detail). Owns only its own session id. */
export function MobileDraftCapture({ available, unavailableReason, target, open, onOpenChange, onCaptured,inline=false }: {
  available: boolean; unavailableReason: string; target: MobilePhotoTarget | null;
  open: boolean; onOpenChange: (open: boolean) => void; onCaptured: (garment: GarmentRecord) => void;
  inline?:boolean;
}) {
  const [session, setSession] = useState<MobilePhotoSession | null>(null);
  const [error, setError] = useState('');
  const [qrError, setQrError] = useState('');
  const [closing, setClosing] = useState(false);
  const [starting, setStarting] = useState(false);
  const [urlIndex, setUrlIndex] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  const ownId = useRef<string | null>(null);
  const gen = useRef(0);
  const seenCount = useRef(0);
  const onCapturedRef = useRef(onCaptured); onCapturedRef.current = onCaptured;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const restoreRef = useRef<HTMLElement | null>(null);
  const targetKey = target ? `${target.orderId}|${target.unitKey}|${target.itemId}|${target.customerName}|${target.customerPhone}` : '';

  const release = useCallback(() => {
    gen.current += 1;
    const id = ownId.current; ownId.current = null;
    if (id) void stopMobilePhotos(id).catch(() => undefined);
    setSession(null); setStarting(false); seenCount.current = 0;
  }, []);

  const close = useCallback(async () => {
    if (closing) return;
    setClosing(true);
    try {
      if (ownId.current) await stopMobilePhotos(ownId.current);
      release(); setError(''); setQrError(''); onOpenChange(false);
    } catch (c) {
      setError(`QR 종료를 확인하지 못했습니다. 다시 닫기를 누르세요. ${errText(c, '')}`);
    } finally { setClosing(false); }
  }, [release, onOpenChange, closing]);
  const closeRef = useRef(close); closeRef.current = close;

  // Target change or unmount revokes only this component's session.
  useEffect(() => () => release(), [release]);
  const previousTarget = useRef(targetKey);
  useEffect(() => {
    if (previousTarget.current !== targetKey) {
      previousTarget.current = targetKey;
      void closeRef.current();
    }
  }, [targetKey]);
  useEffect(() => { if (open && !available) closeRef.current(); }, [open, available]);

  async function begin() {
    if (!available || !target || starting) return;
    restoreRef.current = document.activeElement as HTMLElement | null;
    release(); setError(''); setQrError(''); setUrlIndex(0); onOpenChange(true); setStarting(true); setNow(Date.now());
    const my = gen.current;
    try {
      const s = await startMobilePhotos(target);
      if (my !== gen.current) { void stopMobilePhotos(s.id).catch(() => undefined); return; }
      ownId.current = s.id; seenCount.current = s.uploadedCount; setSession(s);
    } catch (c) { if (my === gen.current) setError(errText(c, '휴대폰 촬영 세션을 시작하지 못했습니다.')); }
    finally { if (my === gen.current) setStarting(false); }
  }
  useEffect(()=>{
    if(inline&&available&&target)void begin();
    // The sidebar owner keys this component by immutable customer/garment target.
    // A failed start is retried only by the employee, never an automatic loop.
  },[inline,available,targetKey]);

  const refresh = useCallback(async () => {
    const id = ownId.current; if (!id) return;
    const my = gen.current;
    try {
      const s = await mobilePhotoStatus(id);
      if (my !== gen.current || ownId.current !== id) return;
      if (s.uploadedCount < seenCount.current) return;
      setError('');
      setSession(s);
      if (s.uploadedCount > seenCount.current) {
        seenCount.current = s.uploadedCount;
        if (s.lastResult?.garment) onCapturedRef.current(s.lastResult.garment);
      }
    } catch (c) { if (my === gen.current) setError(errText(c, '휴대폰 사진 상태를 읽지 못했습니다.')); }
  }, []);

  useEffect(() => {
    if (!session?.id) return;
    const t = setInterval(() => { void refresh(); setNow(Date.now()); }, 2000);
    const off = (window as unknown as DesktopEvents).k99Desktop?.onChanged?.(() => void refresh());
    return () => { clearInterval(t); if (typeof off === 'function') off(); };
  }, [session?.id, refresh]);

  const url = session?.urls[urlIndex] ?? session?.urls[0] ?? '';
  useEffect(() => {
    if (!url || !canvasRef.current) return;
    try { bwipjs.toCanvas(canvasRef.current, { bcid: 'qrcode', text: url, scale: 5, padding:4 }); setQrError(''); }
    catch { setQrError('QR 코드를 만들지 못했습니다. 아래 주소를 휴대폰에 직접 입력해 주세요.'); }
  }, [url]);

  useEffect(() => {
    if (!open||inline) return;
    const el = dialogRef.current;
    el?.querySelector<HTMLElement>('[data-autofocus]')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeRef.current(); return; }
      if (e.key !== 'Tab' || !el) return;
      const f = Array.from(el.querySelectorAll<HTMLElement>('button:not([disabled]),select,input,textarea,[tabindex="0"]'));
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (!el.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
      else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey, true);
    return () => { document.removeEventListener('keydown', onKey, true); restoreRef.current?.focus?.(); };
  }, [open,inline]);

  const expired = !!session && session.expiresAt <= now;
  const remain = session ? Math.max(0, Math.ceil((session.expiresAt - now) / 60000)) : 0;
  const job = session?.lastResult?.job?.status;

  if(inline)return <section className="mdc-inline" aria-label="휴대폰 정밀 촬영">
    <button type="button" onClick={()=>void begin()} disabled={!available||!target||starting}
      data-testid="button-mobile-open">휴대폰 정밀 촬영</button>
    <div className="mdc-inline-qr" style={{width:130,height:130,margin:'6px auto',background:'#fff'}}>
      {session&&!expired?<canvas ref={canvasRef} style={{width:130,height:130}} aria-label="휴대폰 업로드 QR" data-testid="img-mobile-qr"/>:
        <span>{starting?'QR 연결 중…':expired?'QR 만료 · 버튼으로 갱신':available?'QR 준비':'고객·품목 선택 후 QR 연결'}</span>}
    </div>
    <small role="status">{error||qrError||(!available?unavailableReason:session?`${session.itemName} · ${session.uploadedCount}컷 · 같은 WiFi`:'')}</small>
  </section>;

  return (
    <section className="mdc" aria-label="휴대폰 정밀 촬영" data-testid="section-mobile-capture">
      <div className="mdc__text"><h4>휴대폰 정밀 촬영 (QR)</h4><p>케어라벨 / 세부 오염 근접 촬영용</p></div>
      <button type="button" className="mdc__open" disabled={!available || !target} onClick={() => void begin()} data-testid="button-mobile-open">
        <Smartphone aria-hidden="true" />휴대폰 정밀 촬영 (QR)</button>
      {!available && <p className="mdc__hint" data-testid="text-mobile-unavailable">{unavailableReason}</p>}
      {open && <div className="mdc__backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) close(); }}>
        <div ref={dialogRef} className="mdc__dialog" role="dialog" aria-modal="true" aria-labelledby="mdc-title" data-testid="dialog-mobile">
          <header><h3 id="mdc-title">휴대폰 정밀 촬영</h3>
            <button type="button" className="mdc__x" onClick={close} aria-label="닫기" data-autofocus data-testid="button-mobile-close"><X aria-hidden="true" /></button></header>
          {starting && <div className="mdc__skel" aria-busy="true"><span /><span /><span /></div>}
          {session && <div className="mdc__body">
            <div className="mdc__qr">{expired ? <p className="mdc__err">QR이 만료되었습니다. 닫고 다시 열어 주세요.</p> : <canvas ref={canvasRef} aria-label="휴대폰 업로드 QR" data-testid="img-mobile-qr" />}</div>
            <dl className="mdc__meta">
              <dt>고객</dt><dd data-testid="text-mobile-customer">{session.customerName} · {session.phoneLast4}</dd>
              <dt>품목</dt><dd data-testid="text-mobile-item">{session.itemName}</dd>
              <dt>저장 폴더</dt><dd data-testid="text-mobile-folder">{session.folderIdentifier}</dd>
              <dt>유효 시간</dt><dd data-testid="text-mobile-expiry">{expired ? '만료됨' : `약 ${remain}분 남음 (10분 유효)`}</dd>
            </dl>
            {session.urls.length > 1 && <label className="mdc__urls">네트워크 주소 선택
              <select value={urlIndex} onChange={(e) => setUrlIndex(Number(e.target.value))} data-testid="select-mobile-url">
                {session.urls.map((u, i) => <option key={u} value={i}>{u.replace(/\?.*$/, '')}</option>)}</select></label>}
            <input className="mdc__url" readOnly value={url} onFocus={(e) => e.currentTarget.select()} aria-label="업로드 주소" data-testid="input-mobile-url" />
            <ul className="mdc__guide">
              <li>사진은 매장 PC에 즉시 저장됩니다. AI 분석은 직원이 별도로 요청할 때만 시도하며, 소재·색상 선택과 태그 출력을 지연하지 않습니다.</li>
              <li>휴대폰과 이 PC가 같은 매장 WiFi에 연결되어 있어야 합니다.</li>
              <li>연결이 안 되면 Windows 네트워크를 개인(Private)으로 바꾸고 방화벽에서 TCP 5050 포트를 허용해 주세요.</li>
              <li>사진은 매장 PC로만 전송되며 클라우드로 보내지 않습니다. 창을 닫으면 QR은 즉시 무효가 됩니다.</li>
            </ul>
            {session.uploadedCount > 0 && <p className="mdc__ok" role="status" data-testid="status-mobile-count">휴대폰 사진 {session.uploadedCount}장이 성공적으로 동기화되었습니다.</p>}
            {session.lastResult?.archive && <p className="mdc__small">마지막 파일: {session.lastResult.archive.fileName}</p>}
            {job && <p className={job === 'failed' || !['printed','submitted','skipped','pending'].includes(job) ? 'mdc__err' : 'mdc__small'} data-testid="status-mobile-job">{jobLabel(job)}</p>}
          </div>}
          {error && <p className="mdc__err" role="alert" data-testid="status-mobile-error">{error}</p>}
           {qrError && <p className="mdc__err" role="alert">{qrError}</p>}
           <footer><button type="button" disabled={closing} onClick={() => void close()} data-testid="button-mobile-done">{closing ? '연결 종료 중…' : '닫기 (QR 무효화)'}</button></footer>
        </div>
      </div>}
    </section>
  );
}
