import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Camera, CameraOff, Footprints } from 'lucide-react';
import { equipmentRequest, getEquipmentState, DEFAULT_FOOT_SWITCH_KEY, type EquipmentConfig } from './equipment-client';
import type { GarmentRecord } from './garment-record';
import './native-draft-camera.css';
import { openPreferredCamera, useFootCapture } from './camera-capture-controls';
import { MobileDraftCapture } from './MobileDraftCapture';
import {LocalGarmentPhoto} from './components/LocalGarmentPhoto';

export type DraftCaptureTarget = { rowId: number; itemId: string; itemName: string; unitIndex: number; rowQuantity: number };
export type DraftNativeUnit = { unitKey: string; rowId: number; itemId: string; unitIndex: number; garment: GarmentRecord };
export const draftUnitKey = (rowId: number, unitIndex: number) => `${rowId}:${unitIndex}`;

type CaptureResponse = { garment: GarmentRecord; archive?: { folder: string; fileName: string }; job?: unknown };

function mockShot(label: string, n: number) {
  const c = document.createElement('canvas'); c.width = 960; c.height = 720;
  const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
  g.fillStyle = '#e9e4d6'; g.fillRect(0, 0, 960, 720);
  g.fillStyle = '#21323d'; g.font = 'bold 34px sans-serif'; g.fillText(`${label} · ${n}번째`, 40, 80);
  g.fillStyle = 'rgba(176,52,40,.6)'; g.font = 'bold 110px sans-serif'; g.fillText('모의 촬영', 220, 400);
  return c.toDataURL('image/jpeg', 0.9);
}

/** Prereceipt native camera: one live preview, unit selector, every shot saved immediately via capture-draft. */
export function NativeDraftCamera({ orderId, targets, units, customerName, customerPhone, disabled, onCaptured }: {
  orderId: string; targets: DraftCaptureTarget[]; units: DraftNativeUnit[];
  customerName: string; customerPhone: string; disabled?: boolean;
  onCaptured: (unit: DraftNativeUnit) => void;
}) {
  const [config, setConfig] = useState<EquipmentConfig | null>(null);
  const [native, setNative] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [selected, setSelected] = useState('');
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState('');
  const [previewOn, setPreviewOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [lastShot, setLastShot] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const busyRef = useRef(false);

  useEffect(() => {
    let live = true;
    getEquipmentState().then((s) => { if (!live) return; setConfig(s.config); setNative(s.native); setDeviceId((d) => d || s.config.cameraDeviceId); })
      .catch((c) => live && setLoadError(c instanceof Error ? c.message : '장비 설정을 읽지 못했습니다.'));
    return () => { live = false; };
  }, []);

  const keys = useMemo(() => targets.map((t) => draftUnitKey(t.rowId, t.unitIndex)), [targets]);
  useEffect(() => { if (!keys.includes(selected)) setSelected(keys[0] ?? ''); }, [keys, selected]);
  const target = targets.find((t) => draftUnitKey(t.rowId, t.unitIndex) === selected);
  const unitFor = (key: string, itemId: string) => units.find((u) => u.unitKey === key && u.itemId === itemId);
  const shotCount = (u?: DraftNativeUnit) => u?.garment.photoHistory?.length ?? 0;
  const conflict = (key: string, itemId: string) => units.some((u) => u.unitKey === key && u.itemId !== itemId);
  const targetConflict = !!target && conflict(selected, target.itemId);
  const realMode = native && config?.mode === 'real';
  const footKey = config?.footSwitchKey ?? DEFAULT_FOOT_SWITCH_KEY;

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setPreviewOn(false);
  }, []);
  useEffect(() => stop, [stop]);

  async function start() {
    setMessage(null);
    if (!realMode) { setPreviewOn(true); return; }
    try {
      stop();
      const stream = await openPreferredCamera(deviceId);
      setDeviceId(stream.getVideoTracks()[0]?.getSettings().deviceId||deviceId);
      streamRef.current = stream;
      if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); }
      setPreviewOn(true);
      const all = await navigator.mediaDevices.enumerateDevices();
      setDevices(all.filter((d) => d.kind === 'videoinput'));
    } catch (c) { setMessage({ kind: 'error', text: c instanceof Error ? c.message : '카메라를 시작하지 못했습니다.' }); stop(); }
  }

  async function shoot() {
    if (!target || busyRef.current || disabled || targetConflict) return;
    busyRef.current = true; setBusy(true);
    try {
      const key = draftUnitKey(target.rowId, target.unitIndex);
      const n = shotCount(unitFor(key, target.itemId)) + 1;
      let image: string;
      if (realMode) {
        const v = videoRef.current;
        if (!previewOn || !v || !v.videoWidth) throw new Error('카메라 영상이 준비되지 않았습니다.');
        const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
        const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
        g.drawImage(v, 0, 0); image = c.toDataURL('image/jpeg', 0.92);
      } else image = mockShot(target.itemName, n);
      setLastShot(image);
      const r = await equipmentRequest<CaptureResponse>('capture-draft', {
        orderId, unitKey: key, itemName: target.itemName, itemId: target.itemId, customerName, customerPhone,
        imageDataUrl: image, photo_type: 'intake', requestId: crypto.randomUUID(), expectedMode: realMode ? 'real' : 'mock',
      });
      onCaptured({ unitKey: key, rowId: target.rowId, itemId: target.itemId, unitIndex: target.unitIndex, garment: r.garment });
      const count = r.garment.photoHistory?.length ?? n;
      setMessage({ kind: 'ok', text: `${target.itemName} ${target.unitIndex}번 · ${count}컷 저장${count === 1 ? ' · 태그 자동 발행 예약' : ''}${r.archive ? ` · ${r.archive.fileName}` : ''}` });
    } catch (c) { setMessage({ kind: 'error', text: c instanceof Error ? c.message : '사진을 저장하지 못했습니다.' }); }
    finally { busyRef.current = false; setBusy(false); }
  }
  const shootRef = useRef(shoot);
  shootRef.current = shoot;

  const footReady = !mobileOpen && previewOn && !!target && !disabled && !targetConflict;
  const footError = useFootCapture(footReady, footKey, () => void shootRef.current());

  const mobileAvailable = realMode && !!target && !disabled && !targetConflict;
  const mobileReason = !native ? '휴대폰 촬영은 Windows 매장 프로그램에서만 사용할 수 있습니다.' : !realMode ? '휴대폰 촬영은 실카메라 모드에서만 사용할 수 있습니다.'
    : disabled ? '고객 이름과 전화번호를 먼저 입력해 주세요.' : targetConflict ? '품목이 변경된 줄은 휴대폰 촬영을 할 수 없습니다.' : !target ? '촬영할 의류를 선택해 주세요.' : '';
  const mobileTarget = target ? { orderId, unitKey: selected, itemId: target.itemId, itemName: target.itemName, customerName, customerPhone } : null;

  if (!targets.length) return null;
  return (
    <section className="ndc" aria-label="접수 사진 촬영" data-testid="section-native-draft-camera">
      <header className="ndc__head">
        <div><h3>접수 사진 촬영</h3><p>촬영 사진은 바로 저장됩니다. 태그는 라벨 분석 완료 또는 다음 의류 촬영·접수 마감 시 1회 자동 발행됩니다.</p></div>
        <span className={`ndc__mode ${realMode ? 'is-real' : ''}`} data-testid="status-ndc-mode">{config ? realMode ? '실카메라' : '모의 촬영' : '설정 확인 중'}</span>
      </header>
      {loadError && <p className="ndc__err" role="alert">{loadError}</p>}
      {footError && <p className="ndc__err" role="alert">{footError}</p>}
      <div className="ndc__units" role="listbox" aria-label="촬영할 의류">
        {targets.map((t) => {
          const key = draftUnitKey(t.rowId, t.unitIndex);
          const n = shotCount(unitFor(key, t.itemId));
          return <button key={key} type="button" role="option" aria-selected={key === selected} onClick={() => setSelected(key)}
            data-testid={`button-ndc-unit-${key}`}><span>{t.itemName}{t.rowQuantity > 1 ? ` ${t.unitIndex}번` : ''}</span><em>{conflict(key, t.itemId) ? '품목 변경됨' : `${n}컷`}</em></button>;
        })}
      </div>
      <h4 className="ndc__section">PC 카메라(Insta360) / 풋스위치 촬영</h4>
      <div className="ndc__stage">
        <video ref={videoRef} muted playsInline hidden={!realMode || !previewOn} />
        {!previewOn && <span>{realMode ? '미리보기를 켜면 카메라 영상이 표시됩니다.' : '모의 모드: 미리보기를 켜고 촬영하면 모의 이미지가 저장됩니다.'}</span>}
        {previewOn && !realMode && <span>모의 촬영 대기 중</span>}
        {lastShot && <img src={lastShot} alt="마지막 촬영" className="ndc__last" data-testid="img-ndc-last" />}
        {target && <div className="ndc__count" data-testid="text-ndc-count"><strong>{target.itemName} {target.unitIndex}번</strong><span aria-hidden="true"> · </span><em>{shotCount(unitFor(selected, target.itemId))}컷</em></div>}
      </div>
      <div className="ndc__bar">
        {realMode && <select value={deviceId} onChange={(e) => { setDeviceId(e.target.value); stop(); }} aria-label="카메라 장치" data-testid="select-ndc-device">
          <option value="">기본 카메라</option>
          {config?.cameraDeviceId && !devices.some((d) => d.deviceId === config.cameraDeviceId) && <option value={config.cameraDeviceId}>저장된 장치</option>}
          {devices.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `카메라 ${i + 1}`}</option>)}
        </select>}
        <button type="button" className={!previewOn ? 'ndc__preview-guide' : undefined} onClick={() => (previewOn ? stop() : void start())} data-testid="button-ndc-preview">
          {previewOn ? <><CameraOff aria-hidden="true" />미리보기 끄기</> : <><Camera aria-hidden="true" />미리보기 켜기</>}</button>
        <button type="button" className="ndc__shoot" disabled={!previewOn || !target || busy || disabled || targetConflict} onClick={() => void shoot()} data-testid="button-ndc-shoot">
          {busy ? '저장 중' : '촬영'}</button>
        {target && shotCount(unitFor(selected, target.itemId)) > 0 && <span className="ndc__shot-guide" role="status">
          추가 촬영 가능 / {shotCount(unitFor(selected, target.itemId))}컷 촬영됨
        </span>}
        {footReady && <span className="ndc__foot" data-testid="status-ndc-foot"><Footprints aria-hidden="true" />풋 스위치 {footKey}</span>}
      </div>
      {realMode && !!target && shotCount(unitFor(selected, target.itemId)) > 0 && <ol className="ndc__photos" aria-label="이 의류의 PC·휴대폰 통합 촬영 순서" data-testid="list-ndc-hybrid-photos">
        {unitFor(selected, target.itemId)?.garment.photoHistory?.map((photo, index) => <li key={photo.requestId}>
          <LocalGarmentPhoto photoId={photo.sourcePhotoId} pathHint={photo.path}
            orderId={unitFor(selected,target.itemId)?.garment.orderId} garmentId={photo.garmentId} alt={`${target.itemName} ${target.unitIndex}번 ${index + 1}번째 사진`} />
          <span>{index + 1}컷</span>
        </li>)}
      </ol>}
      {target&&unitFor(selected,target.itemId)?.garment.material_group&&<p role="status" data-testid="status-ndc-label-material">
        [소재] {unitFor(selected,target.itemId)?.garment.material_group} ({unitFor(selected,target.itemId)?.garment.wash_method}) /
        [색상] {unitFor(selected,target.itemId)?.garment.color||'확인 필요'}
      </p>}
      {target && <MobileDraftCapture available={mobileAvailable} unavailableReason={mobileReason} target={mobileTarget}
        open={mobileOpen} onOpenChange={setMobileOpen}
        onCaptured={(garment) => onCaptured({ unitKey: draftUnitKey(target.rowId, target.unitIndex), rowId: target.rowId, itemId: target.itemId, unitIndex: target.unitIndex, garment })} />}
      {targetConflict && <p className="ndc__err" role="alert" data-testid="text-ndc-conflict">이 줄은 다른 품목으로 이미 촬영되었습니다. 품목을 바꾸려면 줄을 삭제하고 새 줄로 추가해 촬영하세요. 기존 사진은 다른 의류로 옮겨지지 않습니다.</p>}
      {disabled && <p className="ndc__err">고객 이름과 전화번호를 먼저 입력해 주세요.</p>}
      {message && <p className={message.kind === 'ok' ? 'ndc__ok' : 'ndc__err'} role="status" data-testid="status-ndc">{message.text}</p>}
    </section>
  );
}
