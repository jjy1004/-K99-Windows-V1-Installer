import { Component, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Camera, Footprints } from 'lucide-react';
import { equipmentRequest, getEquipmentState, type EquipmentConfig } from './equipment-client';
import type { GarmentRecord } from './garment-record';
import './native-draft-camera.css';
import { openIriunCamera,iriunDevices,iriunFailure } from './iriun-camera';
import {showCameraVideo} from './camera-video';
import { cameraStreamDeviceId } from './camera-device';
import {captureShortcut} from './capture-shortcut';
import { useCameraViewport } from './use-camera-viewport';
import { MobileDraftCapture } from './MobileDraftCapture';
import {LocalGarmentPhoto} from './components/LocalGarmentPhoto';
import {normalizeLabelSelection,type LabelSelection} from './manual-label';
import {ReceptionSidebar} from './ReceptionSidebar';
import {V2TagControls,type TagPolicy} from './V2TagControls';

export type DraftCaptureTarget = { rowId: number; itemId: string; itemName: string; unitIndex: number; rowQuantity: number };
export type DraftNativeUnit = { unitKey: string; rowId: number; itemId: string; unitIndex: number; garment: GarmentRecord };
export const draftUnitKey = (rowId: number, unitIndex: number) => `${rowId}:${unitIndex}`;

type CaptureResponse = { garment: GarmentRecord; archive?: { folder: string; fileName: string }; job?: unknown };

function mockShot(label: string, n: number) {
  const c = document.createElement('canvas'); c.width = 960; c.height = 720;
  const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
  g.fillStyle = '#e9e4d6'; g.fillRect(0, 0, 960, 720);
  g.fillStyle = '#21323d'; g.font = 'bold 34px sans-serif'; g.fillText(`${label} · ${n}번째`, 40, 80);
  g.fillStyle = 'rgba(176,52,40,.6)'; g.font = 'bold 110px sans-serif'; g.fillText('모의 촬영', 220, 400);
  return c.toDataURL('image/jpeg', 0.9);
}

/** Prereceipt native camera: one live preview, unit selector, every shot saved immediately via capture-draft. */
export function NativeDraftCamera({ orderId, targets, units, customerName, customerPhone, disabled, onCaptured,labelSelection,onSelectLabel,onFinalConfirm }: {
  orderId: string; targets: DraftCaptureTarget[]; units: DraftNativeUnit[];
  customerName: string; customerPhone: string; disabled?: boolean;
  onCaptured: (unit: DraftNativeUnit) => void;
  labelSelection:LabelSelection;
  onSelectLabel:(value:LabelSelection)=>void;
  onFinalConfirm:()=>void;
}) {
  const [cameraOpen,setCameraOpen]=useState(false);
  const [config, setConfig] = useState<EquipmentConfig | null>(null);
  const [native, setNative] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [selected, setSelected] = useState('');
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState('');
  const [previewOn, setPreviewOn] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [lastShot, setLastShot] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [connectionMode,setConnectionMode]=useState<'wifi'|'usb'>(()=>{
    try{return localStorage.getItem('k99.iriun-connection')==='usb'?'usb':'wifi';}catch{return 'wifi';}
  });
  const [receiverNote,setReceiverNote]=useState('');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const openAbort=useRef<AbortController|null>(null);
  const cameraEpoch=useRef(0);
  const deviceInventory=useRef('');
  const pedalZoomHeld=useRef(false);
  const busyRef = useRef(false);
  const [ocrText,setOcrText]=useState('');
  const [tagPolicy,setTagPolicy]=useState<TagPolicy>({mode:'printer',lastNumber:'1-0'});
  const [tagError,setTagError]=useState('');
  const currentOcrTarget=useRef('');currentOcrTarget.current=`${orderId}:${selected}`;
  const viewport = useCameraViewport(cameraOpen && previewOn, `${orderId}:${selected}:${deviceId}`);

  useEffect(() => {
    let live = true;
    getEquipmentState().then((s) => { if (!live) return; setConfig(s.config); setNative(s.native);
      void navigator.mediaDevices?.enumerateDevices().then(all=>{
        if(!live)return;
        setDevices(iriunDevices(all));
        deviceInventory.current=iriunDevices(all).map(d=>d.deviceId).sort().join('|');
        setDeviceId(d=>d||iriunDevices(all)[0]?.deviceId||'');
      }).catch(()=>{});
    })
      .catch((c) => live && setLoadError(c instanceof Error ? c.message : '장비 설정을 읽지 못했습니다.'));
    return () => { live = false; };
  }, []);

  const keys = useMemo(() => targets.map((t) => draftUnitKey(t.rowId, t.unitIndex)), [targets]);
  useEffect(() => { if (!keys.includes(selected)) setSelected(keys[0] ?? ''); }, [keys, selected]);
  const target = targets.find((t) => draftUnitKey(t.rowId, t.unitIndex) === selected);
  const unitFor = (key: string, itemId: string) => units.find((u) => u.unitKey === key && u.itemId === itemId);
  const shotCount = (u?: DraftNativeUnit) => u?.garment.photoHistory?.length ?? 0;
  const conflict = (key: string, itemId: string) => units.some((u) => u.unitKey === key && u.itemId !== itemId);
  const targetConflict = !!target && conflict(selected, target.itemId);
  const realMode = native && config?.mode === 'real';
  const onCapturedRef=useRef(onCaptured);onCapturedRef.current=onCaptured;
  const targetSignature=targets.map(t=>`${t.rowId}:${t.unitIndex}:${t.itemId}`).join('|');
  async function reserveNumbers(number?:string){
    if(disabled||!targets.length)return;
    try{
      const selectedIndex=targets.findIndex(t=>draftUnitKey(t.rowId,t.unitIndex)===selected);
      const list=number!==undefined?targets.slice(selectedIndex).filter((t,i)=>i===0||!shotCount(unitFor(draftUnitKey(t.rowId,t.unitIndex),t.itemId))):targets;
      const r=await equipmentRequest<{units:DraftNativeUnit[];tagPolicy:TagPolicy}>('reserve-roll-tags',{
        orderId,customerName,customerPhone,targets:list.map(t=>({unitKey:draftUnitKey(t.rowId,t.unitIndex),
        itemId:t.itemId,itemName:t.itemName,...(number?(draftUnitKey(t.rowId,t.unitIndex)===selected?{number}:{renumber:true}):{})}))});
      for(const u of r.units)onCapturedRef.current(u);
      setTagPolicy(r.tagPolicy);setTagError('');
    }catch(error){setTagError(error instanceof Error?error.message:'롤태그 번호 저장 실패');}
  }
  useEffect(()=>{void equipmentRequest<TagPolicy>('tag-policy').then(setTagPolicy).catch(()=>setTagError('태그 방식 설정을 읽지 못했습니다.'));},[]);
  useEffect(()=>{
    if(tagPolicy.mode==='roll')void reserveNumbers();
  },[tagPolicy.mode,orderId,targetSignature,customerName,customerPhone,disabled]);
  const previousLabelTarget=useRef('');
  const capturedUnit=target?unitFor(selected,target.itemId):undefined;
  useEffect(()=>{
    setOcrText('');
    const key=`${orderId}:${selected}`;
    if(previousLabelTarget.current!==key){
      previousLabelTarget.current=key;
      if(capturedUnit){onSelectLabel(normalizeLabelSelection(capturedUnit.garment));return;}
    }
    if(!target||!capturedUnit||disabled)return;
    if(capturedUnit.garment.manualMaterial===labelSelection.manualMaterial&&capturedUnit.garment.manualColor===labelSelection.manualColor)return;
    let live=true;
    void equipmentRequest<{garment:GarmentRecord}>('set-label-selection',{orderId,unitKey:selected,...labelSelection})
      .then(r=>{if(live)onCapturedRef.current({...capturedUnit,garment:r.garment});})
      .catch(()=>{if(live)setMessage({kind:'error',text:'품목의 소재·색상 저장을 확인하지 못했습니다. 접수 전에 다시 선택해 주세요.'});});
    return()=>{live=false;};
  },[orderId,selected,target?.itemId,capturedUnit?.garment.garmentId,labelSelection.manualMaterial,labelSelection.manualColor,disabled]);

  const stop = useCallback(() => {
    cameraEpoch.current+=1;
    openAbort.current?.abort();openAbort.current=null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setPreviewOn(false);
  }, []);
  useEffect(() => stop, [stop]);

  async function start(_requestedDevice?:string) {
    setMessage(null);
    setCameraError('');
    if (!realMode) { setPreviewOn(true); return; }
    stop();
    const abort=new AbortController();openAbort.current=abort;
    const epoch=cameraEpoch.current;
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      if(epoch!==cameraEpoch.current)return;
      setDevices(iriunDevices(all));
      deviceInventory.current=iriunDevices(all).map(d=>d.deviceId).sort().join('|');
      const stream = await openIriunCamera(navigator.mediaDevices,abort.signal);
      if(epoch!==cameraEpoch.current){stream.getTracks().forEach(t=>t.stop());return;}
      setDeviceId(cameraStreamDeviceId(stream));
      streamRef.current = stream;
      if (!videoRef.current) { stream.getTracks().forEach(t=>t.stop());streamRef.current=null; return; }
      await showCameraVideo(videoRef.current,stream);
      if(epoch!==cameraEpoch.current)return;
      setPreviewOn(true);
      stream.getVideoTracks()[0]?.addEventListener('ended',()=>{
        if(streamRef.current===stream){deviceInventory.current='';stop();setCameraError('Iriun 연결이 끊겼습니다. 휴대폰 앱과 선택한 Wi-Fi·USB 연결을 확인하고 다시 연결하세요.');}
      },{once:true});
    } catch (error) {
      if(epoch!==cameraEpoch.current)return;
      stop();setCameraError(iriunFailure(error));
    }
  }
  const startRef=useRef(start);startRef.current=start;
  useEffect(()=>{
    if(!realMode||!navigator.mediaDevices)return;
    let live=true,sequence=0;
    const reconnect=async()=>{
      const ticket=++sequence;
      try{
        const all=await navigator.mediaDevices.enumerateDevices();
        if(!live||ticket!==sequence)return;
        setDevices(iriunDevices(all));
        const inventory=iriunDevices(all).map(d=>d.deviceId).sort().join('|');
        const liveTrack=streamRef.current?.getVideoTracks()[0];
        if(inventory===deviceInventory.current&&(!cameraOpen||liveTrack?.readyState==='live'))return;
        deviceInventory.current=inventory;
        const preferred=iriunDevices(all)[0];
        if(!preferred){
          if(cameraOpen){stop();setCameraError('Iriun 카메라가 없습니다. 휴대폰 앱을 켜고 PC 수신기 연결을 확인하세요.');}
          return;
        }
        setDeviceId(preferred.deviceId);
        const track=streamRef.current?.getVideoTracks()[0];
        if(track?.readyState==='live'&&track.getSettings().deviceId===preferred.deviceId)return;
        if(cameraOpen)void startRef.current(preferred.deviceId);
      }catch{if(live)setCameraError('카메라 장치 목록을 읽지 못했습니다. 권한과 USB 연결을 확인해 주세요.');}
    };
    // No 500ms debounce: start enumeration in the very same devicechange callback.
    navigator.mediaDevices.addEventListener?.('devicechange',reconnect);
    return()=>{live=false;sequence++;navigator.mediaDevices.removeEventListener?.('devicechange',reconnect);};
  },[realMode,cameraOpen,stop]);
  useEffect(()=>{
    if(!cameraOpen)return;
    let live=true;
    setReceiverNote('');
    void window.k99Desktop?.iriunSession?.({active:true,mode:connectionMode})
      .then(state=>{
        if(!live)return;
        setReceiverNote(state.warning||(!state.installed?'PC에 Iriun Webcam을 먼저 설치해 주세요.':''));
      }).catch(()=>{if(live)setReceiverNote('PC 수신기를 확인해 주세요. 휴대폰 절전·깨우기는 연결 환경에 따라 다릅니다.');});
    return()=>{live=false;void window.k99Desktop?.iriunSession?.({active:false,mode:connectionMode}).catch(()=>{});};
  },[cameraOpen,connectionMode]);
  useEffect(()=>{
    if(!cameraOpen){stop();return;}
    void start();
    const onKey=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){event.preventDefault();setCameraOpen(false);}
    };
    window.addEventListener('keydown',onKey);
    return()=>{window.removeEventListener('keydown',onKey);stop();};
    // Starting/stopping is tied to the in-app dialog, never to a URL/protocol.
  },[cameraOpen,realMode,stop]);
  useEffect(()=>{setLastShot('');},[selected]);
  useEffect(()=>{
    const open=()=>setCameraOpen(true);
    window.addEventListener('k99:open-intake-camera',open);
    return()=>window.removeEventListener('k99:open-intake-camera',open);
  },[]);

  async function shoot() {
    if (!target || busyRef.current || disabled || targetConflict) return;
    busyRef.current = true; setBusy(true);
    try {
      const key = draftUnitKey(target.rowId, target.unitIndex);
      const n = shotCount(unitFor(key, target.itemId)) + 1;
      let image: string;
      if (realMode) {
        const v = videoRef.current;
        if (!previewOn || !v || !v.videoWidth) throw new Error('카메라 영상이 준비되지 않았습니다.');
        const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
        const g = c.getContext('2d'); if (!g) throw new Error('캔버스를 만들 수 없습니다.');
        viewport.capture(g, v);
        image = c.toDataURL('image/jpeg', 0.95);
      } else image = mockShot(target.itemName, n);
      setLastShot(image);
      const r = await equipmentRequest<CaptureResponse>('capture-draft', {
        orderId, unitKey: key, itemName: target.itemName, itemId: target.itemId, customerName, customerPhone,
        imageDataUrl: image, photo_type: 'intake', requestId: crypto.randomUUID(), expectedMode: realMode ? 'real' : 'mock',...labelSelection,
      });
      onCaptured({ unitKey: key, rowId: target.rowId, itemId: target.itemId, unitIndex: target.unitIndex, garment: r.garment });
      const count = r.garment.photoHistory?.length ?? n;
      const status=(r.job as {status?:string}|undefined)?.status;
      setMessage({ kind: 'ok', text: `${target.itemName} ${target.unitIndex}번 · ${count}컷 저장${r.garment.tagMode==='roll'?` · 롤태그 ${r.garment.tagNumber} (인쇄 없음)`:count===1 ? status==='submitted'||status==='printed'?' · 첫 컷 태그 1회 전송 완료':` · 태그 상태: ${status||'확인 필요'}` : ' · 추가 태그 없음'}${r.archive ? ` · ${r.archive.fileName}` : ''}` });
    } catch (c) { setMessage({ kind: 'error', text: c instanceof Error ? c.message : '사진을 저장하지 못했습니다.' }); }
    finally { busyRef.current = false; setBusy(false); }
  }
  const shootRef = useRef(shoot);
  shootRef.current = shoot;

  const footReady = cameraOpen && previewOn && !!target && !disabled && !targetConflict;
  const nextGarment=()=>{
    if(busyRef.current||disabled)return;
    viewport.hold.cancel();viewport.reset();
    const index=keys.indexOf(selected);
    if(index<keys.length-1)setSelected(keys[index+1]);
    else setMessage({kind:'ok',text:'마지막 세탁물입니다. 접수 최종 확인을 진행하세요.'});
  };
  const finalConfirm=()=>{
    if(busyRef.current||disabled)return;
    if(tagPolicy.mode==='roll'&&(tagError||targets.some(t=>{
      const u=unitFor(draftUnitKey(t.rowId,t.unitIndex),t.itemId);
      return !u?.garment.tagNumber&&!(u?.garment.tagMode==='printer'&&shotCount(u)>0);
    }))){
      setTagError('각 의류의 롤태그 번호 저장을 확인한 뒤 최종 확인하세요.');return;
    }
    onFinalConfirm();
    setCameraOpen(false);
  };
  const keysRef=useRef({nextGarment,footReady,viewport});
  keysRef.current={nextGarment,footReady,viewport};
  useEffect(()=>{
    if(!cameraOpen)return;
    const handler=(event:KeyboardEvent)=>{
      const key=captureShortcut(event);if(!key)return;
      event.preventDefault();event.stopImmediatePropagation();
      if(event.repeat)return;
      if(key==='F7'&&keysRef.current.footReady)void shootRef.current();
      if(key==='F8'&&keysRef.current.footReady){pedalZoomHeld.current=true;keysRef.current.viewport.hold.start('F8');}
      if(key==='F9')keysRef.current.nextGarment();
    };
    const release=(event:KeyboardEvent)=>{
      // Release a held pedal even if focus moved into a field after keydown.
      if(!['F8','b','B'].includes(event.key)&&event.code!=='KeyB')return;
      if(!pedalZoomHeld.current)return;
      pedalZoomHeld.current=false;
      event.preventDefault();event.stopImmediatePropagation();keysRef.current.viewport.hold.end('F8');
    };
    window.addEventListener('keydown',handler,true);
    window.addEventListener('keyup',release,true);
    return()=>{
      window.removeEventListener('keydown',handler,true);window.removeEventListener('keyup',release,true);
      pedalZoomHeld.current=false;
      keysRef.current.viewport.hold.cancel();
    };
  },[cameraOpen]);

  const mobileAvailable = realMode && !!target && !disabled && !targetConflict;
  const mobileReason = !native ? '휴대폰 촬영은 Windows 매장 프로그램에서만 사용할 수 있습니다.' : !realMode ? '휴대폰 촬영은 실카메라 모드에서만 사용할 수 있습니다.'
    : disabled ? '고객 이름과 전화번호를 먼저 입력해 주세요.' : targetConflict ? '품목이 변경된 줄은 휴대폰 촬영을 할 수 없습니다.' : !target ? '촬영할 의류를 선택해 주세요.' : '';
  const mobileTarget = target ? { orderId, unitKey: selected, itemId: target.itemId, itemName: target.itemName, customerName, customerPhone } : null;

  const mobilePanel=<MobileDraftCapture key={mobileTarget?`${orderId}:${selected}:${target?.itemId}:${customerName}:${customerPhone}`:'empty'}
    inline available={mobileAvailable} unavailableReason={mobileReason} target={mobileTarget}
    open={mobileOpen} onOpenChange={setMobileOpen}
    onCaptured={garment=>{if(target)onCaptured({unitKey:selected,rowId:target.rowId,itemId:target.itemId,unitIndex:target.unitIndex,garment});}}/>;
  return (
    <>
    {createPortal(<ReceptionSidebar labelSelection={labelSelection} onLabelSelection={onSelectLabel}
      mobilePanel={mobilePanel} onOpenCamera={()=>setCameraOpen(true)} onFinalConfirm={finalConfirm}
      tagPanel={<V2TagControls policy={tagPolicy} currentNumber={capturedUnit?.garment.tagNumber||''} error={tagError}
        onPrinterKind={printerKind=>{
          void equipmentRequest<TagPolicy>('configure-tag-mode',{mode:'printer',printerKind}).then(p=>{
            setTagPolicy(p);setTagError('');return getEquipmentState();
          }).then(s=>setConfig(s.config)).catch(e=>setTagError(String(e.message||e)));
        }}
        onNumber={number=>void reserveNumbers(number)} onMode={mode=>{
          void equipmentRequest<TagPolicy>('configure-tag-mode',{mode}).then(p=>{setTagPolicy(p);setTagError('');})
            .catch(error=>setTagError(String(error.message)));
        }}/>}/>,document.body)}
    {cameraOpen&&createPortal(<div className="ndc-modal-backdrop">
    <div className="ndc-modal" role="dialog" aria-modal="true" aria-label="접수 사진 촬영" data-testid="dialog-intake-camera">
    <button type="button" className="ndc-modal-close" onClick={()=>setCameraOpen(false)}>촬영 창 닫기</button>
    <section className="ndc" aria-label="접수 사진 촬영" data-testid="section-native-draft-camera">
      <header className="ndc__head">
        <div><h3>Iriun 휴대폰 사진 촬영</h3><p>휴대폰 원본 화질 · 첫 컷 태그 1회 · 추가 컷은 사진만 저장</p></div>
        <span className={`ndc__mode ${realMode ? 'is-real' : ''}`} data-testid="status-ndc-mode">{config ? realMode ? '실카메라' : '모의 촬영' : '설정 확인 중'}</span>
      </header>
      {loadError && <p className="ndc__err" role="alert">{loadError}</p>}
      <div className="ndc__connection" aria-label="휴대폰 연결 방식">
        {(['wifi','usb'] as const).map(mode=><button type="button" key={mode} aria-pressed={connectionMode===mode}
          onClick={()=>{setConnectionMode(mode);try{localStorage.setItem('k99.iriun-connection',mode);}catch{}}}>
          {mode==='wifi'?'📶 Wi-Fi 무선 연결':'🔌 USB 유선 연결'}
        </button>)}
      </div>
      <div className="ndc__units" role="listbox" aria-label="촬영할 의류">
        {targets.map((t) => {
          const key = draftUnitKey(t.rowId, t.unitIndex);
          const n = shotCount(unitFor(key, t.itemId));
          return <button key={key} type="button" role="option" aria-selected={key === selected} onClick={() => setSelected(key)}
            data-testid={`button-ndc-unit-${key}`}><span>{t.itemName}{t.rowQuantity > 1 ? ` ${t.unitIndex}번` : ''} {unitFor(key,t.itemId)?.garment.tagNumber&&` · 태그 ${unitFor(key,t.itemId)?.garment.tagNumber}`}</span><em>{conflict(key, t.itemId) ? '품목 변경됨' : `${n}컷`}</em></button>;
        })}
      </div>
      <div className="ndc__preview-slot"><div ref={viewport.stageRef} className={`ndc__stage ${viewport.view.zoom>1?'is-zoomed':''}`}
        {...viewport.stageEvents} data-testid="camera-viewport">
        <video ref={videoRef} muted playsInline hidden={!realMode} style={viewport.videoStyle}
          onLoadedMetadata={event=>viewport.onMetadata(event.currentTarget)} />
        <span className="ndc__zoom-badge" data-testid="camera-zoom" aria-label="현재 카메라 배율">{viewport.view.zoom.toFixed(1)}x</span>
        {cameraError ? <div className="ndc__camera-error" role="alert" data-testid="error-ndc-camera">{cameraError}</div> :
          !previewOn && <span>{realMode ? '미리보기를 켜면 카메라 영상이 표시됩니다.' : '모의 모드: 미리보기를 켜고 촬영하면 모의 이미지가 저장됩니다.'}</span>}
        {previewOn && !realMode && <span>모의 촬영 대기 중</span>}
        {lastShot && <img src={lastShot} alt="마지막 촬영" className="ndc__last" data-testid="img-ndc-last" />}
        {target && <div className="ndc__count" data-testid="text-ndc-count"><strong>{target.itemName} {target.unitIndex}번</strong><span aria-hidden="true"> · </span><em>{shotCount(unitFor(selected, target.itemId))}컷</em></div>}
      </div></div>
      <div className="ndc__bar">
        <span>Iriun Webcam · {devices.length?'휴대폰 수신기 감지':'휴대폰 앱을 켜 주세요'}</span>
        {!previewOn&&<button type="button" className="ndc__preview-guide" onClick={() => void start()} data-testid="button-ndc-preview">
          <Camera aria-hidden="true" />다시 연결</button>}
        {target && shotCount(unitFor(selected, target.itemId)) > 0 && <span className="ndc__shot-guide" role="status">
          추가 촬영 가능 / {shotCount(unitFor(selected, target.itemId))}컷 촬영됨
        </span>}
        {footReady && <span className="ndc__foot" data-testid="status-ndc-foot"><Footprints aria-hidden="true" />A/F7 촬영 · B/F8 확대 · C/F9 다음</span>}
      </div>
      <div className="ndc__actions" aria-label="촬영 및 접수 조작">
        <button type="button" className="ndc__shoot" disabled={!previewOn || !target || busy || disabled || targetConflict} onClick={() => void shoot()} data-testid="button-ndc-shoot">
          {busy ? '저장 중' : '📷 사진 촬영 (A / F7)'}</button>
        <button type="button" disabled={!footReady} data-testid="button-camera-zoom"
          onPointerDown={event=>{
            if(event.button!==0)return;
            event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);viewport.hold.start(`pointer:${event.pointerId}`);
          }}
          onPointerUp={event=>viewport.hold.end(`pointer:${event.pointerId}`)}
          onPointerCancel={()=>viewport.hold.cancel()} onLostPointerCapture={()=>viewport.hold.cancel()}
          onKeyDown={event=>{if([' ','Enter'].includes(event.key)){event.preventDefault();viewport.hold.start('button');}}}
          onKeyUp={event=>{if([' ','Enter'].includes(event.key)){event.preventDefault();viewport.hold.end('button');}}}
          onContextMenu={event=>event.preventDefault()}>
          🔍 확대 (B / F8)<small>누르고 있기 / 탭 초기화</small></button>
        <button type="button" onClick={()=>{viewport.hold.cancel();viewport.reset();}} data-testid="button-camera-reset">1.0x 복귀</button>
        <button type="button" onClick={nextGarment} data-testid="button-camera-next">➡️ 다음 세탁물 (C / F9)</button>
      </div>
      <div className="ndc__bar ndc__final">
        <span>휠: 확대·축소 · 드래그: 위치 이동</span>
        <button type="button" onClick={finalConfirm} data-testid="button-camera-final">✅ 접수 최종 확인</button>
      </div>
      <div className="ndc__connection-guide" role="note">
        {connectionMode==='wifi'
          ?'1. 최초 1회 PC에 Iriun Webcam 프로그램 설치 → 2. 아침 출근 후 스마트폰에서 Iriun Webcam 앱 한 번 켜두기 → 3. 촬영 창을 열면 자동 연결 / 닫으면 절전 대기'
          :"1. 스마트폰과 PC를 USB 케이블로 연결 → 2. 스마트폰 설정 > 연결 > 모바일 핫스팟 및 테더링 > 'USB 테더링'(또는 USB 디버깅) 켜기 → 3. 아침에 Iriun Webcam 앱 한 번 켜두면 촬영 시 자동 활성화"}
        <small>창을 닫으면 PC 카메라 연결을 해제합니다. 실제 휴대폰 절전·USB 연결 지원은 기종과 Iriun 설정에 따라 다릅니다. USB 디버깅은 신뢰하는 매장 PC에서만 허용하세요.</small>
      </div>
      {receiverNote&&<p className="ndc__err" role="status">{receiverNote}</p>}
      <details className="ndc__more"><summary>촬영 사진 · 태그 정보 · 선택형 AI 보기</summary><div className="ndc__more-body">
      {realMode && !!target && shotCount(unitFor(selected, target.itemId)) > 0 && <ol className="ndc__photos" aria-label="이 의류의 PC·휴대폰 통합 촬영 순서" data-testid="list-ndc-hybrid-photos">
        {unitFor(selected, target.itemId)?.garment.photoHistory?.map((photo, index) => <li key={photo.requestId}>
          <LocalGarmentPhoto photoId={photo.sourcePhotoId} pathHint={photo.path}
            orderId={unitFor(selected,target.itemId)?.garment.orderId} garmentId={photo.garmentId} alt={`${target.itemName} ${target.unitIndex}번 ${index + 1}번째 사진`} />
          <span>{index + 1}컷</span>
        </li>)}
      </ol>}
      {target&&<p role="status" data-testid="status-ndc-label-material">
        [태그 소재] {capturedUnit?.garment.manualMaterial||labelSelection.manualMaterial} /
        [색상] {capturedUnit?.garment.manualColor||labelSelection.manualColor}
      </p>}
      <div>
        <button type="button" onClick={()=>{
          const photoId=capturedUnit?.garment.photoHistory?.at(-1)?.sourcePhotoId;
          if(!photoId)return;
          const key=currentOcrTarget.current;
          void equipmentRequest<{raw_material?:string}|null>('optional-ai',{photoId})
            .then(r=>{if(key===currentOcrTarget.current&&r?.raw_material)setOcrText(r.raw_material);}).catch(()=>{});
        }}>AI 라벨 분석</button>
        {ocrText&&<small> 선택형 OCR 참고: {ocrText} · 태그에는 상단 선택값을 인쇄합니다.</small>}
      </div>
      </div></details>
      {!targets.length&&<p role="status">접수 품목을 먼저 추가해 주세요.</p>}
      {targetConflict && <p className="ndc__err" role="alert" data-testid="text-ndc-conflict">이 줄은 다른 품목으로 이미 촬영되었습니다. 품목을 바꾸려면 줄을 삭제하고 새 줄로 추가해 촬영하세요. 기존 사진은 다른 의류로 옮겨지지 않습니다.</p>}
      {disabled && <p className="ndc__err">고객 이름과 전화번호를 먼저 입력해 주세요.</p>}
      {message && <p className={message.kind === 'ok' ? 'ndc__ok' : 'ndc__err'} role="status" data-testid="status-ndc">{message.text}</p>}
    </section>
    </div></div>,document.body)}
    </>
  );
}

class CaptureBoundary extends Component<{children:ReactNode},{failed:boolean}> {
  state={failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  componentDidCatch(error:Error){console.error('K99 in-app camera render:',error.message);}
  render(){return this.state.failed?<div role="alert">촬영 화면을 열지 못했습니다. 접수 데이터는 유지됩니다.
    <button type="button" onClick={()=>this.setState({failed:false})}>촬영 화면 다시 연결</button></div>:this.props.children;}
}
export function SafeNativeDraftCamera(props:Parameters<typeof NativeDraftCamera>[0]){
  return <CaptureBoundary><NativeDraftCamera {...props}/></CaptureBoundary>;
}
