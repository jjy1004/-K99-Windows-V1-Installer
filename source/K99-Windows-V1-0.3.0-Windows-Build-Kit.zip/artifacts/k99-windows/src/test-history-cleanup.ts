/** Only order-contained histories are deletable. Device settings and counters are never enumerated. */
export const TEST_ORDERS_KEY = 'k99-confirmed-orders-v1';
export type CleanupBackup = { format: 'k99-test-cleanup-backup'; version: 1; createdAt: string; rawOrders: string | null };
export function createCleanupBackup(storage: Storage): CleanupBackup {
  const rawOrders = storage.getItem(TEST_ORDERS_KEY);
  const orders = JSON.parse(rawOrders ?? '[]');
  if (!Array.isArray(orders) || orders.some(o => !o || typeof o.id !== 'string'))
    throw new Error('주문 구조를 확인할 수 없어 정리를 중단했습니다.');
  return { format: 'k99-test-cleanup-backup', version: 1, createdAt: new Date().toISOString(), rawOrders };
}
export function verifyCleanupBackup(text: string, expected: CleanupBackup): void {
  const parsed = JSON.parse(text);
  if (parsed.format !== expected.format || parsed.version !== 1 ||
      parsed.createdAt !== expected.createdAt || parsed.rawOrders !== expected.rawOrders)
    throw new Error('다운로드한 원본 백업과 일치하지 않습니다. 삭제하지 않았습니다.');
}
export function deleteConfirmedTestOrders(storage: Storage, backup: CleanupBackup, ids: string[]): number {
  if (storage.getItem(TEST_ORDERS_KEY) !== backup.rawOrders)
    throw new Error('다른 화면에서 주문이 변경되었습니다. 최신 백업을 다시 만들어 주세요.');
  const orders = JSON.parse(backup.rawOrders ?? '[]');
  const selected = new Set(ids);
  if (!selected.size || ids.length !== selected.size || ids.some(id => !orders.some((o: { id: string }) => o.id === id)))
    throw new Error('테스트로 확인한 주문을 선택하세요.');
  throw new Error('영구 삭제 기능은 중단되었습니다. 세탁·검수의 주문별 관리자 논리 삭제를 이용하세요.');
}
export function restoreCleanupBackup(storage: Storage, text: string): number {
  const backup = JSON.parse(text);
  if (backup.format !== 'k99-test-cleanup-backup' || backup.version !== 1 ||
      !(backup.rawOrders === null || typeof backup.rawOrders === 'string')) throw new Error('지원하는 정리 백업이 아닙니다.');
  const old = JSON.parse(backup.rawOrders ?? '[]');
  const current = JSON.parse(storage.getItem(TEST_ORDERS_KEY) ?? '[]');
  if (!Array.isArray(old) || !Array.isArray(current) || old.some(o => !o || typeof o.id !== 'string'))
    throw new Error('백업 주문 구조가 올바르지 않습니다.');
  if (new Set(old.map(o => o.id)).size !== old.length) throw new Error('백업에 중복 주문 번호가 있습니다.');
  for (const order of old) {
    const match = current.find(o => o.id === order.id);
    if (match && JSON.stringify(match) !== JSON.stringify(order)) throw new Error('현재 주문과 백업이 충돌합니다. 덮어쓰지 않았습니다.');
  }
  const missing = old.filter(o => !current.some(c => c.id === o.id));
  const owners = new Map<string, string>();
  for (const order of [...current, ...missing]) {
    for (const garment of order.garments ?? []) {
      for (const code of new Set([garment.garmentId, garment.barcodeValue].filter(Boolean))) {
        if (owners.has(code)) throw new Error('기존·삭제 주문과 태그번호가 중복됩니다. 번호를 재사용하거나 백업을 덮어쓰지 않았습니다.');
        owners.set(code, order.id);
      }
    }
  }
  storage.setItem(TEST_ORDERS_KEY, JSON.stringify([...current, ...missing]));
  return missing.length;
}
