import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { requiredIntakeIdentity } from './customer-input';
import type { CustomerIdentity } from './CustomerIdentityEditor';

export function canEditCustomer(order: ConfirmedOrder): boolean {
  return !order.operations?.cancelledAt && !order.operations?.completedAt &&
    !(order.garments ?? []).some(g => g.beforePhoto || g.completionPhoto || g.photoPath ||
      g.photoHistory?.length || g.captureRequestId || g.tagStatus !== 'not-generated');
}

export function updateCustomerBeforePhoto(original: ConfirmedOrder, value: CustomerIdentity): ConfirmedOrder {
  if (!requiredIntakeIdentity(value.customerName, value.customerPhone))
    throw new Error('고객명과 유효한 휴대전화번호를 확인하세요.');
  const latest = readConfirmedOrders().find(order => order.id === original.id);
  if (!latest || !canEditCustomer(latest) || !canEditCustomer(original))
    throw new Error('촬영·태그 작업이 시작된 주문은 여기서 수정할 수 없습니다. 기존 사진과 장비 설정은 보존했습니다.');
  if ((original.choices.pickupRequested || original.choices.deliveryRequested) && !value.customerAddress.trim())
    throw new Error('수거·배달 주소를 입력하세요.');
  // Folder names and IDs are immutable even if an empty folder already exists on Windows.
  const updated: ConfirmedOrder = { ...original, ...value,
    history: [...(original.history ?? []), { at: new Date().toISOString(), kind: 'operations-update',
      details: { action: 'customer-identity-before-photo', previous: {
        customerName: original.customerName, customerPhone: original.customerPhone, customerAddress: original.customerAddress },
        revised: value } }] };
  updateSavedOrder(updated, original);
  window.dispatchEvent(new StorageEvent('storage', { key: 'k99-confirmed-orders-v1' }));
  return updated;
}
