import { useCallback, useEffect, useLayoutEffect, useRef, useState, type JSX, type KeyboardEvent, type ReactNode } from 'react';
import {createPortal} from 'react-dom';
import bwipjs from 'bwip-js/browser';
import {
  AlertTriangle, BadgePercent, BookOpen, Camera, CheckCircle2, ChevronLeft, CircleHelp, Info, Loader2, MessageCircle, Printer, Settings, Smartphone, Store, UserCog, X, Save, QrCode, RefreshCw,
} from 'lucide-react';
import { openGuide } from './guide-data';
import { PictureGuideHost } from './PictureGuide';
import './settings-hub.css';
import {
  messenger, noticeApi, OPEN_CUSTOMER_NOTICE,
  type CustomerNotice as BaseNotice, type MessengerResult, type NoticeContext, type NoticeTemplate as BaseTemplate, type StoreProfile,type NoticeOpenOptions,
} from './notice-api';

// 서버 확장 필드(광고 단계·템플릿 revision·광고 동의)를 이 파일 안에서만 보강
type Stage = 'before' | 'after' | 'advert';
type NoticeTemplate = Omit<BaseTemplate, 'stage'> & { stage: Stage; revision: number };
type CustomerNotice = BaseNotice & { advertConsentConfirmed?: boolean };
import './notice-center.css';
import { AccountlessNoticeActions } from './LocalNoticeDialogs';
import { SpecialNoteHost } from './CustomerSpecialNote';
import { appendMobileNotice } from './notice-text';
import { OwnerSecurityPanel } from './OwnerSecurityPanel';
import { HardwareSettings } from './HardwareSettings';
import {ProgramIntegrationSettings} from './ProgramIntegrationSettings';
import {StorageLayoutSettings} from './StorageLayoutSettings';
import {readConfirmedOrders,type ConfirmedOrder} from './order-record';
import {CustomerNoticeOrderSummary,CustomerNoticeTemplateChoices} from './CustomerNoticeDetails';
import './customer-notice-details.css';

type Tone = 'info' | 'ok' | 'warn' | 'err';
const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');

function Msg({ tone, children }: { tone: Tone; children: ReactNode }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle;
  return <div className={`nc-msg ${tone}`} role={tone === 'err' ? 'alert' : 'status'}><Icon size={22} aria-hidden /> <div>{children}</div></div>;
}

function QrCanvas({ url }: { url: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    if (!ref.current || !url) return;
    try { bwipjs.toCanvas(ref.current, { bcid: 'qrcode', text: url, scale: 5, padding: 4, backgroundcolor: 'FFFFFF' }); setErr(false); }
    catch { setErr(true); }
  }, [url]);
  return err ? <Msg tone="err">QR을 만들지 못했습니다. 연결 끝내기 후 다시 만들어 주세요.</Msg>
    : <canvas ref={ref} role="img" aria-label="휴대폰으로 글쓰기 연결 QR 코드" style={{ display: 'block', maxWidth: '100%' }} />;
}

function Modal({ title, sub, onClose, narrow, children, className='' }: { title: string; sub?: string; onClose: () => void; narrow?: boolean; children: ReactNode; className?:string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous=document.activeElement as HTMLElement|null;
    ref.current?.focus();
    return()=>{if(previous?.isConnected)previous.focus();};
  }, []);
  const onKey = (e: KeyboardEvent) => {
    // 접수 화면 전역 단축키와 격리
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) onClose();
    if(e.key==='Tab'){
      const focusable=Array.from(ref.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]')||[])
        .filter(el=>el.getClientRects().length>0);
      const first=focusable[0],last=focusable.at(-1);
      if(!first){e.preventDefault();ref.current?.focus();}
      else if(e.shiftKey&&(document.activeElement===first||document.activeElement===ref.current)){e.preventDefault();last?.focus();}
      else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===ref.current)){e.preventDefault();first.focus();}
    }
  };
  return createPortal(
    <div className="nc-backdrop" data-notice-modal="true" onKeyDown={onKey} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className={`nc-modal${narrow ? ' narrow' : ''} ${className}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="nc-head">
          <div><h2>{title}</h2>{sub && <p>{sub}</p>}</div>
          <button type="button" className="nc-close" onClick={onClose} aria-label={`${title} 닫기`}><X size={22} aria-hidden />닫기</button>
        </div>
        {children}
      </div>
    </div>,document.body
  );
}

function resultLine(r: MessengerResult): { tone: Tone; text: string } {
  if (!r.success) return { tone: 'err', text: r.error || r.detail || '확인 필요: 프로그램을 열지 못했습니다.' };
  switch (r.status) {
    case 'prepared': return { tone: 'warn', text: '자동입력됨 — 외부 앱 화면에서 직원이 내용을 확인한 뒤 직접 보내기를 눌러 주세요.' };
    case 'send_requested': return { tone: 'warn', text: '전송요청됨 — 고객에게 도착했는지는 아직 확인되지 않았습니다.' };
    case 'opened': return { tone: 'info', text: '열기 요청을 보냈습니다. 화면에서 직접 확인해 주세요.' };
    default: return { tone: 'warn', text: `확인 필요${r.detail ? ` — ${r.detail}` : ''}` };
  }
}

/* ---------------- 휴대폰 문자·카톡 연결 (설정 > 휴대폰 하위) ---------------- */
function ConnectHelperBody() {
  const [busy, setBusy] = useState(false);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const run = async () => {
    if (busy) return; setBusy(true); setLine(null);
    try {
      const r = await messenger({action:'phone'});
      setLine(r.success ? {tone:'info',text:'휴대폰 연결 창을 여는 요청을 보냈습니다. 실제 연결 상태는 열린 창에서 확인해 주세요.'}:resultLine(r));
    } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { setBusy(false); }
  };
  return (<>
    <ol className="sh-steps">
      <li>휴대폰 화면 잠금을 푼 상태로 연결해 주세요.</li>
      <li>한 번 연결되면 창을 닫아도(X) 백그라운드에서 계속 유지됩니다.</li>
      <li>PC에서 문자와 갤러리 사진을 바로 쓰실 수 있습니다.</li>
    </ol>
    <div className="sh-actions">
      <button type="button" className="sh-btn gold" disabled={busy} onClick={()=>void run()} data-testid="button-phone-connect"><Smartphone aria-hidden />휴대폰 연결 창 열기</button>
      <button type="button" className="sh-btn ghost" onClick={()=>openGuide('setup','storephone')}><BookOpen aria-hidden />매장폰 그림 설명</button>
    </div>
    {line && <Msg tone={line.tone}>{line.text}</Msg>}
  </>);
}

function CameraPhoneBody() {
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const call = async (action: 'iriun' | 'driver') => {
    const fn = window.k99Desktop?.cameraConnection;
    if (!fn) { setLine({ tone: 'warn', text: 'Iriun 실행은 PC에 설치된 K99 프로그램에서만 됩니다. 아래 그림 설명서는 볼 수 있습니다.' }); return; }
    try { const r = await fn(action); setLine({ tone: 'info', text: r.message || '요청을 보냈습니다. 화면에서 직접 확인해 주세요.' }); }
    catch (e) { setLine({ tone: 'err', text: errText(e) }); }
  };
  return (<>
    <p className="sh-big">아침에 휴대폰의 Iriun Webcam 앱을 한 번 켜 두면, 접수 화면의 [촬영 창 열기]에서 연결을 시도합니다.</p>
    <div className="sh-actions">
      <button type="button" className="sh-btn gold" onClick={()=>void call('iriun')} data-testid="button-iriun-open"><Camera aria-hidden />PC Iriun 프로그램 열기</button>
      <button type="button" className="sh-btn ghost" onClick={()=>void call('driver')}><RefreshCw aria-hidden />Iriun 설치·드라이버 확인</button>
    </div>
    <div className="sh-actions">
      <button type="button" className="sh-btn ghost" onClick={()=>openGuide('setup','usb')}><BookOpen aria-hidden />USB 연결 그림</button>
      <button type="button" className="sh-btn ghost" onClick={()=>openGuide('setup','heat')}><BookOpen aria-hidden />발열 줄이기 그림</button>
    </div>
    {line && <Msg tone={line.tone}>{line.text}</Msg>}
  </>);
}

/* ---------------- 매장 설정 (5대 메뉴) ---------------- */
const DISCOUNT_FIELDS: [keyof StoreProfile['discounts'], string][] = [
  ['firstThreshold', '1단계 할인 기준금액(원)'], ['firstRate', '1단계 할인율(%)'],
  ['secondThreshold', '2단계 할인 기준금액(원)'], ['secondRate', '2단계 할인율(%)'],
  ['reviewThreshold', '리뷰할인 기준금액(원)'], ['reviewDiscount', '리뷰 할인액(원)'],
];
type View = 'home' | 'store' | 'price' | 'owner' | 'hardware' | 'phone' | 'phone-camera' | 'phone-message';
const MENU: [View, string, string, typeof Store][] = [
  ['store', '매장 정보', '이름 · 전화 · 소개 · 계좌', Store],
  ['price', '가격 정책', '할인 기준 · 할인율', BadgePercent],
  ['owner', '매장 점주·관리자', '직원 · 관리자 보안', UserCog],
  ['hardware', '하드웨어 설정', '라벨 · 영수증 · 카메라 · 모니터', Printer],
  ['phone', '휴대폰 연결 설정', '촬영용 · 문자카톡', Smartphone],
];
const TITLES: Record<View, string> = { home: '매장 맞춤 설정', store: '매장정보', price: '가격정책', owner: '점주·관리자', hardware: '하드웨어', phone: '휴대폰연결', 'phone-camera': '촬영용 휴대폰', 'phone-message': '문자·카톡 휴대폰' };
function StoreSettings({ onClose, initialView = 'home' }: { onClose: () => void; initialView?: View }) {
  const [view, setView] = useState<View>(initialView);
  const [rev, setRev] = useState<number | null>(null);
  const [p, setP] = useState<StoreProfile | null>(null);
  const [staffText, setStaffText] = useState('');
  const [nums, setNums] = useState<Record<string, string>>({});
  const [loadErr, setLoadErr] = useState('');
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const apply = (r: { profile: StoreProfile; revision: number }) => {
    setP(r.profile); setRev(r.revision); setStaffText(r.profile.staff.join('\n'));
    setNums(Object.fromEntries(DISCOUNT_FIELDS.map(([k]) => [k, String(r.profile.discounts[k] ?? 0)])));
  };
  const load = useCallback(() => {
    setLoadErr('');
    noticeApi<{ profile: StoreProfile; revision: number }>('GET', '/profile').then(apply).catch((e) => setLoadErr(errText(e)));
  }, []);
  useEffect(load, [load]);
  useEffect(() => setLine(null), [view]);
  const save = async () => {
    if (!p || rev === null || saving) return;
    const discounts = {} as StoreProfile['discounts'];
    for (const [k, label] of DISCOUNT_FIELDS) {
      const n = Number(nums[k]);
      if (!Number.isFinite(n) || n < 0) { setLine({ tone: 'err', text: `${label}에 0 이상의 숫자를 넣어 주세요.` }); return; }
      discounts[k] = n;
    }
    const staff = staffText.split('\n').map((s) => s.trim()).filter(Boolean);
    setSaving(true); setLine(null);
    try {
      const r = await noticeApi<{ profile: StoreProfile; revision: number }>('PUT', '/profile', { profile: { ...p, staff, discounts }, revision: rev });
      apply(r);setLine({ tone: 'ok', text: '저장되었습니다.' });
    } catch (e) { setLine({ tone: 'err', text: `저장 실패: ${errText(e)} 다른 곳에서 바뀌었다면 “다시 불러오기” 후 수정해 주세요.` }); }
    finally { setSaving(false); }
  };
  const parent: View = view === 'phone-camera' || view === 'phone-message' ? 'phone' : 'home';
  const saveRow = (
    <div className="sh-actions">
      <button type="button" className="sh-btn gold" disabled={saving || !p} onClick={save} aria-label="매장 설정 저장하기" data-testid="button-save-profile">{saving ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}저장하기</button>
      <button type="button" className="sh-btn ghost" disabled={saving} onClick={load} aria-label="매장 설정 다시 불러오기"><RefreshCw aria-hidden />다시 불러오기</button>
    </div>);
  const profileState = <>
    {loadErr && <Msg tone="err">{loadErr} <button type="button" className="nc-close" onClick={load}><RefreshCw size={18} aria-hidden />다시 시도</button></Msg>}
    {!p && !loadErr && <div className="sh-skel" aria-label="불러오는 중"><i /><i /><i /></div>}
  </>;
  return (
    <Modal title={TITLES[view]} sub={view === 'home' ? '큰 그림을 눌러 들어가세요. 언제든 뒤로가기로 돌아옵니다.' : undefined} onClose={onClose}>
      <div className="sh-root" data-view={view}>
        {view !== 'home' && <div className="sh-nav">
          <button type="button" className="sh-back" onClick={() => setView(parent)} data-testid="button-settings-back"><ChevronLeft aria-hidden />{parent === 'home' ? '설정 처음으로' : '휴대폰연결로'}</button>
          <span className="sh-crumb">설정 › {parent === 'phone' ? '휴대폰연결 › ' : ''}{TITLES[view]}</span>
        </div>}
        {view === 'home' && <>
          <div className="sh-tiles five">
            {MENU.map(([id, t, s, Icon], i) => <button key={id} type="button" className={`sh-tile c${i + 1}`} onClick={() => setView(id)} data-testid={`button-settings-${id}`}>
              <Icon aria-hidden /><b>{t}</b><small>{s}</small></button>)}
          </div>
          <button type="button" className="sh-btn ghost sh-guide-link" onClick={() => openGuide('setup', 'menu')}><BookOpen aria-hidden />설정 메뉴 그림 설명서</button>
        </>}
        {view === 'store' && <>{profileState}{p && <>
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-store">매장명</label>
              <input id="nc-store" lang="ko" className="nc-input" value={p.storeName} onChange={(e) => setP({ ...p, storeName: e.target.value })} /></div>
            <div><label className="nc-label" htmlFor="nc-owner">본인 휴대폰 번호</label>
              <input id="nc-owner" lang="ko" inputMode="tel" className="nc-input" value={p.ownerPhone} onChange={(e) => setP({ ...p, ownerPhone: e.target.value })} /></div>
          </div>
          <label className="nc-label" htmlFor="nc-intro">매장 소개글</label>
          <textarea id="nc-intro" lang="ko" className="nc-input" value={p.introduction} onChange={(e) => setP({ ...p, introduction: e.target.value })} />
          <label className="nc-label" htmlFor="nc-bank">입금 계좌 안내 (은행 · 계좌번호 · 예금주)</label>
          <input id="nc-bank" className="nc-input" maxLength={300} value={p.bankAccount ?? ''} onChange={(e) => setP({ ...p, bankAccount: e.target.value })} />
          <p className="nc-hint">등록한 계좌는 고객 안내문에 자동으로 들어갑니다. 실제 매장 계좌를 확인해 입력해 주세요.</p>
          {saveRow}
        </>}
          <details className="nc-section"><summary>프로그램 연결 주소 · 저장 위치 관리 (펼치기)</summary>
            <ProgramIntegrationSettings/><StorageLayoutSettings/>
          </details>
        </>}
        {view === 'price' && <>{profileState}{p && <>
          <div className="nc-grid3">
            {DISCOUNT_FIELDS.map(([k, label]) => (
              <div key={k}><label className="nc-label" htmlFor={`nc-d-${k}`}>{label}</label>
                <input id={`nc-d-${k}`} className="nc-input" inputMode="numeric" lang="ko" value={nums[k] ?? ''} onChange={(e) => setNums({ ...nums, [k]: e.target.value })} /></div>
            ))}
          </div>
          <Msg tone="info">기준금액 또는 할인율·할인액을 0으로 두면 그 할인은 꺼집니다. 품목 가격표는 통합관리센터에서 바꿉니다.</Msg>
          {saveRow}
        </>}</>}
        {view === 'owner' && <>{profileState}{p && <>
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-staff">직원 목록 (한 줄에 한 명)</label>
              <textarea id="nc-staff" lang="ko" className="nc-input" value={staffText} onChange={(e) => setStaffText(e.target.value)} /></div>
            <div><label className="nc-label" htmlFor="nc-default-staff">기본 담당자</label>
              <select id="nc-default-staff" className="nc-input" value={p.defaultStaff} onChange={(e) => setP({ ...p, defaultStaff: e.target.value })}>
                <option value="">선택 안 함</option>
                {staffText.split('\n').map((s) => s.trim()).filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
              </select></div>
          </div>
          {saveRow}
        </>}
          <OwnerSecurityPanel />
          <button type="button" className="sh-btn ghost" onClick={() => openGuide('setup', 'owner')}><BookOpen aria-hidden />점주 보안 그림 설명</button>
        </>}
        {view === 'hardware' && <HardwareSettings />}
        {view === 'phone' && <div className="sh-tiles two">
          <button type="button" className="sh-tile c6" onClick={() => setView('phone-camera')} data-testid="button-phone-camera"><Camera aria-hidden /><b>촬영용 휴대폰</b><small>Iriun 카메라 연결</small></button>
          <button type="button" className="sh-tile c7" onClick={() => setView('phone-message')} data-testid="button-phone-message"><MessageCircle aria-hidden /><b>문자 · 카톡 휴대폰</b><small>PC와 휴대폰 연결</small></button>
        </div>}
        {view === 'phone-camera' && <CameraPhoneBody />}
        {view === 'phone-message' && <ConnectHelperBody />}
        {line && <Msg tone={line.tone}>{line.text}</Msg>}
      </div>
    </Modal>
  );
}

/* ---------------- 고객 메시지 편집 ---------------- */
function NoticeEditor({ orderId, initialTemplateId, onClose,showOrderDetails=false,onHandover }: { orderId: string; initialTemplateId?: string; onClose: () => void }&NoticeOpenOptions) {
  const seq = useRef(0);
  const [loadErr, setLoadErr] = useState('');
  const [templates, setTemplates] = useState<NoticeTemplate[]>([]);
  const [ctx, setCtx] = useState<NoticeContext | null>(null);
  const [detailOrder,setDetailOrder]=useState<ConfirmedOrder|null>(null);
  const [handoverDone,setHandoverDone]=useState(false);
  const [notices, setNotices] = useState<CustomerNotice[]>([]);
  const [selected, setSelected] = useState<{ id: string; revision: number } | null>(null);
  const [templateId, setTemplateId] = useState('');
  const [stageView,setStageView]=useState<'before'|'after'>(initialTemplateId?.startsWith('after-')?'after':'before');
  const [body, setBody] = useState('');
  const [theme, setTheme] = useState('');
  const [dirty, setDirty] = useState(false);
  const [review, setReview] = useState(false);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [mobile, setMobile] = useState<{ url: string; expiresAt: string } | null>(null);
  const [pollErr, setPollErr] = useState('');
  const busyRef = useRef(false);
  const editToken = useRef(0);
  const bodyRef=useRef(''),cursorRef=useRef<number|null>(null),composing=useRef(false);
  const bodyInput=useRef<HTMLTextAreaElement>(null),pendingCursor=useRef<number|null>(null);
  useLayoutEffect(()=>{
    if(pendingCursor.current!==null&&document.activeElement===bodyInput.current)
      bodyInput.current?.setSelectionRange(pendingCursor.current,pendingCursor.current);
    pendingCursor.current=null;
  },[body]);
  const seenMobile=useRef(new Map<string,number>());
  const previewSeq=useRef(0),previewPending=useRef(false);
  const [previewBusy,setPreviewBusy]=useState(false);
  const editBody = (v: string) => { editToken.current++;bodyRef.current=v;setBody(v); setDirty(true); };
  // 비동기 결과로 본문 교체: 요청 이후 직원이 손댔거나 주문이 바뀌었으면 버림
  const applyAsyncBody = (my: number, token: number, v: string) => {
    if (my !== seq.current || token !== editToken.current) { setLine({ tone: 'warn', text: '그 사이 글을 고치셔서 불러온 글은 적용하지 않았습니다. 필요하면 다시 눌러 주세요.' }); return false; }
    editToken.current++;bodyRef.current=v;setBody(v);cursorRef.current=null;
    setDirty(false); setSelected(null); return true;
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const runPreview = useCallback(async (tid: string, rc: boolean, replaceBody: boolean) => {
    const my = seq.current,request=++previewSeq.current; const token = editToken.current;
    previewPending.current=true;setPreviewBusy(true);
    try {
      const r = await noticeApi<{ body: string }>('POST', '/preview', { orderId, templateId: tid, reviewConfirmed: rc });
      if (my !== seq.current||request!==previewSeq.current) return;
      if (replaceBody) applyAsyncBody(my, token, r.body);
    } catch (e) { if (my === seq.current&&request===previewSeq.current) setLine({ tone: 'err', text: `미리보기 실패: ${errText(e)}` }); }
    finally{if(my===seq.current&&request===previewSeq.current){previewPending.current=false;setPreviewBusy(false);}}
  }, [orderId]);

  // 처음 / 다른 주문: 오래된 응답 무시
  useEffect(() => {
    const my = ++seq.current;
    setLoadErr(''); setCtx(null); setNotices([]); setSelected(null); setBody(''); setTheme(''); setDirty(false);
    bodyRef.current='';cursorRef.current=null;seenMobile.current.clear();
    setLine(null);setMobile(null); setReview(false);
    (async () => {
      try {
        if(showOrderDetails)setDetailOrder(readConfirmedOrders().find(order=>order.id===orderId)??null);
        const [t, c, d] = await Promise.all([
          noticeApi<{ templates: NoticeTemplate[] }>('GET', '/templates'),
          noticeApi<{ context: NoticeContext }>('GET', `/context?orderId=${encodeURIComponent(orderId)}`),
          noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`),
        ]);
        if (my !== seq.current) return;
        const available=t.templates.filter(x=>x.stage!=='advert');
        setTemplates(available); setCtx(c.context); setNotices(d.notices);setReview(c.context.reviewConfirmed===true);
        d.notices.filter(n=>n.source==='mobile').forEach(n=>seenMobile.current.set(n.id,n.revision));
        const first = available.find((x) => x.stage === 'before') ?? available[0];
        const tid = initialTemplateId && available.some((x) => x.id === initialTemplateId) ? initialTemplateId : first?.id ?? '';
        if (tid) {setTheme(available.find(t=>t.id===tid)?.title||'고객 안내');setTemplateId(tid); await runPreview(tid, c.context.reviewConfirmed===true, true); }
      } catch (e) { if (my === seq.current) setLoadErr(errText(e)); }
    })();
    return () => { seq.current++; };
  }, [orderId, initialTemplateId, runPreview,showOrderDetails]);

  // 촬영 QR에서 들어온 글도 수신한다. 편집창 자체 QR을 켰는지와 무관하게
  // 유효한 주문의 목록만 3초마다 갱신하고 작성 중 본문은 덮어쓰지 않는다.
  useEffect(() => {
    if (ctx?.orderId !== orderId) return;
    const my = seq.current; let inflight = false;
    const id = window.setInterval(async () => {
      if (inflight) return; inflight = true;
      try {
        const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
        if (my === seq.current) {
          setNotices(d.notices);setPollErr('');
          const incoming=d.notices.filter(n=>n.source==='mobile'&&seenMobile.current.get(n.id)!==n.revision)
            .sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)||a.id.localeCompare(b.id));
          if(incoming.length&&!composing.current&&!busyRef.current&&!previewPending.current){
            const next=appendMobileNotice(bodyRef.current,incoming.map(n=>n.body).join('\n\n'),cursorRef.current);
            pendingCursor.current=next.cursor;editBody(next.body);cursorRef.current=next.cursor;
            incoming.forEach(n=>seenMobile.current.set(n.id,n.revision));
            setLine({tone:'info',text:'휴대폰에서 보낸 글을 보낼 글에 추가했습니다. 기존 글은 지우지 않았습니다.'});
          }
        }
      } catch (e) { if (my === seq.current) setPollErr(`휴대폰 메시지 확인 실패: ${errText(e)}`); }
      finally { inflight = false; }
    }, 3000);
    return () => window.clearInterval(id);
  }, [ctx?.orderId, orderId]);

  const latestOfSelected = selected ? notices.find((n) => n.id === selected.id) : undefined;
  const staleSelected = !!(selected && latestOfSelected && latestOfSelected.revision > selected.revision);

  const pickTemplate = (t: NoticeTemplate) => {
    if(busyRef.current)return;
    editToken.current++;bodyRef.current='';cursorRef.current=null;setBody('');setSelected(null);setDirty(false);
    setTheme(t.title);setLine(null);setTemplateId(t.id);void runPreview(t.id, review, true);
  };

  const save = async (): Promise<CustomerNotice | null> => {
    if (!body.trim()) { setLine({ tone: 'err', text: '보낼 글이 비어 있습니다.' }); return null; }
    if (!templateId) { setLine({ tone: 'err', text: '안내문 종류를 먼저 골라 주세요.' }); return null; }
    const my = seq.current, token = editToken.current;
    if (selected) {
      const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
      if (my !== seq.current) return null;
      setNotices(d.notices);
      const cur = d.notices.find((n) => n.id === selected.id);
      if (cur && cur.revision !== selected.revision) {
        setLine({ tone: 'warn', text: '다른 곳에서 저장된 글이 바뀌었습니다. 작성한 글을 복사해 둔 뒤 안내문을 다시 선택해 주세요.' });
        return null;
      }
    }
    const r = await noticeApi<{ notice: CustomerNotice }>('POST', '/drafts', {
      ...(selected ? { id: selected.id, revision: selected.revision } : {}), orderId, body, theme, templateId, advertConsentConfirmed:false,
    });
    if (my !== seq.current) return null;
    setSelected({ id: r.notice.id, revision: r.notice.revision });
    if(token===editToken.current)setDirty(false);
    setNotices((list) => [r.notice, ...list.filter((n) => n.id !== r.notice.id)]);
    return r.notice;
  };

  const guard = async (key: string, fn: () => Promise<void>) => {
    if (busyRef.current) return; busyRef.current = true; setBusy(key);
    try { await fn(); } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { busyRef.current = false; setBusy(null); }
  };
  const prepareLocal = async () => {
    if (busyRef.current) return false;
    busyRef.current = true; setBusy('prepare-local');
    try {
      const n = await save();
      if (!n) return false;
      setLine({tone:'info',text:'문안을 저장했습니다. QR이나 카카오톡을 준비해도 실제 발송 완료로 기록하지 않습니다.'});
      return {noticeId:n.id, revision:n.revision};
    } catch (e) { setLine({tone:'err',text:errText(e)}); return false; }
    finally { busyRef.current = false; setBusy(null); }
  };
  const startMobile = () => guard('mobile', async () => {
    const my = seq.current;
    const r = await noticeApi<{ url: string; expiresAt: string }>('POST', '/mobile/start', { orderId });
    if (my === seq.current) setMobile(r);
  });
  const before = templates.filter((t) => t.stage === 'before');
  const after = templates.filter((t) => t.stage === 'after');
  const tplGroup = (title: string, list: NoticeTemplate[]) => (
    <div><h4 style={{ margin: '8px 0', fontSize: 18 }}>{title}</h4>
      <div className="nc-tpls">{list.map((t) => (
        <button key={t.id} type="button" className="nc-tpl" disabled={!!busy} aria-pressed={templateId === t.id} onClick={() => pickTemplate(t)} aria-label={`${title} 안내문: ${t.title}`}>{t.title}</button>
      ))}</div></div>
  );
  const anyBusy = !!busy||previewBusy;
  const safeClose = () => {
    if(busyRef.current){setLine({tone:'warn',text:'문안 저장·준비가 끝난 뒤 닫아 주세요.'});return;}
    if(dirty&&body.trim()&&!window.confirm('수정한 메시지를 저장하지 않고 닫을까요?'))return;
    onClose();
  };

  return (
    <Modal title={showOrderDetails?'고객 상세 · 메시지 발송':'고객 메시지 편집'} className={showOrderDetails?'nc-order-detail':''}
      sub={ctx ? `${ctx.customerName} 고객 · 주문 ${ctx.orderId}` : `주문 ${orderId}`} onClose={safeClose}>
      {loadErr && <Msg tone="err">불러오기 실패: {loadErr}</Msg>}
      {!ctx && !loadErr && <Msg tone="info">주문 정보를 불러오는 중입니다…</Msg>}
      {ctx && (
        <div className="nc-layout nc-simple-editor">
          {showOrderDetails&&<CustomerNoticeOrderSummary context={ctx} order={detailOrder} templateId={templateId}/>}
          <div>
            <section className="nc-section"><h3>안내문 종류 고르기</h3>
              <div className="nc-toggle" role="group" aria-label="안내문 단계">
                <button type="button" aria-pressed={stageView==='before'} onClick={()=>setStageView('before')}>세탁 전 · 기본 안내</button>
                <button type="button" aria-pressed={stageView==='after'} onClick={()=>setStageView('after')}>세탁 후 · 특별 안내</button>
              </div>
              {showOrderDetails?<CustomerNoticeTemplateChoices orderId={orderId} title={stageView==='before'?'세탁 전':'세탁 후'}
                templates={stageView==='before'?before:after} selectedId={templateId} busy={!!busy} onSelect={pickTemplate}/>
                :stageView==='before'?tplGroup('세탁 전',before):tplGroup('세탁 후',after)}
            </section>
            {staleSelected && <Msg tone="warn">다른 곳에서 저장된 문안이 변경되었습니다. 작성한 글은 유지했습니다. 글을 복사해 둔 뒤 안내문을 다시 선택해 주세요.</Msg>}
            <label className="nc-label" htmlFor="nc-body">보낼 글 (자유롭게 고치세요)</label>
            <textarea ref={bodyInput} id="nc-body" lang="ko" className="nc-input nc-body" value={body}
              onChange={(e) => editBody(e.target.value)}
              onSelect={e=>{cursorRef.current=e.currentTarget.selectionStart;}}
              onCompositionStart={()=>{composing.current=true;}} onCompositionEnd={e=>{composing.current=false;cursorRef.current=e.currentTarget.selectionStart;}}
              aria-label="고객에게 보낼 글" />
            <p className="nc-hint">받는 분: {ctx.customerName} · {ctx.customerPhone} / 저장된 주문 금액: {won(ctx.total)}</p>
            {onHandover&&<button type="button" className="nc-big gold cnd-handover" data-testid="button-detail-handover"
              disabled={anyBusy||handoverDone} onClick={()=>void guard('handover',async()=>{
                const result=onHandover();
                if(result.success){setHandoverDone(true);setDetailOrder(readConfirmedOrders().find(order=>order.id===orderId)??null);}
                setLine({tone:result.success?'ok':'warn',text:result.message});
              })}>{handoverDone?'출고 완료':'이 고객 출고 완료 처리'}</button>}
            <AccountlessNoticeActions recipient={ctx.customerPhone} body={body} onPrepare={prepareLocal} disabled={anyBusy}
              orderId={orderId} templateId={templateId} customerName={ctx.customerName}
              launchLabel={showOrderDetails?'휴대폰으로 메시지 보내기(카톡 · 문자)':undefined}/>
            {line && <Msg tone={line.tone}>{line.text}</Msg>}
          </div>
          <div>
            <section className="nc-section"><h3>휴대폰으로 글 입력하기 (QR)</h3>
              <p style={{fontSize:20,lineHeight:1.7}}>① QR 스캔 → ② 휴대폰에서 음성/글 입력 후 전송 → ③ 왼쪽 ‘보낼 글’에 자동 삽입</p>
              {mobile ? (<>
                <div className="nc-qr"><QrCanvas url={mobile.url} /></div>
                <p style={{ margin: '8px 0 0' }}>{new Date(mobile.expiresAt).toLocaleTimeString('ko-KR')}까지 유효합니다. 받은 글은 PC의 커서 위치 또는 본문 하단에 추가됩니다. 같은 매장 Wi-Fi에 연결해 주세요.</p>
                <div className="nc-row"><button type="button" className="nc-big ghost" onClick={() => setMobile(null)} aria-label="휴대폰 쓰기 연결 끝내기">연결 끝내기</button></div>
              </>) : (
                <button type="button" className="nc-big" disabled={anyBusy} onClick={startMobile} aria-label="휴대폰으로 쓰기 QR 만들기"><QrCode aria-hidden />QR 만들기</button>)}
              {pollErr && <Msg tone="err">{pollErr}</Msg>}
            </section>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ---------------- 진입점 ---------------- */
export function MessagingToolbar(): JSX.Element {
  const [open, setOpen] = useState<{ view: View; key: number } | null>(null);
  const [notice, setNotice] = useState<({ orderId: string; templateId?: string;key: number }&NoticeOpenOptions) | null>(null);
  useEffect(() => {
    const h = (e: Event) => {
      const d = (e as CustomEvent<{ orderId?: string; templateId?: string }&NoticeOpenOptions>).detail;
      if (d?.orderId) setNotice({ orderId: d.orderId, templateId: d.templateId,showOrderDetails:d.showOrderDetails===true,
        onHandover:typeof d.onHandover==='function'?d.onHandover:undefined,key: Date.now() });
    };
    window.addEventListener(OPEN_CUSTOMER_NOTICE, h);
    const settings=(e:Event)=>{const v=(e as CustomEvent<{view?:View}>).detail?.view;setOpen({view:v&&v in TITLES?v:'home',key:Date.now()});};
    window.addEventListener('k99-open-store-settings',settings);
    return () => {window.removeEventListener(OPEN_CUSTOMER_NOTICE, h);window.removeEventListener('k99-open-store-settings',settings);};
  }, []);
  return (
    <>
      <div className="nc-toolbar">
        <button type="button" className="nc-big sh-help" onClick={() => openGuide()} aria-label="도움말 그림 설명서 열기" data-testid="button-open-help"><CircleHelp aria-hidden />도움말</button>
        <button type="button" className="nc-big" onClick={() => setOpen({view:'home',key:Date.now()})} aria-label="매장 맞춤 설정" data-testid="button-open-settings"><Settings aria-hidden />매장 맞춤 설정</button>
      </div>
      {open && <StoreSettings key={open.key} initialView={open.view} onClose={() => setOpen(null)} />}
      {notice && <NoticeEditor key={notice.key} orderId={notice.orderId} initialTemplateId={notice.templateId}
        showOrderDetails={notice.showOrderDetails} onHandover={notice.onHandover} onClose={() => setNotice(null)} />}
      <SpecialNoteHost />
      <PictureGuideHost />
    </>
  );
}

export default MessagingToolbar;
