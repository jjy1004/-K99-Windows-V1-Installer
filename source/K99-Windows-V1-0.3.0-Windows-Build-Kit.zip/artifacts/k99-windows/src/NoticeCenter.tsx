import { useCallback, useEffect, useRef, useState, type JSX, type KeyboardEvent, type ReactNode } from 'react';
import {createPortal} from 'react-dom';
import bwipjs from 'bwip-js/browser';
import {
  AlertTriangle, CheckCircle2, Info, Loader2, MessageCircle, Search, Send, Settings, Smartphone, X, Save, QrCode, Sparkles, RefreshCw,
} from 'lucide-react';
import {
  messenger, noticeApi, OPEN_CUSTOMER_NOTICE,
  type CustomerNotice as BaseNotice, type MessengerResult, type NoticeCase, type NoticeContext, type NoticeQuote, type NoticeTemplate as BaseTemplate, type StoreProfile,
} from './notice-api';

// 서버 확장 필드(광고 단계·템플릿 revision·광고 동의)를 이 파일 안에서만 보강
type Stage = 'before' | 'after' | 'advert';
type NoticeTemplate = Omit<BaseTemplate, 'stage'> & { stage: Stage; revision: number };
type CustomerNotice = BaseNotice & { advertConsentConfirmed?: boolean };
const PLACEHOLDERS = ['{고객명}', '{연락처}', '{품목내역}', '{견적내역}', '{매장명}', '{매장소개}', '{담당자}'];
import './notice-center.css';

type Tone = 'info' | 'ok' | 'warn' | 'err';
const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');

function Msg({ tone, children }: { tone: Tone; children: ReactNode }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle;
  return <div className={`nc-msg ${tone}`} role={tone === 'err' ? 'alert' : 'status'}><Icon size={22} aria-hidden /> <div>{children}</div></div>;
}

function QrCanvas({ url }: { url: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    if (!ref.current || !url) return;
    try { bwipjs.toCanvas(ref.current, { bcid: 'qrcode', text: url, scale: 5, padding: 4 }); setErr(false); }
    catch { setErr(true); }
  }, [url]);
  return err ? <Msg tone="err">QR을 만들지 못했습니다. 연결 끝내기 후 다시 만들어 주세요.</Msg>
    : <canvas ref={ref} role="img" aria-label="휴대폰으로 글쓰기 연결 QR 코드" style={{ display: 'block', maxWidth: '100%' }} />;
}

function Modal({ title, sub, onClose, narrow, children }: { title: string; sub?: string; onClose: () => void; narrow?: boolean; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous=document.activeElement as HTMLElement|null;
    ref.current?.focus();
    return()=>{if(previous?.isConnected)previous.focus();};
  }, []);
  const onKey = (e: KeyboardEvent) => {
    // 접수 화면 전역 단축키와 격리
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) onClose();
    if(e.key==='Tab'){
      const focusable=Array.from(ref.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]')||[])
        .filter(el=>el.getClientRects().length>0);
      const first=focusable[0],last=focusable.at(-1);
      if(!first){e.preventDefault();ref.current?.focus();}
      else if(e.shiftKey&&(document.activeElement===first||document.activeElement===ref.current)){e.preventDefault();last?.focus();}
      else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===ref.current)){e.preventDefault();first.focus();}
    }
  };
  return createPortal(
    <div className="nc-backdrop" data-notice-modal="true" onKeyDown={onKey} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className={`nc-modal${narrow ? ' narrow' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="nc-head">
          <div><h2>{title}</h2>{sub && <p>{sub}</p>}</div>
          <button type="button" className="nc-close" onClick={onClose} aria-label={`${title} 닫기`}><X size={22} aria-hidden />닫기</button>
        </div>
        {children}
      </div>
    </div>,document.body
  );
}

function resultLine(r: MessengerResult): { tone: Tone; text: string } {
  if (!r.success) return { tone: 'err', text: r.error || r.detail || '확인 필요: 프로그램을 열지 못했습니다.' };
  switch (r.status) {
    case 'prepared': return { tone: 'warn', text: '자동입력됨 — 외부 앱 화면에서 직원이 내용을 확인한 뒤 직접 보내기를 눌러 주세요.' };
    case 'send_requested': return { tone: 'warn', text: '전송요청됨 — 고객에게 도착했는지는 아직 확인되지 않았습니다.' };
    case 'opened': return { tone: 'info', text: '열기 요청을 보냈습니다. 화면에서 직접 확인해 주세요.' };
    default: return { tone: 'warn', text: `확인 필요${r.detail ? ` — ${r.detail}` : ''}` };
  }
}

/* ---------------- 연결 도우미 ---------------- */
function ConnectHelper({ onClose }: { onClose: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [phone, setPhone] = useState('');
  const [profile, setProfile] = useState<{ profile: StoreProfile; revision: number } | null>(null);
  useEffect(() => {
    let live = true;
    noticeApi<{ profile: StoreProfile; revision: number }>('GET', '/profile')
      .then((p) => { if (live) { setProfile(p); setPhone(p.profile.ownerPhone || ''); } })
      .catch((e) => live && setLine({ tone: 'err', text: errText(e) }));
    return () => { live = false; };
  }, []);
  const run = async (key: string, fn: () => Promise<MessengerResult>) => {
    if (busy) return; setBusy(key); setLine(null);
    try {
      const r = await fn();
      setLine(r.success ? { tone: 'info', text: `${key === 'test' ? '테스트 문자 열기' : '연결 화면 열기'} 요청을 보냈습니다. 실제 연결·도착 여부는 휴대폰에서 직접 확인해 주세요.${r.detail ? ` (${r.detail})` : ''}` } : resultLine(r));
    } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { setBusy(null); }
  };
  const test = async (channel:'sms'|'kakao'='sms') => {
    const p = phone.trim();
    if (!/^[0-9-]{9,14}$/.test(p)) { setLine({ tone: 'err', text: '본인 휴대폰 번호를 숫자로 정확히 입력해 주세요.' }); return; }
    if (profile && profile.profile.ownerPhone !== p) {
      try {
        const saved = await noticeApi<{ profile: StoreProfile; revision: number }>('PUT', '/profile', { profile: { ...profile.profile, ownerPhone: p }, revision: profile.revision });
        setProfile(saved);
      } catch (e) { setLine({ tone: 'err', text: `본인번호 저장 실패: ${errText(e)}` }); return; }
    }
    await run('test', () => messenger({ action: 'test', phone: p,channel }));
  };
  return (
    <Modal title="휴대폰·카톡 연결하기" sub="PC에서 휴대폰 문자와 카카오톡을 열 수 있게 준비합니다." onClose={onClose}>
      <div className="nc-row">
        <button type="button" className="nc-big gold" disabled={!!busy} onClick={() => run('phone', () => messenger({ action: 'phone' }))} aria-label="휴대폰 문자 연결 화면 열기">
          {busy === 'phone' ? <Loader2 className="animate-spin" aria-hidden /> : <Smartphone aria-hidden />}휴대폰 연결 열기
        </button>
        <button type="button" className="nc-big gold" disabled={!!busy} onClick={() => run('kakao', () => messenger({ action: 'kakao' }))} aria-label="PC 카카오톡 열기">
          {busy === 'kakao' ? <Loader2 className="animate-spin" aria-hidden /> : <MessageCircle aria-hidden />}카카오톡 열기
        </button>
      </div>
      <section className="nc-section" aria-label="연결 3단계 안내">
        <h3>이렇게 따라 하세요</h3>
        <div className="nc-steps">
          <div className="nc-step"><b>1</b><strong>QR 찍기</strong><span>PC 화면에 나온 QR을 휴대폰 카메라로 찍습니다.</span></div>
          <div className="nc-step"><b>2</b><strong>연결 허용</strong><span>휴대폰에 뜬 “허용” 버튼을 누릅니다.</span></div>
          <div className="nc-step"><b>3</b><strong>완료 확인</strong><span>PC에 내 문자 목록이 보이면 끝입니다.</span></div>
        </div>
      </section>
      <section className="nc-section">
        <h3>내 번호로 시험해 보기</h3>
        <label className="nc-label" htmlFor="nc-owner-phone">본인 휴대폰 번호</label>
        <input id="nc-owner-phone" className="nc-input" lang="ko" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="010-0000-0000" aria-label="본인 휴대폰 번호" />
        <div className="nc-row">
          <button type="button" className="nc-big" disabled={!!busy} onClick={()=>test('sms')} aria-label="본인 번호로 테스트 문자 열기">
            {busy === 'test' ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}테스트 문자 열기
          </button>
          <button type="button" className="nc-big gold" disabled={!!busy} onClick={()=>test('kakao')}>카톡 연결 상태 확인 테스트</button>
        </div>
      </section>
      {line && <Msg tone={line.tone}>{line.text}</Msg>}
    </Modal>
  );
}

/* ---------------- 매장 설정 ---------------- */
const DISCOUNT_FIELDS: [keyof StoreProfile['discounts'], string][] = [
  ['firstThreshold', '1단계 할인 기준금액(원)'], ['firstRate', '1단계 할인율(%)'],
  ['secondThreshold', '2단계 할인 기준금액(원)'], ['secondRate', '2단계 할인율(%)'],
  ['reviewThreshold', '리뷰할인 기준금액(원)'], ['reviewDiscount', '리뷰 할인액(원)'],
];
function StoreSettings({ onClose }: { onClose: () => void }) {
  const [rev, setRev] = useState<number | null>(null);
  const [p, setP] = useState<StoreProfile | null>(null);
  const [staffText, setStaffText] = useState('');
  const [nums, setNums] = useState<Record<string, string>>({});
  const [loadErr, setLoadErr] = useState('');
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const apply = (r: { profile: StoreProfile; revision: number }) => {
    setP(r.profile); setRev(r.revision); setStaffText(r.profile.staff.join('\n'));
    setNums(Object.fromEntries(DISCOUNT_FIELDS.map(([k]) => [k, String(r.profile.discounts[k] ?? 0)])));
  };
  const load = useCallback(() => {
    setLoadErr('');
    noticeApi<{ profile: StoreProfile; revision: number }>('GET', '/profile').then(apply).catch((e) => setLoadErr(errText(e)));
  }, []);
  useEffect(load, [load]);
  const save = async () => {
    if (!p || rev === null || saving) return;
    const discounts = {} as StoreProfile['discounts'];
    for (const [k, label] of DISCOUNT_FIELDS) {
      const n = Number(nums[k]);
      if (!Number.isFinite(n) || n < 0) { setLine({ tone: 'err', text: `${label}에 0 이상의 숫자를 넣어 주세요.` }); return; }
      discounts[k] = n;
    }
    const staff = staffText.split('\n').map((s) => s.trim()).filter(Boolean);
    setSaving(true); setLine(null);
    try {
      const r = await noticeApi<{ profile: StoreProfile; revision: number }>('PUT', '/profile', { profile: { ...p, staff, discounts }, revision: rev });
      apply(r); setLine({ tone: 'ok', text: '저장되었습니다.' });
    } catch (e) { setLine({ tone: 'err', text: `저장 실패: ${errText(e)} 다른 곳에서 바뀌었다면 “다시 불러오기” 후 수정해 주세요.` }); }
    finally { setSaving(false); }
  };
  return (
    <Modal title="매장 맞춤 설정" sub="고객 안내문에 들어갈 매장 정보와 할인 기준입니다." onClose={onClose}>
      {loadErr && <Msg tone="err">{loadErr} <button type="button" className="nc-close" onClick={load}><RefreshCw size={18} aria-hidden />다시 시도</button></Msg>}
      {!p && !loadErr && <Msg tone="info">불러오는 중입니다…</Msg>}
      {p && (
        <>
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-store">매장명</label>
              <input id="nc-store" lang="ko" className="nc-input" value={p.storeName} onChange={(e) => setP({ ...p, storeName: e.target.value })} /></div>
            <div><label className="nc-label" htmlFor="nc-owner">본인 휴대폰 번호</label>
              <input id="nc-owner" lang="ko" inputMode="tel" className="nc-input" value={p.ownerPhone} onChange={(e) => setP({ ...p, ownerPhone: e.target.value })} /></div>
          </div>
          <label className="nc-label" htmlFor="nc-intro">매장 소개글</label>
          <textarea id="nc-intro" lang="ko" className="nc-input" value={p.introduction} onChange={(e) => setP({ ...p, introduction: e.target.value })} />
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-staff">직원 목록 (한 줄에 한 명)</label>
              <textarea id="nc-staff" lang="ko" className="nc-input" value={staffText} onChange={(e) => setStaffText(e.target.value)} /></div>
            <div><label className="nc-label" htmlFor="nc-default-staff">기본 담당자</label>
              <select id="nc-default-staff" className="nc-input" value={p.defaultStaff} onChange={(e) => setP({ ...p, defaultStaff: e.target.value })}>
                <option value="">선택 안 함</option>
                {staffText.split('\n').map((s) => s.trim()).filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
              </select></div>
          </div>
          <section className="nc-section"><h3>할인 정책</h3>
            <div className="nc-grid3">
              {DISCOUNT_FIELDS.map(([k, label]) => (
                <div key={k}><label className="nc-label" htmlFor={`nc-d-${k}`}>{label}</label>
                  <input id={`nc-d-${k}`} className="nc-input" inputMode="numeric" lang="ko" value={nums[k] ?? ''} onChange={(e) => setNums({ ...nums, [k]: e.target.value })} /></div>
              ))}
            </div>
            <Msg tone="info">기준금액 또는 할인율·할인액을 0으로 두면 그 할인은 꺼집니다. 1단계·2단계 할인이 둘 다 켜져 있을 때만 기준금액 순서를 서버가 확인합니다.</Msg>
          </section>
          <div className="nc-row">
            <button type="button" className="nc-big gold" disabled={saving} onClick={save} aria-label="매장 설정 저장하기">{saving ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}저장하기</button>
            <button type="button" className="nc-big ghost" disabled={saving} onClick={load} aria-label="매장 설정 다시 불러오기"><RefreshCw aria-hidden />다시 불러오기</button>
          </div>
        </>
      )}
      {line && <Msg tone={line.tone}>{line.text}</Msg>}
    </Modal>
  );
}

/* ---------------- 고객 메시지 편집 ---------------- */
function NoticeEditor({ orderId, initialTemplateId, onClose }: { orderId: string; initialTemplateId?: string; onClose: () => void }) {
  const seq = useRef(0);
  const [loadErr, setLoadErr] = useState('');
  const [templates, setTemplates] = useState<NoticeTemplate[]>([]);
  const [ctx, setCtx] = useState<NoticeContext | null>(null);
  const [notices, setNotices] = useState<CustomerNotice[]>([]);
  const [selected, setSelected] = useState<{ id: string; revision: number } | null>(null);
  const [templateId, setTemplateId] = useState('');
  const [body, setBody] = useState('');
  const [theme, setTheme] = useState('');
  const [dirty, setDirty] = useState(false);
  const [review, setReview] = useState(false);
  const [quote, setQuote] = useState<NoticeQuote | null>(null);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [mode, setMode] = useState<'confirm' | 'immediate'>('confirm');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const [mobile, setMobile] = useState<{ url: string; expiresAt: string } | null>(null);
  const [pollErr, setPollErr] = useState('');
  const [keyword, setKeyword] = useState('');
  const [cases, setCases] = useState<NoticeCase[] | null>(null);
  const busyRef = useRef(false);
  const editToken = useRef(0);
  const [advertOk, setAdvertOk] = useState(false);
  const [rawText, setRawText] = useState('');
  const [rawFor, setRawFor] = useState<{ id: string; revision: number } | null>(null);
  const [rawLine, setRawLine] = useState<{ tone: Tone; text: string } | null>(null);
  const themeRef = useRef<HTMLInputElement>(null);
  const editBody = (v: string) => { editToken.current++; setBody(v); setDirty(true); };
  // 비동기 결과로 본문 교체: 요청 이후 직원이 손댔거나 주문이 바뀌었으면 버림
  const applyAsyncBody = (my: number, token: number, v: string, th?: string) => {
    if (my !== seq.current || token !== editToken.current) { setLine({ tone: 'warn', text: '그 사이 글을 고치셔서 불러온 글은 적용하지 않았습니다. 필요하면 다시 눌러 주세요.' }); return false; }
    editToken.current++; setBody(v); if (th !== undefined) setTheme(th); setDirty(true); setSelected(null); return true;
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const runPreview = useCallback(async (tid: string, rc: boolean, replaceBody: boolean) => {
    const my = seq.current; const token = editToken.current;
    try {
      const r = await noticeApi<{ body: string; quote: NoticeQuote }>('POST', '/preview', { orderId, templateId: tid, reviewConfirmed: rc });
      if (my !== seq.current) return;
      setQuote(r.quote);
      if (replaceBody) applyAsyncBody(my, token, r.body);
    } catch (e) { if (my === seq.current) setLine({ tone: 'err', text: `미리보기 실패: ${errText(e)}` }); }
  }, [orderId]);

  // 처음 / 다른 주문: 오래된 응답 무시
  useEffect(() => {
    const my = ++seq.current;
    setLoadErr(''); setCtx(null); setNotices([]); setSelected(null); setBody(''); setTheme(''); setDirty(false);
    setQuote(null); setLine(null); setAttemptId(null); setMobile(null); setReview(false); setCases(null); setAdvertOk(false); setRawFor(null); setRawLine(null);
    (async () => {
      try {
        const [t, c, d] = await Promise.all([
          noticeApi<{ templates: NoticeTemplate[] }>('GET', '/templates'),
          noticeApi<{ context: NoticeContext }>('GET', `/context?orderId=${encodeURIComponent(orderId)}`),
          noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`),
        ]);
        if (my !== seq.current) return;
        setTemplates(t.templates); setCtx(c.context); setNotices(d.notices);setReview(c.context.reviewConfirmed===true);
        const first = t.templates.find((x) => x.stage === 'before') ?? t.templates[0];
        const tid = initialTemplateId && t.templates.some((x) => x.id === initialTemplateId) ? initialTemplateId : first?.id ?? '';
        if (tid) { setTemplateId(tid); await runPreview(tid, c.context.reviewConfirmed===true, true); }
      } catch (e) { if (my === seq.current) setLoadErr(errText(e)); }
    })();
  }, [orderId, initialTemplateId, runPreview]);

  // 촬영 QR에서 들어온 글도 수신한다. 편집창 자체 QR을 켰는지와 무관하게
  // 유효한 주문의 목록만 3초마다 갱신하고 작성 중 본문은 덮어쓰지 않는다.
  useEffect(() => {
    if (ctx?.orderId !== orderId) return;
    const my = seq.current; let inflight = false;
    const id = window.setInterval(async () => {
      if (inflight) return; inflight = true;
      try {
        const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
        if (my === seq.current) { setNotices(d.notices); setPollErr(''); }
      } catch (e) { if (my === seq.current) setPollErr(`휴대폰 메시지 확인 실패: ${errText(e)}`); }
      finally { inflight = false; }
    }, 3000);
    return () => window.clearInterval(id);
  }, [ctx?.orderId, orderId]);

  const curTpl = templates.find((t) => t.id === templateId);
  const kind: Stage = curTpl?.stage ?? 'before';
  const isAdvert = kind === 'advert';
  const latestOfSelected = selected ? notices.find((n) => n.id === selected.id) : undefined;
  const staleSelected = !!(selected && latestOfSelected && latestOfSelected.revision > selected.revision);

  const pickTemplate = (t: NoticeTemplate) => {
    if (dirty && body.trim() && !window.confirm('지금 쓰고 있는 글을 이 안내문으로 바꿀까요?')) return;
    setTemplateId(t.id); setAdvertOk(false); setCases(null); void runPreview(t.id, review, true);
  };
  const pickNotice = (n: CustomerNotice) => {
    if (dirty && body.trim() && !window.confirm('지금 쓰고 있는 글 대신 저장된 글을 불러올까요?')) return;
    setSelected({ id: n.id, revision: n.revision }); setBody(n.body); setTheme(n.theme); setTemplateId(n.templateId); setAdvertOk(!!n.advertConsentConfirmed); setDirty(false);
  };
  const toggleReview = (v: boolean) => { setReview(v); if (templateId) void runPreview(templateId, v, false); };

  const save = async (): Promise<CustomerNotice | null> => {
    if (!body.trim()) { setLine({ tone: 'err', text: '보낼 글이 비어 있습니다.' }); return null; }
    if (!templateId) { setLine({ tone: 'err', text: '안내문 종류를 먼저 골라 주세요.' }); return null; }
    const my = seq.current;
    if (selected) {
      const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
      if (my !== seq.current) return null;
      setNotices(d.notices);
      const cur = d.notices.find((n) => n.id === selected.id);
      if (cur && cur.revision !== selected.revision) {
        setLine({ tone: 'warn', text: '다른 곳(휴대폰 등)에서 이 글이 바뀌었습니다. 목록에서 최신 글을 다시 불러온 뒤 저장해 주세요.' });
        return null;
      }
    }
    const r = await noticeApi<{ notice: CustomerNotice }>('POST', '/drafts', {
      ...(selected ? { id: selected.id, revision: selected.revision } : {}), orderId, body, theme, templateId, advertConsentConfirmed: isAdvert ? advertOk : false,
    });
    if (my !== seq.current) return null;
    setSelected({ id: r.notice.id, revision: r.notice.revision }); setDirty(false);
    setNotices((list) => [r.notice, ...list.filter((n) => n.id !== r.notice.id)]);
    return r.notice;
  };

  const guard = async (key: string, fn: () => Promise<void>) => {
    if (busyRef.current) return; busyRef.current = true; setBusy(key);
    try { await fn(); } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { busyRef.current = false; setBusy(null); }
  };
  const onSave = () => guard('save', async () => { setLine(null); const n = await save(); if (n) setLine({ tone: 'ok', text: '저장되었습니다. (아직 고객에게 보내지 않았습니다)' }); });
  const doSend = () => guard('send', async () => {
    setLine(null); setConfirmOpen(false); setAttemptId(null);
    if (isAdvert && !advertOk) { setLine({ tone: 'err', text: '광고 수신 동의·(광고) 표기·수신거부 안내 확인 체크가 필요합니다.' }); return; }
    const n = await save(); if (!n) return;
    const r = await messenger({ action: 'dispatch', noticeId: n.id, revision: n.revision, mode, requestId: crypto.randomUUID() });
    let l = resultLine(r);
    if (mode === 'immediate' && (r.manualRequired || r.status === 'unconfirmed' || r.status === 'failed')) {
      l = { tone: l.tone === 'err' ? 'err' : 'warn', text: `${l.text} 받는 사람 확인이 되지 않아 자동으로 보내지 않았습니다. 외부 앱에서 직접 확인 후 보내 주세요.` };
    }
    setLine(l); if (r.attemptId) setAttemptId(r.attemptId);
  });
  const onSendClick = () => {
    if (!theme.trim()) { setLine({ tone: 'err', text: '보내기 전에 “이 글의 테마 이름”(예: 얼룩, 수선)을 꼭 입력해 주세요.' }); themeRef.current?.focus(); return; }
    if (isAdvert && !advertOk) { setLine({ tone: 'err', text: '광고 메시지는 고객의 광고 수신 동의, 글 맨 앞 (광고) 표기, 수신거부 방법 안내를 확인하고 체크해야 보낼 수 있습니다.' }); return; }
    if (mode === 'immediate') setConfirmOpen(true); else void doSend(); };
  const confirmSent = () => guard('sent', async () => {
    if (!attemptId) return;
    await noticeApi('POST', '/confirm-sent', { attemptId });
    setAttemptId(null); setLine({ tone: 'ok', text: '발송 기록을 남겼습니다. (직원 확인)' });
  });
  const startMobile = () => guard('mobile', async () => {
    const my = seq.current;
    const r = await noticeApi<{ url: string; expiresAt: string }>('POST', '/mobile/start', { orderId });
    if (my === seq.current) setMobile(r);
  });
  const searchCases = () => guard('search', async () => {
    const my = seq.current;
    const r = await noticeApi<{ cases: NoticeCase[] }>('GET', `/cases?keyword=${encodeURIComponent(keyword.trim())}&kind=${kind}`);
    if (my === seq.current) setCases(r.cases);
  });
  const generate = () => guard('gen', async () => {
    if (!keyword.trim()) { setLine({ tone: 'err', text: '찾을 테마(예: 얼룩, 수선)를 입력해 주세요.' }); return; }
    if (dirty && body.trim() && !window.confirm('사례 글로 지금 글을 바꿀까요?')) return;
    const my = seq.current; const token = editToken.current; const kw = keyword.trim();
    const r = await noticeApi<{ body: string; caseId?: string; found: boolean }>('POST', '/generate-case', { orderId, keyword: kw, kind });
    if (my !== seq.current) return;
    if (!r.found) { setLine({ tone: 'warn', text: '저장된 사례 중 근거가 되는 글이 없습니다. 직접 작성해 주세요.' }); return; }
    if (applyAsyncBody(my, token, r.body, kw)) setLine({ tone: 'info', text: '저장된 사례를 바탕으로 글을 채웠습니다. 꼭 읽어 보고 고쳐 주세요.' });
  });
  const useCase = (c: NoticeCase) => guard('case-use', async () => {
    if (dirty && body.trim() && !window.confirm('이 사례 글로 바꿀까요?')) return;
    const my = seq.current; const token = editToken.current;
    const r = await noticeApi<{ body: string; caseId?: string; found: boolean }>('POST', '/generate-case', { orderId, keyword: c.theme, caseId: c.id, kind });
    if (my !== seq.current) return;
    if (!r.found) { setLine({ tone: 'warn', text: '이 사례를 이 주문에 맞게 바꾸지 못했습니다. 직접 작성해 주세요.' }); return; }
    if (applyAsyncBody(my, token, r.body, c.theme)) setLine({ tone: 'info', text: '사례 글을 이 고객에 맞게 채웠습니다. 꼭 읽어 보고 고쳐 주세요.' });
  });
  const saveCase = () => guard('case', async () => {
    if (!theme.trim()) { setLine({ tone: 'err', text: '사례로 저장할 테마 이름을 입력해 주세요.' }); return; }
    const n = await save(); if (!n) return;
    await noticeApi('POST', '/cases', { noticeId: n.id, theme: theme.trim() });
    setLine({ tone: 'ok', text: '사례로 저장했습니다. 고객 이름은 서버에서 지워집니다.' });
  });

  const openRaw = () => {
    const t = curTpl; if (!t) return;
    setRawFor({ id: t.id, revision: t.revision }); setRawText(t.text); setRawLine(null);
  };
  const saveRaw = () => guard('raw', async () => {
    if (!rawFor) return;
    if (!rawText.trim()) { setRawLine({ tone: 'err', text: '기본 문구가 비어 있습니다.' }); return; }
    const my = seq.current;
    const r = await noticeApi<{ template: NoticeTemplate }>('PUT', `/templates/${encodeURIComponent(rawFor.id)}`, { text: rawText, revision: rawFor.revision })
      .catch((e) => { setRawLine({ tone: 'err', text: `저장 실패: ${errText(e)} 다른 곳에서 바뀌었다면 닫았다가 다시 열어 주세요.` }); return null; });
    if (!r || my !== seq.current) return;
    setTemplates((list) => list.map((t) => (t.id === r.template.id ? r.template : t)));
    setRawFor({ id: r.template.id, revision: r.template.revision });
    setRawLine({ tone: 'ok', text: '기본 문구를 저장했습니다. 지금 쓰고 있는 고객 글은 바뀌지 않았습니다. 새 문구를 쓰려면 위 템플릿 버튼을 다시 눌러 주세요.' });
  });
  const before = templates.filter((t) => t.stage === 'before');
  const advert = templates.filter((t) => t.stage === 'advert');
  const after = templates.filter((t) => t.stage === 'after');
  const tplGroup = (title: string, list: NoticeTemplate[]) => (
    <div><h4 style={{ margin: '8px 0', fontSize: 18 }}>{title}</h4>
      <div className="nc-tpls">{list.map((t) => (
        <button key={t.id} type="button" className="nc-tpl" aria-pressed={templateId === t.id} onClick={() => pickTemplate(t)} aria-label={`${title} 안내문: ${t.title}`}>{t.title}</button>
      ))}</div></div>
  );
  const anyBusy = !!busy;

  return (
    <Modal title="고객 메시지 편집" sub={ctx ? `${ctx.customerName} 고객 · 주문 ${ctx.orderId}` : `주문 ${orderId}`} onClose={onClose}>
      {loadErr && <Msg tone="err">불러오기 실패: {loadErr}</Msg>}
      {!ctx && !loadErr && <Msg tone="info">주문 정보를 불러오는 중입니다…</Msg>}
      {ctx && (
        <div className="nc-layout">
          <div>
            <section className="nc-section"><h3>안내문 종류 고르기</h3>{tplGroup('세탁 전', before)}{tplGroup('세탁 후', after)}</section>
            {advert.length > 0 && <section className="nc-section nc-advert"><h3>광고 메시지</h3>{tplGroup('광고', advert)}<p className="nc-hint">광고는 수신 동의한 고객에게만, 글 맨 앞 (광고) 표기와 수신거부 방법을 넣어 보내야 합니다.</p></section>}
            {curTpl && (
              <details className="nc-raw" onToggle={(e) => { if ((e.currentTarget as HTMLDetailsElement).open && rawFor?.id !== curTpl.id) openRaw(); }}>
                <summary>“{curTpl.title}” 기본 문구 고치기 (모든 고객에게 쓰는 원본)</summary>
                {rawFor && rawFor.id !== curTpl.id ? (
                  <div className="nc-row"><button type="button" className="nc-big ghost" onClick={openRaw} aria-label="선택한 템플릿 기본 문구 불러오기"><RefreshCw aria-hidden />선택한 템플릿 원본 불러오기</button></div>
                ) : (<>
                  <p className="nc-hint">여기는 고객 한 명에게 보내는 글이 아니라 원본 틀입니다. 이름·금액을 직접 쓰지 말고 아래 자리표시자를 넣으세요. 보낼 때 주문 정보로 자동으로 바뀝니다.</p>
                  <div className="nc-chips">{PLACEHOLDERS.map((ph) => <code key={ph}>{ph}</code>)}</div>
                  <label className="nc-label" htmlFor="nc-raw">기본 문구 원본</label>
                  <textarea id="nc-raw" lang="ko" className="nc-input nc-body" value={rawText} onChange={(e) => setRawText(e.target.value)} aria-label={`${curTpl.title} 기본 문구 원본`} />
                  <div className="nc-row"><button type="button" className="nc-big gold" disabled={anyBusy || !rawFor} onClick={saveRaw} aria-label="기본 문구로 저장">{busy === 'raw' ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}기본 문구로 저장</button></div>
                  {rawLine && <Msg tone={rawLine.tone}>{rawLine.text}</Msg>}
                </>)}
              </details>
            )}
            {staleSelected && <Msg tone="warn">휴대폰에서 이 글의 새 버전이 저장되었습니다. 지금 쓰는 글은 그대로 두었습니다. 오른쪽 목록에서 불러올 수 있습니다.</Msg>}
            <label className="nc-label" htmlFor="nc-body">보낼 글 (자유롭게 고치세요)</label>
            <textarea id="nc-body" lang="ko" className="nc-input nc-body" value={body} onChange={(e) => editBody(e.target.value)} aria-label="고객에게 보낼 글" />
            {isAdvert && (
              <label className="nc-check nc-consent" style={{ marginTop: 14 }}>
                <input type="checkbox" checked={advertOk} onChange={(e) => setAdvertOk(e.target.checked)} aria-label="광고 수신 동의와 수신거부 안내 확인" required />
                <span>(필수) 이 고객의 광고 수신 동의를 확인했고, 글 맨 앞 (광고) 표기와 수신거부 방법 안내를 넣었습니다</span>
              </label>
            )}
            <label className="nc-check" style={{ marginTop: 14 }}>
              <input type="checkbox" checked={review} onChange={(e) => toggleReview(e.target.checked)} aria-label="영수증 리뷰 작성 확인" />영수증 리뷰 작성 확인함 (확인해야 리뷰할인 적용)
            </label>
            <section className="nc-section" aria-label="보내기 전 검토">
              <h3>보내기 전 검토</h3>
              <div className="nc-quote">
                <span>받는 분</span><strong>{ctx.customerName} · {ctx.customerPhone}</strong>
                {quote && <><span>금액</span><strong>{won(quote.subtotal)}</strong>
                  <span>할인 ({quote.rate}%)</span><strong>-{won(quote.discount)}</strong>
                  <span>리뷰 할인</span><strong>-{won(quote.reviewDiscount)}</strong>
                  <span>최종 금액</span><strong style={{ color: '#e8c76d' }}>{won(quote.total)}</strong></>}
              </div>
            </section>
            <div className="nc-row">
              <div className="nc-toggle" role="group" aria-label="보내기 방식">
                <button type="button" aria-pressed={mode === 'confirm'} disabled={anyBusy} onClick={() => setMode('confirm')} aria-label="확인 후 보내기 방식">확인 후 보내기</button>
                <button type="button" aria-pressed={mode === 'immediate'} disabled={anyBusy} onClick={() => setMode('immediate')} aria-label="즉시 보내기 방식">즉시 보내기</button>
              </div>
              <button type="button" className="nc-big gold" disabled={anyBusy} onClick={onSendClick} aria-label="저장하고 보내기">
                {busy === 'send' ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}{busy === 'send' ? '처리 중…' : '저장하고 보내기'}
              </button>
              <button type="button" className="nc-big" disabled={anyBusy} onClick={onSave} aria-label="글 저장만 하기">
                {busy === 'save' ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}저장만
              </button>
            </div>
            {confirmOpen && (
              <div className="nc-confirm-box" style={{ marginTop: 14 }} role="alertdialog" aria-label="즉시 전송 확인">
                <strong style={{ fontSize: 20 }}>정말 바로 보낼까요?</strong>
                <div>받는 번호: <strong>{ctx.customerPhone}</strong></div>
                <pre>{body}</pre>
                <div className="nc-row">
                  <button type="button" className="nc-big danger" disabled={anyBusy} onClick={doSend} aria-label="즉시 전송 확인">네, 바로 보냅니다</button>
                  <button type="button" className="nc-big ghost" onClick={() => setConfirmOpen(false)} aria-label="즉시 전송 취소">취소</button>
                </div>
              </div>
            )}
            {line && <Msg tone={line.tone}>{line.text}</Msg>}
            {attemptId && (
              <div className="nc-row">
                <button type="button" className="nc-big" disabled={anyBusy} onClick={confirmSent} aria-label="외부 앱에서 실제로 보낸 것을 확인했습니다">
                  <CheckCircle2 aria-hidden />외부 앱에서 실제로 보냈음 (기록하기)
                </button>
              </div>
            )}
          </div>
          <div>
            <section className="nc-section"><h3>저장된 글</h3>
              {notices.length === 0 ? <p style={{ margin: 0 }}>아직 저장된 글이 없습니다.</p> : (
                <ul className="nc-list">{notices.map((n) => (
                  <li key={n.id}><button type="button" aria-pressed={selected?.id === n.id} onClick={() => pickNotice(n)} aria-label={`${n.source === 'mobile' ? '휴대폰' : '직원'} 작성 글 불러오기`}>
                    {n.body.slice(0, 40)}{n.body.length > 40 ? '…' : ''}
                    <small>{n.source === 'mobile' ? '휴대폰 작성' : '직원 작성'} · {n.revision}번째 수정 · {new Date(n.updatedAt).toLocaleString('ko-KR')}</small>
                  </button></li>))}</ul>)}
            </section>
            <section className="nc-section"><h3>휴대폰으로 쓰기</h3>
              {mobile ? (<>
                <div className="nc-qr"><QrCanvas url={mobile.url} /></div>
                <p style={{ margin: '8px 0 0' }}>휴대폰으로 찍어 글을 쓰세요. {new Date(mobile.expiresAt).toLocaleTimeString('ko-KR')}까지 유효. 새 글은 위 목록에만 나타납니다.</p>
                {pollErr && <Msg tone="err">{pollErr}</Msg>}
                <div className="nc-row"><button type="button" className="nc-big ghost" onClick={() => setMobile(null)} aria-label="휴대폰 쓰기 연결 끝내기">연결 끝내기</button></div>
              </>) : (
                <button type="button" className="nc-big" disabled={anyBusy} onClick={startMobile} aria-label="휴대폰으로 쓰기 QR 만들기"><QrCode aria-hidden />QR 만들기</button>)}
            </section>
            <section className="nc-section"><h3>비슷한 사례 찾기 ({kind === 'advert' ? '광고' : kind === 'after' ? '세탁 후' : '세탁 전'})</h3>
              <p className="nc-hint">이 매장에 저장해 둔 사례로만 글을 만듭니다. 외부 AI나 인터넷에 보내지 않습니다.</p>
              <label className="nc-label" htmlFor="nc-kw">테마 (예: 얼룩, 수선)</label>
              <input id="nc-kw" lang="ko" className="nc-input" value={keyword} onChange={(e) => setKeyword(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.nativeEvent.isComposing) void searchCases(); }} />
              <div className="nc-row">
                <button type="button" className="nc-big" disabled={anyBusy} onClick={searchCases} aria-label="사례 검색"><Search aria-hidden />검색</button>
                <button type="button" className="nc-big" disabled={anyBusy} onClick={generate} aria-label="매장에 저장된 사례로 글 만들기"><Sparkles aria-hidden />저장 사례로 글 만들기</button>
              </div>
              {cases && (cases.length === 0 ? <p>찾은 사례가 없습니다.</p> : (
                <ul className="nc-list" style={{ marginTop: 12 }}>{cases.map((c) => (
                  <li key={c.id}><button type="button" disabled={anyBusy} onClick={() => void useCase(c)} aria-label={`${c.theme} 사례 글 사용`}>
                    {c.theme}<small>{c.body.slice(0, 50)}</small></button></li>))}</ul>))}
              <label className="nc-label" htmlFor="nc-theme">이 글의 테마 이름 (보내기 전 필수)</label>
              <input id="nc-theme" ref={themeRef} required aria-required="true" lang="ko" className="nc-input" value={theme} onChange={(e) => { setTheme(e.target.value); setDirty(true); }} />
              <div className="nc-row"><button type="button" className="nc-big" disabled={anyBusy} onClick={saveCase} aria-label="이 글을 사례로 저장"><Save aria-hidden />사례로 저장</button></div>
            </section>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ---------------- 진입점 ---------------- */
export function MessagingToolbar(): JSX.Element {
  const [open, setOpen] = useState<'connect' | 'settings' | null>(null);
  const [notice, setNotice] = useState<{ orderId: string; templateId?: string; key: number } | null>(null);
  useEffect(() => {
    const h = (e: Event) => {
      const d = (e as CustomEvent<{ orderId?: string; templateId?: string }>).detail;
      if (d?.orderId) setNotice({ orderId: d.orderId, templateId: d.templateId, key: Date.now() });
    };
    window.addEventListener(OPEN_CUSTOMER_NOTICE, h);
    return () => window.removeEventListener(OPEN_CUSTOMER_NOTICE, h);
  }, []);
  return (
    <>
      <div className="nc-toolbar">
        <button type="button" className="nc-big" onClick={() => setOpen('connect')} aria-label="휴대폰·카톡 연결하기"><Smartphone aria-hidden />휴대폰·카톡 연결하기</button>
        <button type="button" className="nc-big" onClick={() => setOpen('settings')} aria-label="매장 맞춤 설정"><Settings aria-hidden />매장 맞춤 설정</button>
      </div>
      {open === 'connect' && <ConnectHelper onClose={() => setOpen(null)} />}
      {open === 'settings' && <StoreSettings onClose={() => setOpen(null)} />}
      {notice && <NoticeEditor key={notice.key} orderId={notice.orderId} initialTemplateId={notice.templateId} onClose={() => setNotice(null)} />}
    </>
  );
}

export default MessagingToolbar;
