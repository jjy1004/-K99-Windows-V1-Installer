import { useCallback, useEffect, useLayoutEffect, useRef, useState, type JSX, type KeyboardEvent, type ReactNode } from 'react';
import {createPortal} from 'react-dom';
import bwipjs from 'bwip-js/browser';
import {
  AlertTriangle, CheckCircle2, Info, Loader2, MessageCircle, Send, Settings, Smartphone, X, Save, QrCode, RefreshCw,
} from 'lucide-react';
import {
  messenger, noticeApi, OPEN_CUSTOMER_NOTICE,
  type CustomerNotice as BaseNotice, type MessengerResult, type NoticeContext, type NoticeTemplate as BaseTemplate, type StoreProfile,
} from './notice-api';

// 서버 확장 필드(광고 단계·템플릿 revision·광고 동의)를 이 파일 안에서만 보강
type Stage = 'before' | 'after' | 'advert';
type NoticeTemplate = Omit<BaseTemplate, 'stage'> & { stage: Stage; revision: number };
type CustomerNotice = BaseNotice & { advertConsentConfirmed?: boolean };
import './notice-center.css';
import { AccountlessNoticeActions } from './LocalNoticeDialogs';
import { SpecialNoteHost } from './CustomerSpecialNote';
import { appendMobileNotice } from './notice-text';
import { CustomerPrivacySettings } from './CustomerPrivacySettings';

type Tone = 'info' | 'ok' | 'warn' | 'err';
const won = (n: number) => `${Math.round(n).toLocaleString('ko-KR')}원`;
const errText = (e: unknown) => (e instanceof Error ? e.message : '알 수 없는 오류가 발생했습니다.');

function Msg({ tone, children }: { tone: Tone; children: ReactNode }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle;
  return <div className={`nc-msg ${tone}`} role={tone === 'err' ? 'alert' : 'status'}><Icon size={22} aria-hidden /> <div>{children}</div></div>;
}

function QrCanvas({ url }: { url: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    if (!ref.current || !url) return;
    try { bwipjs.toCanvas(ref.current, { bcid: 'qrcode', text: url, scale: 5, padding: 4, backgroundcolor: 'FFFFFF' }); setErr(false); }
    catch { setErr(true); }
  }, [url]);
  return err ? <Msg tone="err">QR을 만들지 못했습니다. 연결 끝내기 후 다시 만들어 주세요.</Msg>
    : <canvas ref={ref} role="img" aria-label="휴대폰으로 글쓰기 연결 QR 코드" style={{ display: 'block', maxWidth: '100%' }} />;
}

function Modal({ title, sub, onClose, narrow, children }: { title: string; sub?: string; onClose: () => void; narrow?: boolean; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous=document.activeElement as HTMLElement|null;
    ref.current?.focus();
    return()=>{if(previous?.isConnected)previous.focus();};
  }, []);
  const onKey = (e: KeyboardEvent) => {
    // 접수 화면 전역 단축키와 격리
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) onClose();
    if(e.key==='Tab'){
      const focusable=Array.from(ref.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]')||[])
        .filter(el=>el.getClientRects().length>0);
      const first=focusable[0],last=focusable.at(-1);
      if(!first){e.preventDefault();ref.current?.focus();}
      else if(e.shiftKey&&(document.activeElement===first||document.activeElement===ref.current)){e.preventDefault();last?.focus();}
      else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===ref.current)){e.preventDefault();first.focus();}
    }
  };
  return createPortal(
    <div className="nc-backdrop" data-notice-modal="true" onKeyDown={onKey} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} tabIndex={-1} className={`nc-modal${narrow ? ' narrow' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="nc-head">
          <div><h2>{title}</h2>{sub && <p>{sub}</p>}</div>
          <button type="button" className="nc-close" onClick={onClose} aria-label={`${title} 닫기`}><X size={22} aria-hidden />닫기</button>
        </div>
        {children}
      </div>
    </div>,document.body
  );
}

function resultLine(r: MessengerResult): { tone: Tone; text: string } {
  if (!r.success) return { tone: 'err', text: r.error || r.detail || '확인 필요: 프로그램을 열지 못했습니다.' };
  switch (r.status) {
    case 'prepared': return { tone: 'warn', text: '자동입력됨 — 외부 앱 화면에서 직원이 내용을 확인한 뒤 직접 보내기를 눌러 주세요.' };
    case 'send_requested': return { tone: 'warn', text: '전송요청됨 — 고객에게 도착했는지는 아직 확인되지 않았습니다.' };
    case 'opened': return { tone: 'info', text: '열기 요청을 보냈습니다. 화면에서 직접 확인해 주세요.' };
    default: return { tone: 'warn', text: `확인 필요${r.detail ? ` — ${r.detail}` : ''}` };
  }
}

/* ---------------- 연결 도우미 ---------------- */
function ConnectHelper({ onClose }: { onClose: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [phone, setPhone] = useState('');
  const [watchPhone, setWatchPhone] = useState(false);
  const [testGuide, setTestGuide] = useState(false);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!watchPhone || !window.k99Desktop?.messenger) return;
    let live=true;
    let timer:ReturnType<typeof setTimeout>;
    const check=async()=>{
      try{
        const r=await messenger({action:'phone-status'});
        if(live&&r.connected===true&&r.verified===true){closeRef.current();return;}
      }catch{/* Status unavailable never blocks receipt or pretends success. */}
      if(live)timer=setTimeout(check,5000);
    };
    timer=setTimeout(check,1500);
    return()=>{live=false;clearTimeout(timer);};
  },[watchPhone]);
  const [profile, setProfile] = useState<{ profile: StoreProfile; revision: number } | null>(null);
  useEffect(() => {
    let live = true;
    noticeApi<{ profile: StoreProfile; revision: number }>('GET', '/profile')
      .then((p) => { if (live) { setProfile(p); setPhone(p.profile.ownerPhone || ''); } })
      .catch((e) => live && setLine({ tone: 'err', text: errText(e) }));
    return () => { live = false; };
  }, []);
  const run = async (key: string, fn: () => Promise<MessengerResult>) => {
    if (busy) return; setBusy(key); setLine(null); setTestGuide(false);
    try {
      const r = await fn();
      if (r.success && key==='phone') setWatchPhone(true);
      if (r.success && key==='test' && r.channel==='sms') setTestGuide(true);
      setLine(r.success ? { tone: 'info', text: `${key === 'test' ? '테스트 문자 열기' : '연결 화면 열기'} 요청을 보냈습니다. 실제 연결·도착 여부는 휴대폰에서 직접 확인해 주세요.${r.detail ? ` (${r.detail})` : ''}` } : resultLine(r));
    } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { setBusy(null); }
  };
  const test = async (channel:'sms'|'kakao'='sms') => {
    const p = phone.trim();
    if (!/^[0-9-]{9,14}$/.test(p)) { setLine({ tone: 'err', text: '본인 휴대폰 번호를 숫자로 정확히 입력해 주세요.' }); return; }
    if (profile && profile.profile.ownerPhone !== p) {
      try {
        const saved = await noticeApi<{ profile: StoreProfile; revision: number }>('PUT', '/profile', { profile: { ...profile.profile, ownerPhone: p }, revision: profile.revision });
        setProfile(saved);
      } catch (e) { setLine({ tone: 'err', text: `본인번호 저장 실패: ${errText(e)}` }); return; }
    }
    await run('test', () => messenger({ action: 'test', phone: p,channel }));
  };
  return (
    <Modal title="휴대폰·카톡 연결하기" sub="PC에서 휴대폰 문자와 카카오톡을 열 수 있게 준비합니다." onClose={onClose}>
      <div className="nc-row">
        <button type="button" className="nc-big gold" disabled={!!busy} onClick={() => run('phone', () => messenger({ action: 'phone' }))} aria-label="휴대폰 문자 연결 화면 열기">
          {busy === 'phone' ? <Loader2 className="animate-spin" aria-hidden /> : <Smartphone aria-hidden />}휴대폰 연결 열기
        </button>
        <button type="button" className="nc-big gold" disabled={!!busy} onClick={() => run('kakao', () => messenger({ action: 'kakao' }))} aria-label="PC 카카오톡 열기">
          {busy === 'kakao' ? <Loader2 className="animate-spin" aria-hidden /> : <MessageCircle aria-hidden />}카카오톡 열기
        </button>
      </div>
      <section className="nc-section" aria-label="연결 3단계 안내">
        <p style={{fontSize:20,fontWeight:700}}>※ 선택 창이 뜨면 반드시 [휴대폰과 연결] 선택 후 [항상]을 클릭하세요.</p>
        <h3>이렇게 따라 하세요</h3>
        <div className="nc-steps">
          <div className="nc-step"><b>1</b><strong>휴대폰 연결 열기</strong><span>위의 [휴대폰 연결 열기] 버튼을 누릅니다.</span></div>
          <div className="nc-step"><b>2</b><strong>Windows와 연결 켜기</strong><span>스마트폰 빠른 설정창에서 [Windows와 연결]을 켜고 최초 연결 안내를 따르세요.</span></div>
          <div className="nc-step"><b>3</b><strong>연결 확인 후 닫기</strong><span>PC에 [연결됨]이 표시되는지 확인하세요. 자동 확인되면 이 창이 닫힙니다. 감지가 안 되면 직접 닫아도 됩니다.</span></div>
        </div>
      </section>
      {testGuide&&<section className="nc-section" aria-label="테스트 문자 3단계 시각 가이드" style={{border:'3px solid #dc2626',fontSize:20}}>
        <h3>열린 ‘휴대폰과 연결’ 화면에서 따라 하세요</h3>
        <div className="nc-steps">
          <div className="nc-step" style={{border:'2px solid #dc2626'}}><b>1</b><strong>↖ 좌측 상단 · 연결 상태</strong><span>녹색 불빛과 [연결됨] 표시를 확인하세요. 앱이 열린 것만으로 연결된 것은 아닙니다.</span></div>
          <div className="nc-step" style={{border:'2px solid #dc2626'}}><b>2</b><strong>↘ 우측 하단 · 받는 번호와 글</strong><span>본인 번호와 테스트 문구가 입력되어 있는지 확인하세요. 글이 비어 있으면 Ctrl+V로 붙여넣으세요.</span></div>
          <div className="nc-step" style={{border:'2px solid #dc2626'}}><b>3</b><strong>→ 입력창 오른쪽 · 보내기</strong><span>종이비행기 모양 [보내기]를 누르면 실제 문자가 전송됩니다. 번호를 먼저 확인하세요.</span></div>
        </div>
        <p>Windows 앱 버전에 따라 위치가 다를 수 있습니다. 이 그림 안내는 외부 앱 위에 겹쳐 표시되는 화면이 아닙니다.</p>
      </section>}
      <section className="nc-section">
        <h3>내 번호로 시험해 보기</h3>
        <label className="nc-label" htmlFor="nc-owner-phone">본인 휴대폰 번호</label>
        <input id="nc-owner-phone" className="nc-input" lang="ko" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="010-0000-0000" aria-label="본인 휴대폰 번호" />
        <div className="nc-row">
          <button type="button" className="nc-big" disabled={!!busy} onClick={()=>test('sms')} aria-label="본인 번호로 테스트 문자 열기">
            {busy === 'test' ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}테스트 문자 열기
          </button>
          <button type="button" className="nc-big gold" disabled={!!busy} onClick={()=>test('kakao')}>카톡 연결 상태 확인 테스트</button>
        </div>
      </section>
      {line && <Msg tone={line.tone}>{line.text}</Msg>}
    </Modal>
  );
}

/* ---------------- 매장 설정 ---------------- */
const DISCOUNT_FIELDS: [keyof StoreProfile['discounts'], string][] = [
  ['firstThreshold', '1단계 할인 기준금액(원)'], ['firstRate', '1단계 할인율(%)'],
  ['secondThreshold', '2단계 할인 기준금액(원)'], ['secondRate', '2단계 할인율(%)'],
  ['reviewThreshold', '리뷰할인 기준금액(원)'], ['reviewDiscount', '리뷰 할인액(원)'],
];
function StoreSettings({ onClose }: { onClose: () => void }) {
  const [rev, setRev] = useState<number | null>(null);
  const [p, setP] = useState<StoreProfile | null>(null);
  const [staffText, setStaffText] = useState('');
  const [nums, setNums] = useState<Record<string, string>>({});
  const [loadErr, setLoadErr] = useState('');
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const apply = (r: { profile: StoreProfile; revision: number }) => {
    setP(r.profile); setRev(r.revision); setStaffText(r.profile.staff.join('\n'));
    setNums(Object.fromEntries(DISCOUNT_FIELDS.map(([k]) => [k, String(r.profile.discounts[k] ?? 0)])));
  };
  const load = useCallback(() => {
    setLoadErr('');
    noticeApi<{ profile: StoreProfile; revision: number }>('GET', '/profile').then(apply).catch((e) => setLoadErr(errText(e)));
  }, []);
  useEffect(load, [load]);
  const save = async () => {
    if (!p || rev === null || saving) return;
    const discounts = {} as StoreProfile['discounts'];
    for (const [k, label] of DISCOUNT_FIELDS) {
      const n = Number(nums[k]);
      if (!Number.isFinite(n) || n < 0) { setLine({ tone: 'err', text: `${label}에 0 이상의 숫자를 넣어 주세요.` }); return; }
      discounts[k] = n;
    }
    const staff = staffText.split('\n').map((s) => s.trim()).filter(Boolean);
    setSaving(true); setLine(null);
    try {
      const r = await noticeApi<{ profile: StoreProfile; revision: number }>('PUT', '/profile', { profile: { ...p, staff, discounts }, revision: rev });
      apply(r); setLine({ tone: 'ok', text: '저장되었습니다.' });
    } catch (e) { setLine({ tone: 'err', text: `저장 실패: ${errText(e)} 다른 곳에서 바뀌었다면 “다시 불러오기” 후 수정해 주세요.` }); }
    finally { setSaving(false); }
  };
  return (
    <Modal title="매장 맞춤 설정" sub="고객 안내문에 들어갈 매장 정보와 할인 기준입니다." onClose={onClose}>
      {loadErr && <Msg tone="err">{loadErr} <button type="button" className="nc-close" onClick={load}><RefreshCw size={18} aria-hidden />다시 시도</button></Msg>}
      {!p && !loadErr && <Msg tone="info">불러오는 중입니다…</Msg>}
      {p && (
        <>
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-store">매장명</label>
              <input id="nc-store" lang="ko" className="nc-input" value={p.storeName} onChange={(e) => setP({ ...p, storeName: e.target.value })} /></div>
            <div><label className="nc-label" htmlFor="nc-owner">본인 휴대폰 번호</label>
              <input id="nc-owner" lang="ko" inputMode="tel" className="nc-input" value={p.ownerPhone} onChange={(e) => setP({ ...p, ownerPhone: e.target.value })} /></div>
          </div>
          <label className="nc-label" htmlFor="nc-intro">매장 소개글</label>
          <textarea id="nc-intro" lang="ko" className="nc-input" value={p.introduction} onChange={(e) => setP({ ...p, introduction: e.target.value })} />
          <label className="nc-label" htmlFor="nc-bank">입금 계좌 안내 (은행 · 계좌번호 · 예금주)</label>
          <input id="nc-bank" className="nc-input" maxLength={300} value={p.bankAccount ?? ''} onChange={(e) => setP({ ...p, bankAccount: e.target.value })} />
          <p className="nc-hint">등록한 계좌는 고객 안내문에 자동으로 들어갑니다. 실제 매장 계좌를 확인해 입력해 주세요.</p>
          <div className="nc-grid2">
            <div><label className="nc-label" htmlFor="nc-staff">직원 목록 (한 줄에 한 명)</label>
              <textarea id="nc-staff" lang="ko" className="nc-input" value={staffText} onChange={(e) => setStaffText(e.target.value)} /></div>
            <div><label className="nc-label" htmlFor="nc-default-staff">기본 담당자</label>
              <select id="nc-default-staff" className="nc-input" value={p.defaultStaff} onChange={(e) => setP({ ...p, defaultStaff: e.target.value })}>
                <option value="">선택 안 함</option>
                {staffText.split('\n').map((s) => s.trim()).filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
              </select></div>
          </div>
          <section className="nc-section"><h3>할인 정책</h3>
            <div className="nc-grid3">
              {DISCOUNT_FIELDS.map(([k, label]) => (
                <div key={k}><label className="nc-label" htmlFor={`nc-d-${k}`}>{label}</label>
                  <input id={`nc-d-${k}`} className="nc-input" inputMode="numeric" lang="ko" value={nums[k] ?? ''} onChange={(e) => setNums({ ...nums, [k]: e.target.value })} /></div>
              ))}
            </div>
            <Msg tone="info">기준금액 또는 할인율·할인액을 0으로 두면 그 할인은 꺼집니다. 1단계·2단계 할인이 둘 다 켜져 있을 때만 기준금액 순서를 서버가 확인합니다.</Msg>
          </section>
          <CustomerPrivacySettings />
          <div className="nc-row">
            <button type="button" className="nc-big gold" disabled={saving} onClick={save} aria-label="매장 설정 저장하기">{saving ? <Loader2 className="animate-spin" aria-hidden /> : <Save aria-hidden />}저장하기</button>
            <button type="button" className="nc-big ghost" disabled={saving} onClick={load} aria-label="매장 설정 다시 불러오기"><RefreshCw aria-hidden />다시 불러오기</button>
          </div>
        </>
      )}
      {line && <Msg tone={line.tone}>{line.text}</Msg>}
    </Modal>
  );
}

/* ---------------- 고객 메시지 편집 ---------------- */
function NoticeEditor({ orderId, initialTemplateId, onClose }: { orderId: string; initialTemplateId?: string; onClose: () => void }) {
  const seq = useRef(0);
  const [loadErr, setLoadErr] = useState('');
  const [templates, setTemplates] = useState<NoticeTemplate[]>([]);
  const [ctx, setCtx] = useState<NoticeContext | null>(null);
  const [notices, setNotices] = useState<CustomerNotice[]>([]);
  const [selected, setSelected] = useState<{ id: string; revision: number } | null>(null);
  const [templateId, setTemplateId] = useState('');
  const [stageView,setStageView]=useState<'before'|'after'>(initialTemplateId?.startsWith('after-')?'after':'before');
  const [body, setBody] = useState('');
  const [theme, setTheme] = useState('');
  const [dirty, setDirty] = useState(false);
  const [review, setReview] = useState(false);
  const [line, setLine] = useState<{ tone: Tone; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [mobile, setMobile] = useState<{ url: string; expiresAt: string } | null>(null);
  const [pollErr, setPollErr] = useState('');
  const busyRef = useRef(false);
  const editToken = useRef(0);
  const bodyRef=useRef(''),cursorRef=useRef<number|null>(null),composing=useRef(false);
  const bodyInput=useRef<HTMLTextAreaElement>(null),pendingCursor=useRef<number|null>(null);
  useLayoutEffect(()=>{
    if(pendingCursor.current!==null&&document.activeElement===bodyInput.current)
      bodyInput.current?.setSelectionRange(pendingCursor.current,pendingCursor.current);
    pendingCursor.current=null;
  },[body]);
  const seenMobile=useRef(new Map<string,number>());
  const previewSeq=useRef(0),previewPending=useRef(false);
  const [previewBusy,setPreviewBusy]=useState(false);
  const editBody = (v: string) => { editToken.current++;bodyRef.current=v;setBody(v); setDirty(true); };
  // 비동기 결과로 본문 교체: 요청 이후 직원이 손댔거나 주문이 바뀌었으면 버림
  const applyAsyncBody = (my: number, token: number, v: string) => {
    if (my !== seq.current || token !== editToken.current) { setLine({ tone: 'warn', text: '그 사이 글을 고치셔서 불러온 글은 적용하지 않았습니다. 필요하면 다시 눌러 주세요.' }); return false; }
    editToken.current++;bodyRef.current=v;setBody(v);cursorRef.current=null;
    setDirty(false); setSelected(null); return true;
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const runPreview = useCallback(async (tid: string, rc: boolean, replaceBody: boolean) => {
    const my = seq.current,request=++previewSeq.current; const token = editToken.current;
    previewPending.current=true;setPreviewBusy(true);
    try {
      const r = await noticeApi<{ body: string }>('POST', '/preview', { orderId, templateId: tid, reviewConfirmed: rc });
      if (my !== seq.current||request!==previewSeq.current) return;
      if (replaceBody) applyAsyncBody(my, token, r.body);
    } catch (e) { if (my === seq.current&&request===previewSeq.current) setLine({ tone: 'err', text: `미리보기 실패: ${errText(e)}` }); }
    finally{if(my===seq.current&&request===previewSeq.current){previewPending.current=false;setPreviewBusy(false);}}
  }, [orderId]);

  // 처음 / 다른 주문: 오래된 응답 무시
  useEffect(() => {
    const my = ++seq.current;
    setLoadErr(''); setCtx(null); setNotices([]); setSelected(null); setBody(''); setTheme(''); setDirty(false);
    bodyRef.current='';cursorRef.current=null;seenMobile.current.clear();
    setLine(null);setMobile(null); setReview(false);
    (async () => {
      try {
        const [t, c, d] = await Promise.all([
          noticeApi<{ templates: NoticeTemplate[] }>('GET', '/templates'),
          noticeApi<{ context: NoticeContext }>('GET', `/context?orderId=${encodeURIComponent(orderId)}`),
          noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`),
        ]);
        if (my !== seq.current) return;
        const available=t.templates.filter(x=>x.stage!=='advert');
        setTemplates(available); setCtx(c.context); setNotices(d.notices);setReview(c.context.reviewConfirmed===true);
        d.notices.filter(n=>n.source==='mobile').forEach(n=>seenMobile.current.set(n.id,n.revision));
        const first = available.find((x) => x.stage === 'before') ?? available[0];
        const tid = initialTemplateId && available.some((x) => x.id === initialTemplateId) ? initialTemplateId : first?.id ?? '';
        if (tid) {setTheme(available.find(t=>t.id===tid)?.title||'고객 안내');setTemplateId(tid); await runPreview(tid, c.context.reviewConfirmed===true, true); }
      } catch (e) { if (my === seq.current) setLoadErr(errText(e)); }
    })();
    return () => { seq.current++; };
  }, [orderId, initialTemplateId, runPreview]);

  // 촬영 QR에서 들어온 글도 수신한다. 편집창 자체 QR을 켰는지와 무관하게
  // 유효한 주문의 목록만 3초마다 갱신하고 작성 중 본문은 덮어쓰지 않는다.
  useEffect(() => {
    if (ctx?.orderId !== orderId) return;
    const my = seq.current; let inflight = false;
    const id = window.setInterval(async () => {
      if (inflight) return; inflight = true;
      try {
        const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
        if (my === seq.current) {
          setNotices(d.notices);setPollErr('');
          const incoming=d.notices.filter(n=>n.source==='mobile'&&seenMobile.current.get(n.id)!==n.revision)
            .sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)||a.id.localeCompare(b.id));
          if(incoming.length&&!composing.current&&!busyRef.current&&!previewPending.current){
            const next=appendMobileNotice(bodyRef.current,incoming.map(n=>n.body).join('\n\n'),cursorRef.current);
            pendingCursor.current=next.cursor;editBody(next.body);cursorRef.current=next.cursor;
            incoming.forEach(n=>seenMobile.current.set(n.id,n.revision));
            setLine({tone:'info',text:'휴대폰에서 보낸 글을 보낼 글에 추가했습니다. 기존 글은 지우지 않았습니다.'});
          }
        }
      } catch (e) { if (my === seq.current) setPollErr(`휴대폰 메시지 확인 실패: ${errText(e)}`); }
      finally { inflight = false; }
    }, 3000);
    return () => window.clearInterval(id);
  }, [ctx?.orderId, orderId]);

  const latestOfSelected = selected ? notices.find((n) => n.id === selected.id) : undefined;
  const staleSelected = !!(selected && latestOfSelected && latestOfSelected.revision > selected.revision);

  const pickTemplate = (t: NoticeTemplate) => {
    if(busyRef.current)return;
    editToken.current++;bodyRef.current='';cursorRef.current=null;setBody('');setSelected(null);setDirty(false);
    setTheme(t.title);setLine(null);setTemplateId(t.id);void runPreview(t.id, review, true);
  };

  const save = async (): Promise<CustomerNotice | null> => {
    if (!body.trim()) { setLine({ tone: 'err', text: '보낼 글이 비어 있습니다.' }); return null; }
    if (!templateId) { setLine({ tone: 'err', text: '안내문 종류를 먼저 골라 주세요.' }); return null; }
    const my = seq.current, token = editToken.current;
    if (selected) {
      const d = await noticeApi<{ notices: CustomerNotice[] }>('GET', `/drafts?orderId=${encodeURIComponent(orderId)}`);
      if (my !== seq.current) return null;
      setNotices(d.notices);
      const cur = d.notices.find((n) => n.id === selected.id);
      if (cur && cur.revision !== selected.revision) {
        setLine({ tone: 'warn', text: '다른 곳에서 저장된 글이 바뀌었습니다. 작성한 글을 복사해 둔 뒤 안내문을 다시 선택해 주세요.' });
        return null;
      }
    }
    const r = await noticeApi<{ notice: CustomerNotice }>('POST', '/drafts', {
      ...(selected ? { id: selected.id, revision: selected.revision } : {}), orderId, body, theme, templateId, advertConsentConfirmed:false,
    });
    if (my !== seq.current) return null;
    setSelected({ id: r.notice.id, revision: r.notice.revision });
    if(token===editToken.current)setDirty(false);
    setNotices((list) => [r.notice, ...list.filter((n) => n.id !== r.notice.id)]);
    return r.notice;
  };

  const guard = async (key: string, fn: () => Promise<void>) => {
    if (busyRef.current) return; busyRef.current = true; setBusy(key);
    try { await fn(); } catch (e) { setLine({ tone: 'err', text: errText(e) }); } finally { busyRef.current = false; setBusy(null); }
  };
  const prepareLocal = async () => {
    if (busyRef.current) return false;
    busyRef.current = true; setBusy('prepare-local');
    try {
      const n = await save();
      if (!n) return false;
      setLine({tone:'info',text:'문안을 저장했습니다. QR이나 카카오톡을 준비해도 실제 발송 완료로 기록하지 않습니다.'});
      return true;
    } catch (e) { setLine({tone:'err',text:errText(e)}); return false; }
    finally { busyRef.current = false; setBusy(null); }
  };
  const startMobile = () => guard('mobile', async () => {
    const my = seq.current;
    const r = await noticeApi<{ url: string; expiresAt: string }>('POST', '/mobile/start', { orderId });
    if (my === seq.current) setMobile(r);
  });
  const before = templates.filter((t) => t.stage === 'before');
  const after = templates.filter((t) => t.stage === 'after');
  const tplGroup = (title: string, list: NoticeTemplate[]) => (
    <div><h4 style={{ margin: '8px 0', fontSize: 18 }}>{title}</h4>
      <div className="nc-tpls">{list.map((t) => (
        <button key={t.id} type="button" className="nc-tpl" disabled={!!busy} aria-pressed={templateId === t.id} onClick={() => pickTemplate(t)} aria-label={`${title} 안내문: ${t.title}`}>{t.title}</button>
      ))}</div></div>
  );
  const anyBusy = !!busy||previewBusy;
  const safeClose = () => {
    if(busyRef.current){setLine({tone:'warn',text:'문안 저장·준비가 끝난 뒤 닫아 주세요.'});return;}
    if(dirty&&body.trim()&&!window.confirm('수정한 메시지를 저장하지 않고 닫을까요?'))return;
    onClose();
  };

  return (
    <Modal title="고객 메시지 편집" sub={ctx ? `${ctx.customerName} 고객 · 주문 ${ctx.orderId}` : `주문 ${orderId}`} onClose={safeClose}>
      {loadErr && <Msg tone="err">불러오기 실패: {loadErr}</Msg>}
      {!ctx && !loadErr && <Msg tone="info">주문 정보를 불러오는 중입니다…</Msg>}
      {ctx && (
        <div className="nc-layout nc-simple-editor">
          <div>
            <section className="nc-section"><h3>안내문 종류 고르기</h3>
              <div className="nc-toggle" role="group" aria-label="안내문 단계">
                <button type="button" aria-pressed={stageView==='before'} onClick={()=>setStageView('before')}>세탁 전 · 기본 안내</button>
                <button type="button" aria-pressed={stageView==='after'} onClick={()=>setStageView('after')}>세탁 후 · 특별 안내</button>
              </div>
              {stageView==='before'?tplGroup('세탁 전',before):tplGroup('세탁 후',after)}
            </section>
            {staleSelected && <Msg tone="warn">다른 곳에서 저장된 문안이 변경되었습니다. 작성한 글은 유지했습니다. 글을 복사해 둔 뒤 안내문을 다시 선택해 주세요.</Msg>}
            <label className="nc-label" htmlFor="nc-body">보낼 글 (자유롭게 고치세요)</label>
            <textarea ref={bodyInput} id="nc-body" lang="ko" className="nc-input nc-body" value={body}
              onChange={(e) => editBody(e.target.value)}
              onSelect={e=>{cursorRef.current=e.currentTarget.selectionStart;}}
              onCompositionStart={()=>{composing.current=true;}} onCompositionEnd={e=>{composing.current=false;cursorRef.current=e.currentTarget.selectionStart;}}
              aria-label="고객에게 보낼 글" />
            <p className="nc-hint">받는 분: {ctx.customerName} · {ctx.customerPhone} / 저장된 주문 금액: {won(ctx.total)}</p>
            <AccountlessNoticeActions recipient={ctx.customerPhone} body={body} onPrepare={prepareLocal} disabled={anyBusy} />
            {line && <Msg tone={line.tone}>{line.text}</Msg>}
          </div>
          <div>
            <section className="nc-section"><h3>휴대폰으로 글 입력하기 (QR)</h3>
              <p style={{fontSize:20,lineHeight:1.7}}>① QR 스캔 → ② 휴대폰에서 음성/글 입력 후 전송 → ③ 왼쪽 ‘보낼 글’에 자동 삽입</p>
              {mobile ? (<>
                <div className="nc-qr"><QrCanvas url={mobile.url} /></div>
                <p style={{ margin: '8px 0 0' }}>{new Date(mobile.expiresAt).toLocaleTimeString('ko-KR')}까지 유효합니다. 받은 글은 PC의 커서 위치 또는 본문 하단에 추가됩니다. 같은 매장 Wi-Fi에 연결해 주세요.</p>
                <div className="nc-row"><button type="button" className="nc-big ghost" onClick={() => setMobile(null)} aria-label="휴대폰 쓰기 연결 끝내기">연결 끝내기</button></div>
              </>) : (
                <button type="button" className="nc-big" disabled={anyBusy} onClick={startMobile} aria-label="휴대폰으로 쓰기 QR 만들기"><QrCode aria-hidden />QR 만들기</button>)}
              {pollErr && <Msg tone="err">{pollErr}</Msg>}
            </section>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ---------------- 진입점 ---------------- */
export function MessagingToolbar(): JSX.Element {
  const [open, setOpen] = useState<'connect' | 'settings' | null>(null);
  const [notice, setNotice] = useState<{ orderId: string; templateId?: string; key: number } | null>(null);
  useEffect(() => {
    const h = (e: Event) => {
      const d = (e as CustomEvent<{ orderId?: string; templateId?: string }>).detail;
      if (d?.orderId) setNotice({ orderId: d.orderId, templateId: d.templateId, key: Date.now() });
    };
    window.addEventListener(OPEN_CUSTOMER_NOTICE, h);
    return () => window.removeEventListener(OPEN_CUSTOMER_NOTICE, h);
  }, []);
  return (
    <>
      <div className="nc-toolbar">
        <button type="button" className="nc-big" onClick={() => setOpen('connect')} aria-label="휴대폰·카톡 연결하기"><Smartphone aria-hidden />휴대폰·카톡 연결하기</button>
        <button type="button" className="nc-big" onClick={() => setOpen('settings')} aria-label="매장 맞춤 설정"><Settings aria-hidden />매장 맞춤 설정</button>
      </div>
      {open === 'connect' && <ConnectHelper onClose={() => setOpen(null)} />}
      {open === 'settings' && <StoreSettings onClose={() => setOpen(null)} />}
      {notice && <NoticeEditor key={notice.key} orderId={notice.orderId} initialTemplateId={notice.templateId} onClose={() => setNotice(null)} />}
      <SpecialNoteHost />
    </>
  );
}

export default MessagingToolbar;
