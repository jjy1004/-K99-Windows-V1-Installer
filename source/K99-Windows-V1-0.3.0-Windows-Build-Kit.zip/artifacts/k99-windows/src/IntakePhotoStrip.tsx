import { useEffect, useState } from 'react';
import type { GarmentRecord } from './garment-record';
import { listRecentPhotos, loadPhotoPreview } from './photo-source';
import { intakePhotoSourceId } from './intake-photo-source';

/** Read-only display using the existing verified source; never captures or reassigns a photo. */
export function IntakePhotoStrip({ garments }: { garments: GarmentRecord[] }) {
  const [images, setImages] = useState<Record<string, string>>({});
  const [unavailable, setUnavailable] = useState(false);
  const signature = JSON.stringify(garments.map(item =>
    [item.garmentId, item.photoStatus, item.photoPath, item.photoTimestamp, item.beforePhoto]));
  useEffect(() => {
    let alive = true;
    setImages({}); setUnavailable(false);
    const saved = garments.filter((item) =>
      (item.photoStatus === 'saved' && item.photoPath) ||
      (item.beforePhoto?.status === 'saved' && item.beforePhoto.origin === 'bridge'));
    if (!saved.length) { setUnavailable(garments.some((item) => item.photoStatus === 'saved')); return; }
    void (async () => {
      try {
        // A stored, verified source ID can outlive the most-recent 30-photo list.
        // Only legacy path-only records need that bounded list; never rematch by filename alone.
        const sources = saved.some((item) => !intakePhotoSourceId(item))
          ? await listRecentPhotos() : [];
        const entries = await Promise.all(saved.map(async (item) => {
          const id = intakePhotoSourceId(item, sources);
          if (!id) return [item.garmentId, ''] as const;
          try { return [item.garmentId, await loadPhotoPreview(id, 'bridge')] as const; }
          catch { return [item.garmentId, ''] as const; }
        }));
        if (alive) { setImages(Object.fromEntries(entries)); setUnavailable(entries.some(([, url]) => !url)); }
      } catch { if (alive) setUnavailable(true); }
    })();
    return () => { alive = false; };
  }, [signature]);
  return <section className="staff-intake-photos" aria-label="접수 사진">
    <h3>접수 사진</h3>
    <div className="staff-intake-photos__grid">{garments.map((item) => <figure key={item.garmentId}>
      {images[item.garmentId] ? <img src={images[item.garmentId]} alt={`${item.itemName} 접수 사진`} />
        : <div>{item.photoStatus === 'simulated' || item.beforePhoto?.status === 'simulated'
          ? '모의 사진 기록 · 실제 촬영 사진 아님'
          : item.photoStatus !== 'saved' && item.beforePhoto?.status !== 'saved'
            ? '접수 사진 없음' : unavailable ? '사진 연결 기록 있음 · 미리보기 연결 필요' : '사진 확인 중…'}</div>}
      <figcaption>{item.itemName} · {item.sequence}/{item.totalSequence}</figcaption>
    </figure>)}</div>
    {unavailable && <p>매장 PC의 사진 연결을 확인해 주세요. 원본 사진과 연결 기록은 변경되지 않습니다.</p>}
  </section>;
}