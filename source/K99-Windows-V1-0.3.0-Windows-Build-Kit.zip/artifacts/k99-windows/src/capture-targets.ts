export const draftUnitKey=(rowId:number,unitIndex:number)=>`${rowId}:${unitIndex}`;
export function captureTargets<T extends {id:number;itemId:string;quantity:number}>(rows:readonly T[],name:(row:T)=>string){
  return rows.flatMap(row=>Array.from({length:row.quantity},(_,index)=>({
    rowId:row.id,itemId:row.itemId,itemName:name(row),unitIndex:index+1,rowQuantity:row.quantity,
  })));
}
export function nextCaptureKey(keys:readonly string[],selected:string){
  const index=keys.indexOf(selected);
  return index>=0&&index<keys.length-1?keys[index+1]:null;
}
