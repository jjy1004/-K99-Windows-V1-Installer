export type CatalogPrice = {
  id: string;
  displayNameKo: string;
  generalPrice: number;
  premiumPrice: number;
};

export type CatalogCategory = 'top' | 'bottom' | 'outer' | 'bedding' | 'shoes' | 'etc';
export const CATEGORY_ORDER: readonly CatalogCategory[] = ['top', 'bottom', 'outer', 'etc', 'bedding', 'shoes'];
export const CATEGORY_LABELS: Record<CatalogCategory, string> = {
  top: '상의', bottom: '하의', outer: '아우터·패딩·코트', bedding: '침구', shoes: '운동화·신발', etc: '정장·원피스·기타',
};

export type CatalogEntry = CatalogPrice & {
  category: CatalogCategory;
  /** Hidden from new selections; kept so saved drafts/orders using old IDs still resolve. */
  legacy?: boolean;
  /** Service variant derived from another entry (e.g. premium sneaker service). Not separately listed/edited. */
  derivedFrom?: string;
  unit?: 'pair';
  custom?: boolean;
  userAdded?: boolean;
  sortOrder?: number;
};

export const PREMIUM_SURCHARGE = 9000;
export const SHIRT_PREMIUM_PRICE = 9000;

/** Premium rule: general + 9,000 won; dress shirt premium is exactly 9,000 won. */
export function premiumFor(id: string, generalPrice: number): number {
  if (id === 'shirt_dress') return SHIRT_PREMIUM_PRICE;
  return generalPrice + PREMIUM_SURCHARGE;
}

const e = (id: string, displayNameKo: string, generalPrice: number, category: CatalogCategory,
  extra: Partial<CatalogEntry> = {}): CatalogEntry =>
  ({ id, displayNameKo, generalPrice, premiumPrice: premiumFor(id, generalPrice), category, ...extra });

/** Ordered master: 상의 → 하의 → 이불·침구 → 신발 → 기타. 33 listed items. */
export const CATALOG_DEFAULTS: readonly CatalogEntry[] = [
  e('shirt_dress', '와이셔츠', 5000, 'top'),
  e('shirt_casual', '남방', 9000, 'top'),
  e('blouse', '블라우스', 15000, 'top'),
  e('sweater', '스웨터', 15000, 'top'),
  e('cardigan', '가디건', 15000, 'top'),
  e('vest', '조끼', 15000, 'top'),
  e('suit_jacket', '정장 상의', 19000, 'top'),
  e('one_piece_dress', '원피스', 29000, 'top'),
  e('half_padding', '하프패딩', 29000, 'top'),
  e('outdoor', '아웃도어', 29000, 'top'),
  e('half_coat', '하프코트', 45000, 'top'),
  e('faux_leather', '인조 가죽', 49000, 'top'),
  e('coat', '롱코트', 59000, 'top'),
  e('moncler', '몽클레어', 79000, 'top'),
  e('leather_jacket', '가죽', 95000, 'top'),
  e('burberry_maxmara', '버버리 및 막스마라', 98000, 'top'),
   e('jacket', '재킷', 29000, 'top'),
   e('jumper', '점퍼(잠바)', 29000, 'top'),
  e('t_shirt', '티셔츠', 15000, 'top'),
  e('suit_pants', '정장 하의', 15000, 'bottom'),
  e('skirt', '치마', 15000, 'bottom'),
  e('pleated_skirt', '주름치마', 15000, 'bottom'),
  e('blanket', '일반 이불', 29000, 'bedding'),
  e('wool_blanket', '양모 이불', 39000, 'bedding'),
  e('pillow', '베개', 25000, 'bedding'),
  e('tempur_pillow', '템퍼 베개', 24000, 'bedding'),
  e('sneakers_general', '운동화', 9000, 'shoes', { unit: 'pair' }),
  e('ugg', '어그 부츠', 39000, 'shoes'),
  e('hanbok', '한복', 49000, 'etc'),
  e('necktie', '넥타이', 9000, 'etc'),
  e('curtain_2m', '커튼 2m 이하', 24000, 'etc'),
  e('muffler', '목도리', 15000, 'etc'),
  e('scarf', '스카프', 15000, 'etc'),
  e('cap', '모자', 9000, 'etc'),
  e('other', '기타', 0, 'etc', { premiumPrice: 0, custom: true }),
  // Premium sneaker service: priced as 운동화 general + 9,000 (fixed per selected service).
  { id: 'sneakers_premium', displayNameKo: '프리미엄 운동화', generalPrice: 18000, premiumPrice: 18000,
    category: 'shoes', unit: 'pair', derivedFrom: 'sneakers_general',
  },
  // Legacy IDs retained only so previously saved drafts/orders can still be read.
  { id: 'sweatshirt', displayNameKo: '스웨트', generalPrice: 15000, premiumPrice: 24000, category: 'top', legacy: true },
  { id: 'light_padded_jacket', displayNameKo: '경량 패딩', generalPrice: 30000, premiumPrice: 39000, category: 'top', legacy: true },
  { id: 'padded_jacket', displayNameKo: '일반 패딩', generalPrice: 35000, premiumPrice: 44000, category: 'top', legacy: true },
  { id: 'vintage', displayNameKo: '빈티지', generalPrice: 30000, premiumPrice: 39000, category: 'etc', legacy: true },
];

/** Items selectable for new intake, in display order. */
export function selectableEntries<T extends CatalogEntry>(catalog: readonly T[]): T[] {
  return sortCatalog(catalog.filter((entry) => !entry.legacy && !entry.derivedFrom));
}

// Existing IDs/categories remain readable. Classification changes presentation only.
export function effectiveCategory(entry: CatalogEntry): CatalogCategory {
  if (entry.userAdded) return entry.category;
  if (['suit_jacket', 'one_piece_dress'].includes(entry.id)) return 'etc';
  if (['half_padding', 'outdoor', 'half_coat', 'faux_leather', 'coat', 'moncler',
    'leather_jacket', 'burberry_maxmara', 'jacket', 'jumper', 'light_padded_jacket', 'padded_jacket'].includes(entry.id)) return 'outer';
  return entry.category;
}
export function itemFamily(entry: CatalogEntry): string {
  const name = entry.displayNameKo.replace(/\s/g, '');
  if (/패딩|몽클레어/.test(name) || entry.id === 'moncler') return '패딩';
  if (/코트|트렌치|버버리|막스마라/.test(name) || entry.id === 'coat') return '코트';
  if (/자켓|재킷|점퍼|잠바|가죽|아웃도어/.test(name)) return '자켓·점퍼';
  return name;
}
export function sortCatalog<T extends CatalogEntry>(catalog: readonly T[]): T[] {
  const ko = (a: string, b: string) => a.localeCompare(b, 'ko');
  return [...catalog].sort((a,b) =>
    CATEGORY_ORDER.indexOf(effectiveCategory(a)) - CATEGORY_ORDER.indexOf(effectiveCategory(b))
    || ko(itemFamily(a), itemFamily(b))
    || (a.sortOrder ?? 0) - (b.sortOrder ?? 0)
    || ko(a.displayNameKo, b.displayNameKo) || ko(a.id, b.id));
}
export function groupByCategory<T extends CatalogEntry>(catalog: readonly T[]) {
  return CATEGORY_ORDER.map((category) => ({
    category, label: CATEGORY_LABELS[category],
    items: sortCatalog(catalog.filter((entry) => effectiveCategory(entry) === category)),
  })).filter((group) => group.items.length > 0);
}

/** Reception-only layout. Historical IDs, prices and manager category data are untouched. */
export function receptionGroups<T extends CatalogEntry>(catalog:readonly T[]){
  const outerNames=['가죽','롱패딩','하프패딩','몽클레어','아웃도어','인조가죽','롱코트','하프코트','버버리','막스마라'];
  const etcIds=['necktie','cap','muffler','scarf','curtain_2m','hanbok'];
  const topIds=['cardigan','shirt_casual','blouse','sweater','suit_jacket','suit_pants','shirt_dress','vest','one_piece_dress','jacket','jumper','t_shirt','skirt','pleated_skirt'];
  const compact=(e:CatalogEntry)=>e.displayNameKo.replace(/\s/g,'');
  const outerRank=(e:CatalogEntry)=>{const n=compact(e),i=outerNames.indexOf(n);return i<0?100:i;};
  const kind=(e:CatalogEntry)=>{
    if(topIds.includes(e.id))return 'top';
    if(outerRank(e)<100)return 'outer';
    if(etcIds.includes(e.id))return 'etc';
    const c=effectiveCategory(e);
    return c==='bottom'?'top':c==='etc'?'custom':c;
  };
  const items=catalog.filter(e=>e.id!=='other'&&e.id!=='burberry_maxmara');
  return [
    ['top','상의'],['outer','아우터 · 패딩 · 코트'],['etc','기타'],
    ['bedding','침구'],['shoes','운동화 · 신발 · 어그부츠'],['custom','매장 추가 품목'],
  ].map(([category,label])=>({category,label,items:items.filter(e=>kind(e)===category).sort((a,b)=>{
    if(category==='outer')return outerRank(a)-outerRank(b)||a.displayNameKo.localeCompare(b.displayNameKo,'ko');
    if(category==='etc')return etcIds.indexOf(a.id)-etcIds.indexOf(b.id);
    if(category==='top'){
      const rank=(e:CatalogEntry)=>topIds.includes(e.id)?topIds.indexOf(e.id):100;
      return rank(a)-rank(b)||a.displayNameKo.localeCompare(b.displayNameKo,'ko');
    }
    return a.displayNameKo.localeCompare(b.displayNameKo,'ko');
  }).map(e=>e.id==='curtain_2m'?{...e,displayNameKo:'커튼'}:e.id==='faux_leather'?{...e,displayNameKo:'인조가죽'}:e)})).filter(g=>g.items.length);
}

/** Stable display order index for any item id (unknown ids sort last). */
export function catalogOrderIndex(catalog: readonly CatalogEntry[], id: string): number {
  const entry = catalog.find((item) => item.id === id);
  if (!entry) return Number.MAX_SAFE_INTEGER;
  return sortCatalog(catalog).findIndex((item) => item.id === id);
}

export const PRICE_STORAGE_KEY = 'k99-price-overrides-v2';
const validPrice = (price: unknown): price is number =>
  typeof price === 'number' && Number.isSafeInteger(price) && price >= 0 && price <= 100000000;

type GeneralOverride = Partial<CatalogEntry> & { id: string; generalPrice: number };

/** Validates admin overrides of general price; premium is always derived. Legacy ids are not editable. */
export function validateCatalog<T extends CatalogEntry>(defaults: readonly T[], candidate: unknown): T[] {
  if (!Array.isArray(candidate)) throw new Error('가격표 형식을 확인해 주세요.');
  const editable = new Set(defaults.filter((entry) => !entry.legacy && !entry.derivedFrom && !entry.custom).map((entry) => entry.id));
  const overrides = new Map<string, number>();
  const additions: CatalogEntry[] = [];
  const seen = new Set<string>();
  for (const value of candidate as GeneralOverride[]) {
    if (!value || typeof value.id !== 'string' || seen.has(value.id))
      throw new Error('가격표에 알 수 없거나 중복된 품목이 있습니다.');
    seen.add(value.id);
    if (value.userAdded && !/^user_[a-zA-Z0-9-]{1,80}$/.test(value.id))
      throw new Error('기본 품목의 식별자는 변경할 수 없습니다.');
    if (!editable.has(value.id) && !(value.userAdded === true && /^user_[a-zA-Z0-9-]{1,80}$/.test(value.id)))
      throw new Error('가격표에 알 수 없거나 중복된 품목이 있습니다.');
    if (!validPrice(value.generalPrice) || value.generalPrice === 0) {
      const name = defaults.find((entry) => entry.id === value.id)?.displayNameKo ?? value.id;
      throw new Error(`${name} 가격을 1원 이상 1억 원 이하의 정수로 입력해 주세요.`);
    }
    if (value.id === 'shirt_dress' && value.generalPrice > SHIRT_PREMIUM_PRICE)
      throw new Error('와이셔츠 프리미엄은 9,000원 고정이므로 일반 세탁비는 9,000원 이하로 입력해 주세요.');
    overrides.set(value.id, value.generalPrice);
    if (value.userAdded) {
      const name = value.displayNameKo?.normalize('NFC').trim();
      if (!name || name.length > 60 || /[\u0000-\u001f\u007f]/.test(name)
        || !CATEGORY_ORDER.includes(value.category as CatalogCategory)
        || value.legacy !== undefined && typeof value.legacy !== 'boolean'
        || value.sortOrder !== undefined && (!Number.isSafeInteger(value.sortOrder) || Math.abs(value.sortOrder) > 100000))
        throw new Error('추가 품목의 이름·카테고리·순서를 확인해 주세요.');
      additions.push({id:value.id, displayNameKo:name, category:value.category as CatalogCategory,
        generalPrice:value.generalPrice, premiumPrice:premiumFor(value.id,value.generalPrice),
        userAdded:true, ...(value.legacy ? {legacy:true}:{}),
        ...(value.sortOrder !== undefined ? {sortOrder:value.sortOrder}:{})});
    }
  }
  const resolved = defaults.map((original) => {
    if (original.legacy || original.derivedFrom || original.custom) return { ...original };
    const generalPrice = overrides.get(original.id) ?? original.generalPrice;
    return { ...original, generalPrice, premiumPrice: premiumFor(original.id, generalPrice) };
  });
  return [...resolved, ...additions as T[]].map((entry) => {
    if (!entry.derivedFrom) return entry;
    const base = resolved.find((item) => item.id === entry.derivedFrom);
    const price = base ? base.generalPrice + PREMIUM_SURCHARGE : entry.generalPrice;
    return { ...entry, generalPrice: price, premiumPrice: price };
  });
}

export function readManagedCatalog<T extends CatalogEntry>(defaults: readonly T[]): T[] {
  if (typeof window === 'undefined') return validateCatalog(defaults, []);
  const raw = window.localStorage.getItem(PRICE_STORAGE_KEY);
  return validateCatalog(defaults, raw ? JSON.parse(raw) : []);
}

export function saveManagedCatalog<T extends CatalogEntry>(defaults: readonly T[], entries: unknown): T[] {
  const list = Array.isArray(entries) ? entries : [];
  const editable = list.filter((entry: Partial<CatalogEntry>) => {
    const original = defaults.find((item) => item.id === entry?.id);
    return entry.userAdded || original && !original.legacy && !original.derivedFrom && !original.custom;
  }).map((entry: GeneralOverride) => entry.userAdded ? entry : ({ id: entry.id, generalPrice: entry.generalPrice }));
  const catalog = validateCatalog(defaults, editable);
  const serialized = JSON.stringify(editable);
  window.localStorage.setItem(PRICE_STORAGE_KEY, serialized);
  if (window.localStorage.getItem(PRICE_STORAGE_KEY) !== serialized)
    throw new Error('가격표 저장을 확인하지 못했습니다. 다시 시도해 주세요.');
  return catalog;
}
