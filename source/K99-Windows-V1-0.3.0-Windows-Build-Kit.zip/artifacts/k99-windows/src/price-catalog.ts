export type CatalogPrice = {
  id: string;
  displayNameKo: string;
  generalPrice: number;
  premiumPrice: number;
};

export type CatalogCategory = 'top' | 'bottom' | 'bedding' | 'shoes' | 'etc';
export const CATEGORY_ORDER: readonly CatalogCategory[] = ['top', 'bottom', 'bedding', 'shoes', 'etc'];
export const CATEGORY_LABELS: Record<CatalogCategory, string> = {
  top: '상의', bottom: '하의', bedding: '이불·침구', shoes: '신발', etc: '기타',
};

export type CatalogEntry = CatalogPrice & {
  category: CatalogCategory;
  /** Hidden from new selections; kept so saved drafts/orders using old IDs still resolve. */
  legacy?: boolean;
  /** Service variant derived from another entry (e.g. premium sneaker service). Not separately listed/edited. */
  derivedFrom?: string;
  unit?: 'pair';
  custom?: boolean;
};

export const PREMIUM_SURCHARGE = 9000;
export const SHIRT_PREMIUM_PRICE = 9000;

/** Premium rule: general + 9,000 won; dress shirt premium is exactly 9,000 won. */
export function premiumFor(id: string, generalPrice: number): number {
  if (id === 'shirt_dress') return SHIRT_PREMIUM_PRICE;
  return generalPrice + PREMIUM_SURCHARGE;
}

const e = (id: string, displayNameKo: string, generalPrice: number, category: CatalogCategory,
  extra: Partial<CatalogEntry> = {}): CatalogEntry =>
  ({ id, displayNameKo, generalPrice, premiumPrice: premiumFor(id, generalPrice), category, ...extra });

/** Ordered master: 상의 → 하의 → 이불·침구 → 신발 → 기타. 33 listed items. */
export const CATALOG_DEFAULTS: readonly CatalogEntry[] = [
  e('shirt_dress', '와이셔츠', 5000, 'top'),
  e('shirt_casual', '남방', 9000, 'top'),
  e('blouse', '블라우스', 15000, 'top'),
  e('sweater', '스웨터', 15000, 'top'),
  e('cardigan', '가디건', 15000, 'top'),
  e('vest', '조끼', 15000, 'top'),
  e('suit_jacket', '정장 상의', 19000, 'top'),
  e('one_piece_dress', '원피스', 29000, 'top'),
  e('half_padding', '하프패딩', 29000, 'top'),
  e('outdoor', '아웃도어', 29000, 'top'),
  e('half_coat', '하프코트', 45000, 'top'),
  e('faux_leather', '인조 가죽', 49000, 'top'),
  e('coat', '롱코트', 59000, 'top'),
  e('moncler', '몽클레어', 79000, 'top'),
  e('leather_jacket', '가죽', 95000, 'top'),
  e('burberry_maxmara', '버버리 및 막스마라', 98000, 'top'),
  e('jacket', '자켓', 29000, 'top'),
  e('jumper', '잠바', 29000, 'top'),
  e('t_shirt', '티셔츠', 15000, 'top'),
  e('suit_pants', '정장 하의', 15000, 'bottom'),
  e('skirt', '치마', 15000, 'bottom'),
  e('pleated_skirt', '주름치마', 15000, 'bottom'),
  e('blanket', '일반 이불', 29000, 'bedding'),
  e('wool_blanket', '양모 이불', 39000, 'bedding'),
  e('pillow', '베개', 25000, 'bedding'),
  e('tempur_pillow', '템퍼 베개', 24000, 'bedding'),
  e('sneakers_general', '운동화', 9000, 'shoes', { unit: 'pair' }),
  e('ugg', '어그 부츠', 39000, 'shoes'),
  e('hanbok', '한복', 49000, 'etc'),
  e('necktie', '넥타이', 9000, 'etc'),
  e('curtain_2m', '커튼 2m 이하', 24000, 'etc'),
  e('muffler', '목도리', 15000, 'etc'),
  e('scarf', '스카프', 15000, 'etc'),
  e('cap', '모자', 9000, 'etc'),
  e('other', '기타', 0, 'etc', { premiumPrice: 0, custom: true }),
  // Premium sneaker service: priced as 운동화 general + 9,000 (fixed per selected service).
  { id: 'sneakers_premium', displayNameKo: '프리미엄 운동화', generalPrice: 18000, premiumPrice: 18000,
    category: 'shoes', unit: 'pair', derivedFrom: 'sneakers_general',
  },
  // Legacy IDs retained only so previously saved drafts/orders can still be read.
  { id: 'sweatshirt', displayNameKo: '스웨트', generalPrice: 15000, premiumPrice: 24000, category: 'top', legacy: true },
  { id: 'light_padded_jacket', displayNameKo: '경량 패딩', generalPrice: 30000, premiumPrice: 39000, category: 'top', legacy: true },
  { id: 'padded_jacket', displayNameKo: '일반 패딩', generalPrice: 35000, premiumPrice: 44000, category: 'top', legacy: true },
  { id: 'vintage', displayNameKo: '빈티지', generalPrice: 30000, premiumPrice: 39000, category: 'etc', legacy: true },
];

/** Items selectable for new intake, in display order. */
export function selectableEntries<T extends CatalogEntry>(catalog: readonly T[]): T[] {
  return catalog.filter((entry) => !entry.legacy && !entry.derivedFrom);
}

export function groupByCategory<T extends CatalogEntry>(catalog: readonly T[]) {
  return CATEGORY_ORDER.map((category) => ({
    category, label: CATEGORY_LABELS[category],
    items: catalog.filter((entry) => entry.category === category),
  })).filter((group) => group.items.length > 0);
}

/** Stable display order index for any item id (unknown ids sort last). */
export function catalogOrderIndex(catalog: readonly CatalogEntry[], id: string): number {
  const entry = catalog.find((item) => item.id === id);
  if (!entry) return Number.MAX_SAFE_INTEGER;
  return CATEGORY_ORDER.indexOf(entry.category) * 1000 + catalog.indexOf(entry);
}

export const PRICE_STORAGE_KEY = 'k99-price-overrides-v2';
const validPrice = (price: unknown): price is number =>
  typeof price === 'number' && Number.isSafeInteger(price) && price >= 0 && price <= 100000000;

type GeneralOverride = { id: string; generalPrice: number };

/** Validates admin overrides of general price; premium is always derived. Legacy ids are not editable. */
export function validateCatalog<T extends CatalogEntry>(defaults: readonly T[], candidate: unknown): T[] {
  if (!Array.isArray(candidate)) throw new Error('가격표 형식을 확인해 주세요.');
  const editable = new Set(defaults.filter((entry) => !entry.legacy && !entry.derivedFrom && !entry.custom).map((entry) => entry.id));
  const overrides = new Map<string, number>();
  for (const value of candidate as GeneralOverride[]) {
    if (!value || typeof value.id !== 'string' || !editable.has(value.id) || overrides.has(value.id))
      throw new Error('가격표에 알 수 없거나 중복된 품목이 있습니다.');
    if (!validPrice(value.generalPrice) || value.generalPrice === 0) {
      const name = defaults.find((entry) => entry.id === value.id)?.displayNameKo ?? value.id;
      throw new Error(`${name} 가격을 1원 이상 1억 원 이하의 정수로 입력해 주세요.`);
    }
    if (value.id === 'shirt_dress' && value.generalPrice > SHIRT_PREMIUM_PRICE)
      throw new Error('와이셔츠 프리미엄은 9,000원 고정이므로 일반 세탁비는 9,000원 이하로 입력해 주세요.');
    overrides.set(value.id, value.generalPrice);
  }
  const resolved = defaults.map((original) => {
    if (original.legacy || original.derivedFrom || original.custom) return { ...original };
    const generalPrice = overrides.get(original.id) ?? original.generalPrice;
    return { ...original, generalPrice, premiumPrice: premiumFor(original.id, generalPrice) };
  });
  return resolved.map((entry) => {
    if (!entry.derivedFrom) return entry;
    const base = resolved.find((item) => item.id === entry.derivedFrom);
    const price = base ? base.generalPrice + PREMIUM_SURCHARGE : entry.generalPrice;
    return { ...entry, generalPrice: price, premiumPrice: price };
  });
}

export function readManagedCatalog<T extends CatalogEntry>(defaults: readonly T[]): T[] {
  if (typeof window === 'undefined') return validateCatalog(defaults, []);
  const raw = window.localStorage.getItem(PRICE_STORAGE_KEY);
  return validateCatalog(defaults, raw ? JSON.parse(raw) : []);
}

export function saveManagedCatalog<T extends CatalogEntry>(defaults: readonly T[], entries: unknown): T[] {
  const list = Array.isArray(entries) ? entries : [];
  const editable = list.filter((entry: Partial<CatalogEntry>) => {
    const original = defaults.find((item) => item.id === entry?.id);
    return original && !original.legacy && !original.derivedFrom && !original.custom;
  }).map((entry: GeneralOverride) => ({ id: entry.id, generalPrice: entry.generalPrice }));
  const catalog = validateCatalog(defaults, editable);
  const serialized = JSON.stringify(editable);
  window.localStorage.setItem(PRICE_STORAGE_KEY, serialized);
  if (window.localStorage.getItem(PRICE_STORAGE_KEY) !== serialized)
    throw new Error('가격표 저장을 확인하지 못했습니다. 다시 시도해 주세요.');
  return catalog;
}
