import { useEffect, useRef, useState } from 'react';
import { readPhotoBridgeConnectionSession } from './photo-bridge-session';

type CopyReport = { active: boolean; copied: number; paths: string[]; pending: number; error: string };
const COPY_URL = 'k99-disabled://hardware';

export function IntakePhotoCopy({ draftId, customerName, customerPhone, active }: {
  draftId: string; customerName: string; customerPhone: string; active: boolean;
}) {
  const owner = useRef(crypto.randomUUID());
  const leaseOwner = useRef('');
  const revision = useRef(0);
  const [report, setReport] = useState<CopyReport | null>(null);
  const [error, setError] = useState('');
  const digits = customerPhone.replace(/\D/g, '');
  const ready = active && Boolean(customerName.trim()) && digits.length >= 4;

  useEffect(() => {
    const currentOwner = `${owner.current}-${crypto.randomUUID()}`;
    leaseOwner.current = currentOwner;
    return () => {
      const session = readPhotoBridgeConnectionSession();
      if (session?.mode === 'STORE' && active) {
        void fetch(`${COPY_URL}/context`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json', 'X-K99-Copy-Token': session.token },
          body: JSON.stringify({ owner: currentOwner }),
        }).catch(() => { /* Only this intake lease; never stops Bridge. */ });
      }
    };
  }, [draftId, active]);

  useEffect(() => {
    setReport(null);
    setError('');
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    let controller: AbortController | undefined;
    // Identity edits share the intake baseline. A different intake has a new
    // lease owner, so a late DELETE cannot stop its replacement.
    const currentOwner = leaseOwner.current;
    const contextRevision = ++revision.current;
    const sync = async () => {
      const session = readPhotoBridgeConnectionSession();
      if (!session || session.mode !== 'STORE') {
        if (!disposed) setError('기존 STORE 직원 탭 인증 연결이 필요합니다.');
      } else {
        controller = new AbortController();
        const deadline = setTimeout(() => controller?.abort(), 2500);
        try {
          const response = await fetch(`${COPY_URL}/context`, {
            method: 'POST', cache: 'no-store', signal: controller.signal,
            headers: { 'Content-Type': 'application/json', 'X-K99-Copy-Token': session.token },
            body: JSON.stringify({ owner: currentOwner, draftId, customerName: ready ? customerName : '',
              last4: ready ? digits.slice(-4) : '', waiting: !ready, revision: contextRevision }),
          });
          const value = await response.json();
          if (!response.ok) throw new Error(value.error || '사진 복사 도우미 요청 실패');
          if (typeof value.active !== 'boolean' || !Number.isSafeInteger(value.copied) ||
              !Array.isArray(value.paths) || !value.paths.every((p: unknown) => typeof p === 'string') ||
              typeof value.error !== 'string' || !Number.isSafeInteger(value.pending)) {
            throw new Error('사본 저장 결과를 확인하지 못했습니다.');
          }
          if (!disposed) { setReport(value); setError(''); }
        } catch (cause) {
          if (!disposed) {
            setReport(null);
            setError(cause instanceof Error && !/fetch|abort/i.test(cause.message)
              ? cause.message : '별도 사진 복사 도우미 연결이 필요합니다. K99_PHOTO_COPY_START.cmd를 실행해 주세요.');
          }
        } finally { clearTimeout(deadline); }
      }
      if (!disposed) timer = setTimeout(sync, 2000);
    };
    // Do not arm intermediate IME/typing values as separate customers.
    if (active) timer = setTimeout(sync, ready ? 500 : 0);
    return () => {
      disposed = true;
      clearTimeout(timer);
      controller?.abort();
    };
  }, [active, ready, draftId, customerName, digits]);

  return <section className="intake-photo-bridge" data-testid="intake-photo-copy" aria-label="고객별 사진 사본 저장">
    <strong>고객별 사진 사본 저장 · 원본 보존</strong>
    <p>{!active ? '접수 중이 아니므로 새 사진 복사를 중지했습니다.'
      : error || report?.error || (!ready ? '고객명·휴대전화번호 확인 대기 · 새 사진은 고객 확인 후 복사합니다.'
      : (report?.active
        ? `새 사진 복사 대기 · 저장 확인 ${report.copied}장${report.pending ? ` · 쓰기 완료 대기 ${report.pending}장` : ''}`
        : '사진 복사 연결 확인 중'))}</p>
    <small>복사 연결 이후 새 JPG·PNG·BMP·WebP만 저장합니다. 기존 사진은 소급 복사하지 않으며, 의류 연결·태그 출력은 기존 절차를 그대로 사용합니다.</small>
  </section>;
}
