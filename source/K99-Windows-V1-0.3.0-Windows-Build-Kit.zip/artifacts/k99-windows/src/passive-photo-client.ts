import type { GarmentTagData, PhotoBridgeTagJobStatus } from './garment-record';
import type { ConfirmedOrder } from './order-record';
import { withPhotoReadDeadline } from './photo-read-deadline.ts';
import {
  readOperationalPhotoBridgeSession, readPhotoBridgeConnectionSession,
  setPhotoBridgeConnectionSession,
} from './photo-bridge-session.ts';

const API_BASE = 'k99-disabled://hardware';

export type PhotoBridgeSession = { token: string };
export type PhotoSettings = {
  sourceRoot: string;
  destinationRoot: string;
  configured: boolean;
};
export type PhotoArmStatus = {
  status: 'armed' | 'saved' | 'failed';
  requestId: string;
  orderId: string;
  garmentId: string;
  photoPath?: string;
  photoTimestamp?: string;
  capturedAt?: string;
  archivePath?: string;
  archiveError?: string;
  error?: string;
};
export type PhotoBridgeTagMode = 'DEV' | 'TEST' | 'STORE';
export type PhotoBridgeTagJob = {
  barcodeValue?: string;
  verifiedPhoto?: { requestId: string; status: 'saved'; photoPath: string; timestamp: string };
  jobId: string;
  requestId: string;
  orderId: string;
  garmentId: string;
  mode: PhotoBridgeTagMode;
  status: PhotoBridgeTagJobStatus;
  automatic: boolean;
  copies: 1;
  hardwareVerified: boolean;
  printReceipt?: {
    hardwareVerified: true; deviceAcknowledged: true; physicalEvidence: 'TSC_LABEL_COUNTER';
    labelCounterBefore: number; labelCounterAfter: number; deviceStatusAfter: '@@@@';
    transport: 'TSPL_USB_DIRECT'; copies: 1;
  };
  reason?: string;
  createdAt: string;
};
export type PhotoBridgeTagTemplate = {
  version: 1;
  id: string;
  verification: 'TEST/PENDING';
  page: { widthMm: number; heightMm: number };
  serviceLabels: Record<ConfirmedOrder['choices']['serviceLevel'] | 'sneaker-general' | 'sneaker-premium', string>;
  elements: Array<
    | {
        type: 'text';
        field: 'customerName' | 'itemName' | 'garmentId' | 'orderNumber' | 'serviceLabel';
        xMm: number; yMm: number; widthMm: number; heightMm: number;
        fontSizePt: number; bold: boolean;
      }
    | {
        type: 'code'; field: 'barcodeValue'; kind: 'code128' | 'qr';
        xMm: number; yMm: number; widthMm: number; heightMm: number;
      }
  >;
};

export type PhotoBridgeTagJobRequest = {
  requestId: string;
  orderId: string;
  garmentId: string;
  photoRequestId: string;
  photoPath?: string;
  photoTimestamp?: string;
  photoStatus: 'saved' | 'simulated';
  staffConfirmed: true;
  copies: 1;
  alreadyPrinted?: boolean;
  manual?: true;
  tag: GarmentTagData;
  renderedTag?: { pngBase64: string; widthMm: number; heightMm: number; templateId: string; garmentId: string };
};
export type PhotoBridgePhotoConfirmationRequest = {
  orderId: string;
  garmentId: string;
  photoRequestId: string;
  photoPath?: string;
  photoTimestamp?: string;
  photoStatus: 'saved' | 'simulated';
  staffConfirmed: true;
};
export type PhotoBridgePhotoConfirmation = {
  orderId: string;
  garmentId: string;
  photoRequestId: string;
  mode: PhotoBridgeTagMode;
  photoVerified: boolean;
};

type TagBridgeFetch = (url: string, init?: RequestInit) => Promise<Response>;

function isTagRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function validatePhotoBridgeTagJob(value: unknown): PhotoBridgeTagJob {
  if (!isTagRecord(value) || typeof value.jobId !== 'string' || !value.jobId.trim() ||
      typeof value.requestId !== 'string' || !value.requestId.trim() ||
      typeof value.orderId !== 'string' || !value.orderId.trim() ||
      typeof value.garmentId !== 'string' || !value.garmentId.trim() ||
      !['DEV', 'TEST', 'STORE'].includes(value.mode as string) ||
      !['pending', 'submitted', 'unknown', 'skipped', 'printed', 'failed'].includes(value.status as string) ||
      (['printed', 'failed'].includes(value.status as string) && value.mode !== 'STORE') ||
      typeof value.automatic !== 'boolean' || value.copies !== 1 || typeof value.hardwareVerified !== 'boolean' ||
      typeof value.createdAt !== 'string' || !Number.isFinite(Date.parse(value.createdAt)) ||
      (value.reason !== undefined && typeof value.reason !== 'string')) {
    throw new Error('Photo Bridge 태그 요청 응답을 검증할 수 없습니다. 실물 인쇄로 간주하지 않았습니다.');
  }
  if (value.status === 'printed' && !hasDevicePrintProof(value)) {
    throw new Error('태그 출력 실패: TE210 실제 장치 완료 증거가 없습니다.');
  }
  if (value.status !== 'printed' && value.hardwareVerified !== false) {
    throw new Error('태그 출력 실패: 장치 검증 상태가 작업 결과와 일치하지 않습니다.');
  }
  return value as unknown as PhotoBridgeTagJob;
}

export function hasDevicePrintProof(value: unknown): boolean {
  if (!isTagRecord(value) || value.mode !== 'STORE' || value.status !== 'printed' ||
      value.hardwareVerified !== true || !isTagRecord(value.printReceipt)) return false;
  const r = value.printReceipt;
  return r.hardwareVerified === true && r.deviceAcknowledged === true &&
    r.physicalEvidence === 'TSC_LABEL_COUNTER' && r.transport === 'TSPL_USB_DIRECT' &&
    r.deviceStatusAfter === '@@@@' && r.copies === 1 &&
    Number.isSafeInteger(r.labelCounterBefore) && (r.labelCounterBefore as number) >= 0 &&
    r.labelCounterAfter === (r.labelCounterBefore as number) + 1;
}

export function validatePhotoBridgeTagTemplate(value: unknown): PhotoBridgeTagTemplate {
  if (!isTagRecord(value) || value.version !== 1 || value.verification !== 'TEST/PENDING' ||
      typeof value.id !== 'string' || !value.id.trim() || !isTagRecord(value.page) ||
      !isTagRecord(value.serviceLabels) || !Array.isArray(value.elements) ||
      !Number.isFinite(value.page.widthMm) || !Number.isFinite(value.page.heightMm) ||
      (value.page.widthMm as number) <= 0 || (value.page.widthMm as number) > 500 ||
      (value.page.heightMm as number) <= 0 || (value.page.heightMm as number) > 500) {
    throw new Error('외부 태그 템플릿이 비어 있거나 안전하게 표시할 수 없습니다.');
  }
  const services = ['general', 'premium', 'sneaker-general', 'sneaker-premium'];
  const serviceLabels = value.serviceLabels as Record<string, unknown>;
  if (!services.every((key) => typeof serviceLabels[key] === 'string' &&
      serviceLabels[key].trim().length > 0 && serviceLabels[key].length <= 40)) {
    throw new Error('외부 태그 템플릿의 일반/프리미엄 표시가 올바르지 않습니다.');
  }
  const allowedTextFields = new Set(['customerName', 'itemName', 'garmentId', 'orderNumber', 'serviceLabel']);
  const seen = new Set<string>();
  let barcodeCount = 0;
  if (value.elements.length < 6 || value.elements.length > 12) {
    throw new Error('외부 태그 템플릿 요소 수가 올바르지 않습니다.');
  }
  for (const element of value.elements) {
    if (!isTagRecord(element) || typeof element.field !== 'string' || seen.has(element.field) ||
        !Number.isFinite(element.xMm) || !Number.isFinite(element.yMm) ||
        !Number.isFinite(element.widthMm) || !Number.isFinite(element.heightMm) ||
        (element.xMm as number) < 0 || (element.yMm as number) < 0 ||
        (element.widthMm as number) <= 0 || (element.heightMm as number) <= 0 ||
        (element.xMm as number) + (element.widthMm as number) > (value.page.widthMm as number) ||
        (element.yMm as number) + (element.heightMm as number) > (value.page.heightMm as number)) {
      throw new Error('외부 태그 템플릿의 좌표를 안전하게 표시할 수 없습니다.');
    }
    if (element.type === 'text') {
      if (!allowedTextFields.has(element.field) || typeof element.fontSizePt !== 'number' ||
          !Number.isFinite(element.fontSizePt) || element.fontSizePt <= 0 ||
          element.fontSizePt > 100 || typeof element.bold !== 'boolean') {
        throw new Error('외부 태그 템플릿의 글자 필드가 올바르지 않습니다.');
      }
    } else if (element.type === 'code') {
      barcodeCount += 1;
      if (element.field !== 'barcodeValue' || !['code128', 'qr'].includes(element.kind as string) ||
          barcodeCount > 1) {
        throw new Error('바코드는 garmentId 하나만 배치할 수 있습니다.');
      }
    } else {
      throw new Error('지원하지 않는 외부 태그 템플릿 요소입니다.');
    }
    seen.add(element.field);
  }
  for (const required of ['customerName', 'itemName', 'garmentId', 'orderNumber', 'serviceLabel', 'barcodeValue']) {
    if (!seen.has(required) || barcodeCount !== 1)
      throw new Error('태그 템플릿의 고객명·품목·의류 ID·접수번호·바코드 위치가 필요합니다.');
  }
  return value as unknown as PhotoBridgeTagTemplate;
}

function tagBridgeRequest<T>(
  path: string,
  init: RequestInit,
  fetchImpl: TagBridgeFetch = fetch,
  notFoundIsNull = false,
  timeoutMs = 3000,
): Promise<T | null> {
  const session = readPhotoBridgeConnectionSession();
  if (!session) throw new Error('Photo Bridge 태그 기능은 연결 상태에서만 요청할 수 있습니다.');
  return (async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const upstream = init.signal;
    const cancel = () => controller.abort();
    upstream?.addEventListener('abort', cancel, { once: true });
    if (upstream?.aborted) controller.abort();
    try {
      const response = await fetchImpl(`${API_BASE}${path}`, {
        ...init,
        cache: 'no-store',
        signal: controller.signal,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'X-K99-Bridge-Token': session.token,
          ...init.headers,
        },
      });
      if (response.status === 404 && notFoundIsNull) return null;
      if (response.status === 404 && init.method !== 'GET') {
        throw new Error('Photo Bridge 태그 endpoint를 확인할 수 없습니다. 사진 기록은 유지했습니다.');
      }
      if (!response.ok) {
        const detail = await response.text().catch(() => '');
        throw new Error(`Photo Bridge 태그 요청 실패 (${response.status})${detail ? `: ${detail.slice(0, 240)}` : ''}`);
      }
      let data: T;
      try {
        data = await response.json() as T;
      } catch {
        throw new Error('Photo Bridge 태그 응답이 JSON이 아니며 실물 출력을 확인하지 못했습니다.');
      }
      const current = readPhotoBridgeConnectionSession();
      if (!current || current.token !== session.token || current.mode !== session.mode) {
        throw new Error('태그 응답을 기다리는 동안 Photo Bridge 연결 세션이 바뀌었습니다. 현재 상태를 다시 조회해 주세요.');
      }
      return data;
    } catch (cause) {
      if (cause instanceof Error && /Photo Bridge|photo bridge|시간 초과/i.test(cause.message)) throw cause;
      if (controller.signal.aborted) {
        throw new Error('태그 응답이 불명확합니다. 중복 출력을 막기 위해 자동 요청을 다시 보내지 않았습니다.');
      }
      throw new Error('Photo Bridge 태그 요청의 출력 결과를 확인하지 못했습니다. 사진은 보존했으며 자동으로 다시 보내지 않았습니다.');
    } finally {
      clearTimeout(timer);
      upstream?.removeEventListener('abort', cancel);
    }
  })();
}

export async function getPhotoBridgeTagTemplate(fetchImpl?: TagBridgeFetch): Promise<{
  template: PhotoBridgeTagTemplate; mode: PhotoBridgeTagMode; hardwareVerified: false;
}> {
  const session = readPhotoBridgeConnectionSession();
  if (!session) throw new Error('Photo Bridge에 연결해야 운영 템플릿을 읽을 수 있습니다.');
  const result = await tagBridgeRequest<unknown>('/v1/tag-template', { method: 'GET' }, fetchImpl);
  if (result === null) throw new Error('Photo Bridge 태그 템플릿을 찾을 수 없습니다.');
  if (!isTagRecord(result) || result.mode !== session.mode || result.hardwareVerified !== false) {
    throw new Error('Photo Bridge 태그 템플릿의 모드·실물 검증 응답을 확인할 수 없습니다.');
  }
  return {
    template: validatePhotoBridgeTagTemplate(result.template),
    mode: session.mode,
    hardwareVerified: false,
  };
}

export async function confirmPhotoBridgeIntakePhoto(
  request: PhotoBridgePhotoConfirmationRequest,
  fetchImpl?: TagBridgeFetch,
): Promise<PhotoBridgePhotoConfirmation> {
  const session = readPhotoBridgeConnectionSession();
  if (!session) throw new Error('Photo Bridge에 연결해야 확인된 사진 증거를 저장할 수 있습니다.');
  if (typeof request.orderId !== 'string' || !request.orderId.trim() ||
      typeof request.garmentId !== 'string' || !request.garmentId.trim() ||
      typeof request.photoRequestId !== 'string' || !request.photoRequestId.trim() ||
      request.staffConfirmed !== true || !['saved', 'simulated'].includes(request.photoStatus) ||
      (request.photoPath !== undefined &&
        (!request.photoPath.trim() || request.photoPath.length > 1024)) ||
      (request.photoStatus === 'saved' &&
        (!request.photoPath || !request.photoTimestamp ||
          !Number.isFinite(Date.parse(request.photoTimestamp)))) ||
      (request.photoTimestamp !== undefined && !Number.isFinite(Date.parse(request.photoTimestamp)))) {
    throw new Error('직원이 확인해 주문에 저장한 같은 의류의 사진 증거만 확인할 수 있습니다.');
  }
  const result = await tagBridgeRequest<unknown>(
    '/v1/tag-jobs/photo-confirmations',
    {
      method: 'POST',
      body: JSON.stringify(request),
    },
    fetchImpl,
  );
  if (!isTagRecord(result) || result.orderId !== request.orderId ||
      result.garmentId !== request.garmentId || result.photoRequestId !== request.photoRequestId ||
      result.mode !== session.mode || result.photoVerified !== (session.mode === 'STORE')) {
    throw new Error('Photo Bridge가 사진 확인 결과의 주문·의류·요청·모드 증거를 확인하지 못했습니다.');
  }
  return {
    orderId: request.orderId,
    garmentId: request.garmentId,
    photoRequestId: request.photoRequestId,
    mode: session.mode,
    photoVerified: result.photoVerified,
  };
}

export async function requestPhotoBridgeTagJob(
  request: PhotoBridgeTagJobRequest,
  kind: 'auto' | 'reprint',
  fetchImpl?: TagBridgeFetch,
): Promise<PhotoBridgeTagJob> {
  if (typeof request.requestId !== 'string' || !request.requestId.trim() ||
      typeof request.orderId !== 'string' || !request.orderId.trim() ||
      typeof request.garmentId !== 'string' || !request.garmentId.trim() ||
      typeof request.photoRequestId !== 'string' || !request.photoRequestId.trim() ||
      request.staffConfirmed !== true || !['saved', 'simulated'].includes(request.photoStatus) ||
      request.copies !== 1 ||
      (request.photoPath !== undefined && (!request.photoPath.trim() || request.photoPath.length > 1024)) ||
      (request.photoStatus === 'saved' && (!request.photoPath || !request.photoTimestamp ||
        !Number.isFinite(Date.parse(request.photoTimestamp)))) ||
      (kind === 'auto' && request.manual === true) ||
      request.tag.orderId !== request.orderId || request.tag.garmentId !== request.garmentId ||
      request.tag.barcodeValue !== request.garmentId ||
      !Number.isInteger(request.tag.sequence) || request.tag.sequence < 1 ||
      !Number.isInteger(request.tag.totalSequence) || request.tag.totalSequence < request.tag.sequence) {
    throw new Error('사진이 확인된 같은 주문의 태그 요청만 TEST/PENDING으로 전달할 수 있습니다.');
  }
  const body: PhotoBridgeTagJobRequest = kind === 'reprint'
    ? { ...request, manual: true }
    : request;
  if (kind === 'reprint') delete body.alreadyPrinted;
  const result = await tagBridgeRequest<unknown>(
    kind === 'auto' ? '/v1/tag-jobs/auto' : '/v1/tag-jobs/reprint',
    { method: 'POST', body: JSON.stringify(body) },
    fetchImpl,
    false,
    request.renderedTag ? 40000 : 3000,
  );
  if (result === null) throw new Error('태그 작업 결과가 없어 자동으로 출력 요청을 재전송하지 않았습니다.');
  const job = validatePhotoBridgeTagJob(result);
  const session = readPhotoBridgeConnectionSession();
  if (job.orderId !== request.orderId || job.garmentId !== request.garmentId ||
      (job.barcodeValue !== undefined && job.barcodeValue !== request.tag.barcodeValue) ||
      job.mode !== session?.mode || job.automatic !== (kind === 'auto') ||
      (kind === 'reprint' && job.requestId !== request.requestId)) {
    throw new Error('태그 요청 응답의 garmentId·주문·모드·매수가 요청과 일치하지 않습니다. 실물 인쇄로 표시하지 않았습니다.');
  }
  return job;
}

export async function getPhotoBridgeTagJob(garmentId: string, fetchImpl?: TagBridgeFetch): Promise<PhotoBridgeTagJob | null> {
  const value = await tagBridgeRequest<unknown>(
    `/v1/tag-jobs/${encodeURIComponent(garmentId)}`, { method: 'GET' }, fetchImpl, true,
  );
  if (value === null) return null;
  const job = validatePhotoBridgeTagJob(value);
  const session = readPhotoBridgeConnectionSession();
  if (job.garmentId !== garmentId || job.mode !== session?.mode) {
    throw new Error('저장된 태그 요청이 현재 의류·모드에 맞지 않거나 출력 여부를 검증할 수 없습니다.');
  }
  return job;
}

/** Session credentials are intentionally never persisted beyond this browser tab. */
export function readPhotoBridgeSession(): PhotoBridgeSession | null {
  return readOperationalPhotoBridgeSession();
}

export function setPhotoBridgeSessionToken(token: string): void {
  setPhotoBridgeConnectionSession(token, 'STORE');
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const session = readPhotoBridgeSession();
  if (!session) throw new Error('Windows 사진 도우미 토큰을 먼저 입력해 주세요.');
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'X-K99-Bridge-Token': session.token,
        ...init.headers,
      },
    });
  } catch {
    throw new Error('Windows 사진 도우미에 연결할 수 없습니다. Windows PC와 로컬 도우미 상태를 확인해 주세요.');
  }
  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(`Windows 사진 도우미 요청 실패 (${response.status})${detail ? `: ${detail.slice(0, 300)}` : ''}`);
  }
  try {
    return await response.json() as T;
  } catch {
    throw new Error('Windows 사진 도우미가 올바르지 않은 응답을 반환했습니다.');
  }
}

export async function getPhotoSettings(): Promise<PhotoSettings> {
  const settings = await withPhotoReadDeadline((signal) =>
    request<PhotoSettings>('/v1/settings', { method: 'GET', signal }));
  // Legacy helpers return null roots before their first configuration.
  settings.sourceRoot ??= '';
  settings.destinationRoot ??= '';
  if (typeof settings.sourceRoot !== 'string' || typeof settings.destinationRoot !== 'string'
    || typeof settings.configured !== 'boolean') {
    throw new Error('Windows 사진 도우미 설정 응답 형식이 올바르지 않습니다.');
  }
  return settings;
}

export async function savePhotoSettings(sourceRoot: string, destinationRoot: string): Promise<PhotoSettings> {
  const { validateWindowsPhotoRoot } = await import('./photo-storage');
  const body = {
    sourceRoot: validateWindowsPhotoRoot(sourceRoot),
    destinationRoot: validateWindowsPhotoRoot(destinationRoot),
  };
  const settings = await request<PhotoSettings>('/v1/settings', {
    method: 'PUT',
    body: JSON.stringify(body),
  });
  if (typeof settings.sourceRoot !== 'string' || typeof settings.destinationRoot !== 'string'
    || typeof settings.configured !== 'boolean') {
    throw new Error('Windows 사진 도우미 설정 저장 응답 형식이 올바르지 않습니다.');
  }
  return settings;
}

export async function registerPhotoOrder(order: ConfirmedOrder): Promise<{ orderId: string; folderPath: string }> {
  const result = await request<{ orderId: string; folderPath: string }>('/v1/orders', {
    method: 'POST',
    body: JSON.stringify({
      orderId: order.id,
      intakeAt: order.intakeAt,
      customerName: order.customerName,
      phoneLast4: order.customerPhone.replace(/\D/g, '').slice(-4),
      garmentIds: (order.garments ?? []).map((garment) => garment.garmentId),
    }),
  });
  if (typeof result.orderId !== 'string' || typeof result.folderPath !== 'string')
    throw new Error('Windows 사진 도우미가 올바르지 않은 주문 등록 응답을 반환했습니다.');
  return result;
}

export async function armPhoto(orderId: string, garmentId: string, requestId: string): Promise<PhotoArmStatus> {
  const result = await request<PhotoArmStatus>('/v1/arms', {
    method: 'POST',
    body: JSON.stringify({ requestId, orderId, garmentId }),
  });
  if (result.status !== 'armed') throw new Error('Windows 사진 도우미가 촬영 준비를 확인하지 못했습니다.');
  return result;
}

export async function getArmPhoto(requestId: string): Promise<PhotoArmStatus> {
  const result = await request<PhotoArmStatus>(`/v1/arms/${encodeURIComponent(requestId)}`, { method: 'GET' });
  if (!['armed', 'saved', 'failed'].includes(result.status)
    || typeof result.requestId !== 'string' || typeof result.orderId !== 'string'
    || typeof result.garmentId !== 'string') {
    throw new Error('Windows 사진 도우미가 올바르지 않은 촬영 상태 응답을 반환했습니다.');
  }
  if (result.status === 'failed') throw new Error(result.error || 'Windows 사진 도우미에서 사진 저장에 실패했습니다.');
  if (result.status === 'saved' && (!result.photoPath || !result.photoTimestamp))
    throw new Error('도우미가 저장 완료를 보고했지만 사진 경로 또는 촬영 시각이 없습니다.');
  return result;
}

/** A probe reports availability only; failures are intentionally represented as false. */
export async function checkPassivePhotoBridge(): Promise<boolean> {
  if (!readPhotoBridgeSession()) return false;
  try {
    await getPhotoSettings();
    return true;
  } catch {
    return false;
  }
}