import { useRef, useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import { previewBackup } from './backup-preview';
import { createManagementExport } from './management-export';

export function BackupPreview({ orders }: { orders: ConfirmedOrder[] }) {
  const [result, setResult] = useState<ReturnType<typeof previewBackup>>([]);
  const [error, setError] = useState('');
  const [consent, setConsent] = useState(false);
  const sequence = useRef(0);
  return <details><summary>주문 JSON 백업 · 복구 미리보기</summary>
    <p>실제 복구·자동 병합 기능은 없습니다. 사진 파일과 브리지 출력 장부는 별도로 백업하세요.</p>
    <label><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} />개인정보 포함·사진 파일 미포함을 확인했습니다.</label>
    <button disabled={!consent} onClick={() => {
      const url = URL.createObjectURL(new Blob([createManagementExport(orders).json], { type: 'application/json' }));
      const a = document.createElement('a'); a.href = url; a.download = 'k99-orders-backup.json'; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }}>주문 JSON 백업</button>
    <label>백업 파일 미리보기<input type="file" accept=".json,application/json" onChange={async e => {
      const token = ++sequence.current;
      setError(''); setResult([]);
      const file = e.target.files?.[0]; if (!file) return;
      try {
        if (file.size > 10_000_000) throw new Error('10MB 이하의 백업 파일을 선택하세요.');
        const text = await file.text();
        if (token === sequence.current) setResult(previewBackup(text, orders));
      } catch (cause) { if (token === sequence.current) setError(cause instanceof Error ? cause.message : '파일 확인 실패'); }
    }} /></label>
    {error && <p role="alert">{error}</p>}
    <p role="status">비교 {result.length}건 · 미리보기이며 저장하지 않았습니다.</p>
    <ul>{result.map(row => <li key={row.id}>{row.id} · {row.status} · 의류 {row.garments}벌</li>)}</ul>
  </details>;
}
