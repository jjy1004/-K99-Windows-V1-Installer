import {useState} from 'react';
import {ImeTextInput} from './ImeTextInput';
export function FreeGarmentEntry({onAdd,disabled}:{onAdd:(name:string,price:number)=>void;disabled:boolean}){
  const [name,setName]=useState(''),[price,setPrice]=useState(''),[error,setError]=useState('');
  return <section className="staff-card" aria-label="기타 자유 기록" style={{padding:14}}>
    <h2 style={{fontSize:22,fontWeight:800}}>기타 (자유 기록)</h2>
    <label>세탁물 품목명<ImeTextInput value={name} maxLength={100} onValue={setName}/></label>
    <label>세탁비 (1벌)<input type="number" min={1} max={100000000} value={price} onChange={e=>setPrice(e.target.value)}/></label>
    <button type="button" className="add-item-button" disabled={disabled} onClick={()=>{
      const p=Number(price);
      if(!name.trim()||!Number.isSafeInteger(p)||p<1||p>100000000){setError('품목명과 1원 이상 세탁비를 입력하세요.');return;}
      onAdd(name.trim(),p);setName('');setPrice('');setError('');
    }}>+ 자유 품목 추가</button>
    {error&&<p role="alert">{error}</p>}
  </section>;
}
