import {useState} from 'react';
import {Plus} from 'lucide-react';
import {ImeTextInput} from './ImeTextInput';
import './free-garment.css';
export function FreeGarmentEntry({onAdd,disabled}:{onAdd:(name:string,price:number)=>void;disabled:boolean}){
  const [name,setName]=useState(''),[price,setPrice]=useState(''),[error,setError]=useState('');
  const add=()=>{
    const p=Number(price);
    if(!name.trim()||!Number.isSafeInteger(p)||p<1||p>100000000){setError('품목명과 1원 이상 금액을 입력하세요.');return;}
    try{onAdd(name.trim(),p);setName('');setPrice('');setError('');}
    catch(e){setError(e instanceof Error?e.message:'품목을 추가하지 못했습니다.');}
  };
  return <section className="fge" aria-label="기타 자유 기재" data-testid="free-garment-entry">
    <h2>기타 (자유 기재)</h2>
    <div className="fge-row">
      <label className="fge-field"><span className="sr-only">세탁물 품목명</span>
        <ImeTextInput value={name} maxLength={100} onValue={setName} placeholder="세탁물 품목명을 적으세요" data-testid="input-free-name"/></label>
      <label className="fge-field"><span className="sr-only">금액</span>
        <input type="text" inputMode="numeric" value={price} placeholder="금액 입력 (예: 10000)" data-testid="input-free-price"
          onChange={e=>setPrice(e.target.value.replace(/\D/g,'').slice(0,9))} onKeyDown={e=>{if(e.key==='Enter')add();}}/></label>
    </div>
    <button type="button" className="fge-add" disabled={disabled} onClick={add} data-testid="button-free-add"><Plus aria-hidden/>자유 품목 추가</button>
    {error&&<p role="alert" className="fge-err">{error}</p>}
  </section>;
}
