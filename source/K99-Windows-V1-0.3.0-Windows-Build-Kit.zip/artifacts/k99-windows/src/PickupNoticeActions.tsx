import { useCallback, useEffect, useRef, useState, type KeyboardEvent, type ReactNode, type RefObject } from 'react';
import { useLocation } from 'wouter';
import { BarChart3, Bell, CheckCircle2, ClipboardCopy, PackageCheck, RefreshCw, Users, X } from 'lucide-react';
import { listPickupNotices, markPickupNotice, type NoticeCard, type NoticeKind, type NoticeList, type NoticeOrder } from './pickup-notices-client';
import './pickup-notice-actions.css';

/*
 * 안내 문자 도우미 — 이 화면은 문자를 "작성·복사"만 합니다. 실제 SMS는 발송하지 않습니다.
 * '발송 완료 기록'은 직원이 외부(휴대폰 등)로 직접 보낸 뒤 확인을 거쳐서만 서버에 기록됩니다.
 */

const REFRESH_MS = 30_000;
type DesktopEvents = { k99Desktop?: { onChanged?: (cb: () => void) => (() => void) | void } };
const errText = (e: unknown, f: string) => (e instanceof Error && e.message ? e.message : f);
const when = (v: string | null) => {
  if (!v) return '';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', dateStyle: 'short', timeStyle: 'short', hour12: false });
};

/** Shared live loader for pickup notices. */
function usePickupNotices(enabled = true) {
  const [data, setData] = useState<NoticeList | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(enabled);
  const seq = useRef(0);
  const alive = useRef(true);
  const load = useCallback(() => {
    const id = ++seq.current;
    setLoading(true);
    listPickupNotices().then((r) => { if (alive.current && id === seq.current) { setData(r); setError(''); } })
      .catch((e) => { if (alive.current && id === seq.current) setError(errText(e, '안내 목록을 불러오지 못했습니다.')); })
      .finally(() => { if (alive.current && id === seq.current) setLoading(false); });
  }, []);
  const apply = useCallback((r: NoticeList) => { seq.current++; setData(r); setError(''); setLoading(false); }, []);
  useEffect(() => {
    alive.current = true;
    if (!enabled) return () => { alive.current = false; };
    load();
    const onVis = () => { if (document.visibilityState === 'visible') load(); };
    const timer = window.setInterval(onVis, REFRESH_MS);
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onVis);
    window.addEventListener('k99-equipment-changed', load);
    let off: (() => void) | void = undefined;
    try { off = (window as unknown as DesktopEvents).k99Desktop?.onChanged?.(load); } catch { off = undefined; }
    return () => {
      alive.current = false;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', onVis);
      window.removeEventListener('k99-equipment-changed', load);
      if (typeof off === 'function') off();
    };
  }, [load, enabled]);
  return { data, error, loading, load, apply };
}

function useFocusReturn(ref: RefObject<HTMLElement | null>) {
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    return () => { prev?.focus?.(); };
  }, [ref]);
}

function trapTab(e: KeyboardEvent<HTMLElement>, root: HTMLElement | null) {
  if (e.key !== 'Tab' || !root) return;
  const f = Array.from(root.querySelectorAll<HTMLElement>('button:not(:disabled),textarea,input,[tabindex="0"]'));
  if (!f.length) return;
  const first = f[0], last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}
const inAutocomplete = (t: EventTarget | null) =>
  t instanceof HTMLElement && !!t.closest('[role="listbox"],[role="combobox"],[aria-expanded="true"]');

function Modal({ title, onClose, children, footer, testId, wide }: {
  title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; testId: string; wide?: boolean;
}) {
  const box = useRef<HTMLDivElement>(null);
  useFocusReturn(box);
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape' && !inAutocomplete(e.target)) { e.stopPropagation(); e.preventDefault(); onClose(); return; }
    trapTab(e, box.current);
  };
  return <div className="pn-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }} data-testid={`backdrop-${testId}`}>
    <div ref={box} className={`pn-modal${wide ? ' wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}
      onKeyDown={onKey} data-testid={`modal-${testId}`}>
      <header className="pn-modal-head">
        <h2>{title}</h2>
        <button type="button" className="pn-x" aria-label="닫기" onClick={onClose} data-testid={`button-close-${testId}`}><X /></button>
      </header>
      <div className="pn-modal-body">{children}</div>
      {footer && <footer className="pn-modal-foot">{footer}</footer>}
    </div>
  </div>;
}

const PLACEHOLDER = /○|\{[^}]*\}|\[[^\]]*\]|__+/;

function NoticeMessageModal({ order, onClose, onMarked }: { order: NoticeOrder; onClose: () => void; onMarked: (r: NoticeList) => void }) {
  // Drafts live for the life of this modal, which is keyed by orderId: 30s refreshes keep them, a different order resets them.
  const [drafts, setDrafts] = useState<Record<string, string>>(() => Object.fromEntries(order.cards.map((c) => [c.kind, c.text])));
  const [copyMsg, setCopyMsg] = useState<{ kind: NoticeKind; ok: boolean; text: string } | null>(null);
  const [confirming, setConfirming] = useState<{ kind: NoticeKind; title: string; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const busyRef = useRef(false);
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  const draftOf = (c: NoticeCard) => (c.sentAt ? c.text : drafts[c.kind] ?? c.text);
  const safeClose = () => { if (!busyRef.current) onClose(); };

  const copy = async (c: NoticeCard) => {
    const text = draftOf(c);
    try {
      if (!navigator.clipboard?.writeText) throw new Error('이 환경은 클립보드 복사를 지원하지 않습니다.');
      await navigator.clipboard.writeText(text);
      if (alive.current) setCopyMsg({ kind: c.kind, ok: true, text: '복사했습니다. 외부 문자앱에 붙여넣어 보내세요.' });
    } catch (e) { if (alive.current) setCopyMsg({ kind: c.kind, ok: false, text: `복사 실패: ${errText(e, '클립보드 접근이 거부되었습니다.')} 직접 선택해 복사하세요.` }); }
  };
  const mark = async () => {
    const snap = confirming;
    if (!snap || busyRef.current || !snap.text.trim()) return;
    busyRef.current = true; setBusy(true); setErr('');
    try {
      const r = await markPickupNotice(order.orderId, snap.kind, snap.text);
      onMarked(r); // always deliver result to parent, even if unmounted
      if (alive.current) setConfirming(null);
    } catch (e) { if (alive.current) setErr(errText(e, '발송 완료 처리에 실패했습니다.')); }
    finally { busyRef.current = false; if (alive.current) setBusy(false); }
  };

  return <Modal title={`${order.customerName || '-'} 님 안내 문안`} onClose={safeClose} testId="notice-message" wide
    footer={<>
      <p className="pn-warn" data-testid="text-placeholder-warning">
        이 프로그램은 문자를 보내지 않습니다. 외부로 보내기 전 ○ 표시 등 빈칸과 금액·날짜를 반드시 확인해 채우세요.
      </p>
      <div className="pn-foot-actions">
        <button type="button" onClick={safeClose} disabled={busy} data-testid="button-back-notice-list">목록으로</button>
      </div>
    </>}>
    {err && <p className="pn-alert" role="alert" data-testid="status-mark-error">{err}</p>}
    {confirming && <div className="pn-confirm" role="alertdialog" aria-label="외부 발송 확인" data-testid="dialog-confirm-external"
      onKeyDown={(e) => { if (e.key === 'Escape') { e.stopPropagation(); if (!busy) setConfirming(null); } }}>
      <strong>실제로 외부 발송하셨습니까?</strong>
      <p>이 버튼은 문자를 보내지 않습니다. 휴대폰 등으로 아래 문안을 이미 보낸 경우에만 "{confirming.title}"을(를) 발송 완료로 기록합니다.</p>
      <pre className="pn-snap" data-testid="text-confirm-snapshot">{confirming.text}</pre>
      <div className="pn-foot-actions">
        <button type="button" autoFocus onClick={() => setConfirming(null)} disabled={busy} data-testid="button-cancel-confirm">아니요, 아직</button>
        <button type="button" className="pn-primary" onClick={mark} disabled={busy} data-testid="button-confirm-external">
          {busy ? '기록 중…' : '네, 보냈습니다 — 기록'}</button>
      </div>
    </div>}
    <div className="pn-msg-cards">
      {order.cards.map((c) => {
        const text = draftOf(c);
        const sent = !!c.sentAt;
        return <section key={c.kind} className={`pn-msg-card${sent ? ' sent' : ''}${c.recommended && !sent ? ' rec' : ''}`}
          aria-label={c.title} data-testid={`card-notice-${c.kind}`}>
          <header className="pn-msg-head">
            <span className="pn-msg-title">{c.title}</span>
            {sent ? <span className="pn-badge done" data-testid={`status-sent-${c.kind}`}>{c.sentKind && c.sentKind !== c.kind ? '다른 완료 안내로 발송 완료' : '발송 완료'} · {when(c.sentAt)}</span>
              : c.recommended ? <span className="pn-badge rec">오늘 발송 권장</span>
                : !c.canMark ? <span className="pn-badge off">아직 시기 아님 · 미리보기</span> : <span className="pn-badge">발송 가능</span>}
          </header>
          <textarea value={text} disabled={sent} aria-label={`${c.title} 문안`} rows={8}
            onChange={(e) => { const v = e.target.value; setDrafts((d) => ({ ...d, [c.kind]: v })); if (copyMsg?.kind === c.kind) setCopyMsg(null); }}
            data-testid={`input-notice-text-${c.kind}`} />
          {!sent && PLACEHOLDER.test(text) && <p className="pn-alert soft" role="status">○ 등 빈칸이 남아 있습니다. 직접 채운 뒤 보내세요.</p>}
          {copyMsg?.kind === c.kind && <p className={`pn-alert ${copyMsg.ok ? 'ok' : ''}`} role={copyMsg.ok ? 'status' : 'alert'} data-testid={`status-copy-${c.kind}`}>{copyMsg.text}</p>}
          <div className="pn-card-actions">
            <button type="button" onClick={() => copy(c)} disabled={!text} data-testid={`button-copy-${c.kind}`}><ClipboardCopy /> 문안 복사</button>
            <button type="button" className="pn-primary" disabled={sent || !c.canMark || busy || !text.trim()}
              onClick={() => { setErr(''); setConfirming({ kind: c.kind, title: c.title, text }); }} data-testid={`button-mark-${c.kind}`}>
              <CheckCircle2 /> 발송 완료 처리</button>
          </div>
        </section>;
      })}
    </div>
  </Modal>;
}

/** Reusable notice workspace (list + message modal). */
export function PickupNoticeWorkspace({ notices }: { notices?: ReturnType<typeof usePickupNotices> }) {
  const own = usePickupNotices(!notices);
  const n = notices ?? own;
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const orders = n.data?.orders ?? [];
  const selected = orders.find((o) => o.orderId === selectedId) ?? null;
  useEffect(() => { if (selectedId && n.data && !n.data.orders.some((o) => o.orderId === selectedId)) setSelectedId(null); }, [n.data, selectedId]);

  return <div className="pn-work" data-testid="workspace-pickup-notices">
    <div className="pn-work-bar">
      <span data-testid="text-notice-asof">{n.data ? `기준 ${when(n.data.asOf)} · 30초마다 갱신` : '불러오는 중'}</span>
      <button type="button" onClick={n.load} disabled={n.loading} data-testid="button-refresh-notices"><RefreshCw className={n.loading ? 'spin' : ''} /> 새로고침</button>
    </div>
    {n.error && <div className="pn-alert" role="alert" data-testid="status-notice-error">
      <span>{n.error}</span><button type="button" onClick={n.load} data-testid="button-retry-notices">다시 시도</button></div>}
    {!n.data && n.loading ? <div className="pn-grid" aria-busy="true">{[0, 1, 2].map((i) => <i key={i} className="pn-skel" />)}</div>
      : n.data && orders.length === 0 ? <p className="pn-empty" data-testid="status-notice-empty">미출고 완료 세탁물이 없습니다.</p>
        : <ul className="pn-grid">{orders.map((o) => {
          const rec = o.cards.some((c) => c.recommended && !c.sentAt);
          return <li key={o.orderId}><button type="button" className={`pn-order${rec ? ' rec' : ''}`} onClick={() => setSelectedId(o.orderId)}
            aria-label={`${o.customerName} ${o.customerPhone} 안내 문구 열기`} data-testid={`card-order-${o.orderId}`}>
            <span className="pn-order-top"><strong>{o.customerName || '-'}</strong>{rec && <span className="pn-badge rec">오늘 발송 권장</span>}</span>
            <span className="pn-mono">{o.customerPhone || '-'}</span>
            <span className="pn-facts"><span>접수 {o.intakeDate || '-'}</span><span>{o.itemCount}점</span><span className="pn-days">{o.elapsedDays}일 경과</span></span>
          </button></li>;
        })}</ul>}
    {selected && <NoticeMessageModal key={selected.orderId} order={selected} onClose={() => setSelectedId(null)}
      onMarked={(r) => { n.apply(r); n.load(); }} />}
  </div>;
}

export function PickupNoticeActions({ onSales, onCustomers }: { onSales: () => void; onCustomers: () => void }) {
  const notices = usePickupNotices();
  const [, navigate] = useLocation();
  const [open, setOpen] = useState(false);
  const count = notices.data?.recommendedCount;
  const items: { key: string; icon: ReactNode; title: string; desc: ReactNode; run: () => void; hot?: boolean }[] = [
    { key: 'today', icon: <Bell />, title: '오늘의 할 일', hot: !!count, run: () => setOpen(true),
      desc: notices.error && count === undefined ? '안내 목록 연결 실패 · 눌러서 확인'
        : count === undefined ? '불러오는 중…' : <>미출고 안내 필요 <b data-testid="text-notice-count">{count}건</b>{notices.error ? ' · 갱신 실패, 이전 값' : ''}</> },
    { key: 'pickup', icon: <PackageCheck />, title: '출고 대기 관리', desc: '오늘 운영 화면으로 이동', run: () => navigate('/management/today') },
    { key: 'sales', icon: <BarChart3 />, title: '정산 · 매출 분석', desc: '월별 표로 바로 이동', run: onSales },
    { key: 'customers', icon: <Users />, title: '고객 이력 관리', desc: '고객 검색으로 이동', run: onCustomers },
  ];
  return <>
    <nav className="pn-actions" aria-label="빠른 작업">
      {items.map((it) => <button key={it.key} type="button" className={`pn-action${it.hot ? ' hot' : ''}`} onClick={it.run} data-testid={`button-action-${it.key}`}>
        <span className="pn-action-icon" aria-hidden="true">{it.icon}</span>
        <strong>{it.title}</strong><span aria-live={it.key === 'today' ? 'polite' : undefined}>{it.desc}</span>
      </button>)}
    </nav>
    {open && <Modal title="미출고 안내 — 오늘의 할 일" onClose={() => setOpen(false)} testId="today-notices" wide
      footer={<p className="pn-warn">문자는 자동 발송되지 않습니다. 빈칸·금액·날짜를 확인한 뒤 외부로 직접 보내고 기록하세요.</p>}>
      <PickupNoticeWorkspace notices={notices} />
    </Modal>}
  </>;
}
