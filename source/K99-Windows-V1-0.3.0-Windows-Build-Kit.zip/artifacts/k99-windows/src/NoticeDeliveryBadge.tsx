import {deliveryTime, useNoticeDelivery} from './notice-delivery-state';
import './notice-delivery.css';

export function NoticeDeliveryBadge({orderId, templateIds, compact = false}: {
  orderId?: string; templateIds?: readonly string[]; compact?: boolean;
}) {
  const state = useNoticeDelivery(orderId, templateIds);
  if (state.kind === 'none') return state.failed
    ? <span className="notice-delivery-badge" data-state="unknown">발송 기록 확인 필요</span> : null;
  const clickCompleted=state.kind==='sent'&&state.completionSource==='button-click';
  const label = state.kind === 'sent' ? clickCompleted
    ? `${state.channel==='kakao-clipboard'?'카카오톡':'문자'} 발송 완료`
    : '✅ 메시지 발송됨' : '발송 준비됨';
  const title = `${label} · ${deliveryTime(state.at)} · ${state.kind === 'sent'
    ? clickCompleted?'발송 버튼 클릭 기준 기록 · 외부 앱 실제 전송 미확인'
      : `직원이 외부 전송 확인${state.summaryOnly ? ' · 요약 문자만 확인' : ' · 전체 문구 확인'}`
    : 'QR·복사 준비 기록이며 실제 발송 완료가 아닙니다.'}${state.preparingAgain ? ' · 재발송 준비 중' : ''}${state.failed ? ' · 최신 기록 재확인 필요' : ''}`;
  return <span className="notice-delivery-badge" data-state={state.kind} data-testid={`notice-status-${orderId}`}
    title={title} aria-label={title}>
    {compact ? state.kind === 'sent' ? '✅ 발송됨' : '준비됨' : label}
    <time dateTime={state.at}>{deliveryTime(state.at)}</time>
  </span>;
}
