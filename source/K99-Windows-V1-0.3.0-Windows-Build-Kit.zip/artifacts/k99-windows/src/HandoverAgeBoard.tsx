import {Archive,ArrowLeft,CalendarClock,CalendarRange,Hourglass,type LucideIcon} from 'lucide-react';
import type {ConfirmedOrder} from './order-record';
import {HANDOVER_AGE_BANDS,handoverIntakeDate,type HandoverAgeGroups,type HandoverAgeSelection} from './handover-age';
import {isUnpaidCustomerJob} from './customer-job-sort';
import {NoticeDeliveryBadge} from './NoticeDeliveryBadge';
import {RELEASE_NOTICES} from './NoticeQuickActions';

const BAND_ICONS:Record<string,LucideIcon>={'31-90':CalendarClock,'91-180':CalendarRange,'181-365':Hourglass,'366-730':Archive};
export function HandoverAgeTabs({value,groups,onChange}:{
  value:HandoverAgeSelection;groups:HandoverAgeGroups;onChange:(value:HandoverAgeSelection)=>void;
}){
  return <nav className="handover-age-tabs" aria-label="장기 보관 기간별 목록">
    {HANDOVER_AGE_BANDS.map(band=>{const Icon=BAND_ICONS[band.id]??Archive;return <button type="button" key={band.id} aria-pressed={value===band.id}
      data-testid={`handover-age-${band.id}`} onClick={()=>onChange(band.id)}>
      <i className="hat-icon" data-band={band.id}><Icon aria-hidden="true"/></i><span className="hat-label">{band.label}<small>{band.min}~{band.max}일</small></span>
      <b data-testid={`handover-age-count-${band.id}`}>{groups[band.id].length}<em>건</em></b>
    </button>;})}
  </nav>;
}
export function HandoverAgeReturn({onClick}:{onClick:()=>void}){
  return <button type="button" className="handover-age-return" onClick={onClick} data-testid="handover-age-return">
    <ArrowLeft aria-hidden="true"/>1개월 이내 기본 목록으로 돌아가기
  </button>;
}
export function ArchivedHandoverGrid({orders,onOpen,registerCard}:{
  orders:readonly ConfirmedOrder[];onOpen:(order:ConfirmedOrder)=>void;
  registerCard:(id:string,element:HTMLButtonElement|null)=>void;
}){
  return <div className="handover-archive-grid" data-testid="handover-archive-grid">{orders.map(order=>
    <button type="button" className="handover-archive-card" key={order.id}
      ref={element=>registerCard(order.id,element)} data-unpaid={isUnpaidCustomerJob(order)}
      data-testid={`archive-order-${order.id}`} aria-haspopup="dialog"
      aria-label={`${order.customerName} 주문 상세·메시지·출고 열기`} onClick={()=>onOpen(order)}>
      <span className="hac-top"><strong title={order.customerName}>{order.customerName}</strong><time>{handoverIntakeDate(order.intakeAt)}</time></span>
      <span className="hac-items" title={order.items.map(i=>`${i.displayNameKo} ${i.quantity}벌`).join(' · ')}>{order.items.map(i=>`${i.displayNameKo} ${i.quantity}벌`).join(' · ')}</span>
      <span className="hac-bottom">{isUnpaidCustomerJob(order)&&<b>후불</b>}<strong>{order.estimatedTotal.toLocaleString('ko-KR')}원</strong>
        <NoticeDeliveryBadge orderId={order.id} templateIds={RELEASE_NOTICES.map(([id])=>id)} compact/></span>
    </button>)}</div>;
}
