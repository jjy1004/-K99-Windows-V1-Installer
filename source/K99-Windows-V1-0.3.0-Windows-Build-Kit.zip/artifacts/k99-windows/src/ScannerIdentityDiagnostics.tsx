import React from 'react';
import type { ConfirmedOrder } from './order-record';
import { listGarments } from './garment-scanner';
import { compareScanText, describeScanText, type ScanDiagnostic } from './scanner-diagnostics';

function DiagnosticValue({label,value,testId}: {label:string;value:string;testId:string}) {
  const description=describeScanText(value);
  return <div className="scanner-diagnostic-value" data-testid={testId}>
    <strong>{label} · length={description.length}</strong>
    <code>{description.escaped}</code>
  </div>;
}

export default function ScannerIdentityDiagnostics({orders,selectedOrderId,onSelectOrder,lastScan}: {
  orders:ConfirmedOrder[];
  selectedOrderId:string;
  onSelectOrder:(id:string)=>void;
  lastScan:ScanDiagnostic|null;
}) {
  const selected=orders.find(order=>order.id===selectedOrderId);
  return <section className="scanner-identity-diagnostics" data-testid="scanner-identity-comparison">
    <h2>스캔 원문·저장된 현재 의류 ID 확인 <small>임시 진단</small></h2>
    <p>입력창이 비워져도 마지막 원문은 유지됩니다. 아래에서 비교할 실제 주문을 선택하세요. 주문 선택은 저장 데이터를 변경하지 않습니다.</p>
    <label>비교할 저장 주문
      <select value={selected ? selectedOrderId : ''} onChange={event=>onSelectOrder(event.target.value)}
        data-testid="select-scanner-diagnostic-order">
        <option value="">고객 검색에서 의류를 선택하거나 여기서 주문을 선택하세요</option>
        {orders.map(order=><option key={order.id} value={order.id}>
          {order.customerName} · {order.items.map(item=>item.displayNameKo).join(', ')} · {order.intakeAt} · {order.id}
        </option>)}
      </select>
    </label>
    {lastScan ? <>
      <DiagnosticValue label="scannedId 원문 (trim 전)" value={lastScan.raw} testId="scanner-diagnostic-raw" />
      <p className="scanner-diagnostic-meta">입력 경로: {lastScan.source} · 시각: {lastScan.capturedAt}<br />
        종료키 Enter: {lastScan.keyEvents.includes('Enter') ? '관찰됨 (문자열과 별도의 키 이벤트)' : '관찰되지 않음'} ·
        CR(\r): {lastScan.raw.includes('\r') ? '원문에 있음' : '원문에 없음'} ·
        LF(\n): {lastScan.raw.includes('\n') ? '원문에 있음' : '원문에 없음'}
      </p>
      {lastScan.pasteRaw !== null && <DiagnosticValue label="붙여넣기 원문 (입력창 개행 제거 전)"
        value={lastScan.pasteRaw} testId="scanner-diagnostic-paste" />}
      <details><summary>관찰한 키 이벤트 확인 (문자열 원문과 별개)</summary>
        <code>{JSON.stringify(lastScan.keyEvents)}</code>
      </details>
    </> : <p data-testid="scanner-diagnostic-waiting">아직 스캔한 원문이 없습니다. 태그를 스캔하면 여기에 그대로 표시됩니다.</p>}
    {selected ? <div data-testid="scanner-diagnostic-saved">
      <p><strong>{selected.customerName} · 접수 {selected.intakeAt}</strong><br />저장 orderId: <code>{selected.id}</code></p>
      {listGarments(selected).map(garment=><div key={garment.garmentId} className="scanner-diagnostic-garment">
        <p><strong>{garment.itemName} · {garment.sequence}/{garment.totalSequence}</strong></p>
        <DiagnosticValue label="저장 garmentId" value={garment.garmentId} testId="scanner-diagnostic-garment-id" />
        <DiagnosticValue label="저장 barcodeValue" value={garment.barcodeValue} testId="scanner-diagnostic-barcode-value" />
        {lastScan && <p data-testid="scanner-diagnostic-difference">{compareScanText(lastScan.raw,garment.garmentId)}</p>}
      </div>)}
    </div> : <p>비교 주문을 아직 선택하지 않았습니다. 이름만으로 최신 주문이나 의류 ID를 추측하지 않습니다.</p>}
    <small>length는 JavaScript 문자열 길이입니다. 공백=\u0020, 탭=\t, CR=\r, LF=\n으로 표시합니다.
      Enter 키를 임의로 CR/LF 문자로 붙이지 않습니다. 단일 줄 입력창이 개행을 제거할 수 있으므로 붙여넣기 원문은 별도로 표시합니다.
      진단 내용은 현재 화면에만 남으며 서버·주문 기록에 저장하지 않습니다.</small>
  </section>;
}
