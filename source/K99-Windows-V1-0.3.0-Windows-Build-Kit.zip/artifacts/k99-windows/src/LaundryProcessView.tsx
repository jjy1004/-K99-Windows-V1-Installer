import { IntakeIdentity } from './IntakeIdentity';
import { useEffect, useRef, useState } from 'react';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import type { FormEvent } from 'react';
import type { ConfirmedOrder } from './order-record';
import type { GarmentPhotoMetadata, GarmentRecord } from './garment-record';
import { currentOperations } from './order-operations';
import { canRecleanReadyGarment, garmentProcessStatus, laundryProgress, RECLEANING_REASONS } from './laundry-process';
import { currentStorageFee, koreaCalendarDate } from './storage-policy';
import type { LaundryAction } from './laundry-process';
import './laundry-process-view.css';
import { StoreName } from './StoreName';

type Props = {
  order: ConfirmedOrder;
  garments: GarmentRecord[];
  selectedGarmentId: string;
  onSelect: (id: string) => void;
  onLookup: (barcode: string) => void;
  onAction: (action: LaundryAction, reason?: string, detail?: string) => void;
  onCompletionPhoto: (garmentId: string) => void;
  onBack: () => void;
  error: string;
  notice: string;
  busy: boolean;
};

type ProcessAudit = GarmentRecord['auditEvents'][number] & {
  previousStatus?: string;
  newStatus?: string;
  source?: string;
};

const actionLabels: Record<LaundryAction, string> = {
  start: '세탁 시작',
  complete: '세탁 완료',
  inspect: '완성 검수',
  'qc-pass': '정상 완료',
  'qc-rewash': '재세탁 필요',
  'qc-hold': '추가 확인 필요',
  'resume-qc': '검수 재개',
  handover: '반출 완료',
  'handover-rewash': '재세탁 필요',
};

function availableActions(status: string, garment: GarmentRecord): LaundryAction[] {
  // Keep controls in lockstep with the transition table in laundry-process.
  if (status === '세탁 대기') return ['start'];
  if (status === '세탁 중') return ['complete'];
  if (status === '세탁 완료') return ['inspect'];
  if (status === '완성 검수') return garment.qcHoldReason ? ['resume-qc'] : ['qc-pass', 'qc-rewash', 'qc-hold'];
  if (status === '출고 대기') return ['handover', 'handover-rewash'];
  return []; // 접수/촬영/전문검수 단계는 이 화면에서 임의로 시작할 수 없음
}

function serviceName(service: GarmentRecord['serviceType']) {
  return ({
    general: '일반 세탁',
    premium: '프리미엄 세탁',
    'sneaker-general': '운동화 일반 세탁',
    'sneaker-premium': '운동화 프리미엄 세탁',
  })[service] ?? service;
}

function photoName(value: GarmentRecord['photoStatus']) {
  return ({
    'not-captured': '촬영 전',
    simulated: '촬영 전',
    saved: '사진 저장 기록',
    failed: '촬영 오류',
  })[value];
}

function tagName(value: GarmentRecord['tagStatus']) {
  return ({
    'not-generated': '태그 생성 전',
    simulated: '태그 생성 전',
    generated: '태그 생성 기록',
    'print-requested': '출력 요청 기록 (장치 미확인)',
    printed: '출력 기록 (장치 미확인)',
    failed: '태그 오류',
  })[value];
}

function workflowName(value: GarmentRecord['cleaningStatus']) {
  return ({ pending: '대기', 'in-progress': '진행 중', complete: '완료' })[value];
}

function displayDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('ko-KR');
}

export default function LaundryProcessView({
  order, garments, selectedGarmentId, onSelect, onLookup, onAction, onCompletionPhoto, onBack, error, notice, busy,
}: Props) {
  const [barcode, setBarcode] = useState('');
  const [photoTab, setPhotoTab] = useState<'compare' | 'intake' | 'completion'>('compare');
  const [pendingAction, setPendingAction] = useState<LaundryAction | null>(null);
  const [reason, setReason] = useState('');
  const [detail, setDetail] = useState('');
  const barcodeRef = useRef<HTMLInputElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);
  const selected = garments.find((garment) => garment.garmentId === selectedGarmentId);
  const progress = laundryProgress(order, garments);
  const readyCount = garments.filter((garment) => ['출고 대기', '반출 완료'].includes(garmentProcessStatus(order, garment))).length;
  const percent = progress.total ? Math.min(100, Math.max(0, Math.round(readyCount / progress.total * 100))) : 0;
  const status = selected ? garmentProcessStatus(order, selected) : '';
  const actions = selected ? availableActions(status, selected) : [];
  const operations = currentOperations(order);
  const storedGarments = garments.filter((garment) =>
    garment.handoverStatus !== 'complete' && garmentProcessStatus(order, garment) !== '반출 완료').length;
  const storageCharge = currentStorageFee({ intakeAt: order.intakeAt, totalQuantity: storedGarments }, new Date());
  const deliveryChoice = order.choices.deliveryRequested ? '배달' : order.choices.directPickup ? '직접 수령' : '수령 방법 확인 필요';
  const chargeTotal = order.inspection?.revisedPrice ?? order.estimatedTotal;
  const paidAmount = operations.paymentStatus === '환불' ? 0 : operations.paidAmount;
  const unpaidAmount = Math.max(0, chargeTotal - paidAmount);
  const handoverLocked = !operations.completedAt || !['매장수령완료', '배달완료'].includes(operations.stage);
  const processingLocked = Boolean(operations.completedAt) || !['매장입고', '세탁중', '세탁완료'].includes(operations.stage) || order.status !== '세탁 진행 승인';
  const recleaningLocked = !canRecleanReadyGarment(order);
  const actionLocked = (action: LaundryAction) => busy || Boolean(operations.cancelledAt) ||
    (action === 'handover' ? handoverLocked : action === 'handover-rewash' ? recleaningLocked : processingLocked);
  const requiresReason = pendingAction === 'qc-rewash' || pendingAction === 'qc-hold' || pendingAction === 'handover-rewash';
  const audit = [...(selected?.auditEvents ?? [])].sort((a, b) => b.at.localeCompare(a.at)) as ProcessAudit[];

  useEffect(() => { barcodeRef.current?.focus(); }, []);
  useEffect(() => { setPendingAction(null); setReason(''); setDetail(''); setPhotoTab('compare'); }, [selectedGarmentId]);
  useEffect(() => { if (pendingAction) cancelRef.current?.focus(); }, [pendingAction]);
  useEffect(() => {
    if (!pendingAction) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !busy) { setPendingAction(null); setReason(''); setDetail(''); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [pendingAction, busy]);

  function submitLookup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!barcode.trim() || busy) return;
    onLookup(barcode.trim());
    setBarcode('');
    // A lookup only selects a garment; it never advances the process.
  }

  function confirmAction(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!pendingAction || !selected || actionLocked(pendingAction) || !actions.includes(pendingAction) || (requiresReason && !reason.trim())) return;
    onAction(pendingAction, reason.trim() || undefined, detail.trim() || undefined);
    setPendingAction(null);
    setReason('');
    setDetail('');
  }

  const beforePhoto: GarmentPhotoMetadata | undefined = selected?.beforePhoto ?? (
    selected && (selected.photoStatus === 'saved' || selected.photoStatus === 'simulated')
      ? {
        garmentId: selected.garmentId,
        requestId: selected.captureRequestId ?? `legacy-${selected.garmentId}`,
        role: 'intake',
        status: selected.photoStatus,
        timestamp: selected.photoTimestamp ?? '',
        origin: 'legacy',
        ...(selected.photoStatus === 'saved' && selected.photoPath ? { path: selected.photoPath } : {}),
      } : undefined
  );
  const completionPhoto = selected?.completionPhoto;
  const completionPhotoEligible = ['세탁 완료', '완성 검수', '출고 대기', '반출 완료'].includes(status);
  const photoStatusName = (photo?: GarmentPhotoMetadata) => !photo
    ? '기록 없음'
    : photo.status === 'simulated' ? '실제 사진 없음' : '저장 확인 기록';
  const photoOriginName = (photo?: GarmentPhotoMetadata) => ({
    simulation: '브라우저 시뮬레이션',
    bridge: 'Local Bridge',
    legacy: '기존 기록 (출처 정보 없음)',
  } as const)[photo?.origin ?? 'legacy'];
  const photoTime = (photo?: GarmentPhotoMetadata) => photo?.timestamp
    ? displayDate(photo.timestamp) : '시간 정보 없음';
  const renderPhotoCard = (label: string, photo?: GarmentPhotoMetadata, testId?: string) => (
    <article className="laundry-process__photo-card" data-testid={testId}>
      <span className="laundry-process__photo-label">{label}</span>
      <strong>{photoStatusName(photo)}</strong>
      
      <small>기록 시각 · {photoTime(photo)}</small>
      {photo?.path && <code title={photo.path} hidden>{photo.path}</code>}
      
    </article>
  );

  return (
    <main className="laundry-process">
      <div className="laundry-process__wrap">
        <header className="laundry-process__top">
          <div className="laundry-process__brand"><StoreName /> <small>직원 작업</small></div>
          <span className="laundry-process__top-id" data-testid="text-process-order-id" hidden>{order.id}</span>
        </header>

        <div className="laundry-process__heading">
          <div>
            
            <h1>세탁 진행 관리</h1>
            <p>의류를 선택하고 지금 할 수 있는 작업 하나를 누르세요.</p>
          </div>
          <div className="laundry-process__customer">
            <span>접수 고객</span>
            <strong data-testid="text-process-customer-name"><IntakeIdentity order={order}/></strong>
            <small data-testid="text-process-phone-last4">연락처 끝 4자리 · {order.customerPhone.replace(/\D/g, '').slice(-4) || '미등록'}</small>
          </div>
        </div>

        <div className="laundry-process__orderline">
          
          <span>접수일 <b data-testid="text-process-intake-date">{displayDate(order.intakeAt)}</b></span>
          <span>서비스 <b>{order.choices.unitServiceLevels ? '세탁물별 선택 (의류 상세 확인)' : order.choices.serviceLevel === 'premium' ? '프리미엄' : '일반'}{garments.some((garment) => garment.serviceType.startsWith('sneaker-')) ? ' · 운동화 포함' : ''}</b></span>
          <span>주문 상태 <b>{orderDisplayStatus(order)}</b></span>
        </div>

        <div className="laundry-process__metrics" aria-label="공정 현황">
          <div className="laundry-process__metric"><span>전체 의류</span><strong data-testid="count-process-total">{progress.total}</strong><small>벌</small></div>
          <div className="laundry-process__metric"><span>진행 중</span><strong data-testid="count-process-in-progress">{progress.inProgress}</strong><small>벌</small></div>
          <div className="laundry-process__metric"><span>완료</span><strong data-testid="count-process-completed">{progress.completed}</strong><small>벌</small></div>
          <div className="laundry-process__metric"><span>반출 대기</span><strong data-testid="count-process-ready">{progress.readyForHandover}</strong><small>벌</small></div>
        </div>
        <div className="laundry-process__progress" role="progressbar" aria-label="출고 준비율" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}><span style={{ transform: `scaleX(${percent / 100})` }} /></div>

        {error && <div className="laundry-process__error" role="alert" data-testid="status-process-error">{error}</div>}
        {notice && <div className="laundry-process__notice" role="status" data-testid="status-process-notice">{notice}</div>}

        <div className="laundry-process__layout">
          <div className="laundry-process__column">
            <section className="laundry-process__panel" aria-label="바코드 조회">
              <div className="laundry-process__section-heading"><div><h2>바코드로 의류 찾기</h2></div></div>
              <div className="laundry-process__scan-box"><span aria-hidden="true" /><div><strong>조회 입력 대기</strong><small>아래 입력란에 초점을 둔 상태에서 키보드형 스캐너로 읽거나 직접 입력하세요.</small></div></div>
              <form className="laundry-process__lookup" onSubmit={submitLookup}>
                <input ref={barcodeRef} type="text" value={barcode} onChange={(event) => setBarcode(event.target.value)} placeholder="의류 태그 바코드 · Enter로 조회" aria-label="바코드 조회 값" autoComplete="off" spellCheck={false} data-testid="input-process-barcode" />
                <button type="submit" className="laundry-process__primary" disabled={busy || !barcode.trim()} data-testid="button-process-lookup">의류 조회</button>
              </form>
              <p className="laundry-process__hint">조회는 의류 선택만 수행합니다. 세탁 시작·완료·검수·반출은 오른쪽에서 별도로 확인해야 기록됩니다.</p>
            </section>

            <section className="laundry-process__panel" aria-label="전체 의류">
              <div className="laundry-process__section-heading"><div><h2>접수 의류 전체</h2></div><span>{garments.length}벌</span></div>
              {garments.length ? <div className="laundry-process__list">
                {garments.map((garment) => <button key={garment.garmentId} type="button" className="laundry-process__item" aria-current={selectedGarmentId === garment.garmentId} onClick={() => onSelect(garment.garmentId)} data-testid={`button-process-select-${garment.garmentId}`}>
                  <span className="laundry-process__number">{String(garment.sequence).padStart(2, '0')}</span>
                  <span><strong>{garment.itemName} {garment.tagNumber&&<b> · 태그 {garment.tagNumber}</b>}<span className="laundry-process__unit-count">{garment.unitIndex} / {order.items[garment.itemIndex - 1]?.quantity ?? garment.unitIndex}</span></strong></span>
                  <em data-testid={`status-process-garment-${garment.garmentId}`}>{garmentDisplayStatus(order, garment, garmentProcessStatus(order, garment))}</em>
                </button>)}
              </div> : <div className="laundry-process__empty">이 주문에 등록된 의류가 없습니다. 접수 내역을 확인해 주세요.</div>}
            </section>
          </div>

          <div className="laundry-process__column">
            <section className="laundry-process__panel" aria-label="선택 의류와 작업">
              <div className="laundry-process__section-heading"><div><h2>선택 의류 · 작업</h2></div>{selected && <span>{String(selected.sequence).padStart(2, '0')} / {String(garments.length).padStart(2, '0')}</span>}</div>
              {selected ? <>
                <div className="laundry-process__selected-title"><strong data-testid="text-process-selected-name">{selected.itemName}{selected.tagNumber&&` · 태그 ${selected.tagNumber}`}</strong><span data-testid="status-process-selected">{garmentDisplayStatus(order, selected, status)}</span></div>
                
                 <div hidden><code data-testid="text-process-selected-barcode">{selected.barcodeValue}</code></div>
                <div className="laundry-process__record"><span>서비스</span><strong>{serviceName(selected.serviceType)}</strong></div>
                <div className="laundry-process__record"><span>사진 / 태그</span><strong>{photoName(selected.photoStatus)} / {tagName(selected.tagStatus)}</strong></div>
                <section className="laundry-process__photos" aria-label="접수 및 완성 사진">
                  <div className="laundry-process__section-heading">
                    <div><h3>의류 사진 기록</h3></div>
                    </div>
                  <div className="laundry-process__photo-tabs" role="group" aria-label="사진 보기">
                    {([
                      ['intake', '접수 사진'],
                      ['completion', '완성 사진'],
                      ['compare', '전/후 비교'],
                    ] as const).map(([tab, label]) => <button key={tab} type="button" aria-pressed={photoTab === tab}
                      className={photoTab === tab ? 'laundry-process__primary' : 'laundry-process__button'}
                      onClick={() => setPhotoTab(tab)} data-testid={`button-process-photo-${tab}`}>{label}</button>)}
                  </div>
                  {photoTab === 'intake' && <div className="laundry-process__photo-grid">
                    {renderPhotoCard('접수 사진 · 원본', beforePhoto, 'status-process-before-photo')}
                  </div>}
                  {photoTab === 'completion' && <div className="laundry-process__photo-grid">
                    {renderPhotoCard('완성 사진 · 최신 기록', completionPhoto, 'status-process-completion-photo')}
                  </div>}
                  {photoTab === 'compare' && <div className="laundry-process__photo-grid">
                    {renderPhotoCard('전 · 접수 원본', beforePhoto, 'status-process-before-photo')}
                    {renderPhotoCard('후 · 완성 기록', completionPhoto, 'status-process-completion-photo')}
                  </div>}
                  <button type="button" hidden aria-hidden="true" tabIndex={-1} className="laundry-process__button laundry-process__completion-photo"
                    disabled={busy || !completionPhotoEligible} onClick={() => onCompletionPhoto(selected.garmentId)}
                    data-testid="button-process-completion-photo">
                    {busy ? '기록 중…' : completionPhoto ? '완성 사진 다시 기록' : '완성 사진 기록'}
                  </button>
                  
                </section>
                <div className="laundry-process__record"><span>세탁 / 검수</span><strong>{workflowName(selected.cleaningStatus)} / {workflowName(selected.inspectionStatus)}</strong></div>
                <div className="laundry-process__record"><span>완료 / 반출</span><strong>{workflowName(selected.completionStatus)} / {workflowName(selected.handoverStatus)}</strong></div>
                {(selected.rewashCount ?? 0) > 0 && <div className="laundry-process__record" data-testid="text-process-rewash-count"><span>재세탁 횟수</span><strong>재세탁 {selected.rewashCount}회</strong></div>}
                {selected.qcHoldReason && <div className="laundry-process__notice" role="status" data-testid="status-process-hold-reason">추가 확인 중 · {selected.qcHoldReason}</div>}
                <div className="laundry-process__action-heading">현재 상태에서 가능한 작업</div>
                {actions.length ? <div className="laundry-process__actions">
                   {actions.filter((action) => action !== 'handover').map((action) => <button key={action} type="button" className={action === 'qc-rewash' || action === 'qc-hold' || action === 'handover-rewash' ? 'laundry-process__button' : 'laundry-process__primary'} disabled={actionLocked(action)} onClick={() => { setReason(''); setDetail(''); setPendingAction(action); }} data-testid={`button-process-${action}`}>{actionLabels[action]}</button>)}
                </div> : <div className="laundry-process__empty">현재 상태에서 진행할 작업이 없습니다. 이력 또는 주문 상태를 확인해 주세요.</div>}
                 {actions.includes('handover') && <a className="laundry-process__primary" style={{ display:'inline-flex', alignItems:'center', padding:16, marginTop:16 }}
                   href={`${import.meta.env.BASE_URL}scan`} data-testid="button-process-open-scanner">완성 의류 스캔으로 이동</a>}
                {actions.some((action) => action !== 'handover' && action !== 'handover-rewash') && processingLocked && <p className="laundry-process__hint" data-testid="status-process-stage-lock">매장 입고 및 세탁 진행 승인 상태를 확인해 주세요. 이미 인도된 주문은 작업할 수 없습니다.</p>}
                {actions.includes('handover-rewash') && recleaningLocked && <p className="laundry-process__hint">재세탁은 실제 반출 전인 주문에서만 등록할 수 있습니다.</p>}
                {operations.cancelledAt && <p className="laundry-process__hint" data-testid="status-process-cancel-lock">취소된 주문은 공정을 진행할 수 없습니다.</p>}
                <p className="laundry-process__hint">각 작업은 확인 단계를 거쳐 한 벌에만 반영됩니다. 검수 재세탁·출고 대기 재세탁·보류에는 사유가 필요합니다.</p>
              </> : <div className="laundry-process__empty">왼쪽 목록에서 의류를 직접 선택하거나 바코드를 조회해 주세요. 선택만으로 공정은 변경되지 않습니다.</div>}
            </section>
            <section className="laundry-process__panel" hidden aria-label="작업 환경 안내">
              <div className="laundry-process__section-heading"><div><h2>시뮬레이션 안내</h2></div></div>
              <p className="laundry-process__hint">이 화면은 브라우저 기록을 이용한 공정 시뮬레이션입니다. 실제 스캐너 연결 상태를 확인하지 않으며 세탁 설비·프린터·메시지 발송 장치에 명령을 보내지 않습니다. 키보드형 바코드 입력은 이 입력란에 초점이 있을 때만 조회됩니다.</p>
            </section>
          </div>
        </div>

        <details className="laundry-process__panel laundry-process__audit" aria-label="선택 의류 작업 이력"><summary>작업 이력 보기 (관리용)</summary>
          <div className="laundry-process__section-heading"><div><h2>선택 의류 이력</h2></div><span>{audit.length}건</span></div>
          {selected ? audit.length ? <div className="laundry-process__audit-list">
            {audit.map((event, index) => <div className="laundry-process__audit-row" key={`${event.at}-${event.type}-${index}`} data-testid={`row-process-audit-${index}`}>
              <time dateTime={event.at}>{displayDate(event.at)}</time>
               <div><strong>{event.action ?? (event.type === 'laundry-process' ? '세탁 공정' : event.type)} · {event.status}</strong><small>{[event.details, event.rewashCycle && `재세탁 ${event.rewashCycle}회차`, event.reason && `사유: ${event.reason}`, event.detail && `상세: ${event.detail}`, event.source && `출처: ${event.source}`].filter(Boolean).join(' · ') || '상세 기록 없음'}</small></div>
              <em>{event.previousStatus && event.newStatus ? `${event.previousStatus} → ${event.newStatus}` : event.newStatus ?? event.status}</em>
            </div>)}
          </div> : <div className="laundry-process__empty">아직 이 의류의 작업 이력이 없습니다. 공정을 확인하면 시간과 상태 변경이 이곳에 남습니다.</div> : <div className="laundry-process__empty">의류를 선택하면 해당 의류의 작업 이력이 표시됩니다.</div>}
        </details>
        <footer className="laundry-process__footer"><button type="button" onClick={onBack} data-testid="button-process-back">← 이전 화면으로 돌아가기</button><span><StoreName /></span></footer>
      </div>

      {pendingAction && selected && <div className="laundry-process__dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) { setPendingAction(null); setReason(''); setDetail(''); } }}>
        <form className="laundry-process__dialog" role="dialog" aria-modal="true" aria-labelledby="laundry-process-confirm-title" onSubmit={confirmAction}>
          
          <h2 id="laundry-process-confirm-title">{pendingAction === 'handover-rewash' ? '재세탁 처리' : `${actionLabels[pendingAction]} 확인`}</h2>
          {pendingAction === 'handover' ? <>
            <p>최종 반출 확인 · <strong><IntakeIdentity order={order}/></strong></p>
            <p>전체 세탁물 <strong>{garments.length}벌</strong> · 현재 반출 준비 <strong>{progress.readyForHandover}벌</strong></p>
            <p>인도 방법 <strong>{deliveryChoice}</strong>{order.choices.pickupRequested ? ' · 방문 수거 접수' : ''}</p>
            <p>결제상태 <strong>{operations.paymentStatus}</strong> · 기록 결제액 <strong>{paidAmount.toLocaleString('ko-KR')}원</strong> · 미수 예상액 <strong>{unpaidAmount.toLocaleString('ko-KR')}원</strong></p>
            <p>추가 기술료 <strong>{(order.choices.technicalFee ?? 0).toLocaleString('ko-KR')}원</strong> · 수거/배달비 <strong>{order.serviceFee.toLocaleString('ko-KR')}원</strong>{order.inspection && order.inspection.revisedPrice !== order.estimatedTotal
              ? ` · 검수 조정 ${order.inspection.revisedPrice - order.estimatedTotal >= 0 ? '+' : ''}${(order.inspection.revisedPrice - order.estimatedTotal).toLocaleString('ko-KR')}원` : ''}</p>
            <p>현재 보관료 <strong>{storageCharge.toLocaleString('ko-KR')}원</strong> · 기준일 {koreaCalendarDate(new Date())} · 미인도 {storedGarments}벌</p>
             <p>확인한 의류 <strong>{selected.itemName}</strong> · 상태 <strong>{garmentDisplayStatus(order, selected, status)}</strong></p>
          </> : pendingAction === 'handover-rewash' ? <>
            <p>접수 고객: <strong><IntakeIdentity order={order}/></strong></p>
            <p>의류명: <strong>{selected.itemName}</strong></p>
            
            <p>현재 상태: <strong>출고 대기</strong></p>
            <label>재세탁 사유 · 필수
              <select value={reason} onChange={(event) => setReason(event.target.value)} required data-testid="select-process-rewash-reason">
                <option value="">사유 선택</option>
                {RECLEANING_REASONS.map((option) => <option key={option} value={option}>{option}</option>)}
              </select>
            </label>
            <label>재세탁 사유 상세 · 선택<textarea value={detail} onChange={(event) => setDetail(event.target.value)} maxLength={500}
              placeholder="추가로 기록할 내용이 있으면 입력해 주세요." data-testid="input-process-rewash-detail" /></label>
          </> : <>
            <p><strong>{selected.itemName}</strong> 한 벌의 상태를 변경합니다. 처리 전 의류와 작업을 다시 확인해 주세요.</p>
            {requiresReason && <label>처리 사유 · 필수<textarea value={reason} onChange={(event) => setReason(event.target.value)} placeholder={pendingAction === 'qc-rewash' ? '재세탁이 필요한 상태를 구체적으로 적어 주세요.' : '보류 사유와 확인이 필요한 내용을 적어 주세요.'} data-testid="input-process-reason" /></label>}
          </>}
          <div className="laundry-process__dialog-actions">
            <button ref={cancelRef} type="button" className="laundry-process__button" disabled={busy} onClick={() => { setPendingAction(null); setReason(''); setDetail(''); }} data-testid="button-process-cancel">취소</button>
            <button type="submit" className="laundry-process__primary" disabled={actionLocked(pendingAction) || (requiresReason && !reason.trim()) || !actions.includes(pendingAction)} data-testid="button-process-confirm">{busy ? '처리 중…' : pendingAction === 'handover-rewash' ? '재세탁 등록' : `${actionLabels[pendingAction]} 확정`}</button>
          </div>
        </form>
      </div>}
    </main>
  );
}