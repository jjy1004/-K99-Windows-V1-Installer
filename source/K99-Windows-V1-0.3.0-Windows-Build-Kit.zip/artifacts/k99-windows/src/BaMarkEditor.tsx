import { useEffect, useRef, useState, type PointerEvent as RPE } from 'react';
import { coverRect, isUsableMark, MARK_HEX, moveMark, rectFromPoints, resizeMark, toNormalized,
  type Box, type Corner, type Mark, type MarkColor, type MarkKind, type Pt } from './ba-geometry';

type Drag = { mode: 'create'; start: Pt; id: string } | { mode: 'move'; start: Pt; orig: Mark } | { mode: 'resize'; corner: Corner; orig: Mark };

/** Normalized source-image marks share the same centered cover transform as the saved JPEG. */
export function BaMarkEditor({ src, marks, onChange, tool, color, disabled, testId }: {
  src: string; marks: Mark[]; onChange: (m: Mark[]) => void; tool: MarkKind; color: MarkColor; disabled?: boolean; testId: string;
}) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [nat, setNat] = useState({ src: '', w: 0, h: 0 });
  const [selected, setSelected] = useState<string | null>(null);
  const drag = useRef<Drag | null>(null);
  const marksRef = useRef(marks); marksRef.current = marks;
  const changeRef = useRef(onChange); changeRef.current = onChange;

  // Do not clear dimensions in a passive effect: cached images may have
  // already fired load before that effect, leaving a permanent zero-size overlay.
  useEffect(() => { setSelected(null); drag.current = null; }, [src]);
  useEffect(() => {
    const el = wrapRef.current; if (!el) return;
    const ro = new ResizeObserver(() => setBox({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el); return () => ro.disconnect();
  }, []);
  useEffect(() => { if (selected && !marks.some((m) => m.id === selected)) setSelected(null); }, [marks, selected]);

  const area: Box = coverRect(nat.src === src ? nat.w : 0, nat.src === src ? nat.h : 0,
    { x: 0, y: 0, w: box.w, h: box.h });
  const pt = (e: RPE): Pt => {
    const r = svgRef.current!.getBoundingClientRect();
    return toNormalized({ x: e.clientX - r.left, y: e.clientY - r.top }, { x: 0, y: 0, w: r.width, h: r.height });
  };
  const capture = (e: RPE) => { try { svgRef.current?.setPointerCapture(e.pointerId); } catch { /* noop */ } };
  // Pointer events may arrive within a single React frame; retain the newest
  // geometry synchronously so pointerup does not discard a just-drawn shape.
  const commit = (next: Mark[]) => { marksRef.current = next; changeRef.current(next); };
  const replace = (m: Mark) => commit(marksRef.current.map((x) => x.id === m.id ? m : x));

  const onDown = (e: RPE) => {
    if (disabled || e.button !== 0) return;
    const p = pt(e); const id = `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    drag.current = { mode: 'create', start: p, id }; setSelected(null); capture(e);
    commit([...marksRef.current, { id, kind: tool, color, x: p.x, y: p.y, w: 0, h: 0 }]);
  };
  const onMoveDown = (e: RPE, m: Mark) => {
    if (disabled) return; e.stopPropagation(); setSelected(m.id);
    drag.current = { mode: 'move', start: pt(e), orig: m }; capture(e);
  };
  const onCornerDown = (e: RPE, m: Mark, corner: Corner) => {
    if (disabled) return; e.stopPropagation(); drag.current = { mode: 'resize', corner, orig: m }; capture(e);
  };
  const onMove = (e: RPE) => {
    const d = drag.current; if (!d) return; const p = pt(e);
    if (d.mode === 'create') {
      const cur = marksRef.current.find((m) => m.id === d.id); if (cur) replace({ ...cur, ...rectFromPoints(d.start, p) });
    } else if (d.mode === 'move') replace(moveMark(d.orig, p.x - d.start.x, p.y - d.start.y));
    else replace(resizeMark(d.orig, d.corner, p));
  };
  const onUp = () => {
    const d = drag.current; drag.current = null; if (!d) return;
    if (d.mode === 'create') {
      const cur = marksRef.current.find((m) => m.id === d.id);
      if (cur && !isUsableMark(cur)) commit(marksRef.current.filter((m) => m.id !== d.id));
      else if (cur) setSelected(cur.id);
    } else {
      const cur = marksRef.current.find((m) => m.id === d.orig.id);
      if (cur && !isUsableMark(cur)) replace(d.orig);
    }
  };
  const removeSelected = () => { if (selected) commit(marksRef.current.filter((m) => m.id !== selected)); setSelected(null); };

  return <div className="bam">
    <div className="bam__stage" ref={wrapRef} data-testid={`editor-${testId}`}>
      {src ? <img src={src} alt="" draggable={false} onLoad={(e) => {
        setNat({ src, w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight });
        // Initialize immediately as well as observing later window resizes.
        const el = wrapRef.current;
        if (el) setBox({ w: el.clientWidth, h: el.clientHeight });
      }} />
        : <div className="bam__empty">사진을 선택하세요</div>}
      {src && area.w > 0 && <svg ref={svgRef} className="bam__svg" data-disabled={disabled || undefined}
        style={{ left: area.x, top: area.y, width: area.w, height: area.h }} viewBox={`0 0 ${area.w} ${area.h}`}
        onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
        {marks.map((m) => {
          const x = m.x * area.w, y = m.y * area.h, w = m.w * area.w, h = m.h * area.h;
          const shape = (cls: string, sw: number, stroke: string) => m.kind === 'circle'
            ? <ellipse className={cls} cx={x + w / 2} cy={y + h / 2} rx={w / 2} ry={h / 2} fill="none" stroke={stroke} strokeWidth={sw} />
            : <rect className={cls} x={x} y={y} width={w} height={h} fill="none" stroke={stroke} strokeWidth={sw} />;
          const sel = selected === m.id;
          return <g key={m.id}>
            {shape('bam__vis', 4, MARK_HEX[m.color])}
            <g onPointerDown={(e) => onMoveDown(e, m)} data-testid={`mark-${testId}-${m.id}`}>{shape('bam__hit', 18, 'transparent')}</g>
            {sel && <rect className="bam__bbox" x={x} y={y} width={w} height={h} fill="none" />}
            {sel && (['nw', 'ne', 'sw', 'se'] as Corner[]).map((c) => <rect key={c} className="bam__handle" data-corner={c}
              x={(c[1] === 'w' ? x : x + w) - 8} y={(c[0] === 'n' ? y : y + h) - 8} width={16} height={16}
              onPointerDown={(e) => onCornerDown(e, m, c)} />)}
          </g>;
        })}
      </svg>}
    </div>
    <div className="bam__bar">
      <span>{marks.length ? `표시 ${marks.length}개` : '사진 위를 드래그해 표시하세요'}</span>
      <button type="button" disabled={disabled || !selected} onClick={removeSelected} data-testid={`button-${testId}-delete-mark`}>선택 도형 지우기</button>
      <button type="button" disabled={disabled || !marks.length} onClick={() => { setSelected(null); commit([]); }} data-testid={`button-${testId}-clear-marks`}>모두 지우기</button>
    </div>
  </div>;
}
