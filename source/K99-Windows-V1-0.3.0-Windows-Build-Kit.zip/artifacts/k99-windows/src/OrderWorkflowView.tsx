import { useState } from 'react';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import type { ConfirmedOrder } from './order-record';
import type { ActualCleaningMethod } from './inspection-record';
import { garmentProcessStatus } from './laundry-process';
import { currentOperations } from './order-operations';
import {
  WORKFLOW_STAGES, WORKFLOW_FIELDS, getWorkflowIssues, workflowStageState, workflowReviewFor, workflowBatchPlan,
} from './order-workflow';
import type { WorkflowStage, WorkflowBatchAction } from './order-workflow';
import './order-workflow.css';

type Props = {
  order: ConfirmedOrder; busy: boolean; error: string; notice: string;
  methods: Record<number, ActualCleaningMethod>;
  onMethod: (index: number, method: ActualCleaningMethod) => void;
  onBatch: (action: WorkflowBatchAction) => void;
  onReview: (id: string, stage: WorkflowStage, selected: string[], note: string, resolved: boolean) => boolean;
  onCapture: (garmentId?: string) => void;
  onInspection: () => void; onScanner: () => void; onBack: () => void; onLegacy: () => void;
};

const SYMBOL = { done: '✓', attention: '!', pending: '·' } as const;
const STATE_LABEL = { done: '완료', attention: '확인 필요', pending: '대기' } as const;
const BATCHES: { action: WorkflowBatchAction; label: string }[] = [
  { action: 'start', label: '정상 의류 세탁 시작' },
  { action: 'complete', label: '세탁 완료 확인' },
  { action: 'postwash', label: '세탁 후 정상 확인' },
  { action: 'final', label: '최종 정상 확인' },
];

export default function OrderWorkflowView(p: Props) {
  const { order, busy } = p;
  const operation = currentOperations(order);
  const visibleStatus = operation.completedAt || operation.stage === '배달중'
    ? orderDisplayStatus(order, operation.stage) : orderDisplayStatus(order);
  const garments = order.garments ?? [];
  const [open, setOpen] = useState<{ id: string; stage: WorkflowStage } | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [note, setNote] = useState('');

  function openStage(id: string, stage: WorkflowStage) {
    if (open?.id === id && open.stage === stage) { setOpen(null); return; }
    const g = garments.find((x) => x.garmentId === id)!;
    const r = workflowReviewFor(g, stage);
    const issues = getWorkflowIssues(order, g, stage).map((i) => i.key);
    setSelected(Array.from(new Set([...(r?.selected ?? []), ...issues])));
    setNote(r?.note ?? '');
    setOpen({ id, stage });
  }
  const plans = BATCHES.filter((b) => garments.some((g) => {
    const status = garmentProcessStatus(order,g);
    return b.action === 'start' ? ['접수 완료','촬영/태그 완료','전문검수 완료','세탁 대기'].includes(status)
      : b.action === 'complete' ? status === '세탁 중'
      : b.action === 'postwash' ? status === '세탁 완료' : status === '완성 검수';
  })).map((b) => ({ ...b, plan: workflowBatchPlan(order, b.action) }));
  const blockers = [...new Set(plans.flatMap((x) => x.plan.blockers))];

  return (
    <main className="owf" data-testid="workflow-order">
      <div className="owf-top">
        <div><h1>{order.customerName} 고객 · 세탁물 {garments.length}벌</h1>
          <small>{visibleStatus} · 예외만 열어 확인하세요</small>
          <p>{order.customerPhone} · 접수 {new Date(order.intakeAt).toLocaleString('ko-KR')} · 주문 {order.id}</p></div>
        <div className="owf-nav">
          <button type="button" onClick={p.onBack} data-testid="button-workflow-back">이전</button>
          <button type="button" onClick={() => p.onCapture()} data-testid="button-workflow-capture">촬영</button>
          <button type="button" onClick={p.onInspection} data-testid="button-workflow-inspection">전문검수·승인</button>
          <button type="button" onClick={p.onScanner} data-testid="button-workflow-scanner">스캐너</button>
          <button type="button" onClick={p.onLegacy} data-testid="button-workflow-legacy">기존 공정 화면</button>
        </div>
      </div>
      {p.error && <div className="owf-msg owf-err" role="alert">{p.error}</div>}
      {p.notice && <div className="owf-msg owf-ok" role="status">{p.notice}</div>}

      {(!order.inspection || order.status !== '세탁 진행 승인') &&
        workflowBatchPlan(order,'start').eligible.length > 0 && <section aria-label="세탁 방법" className="owf-methods">
        <p>세탁방법은 품목당 한 번 직접 선택합니다. 아래 일괄 확인은 직원이 해당 의류를 실제 점검했다는 기록입니다.</p>
        {order.items.map((it, i) => (
          <label key={i}>{it.displayNameKo} × {it.quantity}
            <select value={p.methods[i] ?? ''} disabled={busy} data-testid={`select-workflow-method-${i}`}
              aria-label={`${it.displayNameKo} 세탁 방법`}
              onChange={(e) => e.target.value && p.onMethod(i, e.target.value as ActualCleaningMethod)}>
              <option value="">방법 선택</option><option value="물세탁">물세탁</option><option value="드라이세탁">드라이세탁</option>
            </select></label>
        ))}
      </section>}

      <div className="owf-bar" role="group" aria-label="일괄 처리">
        {plans.map(({ action, label, plan }) => (
          <button key={action} type="button" className="owf-primary" disabled={busy || plan.eligible.length === 0}
            onClick={() => p.onBatch(action)} data-testid={`button-workflow-${action}`}>
            {plan.label || label}</button>
        ))}
      </div>
      {blockers.length > 0 && (
        <ul className="owf-blockers" data-testid="workflow-blockers">{blockers.map((b, i) => <li key={i}>{b}</li>)}</ul>
      )}

      <section aria-label="의류 목록">
        {garments.map((g) => {
          const states = WORKFLOW_STAGES.map((s) => workflowStageState(order, g, s.key));
          const status = garmentProcessStatus(order,g);
          const current = states[0] === 'attention' ? 0
            : ['접수 완료','촬영/태그 완료','전문검수 완료','세탁 대기'].includes(status) ? 1
            : status === '세탁 완료' ? 2 : status === '완성 검수' ? 3 : -1;
          return (
            <div key={g.garmentId} className="owf-row" data-testid={`workflow-garment-${g.garmentId}`}>
              <div className="owf-name"><strong>{String(g.sequence).padStart(2, '0')} {g.itemName}</strong>
                <small>서비스 · {g.serviceType.includes('premium') ? '프리미엄' : '일반'}</small>
                <small>{garmentDisplayStatus(order, g, garmentProcessStatus(order, g))}</small>
              <small>사진 {g.photoStatus === 'saved' ? '연결됨' : g.photoStatus === 'simulated' ? '모의 기록' : '미연결'}
                {' · '}태그 {g.photoBridgeAutoTagStatus ?? g.tagStatus}
                 {' · '}바코드 {g.barcodeValue}</small>{g.tagNumber&&<strong>태그 {g.tagNumber}</strong>}</div>
              <div className="owf-stages">
                {WORKFLOW_STAGES.map((s, i) => {
                  const st = states[i];
                  const exp = open?.id === g.garmentId && open.stage === s.key;
                  return (
                    <button key={s.key} type="button" className="owf-stage" data-state={st} aria-expanded={exp}
                      aria-label={`${s.label} ${STATE_LABEL[st]}`} disabled={busy || (st === 'pending' && i !== current)}
                      onClick={() => openStage(g.garmentId, s.key)} data-testid={`workflow-stage-${s.key}-${g.garmentId}`}>
                      <span className="owf-sym" aria-hidden="true">{SYMBOL[st]}</span>{s.label}</button>
                  );
                })}
              </div>
              {open?.id === g.garmentId && (() => {
                const idx = WORKFLOW_STAGES.findIndex((s) => s.key === open.stage);
                const st = states[idx];
                const editableIntake = open.stage === 'intake' &&
                  ['접수 완료','촬영/태그 완료','전문검수 완료','세탁 대기'].includes(status);
                const isCurrent = idx === current || editableIntake;
                const readonly = !editableIntake && st === 'done' || !isCurrent;
                const issues = getWorkflowIssues(order, g, open.stage);
                return (
                  <div className="owf-panel" role="group" aria-label="상세 확인">
                    {issues.length > 0 && <ul className="owf-blockers" style={{ margin: 0 }}>{issues.map((i) => <li key={`${i.key}:${i.label}`}>{i.label}</li>)}</ul>}
                    <div className="owf-fields">
                      {WORKFLOW_FIELDS[open.stage].map((f) => (
                        <label key={f.key} className="owf-chk">
                          <input type="checkbox" disabled={readonly || busy} checked={selected.includes(f.key)}
                            onChange={(e) => setSelected((c) => e.target.checked ? [...c, f.key] : c.filter((k) => k !== f.key))} />
                          {f.label}</label>
                      ))}
                    </div>
                    <textarea value={note} readOnly={readonly} onChange={(e) => setNote(e.target.value)}
                      aria-label="메모" placeholder="메모" data-testid="input-workflow-note" />
                    <p>확인 내용을 저장합니다. 필수 세탁방법·전문검수·고객 동의가 남아 있으면 이를 먼저 처리한 후 일괄 진행하세요.</p>
                    <div className="owf-acts">
                      <button type="button" className="owf-primary" disabled={readonly || busy}
                        onClick={() => { if (p.onReview(g.garmentId, open.stage, selected, note, true)) setOpen(null); }}
                        data-testid="button-workflow-review-confirm">확인 완료 → 다음 단계</button>
                      <button type="button" onClick={() => p.onCapture(g.garmentId)} data-testid="button-workflow-photo">사진</button>
                      <button type="button" disabled={readonly || busy || (selected.length === 0 && !note.trim())}
                        onClick={() => { if (p.onReview(g.garmentId, open.stage, selected, note, false)) setOpen(null); }}
                        data-testid="button-workflow-review-hold">{issues.length ? '보류 저장' : '특이사항 기록'}</button>
                      <button type="button" onClick={() => setOpen(null)}>닫기</button>
                    </div>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </section>
    </main>
  );
}
