import { useEffect } from 'react';
import { PHOTO_BRIDGE_SESSION_EVENT, sendPhotoBridgeSelection } from './photo-bridge-session';

/** Shares the current target in DEV too, without arming a camera or enabling STORE mode. */
export function usePhotoBridgeSelection(orderId: string, garmentId: string | undefined): void {
  useEffect(() => {
    if (!garmentId) return;
    let live = true;
    let revision = 0;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let request: AbortController | undefined;
    let warned = false;
    const send = async () => {
      const currentRevision = ++revision;
      if (timer) clearTimeout(timer);
      request?.abort();
      request = new AbortController();
      try {
        if (await sendPhotoBridgeSelection(orderId, garmentId, request.signal)) warned = false;
      } catch (cause) {
        if (live && currentRevision === revision && !request.signal.aborted && !warned) {
          warned = true;
          // Diagnostics stay in logs, not in a new staff UI or a customer record.
          console.warn('Photo Bridge 의류 선택 전달 실패:', cause instanceof Error ? cause.message : '통신 오류');
        }
      } finally {
        if (live && currentRevision === revision) timer = setTimeout(() => { void send(); }, 4000);
      }
    };
    const changed = () => { void send(); };
    window.addEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
    void send();
    return () => {
      live = false;
      revision++;
      if (timer) clearTimeout(timer);
      request?.abort();
      window.removeEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
    };
  }, [orderId, garmentId]);
}