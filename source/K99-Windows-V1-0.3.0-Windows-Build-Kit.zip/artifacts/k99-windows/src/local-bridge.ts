import type { GarmentTagData } from './garment-record';
import {
  createTagPrinterSettings,
  requireRequestId,
  type PrinterOperationResult,
  type TagPrinterAdapter,
  type TagPrinterSettings,
} from './tag-printer.ts';

export const DEFAULT_LOCAL_BRIDGE_BASE_URL = 'k99-disabled://hardware';

export type LocalBridgeClientOptions = {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
};

export type CaptureRequest = {
  requestId: string;
  orderId: string;
  garmentId: string;
  [key: string]: unknown;
};

type BridgeTagData = GarmentTagData & {
  garmentId: string;
  orderId: string;
  customerName: string;
  sequence: number;
  totalSequence: number;
  barcodeValue: string;
};

function validateLoopbackBaseUrl(baseUrl: string): URL {
  let url: URL;
  try {
    url = new URL(baseUrl);
  } catch {
    throw new Error('Local Bridge URL은 올바른 loopback URL이어야 합니다.');
  }
  const hostname = url.hostname.toLowerCase();
  const isLoopback = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]';
  if (!isLoopback || !['http:', 'https:'].includes(url.protocol) ||
      url.username || url.password || url.search || url.hash) {
    throw new Error('Local Bridge loopback URL은 localhost, 127.0.0.1 또는 ::1 주소만 사용할 수 있습니다.');
  }
  return url;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function validateStatusResponse(value: unknown, endpoint: string): Record<string, unknown> {
  if (!isRecord(value)) throw new Error(`Local Bridge ${endpoint} 응답 형식이 올바르지 않습니다.`);
  if (typeof value.status !== 'string' && typeof value.online !== 'boolean' && typeof value.ok !== 'boolean') {
    throw new Error(`Local Bridge ${endpoint} 응답에 상태 정보가 없습니다.`);
  }
  return value;
}

function validateTagData(tagData: GarmentTagData): BridgeTagData {
  const data = tagData as unknown as Record<string, unknown>;
  if (typeof data.orderId !== 'string' || !data.orderId.trim() ||
      typeof data.garmentId !== 'string' || !data.garmentId.trim() ||
      typeof data.barcodeValue !== 'string' || !data.barcodeValue.trim()) {
    throw new Error('태그 데이터에 orderId, garmentId, barcodeValue가 필요합니다.');
  }
  if (data.barcodeValue !== data.garmentId ||
      /^\+?\d[\d\s().-]*$/.test(data.barcodeValue)) {
    throw new Error('바코드에는 전체 전화번호가 아닌 의류 ID만 사용할 수 있습니다.');
  }
  return tagData as unknown as BridgeTagData;
}

function validatePrintResponse(
  value: unknown,
  requestId: string,
  orderId?: string,
  garmentId?: string,
): PrinterOperationResult {
  if (!isRecord(value) || (value.status !== 'printed' && value.status !== 'simulated')) {
    throw new Error('Local Bridge 인쇄 응답에 검증 가능한 printed 또는 simulated 상태가 없습니다.');
  }
  if (value.requestId !== requestId) {
    throw new Error('Local Bridge 인쇄 응답의 requestId가 요청과 일치하지 않습니다.');
  }
  if (orderId && value.orderId !== orderId) {
    throw new Error('Local Bridge 인쇄 응답의 orderId가 요청과 일치하지 않습니다.');
  }
  if (garmentId && value.garmentId !== garmentId) {
    throw new Error('Local Bridge 인쇄 응답의 garmentId가 요청과 일치하지 않습니다.');
  }
  if (value.message !== undefined && typeof value.message !== 'string') {
    throw new Error('Local Bridge 인쇄 응답의 message 형식이 올바르지 않습니다.');
  }
  return {
    status: value.status,
    requestId,
    ...(orderId && { orderId }),
    ...(garmentId && { garmentId }),
    ...(typeof value.message === 'string' && { message: value.message }),
  };
}

export class LocalBridgeClient {
  readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;

  constructor(options: LocalBridgeClientOptions = {}) {
    const url = validateLoopbackBaseUrl(options.baseUrl ?? DEFAULT_LOCAL_BRIDGE_BASE_URL);
    this.baseUrl = url.toString().replace(/\/$/, '');
    // Browser-native fetch requires Window as its receiver; calling an
    // unbound reference as a class method throws "Illegal invocation".
    this.fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
  }

  getHealth(): Promise<Record<string, unknown>> {
    return this.getStatus('health');
  }

  getHardwareStatus(): Promise<Record<string, unknown>> {
    return this.getStatus('hardware-status');
  }

  getPrinterStatus(): Promise<Record<string, unknown>> {
    return this.getStatus('printer-status');
  }

  async capture(request: CaptureRequest): Promise<Record<string, unknown>> {
    const requestId = requireRequestId(request.requestId);
    if (!request.orderId?.trim() || !request.garmentId?.trim()) {
      throw new Error('촬영 요청에 orderId와 garmentId가 필요합니다.');
    }
    const result = await this.post('capture', { ...request, requestId });
    if (!isRecord(result) ||
        result.success === false ||
        (typeof result.status !== 'string' && typeof result.success !== 'boolean') ||
        result.requestId !== requestId || result.orderId !== request.orderId ||
        result.garmentId !== request.garmentId) {
      throw new Error('Local Bridge capture 응답의 상태 또는 요청 식별자가 올바르지 않습니다.');
    }
    return result;
  }

  async printTag(
    tagData: GarmentTagData,
    requestId: string,
    settings: Partial<TagPrinterSettings> = {},
  ): Promise<PrinterOperationResult> {
    return this.sendTagPrint('print-tag', tagData, requestId, settings);
  }

  async reprintTag(
    tagData: GarmentTagData,
    requestId: string,
    settings: Partial<TagPrinterSettings> = {},
  ): Promise<PrinterOperationResult> {
    return this.sendTagPrint('reprint-tag', tagData, requestId, settings);
  }

  async testPrint(
    requestId: string,
    settings: Partial<TagPrinterSettings> = {},
  ): Promise<PrinterOperationResult> {
    const id = requireRequestId(requestId);
    const printerSettings = createTagPrinterSettings(settings);
    const response = await this.post('test-print', {
      requestId: id,
      printerModel: printerSettings.printerModel,
      ...(printerSettings.printerName && { printerName: printerSettings.printerName }),
      copies: printerSettings.copies,
        settings: printerSettings,
    });
    return validatePrintResponse(response, id);
  }

  private async getStatus(endpoint: string): Promise<Record<string, unknown>> {
    const response = await this.request(endpoint, { method: 'GET' });
    return validateStatusResponse(response, endpoint);
  }

  private async sendTagPrint(
    endpoint: 'print-tag' | 'reprint-tag',
    tagData: GarmentTagData,
    requestId: string,
    settings: Partial<TagPrinterSettings>,
  ): Promise<PrinterOperationResult> {
    const id = requireRequestId(requestId);
    const tag = validateTagData(tagData);
    const printerSettings = createTagPrinterSettings(settings);
    const response = await this.post(endpoint, {
      requestId: id,
      orderId: tag.orderId,
      garmentId: tag.garmentId,
      printerModel: printerSettings.printerModel,
      ...(printerSettings.printerName && { printerName: printerSettings.printerName }),
      copies: printerSettings.copies,
      tagData: tag,
      barcodeType: printerSettings.barcodeType,
      settings: printerSettings,
    });
    return validatePrintResponse(response, id, tag.orderId, tag.garmentId);
  }

  private async post(endpoint: string, body: Record<string, unknown>): Promise<unknown> {
    return this.request(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  private async request(endpoint: string, init: RequestInit): Promise<unknown> {
    let response: Response;
    try {
      response = await this.fetchImpl(`${this.baseUrl}/${endpoint}`, init);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'network error';
      throw new Error(`Local Bridge ${endpoint} 요청에 실패했습니다: ${message}`);
    }

    let payload: unknown;
    try {
      payload = await response.json();
    } catch {
      throw new Error(`Local Bridge ${endpoint} 응답을 JSON으로 읽을 수 없습니다.`);
    }

    if (!response.ok) {
      const message = isRecord(payload) && typeof payload.error === 'string'
        ? payload.error
        : `HTTP ${response.status}`;
      throw new Error(`Local Bridge ${endpoint} 실패: ${message}`);
    }
    if (init.method === 'POST' && isRecord(payload) && payload.status === 'offline') {
      throw new Error(`Local Bridge ${endpoint}: 프린터가 오프라인입니다.`);
    }
    return payload;
  }
}

/**
 * Application-side hardware status lookup. A missing/unreachable bridge is an
 * explicit simulation result so callers can keep the workflow usable without
 * repeatedly surfacing connection failures.
 */
export async function getHardwareStatus(
  client: LocalBridgeClient = new LocalBridgeClient(),
): Promise<Record<string, unknown>> {
  try {
    return await client.getHardwareStatus();
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    return {
      status: 'simulated',
      online: false,
      mode: 'simulation',
      message: `시뮬레이션 모드 · Local Bridge 상태를 확인하지 못했습니다. (${detail})`,
    };
  }
}

/** Application-side capture function; it never claims a photo was saved itself. */
export function captureGarmentPhoto(
  client: LocalBridgeClient,
  request: CaptureRequest,
): Promise<Record<string, unknown>> {
  return client.capture(request);
}

export function createLocalBridgeTagPrinterAdapter(
  client: LocalBridgeClient,
  settings: Partial<TagPrinterSettings> = {},
): TagPrinterAdapter {
  const resolvedSettings = createTagPrinterSettings(settings);
  return {
    getPrinterStatus: () => client.getPrinterStatus(),
    printGarmentTag: (tagData, requestId) => client.printTag(tagData, requestId, resolvedSettings),
    reprintGarmentTag: (tagData, requestId) => client.reprintTag(tagData, requestId, resolvedSettings),
    testPrint: (requestId) => client.testPrint(requestId, resolvedSettings),
  };
}