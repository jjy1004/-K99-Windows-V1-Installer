import { useCallback, useEffect, useRef, useState } from 'react';
import { garmentDisplayStatus } from './handover-display';
import { NoticeQuickActions } from './NoticeQuickActions';
import { PaymentBadge, paymentInfo } from './order-payment';
import type { ConfirmedOrder } from './order-record';
import { readConfirmedOrders, updateSavedOrder } from './order-record';
import { currentOperations } from './order-operations';
import { garmentProcessStatus } from './laundry-process';
import { findSavedGarment, isGarmentComplete, listGarments } from './garment-scanner';
import { confirmStaffHandover, handoverScanCount, handoverScanFingerprint, isReadyForHandover,
  staffHandoverBlockers, type HandoverScans } from './order-handover';
import { ScannerOrderProgress } from './ScannerOrderProgress';
import './garment-scanner.css';
import { FolderOpen, Images, ScanLine, Truck, Store, PackageCheck, Trash2 } from 'lucide-react';
import OrderDeletionDialog from './OrderDeletionDialog';
import { BeforeAfterComposer } from './BeforeAfterComposer';
import { openPhotoFolder } from './equipment-client';
import { openCustomerNotice } from './notice-api';
import { useOrderComparisons } from './useOrderComparisons';
import { barcodeCharFromKey } from './barcode-keys';
import { convertKoreanSearch } from './korean-input-conversion';
import { canRestoreHandover, latestHandedOrder, restoreHandover } from './handover-recovery';
import { StoreName } from './StoreName';

const ACTOR_KEY = 'k99-scan-staff-actor';

type Props = {
  initialOrderId?: string;
  initialGarmentId?: string;
  captureError?: string;
  onBack: () => void;
  onOpenCapture: (orderId: string, garmentId: string) => void;
  onOrderChange?: (order: ConfirmedOrder) => void;
};

const last4 = (phone: string) => phone.replace(/\D/g, '').slice(-4);

export default function GarmentScannerWorkspace({ initialOrderId, initialGarmentId, captureError, onOrderChange }: Props) {
  const [orders, setOrders] = useState<ConfirmedOrder[]>([]);
  const [deleting, setDeleting] = useState<ConfirmedOrder | null>(null);
  const [orderId, setOrderId] = useState(initialOrderId ?? '');
  const [composerOpen, setComposerOpen] = useState(false);
  const [candidates, setCandidates] = useState<string[]>([]);
  const composing = useRef(false);
  const lastKeyAt = useRef<number[]>([]);
  const [folderNote, setFolderNote] = useState('');
  const [garmentId, setGarmentId] = useState(initialGarmentId ?? '');
  const [barcode, setBarcode] = useState('');
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [busy, setBusy] = useState(false);
  const [handoverScans, setHandoverScans] = useState<HandoverScans>({});
  const [actor, setActor] = useState(() => { try { return window.localStorage.getItem(ACTOR_KEY) ?? ''; } catch { return ''; } });
  const actorRef = useRef(actor);
  actorRef.current = actor;
  const input = useRef<HTMLInputElement>(null);
  const nameBuffer = useRef({ raw: '', display: '' });
  const cardRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const working = useRef(false);
  const burst = useRef({ value: '', at: 0 });
  const refresh = useCallback(() => {
    try { setOrders(readConfirmedOrders()); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '접수 내역을 불러오지 못했습니다.'); }
  }, []);
  useEffect(() => {
    refresh();
    const focus = () => refresh();
    window.addEventListener('focus', focus);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('focus', focus); window.removeEventListener('storage', refresh); };
  }, [refresh]);

  const focusCard = (id: string) => {
    requestAnimationFrame(() => {
      const el = cardRefs.current[id];
      el?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      el?.focus({ preventScroll: true });
    });
  };

  const selectOrder = useCallback((item: ConfirmedOrder, clothId?: string) => {
    setOrderId(item.id);
    setGarmentId(clothId ?? listGarments(item)[0]?.garmentId ?? '');
    setError('');
  }, []);

  const commitHandover = useCallback((id: string, scans: HandoverScans) => {
    if (working.current || deleting) return;
    working.current = true; setBusy(true); setError(''); setFeedback('');
    try {
      // Fresh read immediately before persisting so a stale card never overwrites newer state.
      const latest = readConfirmedOrders().find((item) => item.id === id);
      if (!latest) throw new Error('원본 주문을 다시 확인해 주세요.');
      const blockers = staffHandoverBlockers(latest);
      if (blockers.length) throw new Error(blockers.join('\n'));
      if (paymentInfo(latest).type === 'POSTPAID' && paymentInfo(latest).status === 'UNPAID' &&
          !window.confirm(`결제 완료 후 출고하시겠습니까?\n미납금액: ${paymentInfo(latest).due.toLocaleString('ko-KR')}원\n실제 결제를 확인한 경우에만 확인을 누르세요.`)) return;
      const count = listGarments(latest).length;
      const updated = confirmStaffHandover(latest, { actor: actorRef.current, scans, paymentConfirmed: true });
      updateSavedOrder(updated, latest);
      onOrderChange?.(updated);
      setOrderId(latest.id); setCandidates([]);
      setFeedback(latest.choices.deliveryRequested
        ? `${latest.customerName} 고객님 의류 ${count}벌을 배달 출고했습니다.`
        : `${latest.customerName} 고객님께 의류 ${count}벌을 인도했습니다.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '인도를 확정하지 못했습니다.');
    } finally { working.current = false; setBusy(false); refresh(); }
  }, [refresh, onOrderChange, deleting]);

  const restoreOrder = useCallback((id: string, displayed?: ConfirmedOrder) => {
    if (working.current || deleting) return;
    working.current = true; setBusy(true); setError(''); setFeedback('');
    try {
      const latest = readConfirmedOrders().find(item => item.id === id);
      if (!latest) throw new Error('원본 주문을 찾을 수 없습니다.');
      if (displayed && JSON.stringify(latest) !== JSON.stringify(displayed))
        throw new Error('조회 후 주문이 변경되었습니다. 새 상태를 확인한 뒤 다시 복구해 주세요.');
      const updated = restoreHandover(latest, actorRef.current);
      updateSavedOrder(updated, latest);
      onOrderChange?.(updated);
      setOrderId(id); setHandoverScans({}); setCandidates([]); setBarcode('');
      setFeedback(`${latest.customerName} 고객님 주문을 출고 대기로 복구했습니다. 결제 기록은 변경하지 않았습니다.`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : '출고를 복구하지 못했습니다.'); }
    finally { working.current = false; setBusy(false); refresh(); }
  }, [deleting, onOrderChange, refresh]);

  /** Search is read-only, including scanner Enter; include previous departures. */
  const resolve = useCallback((value: string, all: ConfirmedOrder[]) => {
    const ready = all.filter(item => isReadyForHandover(item) || canRestoreHandover(item));
    const code = value.toLowerCase();
    const byId = ready.filter((item) => item.id.toLowerCase() === code);
    if (byId.length) return byId;
    if (/^\d{4}$/.test(value)) return ready.filter((item) => last4(item.customerPhone) === value);
    const partialIds = /^[a-z\d-]{4,}$/i.test(value) ? ready.filter(item => item.id.toLowerCase().includes(code)) : [];
    if (partialIds.length) return partialIds;
    const name = convertKoreanSearch(value).replace(/\s/g, '');
    if (!name) return [];
    return ready.filter((item) => item.customerName.replace(/\s/g, '').includes(name));
  }, []);

  const scan = useCallback((raw: string, commit: boolean, source: 'scanner' | 'manual' = 'manual') => {
    if (working.current || deleting || !raw.trim()) return;
    const value = raw.trim();
    setError(''); setFeedback('');
    let all: ConfirmedOrder[] = [];
    try { all = readConfirmedOrders(); setOrders(all); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '주문을 읽지 못했습니다.'); return; }
    let found: ReturnType<typeof findSavedGarment> = null;
    try { found = /^[\x20-\x7e]+$/.test(value) ? findSavedGarment(value) : null; }
    catch (cause) { setError(cause instanceof Error ? cause.message : '바코드 연결을 확인하지 못했습니다.'); return; }
    if (found) {
      if (commit && source === 'scanner' && isGarmentComplete(found.garment) && !found.garment.qcHoldReason)
        setHandoverScans(old => ({ ...old, [found.garment.garmentId]: handoverScanFingerprint(found.garment) }));
      selectOrder(found.order, found.garment.garmentId);
      setCandidates([found.order.id]);
      if (commit) setFeedback('조회만 완료했습니다. 주문을 확인한 뒤 출고 또는 복구 버튼을 선택하세요.');
      return;
    }
    const matches = resolve(value, all);
    if (!matches.length) { if (commit) setError('일치하는 출고 대기·출고 완료 주문을 찾지 못했습니다.'); setCandidates([]); setOrderId(''); setGarmentId(''); return; }
    if (matches.length > 1) {
      setOrderId(''); setGarmentId('');
      setCandidates(matches.map((item) => item.id));
      setFeedback(`${matches.length}건이 일치합니다. 출고할 주문을 직접 선택해 주세요.`);
      return;
    }
    setCandidates([matches[0].id]);
    selectOrder(matches[0]);
    if (commit) setFeedback('조회만 완료했습니다. 주문을 확인한 뒤 출고 또는 복구 버튼을 선택하세요.');
  }, [selectOrder, resolve, deleting]);

  useEffect(() => {
    const value = barcode.trim();
    if (!value || composing.current) return;
    // Debounced typing and scanner Enter only query. Departure requires a separate button.
    const timer = setTimeout(() => scan(value, false), 250);
    return () => clearTimeout(timer);
  }, [barcode, scan]);

  useEffect(() => {
    // Keyboard-wedge reader works anywhere outside editable fields.
    const key = (event: KeyboardEvent) => {
      if (deleting) { burst.current = { value: '', at: 0 }; return; }
      const target = event.target instanceof Element ? event.target : null;
      if (target?.closest('input,textarea,select,[contenteditable="true"]') ||
          event.ctrlKey || event.altKey || event.metaKey || event.repeat) {
        burst.current = { value: '', at: 0 }; return;
      }
      if (event.key === 'Shift') return;
      const now = performance.now();
      if (event.key === 'Enter') {
        const pending = burst.current; burst.current = { value: '', at: 0 };
        if (pending.value.length > 4 && now - pending.at < 120) { event.preventDefault(); scan(pending.value, true, 'scanner'); }
      } else if (barcodeCharFromKey(event)) {
        const ch = barcodeCharFromKey(event)!;
        burst.current = { value: now - burst.current.at < 120 ? (burst.current.value + ch).slice(0, 160) : ch, at: now };
      } else burst.current = { value: '', at: 0 };
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [scan, deleting]);

  const readyOrders = orders.filter(isReadyForHandover)
    .sort((a, b) => currentOperations(a).updatedAt.localeCompare(currentOperations(b).updatedAt));
  const comparisons = useOrderComparisons(readyOrders.map(item => item.id), String(composerOpen));
  const order = orders.find((item) => item.id === orderId);
  const garments = order ? listGarments(order) : [];
  const garment = garments.find((item) => item.garmentId === garmentId);
  const operation = order ? currentOperations(order) : null;
  const blockers = order ? staffHandoverBlockers(order) : [];
  const handedOver = Boolean(operation?.completedAt || operation?.stage === '배달중' || operation?.stage === '배달완료');
  const ready = Boolean(order && !handedOver && blockers.length === 0);
  const scanned = order ? handoverScanCount(order, handoverScans) : 0;

  const handover = () => { if (ready && order) commitHandover(order.id, handoverScans); };
  const candidateOrders = candidates.map((id) => orders.find((item) => item.id === id)).filter((item): item is ConfirmedOrder => Boolean(item));
  const undoOrder = latestHandedOrder(orders);

  return <main className="garment-scanner">
    {comparisons.viewer}
    {comparisons.note && <p role="status" className="garment-scanner__feedback">{comparisons.note}</p>}
    <div className="garment-scanner__wrap">
      <header className="garment-scanner__topline"><div className="garment-scanner__brand"><StoreName /> <small>완성 의류 출고</small></div>
        <button type="button" className="garment-scanner__button" disabled={!undoOrder || busy}
          title={undoOrder ? `${undoOrder.customerName} · ${currentOperations(undoOrder).completedAt || currentOperations(undoOrder).updatedAt} · 결제는 유지됩니다` : '되돌릴 출고 이력이 없습니다'}
          onClick={() => undoOrder && restoreOrder(undoOrder.id, undoOrder)} data-testid="button-undo-handover">↩ 직전 출고 취소 (뒤로 가기){undoOrder ? ` · ${undoOrder.customerName}` : ''}</button></header>

      <section className="handover-board" aria-labelledby="handover-board-title">
        <div className="handover-board__head">
          <h1 id="handover-board-title">출고 대기 <span data-testid="text-ready-count">{readyOrders.length}</span></h1>
          <p>하단 검색·스캔은 조회만 합니다. 주문을 확인한 뒤 출고 완료 또는 출고 대기 복구를 선택하세요.</p>
        </div>
        {readyOrders.length === 0
          ? <div className="handover-board__empty" data-testid="status-ready-empty">
              <strong>지금 출고할 완성 의류가 없습니다.</strong>
              <span>세탁·검수가 끝난 주문이 이곳에 나타납니다.</span>
            </div>
          : <div className="handover-board__grid">
            {readyOrders.map((item) => {
              const list = listGarments(item);
              const delivery = item.choices.deliveryRequested;
              const picked = item.id === orderId;
              return <article key={item.id} className="handover-card" data-selected={picked} data-candidate={candidates.includes(item.id)}
                data-testid={`card-ready-order-${item.id}`}>
                <button type="button" className="handover-card__delete" disabled={busy || !!deleting}
                  aria-label={`${item.customerName} 주문 ${item.id} 삭제`}
                  title="이 주문 삭제" data-testid={`button-delete-ready-order-${item.id}`}
                  onClick={() => { setError(''); setFeedback(''); burst.current = { value: '', at: 0 }; setDeleting(item); }}>
                  <Trash2 aria-hidden="true" />
                </button>
                <button type="button" ref={(el) => { cardRefs.current[item.id] = el; }} className="handover-card__select"
                  aria-pressed={picked} onClick={() => selectOrder(item)} data-testid={`button-select-order-${item.id}`}>
                  <span className="handover-card__top"><code>{item.id.slice(-8).toUpperCase()}</code>
                    <span className="handover-card__mode">{delivery ? <Truck aria-hidden="true" /> : <Store aria-hidden="true" />}{delivery ? '배달' : '매장'}</span></span>
                  <strong>{item.customerName} <PaymentBadge order={item} /> <small>{last4(item.customerPhone)}</small></strong>
                  <span className="handover-card__items">{list.map((g) => g.itemName).slice(0, 3).join(' · ')}{list.length > 3 ? ` 외 ${list.length - 3}` : ''}</span>
                </button>
                <div className="handover-card__foot">
                  <button type="button" className="handover-card__folder" onClick={()=>openCustomerNotice(item.id,'complete-pickup')}>고객 알림 편집·발송</button>
                  <NoticeQuickActions orderId={item.id} stage="release"/>
                  <em>{list.length}벌</em>
                  <button type="button" className="handover-card__folder" title="접수 사진 폴더 열기"
                    onClick={(event) => { event.stopPropagation(); void openPhotoFolder(item.id, 'intake')
                      .then((r) => setFolderNote(`${item.customerName} · 탐색기에서 열었습니다 · ${r.folder}`))
                      .catch((c) => setFolderNote(c instanceof Error ? c.message : '폴더를 열지 못했습니다.')); }}
                    data-testid={`button-card-photo-folder-${item.id}`}><FolderOpen aria-hidden="true" />사진 폴더</button>
                  {(comparisons.counts[item.id] ?? 0) > 0 && <button type="button" className="handover-card__comparison"
                    disabled={comparisons.opening} onClick={event => { event.stopPropagation(); void comparisons.open(item.id); }}
                    data-testid={`button-card-comparison-${item.id}`}>✨ 세탁 전후 사진</button>}
                  <button type="button" className="handover-card__go" disabled={busy}
                    onClick={() => commitHandover(item.id, handoverScans)} data-testid={`button-card-handover-${item.id}`}>
                    <PackageCheck aria-hidden="true" />출고</button>
                </div>
              </article>;
            })}
          </div>}
      </section>

      {(error || captureError) && <p className="garment-scanner__error" role="alert" data-testid="status-scanner-error">{error || captureError}</p>}
      {folderNote && !order && <p className="garment-scanner__feedback" role="status" data-testid="status-card-folder">{folderNote}</p>}
      {feedback && <p className="garment-scanner__feedback" role="status" data-testid="status-scanner-feedback">{feedback}</p>}

      {order && <section className="staff-scan-result handover-detail" data-testid="panel-selected-order">
        <div className="garment-scanner__tools" data-testid="toolbar-scanner-order">
          <strong>{order.customerName} · {order.totalQuantity}점</strong>
          {(['intake', 'comparison'] as const).map((kind) => <button key={kind} type="button" className="garment-scanner__button"
            onClick={() => void openPhotoFolder(order.id, kind).then((r) => setFolderNote(`탐색기에서 열었습니다 · ${r.folder}`))
              .catch((c) => setFolderNote(c instanceof Error ? c.message : '폴더를 열지 못했습니다.'))}
            data-testid={`button-scanner-folder-${kind}`}><FolderOpen aria-hidden="true" />{kind === 'intake' ? '접수 사진 폴더' : '전후 사진 폴더'}</button>)}
          <button type="button" className="garment-scanner__button" onClick={() => setComposerOpen(true)} data-testid="button-scanner-before-after">
            <Images aria-hidden="true" />전·후 사진 만들기</button>
          {folderNote && <span role="status">{folderNote}</span>}
        </div>
        <div className="handover-detail__body">
          <div>
            <h2 data-testid="text-scanner-customer-name">{order.customerName} <small>연락처 끝 {last4(order.customerPhone)}</small></h2>
            <div className="handover-detail__garments">
              {garments.map((g) => <button key={g.garmentId} type="button" className="handover-chip"
                aria-pressed={g.garmentId === garmentId} onClick={() => setGarmentId(g.garmentId)}
                data-testid={`button-select-garment-${g.garmentId}`}>
                {g.itemName} {g.sequence}/{g.totalSequence}
                <small>{garmentDisplayStatus(order, g, isGarmentComplete(g) ? '출고 준비 완료' : garmentProcessStatus(order, g))}</small>
              </button>)}
            </div>
            <ScannerOrderProgress order={order} scans={handoverScans} />
          </div>
          <div className="garment-scanner__handover">
            {handedOver ? <span role="status" data-testid="status-handed-over">{order.choices.deliveryRequested && !operation?.completedAt
              ? '배달 출고 완료 · 배달 중입니다.' : '인도가 완료되었습니다.'}</span>
              : <>
                {blockers.length > 0 && <ul className="handover-detail__blockers" data-testid="scanner-handover-blockers">
                  {blockers.map((text) => <li key={text}>{text}</li>)}</ul>}
                <label className="garment-scanner__actor">확인 직원 (선택)
                  <input value={actor} onChange={(e) => { setActor(e.target.value); try { window.localStorage.setItem(ACTOR_KEY, e.target.value); } catch { /* optional */ } }}
                    placeholder="이름" data-testid="input-handover-actor" /></label>
                <button type="button" className="garment-scanner__primary" disabled={!ready || busy} onClick={handover} data-testid="button-scanner-handover">
                  {order.choices.deliveryRequested ? '실제 배달 출고 확정' : '고객에게 실제 인도 확정'}
                </button>
                {ready && <small>{scanned === garments.length ? '전 품목 스캔 확인됨' : `스캔 ${scanned}/${garments.length} · 직원 확인 인도로 기록됩니다`}</small>}
              </>}
          </div>
        </div>
      </section>}
      {composerOpen && order && <BeforeAfterComposer order={order} onClose={() => setComposerOpen(false)} />}
      {deleting && <OrderDeletionDialog order={deleting}
        confirmationText="해당 출고 대기 세탁물(주문)을 정말 삭제하시겠습니까? 삭제 시 통계 및 알림 대상에서 완전히 제외됩니다."
        onClose={() => setDeleting(null)}
        onDeleted={() => {
          // Called only after the existing synchronous SQLite-backed save succeeds.
          setDeleting(null); setOrderId(''); setGarmentId(''); setCandidates([]);
          setHandoverScans({}); setBarcode(''); setComposerOpen(false); setFolderNote('');
          nameBuffer.current = { raw: '', display: '' }; burst.current = { value: '', at: 0 };
          lastKeyAt.current = []; refresh();
          setFeedback('선택한 주문을 삭제 표시했습니다. 출고 대기·통계·알림·바코드 인도 대상에서 제외했습니다. 원본 사진·태그는 보존됩니다.');
        }} />}

      {candidateOrders.length > 0 && <section className="handover-choices" data-testid="panel-lookup-choices">
        <strong>조회 결과 {candidateOrders.length}건 · 조회만으로 출고되지 않습니다</strong>
        {candidateOrders.map((item) => <div key={item.id} className="handover-choices__row">
          <span><code>{item.id.slice(-8).toUpperCase()}</code> {item.customerName} · 끝 {last4(item.customerPhone)} · {listGarments(item).length}벌 · {currentOperations(item).stage}</span>
          <button type="button" className="garment-scanner__button" onClick={() => { selectOrder(item); focusCard(item.id); }} data-testid={`button-choice-select-${item.id}`}>보기</button>
          {isReadyForHandover(item) && <button type="button" className="garment-scanner__primary" disabled={busy} onClick={() => commitHandover(item.id, handoverScans)} data-testid={`button-choice-handover-${item.id}`}>출고 완료 처리</button>}
          {canRestoreHandover(item) && <button type="button" className="garment-scanner__button" disabled={busy} onClick={() => restoreOrder(item.id, item)} data-testid={`button-choice-restore-${item.id}`}>출고 대기로 복구</button>}
        </div>)}
      </section>}

      <form className="handover-lookup" onSubmit={(event) => {
        event.preventDefault();
        if (composing.current) return;
        const visible = input.current?.value ?? barcode;
        const value = nameBuffer.current.display === visible ? nameBuffer.current.raw : visible;
        const t = lastKeyAt.current; lastKeyAt.current = [];
        const fast = t.length > 4 && t[t.length - 1] - t[0] < t.length * 40;
        scan(value, true, fast && /^[\x20-\x7e]+$/.test(value.trim()) ? 'scanner' : 'manual');
      }}>
        <ScanLine aria-hidden="true" />
        <input ref={input} value={barcode} onChange={(event) => {
          const raw = event.target.value;
          const previous = nameBuffer.current;
          const candidate = raw.startsWith(previous.display) ? previous.raw + raw.slice(previous.display.length) : raw;
          const display = composing.current ? raw : convertKoreanSearch(candidate);
          nameBuffer.current = { raw: candidate, display };
          setBarcode(display);
        }}
          aria-label="바코드·주문번호·이름·연락처 끝 4자리" inputMode="text" lang="ko" autoCapitalize="off" spellCheck={false}
          onCompositionStart={() => { composing.current = true; }}
          onCompositionEnd={(event) => {
            composing.current = false; setBarcode(event.currentTarget.value);
            nameBuffer.current = { raw: event.currentTarget.value, display: event.currentTarget.value };
          }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault();
              if (!event.nativeEvent.isComposing && !composing.current && event.keyCode !== 229)
                event.currentTarget.form?.requestSubmit();
              return;
            }
            if (event.key.length === 1) lastKeyAt.current = [...lastKeyAt.current, performance.now()].slice(-160);
            if (event.key !== 'Enter' && !/^[\x20-\x7e]$/.test(event.key) && !event.ctrlKey && !event.metaKey && !composing.current) {
              const ch = barcodeCharFromKey(event.nativeEvent);
              if (ch) { event.preventDefault(); setBarcode((old) => (old + ch).slice(0, 160)); }
            }
          }}
          placeholder="바코드 · 주문번호 · 이름 · 연락처 끝 4자리 → Enter 조회" autoComplete="off" data-scanner-input data-testid="input-scanner-barcode" />
        <button type="submit" className="garment-scanner__primary" disabled={busy || !barcode.trim()} data-testid="button-scanner-lookup">조회</button>
      </form>
    </div>
  </main>;
}
