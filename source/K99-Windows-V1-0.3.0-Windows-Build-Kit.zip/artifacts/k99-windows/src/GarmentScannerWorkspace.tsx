import { useCallback, useEffect, useRef, useState } from 'react';
import { garmentDisplayStatus } from './handover-display';
import type { ConfirmedOrder } from './order-record';
import { readConfirmedOrders, updateSavedOrder } from './order-record';
import { currentOperations } from './order-operations';
import { garmentProcessStatus } from './laundry-process';
import { findSavedGarment, isGarmentComplete, listGarments, scanIssuedTagForHandover } from './garment-scanner';
import { finishOrderHandover, handoverBlockers, handoverScanFingerprint, type HandoverScans } from './order-handover';
import { ScannerOrderProgress, scannerCustomerChoices } from './ScannerOrderProgress';
import type { ScanDiagnostic } from './scanner-diagnostics';
import './garment-scanner.css';
import { FolderOpen, Images, Keyboard } from 'lucide-react';
import { BeforeAfterComposer } from './BeforeAfterComposer';
import { SavedOrderLookup } from './SavedOrderLookup';
import { openPhotoFolder } from './equipment-client';
import { barcodeCharFromKey } from './barcode-keys';

const ACTOR_KEY = 'k99-scan-staff-actor';

type Props = {
  initialOrderId?: string;
  initialGarmentId?: string;
  captureError?: string;
  onBack: () => void;
  onOpenCapture: (orderId: string, garmentId: string) => void;
  onOrderChange?: (order: ConfirmedOrder) => void;
};

export default function GarmentScannerWorkspace({ initialOrderId, initialGarmentId, captureError, onBack, onOrderChange }: Props) {
  const [orders, setOrders] = useState<ConfirmedOrder[]>([]);
  const [orderId, setOrderId] = useState(initialOrderId ?? '');
  const [composing, setComposing] = useState(false);
  const [folderNote, setFolderNote] = useState('');
  const [garmentId, setGarmentId] = useState(initialGarmentId ?? '');
  const [barcode, setBarcode] = useState('');
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [lastScan, setLastScan] = useState<ScanDiagnostic|null>(null);
  const [diagnosticOrderId, setDiagnosticOrderId] = useState(initialOrderId ?? '');
  const diagnosticInput = useRef<{keyEvents:string[];pasteRaw:string|null}>({keyEvents:[],pasteRaw:null});
  const [busy, setBusy] = useState(false);
  const [handoverScans,setHandoverScans] = useState<HandoverScans>({});
  const [actor, setActor] = useState(() => { try { return window.localStorage.getItem(ACTOR_KEY) ?? ''; } catch { return ''; } });
  const actorRef = useRef(actor);
  actorRef.current = actor;
  const [manualOpen, setManualOpen] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const working = useRef(false);
  const burst = useRef({ value: '', at: 0 });
  const refresh = useCallback(() => {
    try { setOrders(readConfirmedOrders()); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '접수 내역을 불러오지 못했습니다.'); }
  }, []);
  useEffect(() => {
    refresh();
    const focus = () => { refresh(); input.current?.focus(); };
    window.addEventListener('focus', focus);
    window.addEventListener('storage', refresh);
    input.current?.focus();
    return () => { window.removeEventListener('focus', focus); window.removeEventListener('storage', refresh); };
  }, [refresh]);

  const scan = useCallback((value: string, source:ScanDiagnostic['source']='input-submit', method: 'scanner' | 'manual-entry' | 'manual' = 'scanner', reason?: string) => {
    if (working.current) return;
    // Observe before trimming, clearing the input or attempting any lookup.
    setLastScan({raw:value,source,keyEvents:[...diagnosticInput.current.keyEvents],
      pasteRaw:diagnosticInput.current.pasteRaw,capturedAt:new Date().toISOString()});
    diagnosticInput.current={keyEvents:[],pasteRaw:null};
    if (working.current || !value.trim()) return;
    working.current = true; setBusy(true); setError(''); setFeedback(''); setBarcode('');
    try {
      const found = findSavedGarment(value);
      if (!found) {
        // Keep the current scoped order and its physical-scan receipts.
        // Standalone lookup retains its existing unknown-barcode behavior.
        if (!initialOrderId) { setOrderId(''); setGarmentId(''); }
        setError('등록되지 않은 바코드입니다. 태그를 다시 확인해 주세요.');
        return;
      }
      setOrderId(found.order.id); setGarmentId(found.garment.garmentId);
      setDiagnosticOrderId(current=>current || found.order.id);
      const result = scanIssuedTagForHandover(value, method, actorRef.current.trim() || '매장 직원', new Date(), reason);
      if (result.outcome !== 'blocked' && result.garment && result.order &&
          isGarmentComplete(result.garment) && !result.garment.qcHoldReason &&
          !currentOperations(result.order).cancelledAt && !currentOperations(result.order).completedAt) {
        const proof = handoverScanFingerprint(result.garment);
        setHandoverScans((old)=>({...old,[result.garment!.garmentId]:proof}));
      }
      if (result.outcome === 'blocked') setError(result.message);
      else setFeedback(result.outcome === 'duplicate'
        ? `${found.order.customerName} 고객님의 ${found.garment.itemName}입니다. 이미 완성 확인된 의류입니다.`
        : `${found.order.customerName} 고객님 · ${found.garment.itemName} · 출고 준비 완료 (인도 전)`);
      if (result.order) onOrderChange?.(result.order);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '바코드를 확인하지 못했습니다.');
    } finally {
      working.current = false; setBusy(false);
      refresh();
      input.current?.focus();
    }
  }, [refresh, initialOrderId, orderId, onOrderChange]);

  useEffect(() => {
    // A keyboard-wedge reader also works after a staff action, without another arm button.
    // Never intercept customer search, editable fields, IME or keyboard shortcuts.
    const key = (event: KeyboardEvent) => {
      const target = event.target instanceof Element ? event.target : null;
      if (target?.closest('input,textarea,select,[contenteditable="true"]') ||
          event.ctrlKey || event.altKey || event.metaKey || event.repeat) {
        burst.current = { value: '', at: 0 }; return;
      }
      if (event.key === 'Shift') return;
      diagnosticInput.current.keyEvents=[...diagnosticInput.current.keyEvents,event.key].slice(-512);
      const now = performance.now();
      if (event.key === 'Enter') {
        const pending = burst.current; burst.current = { value: '', at: 0 };
        if (pending.value.length > 2 && now - pending.at < 120) { event.preventDefault(); scan(pending.value,'keyboard-wedge'); }
      } else if (barcodeCharFromKey(event)) {
        const ch = barcodeCharFromKey(event)!;
        burst.current = { value: now - burst.current.at < 120 ? (burst.current.value + ch).slice(0, 160) : ch, at: now };
      } else burst.current = { value: '', at: 0 };
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [scan]);

  const order = orders.find((item) => item.id === orderId);
  const garments = order ? listGarments(order) : [];
  const garment = garments.find((item) => item.garmentId === garmentId);
  const operation = order ? currentOperations(order) : null;
  const allComplete = garments.length > 0 && garments.every(isGarmentComplete);
  const blockers = order ? handoverBlockers(order,handoverScans) : [];
  const handedOver = Boolean(operation?.completedAt || operation?.stage === '배달중');
  const ready = Boolean(order && garment && allComplete && !handedOver && blockers.length === 0);
  const manualReady = Boolean(order && garment && !handedOver &&
    !operation?.cancelledAt && !garment.qcHoldReason &&
    garmentProcessStatus(order, garment) === '출고 대기');
  const handover = () => {
    if (!ready || !order || working.current) return;
    working.current = true; setBusy(true); setError('');
    try {
      const latest = readConfirmedOrders().find((item) => item.id === order.id);
      if (!latest) throw new Error('원본 주문을 다시 확인해 주세요.');
      const updated = finishOrderHandover(latest,handoverScans);
      updateSavedOrder(updated, latest);
      // All receipts were checked before the guarded write. Carry them to the
      // committed handover version, rather than rendering a false 0/N reset.
      setHandoverScans(Object.fromEntries(listGarments(updated).map((item)=>
        [item.garmentId,handoverScanFingerprint(item)])));
      onOrderChange?.(updated);
      refresh(); setFeedback(`${latest.customerName} 고객님의 의류 ${garments.length}벌을 출고했습니다.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '출고하지 못했습니다.');
      refresh();
    } finally { working.current = false; setBusy(false); input.current?.focus(); }
  };

  const selectReady = () => {
    if (!garment || !manualReady) return;
    scan(garment.barcodeValue, 'input-submit', 'manual', '바코드 판독 불가 · 고객·의류 조회로 직원 확인');
  };

  return <main className="garment-scanner">
    <div className="garment-scanner__wrap">
      <header className="garment-scanner__topline"><div className="garment-scanner__brand">K99 품격세탁소 <small>과천점 · 출고 준비</small></div>
        <button type="button" className="garment-scanner__button" onClick={onBack} data-testid="button-back-from-scanner">돌아가기</button></header>
      {order && <div className="garment-scanner__tools" data-testid="toolbar-scanner-order">
        <strong>{order.customerName} · {order.totalQuantity}점</strong>
        {(['intake', 'comparison'] as const).map((kind) => <button key={kind} type="button" className="garment-scanner__button"
          onClick={() => void openPhotoFolder(order.id, kind).then((r) => setFolderNote(`탐색기에서 열었습니다 · ${r.folder}`))
            .catch((c) => setFolderNote(c instanceof Error ? c.message : '폴더를 열지 못했습니다.'))}
          data-testid={`button-scanner-folder-${kind}`}><FolderOpen aria-hidden="true" />{kind === 'intake' ? '세탁 접수 사진 폴더' : '세탁 전후 사진 폴더'}</button>)}
        <button type="button" className="garment-scanner__button" onClick={() => setComposing(true)} data-testid="button-scanner-before-after">
          <Images aria-hidden="true" />세탁 전·후 사진 만들기</button>
        {folderNote && <span role="status">{folderNote}</span>}
      </div>}
      {composing && order && <BeforeAfterComposer order={order} onClose={() => setComposing(false)} />}
      <div className="garment-scanner__split">
      <section className="staff-scan-prompt">
        <h1>바코드를 스캔하세요</h1>
        <p>세탁 후 검수와 다림질이 끝난 의류는 스캔 즉시 출고 준비 완료로 기록됩니다. 고객 인도는 오른쪽에서 따로 확인합니다.</p>
        <form onSubmit={(event) => {
          event.preventDefault();
          // A fast keyboard-wedge Enter must consume the input's current text,
          // not a render-time state snapshot that may be one character behind.
          scan(input.current?.value ?? barcode, 'input-submit', manualOpen ? 'manual-entry' : 'scanner');
        }}>
          <input ref={input} value={barcode} onChange={(event) => setBarcode(event.target.value)} aria-label="바코드 스캔"
            inputMode="text" lang="en" autoCapitalize="off" spellCheck={false}
            onKeyDown={event=>{
              diagnosticInput.current.keyEvents=[...diagnosticInput.current.keyEvents,event.key].slice(-512);
              // With a Korean IME active, map the physical key to ASCII instead of Hangul.
              if (event.key !== 'Enter' && !/^[\x20-\x7e]$/.test(event.key) && !event.ctrlKey && !event.metaKey) {
                const ch = barcodeCharFromKey(event.nativeEvent);
                if (ch) { event.preventDefault(); setBarcode((old) => (old + ch).slice(0, 160)); }
              }
            }}
            onPaste={event=>{diagnosticInput.current.pasteRaw=event.clipboardData.getData('text/plain');}}
            placeholder="태그의 바코드를 읽어주세요" autoComplete="off" data-scanner-input data-testid="input-scanner-barcode" />
          <button type="submit" disabled={busy || !barcode.trim()}>출고 준비 확인</button>
        </form>
        <small data-testid="status-scanner-listening">{busy ? '확인 중' : '다음 스캔 대기 중'}</small>
        <button type="button" className="garment-scanner__manual-toggle" aria-expanded={manualOpen}
          onClick={() => { setManualOpen((v) => !v); input.current?.focus(); }} data-testid="button-scanner-manual">
          <Keyboard aria-hidden="true" /> 바코드 직접 입력 · 고객으로 찾기
        </button>
        {manualOpen && <div className="staff-scan-search" data-testid="scanner-manual-panel">
          <p>바코드 숫자를 위 입력칸에 직접 입력하거나, 고객을 찾아 의류를 선택한 뒤 같은 출고 준비 처리를 합니다.</p>
          <input type="search" lang="ko" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="고객명 또는 연락처"
            aria-label="고객 검색" data-testid="input-search-scanner-orders" />
          {scannerCustomerChoices(orders, search, initialOrderId).map((item) =>
            <div key={item.id}><h3>{item.customerName} · 연락처 끝 {item.customerPhone.replace(/\D/g, '').slice(-4)}</h3>
              {listGarments(item).map((cloth) => <button key={cloth.garmentId} type="button" className="garment-scanner__button"
                aria-pressed={cloth.garmentId === garmentId}
                onClick={() => { setOrderId(item.id); setGarmentId(cloth.garmentId); setDiagnosticOrderId(item.id); }}
                data-testid={`button-select-garment-${cloth.garmentId}`}>{cloth.itemName} {cloth.sequence}/{cloth.totalSequence}</button>)}</div>)}
          {garment && !isGarmentComplete(garment) && <button type="button" className="garment-scanner__primary" disabled={busy || !manualReady}
            onClick={selectReady} data-testid="button-manual-ready">{garment.itemName} 출고 준비 완료 처리</button>}
          {garment && !isGarmentComplete(garment) && !manualReady &&
            <p>세탁 후 검수·다림질 완료를 확인하세요. 보류·취소·인도된 의류는 처리할 수 없습니다.</p>}
        </div>}
      </section>
      <section className="garment-scanner__result-col">
      {(error || captureError) && <p className="garment-scanner__error" role="alert" data-testid="status-scanner-error">{error || captureError}</p>}
      {feedback && <p className="garment-scanner__feedback" role="status" data-testid="status-scanner-feedback">{feedback}</p>}
      {order && garments.length > 0 ? <section className="staff-scan-result">
        <span>{garment ? '스캔한 의류' : '현재 주문의 의류'}</span>
        <h2 data-testid="text-scanner-customer-name">{order.customerName}</h2>
        {garment && <p className="staff-scan-item">{garment.itemName} <small>{garment.sequence}/{garment.totalSequence}벌 · {garment.serviceType.includes('premium') ? '프리미엄' : '일반'}</small></p>}
        <p>연락처 끝 {order.customerPhone.replace(/\D/g, '').slice(-4)}
          {garment && ` · ${garmentDisplayStatus(order, garment, isGarmentComplete(garment) ? '출고 준비 완료' : garmentProcessStatus(order, garment))}`}</p>
        <ScannerOrderProgress order={order} scans={handoverScans} />
        {!handedOver && blockers.length > 0 && <details data-testid="scanner-handover-blockers"><summary>인도 전 확인 {blockers.length}건</summary>
          <ul>{blockers.map((text)=><li key={text}>{text}</li>)}</ul></details>}
        <div className="garment-scanner__handover">
          <strong>고객 인도 · 별도 확인</strong>
          {handedOver ? <span role="status">{order.choices.deliveryRequested && !operation?.completedAt
            ? '배달 출고완료 · 배달 중입니다.' : '인도가 완료되었습니다.'}</span>
            : <button type="button" className="garment-scanner__primary" disabled={!ready || busy} onClick={handover} data-testid="button-scanner-handover">
              {order.choices.deliveryRequested ? '실제 배달 출고 확정' : '고객에게 실제 인도 확정'}
            </button>}
          {ready && <small>고객과 전체 품목을 눈으로 확인한 뒤에만 누르세요. 스캔만으로는 인도되지 않습니다.</small>}
        </div>
      </section> : <section className="staff-scan-result staff-scan-result--empty"><span>스캔 결과</span><p>고객 이름, 의류, 결과만 이곳에 표시됩니다.</p></section>}
      </section>
      </div>
      <SavedOrderLookup onResume={(id) => { setOrderId(id); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />
    </div>
  </main>;
}
