export type CameraHelpAction='iriun'|'driver'|'guide';
export async function cameraConnectionAction(action:CameraHelpAction):Promise<{message:string}>{
  if(window.k99Desktop?.cameraConnection)return window.k99Desktop.cameraConnection(action);
  const url=action==='guide'?'https://developer.android.com/studio/run/device?hl=ko#setting-up':
    action==='driver'?'https://developer.android.com/studio/run/oem-usb?hl=ko':'https://iriun.com/';
  const opened=window.open(url,'_blank','noopener,noreferrer');
  // noopener intentionally does not return a WindowProxy, so do not claim
  // installation or launch success from the return value.
  void opened;
  return {message:'공식 안내 페이지 열기를 요청했습니다. 팝업이 차단되었다면 브라우저에서 팝업을 허용해 주세요. 설치·휴대폰 허용은 직접 진행해 주세요.'};
}
