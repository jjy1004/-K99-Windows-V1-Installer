import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';
import { actualCleaningMethodChanged, careLabelConflict } from './inspection-record';
import { reviewClassification } from './item-intake-details';

export function hasIntakeConcern(value: string | undefined): boolean {
  return Boolean(value?.trim() && !/^(없음|이상\s*없음|정상|해당\s*없음|특이사항\s*없음|미해당)$/.test(value.trim()));
}

/** Actual exception evidence, never the presence of an inspection or a legacy status alone. */
export function specialistRequired(order: ConfirmedOrder, garment: GarmentRecord): boolean {
  const item = order.items[garment.itemIndex - 1];
  if (!item) return true;
  const inspection = order.inspection;
  const scope = inspection?.affectedGarmentIds;
  const scoped = !!scope?.length && new Set(scope).size === scope.length &&
    scope.every(id => order.garments?.some(g => g.garmentId === id && g.orderId === order.id));
  const inScope = !scoped || scope!.includes(garment.garmentId);
  // Explicit physical-garment evidence can scope legacy order/item-level notes;
  // independent current-cycle per-garment findings must always remain blockers.
  if (inScope && (order.choices.luxuryItem || hasIntakeConcern(order.choices.customerRequests))) return true;
  if (inScope && item.intakeDetails && reviewClassification(item.itemId, item.intakeDetails).requiresReview) return true;
  for (const stage of ['intake', 'prewash'] as const) {
    const review = garment.workflowReviews?.[stage];
    if (review?.cycle === (garment.rewashCount ?? 0) &&
        review.selected.some(key => ['method','label','color','special','luxury','price','consent'].includes(key))) return true;
  }
  if (!inspection) return false;
  // Only an explicit, ownership-checked staff scope may separate a contract exception.
  // Old records without this evidence retain their existing order-wide safeguards.
  if (scoped) {
    if (!inScope) return false;
    if (inspection.needsApproval) return true;
  }
  if (inspection.response?.choice === '세탁 진행 거절' || inspection.response?.choice === '보류') return true;
  // Undivided order-level price/waiver/risk changes affect the whole contract.
  if (inspection.revisedPrice !== order.estimatedTotal || inspection.riskRequired ||
      inspection.waiverRequired || inspection.approvalRequirements?.price ||
      inspection.approvalRequirements?.waiver || (inspection.additionalCharge ?? 0) > 0) return true;
  const scopedRisk = inspection.items.some((item, index) => careLabelConflict(item) ||
    actualCleaningMethodChanged(order, inspection, index) || Boolean(item.riskFactors?.length));
  if (inspection.approvalRequirements?.risk && !scopedRisk) return true;
  if (inspection.approvalRequirements?.method && !inspection.items.some((item, index) =>
    item.method !== '기존 방법 유지' || actualCleaningMethodChanged(order, inspection, index))) return true;
  if (inspection.approvalRequirements?.work && !inspection.items.some(item =>
    item.additionalWork.some(work => work !== '추가 작업 없음'))) return true;
  const inspected = inspection.items[garment.itemIndex - 1];
  if (!inspected) return true;
  return inspected.method !== '기존 방법 유지' || careLabelConflict(inspected) ||
    actualCleaningMethodChanged(order, inspection, garment.itemIndex - 1) ||
    Boolean(inspected.riskFactors?.length) ||
    inspected.additionalWork.some(work => work !== '추가 작업 없음') ||
    Object.values(inspected.checks).some(check => check === '주의' || check === '문제 있음');
}

export function normalApprovalSignature(order: ConfirmedOrder, garment: GarmentRecord): string {
  const inspection = order.inspection;
  const scope = inspection?.affectedGarmentIds;
  const elsewhere = !!scope?.length && new Set(scope).size === scope.length &&
    scope.every(id => order.garments?.some(g => g.garmentId === id && g.orderId === order.id)) &&
    !scope.includes(garment.garmentId);
  // A reply about a different explicitly scoped garment must not invalidate
  // normal approvals mid-wash. New findings on THIS garment remain in the signature.
  const evidence = elsewhere ? ['exception-scoped-elsewhere'] : [
    inspection?.items[garment.itemIndex - 1], inspection?.revisedPrice,
    inspection?.riskRequired, inspection?.waiverRequired, inspection?.additionalCharge,
    inspection?.response?.choice, inspection?.affectedGarmentIds,
  ];
  return JSON.stringify([order.id, garment.orderId, garment.garmentId, order.items[garment.itemIndex - 1], order.choices.luxuryItem,
    order.choices.customerRequests, order.estimatedTotal, evidence,
    ...(['intake','prewash'] as const).map(stage => garment.workflowReviews?.[stage]?.selected ?? [])]);
}

export function normalGarmentApproved(order: ConfirmedOrder, garment: GarmentRecord): boolean {
  const approval = order.normalGarmentApprovals?.[garment.garmentId];
  return Boolean(approval && approval.cycle === (garment.rewashCount ?? 0) &&
    ['물세탁','드라이세탁'].includes(approval.method) && !specialistRequired(order, garment) &&
    approval.signature === normalApprovalSignature(order, garment));
}
