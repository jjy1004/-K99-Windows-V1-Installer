import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, RefreshCw, Shirt } from 'lucide-react';
import { fetchSimpleStatistics, type SimpleStatistics, type StatisticsMode } from './simple-statistics-client';
import './simple-statistics.css';
import { ManagementCustomerPanel } from './ManagementCustomerPanel';
import { PickupNoticeActions } from './PickupNoticeActions';
import { ManagementPriceEditor } from './ManagementPriceEditor';

const REFRESH_MS = 60_000;
const pad = (n: number) => String(n).padStart(2, '0');
function todayParts() {
  const s = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Seoul' });
  return s;
}
function defaultPeriod(mode: StatisticsMode) {
  const d = todayParts();
  return mode === 'day' ? d : mode === 'month' ? d.slice(0, 7) : d.slice(0, 4);
}
const valid = (mode: StatisticsMode, p: string) =>
  mode === 'day' ? /^\d{4}-\d{2}-\d{2}$/.test(p) : mode === 'month' ? /^\d{4}-\d{2}$/.test(p) : /^\d{4}$/.test(p);
const num = (v: number) => (Number.isFinite(v) ? v.toLocaleString('ko-KR') : '-');
const won = (v: number) => `${num(v)}원`;
const errText = (e: unknown) => (e instanceof Error && e.message ? e.message : '통계를 불러오지 못했습니다.');
function shiftPeriod(mode: StatisticsMode, p: string, delta: number) {
  if (!valid(mode, p)) return p;
  if (mode === 'year') return String(Number(p) + delta);
  if (mode === 'month') {
    const [y, m] = p.split('-').map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
  }
  const [y, m, dd] = p.split('-').map(Number);
  const d = new Date(y, m - 1, dd + delta);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
const dateTime = (v?: string) => {
  if (!v) return '-';
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return `${v} (시각 미기록)`;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', dateStyle: 'short', timeStyle: 'short', hour12: false });
};

const TABS: [StatisticsMode, string][] = [['day', '일별'], ['month', '월별'], ['year', '연간']];

export function SimpleStatisticsCenter({ onBack, onNewIntake }: { onBack: () => void; onNewIntake: () => void }) {
  const [mode, setMode] = useState<StatisticsMode>('day');
  const [period, setPeriod] = useState(() => defaultPeriod('day'));
  const [data, setData] = useState<SimpleStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const seq = useRef(0);
  const tableRef = useRef<HTMLElement>(null);
  const customerRef = useRef<HTMLDivElement>(null);
  const [pricesOpen, setPricesOpen] = useState(false);

  const load = useCallback((silent = false) => {
    if (!valid(mode, period)) { setError('기간 형식을 확인해 주세요.'); setLoading(false); return; }
    const id = ++seq.current;
    if (!silent) { setLoading(true); setData((d) => (d && d.mode === mode && d.period === period ? d : null)); }
    fetchSimpleStatistics(mode, period).then((r) => {
      if (id !== seq.current) return;
      setData(r); setError(''); setUpdatedAt(new Date());
    }).catch((e) => { if (id === seq.current) setError(errText(e)); })
      .finally(() => { if (id === seq.current) setLoading(false); });
  }, [mode, period]);

  useEffect(() => {
    load();
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') load(true); }, REFRESH_MS);
    const onVisible = () => { if (document.visibilityState === 'visible') load(true); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    window.addEventListener('storage', onVisible);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
      window.removeEventListener('storage', onVisible);
    };
  }, [load]);

  const switchMode = (m: StatisticsMode) => { setMode(m); setPeriod(defaultPeriod(m)); };
  const goSales = () => {
    if (mode !== 'month') { setMode('month'); setPeriod(defaultPeriod('month')); }
    window.requestAnimationFrame(() => { tableRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); tableRef.current?.focus({ preventScroll: true }); });
  };
  const goCustomers = () => {
    const box = customerRef.current; if (!box) return;
    box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    (box.querySelector<HTMLInputElement>('input[type="search"]') ?? box).focus({ preventScroll: true });
  };
  const shown = data && data.mode === mode && data.period === period ? data : null;
  const cards: [string, string, string][] = [
    ['총 접수 건수', shown ? `${num(shown.summary.orderCount)}건` : '-', 'orders'],
    ['총 세탁물 수', shown ? `${num(shown.summary.itemCount)}점` : '-', 'items'],
    ['총 매출액(세탁비)', shown ? won(shown.summary.totalAmount) : '-', 'amount'],
  ];

  return <main className="ss-center" data-testid="management-center">
    <div className="ss-wrap">
      <header className="ss-top">
        <div className="ss-brand"><span className="ss-mono">K99</span><div><strong>품격세탁소 · 과천점</strong><small>접수 통계</small></div></div>
        <div className="ss-actions">
          <button type="button" className="ss-primary" onClick={onNewIntake} data-testid="button-management-new-intake"><Shirt /> 새 접수</button>
          <button type="button" onClick={onBack} data-testid="button-back-management"><ArrowLeft /> 접수로</button>
        </div>
      </header>

      <div ref={customerRef} tabIndex={-1} id="management-customers"><ManagementCustomerPanel /></div>
      <div className="ss-heading">
        <h1>통계</h1>
        <span className="ss-time" data-testid="text-management-updated">{updatedAt ? `마지막 갱신 ${updatedAt.toLocaleTimeString('ko-KR', { hour12: false })} · 1분마다 자동 갱신` : '불러오는 중'}</span>
      </div>

      <div className="ss-controls">
        <div className="ss-tabs" role="tablist" aria-label="통계 기간 단위">
          {TABS.map(([key, label]) => <button key={key} type="button" role="tab" aria-selected={mode === key}
            onClick={() => switchMode(key)} data-testid={`tab-statistics-${key}`}>{label}</button>)}
        </div>
        <div className="ss-period">
          <button type="button" aria-label="이전 기간" onClick={() => setPeriod((p) => shiftPeriod(mode, p, -1))} data-testid="button-period-prev">이전</button>
          {mode === 'day' && <input type="date" value={period} onChange={(e) => e.target.value && setPeriod(e.target.value)} aria-label="날짜 선택" data-testid="input-period-day" />}
          {mode === 'month' && <input type="month" value={period} onChange={(e) => e.target.value && setPeriod(e.target.value)} aria-label="월 선택" data-testid="input-period-month" />}
          {mode === 'year' && <input type="number" min={2000} max={2100} value={period} onChange={(e) => /^\d{4}$/.test(e.target.value) && setPeriod(e.target.value)} aria-label="연도 선택" data-testid="input-period-year" />}
          <button type="button" aria-label="다음 기간" onClick={() => setPeriod((p) => shiftPeriod(mode, p, 1))} data-testid="button-period-next">다음</button>
          <button type="button" onClick={() => setPeriod(defaultPeriod(mode))} data-testid="button-period-current">{mode === 'day' ? '오늘' : mode === 'month' ? '이번 달' : '올해'}</button>
          <button type="button" className="ss-icon" aria-label="새로고침" onClick={() => load()} disabled={loading} data-testid="button-refresh-management"><RefreshCw className={loading ? 'spin' : ''} /></button>
        </div>
      </div>

      {error && <div className="ss-alert" role="alert" data-testid="status-management-error">
        <span>통계 조회 실패: {error}{shown ? ' · 이전에 받은 자료를 표시하고 있습니다.' : ''}</span>
        <button type="button" onClick={() => load()} data-testid="button-retry-management">다시 시도</button>
      </div>}

      <section className="ss-cards" aria-label="기간 합계">
        {cards.map(([label, value, key]) => <div key={key} className={`ss-card ss-card-${key}`}>
          <span>{label}</span>
          {loading && !shown ? <i className="ss-skel" /> : <strong data-testid={`text-summary-${key}`}>{value}</strong>}
        </div>)}
      </section>

      <PickupNoticeActions onSales={goSales} onCustomers={goCustomers} onPrices={() => setPricesOpen(true)} />
      {pricesOpen && <ManagementPriceEditor onClose={() => setPricesOpen(false)} />}

      <section ref={tableRef} tabIndex={-1} id="statistics-table" className="ss-table-wrap" aria-label="기간별 내역">
        {loading && !shown ? <div aria-busy="true">{[0, 1, 2, 3].map((i) => <i key={i} className="ss-skel row" />)}</div>
          : !shown ? <p className="ss-empty">{error ? '표시할 통계가 없습니다. 다시 시도해 주세요.' : '자료를 불러오지 못했습니다.'}</p>
            : shown.rows.length === 0 ? <p className="ss-empty" data-testid="status-statistics-empty">이 기간에 접수 기록이 없습니다.</p>
              : <table className="ss-table">
                {mode === 'day' ? <>
                  <thead><tr><th>접수 시각</th><th>고객</th><th>연락처</th><th className="num">세탁물</th><th className="num">세탁비</th></tr></thead>
                  <tbody>{shown.rows.map((r, i) => <tr key={i} data-testid={`row-statistics-${i}`}>
                    <td>{dateTime(r.datetime)}</td><td>{r.customerName || '-'}</td><td>{r.customerPhone || '-'}</td>
                    <td className="num">{num(r.itemCount)}점</td><td className="num">{won(r.totalAmount)}</td></tr>)}</tbody>
                </> : <>
                  <thead><tr><th>{mode === 'month' ? '날짜' : '월'}</th><th className="num">접수 건수</th><th className="num">세탁물</th><th className="num">세탁비</th></tr></thead>
                  <tbody>{shown.rows.map((r, i) => <tr key={r.period || i} data-testid={`row-statistics-${i}`}>
                    <td>{r.period}</td><td className="num">{num(r.orderCount)}건</td>
                    <td className="num">{num(r.itemCount)}점</td><td className="num">{won(r.totalAmount)}</td></tr>)}</tbody>
                </>}
              </table>}
      </section>
    </div>
  </main>;
}
