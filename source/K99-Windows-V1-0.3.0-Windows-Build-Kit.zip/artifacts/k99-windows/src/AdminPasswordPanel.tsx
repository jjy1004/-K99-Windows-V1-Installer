import { Link } from 'wouter';
import './admin-password-panel.css';

export function AdminPasswordPanel() {
  return <section className="admin-password" data-testid="panel-admin-password">
    <h2>매장 단독 PC · Zero-Auth</h2>
    <p>이 Windows 앱은 관리자 비밀번호 입력 없이 사용합니다. 기존 암호 기록이나 고객 데이터는 초기화하지 않습니다.</p>
    <Link href="/maintenance">데이터 보존 · 장부 가져오기 · 백업 설정 열기</Link>
  </section>;
}
export default AdminPasswordPanel;
