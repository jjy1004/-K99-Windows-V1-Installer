import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { changeAdminPassword, getAdminCredentialStatus, recoverAdminPassword } from '@workspace/api-client-react';
import './admin-password-panel.css';

type Status = { configured: boolean; managed: boolean; environmentRecoveryRequired: boolean };
const MIN = 16;
const MAX = 1024;

function lengthError(value: string) {
  if (value.length < MIN) return `새 비밀번호는 ${MIN}자 이상이어야 합니다.`;
  if (value.length > MAX) return `새 비밀번호는 ${MAX}자 이하여야 합니다.`;
  return '';
}
function errorText(cause: unknown, fallback: string) {
  const data = (cause as { data?: { error?: unknown; message?: unknown } })?.data;
  const text = typeof data?.error === 'string' ? data.error : typeof data?.message === 'string' ? data.message : '';
  return text || fallback;
}

export function AdminPasswordPanel() {
  const [status, setStatus] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [recovery, setRecovery] = useState('');
  const [recNext, setRecNext] = useState('');
  const [recConfirm, setRecConfirm] = useState('');
  const [busy, setBusy] = useState<'' | 'change' | 'recover'>('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setLoadError('');
    try { const result = await getAdminCredentialStatus(); setStatus(result as Status); }
    catch (cause) { setLoadError(errorText(cause, '관리자 비밀번호 상태를 불러오지 못했습니다.')); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function submitChange(event: FormEvent) {
    event.preventDefault();
    const payload = { currentPassword: current, newPassword: next };
    const invalid = !current ? '현재 비밀번호를 입력해 주세요.' : lengthError(next)
      || (next !== confirm ? '새 비밀번호 확인이 일치하지 않습니다.' : '');
    setCurrent(''); setNext(''); setConfirm('');
    if (invalid) { setMessage({ kind: 'error', text: invalid }); return; }
    setBusy('change'); setMessage(null);
    try {
      const result = await changeAdminPassword(payload);
      setStatus(result as Status);
      setMessage({ kind: 'ok', text: '관리자 비밀번호를 변경했습니다.' });
      void load();
    } catch (cause) { setMessage({ kind: 'error', text: errorText(cause, '비밀번호를 변경하지 못했습니다. 현재 비밀번호를 확인해 주세요.') }); }
    finally { setBusy(''); }
  }

  async function submitRecover(event: FormEvent) {
    event.preventDefault();
    const payload = { recoveryPassword: recovery, newPassword: recNext };
    const invalid = !recovery ? '복구 비밀번호를 입력해 주세요.' : lengthError(recNext)
      || (recNext !== recConfirm ? '새 비밀번호 확인이 일치하지 않습니다.' : '')
      || (recNext === recovery ? '새 관리자 비밀번호는 복구 비밀번호와 달라야 합니다.' : '');
    setRecovery(''); setRecNext(''); setRecConfirm('');
    if (invalid) { setMessage({ kind: 'error', text: invalid }); return; }
    setBusy('recover'); setMessage(null);
    try {
      const result = await recoverAdminPassword(payload);
      setStatus(result as Status);
      setMessage({ kind: 'ok', text: '관리자 비밀번호를 복구했습니다.' });
      void load();
    } catch (cause) { setMessage({ kind: 'error', text: errorText(cause, '오프라인 복구는 1단계에서 지원되지 않습니다.') }); }
    finally { setBusy(''); }
  }

  return <section className="admin-password" data-testid="panel-admin-password" aria-labelledby="admin-password-title">
    <header className="admin-password__head">
      <h2 id="admin-password-title">관리자 비밀번호</h2>
      <button type="button" onClick={() => void load()} disabled={loading} data-testid="button-admin-password-refresh">상태 새로고침</button>
    </header>

    {loading && !status && <div className="admin-password__skeleton" aria-hidden="true"><span /><span /><span /></div>}
    {loadError && <div className="admin-password__alert admin-password__alert--error" role="alert" data-testid="text-admin-password-load-error">
      <span>{loadError}</span>
      <button type="button" onClick={() => void load()} data-testid="button-admin-password-retry">다시 시도</button>
    </div>}
    {status && <dl className="admin-password__status" data-testid="status-admin-password">
      <div><dt>설정 여부</dt><dd>{status.configured ? '설정됨' : '설정 안 됨'}</dd></div>
      <div><dt>관리 방식</dt><dd>{status.managed ? '앱에서 변경한 비밀번호 사용' : '최초 설정 비밀번호 사용'}</dd></div>
      <div><dt>오프라인 복구</dt><dd>1단계 미지원</dd></div>
    </dl>}

    {message && <p className={`admin-password__alert admin-password__alert--${message.kind}`} role={message.kind === 'error' ? 'alert' : 'status'}
      data-testid="text-admin-password-result">{message.text}</p>}

    <form className="admin-password__form" onSubmit={submitChange} autoComplete="off">
      <h3>비밀번호 변경</h3>
      <label>현재 비밀번호<input type="password" autoComplete="current-password" maxLength={MAX} value={current}
        onChange={(e) => setCurrent(e.target.value)} data-testid="input-admin-current-password" /></label>
      <label>새 비밀번호 · {MIN}자 이상<input type="password" autoComplete="new-password" maxLength={MAX} value={next}
        onChange={(e) => setNext(e.target.value)} data-testid="input-admin-new-password" /></label>
      <label>새 비밀번호 확인<input type="password" autoComplete="new-password" maxLength={MAX} value={confirm}
        onChange={(e) => setConfirm(e.target.value)} data-testid="input-admin-confirm-password" /></label>
      <button type="submit" disabled={busy !== '' || !status?.configured} data-testid="button-admin-change-password">
        {busy === 'change' ? '변경 중' : '비밀번호 변경'}</button>
    </form>

    <div className="admin-password__recovery">
      <h3>비밀번호를 잊은 경우</h3>
      <p data-testid="text-admin-recovery-unavailable">기본 비밀번호나 우회 방법은 없습니다. Windows V1 1단계에서는 오프라인 비밀번호 복구가 지원되지 않습니다. 현재 비밀번호를 안전한 곳에 보관해 주세요.</p>
      <p className="admin-password__locked" data-testid="text-admin-recovery-locked">
        오프라인 복구는 1단계에서 제공되지 않아 복구 입력란이 비활성화되어 있습니다.</p>
      <form className="admin-password__form" onSubmit={submitRecover} autoComplete="off" aria-disabled="true">
        <fieldset disabled style={{ border: 0, padding: 0, margin: 0, display: 'grid', gap: 'inherit' }}>
          <label>복구 비밀번호<input type="password" autoComplete="off" maxLength={MAX} value={recovery}
            onChange={(e) => setRecovery(e.target.value)} data-testid="input-admin-recovery-password" /></label>
          <label>새 관리자 비밀번호 · {MIN}자 이상<input type="password" autoComplete="new-password" maxLength={MAX} value={recNext}
            onChange={(e) => setRecNext(e.target.value)} data-testid="input-admin-recovery-new-password" /></label>
          <label>새 관리자 비밀번호 확인<input type="password" autoComplete="new-password" maxLength={MAX} value={recConfirm}
            onChange={(e) => setRecConfirm(e.target.value)} data-testid="input-admin-recovery-confirm-password" /></label>
          <button type="submit" data-testid="button-admin-recover-password">
            {busy === 'recover' ? '복구 중' : '비밀번호 복구 (1단계 미지원)'}</button>
        </fieldset>
      </form>
    </div>
  </section>;
}

export default AdminPasswordPanel;
