import { Link } from 'wouter';
import './admin-password-panel.css';

export function AdminPasswordPanel() {
  return <section className="admin-password" data-testid="panel-admin-password">
    <h2>매장 단독 PC · 일상 업무는 비밀번호 없이</h2>
    <p>접수·검색·단가 수정·장부 가져오기는 그대로 사용합니다. 고객 명부 엑셀 내보내기만 상단 매장 맞춤 설정의 관리자 비밀번호로 보호합니다. 기존 암호 기록과 고객 데이터는 초기화하지 않습니다.</p>
    <Link href="/maintenance">데이터 보존 · 장부 가져오기 · 백업 설정 열기</Link>
  </section>;
}
export default AdminPasswordPanel;
