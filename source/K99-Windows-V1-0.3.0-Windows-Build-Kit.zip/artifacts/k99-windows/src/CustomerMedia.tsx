import { type ReactNode, useEffect, useReducer, useRef, useState } from 'react';
import type { LiveVideoStatus } from './customer-video-channel';
import {
  INITIAL_CUSTOMER_MEDIA, customerMediaReducer, customerVideoPath, customerPlaybackError,
  type CustomerMediaCommand,
} from './customer-media';
const MEDIA_STATUS = 'k99-customer-media-status';
export function CustomerMedia({ sourceId, command, children, onStatus, idle = false, receiptRevision = 0 }: {
  sourceId: string; command?: CustomerMediaCommand; children: ReactNode;
  onStatus?: (status: LiveVideoStatus) => void;
  idle?: boolean; receiptRevision?: number;
}) {
  const [state, dispatch] = useReducer(customerMediaReducer, INITIAL_CUSTOMER_MEDIA);
  const videoRef = useRef<HTMLVideoElement>(null);
  const attemptRef = useRef(0);
  const diagnostics = useRef<unknown[]>([]);
  const [returnToPromo, setReturnToPromo] = useState(false);
  const [promoFailed, setPromoFailed] = useState(false);
  const video = ['value','process','water','sneakers'].includes(state.phase)
    ? state.phase as 'value' | 'process' | 'water' | 'sneakers' : null;
  const report = (event: string, player: HTMLVideoElement, error = '', reason?: unknown) => {
    const decode = player as HTMLVideoElement & { webkitAudioDecodedByteCount?: number };
    const diagnostic = {
      at: new Date().toISOString(), event, video, commandId: state.commandId,
      src: player.currentSrc || player.src, readyState: player.readyState, networkState: player.networkState,
      currentTime: player.currentTime, duration: Number.isFinite(player.duration) ? player.duration : null,
      paused: player.paused, muted: player.muted, volume: player.volume,
      decodedVideoFrames: player.getVideoPlaybackQuality?.().totalVideoFrames ?? null,
      decodedAudioBytes: decode.webkitAudioDecodedByteCount ?? null,
      mediaErrorCode: player.error?.code ?? null, mediaErrorMessage: player.error?.message ?? null,
      rejection: reason && typeof reason === 'object' && 'name' in reason ? String(reason.name) : null,
      pageOrigin: location.origin,
      mp4Support: player.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"'),
    };
    diagnostics.current = [...diagnostics.current, diagnostic].slice(-40);
    try { sessionStorage.setItem(`k99-customer-media-log:${sourceId}`, JSON.stringify(diagnostics.current)); } catch { /* Live log remains. */ }
    console.info('[K99 customer media]', diagnostic);
    onStatus?.({ error, diagnostic });
    try { if(!window.k99Desktop)window.opener?.postMessage({ type: MEDIA_STATUS, sourceId, error, diagnostic }, location.origin); }
    catch { /* A disconnected opener cannot prevent playback or the live channel report. */ }
  };
  useEffect(() => { if (command) dispatch({ type: 'manual', command }); }, [command?.id]);
  useEffect(() => { setReturnToPromo(false); }, [receiptRevision, idle]);
  useEffect(() => {
    if (!video) return;
    const player = videoRef.current;
    if (!player) return;
    const attempt = ++attemptRef.current;
    let live = true;
    let failed = false;
    let frame: number | undefined;
    let frameReported = false;
    let startTimer: ReturnType<typeof setTimeout> | undefined;
    const valid = () => live && attempt === attemptRef.current;
    const listen = (event: string) => {
      if (!valid()) return;
      report(event, player);
      if(event==='playing')clearTimeout(startTimer);
      if (event === 'playing' && !frameReported && 'requestVideoFrameCallback' in player) {
        frame = player.requestVideoFrameCallback(() => {
          if (valid()) { frameReported = true; report('first-frame', player); }
        });
      }
    };
    const fail = (event: string, reason?: unknown) => {
      if (!valid() || failed) return;
      failed = true;
      report(event, player, customerPlaybackError(reason, player.error?.code), reason);
      dispatch({ type: 'playback-failed' });
    };
    const handlers = ['loadedmetadata','canplay','playing','waiting','stalled','ended'].map(event => {
      const handler = () => {
        listen(event);
        if (event === 'ended' && valid()) {
          setReturnToPromo(true); dispatch({ type: 'ended' });
        }
      };
      player.addEventListener(event, handler);
      return { event, handler };
    });
    const onError = () => fail('media-error');
    player.addEventListener('error', onError);
    startTimer=setTimeout(()=>fail('play-start-timeout'),12000);
    report('play-request', player);
    // Same engine for every clip. Original audio stays enabled; failures never
    // become muted/simulated playback or a technical error wall for the customer.
    void player.play().then(() => { if (valid()) report('play-resolved', player); })
      .catch(reason => fail('play-rejected', reason));
    return () => {
      live = false;
      clearTimeout(startTimer);
      if (frame !== undefined) player.cancelVideoFrameCallback(frame);
      handlers.forEach(({ event, handler }) => player.removeEventListener(event, handler));
      player.removeEventListener('error', onError);
      player.pause();
    };
  }, [video, state.commandId, sourceId]);
  if (!video) {
    if ((idle || returnToPromo) && !promoFailed) return <main className="customer-shell customer-video-screen customer-promo-screen" data-testid="customer-promo-screen">
      <video className="customer-media-video" src={window.k99Desktop
        ? new URL('/videos/promo.mp4', window.location.href).href
        : customerVideoPath('value', import.meta.env.BASE_URL)}
        autoPlay loop muted playsInline controls={false} preload="auto"
        data-testid="customer-promo-video" onError={() => {
          setPromoFailed(true);
          onStatus?.({ error: '대기 홍보 영상을 재생할 수 없습니다. 로컬 promo.mp4 파일을 확인해 주세요.',
            diagnostic: { event: 'promo-error', commandId: '', video: 'promo' } });
        }} />
    </main>;
    return <>{children}</>;
  }
  return <main className="customer-shell customer-video-screen" data-testid="customer-video-screen">
    <div className="customer-media-shell">
      <video key={`${video}:${state.commandId ?? 'auto'}`} ref={videoRef} className="customer-media-video"
        src={window.k99Desktop ? new URL(`/videos/${video}.mp4`,window.location.href).href : customerVideoPath(video, import.meta.env.BASE_URL)}
        autoPlay playsInline controls={false} preload="auto"
        data-testid="customer-media-video" data-video={video} />
      <button type="button" onClick={() => {
        if (videoRef.current) report('ended', videoRef.current);
        setReturnToPromo(true); dispatch({ type: 'ended' });
      }}
        className="customer-media-close" aria-label="안내 영상 닫기" data-testid="button-customer-video-close">닫기</button>
    </div>
  </main>;
}
