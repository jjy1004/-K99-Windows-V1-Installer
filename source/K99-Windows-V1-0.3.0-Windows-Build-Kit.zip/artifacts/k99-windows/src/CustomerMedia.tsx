import { type ReactNode, useEffect, useReducer, useRef, useState } from 'react';
import type { LiveVideoStatus } from './customer-video-channel';
import { CustomerReceiptPanel } from './CustomerReceiptPanel';
import {
  INITIAL_CUSTOMER_MEDIA, customerMediaReducer, customerPlaybackError, releaseCustomerGuide,
  type CustomerMediaCommand, type ReceiptRequest,
} from './customer-media';
const MEDIA_STATUS = 'k99-customer-media-status';
export function CustomerMedia({ sourceId, command, children, onStatus, receiptRequest }: {
  sourceId: string; command?: CustomerMediaCommand; children: ReactNode;
  onStatus?: (status: LiveVideoStatus) => void;
  receiptRequest?: ReceiptRequest;
}) {
  const [state, dispatch] = useReducer(customerMediaReducer, INITIAL_CUSTOMER_MEDIA);
  const videoRef = useRef<HTMLVideoElement>(null);
  const promoRef = useRef<HTMLVideoElement>(null);
  const attemptRef = useRef(0);
  const diagnostics = useRef<unknown[]>([]);
  const [promoFailed, setPromoFailed] = useState(false);
  const [idleFiles, setIdleFiles] = useState<{name:string;url:string;kind?:'image';durationMs?:number}[]>([]);
  const [idleIndex, setIdleIndex] = useState(0);
  const [failedIdle, setFailedIdle] = useState<string[]>([]);
  const playableIdle = idleFiles.filter(file => !failedIdle.includes(file.url));
  const idleEntry=playableIdle[idleIndex % playableIdle.length];
  const idleSource = playableIdle.length ? playableIdle[idleIndex % playableIdle.length].url :
    new URL(`${import.meta.env.BASE_URL}videos/promo.mp4`, window.location.href).href;
  useEffect(() => {
    let live = true;
    let request = 0;
    const reload = async () => {
      const id = ++request;
      try {
        const reply = await window.k99Desktop?.idleVideos?.('list');
        if (!live || id !== request || !reply?.success) return;
        setIdleFiles(reply.files ?? []); setIdleIndex(0); setFailedIdle([]); setPromoFailed(false);
      } catch { /* Retain the packaged idle clip when the local folder is unavailable. */ }
    };
    void reload();
    const unsubscribe = window.k99Desktop?.onIdleVideosChanged?.(() => void reload());
    return () => { live = false; unsubscribe?.(); };
  }, []);
  const video = state.viewMode === 'GUIDE_VIDEO' ? state.activeGuideVideo : null;
  useEffect(()=>{
    if(state.viewMode!=='IDLE'||idleEntry?.kind!=='image')return;
    const timer=setTimeout(()=>setIdleIndex(index=>index+1),idleEntry.durationMs||10000);
    return()=>clearTimeout(timer);
  },[state.viewMode,idleEntry?.url,idleIndex]);
  const report = (event: string, player: HTMLVideoElement, error = '', reason?: unknown) => {
    const decode = player as HTMLVideoElement & { webkitAudioDecodedByteCount?: number };
    const diagnostic = {
      at: new Date().toISOString(), event, video, commandId: state.commandId,
      src: player.currentSrc || player.src, readyState: player.readyState, networkState: player.networkState,
      currentTime: player.currentTime, duration: Number.isFinite(player.duration) ? player.duration : null,
      paused: player.paused, muted: player.muted, volume: player.volume,
      decodedVideoFrames: player.getVideoPlaybackQuality?.().totalVideoFrames ?? null,
      decodedAudioBytes: decode.webkitAudioDecodedByteCount ?? null,
      mediaErrorCode: player.error?.code ?? null, mediaErrorMessage: player.error?.message ?? null,
      rejection: reason && typeof reason === 'object' && 'name' in reason ? String(reason.name) : null,
      pageOrigin: location.origin,
      mp4Support: player.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"'),
    };
    diagnostics.current = [...diagnostics.current, diagnostic].slice(-40);
    try { sessionStorage.setItem(`k99-customer-media-log:${sourceId}`, JSON.stringify(diagnostics.current)); } catch { /* Live log remains. */ }
    console.info('[K99 customer media]', diagnostic);
    onStatus?.({ error, diagnostic });
    try { if(!window.k99Desktop)window.opener?.postMessage({ type: MEDIA_STATUS, sourceId, error, diagnostic }, location.origin); }
    catch { /* A disconnected opener cannot prevent playback or the live channel report. */ }
  };
  const handleVideoFinish = (player: HTMLVideoElement | null) => {
    ++attemptRef.current;
    try {
      if (player) {
        report('ended', player);
        releaseCustomerGuide(player);
      }
    } finally {
      dispatch({ type: 'ended' });
    }
  };
  const showIdle = () => {
    ++attemptRef.current;
    if (videoRef.current) {
      report('ended', videoRef.current);
      releaseCustomerGuide(videoRef.current);
    }
    setPromoFailed(false);
    dispatch({ type: 'idle' });
  };
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !event.repeat) { event.preventDefault(); showIdle(); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  });
  useEffect(() => {
    if (command) {
      if (command.video === 'idle') setPromoFailed(false);
      dispatch({ type: 'manual', command });
    }
  }, [command?.id]);
  useEffect(() => {
    if (state.viewMode === 'IDLE' && promoRef.current && state.commandId)
      report('idle', promoRef.current);
  }, [state.viewMode, state.commandId]);
  // Only live staff input, never an initial/restored snapshot, exits idle.
  useEffect(() => {
    if (receiptRequest) dispatch({ type: 'intake-input' });
  }, [receiptRequest?.id]);
  useEffect(() => {
    if (!video) return;
    const player = videoRef.current;
    if (!player) return;
    // Guide clips always play once, even if a previous idle player looped.
    player.loop = false;
    player.removeAttribute('loop');
    const attempt = ++attemptRef.current;
    let live = true;
    let failed = false;
    let frame: number | undefined;
    let frameReported = false;
    let startTimer: ReturnType<typeof setTimeout> | undefined;
    const valid = () => live && attempt === attemptRef.current;
    const listen = (event: string) => {
      if (!valid()) return;
      report(event, player);
      if(event==='playing')clearTimeout(startTimer);
      if (event === 'playing' && !frameReported && 'requestVideoFrameCallback' in player) {
        frame = player.requestVideoFrameCallback(() => {
          if (valid()) { frameReported = true; report('first-frame', player); }
        });
      }
    };
    const fail = (event: string, reason?: unknown) => {
      if (!valid() || failed) return;
      failed = true;
      report(event, player, customerPlaybackError(reason, player.error?.code), reason);
      dispatch({ type: 'playback-failed' });
    };
    const handlers = ['loadedmetadata','canplay','playing','waiting','stalled'].map(event => {
      const handler = () => listen(event);
      player.addEventListener(event, handler);
      return { event, handler };
    });
    const onError = () => fail('media-error');
    player.addEventListener('error', onError);
    startTimer=setTimeout(()=>fail('play-start-timeout'),12000);
    report('play-request', player);
    // Same engine for every clip. Original audio stays enabled; failures never
    // become muted/simulated playback or a technical error wall for the customer.
    void player.play().then(() => { if (valid()) report('play-resolved', player); })
      .catch(reason => fail('play-rejected', reason));
    return () => {
      live = false;
      clearTimeout(startTimer);
      if (frame !== undefined) player.cancelVideoFrameCallback(frame);
      handlers.forEach(({ event, handler }) => player.removeEventListener(event, handler));
      player.removeEventListener('error', onError);
      releaseCustomerGuide(player);
    };
  }, [video, state.commandId, sourceId]);
  if (!video) {
    if (state.viewMode === 'IDLE') return <main className="customer-shell customer-video-screen customer-promo-screen" data-testid="customer-promo-screen">
      {idleEntry?.kind==='image'?<img key={idleSource} src={idleSource} alt={idleEntry.name}
        style={{width:'100%',height:'100%',objectFit:'contain'}} data-testid="customer-promo-image"
        onError={()=>{setFailedIdle(prior=>[...prior,idleSource]);setIdleIndex(0);}}/>:!promoFailed ? <video key={idleSource} ref={promoRef} className="customer-media-video"
        src={idleSource}
        autoPlay loop={playableIdle.length <= 1} muted playsInline controls={false} preload="auto"
        onEnded={() => setIdleIndex(index => index + 1)}
        onPlaying={event => report('playing', event.currentTarget)}
        data-testid="customer-promo-video" onError={() => {
          if (playableIdle.length) {
            setFailedIdle(prior => [...prior, idleSource]); setIdleIndex(0);
            return;
          }
          setPromoFailed(true);
          onStatus?.({ error: '대기 홍보 영상을 재생할 수 없습니다. 로컬 promo.mp4 파일을 확인해 주세요.',
            diagnostic: { event: 'promo-error', commandId: '', video: 'promo' } });
        }} /> : <p role="status">대기 홍보 영상 파일을 확인해 주세요.</p>}
    </main>;
    return <CustomerReceiptPanel onIdle={showIdle}>{children}</CustomerReceiptPanel>;
  }
  return <main className="customer-shell customer-video-screen" data-testid="customer-video-screen">
    <div className="customer-media-shell">
      <video key={`${video}:${state.commandId ?? 'auto'}`} ref={videoRef} className="customer-media-video"
        src={new URL(`${import.meta.env.BASE_URL}videos/${video}.mp4`,window.location.href).href}
        autoPlay playsInline loop={false} controls={false} preload="auto"
        onEnded={event => handleVideoFinish(event.currentTarget)}
        data-testid="customer-media-video" data-video={video} />
      <button type="button" onClick={() => handleVideoFinish(videoRef.current)}
        className="customer-media-close" aria-label="안내 영상 닫기" data-testid="button-customer-video-close">닫기</button>
    </div>
  </main>;
}
