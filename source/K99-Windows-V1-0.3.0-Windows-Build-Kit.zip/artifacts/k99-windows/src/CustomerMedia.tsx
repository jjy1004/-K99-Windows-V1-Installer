import { type ReactNode, useEffect, useReducer, useRef } from 'react';
import type { LiveVideoStatus } from './customer-video-channel';
import {
  INITIAL_CUSTOMER_MEDIA, customerMediaReducer, customerVideoPath, customerPlaybackError,
  type CustomerMediaCommand,
} from './customer-media';
const MEDIA_STATUS = 'k99-customer-media-status';
export function CustomerMedia({ sourceId, command, children, onStatus }: {
  sourceId: string; command?: CustomerMediaCommand; children: ReactNode;
  onStatus?: (status: LiveVideoStatus) => void;
}) {
  const [state, dispatch] = useReducer(customerMediaReducer, INITIAL_CUSTOMER_MEDIA);
  const videoRef = useRef<HTMLVideoElement>(null);
  const attemptRef = useRef(0);
  const diagnostics = useRef<unknown[]>([]);
  const video = ['value','process','water','sneakers'].includes(state.phase)
    ? state.phase as 'value' | 'process' | 'water' | 'sneakers' : null;
  const report = (event: string, player: HTMLVideoElement, error = '', reason?: unknown) => {
    const decode = player as HTMLVideoElement & { webkitAudioDecodedByteCount?: number };
    const diagnostic = {
      at: new Date().toISOString(), event, video, commandId: state.commandId,
      src: player.currentSrc || player.src, readyState: player.readyState, networkState: player.networkState,
      currentTime: player.currentTime, duration: Number.isFinite(player.duration) ? player.duration : null,
      paused: player.paused, muted: player.muted, volume: player.volume,
      decodedVideoFrames: player.getVideoPlaybackQuality?.().totalVideoFrames ?? null,
      decodedAudioBytes: decode.webkitAudioDecodedByteCount ?? null,
      mediaErrorCode: player.error?.code ?? null, mediaErrorMessage: player.error?.message ?? null,
      rejection: reason && typeof reason === 'object' && 'name' in reason ? String(reason.name) : null,
      pageOrigin: location.origin,
      mp4Support: player.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"'),
    };
    diagnostics.current = [...diagnostics.current, diagnostic].slice(-40);
    try { sessionStorage.setItem(`k99-customer-media-log:${sourceId}`, JSON.stringify(diagnostics.current)); } catch { /* Live log remains. */ }
    console.info('[K99 customer media]', diagnostic);
    onStatus?.({ error, diagnostic });
    try { window.opener?.postMessage({ type: MEDIA_STATUS, sourceId, error, diagnostic }, location.origin); }
    catch { /* A disconnected opener cannot prevent playback or the live channel report. */ }
  };
  useEffect(() => { if (command) dispatch({ type: 'manual', command }); }, [command?.id]);
  useEffect(() => {
    if (!video) return;
    const player = videoRef.current;
    if (!player) return;
    const attempt = ++attemptRef.current;
    let live = true;
    let failed = false;
    let frame: number | undefined;
    let frameReported = false;
    const valid = () => live && attempt === attemptRef.current;
    const listen = (event: string) => {
      if (!valid()) return;
      report(event, player);
      if (event === 'playing' && !frameReported && 'requestVideoFrameCallback' in player) {
        frame = player.requestVideoFrameCallback(() => {
          if (valid()) { frameReported = true; report('first-frame', player); }
        });
      }
    };
    const fail = (event: string, reason?: unknown) => {
      if (!valid() || failed) return;
      failed = true;
      report(event, player, customerPlaybackError(reason, player.error?.code), reason);
      dispatch({ type: 'playback-failed' });
    };
    const handlers = ['loadedmetadata','canplay','playing','waiting','stalled','ended'].map(event => {
      const handler = () => {
        listen(event);
        if (event === 'ended' && valid()) dispatch({ type: 'ended' });
      };
      player.addEventListener(event, handler);
      return { event, handler };
    });
    const onError = () => fail('media-error');
    player.addEventListener('error', onError);
    report('play-request', player);
    // Same engine for every clip. Original audio stays enabled; failures never
    // become muted/simulated playback or a technical error wall for the customer.
    void player.play().then(() => { if (valid()) report('play-resolved', player); })
      .catch(reason => fail('play-rejected', reason));
    return () => {
      live = false;
      if (frame !== undefined) player.cancelVideoFrameCallback(frame);
      handlers.forEach(({ event, handler }) => player.removeEventListener(event, handler));
      player.removeEventListener('error', onError);
      player.pause();
    };
  }, [video, state.commandId, sourceId]);
  if (!video) return <>{children}</>;
  return <main className="customer-shell customer-video-screen" data-testid="customer-video-screen">
    <div className="customer-media-shell">
      <video key={`${video}:${state.commandId ?? 'auto'}`} ref={videoRef} className="customer-media-video"
        src={customerVideoPath(video, import.meta.env.BASE_URL)} playsInline preload="auto"
        data-testid="customer-media-video" data-video={video} />
    </div>
  </main>;
}
