import { getCombinedBreakdown } from './combined-pricing';
import { NumUnit } from './NumUnit';

type CustomerRow = {
  id: number;
  itemId: string;
  displayNameKo: string;
  quantity: number;
  generalPrice: number;
  premiumPrice: number;
};

const formatWon = (value: number) => `${value.toLocaleString('ko-KR')}원`;

export function CombinedOrderDetails({ rows }: { rows: CustomerRow[] }) {
  const breakdown = getCombinedBreakdown(rows);
  return (
    <>
      <div className="customer-items combined-customer-items" data-testid="customer-combined-items">
        <h2 className="customer-group-title" data-testid="customer-garment-section">일반 세탁물</h2>
        <div className="customer-items-heading">
          <span>세탁물 품목</span><span>수량</span><span>일반 금액</span><span>프리미엄 추가금액</span>
        </div>
        {breakdown.garments.map((row) => (
          <div className="customer-item-row" key={row.id} data-testid={`customer-row-laundry-${row.id}`}>
            <span data-testid={`customer-text-item-${row.id}`}>{row.displayNameKo}</span>
            <span className="k99-num-unit" data-testid={`customer-text-quantity-${row.id}`}>{row.quantity}개</span>
            <span className="customer-item-price" data-testid={`customer-price-normal-${row.id}`}>
              <small className="customer-price-type">일반</small>{formatWon(row.generalPrice * row.quantity)}
              <small>단가 {formatWon(row.generalPrice)}</small>
            </span>
            <span className="customer-item-price" data-testid={`customer-price-premium-${row.id}`}>
              <small className="customer-price-type">프리미엄 추가금액</small>+{formatWon((row.premiumPrice - row.generalPrice) * row.quantity)}
              <small>1개당 +{formatWon(row.premiumPrice - row.generalPrice)}</small>
              <small data-testid={`customer-price-difference-${row.id}`}>
                일반 대비 +{formatWon((row.premiumPrice - row.generalPrice) * row.quantity)}
              </small>
            </span>
          </div>
        ))}
        <div className="combined-group-totals">
          <span>일반 세탁물 예상금액</span><strong data-testid="customer-garment-general">{formatWon(breakdown.garmentGeneral)}</strong>
          <span>프리미엄 추가금액 · 일반 세탁물</span><strong data-testid="customer-garment-premium">+{formatWon(breakdown.garmentPremium - breakdown.garmentGeneral)}</strong>
        </div>

        <h2 className="customer-group-title" data-testid="customer-sneaker-section">운동화</h2>
        <div className="customer-items-heading sneaker-only">
          <span>선택한 운동화 서비스</span><span>수량</span><span>선택 서비스 금액</span>
        </div>
        {breakdown.sneakers.map((row) => (
          <div className="customer-item-row sneaker-only" key={row.id} data-testid={`customer-row-laundry-${row.id}`}>
            <span data-testid={`customer-text-item-${row.id}`}>{row.displayNameKo} 세탁</span>
            <span data-testid={`customer-text-quantity-${row.id}`}>{row.quantity}켤레</span>
            <span className="customer-item-price" data-testid={`customer-price-selected-${row.id}`}>
              {formatWon(row.generalPrice * row.quantity)}
              <small>단가 {formatWon(row.generalPrice)} / 1켤레</small>
              <small>{row.itemId === 'sneakers_premium'
                ? `일반 운동화 대비 +${formatWon(9000 * row.quantity)} · 1켤레당 +9,000원 · 선택 금액에 포함`
                : `프리미엄 운동화로 변경 시 +${formatWon(9000 * row.quantity)} · 1켤레당 +9,000원 · 별도 선택`}</small>
            </span>
          </div>
        ))}
        <div className="combined-group-totals">
          <span>선택한 운동화 서비스 합계</span><strong data-testid="customer-sneaker-total">{formatWon(breakdown.sneakerTotal)}</strong>
        </div>
        <p className="customer-total-quantity">
          총 수량: <strong><NumUnit>{breakdown.garments.reduce((sum, row) => sum + row.quantity, 0)}개</NumUnit> · <NumUnit>{breakdown.sneakers.reduce((sum, row) => sum + row.quantity, 0)}켤레</NumUnit></strong>
        </p>
      </div>
      <div className="customer-prices" data-testid="customer-price-summary">
        <div className="price-panel">
          <span className="price-panel-label">합계 · 일반 세탁 예상금액</span>
          <strong className="price-panel-value" data-testid="customer-total-normal">{formatWon(breakdown.combinedGeneral)}</strong>
          <small className="combined-price-explain">일반 세탁물 + 선택 운동화 서비스</small>
        </div>
        <div className="price-panel premium">
          <span className="price-panel-label">프리미엄 추가금액 · 일반 세탁물</span>
          <strong className="price-panel-value" data-testid="customer-total-premium">+{formatWon(breakdown.combinedPremium - breakdown.combinedGeneral)}</strong>
          <small className="combined-price-explain">선택 운동화 서비스 금액은 그대로 유지됩니다</small>
        </div>
      </div>
    </>
  );
}