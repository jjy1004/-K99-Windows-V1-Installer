import {AlertTriangle,BadgeCheck,CalendarDays,CircleDollarSign,Clock,CreditCard,Gift,MapPin,MessageSquareText,Package,PackageCheck,Phone,Ruler,Scissors,Shirt,Sparkles,Star,Tag,Truck,Wrench} from 'lucide-react';
import type {LucideIcon} from 'lucide-react';
import type {NoticeContext,NoticeTemplate} from './notice-api';
import type {ConfirmedOrder} from './order-record';
import {isUnpaidCustomerJob,manualJobTags} from './customer-job-sort';
import {inspectionPaymentLabel} from './inspection-payment';
import {NoticeDeliveryBadge} from './NoticeDeliveryBadge';
import {deliveryTime,deliveryView,useNoticeDelivery} from './notice-delivery-state';
import {IntakeIdentity} from './IntakeIdentity';

const won=(n:number)=>`${n.toLocaleString('ko-KR')}원`;
function intakeDate(order:ConfirmedOrder|null){
  const t=Date.parse(order?.intakeAt??'');
  if(!Number.isFinite(t))return '-';
  const d=new Date(t);
  return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}
function paymentText(order:ConfirmedOrder|null,context:NoticeContext){
  if(order)return inspectionPaymentLabel(order);
  const v=context.paymentType;
  return v==='PREPAID'?'선불':v==='POSTPAID'?'후불':v==='COD'?'착불':v||'미지정';
}

export function CustomerNoticeOrderSummary({context,order,templateId}:{
  context:NoticeContext;order:ConfirmedOrder|null;templateId?:string;
}){
  const unpaid=order?isUnpaidCustomerJob(order):context.paymentType==='POSTPAID';
  const tags=order?manualJobTags(order):[];
  const count=context.items.reduce((s,i)=>s+i.quantity,0);
  const pay=paymentText(order,context);
  return <section className="cnd-summary" data-testid="notice-order-summary" data-unpaid={unpaid}>
    <header className="cnd-summary-head">
      <h3 data-testid="text-notice-customer"><IntakeIdentity order={{intakeAt:order?.intakeAt,customerName:context.customerName,customerPhone:context.customerPhone}}/> 고객 주문 상세</h3>
      {unpaid&&<strong className="cnd-unpaid" data-testid="notice-payment-unpaid"><AlertTriangle aria-hidden="true"/>후불(미결제)</strong>}
    </header>
    <NoticeDeliveryBadge orderId={context.orderId} templateIds={templateId?[templateId]:undefined}/>
    <dl className="cnd-facts">
      <div><dt><Phone aria-hidden="true"/>전화</dt><dd data-testid="text-notice-phone">{context.customerPhone||'-'}</dd></div>
      <div className="cnd-wide"><dt><MapPin aria-hidden="true"/>주소</dt><dd data-testid="text-notice-address">{context.customerAddress||'-'}</dd></div>
      <div><dt><CalendarDays aria-hidden="true"/>접수일</dt><dd data-testid="text-notice-intake">{intakeDate(order)}</dd></div>
      <div><dt><CreditCard aria-hidden="true"/>결제</dt><dd data-testid="text-notice-payment" className={unpaid?'cnd-pay-bad':''}>{pay}{pay==='후불'&&!unpaid?' (수금 완료)':''}</dd></div>
      {tags.length>0&&<div className="cnd-wide"><dt><Tag aria-hidden="true"/>수기 택</dt><dd data-testid="text-notice-tags">{tags.map(t=><span key={t} className="cnd-tag">{t}</span>)}</dd></div>}
    </dl>
    <table className="cnd-items">
      <thead><tr><th>품목</th><th>수량</th><th>금액</th></tr></thead>
      <tbody>{context.items.map((item,i)=><tr key={i} data-testid={`row-notice-item-${i}`}>
        <td>{item.name}</td><td>{item.quantity}벌</td><td>{won(item.amount)}</td></tr>)}
        {context.items.length===0&&<tr><td colSpan={3} className="cnd-empty">등록된 품목이 없습니다</td></tr>}
      </tbody>
    </table>
    <p className="cnd-total"><span>총 {count}벌 · 청구 금액</span><b data-testid="text-notice-total">{won(context.total)}</b></p>
  </section>;
}

const ICONS:[RegExp,LucideIcon][]=[
  [/미결제|후불|결제|입금|금액|요금|견적/,CircleDollarSign],[/수선|수리|단추|지퍼/,Scissors],[/기장|치수|길이/,Ruler],
  [/얼룩|오염|때|이염|복원/,Sparkles],[/손상|파손|주의|불가|하자|변색/,AlertTriangle],[/지연|늦|기간|시간|예정/,Clock],
  [/배송|배달|수거|방문/,Truck],[/찾아|완료|출고|보관|인수/,PackageCheck],[/접수|확인|검수/,BadgeCheck],
  [/리뷰|후기|감사/,Star],[/할인|이벤트|혜택|쿠폰/,Gift],[/가죽|특수|명품|세탁/,Shirt],[/택|번호/,Tag],
  [/포장|박스/,Package],[/공정|작업|처리/,Wrench],
];
const iconFor=(title:string)=>ICONS.find(([r])=>r.test(title))?.[1]??MessageSquareText;

export function CustomerNoticeTemplateChoices({title,templates,selectedId,busy,onSelect,orderId}:{
  title:string;templates:readonly NoticeTemplate[];selectedId:string;busy:boolean;
  onSelect:(template:NoticeTemplate)=>void;orderId?:string;
}){
  const delivery=useNoticeDelivery(orderId);
  return <section className="cnd-template-group"><h4>{title}</h4>
    {templates.length===0?<p className="cnd-empty">등록된 안내문이 없습니다</p>:
    <div className="cnd-template-grid">{templates.map(template=>{const Icon=iconFor(template.title);
      const state=deliveryView(delivery.records,[template.id]);return <button key={template.id} type="button"
      className="cnd-template-button" disabled={busy} aria-pressed={selectedId===template.id}
      data-message-state={state.kind} title={state.kind==='none'?template.title:`${state.kind==='sent'?'직원 발송 확인':'실제 전송 미확인'} · ${deliveryTime(state.at)}`}
      data-testid={`detail-template-${template.id}`} onClick={()=>onSelect(template)}>
      <span className="cnd-icon"><Icon aria-hidden="true"/></span><span className="cnd-label">{template.title}
        {state.kind!=='none'&&<small>{state.kind==='sent'?'✅ 발송됨':'준비됨'} {deliveryTime(state.at)}</small>}</span>
    </button>;})}</div>}
  </section>;
}
