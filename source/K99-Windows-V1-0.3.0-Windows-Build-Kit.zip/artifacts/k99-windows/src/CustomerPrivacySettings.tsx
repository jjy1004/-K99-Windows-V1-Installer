import { useEffect, useRef, useState, type FormEvent } from 'react';
import { directoryRequest } from './customer-directory-client';

export const PRIVACY_CHANGED = 'k99-customer-privacy-changed';
export const IMPORT_PRIVACY_NOTICE = '고객 정보 등록이 완료되었습니다. 매장 내 개인정보 유출 방지를 위해 PC에 남아 있는 원본 엑셀 파일은 반드시 삭제해 주세요.';
export function maskCustomerPhone(value: string, enabled: boolean) {
  if (!enabled || !value) return value;
  const digits = value.replace(/\D/g, '');
  return digits.length >= 8 ? `${digits.slice(0, 3)}-****-${digits.slice(-4)}` : '****';
}

/** Daily counter work remains open; this credential protects directory CSV export only. */
export function CustomerPrivacySettings() {
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [maskPhones, setMask] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [code, setCode] = useState('');
  const composing = useRef(false);
  const current = useRef<HTMLInputElement>(null);
  const next = useRef<HTMLInputElement>(null);
  const confirm = useRef<HTMLInputElement>(null);
  const load = () => {
    if (!window.k99Desktop) { setError('비밀번호와 개인정보 설정은 매장 Windows 앱에서 저장합니다.'); return; }
    Promise.all([
      directoryRequest<{ configured: boolean }>('GET', '/api/admin/password/status'),
      directoryRequest<{ maskPhones: boolean }>('GET', '/api/admin/privacy'),
    ]).then(([a, p]) => { setConfigured(a.configured); setMask(p.maskPhones); setError(''); })
      .catch(e => setError(e instanceof Error ? e.message : '설정을 읽지 못했습니다.'));
  };
  useEffect(load, []);
  async function act(action: 'save' | 'test' | 'recovery', event?: FormEvent) {
    event?.preventDefault();
    if (busy || composing.current || configured === null) return;
    setBusy(true); setError(''); setStatus(''); setCode('');
    try {
      const password = current.current?.value ?? '';
      if (action === 'save') {
        const newPassword = next.current?.value ?? '';
        if (newPassword.normalize('NFC').trim() !== (confirm.current?.value ?? '').normalize('NFC').trim())
          throw new Error('새 비밀번호와 확인 입력이 다릅니다.');
        const result = await directoryRequest<{ configured: boolean }>('POST',
          configured ? '/api/admin/password/change' : '/api/desktop/admin/setup',
          configured ? { currentPassword: password, newPassword } : { password: newPassword });
        setConfigured(result.configured);
        setStatus('저장 후 비밀번호 일치 검사까지 완료했습니다. 이 PC의 SQLite에 보관됩니다.');
        for (const ref of [current, next, confirm]) if (ref.current) ref.current.value = '';
      } else if (action === 'test') {
        await directoryRequest('POST', '/api/admin/password/check', { password });
        setStatus('현재 이 PC에 저장된 비밀번호와 일치합니다.');
      } else {
        const r = await directoryRequest<{ recoveryCode: string }>('POST', '/api/admin/password/recovery-code', { password });
        setCode(r.recoveryCode); setStatus('복구 코드를 새로 발급했습니다. 이전 복구 코드는 사용할 수 없습니다.');
      }
    } catch (e) { setError(e instanceof Error ? e.message : '저장 또는 확인에 실패했습니다.'); }
    finally { setBusy(false); }
  }
  async function toggle(mask: boolean) {
    if (busy) return;
    setBusy(true); setError('');
    try {
      const result = await directoryRequest<{ maskPhones: boolean }>('PUT', '/api/admin/privacy', { maskPhones: mask });
      setMask(result.maskPhones); window.dispatchEvent(new Event(PRIVACY_CHANGED));
      setStatus('고객 명부의 전화번호 표시 설정을 저장했습니다.');
    } catch (e) { setError(e instanceof Error ? e.message : '설정 저장에 실패했습니다.'); }
    finally { setBusy(false); }
  }
  return <section className="nc-section" aria-label="고객 명부 보안" data-testid="customer-privacy-settings">
    <h3>고객 명부 보안 · 관리자 비밀번호</h3>
    <p>접수·검색·단가 수정·엑셀 가져오기는 비밀번호 없이 사용합니다. 고객 명부 엑셀(CSV) 저장 시에만 비밀번호를 확인합니다.</p>
    <p>상태: {configured === null ? '확인 필요' : configured ? '이 PC에 비밀번호 설정됨' : '미설정 · 내보내기 전에 설정해 주세요'}</p>
    <form onSubmit={e => void act('save', e)} onCompositionStart={() => { composing.current = true; }}
      onCompositionEnd={() => { composing.current = false; }}>
      {configured && <label className="nc-label">현재 비밀번호 · 확인/변경용
        <input ref={current} className="nc-input" type="password" autoComplete="current-password" maxLength={1024}
          data-testid="security-current-password" /></label>}
      <label className="nc-label">{configured ? '새 비밀번호' : '비밀번호 설정'} (8자 이상, 앞뒤 공백 제외)
        <input ref={next} className="nc-input" type="password" autoComplete="new-password" maxLength={1024}
          data-testid="security-new-password" /></label>
      <label className="nc-label">새 비밀번호 다시 입력
        <input ref={confirm} className="nc-input" type="password" autoComplete="new-password" maxLength={1024}
          data-testid="security-confirm-password" /></label>
      <div className="nc-row">
        <button className="nc-close" type="submit" disabled={busy || configured === null}>비밀번호 저장</button>
        {configured && <><button className="nc-close" type="button" disabled={busy} onClick={() => void act('test')}>저장된 비밀번호 확인</button>
          <button className="nc-close" type="button" disabled={busy} onClick={() => void act('recovery')}>복구 코드 발급</button></>}
      </div>
    </form>
    {code && <p role="status" style={{ overflowWrap: 'anywhere' }}>복구 코드 (화면을 닫기 전에 별도 안전한 곳에 적어 두세요): <strong>{code}</strong></p>}
    <label className="nc-label"><input type="checkbox" checked={maskPhones} disabled={busy || configured === null}
      onChange={e => void toggle(e.target.checked)} data-testid="security-mask-phones" /> 고객 명부 전화번호 가운데 자리 가리기 (010-****-1234)</label>
    <p className="nc-hint">표시 가리기는 DB 암호화가 아닙니다. DB·백업·내보낸 엑셀은 Windows 계정 잠금과 드라이브 암호화로 보호하세요. 원본 전화번호는 검색·발송을 위해 보존합니다.</p>
    {status && <p role="status">{status}</p>}
    {error && <p role="alert" className="eq-error">{error} <button type="button" onClick={load}>다시 불러오기</button></p>}
  </section>;
}
