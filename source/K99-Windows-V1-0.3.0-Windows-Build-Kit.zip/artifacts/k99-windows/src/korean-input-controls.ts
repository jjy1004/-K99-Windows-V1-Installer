import { composeKoreanEdit } from './korean-input-conversion';

export const KOREAN_MODE_EVENT = 'k99-korean-mode';
export const koreanEnabled = (field: HTMLElement | null) => field?.dataset.koreanMode !== 'english';

/** Floating control avoids wrapping/reparenting React inputs (and losing focus).
 * It belongs to the currently focused editable only, including modal/portal UIs. */
export function installKoreanControls(doc: Document, eligible: (field: HTMLElement) => boolean,
  onMode: (field: HTMLElement) => void) {
  const win = doc.defaultView;
  if (!win || !doc.body) return () => {};
  let current: HTMLElement | null = null, composing = false;
  let editableText = new WeakMap<Node, string>();
  let timer: ReturnType<typeof setTimeout> | undefined, commit: (() => void) | undefined;
  const button = doc.createElement('button');
  button.type = 'button'; button.hidden = true;
  button.setAttribute('aria-label', '한글 우선 입력 전환');
  Object.assign(button.style, { position: 'fixed', zIndex: '2147483000', minWidth: '58px',
    height: '30px', fontSize: '15px', fontWeight: '800', border: '2px solid #fff',
    borderRadius: '8px', padding: '2px 8px', color: '#fff', cursor: 'pointer',
    boxShadow: '0 1px 6px #0009' });
  doc.body.append(button);
  const native = (korean = koreanEnabled(current)) => {
    const bridge = (win as unknown as { k99Desktop?: {forceKorean?:(arg:{korean:boolean})=>Promise<unknown>} }).k99Desktop;
    try { void bridge?.forceKorean?.({ korean }).catch(() => {}); }
    catch { /* OS helper unavailable: the local composer remains active. */ }
  };
  const position = () => {
    if (!current?.isConnected) { button.hidden = true; return; }
    const rect = current.getBoundingClientRect();
    button.hidden = rect.width === 0 || rect.height === 0 || rect.bottom < 0 || rect.top > win.innerHeight;
    button.style.left = `${Math.max(0, Math.min(win.innerWidth - 62, rect.right - 60))}px`;
    button.style.top = `${Math.max(0, rect.top >= 30 ? rect.top - 29 : rect.bottom)}px`;
  };
  const paint = () => {
    button.textContent = koreanEnabled(current) ? '한 / 영' : '영 / 한';
    button.style.background = koreanEnabled(current) ? '#145b43' : '#274f91';
    button.setAttribute('aria-pressed', String(koreanEnabled(current)));
    button.title = koreanEnabled(current) ? '한글 우선 켜짐 · 누르면 영문 입력' : '영문 입력 · 누르면 한글 우선';
  };
  const field = (target: EventTarget | null): HTMLElement | null => {
    if (!(target instanceof win.HTMLElement)) return null;
    return target.closest<HTMLElement>('input,textarea,[contenteditable="true"],[contenteditable=""],[contenteditable="plaintext-only"]');
  };
  const clear = () => { clearTimeout(timer); timer = undefined; commit = undefined; };
  const focus = (event: FocusEvent) => {
    const target = field(event.target);
    if (!target || !eligible(target)) {
      current = null; button.hidden = true;
      if (target && !target.hasAttribute('readonly') && !target.hasAttribute('disabled')) native(false);
      return;
    }
    current = target; editableText = new WeakMap(); paint(); position(); native();
  };
  const blur = (event: FocusEvent) => {
    if (field(event.target) !== current) return;
    if (event.relatedTarget === button) return;
    if (!composing) commit?.();
    clear(); current = null; composing = false; button.hidden = true;
  };
  const change = () => {
    if (!current) return;
    clear(); editableText = new WeakMap();
    current.dataset.koreanMode = koreanEnabled(current) ? 'english' : 'korean';
    onMode(current); current.dispatchEvent(new win.Event(KOREAN_MODE_EVENT));
    paint(); current.focus({ preventScroll: true }); native();
  };
  const preventBlur = (event: Event) => event.preventDefault();
  button.addEventListener('pointerdown', preventBlur);
  button.addEventListener('click', change);
  const start = () => { composing = true; editableText = new WeakMap(); clear(); };
  const end = () => { composing = false; editableText = new WeakMap(); clear(); };
  // Rich editables: replace only the focused text node, never their HTML or
  // sibling nodes. Native IME, paste, markup and the live caret remain intact.
  const input = (event: Event) => {
    const nativeEvent = event as InputEvent, target = field(event.target);
    if (target?.isContentEditable && nativeEvent.inputType !== 'insertText') editableText = new WeakMap();
    if (!target?.isContentEditable || !eligible(target) || !koreanEnabled(target) ||
      composing || nativeEvent.isComposing || nativeEvent.inputType !== 'insertText' ||
      !/^[a-z]+$/i.test(nativeEvent.data || '')) return;
    clear();
    const selection = win.getSelection(), node = selection?.anchorNode, offset = selection?.anchorOffset ?? 0;
    if (!node || node.nodeType !== 3 || !target.contains(node)) return;
    const original = node.textContent || '', size = nativeEvent.data!.length;
    const insertion = offset - size;
    if (insertion < 0) return;
    // Do not reset the baseline on each pending ASCII key: a fast run may
    // reach us entirely before the deferred 30ms conversion has committed.
    const baseline = editableText.get(node) ?? original.slice(0, insertion) + original.slice(offset);
    editableText.set(node, baseline);
    const converted = composeKoreanEdit(baseline, original);
    commit = () => {
      if (!node.isConnected || node.textContent !== original || composing || !koreanEnabled(target)) return;
      node.textContent = converted; editableText.set(node, converted);
      const range = doc.createRange(); range.setStart(node, Math.max(0, Math.min(converted.length, offset + converted.length - original.length))); range.collapse(true);
      selection?.removeAllRanges(); selection?.addRange(range);
      target.dispatchEvent(new win.InputEvent('input', { bubbles: true, inputType: 'insertReplacementText' }));
      commit = undefined;
    };
    timer = setTimeout(() => commit?.(), 30);
  };
  const refocus = () => { if (current) { position(); native(); } };
  doc.addEventListener('focusin', focus, true); doc.addEventListener('focusout', blur, true);
  doc.addEventListener('input', input, true);
  doc.addEventListener('compositionstart', start, true); doc.addEventListener('compositionend', end, true);
  win.addEventListener('focus', refocus); win.addEventListener('resize', position); doc.addEventListener('scroll', position, true);
  return () => {
    clear(); button.remove();
    doc.removeEventListener('focusin', focus, true); doc.removeEventListener('focusout', blur, true);
    doc.removeEventListener('input', input, true);
    doc.removeEventListener('compositionstart', start, true); doc.removeEventListener('compositionend', end, true);
    win.removeEventListener('focus', refocus); win.removeEventListener('resize', position); doc.removeEventListener('scroll', position, true);
  };
}
