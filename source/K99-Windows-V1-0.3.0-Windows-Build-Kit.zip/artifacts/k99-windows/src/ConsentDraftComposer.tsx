import { useMemo, useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import { inspectionFindings, inspectionMethodChanged, updateInspectionMessage } from './inspection-record';
import { consentDraft, type DraftKind } from './workflow-gates';

const KIND_LABEL: Record<DraftKind, string> = {
  fee: '추가 요금만', method: '세탁 방법 변경', risk: '위험·면책 동의', combined: '복합 (요금·방법·위험)', hold: '작업 거절·보류 안내',
};

export function suggestedDraftKind(order: ConfirmedOrder): DraftKind {
  const ins = order.inspection;
  if (!ins) return 'hold';
  const fee = (ins.priceDifference ?? 0) > 0;
  const method = inspectionMethodChanged(order, ins);
  const risk = ins.riskRequired || !!ins.waiverRequired || ins.items.some((i) => i.riskFactors?.length);
  const n = [fee, method, risk].filter(Boolean).length;
  if (n > 1) return 'combined';
  return fee ? 'fee' : method ? 'method' : risk ? 'risk' : 'hold';
}

/** Staff-editable consent draft built from the saved inspection evidence. Saving or
 * copying is never a send record and never permits the changed work. */
export function ConsentDraftComposer({ order, onSave }: { order: ConfirmedOrder; onSave: (o: ConfirmedOrder) => void }) {
  const ins = order.inspection!;
  const [kind, setKind] = useState<DraftKind>(() => suggestedDraftKind(order));
  const affected = useMemo(() => {
    const scope = ins.affectedGarmentIds;
    const garments = (order.garments ?? []).filter((g) => !scope?.length || scope.includes(g.garmentId));
    return garments.length ? garments.map((g) => `${g.itemName} ${g.sequence}번`).join(', ')
      : order.items.map((i) => `${i.displayNameKo} ${i.quantity}점`).join(', ');
  }, [order, ins.affectedGarmentIds]);
  const build = (k: DraftKind) => {
    const findings = inspectionFindings(order, ins).map((f) => `${f.itemName} ${f.category} ${f.result}${f.memo ? `(${f.memo})` : ''}`);
    const risks = [ins.riskNotice, ins.waiverRequired ? `면책 범위: ${ins.waiverNotice}` : '',
      ...ins.items.flatMap((i) => i.riskFactors ?? [])].filter(Boolean);
    const methods = ins.items.filter((i) => i.actualCleaningMethod && i.plannedCleaningMethod && i.actualCleaningMethod !== i.plannedCleaningMethod)
      .map((i) => `${order.items[i.index]?.displayNameKo} ${i.plannedCleaningMethod} → ${i.actualCleaningMethod}${i.methodChangeReason ? ` (${i.methodChangeReason})` : ''}`);
    return consentDraft(k, {
      store: 'K99 품격세탁소 과천점', customer: order.customerName, garment: affected,
      findings: [...findings, ...risks].join(' / ') || '검수 기록 확인 필요',
      before: ins.originalPrice, add: Math.max(0, ins.revisedPrice - ins.originalPrice),
      method: methods.join(', ') || undefined,
    });
  };
  const [text, setText] = useState(() => build(kind));
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  if (ins.itemNotice || ins.stagedApproval) return null;
  return <div className="consent-composer" data-testid="consent-draft-composer">
    <div className="consent-composer__head">
      <strong>동의 요청 문안 초안</strong>
      <select lang="ko" value={kind} onChange={(e) => { const k = e.target.value as DraftKind; setKind(k); setText(build(k)); setNote(''); }}
        data-testid="select-consent-draft-kind">
        {(Object.keys(KIND_LABEL) as DraftKind[]).map((k) => <option key={k} value={k}>{KIND_LABEL[k]}</option>)}
      </select>
    </div>
    <p className="consent-composer__facts">대상 {affected} · 기존 {ins.originalPrice.toLocaleString('ko-KR')}원 · 추가 {Math.max(0, ins.revisedPrice - ins.originalPrice).toLocaleString('ko-KR')}원 · 변경 후 {ins.revisedPrice.toLocaleString('ko-KR')}원</p>
    <textarea lang="ko" rows={7} value={text} onChange={(e) => { setText(e.target.value); setNote(''); }} data-testid="textarea-consent-draft" />
    <div className="consent-composer__actions">
      <button type="button" onClick={() => {
        try { onSave(updateInspectionMessage(order, text, 'edit', new Date(), 'short')); setError(''); setNote('직원 검토 문안으로 저장했습니다. 아직 발송 기록이 아닙니다.'); }
        catch (c) { setError(c instanceof Error ? c.message : '문안을 저장하지 못했습니다.'); }
      }} data-testid="button-save-consent-draft">검토 완료 · 문안 저장</button>
      <button type="button" onClick={() => {
        void navigator.clipboard?.writeText(text).then(() => setNote('복사했습니다. 카카오톡 등에서 직접 발송한 뒤 고객 회신을 아래에 기록해 주세요.'),
          () => setError('복사하지 못했습니다. 문안을 직접 선택해 복사해 주세요.'));
      }} data-testid="button-copy-consent-draft">문안 복사</button>
    </div>
    {note && <p role="status">{note}</p>}
    {error && <p role="alert" className="professional-inspection__warning">{error}</p>}
    <p className="consent-composer__rule">문안 저장·복사는 발송이나 동의가 아닙니다. 고객이 매장에서 직접 동의한 경우에도 아래 회신 항목에 실제 내용과 확인 직원을 기록해야 변경 작업을 진행할 수 있습니다. 동의 · 거절 · 문의 있음 · 연락 안 됨을 구분해 기록합니다.</p>
  </div>;
}
