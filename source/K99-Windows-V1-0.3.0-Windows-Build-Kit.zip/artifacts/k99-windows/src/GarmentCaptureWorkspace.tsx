import { useCallback, useEffect, useRef, useState } from 'react';
import GarmentCaptureView from './GarmentCaptureView';
import { verifiedHistory, tagJobStatusMessage } from './tag-action-policy';
import { photoEligibility, tagIssuance } from './workflow-gates';
import { GarmentTagPreview } from './GarmentTagPreview';
import { renderTagForWindows } from './tag-print-image';
import { GarmentAutomation, type CaptureProvider } from './garment-automation';
import { createTagData, type GarmentRecord } from './garment-record';
import {
  LocalBridgeClient, DEFAULT_LOCAL_BRIDGE_BASE_URL, captureGarmentPhoto,
  createLocalBridgeTagPrinterAdapter, getHardwareStatus,
} from './local-bridge';
import { updateSavedOrder, type ConfirmedOrder } from './order-record';
import { usePhotoBridgeSelection } from './use-photo-bridge-selection';
import { batchTagComplete, batchTagSubmission, nextBatchPhotoIndex, staffCheckBatchTag } from './capture-batch-policy';
import { readBatchArm } from './capture-batch-arm';
import { listRecentPhotos, loadPhotoPreview } from './photo-source';
import {
  armPhoto, checkPassivePhotoBridge, confirmPhotoBridgeIntakePhoto, getPhotoSettings,
  getPhotoBridgeTagJob, getPhotoBridgeTagTemplate, requestPhotoBridgeTagJob,
  readPhotoBridgeSession, registerPhotoOrder,
  type PhotoBridgeTagMode, type PhotoBridgeTagTemplate,
} from './passive-photo-client';
import tagTemplateFile from '../windows-photo-helper/tag-template.json';
import {
  applyPhotoBridgeTagJobSnapshot, currentIntakePhotoProof, photoBridgeTagAutoRequest,
  photoBridgeTagJobSnapshotMatches,
  reserveFirstPhotoBridgeAutoTag, resolvePhotoBridgeTagElements,
} from './photo-tag-jobs';
import { readPhotoBridgeConnectionSession, PHOTO_BRIDGE_SESSION_EVENT } from './photo-bridge-session';
import {
  createTagPrinterSettings, SimulationTagPrinterAdapter,
  type TagPrinterAdapter, type TagPrinterSettings,
} from './tag-printer';

const SETTINGS_KEY = 'k99-garment-device-settings-v1';
const SWITCH_KEY = 'k99-foot-switch-code-v1';
const BRIDGE_KEY = 'k99-local-bridge-url-v1';
const PASSIVE_PENDING_KEY = 'k99-passive-photo-pending-v1';
const simulationPrinter = new SimulationTagPrinterAdapter();
const sampleTagTemplate = tagTemplateFile as PhotoBridgeTagTemplate;

type PassivePhotoRequest = { requestId: string; orderId: string; garmentId: string };
type VerifiedPassivePhoto = PassivePhotoRequest & {
  photoPath: string; photoTimestamp: string; archivePath?: string; archiveError?: string;
};

function readPendingPhotoRequest(orderId: string): PassivePhotoRequest | null {
  try {
    const raw = window.sessionStorage.getItem(`${PASSIVE_PENDING_KEY}:${encodeURIComponent(orderId)}`);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<PassivePhotoRequest>;
    if (value.orderId !== orderId || typeof value.requestId !== 'string' || !value.requestId.trim() ||
        typeof value.garmentId !== 'string' || !value.garmentId.trim()) return null;
    return { requestId: value.requestId, orderId, garmentId: value.garmentId };
  } catch {
    return null;
  }
}

function storePendingPhotoRequest(request: PassivePhotoRequest): void {
  try {
    window.sessionStorage.setItem(`${PASSIVE_PENDING_KEY}:${encodeURIComponent(request.orderId)}`, JSON.stringify(request));
  } catch {
    throw new Error('대기 중인 ARM 요청을 이 탭에 보존할 수 없어 촬영을 시작하지 않았습니다.');
  }
}

function removePendingPhotoRequest(orderId: string): void {
  window.sessionStorage.removeItem(`${PASSIVE_PENDING_KEY}:${encodeURIComponent(orderId)}`);
}

function readSettings(): TagPrinterSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    return createTagPrinterSettings(raw ? JSON.parse(raw) as Partial<TagPrinterSettings> : {});
  } catch {
    return createTagPrinterSettings();
  }
}

function isOnline(value: Record<string, unknown>): boolean {
  return value.online !== false && value.ok !== false && value.status !== 'offline' && value.status !== 'error';
}

function deviceLabel(value: unknown): string {
  if (value === true || value === 'connected' || value === 'online' || value === 'ready') return '연결됨';
  if (value === false || value === 'disconnected' || value === 'offline' || value === 'error') return '연결 안 됨';
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    if (typeof obj.connected === 'boolean') return obj.connected ? '연결됨' : '연결 안 됨';
    if (typeof obj.online === 'boolean') return obj.online ? '연결됨' : '연결 안 됨';
    if (typeof obj.status === 'string') return deviceLabel(obj.status);
  }
  return '상태 미확인';
}

export function GarmentCaptureWorkspace({ order, initialGarmentId, onOrderChange, onBack }: {
  order: ConfirmedOrder;
  initialGarmentId?: string;
  onOrderChange: (order: ConfirmedOrder) => void;
  onBack: () => void;
}) {
  const initialPassiveRequest = readPendingPhotoRequest(order.id);
  const orderRef = useRef(order);
  const [garments, setGarments] = useState<GarmentRecord[]>(order.garments ?? []);
  const [currentIndex, setCurrentIndex] = useState(() =>
    initialPassiveRequest
      ? Math.max(0, (order.garments ?? []).findIndex((item) => item.garmentId === initialPassiveRequest.garmentId))
      : initialGarmentId
      ? Math.max(0, (order.garments ?? []).findIndex((item) => item.garmentId === initialGarmentId))
      : Math.max(0, (order.garments ?? []).findIndex((item) => item.photoStatus === 'not-captured' && !item.lastError)));
  const currentIndexRef = useRef(currentIndex);
  const continuePassiveSequenceRef = useRef(false);
  currentIndexRef.current = currentIndex;
  usePhotoBridgeSelection(order.id, garments[currentIndex]?.garmentId);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [mode, setMode] = useState<'simulation' | 'bridge' | 'passive'>(() =>
    readPhotoBridgeSession() || initialPassiveRequest ? 'passive' : 'simulation');
  const modeRef = useRef(mode);
  modeRef.current = mode;
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});
  const previewGarment = garments[currentIndex];
  useEffect(() => {
    if (modeRef.current !== 'passive' || !previewGarment ||
        previewGarment.photoStatus !== 'saved' || !previewGarment.photoPath ||
        previewUrls[previewGarment.garmentId]) return;
    let live = true;
    void (async () => {
      try {
        const photos = await listRecentPhotos();
        const source = photos.find((item) => item.origin === 'bridge' &&
          item.sourcePath === previewGarment.photoPath &&
          item.timestamp === previewGarment.photoTimestamp);
        if (!source) throw new Error('저장된 의류 사진의 원본 미리보기를 찾지 못했습니다.');
        const preview = await loadPhotoPreview(source.id, 'bridge');
        if (live) setPreviewUrls((old) => ({ ...old, [previewGarment.garmentId]: preview }));
      } catch (cause) {
        if (live) setError(cause instanceof Error ? cause.message : '사진 미리보기를 읽지 못했습니다.');
      }
    })();
    return () => { live = false; };
  }, [previewGarment?.garmentId, previewGarment?.photoPath, previewGarment?.photoTimestamp,
    previewGarment?.photoStatus, previewUrls, mode]);
  const [showTag, setShowTag] = useState(false);
  const [passiveRequest, setPassiveRequest] = useState<PassivePhotoRequest | null>(initialPassiveRequest);
  const operationModeRef = useRef<'simulation' | 'bridge' | 'passive' | null>(null);
  const [hardware, setHardware] = useState({ camera: '상태 미확인', footSwitch: '상태 미확인', printer: '연결 안 됨' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [passiveStatus, setPassiveStatus] = useState(initialPassiveRequest ? '저장된 ARM 요청 복구 중' : '대기 중');
  const [passiveReady, setPassiveReady] = useState(false);
  const [passivePollEnabled, setPassivePollEnabled] = useState(Boolean(initialPassiveRequest));
  const [verifiedPassivePhoto, setVerifiedPassivePhoto] = useState<VerifiedPassivePhoto | null>(null);
  const [bridgeSessionRevision, setBridgeSessionRevision] = useState(0);
  const [tagTemplate, setTagTemplate] = useState<PhotoBridgeTagTemplate>(sampleTagTemplate);
  const [tagTemplateSource, setTagTemplateSource] = useState<'sample' | 'live' | 'unavailable'>('sample');
  const [tagTemplateError, setTagTemplateError] = useState('');
  const [photoBridgeJobNotice, setPhotoBridgeJobNotice] = useState('');
  const [tagStatusChecking, setTagStatusChecking] = useState(false);
  const photoBridgeJobInProgressRef = useRef(new Set<string>());
  const [settings, setSettings] = useState(readSettings);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const [footSwitchCode, setFootSwitchCode] = useState(() => window.localStorage.getItem(SWITCH_KEY) ?? '');
  const [bridgeUrl, setBridgeUrl] = useState(() => window.localStorage.getItem(BRIDGE_KEY) ?? DEFAULT_LOCAL_BRIDGE_BASE_URL);
  const bridgeUrlRef = useRef(bridgeUrl);
  bridgeUrlRef.current = bridgeUrl;
  const passiveActiveRef = useRef(mode === 'passive');
  passiveActiveRef.current = mode === 'passive';
  const passiveRequestRef = useRef(passiveRequest);
  passiveRequestRef.current = passiveRequest;
  const verifiedPassivePhotoRef = useRef(verifiedPassivePhoto);
  verifiedPassivePhotoRef.current = verifiedPassivePhoto;
  const registeredPhotoOrdersRef = useRef(new Set<string>());
  const bridgeSession = readPhotoBridgeConnectionSession();
  const photoBridgeTagMode: PhotoBridgeTagMode | null = bridgeSession &&
    ((mode === 'passive' && bridgeSession.mode === 'STORE') ||
      (mode === 'simulation' && (bridgeSession.mode === 'DEV' || bridgeSession.mode === 'TEST')))
    ? bridgeSession.mode : null;

  useEffect(() => {
    const changed = () => setBridgeSessionRevision((revision) => revision + 1);
    window.addEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
    return () => window.removeEventListener(PHOTO_BRIDGE_SESSION_EVENT, changed);
  }, []);

  useEffect(() => {
    let live = true;
    if (!photoBridgeTagMode) {
      setTagTemplate(sampleTagTemplate);
      setTagTemplateSource('sample');
      setTagTemplateError('');
      return () => { live = false; };
    }
    setTagTemplateSource('unavailable');
    setTagTemplateError('운영 Photo Bridge에서 외부 태그 서식을 확인하는 중입니다.');
    void getPhotoBridgeTagTemplate().then((result) => {
      if (!live || result.mode !== photoBridgeTagMode || result.hardwareVerified) return;
      setTagTemplate(result.template);
      setTagTemplateSource('live');
      setTagTemplateError('');
    }).catch((cause) => {
      if (!live) return;
      setTagTemplateSource('unavailable');
      setTagTemplateError(cause instanceof Error
        ? cause.message : '외부 태그 템플릿을 확인하지 못했습니다.');
    });
    return () => { live = false; };
  }, [photoBridgeTagMode, bridgeSessionRevision]);

  const persist = useCallback((updated: GarmentRecord[], previous: GarmentRecord[]) => {
    const current = orderRef.current;
    if (JSON.stringify(current.garments) !== JSON.stringify(previous))
      throw new Error('다른 화면에서 의류 기록이 변경되었습니다. 주문을 다시 열어 확인해 주세요.');
    const revised = { ...current, garments: updated };
    updateSavedOrder(revised, current);
    orderRef.current = revised;
    setGarments(updated);
    onOrderChange(revised);
  }, [onOrderChange]);

  const savePhotoBridgeJobGarment = useCallback(
    (garmentId: string, transform: (garment: GarmentRecord) => GarmentRecord): GarmentRecord => {
      const previous = orderRef.current.garments ?? [];
      const target = previous.find((garment) => garment.garmentId === garmentId);
      if (!target) throw new Error('저장 주문에서 태그 작업 대상 의류를 찾을 수 없습니다.');
      const changed = transform(target);
      if (JSON.stringify(changed) === JSON.stringify(target)) return target;
      const updated = previous.map((garment) => garment.garmentId === garmentId ? changed : garment);
      persist(updated, previous);
      return changed;
    },
    [persist],
  );

  const confirmPersistedPhotoWithBridge = async (garment: GarmentRecord): Promise<void> => {
    const session = readPhotoBridgeConnectionSession();
    const proof = currentIntakePhotoProof(garment);
    if (!session || !proof) {
      throw new Error('연결된 Photo Bridge 세션과 저장 주문의 현재 접수 사진 증거가 필요합니다.');
    }
    const expectedPhotoVerified = session.mode === 'STORE';
    if (garment.photoBridgePhotoConfirmations?.some((confirmation) =>
      confirmation.photoRequestId === proof.requestId && confirmation.mode === session.mode &&
      confirmation.photoVerified === expectedPhotoVerified)) return;
    const result = await confirmPhotoBridgeIntakePhoto({
      orderId: garment.orderId,
      garmentId: garment.garmentId,
      photoRequestId: proof.requestId,
      photoPath: proof.photoPath,
      photoTimestamp: proof.timestamp,
      photoStatus: proof.status,
      staffConfirmed: true,
    });
    if (result.orderId !== garment.orderId || result.garmentId !== garment.garmentId ||
        result.photoRequestId !== proof.requestId || result.mode !== session.mode ||
        result.photoVerified !== expectedPhotoVerified) {
      throw new Error('Photo Bridge 사진 확인 결과가 저장된 주문·의류·사진·모드와 일치하지 않습니다.');
    }
    savePhotoBridgeJobGarment(garment.garmentId, (record) => {
      if (record.captureRequestId !== proof.requestId || !currentIntakePhotoProof(record)) {
        throw new Error('Photo Bridge가 확인한 사진이 저장 주문의 현재 접수 사진과 달라 확인 기록을 보존하지 않았습니다.');
      }
      const confirmations = record.photoBridgePhotoConfirmations ?? [];
      if (confirmations.some((confirmation) =>
        confirmation.photoRequestId === proof.requestId && confirmation.mode === session.mode &&
        confirmation.photoVerified === expectedPhotoVerified)) return record;
      return {
        ...record,
        photoBridgePhotoConfirmations: [
          ...confirmations,
          {
            photoRequestId: proof.requestId,
            mode: session.mode,
            photoVerified: expectedPhotoVerified,
          },
        ],
      };
    });
  };

  const appendPhotoBridgeTagAudit = (
    garment: GarmentRecord, requestId: string, status: string, detail: string, at: string,
  ): GarmentRecord => ({
    ...garment,
    auditEvents: [...garment.auditEvents, {
      at, type: 'print-requested', status, details: `${detail} (요청 ${requestId})`.slice(0, 300),
      orderId: garment.orderId, garmentId: garment.garmentId, action: 'photo-bridge-tag-job',
    }],
  });

  const queuePhotoBridgeAutoTag = async (garmentId: string): Promise<void> => {
    if (photoBridgeJobInProgressRef.current.has(`auto:${garmentId}`)) return;
    // Enforced at dispatch: effects may resume a persisted photo on a blocked screen.
    const eligibility = photoEligibility(orderRef.current, garmentId);
    if (!eligibility.ok) {
      setPhotoBridgeJobNotice(`자동 태그를 보내지 않았습니다. ${eligibility.reason}`);
      return;
    }
    const session = readPhotoBridgeConnectionSession();
    const modeAtConfirmation = modeRef.current;
    if (!session || !(
      (modeAtConfirmation === 'passive' && session.mode === 'STORE') ||
      (modeAtConfirmation === 'simulation' && (session.mode === 'DEV' || session.mode === 'TEST'))
    )) return;
    const initial = orderRef.current.garments?.find((garment) => garment.garmentId === garmentId);
    if (!initial) return;
    const photo = currentIntakePhotoProof(initial);
    if (!photo) return;
    const replacePriorTestReservation = initial.photoBridgeAutoTagRequestId &&
      (initial.photoBridgeAutoTagMode === 'DEV' || initial.photoBridgeAutoTagMode === 'TEST') &&
      session.mode === 'STORE';
    if (initial.photoBridgeAutoTagRequestId && !replacePriorTestReservation) return;
    const candidate = photoBridgeTagAutoRequest(initial);
    if (!candidate) return;
    const now = new Date().toISOString();
    const proposedId = crypto.randomUUID();
    let created = false;
    let reserved: GarmentRecord;
    try {
      reserved = savePhotoBridgeJobGarment(garmentId, (record) => {
        if (record.captureRequestId !== photo.requestId || !currentIntakePhotoProof(record)) return record;
        const reservation = reserveFirstPhotoBridgeAutoTag(record, proposedId, session.mode, now);
        created = reservation.created;
        const next = reservation.garment;
        if (reservation.created) {
          return appendPhotoBridgeTagAudit(
            next, reservation.requestId!, 'TEST/PENDING',
            '저장 주문·확인된 접수 사진을 기준으로 1회 자동 태그 작업을 예약했습니다. 인쇄 성공 여부는 확인하지 않았습니다.',
            now,
          );
        }
        if (JSON.stringify(next) !== JSON.stringify(record)) {
          return appendPhotoBridgeTagAudit(
            next, reservation.requestId ?? 'already-printed', 'TEST/PENDING',
            '기존 printed 기록이 있어 자동 재인쇄를 건너뛰었습니다.', now,
          );
        }
        return record;
      });
    } catch (cause) {
      setPhotoBridgeJobNotice(`사진은 저장되어 있습니다. 자동 태그 예약은 저장 경합으로 보류했습니다. ${cause instanceof Error ? cause.message : ''}`);
      return;
    }
    if (!created || !reserved.photoBridgeAutoTagRequestId) {
      setPhotoBridgeJobNotice(reserved.photoBridgeAutoTagStatus === 'skipped'
        ? '기존 인쇄 기록이 있어 자동 중복 태그 요청을 건너뛰었습니다.'
        : `태그 작업 ${reserved.photoBridgeAutoTagStatus ?? 'TEST/PENDING'} · 기존 예약은 재전송하지 않았습니다.`);
      return;
    }

    photoBridgeJobInProgressRef.current.add(`auto:${garmentId}`);
    try {
      const latest = orderRef.current.garments?.find((garment) => garment.garmentId === garmentId);
      const proof = latest && currentIntakePhotoProof(latest);
      if (!latest || latest.photoBridgeAutoTagRequestId !== reserved.photoBridgeAutoTagRequestId || !proof) {
        throw new Error('저장된 자동 태그 요청과 확인된 사진이 변경되어 helper에 전송하지 않았습니다.');
      }
      const tag = createTagData(orderRef.current, latest);
      const job = await requestPhotoBridgeTagJob({
        requestId: reserved.photoBridgeAutoTagRequestId,
        orderId: latest.orderId,
        garmentId: latest.garmentId,
        photoRequestId: proof.requestId,
        photoPath: proof.photoPath,
        photoTimestamp: proof.timestamp,
        photoStatus: proof.status,
        staffConfirmed: true,
        copies: 1,
        alreadyPrinted: latest.tagStatus === 'printed',
        tag,
        ...(session.mode === 'STORE' ? { renderedTag: renderTagForWindows(tag, tagTemplate) } : {}),
      }, 'auto');
      const at = new Date().toISOString();
      const saved = savePhotoBridgeJobGarment(garmentId, (record) => {
        if (photoBridgeTagJobSnapshotMatches(record, job, 'auto')) return record;
        return appendPhotoBridgeTagAudit(
          applyPhotoBridgeTagJobSnapshot(record, job, 'auto'),
          job.requestId, `TEST/PENDING · ${job.status}`,
          job.reason || '자동 태그 작업 상태 응답을 확인했습니다. 실물 인쇄 검증은 받지 않았습니다.',
          at,
        );
      });
      setPhotoBridgeJobNotice(`태그 TEST/PENDING · ${saved.photoBridgeAutoTagStatus ?? job.status}. 인쇄 완료를 뜻하지 않습니다.`);
    } catch (cause) {
      const reason = cause instanceof Error ? cause.message : '자동 태그 작업 응답을 확인하지 못했습니다.';
      try {
        const at = new Date().toISOString();
        savePhotoBridgeJobGarment(garmentId, (record) => {
          if (record.photoBridgeAutoTagRequestId !== reserved.photoBridgeAutoTagRequestId) return record;
          return appendPhotoBridgeTagAudit({
            ...record, photoBridgeAutoTagStatus: 'unknown',
            photoBridgeAutoTagReason: reason.slice(0, 240),
          }, reserved.photoBridgeAutoTagRequestId!, 'TEST/PENDING · unknown', reason, at);
        });
      } catch { /* Preserve the previously saved photo and its automatic reservation. */ }
      setPhotoBridgeJobNotice(`사진 저장됨 · 자동 태그 결과 확인 필요. 중복 방지를 위해 자동 재전송하지 않았습니다. ${reason}`);
    } finally {
      photoBridgeJobInProgressRef.current.delete(`auto:${garmentId}`);
    }
  };

  const captureProviderRef = useRef<CaptureProvider | null>(null);
  captureProviderRef.current = {
    async capture(orderId, garmentId, requestId) {
      if ((operationModeRef.current ?? modeRef.current) === 'bridge') {
        const result = await captureGarmentPhoto(
          new LocalBridgeClient({ baseUrl: bridgeUrlRef.current }),
          { orderId, garmentId, requestId },
        );
        if (result.status !== 'saved' || typeof result.photoPath !== 'string' || !result.photoPath.trim())
          throw new Error('Local Bridge가 실제 사진 파일 저장을 확인하지 않았습니다.');
        return { status: 'saved', photoPath: result.photoPath, photoTimestamp: typeof result.photoTimestamp === 'string' ? result.photoTimestamp : undefined };
      }
      const video = videoRef.current;
      if (video && video.videoWidth && video.videoHeight) {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        if (!context) throw new Error('카메라 영상을 캡처할 수 없습니다.');
        context.drawImage(video, 0, 0);
        setPreviewUrls((old) => ({ ...old, [garmentId]: canvas.toDataURL('image/jpeg', 0.85) }));
      }
      // Browser preview data is ephemeral; simulation never asserts that a JPEG was saved to D:.
      return { status: 'simulated' };
    },
  };

  const printerRef = useRef<TagPrinterAdapter | null>(null);
  printerRef.current = {
    getPrinterStatus: () => activePrinter().getPrinterStatus(),
    printGarmentTag: (tagData, requestId) => activePrinter().printGarmentTag(tagData, requestId),
    reprintGarmentTag: (tagData, requestId) => activePrinter().reprintGarmentTag(tagData, requestId),
    testPrint: (requestId) => activePrinter().testPrint(requestId),
  };
  function activePrinter(): TagPrinterAdapter {
    return (operationModeRef.current ?? modeRef.current) === 'bridge'
      ? createLocalBridgeTagPrinterAdapter(new LocalBridgeClient({ baseUrl: bridgeUrlRef.current }), settingsRef.current)
      : simulationPrinter;
  }

  const automationRef = useRef<GarmentAutomation | null>(null);
  if (!automationRef.current) {
    automationRef.current = new GarmentAutomation({
      order,
      getGarments: () => orderRef.current.garments ?? [],
      saveGarments: persist,
      capture: { capture: (...args) => captureProviderRef.current!.capture(...args) },
      printer: {
        getPrinterStatus: () => printerRef.current!.getPrinterStatus(),
        printGarmentTag: (...args) => printerRef.current!.printGarmentTag(...args),
        reprintGarmentTag: (...args) => printerRef.current!.reprintGarmentTag(...args),
        testPrint: (...args) => printerRef.current!.testPrint(...args),
      },
    });
  }

  useEffect(() => {
    let live = true;
    let connectionRetry: ReturnType<typeof setTimeout> | undefined;
    async function checkBridge() {
      if (passiveActiveRef.current || Boolean(readPhotoBridgeSession())) {
        passiveActiveRef.current = true;
        setMode('passive');
        setPassiveReady(false);
        setPassiveStatus('도우미 연결 확인 중');
        try {
          if (!readPhotoBridgeSession()) throw new Error('대기 중인 요청이 보존되어 패시브 모드를 유지합니다. Windows 사진 도우미 토큰을 다시 설정해 주세요.');
          const available = await checkPassivePhotoBridge();
          if (!available) throw new Error('Windows 사진 도우미에 연결할 수 없습니다. 연결 오류 상태에서는 촬영 장치를 실행하지 않습니다.');
          const settings = await getPhotoSettings();
          if (!settings.configured) throw new Error('Windows 사진 도우미의 사진 경로 설정이 완료되지 않았습니다.');
          if (!live) return;
          setPassiveReady(true);
          setPassiveStatus(orderRef.current.garments?.[currentIndexRef.current]?.photoStatus === 'saved'
            ? '사진 완료' : '도우미 연결됨 · ARM 대기');
          setHardware({ camera: '기존 촬영 프로그램 사용', footSwitch: '수동 ARM 필요', printer: '연결 안 됨' });
          setNotice('촬영은 기존 WebCamImageSave와 풋스위치가 담당합니다. 이 화면은 생성된 사진 파일의 연결만 확인합니다.');
          setError('');
        } catch (cause) {
          if (!live) return;
          setMode('passive');
          setPassiveReady(false);
          setPassiveStatus('도우미 사용 불가');
          setHardware({ camera: '수동 도우미 확인 필요', footSwitch: '패시브 모드 · 키 입력 사용 안 함', printer: '연결 안 됨' });
          setError(cause instanceof Error ? cause.message : 'Windows 사진 도우미 상태를 확인하지 못했습니다.');
          // A helper/folder arriving after this screen mounts must recover
          // without resetting the garment or sending a second ARM.
          connectionRetry = setTimeout(() => { if (live) void checkBridge(); }, 1500);
        }
        return;
      }
      try {
        const client = new LocalBridgeClient({ baseUrl: bridgeUrl });
        const health = await client.getHealth();
        if (!isOnline(health)) throw new Error('로컬 장치 연결 안 됨');
        const [devices, printer] = await Promise.all([getHardwareStatus(client), client.getPrinterStatus()]);
        if (devices.mode === 'simulation') throw new Error('Local Bridge를 사용할 수 없습니다.');
        if (!live) return;
        setMode('bridge');
        setHardware({
          camera: deviceLabel(devices.camera),
          footSwitch: deviceLabel(devices.footSwitch),
          printer: deviceLabel(printer),
        });
        setNotice('Local Bridge 응답을 확인했습니다. 실제 장치 연결 상태는 위 항목별로 확인해 주세요.');
        // Simulated steps cannot become physical by merely reconnecting a device.
        const previous = orderRef.current.garments ?? [];
        if (!automationRef.current?.isBusy() &&
          previous.some((item) => item.photoStatus === 'simulated' || item.tagStatus === 'simulated')) {
          const updated = previous.map((item) => {
            if (item.photoStatus !== 'simulated' && item.tagStatus !== 'simulated') return item;
            return {
              ...item, photoStatus: 'not-captured' as const, tagStatus: 'not-generated' as const,
              photoPath: undefined, photoTimestamp: undefined, tagGeneratedAt: undefined,
              printRequestId: undefined, tagPrintRequestedAt: undefined, captureRequestId: undefined,
            };
          });
          try {
            persist(updated, previous);
            setCurrentIndex(Math.max(0, updated.findIndex((item) => item.tagStatus !== 'printed')));
          } catch (cause) {
            setError(cause instanceof Error ? cause.message : '시뮬레이션 기록을 갱신하지 못했습니다.');
          }
        }
      } catch {
        if (!live) return;
        setMode('simulation');
        setHardware({
          camera: '상태 미확인',
          footSwitch: footSwitchCode ? '키 매핑 설정됨 · 실제 연결 미확인' : '상태 미확인',
          printer: '연결 안 됨',
        });
        setNotice('시뮬레이션 모드');
      }
    }
    void checkBridge();
    return () => { live = false; clearTimeout(connectionRetry); };
  }, [bridgeUrl, persist, footSwitchCode, bridgeSessionRevision]);

  useEffect(() => {
    if (mode !== 'simulation') return;
    // Real capture belongs exclusively to the existing store program.
    // Do not request browser camera access, including on a disconnected helper.
    setHardware((old) => ({ ...old, camera: '모의 촬영 · 브라우저 카메라 사용 안 함' }));
  }, [mode]);

  const complete = (result: Awaited<ReturnType<GarmentAutomation['captureAndPrint']>>, fromIndex: number) => {
    if (result.status === 'completed') {
      setError('');
      setNotice(result.garment?.tagStatus === 'printed'
        ? '사진 저장 및 태그 인쇄 응답을 확인했습니다.' : '촬영·태그를 시뮬레이션했습니다. 실제 사진 저장 및 인쇄는 수행하지 않았습니다.');
      return;
    }
    if (result.status === 'busy' || result.status === 'debounced') return;
    const photoFailed = result.garment?.photoStatus === 'failed';
    setError(photoFailed
      ? `사진 촬영 실패. 다시 촬영해 주세요. ${result.error ?? ''}`
      : `TSC TE210 태그 출력 실패. 사진 및 접수 기록은 유지되었습니다. ${result.error ?? ''}`);
    const next = nextBatchPhotoIndex(orderRef.current.garments ?? [], fromIndex);
    if (next >= 0) setCurrentIndex(next);
  };

  const runCapture = useCallback(async () => {
    if (passiveActiveRef.current) return;
    const index = currentIndexRef.current;
    const garment = orderRef.current.garments?.[index];
    if (!garment || automationRef.current!.isBusy()) return;
    const captureGate = photoEligibility(orderRef.current, garment.garmentId);
    if (!captureGate.ok) { setError(captureGate.reason); return; }
    setBusy(true);
    setError('');
    operationModeRef.current = modeRef.current;
    try {
      const result = garment.photoStatus === 'saved'
        ? await automationRef.current!.retakePhoto(garment.garmentId)
        : await automationRef.current!.captureAndPrint(garment.garmentId);
      complete(result, index);
      const bridge = readPhotoBridgeConnectionSession();
      if (result.status === 'completed' && result.garment &&
          modeRef.current === 'simulation' && (bridge?.mode === 'DEV' || bridge?.mode === 'TEST')) {
        try {
          const persisted = orderRef.current.garments?.find((item) => item.garmentId === result.garment!.garmentId);
          if (!persisted || persisted.captureRequestId !== result.garment.captureRequestId) {
            throw new Error('촬영 후 저장 주문에서 같은 사진 요청을 확인하지 못했습니다.');
          }
          await confirmPersistedPhotoWithBridge(persisted);
          await queuePhotoBridgeAutoTag(persisted.garmentId);
        } catch (cause) {
          const detail = cause instanceof Error ? cause.message : 'Photo Bridge 사진 증거를 저장하지 못했습니다.';
          setPhotoBridgeJobNotice(`사진 저장됨 · TEST/PENDING · 사진 증거 확인 실패로 자동 태그 요청을 보류했습니다. ${detail}`);
        }
      }
    } finally {
      operationModeRef.current = null;
      setBusy(false);
    }
  }, []);

  const photoGateRef = useRef(true);
  useEffect(() => {
    if (!footSwitchCode.trim() || mode === 'passive' || passiveActiveRef.current) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (passiveActiveRef.current) return;
      const target = event.target as HTMLElement | null;
      if (event.repeat || event.code !== footSwitchCode.trim() ||
          target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      event.preventDefault();
      if (!photoGateRef.current) return;
      void runCapture();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [footSwitchCode, mode, runCapture]);

  const armPassivePhoto = async () => {
    const existingRequest = passiveRequestRef.current;
    if (existingRequest) {
      setError('');
      setPassiveStatus('보존된 요청 상태 재확인 중');
      setPassivePollEnabled(true);
      return;
    }
    const garment = orderRef.current.garments?.[currentIndexRef.current];
    if (!garment || !passiveReady || busy) return;
    // Auto-continued sequences arm the *current* garment; it must itself be eligible.
    const armGate = photoEligibility(orderRef.current, garment.garmentId);
    if (!armGate.ok) { continuePassiveSequenceRef.current = false; setError(armGate.reason); return; }
    const request: PassivePhotoRequest = {
      requestId: crypto.randomUUID(),
      orderId: orderRef.current.id,
      garmentId: garment.garmentId,
    };
    try {
      storePendingPhotoRequest(request);
    } catch (cause) {
      setPassiveStatus('요청을 보존할 수 없음');
      setError(cause instanceof Error ? cause.message : '대기 요청을 보존하지 못했습니다.');
      return;
    }
    passiveRequestRef.current = request;
    setPassiveRequest(request);
    setVerifiedPassivePhoto(null);
    setPassivePollEnabled(false);
    setBusy(true);
    setError('');
    setNotice('');
    setPassiveStatus('주문 등록 및 ARM 요청 중');
    try {
      if (!registeredPhotoOrdersRef.current.has(orderRef.current.id)) {
        const registration = await registerPhotoOrder(orderRef.current);
        if (registration.orderId !== orderRef.current.id) throw new Error('사진 도우미 주문 등록 응답의 주문 ID가 일치하지 않습니다.');
        registeredPhotoOrdersRef.current.add(orderRef.current.id);
      }
      const result = await armPhoto(request.orderId, request.garmentId, request.requestId);
      if (result.status !== 'armed' || result.requestId !== request.requestId ||
          result.orderId !== request.orderId || result.garmentId !== request.garmentId) {
        throw new Error('사진 도우미 ARM 응답의 상태 또는 주문·의류 식별자가 일치하지 않습니다.');
      }
      setPassiveStatus('ARM 완료 · 촬영 및 새 사진 파일 감지 대기');
      setNotice('ARM 완료. 기존 풋스위치로 촬영하면 새 사진의 저장 완료를 확인해 현재 의류에 자동 연결합니다. 원본은 변경하지 않습니다.');
      setPassivePollEnabled(true);
    } catch (cause) {
      setPassiveStatus('ARM 응답 불명 · 요청 보존됨');
      setError(`${cause instanceof Error ? cause.message : '패시브 촬영 준비에 실패했습니다.'} 중복 촬영을 막기 위해 새 ARM을 보내지 않았습니다. 아래에서 같은 요청의 상태를 다시 확인하세요.`);
    } finally {
      setBusy(false);
    }
  };

  const passiveAttention = (request: PassivePhotoRequest, reason: string, terminal: boolean) => {
    savePhotoBridgeJobGarment(request.garmentId, (record) => ({
      ...record, lastError: reason,
      ...(terminal && record.photoStatus !== 'saved' ? { photoStatus: 'failed' as const } : {}),
    }));
    // Only a matching terminal response releases an ARM. An uncertain network
    // response must never associate its late photo with another garment.
    if (!terminal) return;
    removePendingPhotoRequest(request.orderId);
    passiveRequestRef.current = null;
    verifiedPassivePhotoRef.current = null;
    setPassiveRequest(null);
    setVerifiedPassivePhoto(null);
    continuePassiveSequenceRef.current = false;
    setNotice('사진을 확인하지 못했습니다. 같은 의류에서 다시 촬영하세요. 의류 ID는 유지됩니다.');
  };

  useEffect(() => {
    // Only continue a sequence that staff already armed. Never arm on page load,
    // a mere garment click, or after an uncertain photo-confirmation response.
    if (!continuePassiveSequenceRef.current || mode !== 'passive' || busy ||
        !passiveReady || passiveRequestRef.current) return;
    continuePassiveSequenceRef.current = false;
    void armPassivePhoto();
  }, [currentIndex, mode, busy, passiveReady, passiveRequest]);

  useEffect(() => {
    if (!passiveRequest || mode !== 'passive' || !passivePollEnabled) return;
    let live = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const poll = async () => {
      if (!live) return;
      setPassiveStatus('저장 상태 확인 중');
      let terminal = false;
      try {
        const result = await readBatchArm(passiveRequest);
        if (!live) return;
        if (result.requestId !== passiveRequest.requestId || result.orderId !== passiveRequest.orderId ||
            result.garmentId !== passiveRequest.garmentId) {
          throw new Error('사진 도우미 응답의 요청·주문·의류 식별자가 일치하지 않습니다.');
        }
        terminal = result.status === 'failed';
        if (result.status === 'failed') throw new Error(result.error || '사진 도우미가 사진 저장 실패를 보고했습니다.');
        if (result.status === 'saved') {
          if (typeof result.photoPath !== 'string' || !result.photoPath.trim() ||
              typeof result.photoTimestamp !== 'string' || !result.photoTimestamp.trim()) {
            terminal = true;
            throw new Error('저장 응답에 유효한 사진 경로 또는 촬영 시각이 없습니다.');
          }
          const photo: VerifiedPassivePhoto = {
            ...passiveRequest,
            photoPath: result.photoPath.trim(),
            photoTimestamp: result.photoTimestamp,
            ...(typeof result.archivePath === 'string' && result.archivePath.trim()
              ? { archivePath: result.archivePath.trim() } : {}),
            ...(typeof result.archiveError === 'string' && result.archiveError.trim()
              ? { archiveError: result.archiveError.trim() } : {}),
          };
          verifiedPassivePhotoRef.current = photo;
          setVerifiedPassivePhoto(photo);
          // A saved response for this exact ARM is the Bridge's completed
          // new-file proof. capturedAt is optional across installed versions;
          // its absence must not require a separate staff identity action.
          const photos = await listRecentPhotos();
          const source = photos.find((item) => item.origin === 'bridge' &&
            item.sourcePath === photo.photoPath && item.timestamp === photo.photoTimestamp);
          if (!source) throw new Error('ARM 사진과 일치하는 원본 미리보기를 찾지 못했습니다. 요청은 보존했습니다.');
          const preview = await loadPhotoPreview(source.id, 'bridge');
          if (!live) return;
          setPreviewUrls((old) => ({ ...old, [photo.garmentId]: preview }));
          await confirmPassivePhotoIdentity(true, true);
          setPassivePollEnabled(false);
          return;
        }
        setPassiveStatus('ARM 완료 · 촬영 및 새 사진 파일 감지 대기');
        timer = setTimeout(() => { void poll(); }, 1500);
      } catch (cause) {
        if (!live) return;
        verifiedPassivePhotoRef.current = null;
        setVerifiedPassivePhoto(null);
        setPassivePollEnabled(!terminal);
        setPassiveStatus(terminal ? '상태 확인 오류 · 요청 보존됨' : '같은 촬영 요청 자동 재확인 중');
        setError(`${cause instanceof Error ? cause.message : '사진 저장 상태를 확인하지 못했습니다.'} ARM 요청은 보존했습니다. 새 촬영 요청 없이 같은 요청을 재확인합니다.`);
        try {
          passiveAttention(passiveRequest, cause instanceof Error ? cause.message : '사진 확인 필요', terminal);
          if (terminal) setPassiveStatus('해당 의류 확인 필요 · 나머지 의류 계속 진행');
        } catch (storageError) {
          setError(`주문 저장 확인 필요. 요청을 보존했습니다. ${storageError instanceof Error ? storageError.message : ''}`);
        }
        if (live && !terminal) timer = setTimeout(() => { void poll(); }, 1500);
      }
    };
    void poll();
    return () => {
      live = false;
      if (timer) clearTimeout(timer);
    };
  }, [mode, passivePollEnabled, passiveRequest]);

  const advancePassiveSequence = (id: string, attention = false) => {
    continuePassiveSequenceRef.current = false;
    setNotice(attention ? '현재 세탁물 확인이 필요합니다. 기존 기록은 보존했습니다.'
      : '현재 세탁물 사진 저장 완료. 추가 사진은 같은 세탁물에 촬영하세요. 다음 세탁물 버튼을 누를 때만 전환합니다.');
  };

  const confirmPassivePhotoIdentity = async (identityConfirmed: boolean, automaticReference = false) => {
    if (!identityConfirmed) return;
    const pending = passiveRequestRef.current;
    const photo = verifiedPassivePhotoRef.current;
    if (!pending || !photo || photo.requestId !== pending.requestId ||
        photo.orderId !== pending.orderId || photo.garmentId !== pending.garmentId) {
      setError('확인된 저장 응답과 대기 중인 ARM 요청이 일치하지 않습니다. 요청을 보존했습니다.');
      return;
    }
    if (orderRef.current.id !== pending.orderId ||
        orderRef.current.garments?.[currentIndexRef.current]?.garmentId !== pending.garmentId) {
      setError('ARM한 의류가 현재 선택 의류와 다릅니다. 의류를 전환하지 말고 원래 의류 선택을 복구한 뒤 확인하세요. 요청은 보존했습니다.');
      return;
    }
    const expected = orderRef.current;
    const previous = expected.garments ?? [];
    const target = previous.find((item) => item.garmentId === pending.garmentId);
    if (!target) {
      setError('저장된 주문에서 ARM한 의류를 찾을 수 없습니다. 요청은 보존했습니다.');
      return;
    }
    const sameRequest = (target.photoHistory ?? []).find((entry) => entry.requestId === pending.requestId);
    if (sameRequest) {
      if (sameRequest.path !== photo.photoPath || sameRequest.status !== 'saved' ||
          sameRequest.garmentId !== pending.garmentId || target.captureRequestId !== pending.requestId) {
        setError('기존 사진 요청·현재 의류 요청 ID와 저장된 파일이 일치하지 않습니다. 사진 기록을 덮어쓰지 않았습니다.');
        return;
      }
      setBusy(true);
      try {
        updateSavedOrder(expected, expected);
        await confirmPersistedPhotoWithBridge(target);
        removePendingPhotoRequest(pending.orderId);
        passiveRequestRef.current = null;
        verifiedPassivePhotoRef.current = null;
        setPassiveRequest(null);
        setVerifiedPassivePhoto(null);
        setPassiveStatus('이미 저장된 사진 확인됨');
        setNotice('동일 사진 요청을 다시 연결하지 않았습니다. 도우미에 저장된 사진 증거를 확인했습니다.');
        void queuePhotoBridgeAutoTag(pending.garmentId);
        advancePassiveSequence(pending.garmentId);
      } catch (cause) {
        setError(`기존 사진과 주문은 보존했습니다. 도우미 확인이 끝나지 않아 자동 태그를 보내지 않았습니다. ${cause instanceof Error ? cause.message : ''}`);
        passiveAttention(pending, cause instanceof Error ? cause.message : '사진 확인 필요', true);
      } finally {
        setBusy(false);
      }
      return;
    }

    const timestamp = photo.photoTimestamp;
    if ([...(target.photoHistory ?? []), ...(target.beforePhoto ? [target.beforePhoto] : [])]
      .some((entry) => entry.path === photo.photoPath && entry.requestId !== pending.requestId)) {
      setError('이 사진 파일은 이미 의류 사진 기록에 연결되어 있습니다. 같은 파일을 새 촬영으로 중복 연결하지 않았습니다.');
      return;
    }
    const metadata = {
      garmentId: pending.garmentId,
      requestId: pending.requestId,
      role: 'intake' as const,
      status: 'saved' as const,
      timestamp,
      origin: 'bridge' as const,
      path: photo.photoPath,
      ...(photo.archivePath ? { archivePath: photo.archivePath } : {}),
      ...(photo.archiveError ? { archiveError: photo.archiveError } : {}),
    };
    const updatedGarments = previous.map((item) => {
      if (item.garmentId !== pending.garmentId) return item;
      const history = [...(item.photoHistory ?? [])];
      for (const earlierPhoto of [item.beforePhoto, item.completionPhoto]) {
        if (earlierPhoto && !history.some((entry) => entry.requestId === earlierPhoto.requestId))
          history.push({ ...earlierPhoto });
      }
      const simulatedMetadata = item.beforePhoto?.status === 'simulated'
        ? item.beforePhoto
        : item.photoStatus === 'simulated'
          ? {
            garmentId: item.garmentId,
            requestId: item.captureRequestId ?? `legacy-${item.garmentId}`,
            role: 'intake' as const,
            status: 'simulated' as const,
            timestamp: item.photoTimestamp ?? '',
            origin: 'simulation' as const,
            ...(item.photoPath ? { path: item.photoPath } : {}),
          }
          : undefined;
      if (simulatedMetadata && !history.some((entry) => entry.requestId === simulatedMetadata.requestId))
        history.push({ ...simulatedMetadata });
      history.push(metadata);
      return {
        ...item,
        photoStatus: 'saved' as const,
        captureRequestId: pending.requestId,
        photoPath: photo.photoPath,
        photoTimestamp: timestamp,
        beforePhoto: item.beforePhoto ?? metadata,
        photoHistory: history,
        lastError: undefined,
        auditEvents: [...item.auditEvents, {
          at: timestamp,
          type: 'photo-captured' as const,
          status: 'saved',
          orderId: expected.id,
          garmentId: item.garmentId,
          details: automaticReference
            ? 'ARM 이후 생성되고 쓰기 완료된 새 원본을 ARM 요청의 의류에 자동 연결했습니다. 원본 변경 없음.'
            : '직원 확인: Windows 사진 도우미 저장 파일을 열어 선택한 의류의 사진임을 확인했습니다.',
        }],
      };
    });
    const revised = { ...expected, garments: updatedGarments };
    try {
      updateSavedOrder(revised, expected);
      orderRef.current = revised;
      setGarments(updatedGarments);
      onOrderChange(revised);
      removePendingPhotoRequest(pending.orderId);
      passiveRequestRef.current = null;
      verifiedPassivePhotoRef.current = null;
      setPassiveRequest(null);
      setVerifiedPassivePhoto(null);
      setPassiveStatus(automaticReference ? '사진 완료' : '직원 확인 및 저장 완료');
      setError('');
      const photoNotice = automaticReference
        ? '사진 완료 · ARM한 의류에 새 사진을 자동 연결했습니다. 원본과 태그 작업은 변경하지 않았습니다.'
        : '직원이 Windows Explorer에서 사진과 선택 의류의 일치를 확인해 주문에 저장했습니다. Photo Bridge의 사진 확인 후 태그 작업을 진행합니다.';
      setNotice(`${photoNotice}${photo.archivePath ? ` 고객별 사본 저장 완료: ${photo.archivePath}` : ''}`);
      if (photo.archiveError) setError(photo.archiveError);
    } catch (cause) {
      setError(`${cause instanceof Error ? cause.message : '확인된 사진을 주문에 저장하지 못했습니다.'} 대기 요청과 파일 확인 결과를 보존했습니다. 새 ARM을 보내지 마세요.`);
      return;
    }
    setBusy(true);
    try {
      const savedGarment = revised.garments?.find((item) => item.garmentId === pending.garmentId);
      if (!savedGarment) throw new Error('저장한 주문에서 Photo Bridge 사진 증거를 찾지 못했습니다.');
      await confirmPersistedPhotoWithBridge(savedGarment);
      // Staff starts this batch once; use the unchanged at-most-once tag path.
      // Printer acknowledgement must not delay selecting/arming the next photo.
      void queuePhotoBridgeAutoTag(pending.garmentId);
      advancePassiveSequence(pending.garmentId);
    } catch (cause) {
      const detail = cause instanceof Error ? cause.message : 'Photo Bridge 사진 증거를 저장하지 못했습니다.';
      setPhotoBridgeJobNotice(`사진과 주문은 저장됨 · 사진 확인 증거 실패로 자동 태그 요청을 보류했습니다. ${detail}`);
      passiveAttention(pending, detail, true);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!photoBridgeTagMode) return;
    let live = true;
    let inFlight = false;
    const reconcileTagJobs = async () => {
      if (inFlight || !live) return;
      inFlight = true;
      try {
        const activeSession = readPhotoBridgeConnectionSession();
        if (!activeSession || activeSession.mode !== photoBridgeTagMode) return;
        const records = (orderRef.current.garments ?? [])
          .filter((item) => item.photoBridgeAutoTagRequestId &&
            ['pending', 'submitted', 'unknown'].includes(item.photoBridgeAutoTagStatus ?? 'pending') ||
            item.photoBridgeReprintRequestId &&
            ['pending', 'submitted', 'unknown'].includes(item.photoBridgeReprintStatus ?? 'pending'))
          .slice(0, 12);
        await Promise.all(records.map(async (snapshot) => {
          if (!live) return;
          try {
            const job = await getPhotoBridgeTagJob(snapshot.garmentId);
            if (!live) return;
            if (!job) {
              if (snapshot.photoBridgeAutoTagRequestId && snapshot.photoBridgeAutoTagStatus === 'pending') {
                const at = new Date().toISOString();
                savePhotoBridgeJobGarment(snapshot.garmentId, (record) => {
                  if (record.photoBridgeAutoTagStatus !== 'pending' || record.photoBridgeAutoTagJobId) return record;
                  return {
                    ...record, photoBridgeAutoTagStatus: 'unknown',
                    photoBridgeAutoTagReason: '작업 조회에서 기존 자동 요청을 찾지 못했습니다. 중복 방지를 위해 POST를 재전송하지 않았습니다.',
                    auditEvents: [...record.auditEvents, {
                      at, type: 'print-requested', status: 'TEST/PENDING · unknown',
                      orderId: record.orderId, garmentId: record.garmentId,
                      details: 'Photo Bridge GET 상태 조회에만 실패했습니다. 자동 태그를 재전송하지 않았습니다.',
                    }],
                  };
                });
              }
              return;
            }
            if (job.automatic && job.requestId === snapshot.photoBridgeAutoTagRequestId) {
              const at = new Date().toISOString();
              savePhotoBridgeJobGarment(snapshot.garmentId, (record) => {
                if (photoBridgeTagJobSnapshotMatches(record, job, 'auto')) return record;
                return appendPhotoBridgeTagAudit(
                  applyPhotoBridgeTagJobSnapshot(record, job, 'auto'),
                  job.requestId, `TEST/PENDING · ${job.status}`,
                  job.reason || '자동 태그 작업 상태를 GET으로 다시 확인했습니다. 실물 인쇄는 확인되지 않았습니다.',
                  at,
                );
              });
            } else if (!job.automatic && job.requestId === snapshot.photoBridgeReprintRequestId) {
              const at = new Date().toISOString();
              savePhotoBridgeJobGarment(snapshot.garmentId, (record) => {
                if (photoBridgeTagJobSnapshotMatches(record, job, 'reprint')) return record;
                return appendPhotoBridgeTagAudit(
                  applyPhotoBridgeTagJobSnapshot(record, job, 'reprint'),
                  job.requestId, `직원 재출력 · TEST/PENDING · ${job.status}`,
                  job.reason || '직원 요청 태그 작업을 GET으로 다시 확인했습니다. 실물 인쇄는 확인되지 않았습니다.',
                  at,
                );
              });
            }
          } catch {
            // A lost/unavailable helper is a status-check failure, never permission to resend.
          }
        }));
      } finally {
        inFlight = false;
      }
    };
    void reconcileTagJobs();
    const timer = window.setInterval(() => { void reconcileTagJobs(); }, 4000);
    return () => { live = false; window.clearInterval(timer); };
  }, [photoBridgeTagMode, bridgeSessionRevision, order.id, savePhotoBridgeJobGarment]);

  const runPrint = async (action: 'retry' | 'reprint') => {
    if (modeRef.current === 'passive') return;
    const garment = orderRef.current.garments?.[currentIndexRef.current];
    if (!garment || automationRef.current!.isBusy()) return;
    if (modeRef.current === 'bridge' && garment.photoStatus !== 'saved') {
      setError('실제 사진 파일 저장이 확인되지 않아 실물 태그를 인쇄할 수 없습니다. 먼저 촬영해 주세요.');
      return;
    }
    setBusy(true);
    operationModeRef.current = modeRef.current;
    try {
      complete(await (action === 'retry'
        ? automationRef.current!.retryPrint(garment.garmentId)
        : automationRef.current!.reprint(garment.garmentId)), currentIndexRef.current);
    } finally {
      operationModeRef.current = null;
      setBusy(false);
    }
  };

  /** Read-only: refreshes the saved job status. Never sends a print job. */
  const checkPhotoBridgeTagStatus = async () => {
    const garment = orderRef.current.garments?.[currentIndexRef.current];
    if (!garment || photoBridgeJobInProgressRef.current.has('status-check')) return;
    photoBridgeJobInProgressRef.current.add('status-check');
    setTagStatusChecking(true);
    setPhotoBridgeJobNotice('출력 상태 조회 중입니다. 새 출력 요청은 보내지 않습니다.');
    try {
      const job = await getPhotoBridgeTagJob(garment.garmentId);
      if (orderRef.current.garments?.[currentIndexRef.current]?.garmentId !== garment.garmentId) {
        setPhotoBridgeJobNotice('조회 중 선택 의류가 바뀌었습니다. 현재 의류에서 다시 상태를 확인해 주세요. 재전송하지 않았습니다.');
        return;
      }
      if (!job || job.orderId !== garment.orderId || job.garmentId !== garment.garmentId ||
          (job.barcodeValue !== undefined && job.barcodeValue !== garment.barcodeValue)) {
        setPhotoBridgeJobNotice('출력 작업 기록을 확인하지 못했습니다. 새 작업은 보내지 않았습니다. 프린터 대기열과 실물 태그를 확인해 주세요.');
        return;
      }
      const kind = !job.automatic && job.requestId === garment.photoBridgeReprintRequestId ? 'reprint'
        : job.automatic && job.requestId === garment.photoBridgeAutoTagRequestId ? 'auto' : null;
      if (!kind) {
        setPhotoBridgeJobNotice('저장된 태그 요청 번호와 일치하지 않습니다. 재전송하지 않았습니다.');
        return;
      }
      if (kind) {
        const at = new Date().toISOString();
        savePhotoBridgeJobGarment(garment.garmentId, (record) => photoBridgeTagJobSnapshotMatches(record, job, kind) ? record
          : appendPhotoBridgeTagAudit(applyPhotoBridgeTagJobSnapshot(record, job, kind), job.requestId,
            `상태 조회 · ${job.status}`, '직원이 출력 여부 확인을 눌러 상태만 조회했습니다. 재전송하지 않았습니다.', at));
      }
      setPhotoBridgeJobNotice(tagJobStatusMessage(job));
    } catch (cause) {
      setPhotoBridgeJobNotice(`출력 상태를 조회하지 못했습니다. ${cause instanceof Error ? cause.message : '연결 상태를 확인해 주세요.'} 재전송하지 않았습니다.`);
    } finally {
      photoBridgeJobInProgressRef.current.delete('status-check');
      setTagStatusChecking(false);
    }
  };

  const requestPhotoBridgeReprint = async () => {
    if (!photoBridgeTagMode || photoBridgeJobInProgressRef.current.has('manual-reprint')) return;
    const session = readPhotoBridgeConnectionSession();
    if (!session || session.mode !== photoBridgeTagMode) {
      setPhotoBridgeJobNotice('Photo Bridge 연결 상태를 다시 확인해 주세요. 자동으로 태그를 출력하지 않았습니다.');
      return;
    }
    const garment = orderRef.current.garments?.[currentIndexRef.current];
    if (!garment) return;
    if (garment.barcodeValue !== garment.garmentId) {
      setPhotoBridgeJobNotice('기존 바코드가 현재 출력 양식의 의류 ID와 다릅니다. 값을 바꾸지 않고 출력을 중단했습니다. 관리자 진단에서 원본 태그를 확인하세요.');
      return;
    }
    // Lock before the first network read, not only after confirmation.
    photoBridgeJobInProgressRef.current.add('manual-reprint');
    let proof = currentIntakePhotoProof(garment);
    let historyOnly = false;
    try {
      const latest = await getPhotoBridgeTagJob(garment.garmentId);
      if (latest && (latest.orderId !== garment.orderId || latest.garmentId !== garment.garmentId))
        throw new Error('출력 이력의 주문·의류가 일치하지 않습니다.');
      if (latest && ['pending', 'submitted', 'unknown', 'skipped'].includes(latest.status))
        throw new Error('출력 여부가 불명확합니다. 프린터 대기열·실물 태그와 작업 이력을 먼저 확인하세요. 중복 요청하지 않았습니다.');
      const history = verifiedHistory(garment, latest);
      if (!latest && !garment.photoBridgeAutoTagRequestId && !garment.photoBridgeReprintRequestId && proof) {
        await confirmPersistedPhotoWithBridge(garment);
        await queuePhotoBridgeAutoTag(garment.garmentId);
        return;
      }
      if (!proof && history) { proof = history; historyOnly = true; }
      if (!latest && (garment.photoBridgeAutoTagRequestId || garment.photoBridgeReprintRequestId))
        throw new Error('기존 출력 작업을 찾지 못했습니다. 새 작업을 보내지 않았습니다.');
      if (latest?.status === 'failed' && !window.confirm('프린터 대기열에 작업이 없고 실물 태그가 나오지 않았는지 확인했습니까? 확인 후 1장만 재시도합니다.')) return;
      if (latest?.status === 'printed' && !history)
        throw new Error('검증된 동일 ID·바코드 출력 이력이 필요합니다.');
      if (latest?.status === 'printed' && !window.confirm('기존 태그와 동일한 의류 ID·바코드로 1장을 추가 출력합니까?')) return;
    } catch (cause) {
      setPhotoBridgeJobNotice(cause instanceof Error ? cause.message : '출력 이력 확인 실패');
      return;
    } finally {
      photoBridgeJobInProgressRef.current.delete('manual-reprint');
    }
    if (!proof ||
        (photoBridgeTagMode === 'STORE' && proof.status !== 'saved') ||
        (tagTemplateSource !== 'live' && photoBridgeTagMode === 'STORE')) {
      setPhotoBridgeJobNotice(tagTemplateError ||
        '직접 재출력하려면 현재 의류의 저장 사진 신원과 운영 템플릿을 확인해야 합니다.');
      return;
    }
    photoBridgeJobInProgressRef.current.add('manual-reprint');
    setBusy(true);
    setError('');
    const requestId = crypto.randomUUID();
    const now = new Date().toISOString();
    try {
      const requestGarment = savePhotoBridgeJobGarment(garment.garmentId, (record) => {
        if (!historyOnly && (record.captureRequestId !== proof!.requestId || !currentIntakePhotoProof(record))) {
          throw new Error('직원 재출력 전에 연결 사진이 바뀌었습니다. 다시 선택해 주세요.');
        }
        const reserved: GarmentRecord = {
          ...record,
          photoBridgeReprintRequestId: requestId,
          photoBridgeReprintStatus: 'pending',
          photoBridgeReprintMode: photoBridgeTagMode,
          photoBridgeReprintJobId: undefined,
          photoBridgeReprintReason: undefined,
          photoBridgeReprintCreatedAt: now,
        };
        return appendPhotoBridgeTagAudit(
          reserved, requestId, '직원 재출력 · TEST/PENDING',
          '직원이 기존 [태그 재출력] 동작을 직접 눌러 1장 작업을 요청했습니다. 자동 작업은 재전송하지 않습니다.',
          now,
        );
      });
      if (!historyOnly) await confirmPersistedPhotoWithBridge(requestGarment);
      const job = await requestPhotoBridgeTagJob({
        requestId,
        orderId: requestGarment.orderId,
        garmentId: requestGarment.garmentId,
        photoRequestId: proof.requestId,
        photoPath: proof.photoPath,
        photoTimestamp: proof.timestamp,
        photoStatus: proof.status,
        staffConfirmed: true,
        copies: 1,
        manual: true,
        tag: createTagData(orderRef.current, requestGarment),
        ...(session.mode === 'STORE' ? {
          renderedTag: renderTagForWindows(createTagData(orderRef.current, requestGarment), tagTemplate),
        } : {}),
      }, 'reprint');
      const at = new Date().toISOString();
      const saved = savePhotoBridgeJobGarment(garment.garmentId, (record) => {
        if (photoBridgeTagJobSnapshotMatches(record, job, 'reprint')) return record;
        return appendPhotoBridgeTagAudit(
          applyPhotoBridgeTagJobSnapshot(record, job, 'reprint'),
          requestId, `직원 태그 재출력 · ${job.status}`,
          job.reason || '직원 재출력 작업 상태를 확인했습니다. 인쇄 성공 여부는 확인하지 않았습니다.',
          at,
        );
      });
      setPhotoBridgeJobNotice(job.mode === 'STORE' && ['submitted', 'printed', 'failed', 'unknown'].includes(job.status)
        ? (job.reason || '태그 출력 실패: TE210 실제 출력 결과 증거가 없습니다.')
        : `태그 전송 상태 확인 필요 (${saved.photoBridgeReprintStatus ?? job.status}).`);
    } catch (cause) {
      const reason = cause instanceof Error ? cause.message : '직원 요청 태그 상태를 확인하지 못했습니다.';
      try {
        const at = new Date().toISOString();
        savePhotoBridgeJobGarment(garment.garmentId, (record) => {
          if (record.photoBridgeReprintRequestId !== requestId) return record;
          return appendPhotoBridgeTagAudit({
            ...record, photoBridgeReprintStatus: 'unknown',
            photoBridgeReprintReason: reason.slice(0, 240),
          }, requestId, '직원 태그 재출력 · 결과 확인 불가', reason, at);
        });
      } catch { /* A failed print/status request must not roll back saved order or photo data. */ }
      setPhotoBridgeJobNotice(`직원 요청 결과 확인 필요 · 자동으로 재전송하지 않았습니다. ${reason}`);
    } finally {
      photoBridgeJobInProgressRef.current.delete('manual-reprint');
      setBusy(false);
    }
  };

  const runRetake = async () => {
    if (modeRef.current === 'passive') return;
    const garment = orderRef.current.garments?.[currentIndexRef.current];
    if (!garment || automationRef.current!.isBusy()) return;
    if (garment.photoStatus === 'failed') {
      await runCapture();
      return;
    }
    if (!window.confirm('이 의류의 사진을 다시 촬영합니다. 기존 태그는 재인쇄하지 않습니다. 계속할까요?')) return;
    setBusy(true);
    operationModeRef.current = modeRef.current;
    try {
      const result = await automationRef.current!.retakePhoto(garment.garmentId);
      if (result.status === 'completed') {
        setError('');
        setNotice('같은 의류 ID에 새 사진을 연결했습니다. 기존 태그는 재인쇄하지 않았습니다.');
      } else if (result.status === 'failed') {
        setError(`사진 다시 촬영 실패. 기존 사진과 태그는 유지되었습니다. ${result.error ?? ''}`);
      }
    } finally {
      operationModeRef.current = null;
      setBusy(false);
    }
  };

  const changeGarment = (nextIndex: number) => {
    if (busy) return;
    if (passiveRequestRef.current) {
      setError('패시브 ARM 요청이 대기 중이므로 다른 의류로 전환할 수 없습니다. 같은 요청의 상태를 확인하거나 저장 파일 확인을 마치세요.');
      return;
    }
    continuePassiveSequenceRef.current = false;
    setError('');
    setPhotoBridgeJobNotice('');
    setCurrentIndex(nextIndex);
  };

  const confirmBatchTags = () => {
    if (busy || passiveRequestRef.current || photoBridgeTagMode !== 'STORE') return;
    const previous = orderRef.current.garments ?? [];
    const candidates = previous.filter(g => batchTagSubmission(g) && !batchTagComplete(g, 'STORE'));
    if (!candidates.length || !window.confirm(
      `출력된 태그 ${candidates.length}장을 실제로 확인했나요? 의류별 태그·바코드가 모두 맞는 경우에만 확인하세요. 확인해도 재인쇄하거나 장비 완료 기록을 만들지 않습니다.`,
    )) return;
    try {
      const ids = new Set(candidates.map(g => g.garmentId));
      persist(previous.map(g => ids.has(g.garmentId) ? staffCheckBatchTag(g) : g), previous);
      setNotice(`${candidates.length}벌 태그 직원 실물 확인 완료`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '태그 실물 확인을 저장하지 못했습니다.');
    }
  };

  const current = garments[currentIndex];
  useEffect(() => { setPhotoBridgeJobNotice(''); }, [current?.garmentId]);
  let tag: ReturnType<typeof createTagData> | null = null;
  let tagError = '';
  try {
    if (current) tag = createTagData(order, current);
  } catch (cause) {
    tagError = cause instanceof Error ? cause.message : '저장 주문에서 태그 정보를 읽을 수 없습니다.';
  }
  const gate = photoEligibility(order, current?.garmentId);
  photoGateRef.current = gate.ok;
  const anyEligible = garments.some((g) => photoEligibility(order, g.garmentId).ok
    || g.tagStatus === 'printed' || !!g.photoBridgeAutoTagRequestId || !!g.photoBridgeReprintRequestId);
  if (!anyEligible) return <main className="garment-capture-blocked" data-testid="capture-blocked" style={{ padding: 32 }}>
    <h1>사진·태그 진행 불가</h1>
    <p role="alert">{gate.ok ? '진행 가능한 의류가 없습니다.' : gate.reason}</p>
    <button type="button" onClick={onBack} data-testid="button-capture-blocked-back">돌아가기</button>
  </main>;
  const guarded = (run: () => void, allowExisting = false) => () => {
    const kind = tagIssuance(order, current, false).kind;
    if (!gate.ok && !(allowExisting && (kind === 'status' || current?.tagStatus === 'printed'))) { setError(gate.reason); return; }
    run();
  };
  return <GarmentCaptureView
    order={order} garments={garments} currentIndex={currentIndex} mode={mode} hardware={hardware}
    passiveStatus={passiveStatus} passiveReady={passiveReady}
    passivePendingGarmentId={passiveRequest?.garmentId}
    passivePollEnabled={passivePollEnabled}
    verifiedPassivePhoto={verifiedPassivePhoto ? {
      photoPath: verifiedPassivePhoto.photoPath,
      photoTimestamp: verifiedPassivePhoto.photoTimestamp,
      garmentId: verifiedPassivePhoto.garmentId,
    } : undefined}
    busy={busy} error={error || tagError} notice={notice} photoBridgeTagMode={photoBridgeTagMode}
    photoBridgeTagTemplateSource={tagTemplateSource}
    photoBridgeTagTemplateNotice={tagTemplateError}
    photoBridgeTagJobNotice={photoBridgeJobNotice} tagStatusChecking={tagStatusChecking}
    settings={settings} footSwitchCode={footSwitchCode}
    bridgeUrl={bridgeUrl} photoPreviewUrl={current ? previewUrls[current.garmentId] : undefined}
    cameraVideoRef={videoRef} tagPreview={showTag && tag && tagTemplateSource !== 'unavailable'
      ? <GarmentTagPreview tag={tag} template={tagTemplate} /> : tagTemplateSource === 'unavailable'
        ? <div role="alert" data-testid="preview-garment-tag-unavailable">{tagTemplateError || '외부 태그 템플릿을 확인할 수 없습니다.'}</div>
        : null}
    onCapture={guarded(() => { void (modeRef.current === 'passive' ? armPassivePhoto() : runCapture()); })}
    onRetry={guarded(() => { void (modeRef.current === 'passive' ? armPassivePhoto() : runRetake()); })}
    onReprint={guarded(() => {
      if (photoBridgeTagMode) void (tagIssuance(order, current, false).kind === 'status' ? checkPhotoBridgeTagStatus() : requestPhotoBridgeReprint());
      else void runPrint(current?.tagStatus === 'failed' || current?.tagStatus === 'print-requested' ? 'retry' : 'reprint');
    }, true)}
    onTestPrint={() => {
      if (modeRef.current === 'passive') return;
      if (automationRef.current!.isBusy()) return;
      setBusy(true);
      operationModeRef.current = modeRef.current;
      void printerRef.current!.testPrint(crypto.randomUUID()).then((result) => {
        setNotice(result.status === 'printed' ? '테스트 인쇄 응답을 확인했습니다.' : '테스트 인쇄를 시뮬레이션했습니다. 실제 인쇄는 수행하지 않았습니다.');
        setError('');
      }).catch((cause) => setError(cause instanceof Error ? cause.message : '테스트 인쇄에 실패했습니다.'))
        .finally(() => { operationModeRef.current = null; setBusy(false); });
    }}
    onConfirmPassivePhotoIdentity={confirmPassivePhotoIdentity}
    onPrev={() => changeGarment(Math.max(0, currentIndexRef.current - 1))}
    onNext={() => changeGarment(Math.min(garments.length - 1, currentIndexRef.current + 1))}
    onSelect={changeGarment}
    onConfirmBatchTags={confirmBatchTags}
    onBack={onBack}
    onToggleTagPreview={() => setShowTag((value) => !value)}
    onFootSwitchCode={(value) => { setFootSwitchCode(value); window.localStorage.setItem(SWITCH_KEY, value); }}
    onBridgeUrl={(value) => { setBridgeUrl(value); window.localStorage.setItem(BRIDGE_KEY, value); }}
    onSettings={(value) => {
      try {
        const normalized = createTagPrinterSettings(value);
        setSettings(normalized);
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(normalized));
        setError('');
      } catch (cause) { setError(cause instanceof Error ? cause.message : '태그 설정이 올바르지 않습니다.'); }
    }}
  />;
}