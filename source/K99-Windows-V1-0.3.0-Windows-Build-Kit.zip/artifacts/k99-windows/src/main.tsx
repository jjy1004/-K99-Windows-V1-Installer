import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { installDesktopRuntime } from './desktop-runtime';
import { installKoreanInputs } from './korean-inputs';
import { ErrorBoundary } from '@/components/error-boundary';
import { warmPreferredCamera } from './camera-capture-controls';

import './index.css';

async function boot() {
try {
  installKoreanInputs();
  installDesktopRuntime();
  const {default:App} = window.location.pathname==='/equipment/customer'
    ? await import('./EquipmentCustomer') : await import('./App');
  createRoot(document.getElementById('root')!, {
  // Keeps caught errors off reportError(), which would raise the dev overlay.
  onCaughtError: (error, errorInfo) => {
    console.error(error, errorInfo.componentStack);
  },
}).render(
  <QueryClientProvider client={new QueryClient({defaultOptions:{queries:{retry:1}}})}>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </QueryClientProvider>,
);
  if(window.k99Desktop&&!['/equipment/customer','/customer'].includes(window.location.pathname))
    void warmPreferredCamera();
} catch (error) {
  const root = document.getElementById('root')!;
  root.textContent = `Windows V1을 시작하지 못했습니다. SQLite 연결과 저장 권한을 확인하세요. ${error instanceof Error ? error.message : ''}`;
}
}
void boot();
