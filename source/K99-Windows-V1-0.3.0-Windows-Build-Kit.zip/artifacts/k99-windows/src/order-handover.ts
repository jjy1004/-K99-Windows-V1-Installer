import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';
import { isGarmentComplete, listGarments } from './garment-scanner';
import { advanceOrderStage, currentOperations, nextStage } from './order-operations';
import { advanceGarmentInOrder, garmentProcessStatus } from './laundry-process';
import { paymentInfo } from './order-payment';
import { recordOrderPayment } from './order-operations';

export type HandoverScans = Record<string,string>;
export function handoverScanFingerprint(g: GarmentRecord): string {
  return JSON.stringify([g.barcodeValue,g.completedAt,g.processUpdatedAt,g.rewashCount ?? 0]);
}
export function handoverScanCount(order: ConfirmedOrder, scans: HandoverScans): number {
  return listGarments(order).filter((g) => isGarmentComplete(g) && !g.qcHoldReason &&
    scans[g.garmentId] === handoverScanFingerprint(g)).length;
}
export function handoverBlockers(order: ConfirmedOrder, scans: HandoverScans): string[] {
  const ops = currentOperations(order);
  const blockers: string[] = [];
  if (ops.cancelledAt || ops.completedAt || !['세탁완료','포장완료','배달대기'].includes(ops.stage))
    blockers.push('현재 주문은 출고할 수 없습니다. 취소·입고·완성·출고 상태를 확인해 주세요.');
  for (const g of listGarments(order)) {
    if (g.qcHoldReason ||
        !['출고 대기','반출 완료'].includes(garmentProcessStatus(order,g)))
      blockers.push(`${g.itemName} ${g.sequence}번 – 완성 검수 필요`);
    else if (!isGarmentComplete(g) || scans[g.garmentId] !== handoverScanFingerprint(g))
      blockers.push(`${g.itemName} ${g.sequence}번 – 출고 바코드 스캔 필요`);
  }
  if (!listGarments(order).length) blockers.push('출고할 의류가 없습니다.');
  return blockers;
}
/** No writes until every garment's current-cycle physical scan has been checked. */
export function finishOrderHandover(order: ConfirmedOrder, scans: HandoverScans, at = new Date()): ConfirmedOrder {
  if ((order.voucher || paymentInfo(order).type === 'POSTPAID') && paymentInfo(order).status === 'UNPAID')
    throw new Error('실제 결제 완료를 기록한 뒤 출고해 주세요.');
  const blockers = handoverBlockers(order,scans);
  if (blockers.length) throw new Error(blockers.join('\n'));
  let updated = order;
  const destination = order.choices.deliveryRequested ? '배달중' : '매장수령완료';
  for (let i = 0; i < 3 && currentOperations(updated).stage !== destination; i++) {
    const next = nextStage(updated);
    if (!next || !['포장완료','배달대기',destination].includes(next)) throw new Error('현재 상태에서는 출고할 수 없습니다.');
    updated = advanceOrderStage(updated,next,at);
  }
  if (currentOperations(updated).stage !== destination) throw new Error('출고 상태를 확인해 주세요.');
  if (destination === '매장수령완료') {
    for (const g of listGarments(updated)) {
      if (garmentProcessStatus(updated,g) === '출고 대기')
        updated = advanceGarmentInOrder(updated,g.garmentId,'handover','barcode','',at);
    }
  }
  return updated;
}

export type HandoverMethod = 'staff-confirmed' | 'barcode-scan';
export type StaffHandoverOptions = { actor?: string; scans?: HandoverScans; at?: Date; paymentConfirmed?: boolean };

/**
 * Relaxed blockers for an explicit staff-confirmed handover: the physical
 * scan checklist is not required, but unfinished laundry, QC holds,
 * cancelled and already handed-over orders still block.
 */
export function staffHandoverBlockers(order: ConfirmedOrder): string[] {
  const ops = currentOperations(order);
  const blockers: string[] = [];
  if (ops.cancelledAt) blockers.push('취소된 주문은 인도할 수 없습니다.');
  else if (ops.completedAt || ['매장수령완료','배달중','배달완료'].includes(ops.stage))
    blockers.push('이미 인도 또는 배달 출고된 주문입니다.');
  else if (!['세탁완료','포장완료','배달대기'].includes(ops.stage))
    blockers.push('세탁 완료 전 주문은 인도할 수 없습니다.');
  const garments = listGarments(order);
  for (const g of garments) {
    if (g.qcHoldReason) blockers.push(`${g.itemName} ${g.sequence}번 – 추가 확인 중`);
    else if (!['출고 대기','반출 완료'].includes(garmentProcessStatus(order,g)))
      blockers.push(`${g.itemName} ${g.sequence}번 – 세탁·검수 미완료`);
  }
  if (!garments.length) blockers.push('출고할 의류가 없습니다.');
  return blockers;
}

/** True when the order can be shown in the outgoing ready list. */
export function isReadyForHandover(order: ConfirmedOrder): boolean {
  return staffHandoverBlockers(order).length === 0;
}

/**
 * Staff-confirmed handover: no scan checklist, but the same state machine and an
 * audit entry distinguishing manual confirmation from complete physical scans.
 */
export function confirmStaffHandover(order: ConfirmedOrder, options: StaffHandoverOptions = {}): ConfirmedOrder {
  const at = options.at ?? new Date();
  const blockers = staffHandoverBlockers(order);
  if (blockers.length) throw new Error(blockers.join('\n'));
  const scans = options.scans ?? {};
  const garments = listGarments(order);
  const scanned = garments.filter((g) => scans[g.garmentId] === handoverScanFingerprint(g)).map((g) => g.garmentId);
  const method: HandoverMethod = scanned.length === garments.length ? 'barcode-scan' : 'staff-confirmed';
  let updated = order;
  if ((order.voucher || paymentInfo(order).type === 'POSTPAID') && paymentInfo(order).status === 'UNPAID') {
    if (!options.paymentConfirmed) throw new Error('결제 완료 확인 후 출고해 주세요.');
    updated = recordOrderPayment(order, '결제완료', order.voucher?paymentInfo(order).due:order.estimatedTotal, at);
  }
  const destination = order.choices.deliveryRequested ? '배달중' : '매장수령완료';
  for (let i = 0; i < 3 && currentOperations(updated).stage !== destination; i++) {
    const next = nextStage(updated);
    if (!next || !['포장완료','배달대기',destination].includes(next)) throw new Error('현재 상태에서는 출고할 수 없습니다.');
    updated = advanceOrderStage(updated,next,at);
  }
  if (currentOperations(updated).stage !== destination) throw new Error('출고 상태를 확인해 주세요.');
  if (destination === '매장수령완료') {
    for (const g of listGarments(updated)) {
      if (garmentProcessStatus(updated,g) === '출고 대기')
        updated = advanceGarmentInOrder(updated,g.garmentId,'handover',
          method === 'barcode-scan' ? 'barcode' : 'manual','',at);
    }
  }
  return { ...updated, history: [...(updated.history ?? []), { at: at.toISOString(), kind: 'operations-update',
    details: { action: 'handover-confirmed', method, delivery: destination === '배달중',
      actor: options.actor?.trim() || '매장 직원', scannedGarmentIds: scanned, garmentCount: garments.length } }] };
}
