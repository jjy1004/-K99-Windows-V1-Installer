import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';
import { isGarmentComplete, listGarments } from './garment-scanner';
import { advanceOrderStage, currentOperations, nextStage } from './order-operations';
import { advanceGarmentInOrder, garmentProcessStatus } from './laundry-process';

export type HandoverScans = Record<string,string>;
export function handoverScanFingerprint(g: GarmentRecord): string {
  return JSON.stringify([g.barcodeValue,g.completedAt,g.processUpdatedAt,g.rewashCount ?? 0]);
}
export function handoverScanCount(order: ConfirmedOrder, scans: HandoverScans): number {
  return listGarments(order).filter((g) => isGarmentComplete(g) && !g.qcHoldReason &&
    scans[g.garmentId] === handoverScanFingerprint(g)).length;
}
export function handoverBlockers(order: ConfirmedOrder, scans: HandoverScans): string[] {
  const ops = currentOperations(order);
  const blockers: string[] = [];
  if (ops.cancelledAt || ops.completedAt || !['세탁완료','포장완료','배달대기'].includes(ops.stage))
    blockers.push('현재 주문은 출고할 수 없습니다. 취소·입고·완성·출고 상태를 확인해 주세요.');
  for (const g of listGarments(order)) {
    if (g.qcHoldReason ||
        !['출고 대기','반출 완료'].includes(garmentProcessStatus(order,g)))
      blockers.push(`${g.itemName} ${g.sequence}번 – 완성 검수 필요`);
    else if (!isGarmentComplete(g) || scans[g.garmentId] !== handoverScanFingerprint(g))
      blockers.push(`${g.itemName} ${g.sequence}번 – 출고 바코드 스캔 필요`);
  }
  if (!listGarments(order).length) blockers.push('출고할 의류가 없습니다.');
  return blockers;
}
/** No writes until every garment's current-cycle physical scan has been checked. */
export function finishOrderHandover(order: ConfirmedOrder, scans: HandoverScans, at = new Date()): ConfirmedOrder {
  const blockers = handoverBlockers(order,scans);
  if (blockers.length) throw new Error(blockers.join('\n'));
  let updated = order;
  const destination = order.choices.deliveryRequested ? '배달중' : '매장수령완료';
  for (let i = 0; i < 3 && currentOperations(updated).stage !== destination; i++) {
    const next = nextStage(updated);
    if (!next || !['포장완료','배달대기',destination].includes(next)) throw new Error('현재 상태에서는 출고할 수 없습니다.');
    updated = advanceOrderStage(updated,next,at);
  }
  if (currentOperations(updated).stage !== destination) throw new Error('출고 상태를 확인해 주세요.');
  if (destination === '매장수령완료') {
    for (const g of listGarments(updated)) {
      if (garmentProcessStatus(updated,g) === '출고 대기')
        updated = advanceGarmentInOrder(updated,g.garmentId,'handover','barcode','',at);
    }
  }
  return updated;
}
