import { ArrowRight, MonitorUp } from 'lucide-react';

type Props = {
  onConfirm: () => void;
  onShowCustomer?: () => void;
  customerFacing?: boolean;
};

export function SneakerServiceIntro({ onConfirm, onShowCustomer, customerFacing = false }: Props) {
  return (
    <main className={`sneaker-intro-screen${customerFacing ? ' customer-facing' : ''}`} data-testid="sneaker-service-intro">
      <div className="sneaker-intro-content">
        <div className="sneaker-intro-top">
          <span className="sneaker-intro-brand">K99 품격세탁소 · 과천점</span>
          <span className="sneaker-intro-tag">SNEAKER CARE / SERVICE GUIDE</span>
        </div>
        <header className="sneaker-intro-header">
          <span>접수 전 서비스 안내</span>
          <h1>운동화 세탁 서비스 안내</h1>
          <p>원하시는 세탁 서비스를 확인한 뒤 운동화 수량을 접수해 주세요.</p>
        </header>
        <div className="sneaker-intro-options">
          <article className="sneaker-intro-option">
            <div className="sneaker-option-heading">
              <div><span>01 / PARTNER CARE</span><h2>일반 운동화 세탁</h2></div>
              <strong>9,000원 <small>/ 1켤레</small></strong>
            </div>
            <p>일반 운동화는 전문 협력 세탁소에서 세탁합니다.</p>
          </article>
          <article className="sneaker-intro-option premium">
            <div className="sneaker-option-heading">
              <div><span>02 / K99 DIRECT CARE</span><h2>프리미엄 운동화 세탁</h2></div>
              <strong>18,000원 <small>/ 1켤레</small></strong>
            </div>
            <p>프리미엄 운동화는 K99 품격세탁소 매장에서 교수님이 직접 운동화의 소재, 오염, 황변, 이염 및 손상 상태를 정밀 검수한 후 직접 세탁합니다.</p>
            <p>프리미엄 운동화 세탁에는 발수 가공이 포함됩니다.<br />
              흰색 운동화 끈은 새 끈으로 교환해 드리며, 깔창도 새 깔창으로 교환해 드립니다.</p>
          </article>
        </div>
        <p className="sneaker-intro-note">운동화의 소재, 오염 정도, 황변, 이염, 접착 상태 및 손상 정도에 따라 추가 작업이 필요한 경우 세탁 전 고객님께 안내드립니다.</p>
        <div className="sneaker-intro-actions">
          {onShowCustomer && (
            <button type="button" className="sneaker-intro-customer" data-testid="button-show-sneaker-info-customer" onClick={onShowCustomer}>
              <MonitorUp aria-hidden="true" /> 고객 화면에서 보기
            </button>
          )}
          <button type="button" className="sneaker-intro-confirm" data-testid="button-confirm-sneaker-info" onClick={onConfirm}>
            확인 후 운동화 접수 <ArrowRight aria-hidden="true" />
          </button>
        </div>
      </div>
    </main>
  );
}