import type {ConfirmedOrder} from './order-record';
import {isReadyForHandover} from './order-handover';
import {isDeletedOrder} from './order-deletion-policy';

export const HANDOVER_AGE_BANDS=[
  {id:'31-90',label:'1개월 ~ 3개월',min:31,max:90},
  {id:'91-180',label:'3개월 ~ 6개월',min:91,max:180},
  {id:'181-365',label:'6개월 ~ 1년',min:181,max:365},
  {id:'366-730',label:'1년 ~ 2년',min:366,max:730},
] as const;
export type HandoverAgeBand=typeof HANDOVER_AGE_BANDS[number]['id'];
export type HandoverAgeSelection='recent'|HandoverAgeBand;
export type HandoverAgeGroups=Record<HandoverAgeSelection,ConfirmedOrder[]>&{
  over730:ConfirmedOrder[];invalidDate:ConfirmedOrder[];
};

const calendarDay=(date:Date)=>{
  const d=new Date(0);d.setUTCFullYear(date.getFullYear(),date.getMonth(),date.getDate());d.setUTCHours(0,0,0,0);
  return d.getTime()/86400000;
};
function intakeDay(value:string):number|null{
  if(typeof value!=='string')return null;
  const raw=value.trim(),parts=/^(\d{4})(-?)(\d{2})\2(\d{2})(?=$|T|\s)/.exec(raw);
  if(!parts)return null;
  const y=Number(parts[1]),m=Number(parts[3]),d=Number(parts[4]),check=new Date(0);
  check.setUTCFullYear(y,m-1,d);check.setUTCHours(0,0,0,0);
  if(check.getUTCFullYear()!==y||check.getUTCMonth()!==m-1||check.getUTCDate()!==d)return null;
  if(/^\d{4}-?\d{2}-?\d{2}$/.test(raw))return check.getTime()/86400000;
  const date=new Date(raw);
  return Number.isFinite(date.getTime())?calendarDay(date):null;
}
/** 현지 달력 날짜로 계산한다. 시각·서머타임 때문에 30/31일 경계가 흔들리지 않는다. */
export function handoverAgeDays(intakeAt:string,today=new Date()):number|null{
  const day=intakeDay(intakeAt);
  if(day===null||!Number.isFinite(today.getTime()))return null;
  return calendarDay(today)-day;
}
export function handoverIntakeDate(intakeAt:string):string{
  const day=intakeDay(intakeAt);
  return day===null?'날짜 확인 필요':new Date(day*86400000).toISOString().slice(0,10);
}
export function partitionHandoverOrders(orders:readonly ConfirmedOrder[],today=new Date()):HandoverAgeGroups{
  const groups:HandoverAgeGroups={recent:[],'31-90':[],'91-180':[],'181-365':[],'366-730':[],over730:[],invalidDate:[]};
  for(const order of orders){
    if(isDeletedOrder(order)||!isReadyForHandover(order))continue;
    const age=handoverAgeDays(order.intakeAt,today);
    if(age===null||age<0){groups.invalidDate.push(order);continue;}
    if(age<=30){groups.recent.push(order);continue;}
    const band=HANDOVER_AGE_BANDS.find(b=>age>=b.min&&age<=b.max);
    if(band)groups[band.id].push(order);else groups.over730.push(order);
  }
  return groups;
}
