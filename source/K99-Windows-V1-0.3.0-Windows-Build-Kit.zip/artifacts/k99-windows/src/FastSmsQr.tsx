import {useEffect, useRef} from 'react';
import bwipjs from 'bwip-js/browser';

/** Integer-sized modules prevent the browser resampling the black/white grid. */
export function smsQrPixels(text: string) {
  const options = {bcid: 'qrcode', text, eclevel: 'L'};
  const matrix = bwipjs.raw(options)[0];
  if (!matrix || !('pixs' in matrix) || matrix.pixx !== matrix.pixy || !matrix.pixx)
    throw new Error('문자 QR을 만들지 못했습니다.');
  const scale = Math.ceil(320 / matrix.pixx);
  const quiet = Math.max(24, scale * 4);
  return {matrix, scale, quiet, size: matrix.pixx * scale + quiet * 2};
}

export function FastSmsQr({uri, onError}: {uri: string; onError: (message: string) => void}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const errorRef = useRef(onError); errorRef.current = onError;
  useEffect(() => {
    try {
      const canvas = ref.current;
      if (!canvas) return;
      const {matrix, scale, quiet, size} = smsQrPixels(uri);
      canvas.width = canvas.height = size;
      canvas.dataset.modules = String(matrix.pixx);
      canvas.dataset.modulePixels = String(scale);
      canvas.dataset.quietPixels = String(quiet);
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('QR 표시 화면을 열지 못했습니다.');
      ctx.imageSmoothingEnabled = false;
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, size, size);
      ctx.fillStyle = '#000000';
      for (let y = 0; y < matrix.pixy; y++) for (let x = 0; x < matrix.pixx; x++)
        if (matrix.pixs[y * matrix.pixx + x]) ctx.fillRect(quiet + x * scale, quiet + y * scale, scale, scale);
    } catch (error) { errorRef.current(error instanceof Error ? error.message : '문자 QR 표시 실패'); }
  }, [uri]);
  return <canvas ref={ref} role="img" aria-label="80자 이내 요약 문자 QR 코드"
    style={{display: 'block', width: 'auto', height: 'auto', maxWidth: 'none', background: '#fff', imageRendering: 'pixelated'}}/>;
}
