import { createGarmentRecords, type GarmentRecord, type LaundryProcessStatus } from './garment-record.ts';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record.ts';
import { currentOperations } from './order-operations.ts';
import { GARMENT_READY_STATUS, ORDER_READY_STATUS } from './garment-scanner.ts';
import { normalGarmentApproved } from './normal-inspection-policy';

export const RECLEANING_REASONS = [
  '얼룩 잔존', '세탁 미흡', '냄새 잔존', '형태/주름 문제', '고객 요청', '기타',
] as const;
export type RecleaningReason = typeof RECLEANING_REASONS[number];
export type LaundryAction = 'start' | 'complete' | 'inspect' | 'qc-pass' |
  'qc-rewash' | 'qc-hold' | 'resume-qc' | 'handover' | 'handover-rewash';
export type LaundrySource = 'manual' | 'barcode' | 'simulation';

export function garmentProcessStatus(order: ConfirmedOrder, garment: GarmentRecord): LaundryProcessStatus {
  if (garment.processStatus) return garment.processStatus;
  if (normalGarmentApproved(order, garment)) return '세탁 대기';
  if (garment.completionStatus === 'complete' || garment.status === GARMENT_READY_STATUS) return '출고 대기';
  if (order.inspection && order.status === '세탁 진행 승인' &&
      ['매장입고', '세탁중', '세탁완료'].includes(currentOperations(order).stage)) return '세탁 대기';
  if (order.inspection) return '전문검수 완료';
  if (['simulated', 'printed'].includes(garment.tagStatus)) return '촬영/태그 완료';
  return '접수 완료';
}

export function laundryProgress(order: ConfirmedOrder, garments: GarmentRecord[]) {
  const states = garments.map((garment) => garmentProcessStatus(order, garment));
  return {
    total: states.length,
    completed: states.filter((state) => ['세탁 완료', '완성 검수', '출고 대기', '반출 완료'].includes(state)).length,
    inProgress: states.filter((state) => state === '세탁 중').length,
    readyForHandover: states.filter((state) => state === '출고 대기').length,
  };
}

export function canRecleanReadyGarment(order: ConfirmedOrder): boolean {
  const operations = currentOperations(order);
  return ['세탁 진행 승인', ORDER_READY_STATUS].includes(order.status) &&
    !operations.cancelledAt && !operations.completedAt &&
    !['매장수령완료', '배달완료'].includes(operations.stage);
}

function checkedGarments(order: ConfirmedOrder): GarmentRecord[] {
  const garments = order.garments ?? createGarmentRecords(order);
  const expected = order.items.reduce((sum, item) => sum + item.quantity, 0);
  if (garments.length !== expected || new Set(garments.map((item) => item.garmentId)).size !== expected ||
      garments.some((item) => item.orderId !== order.id || item.barcodeValue !== item.garmentId))
    throw new Error('저장된 의류 수량과 의류 ID가 일치하지 않습니다. 주문 기록을 확인해 주세요.');
  return garments;
}

export function loadLaundryOrder(orderId: string, _options: { allowIntakeOverview?: boolean } = {}): ConfirmedOrder {
  const order = readConfirmedOrders().find((item) => item.id === orderId);
  if (!order) throw new Error('저장된 주문을 찾을 수 없습니다.');
  // All entry points read the original record. Authorization belongs to the
  // actual transition below, not an optional flag that a caller can forget.
  const garments = checkedGarments(order);
  if (order.garments) return order;
  const saved = { ...order, garments };
  updateSavedOrder(saved, order);
  return saved;
}

export function findLaundryGarment(barcode: string): { order: ConfirmedOrder; garment: GarmentRecord } | null {
  const value = barcode.trim();
  if (!value || value.length > 160 || /[\x00-\x1f\x7f]/.test(value))
    throw new Error('의류 바코드를 확인해 주세요.');
  const order = readConfirmedOrders().find((item) =>
    (item.garments ?? createGarmentRecords(item)).some((garment) => garment.garmentId === value));
  if (!order) return null;
  const saved = loadLaundryOrder(order.id);
  const garment = checkedGarments(saved).find((item) => item.garmentId === value)!;
  return { order: saved, garment };
}

const steps: Partial<Record<LaundryAction, [LaundryProcessStatus, LaundryProcessStatus]>> = {
  start: ['세탁 대기', '세탁 중'],
  complete: ['세탁 중', '세탁 완료'],
  inspect: ['세탁 완료', '완성 검수'],
  'qc-pass': ['완성 검수', '출고 대기'],
  'qc-rewash': ['완성 검수', '세탁 대기'],
  'qc-hold': ['완성 검수', '완성 검수'],
  'resume-qc': ['완성 검수', '완성 검수'],
  handover: ['출고 대기', '반출 완료'],
  'handover-rewash': ['출고 대기', '세탁 대기'],
};

export function advanceGarmentLaundry(orderId: string, garmentId: string, action: LaundryAction,
  source: LaundrySource = 'manual', reason = '', at = new Date(), detail = ''): ConfirmedOrder {
  const order = loadLaundryOrder(orderId);
  const updated = advanceGarmentInOrder(order, garmentId, action, source, reason, at, detail);
  updateSavedOrder(updated, order);
  return updated;
}

/** Same guards/history as individual work, without intermediate writes in a batch. */
export function advanceGarmentInOrder(order: ConfirmedOrder, garmentId: string, action: LaundryAction,
  source: LaundrySource = 'manual', reason = '', at = new Date(), detail = ''): ConfirmedOrder {
  if (!['manual', 'barcode', 'simulation'].includes(source)) throw new Error('작업 출처를 확인해 주세요.');
  if (action === 'handover-rewash' && source !== 'manual') throw new Error('재세탁 등록은 직원이 직접 확인해 주세요.');
  const garments = checkedGarments(order);
  const garment = garments.find((item) => item.garmentId === garmentId);
  if (!garment) throw new Error('이 주문에서 해당 의류를 찾을 수 없습니다.');
  const transition = steps[action];
  if (!transition) throw new Error('허용되지 않은 세탁 작업입니다.');
  const previous = garmentProcessStatus(order, garment);
  if (previous !== transition[0]) throw new Error(`현재 ${previous} 상태에서는 해당 작업을 할 수 없습니다.`);
  const stage = currentOperations(order);
  if (stage.cancelledAt) throw new Error('취소된 주문은 작업할 수 없습니다.');
  if (action === 'handover-rewash') {
    if (!canRecleanReadyGarment(order))
      throw new Error('실제 반출 전이며 세탁 완료 상태인 의류만 재세탁으로 돌릴 수 있습니다.');
  } else if (action === 'handover') {
    if (!stage.completedAt || !['매장수령완료', '배달완료'].includes(stage.stage))
      throw new Error('반출 완료는 운영 관리에서 실제 수령 또는 배달 완료를 기록한 뒤 처리해 주세요.');
  } else if (stage.completedAt || !['매장입고', '세탁중', '세탁완료'].includes(stage.stage))
    throw new Error('매장 입고 전이거나 인도된 주문은 세탁 작업을 할 수 없습니다.');
  if (!['handover', 'handover-rewash'].includes(action) && order.status !== '세탁 진행 승인' &&
      !normalGarmentApproved(order, garment))
    throw new Error('이미 완료된 주문은 다시 세탁 단계로 이동할 수 없습니다.');
  const explanation = reason.trim();
  const detailedReason = detail.trim();
  if (['qc-rewash', 'qc-hold'].includes(action) && !explanation)
    throw new Error('재세탁 또는 추가 확인 사유를 입력해 주세요.');
  if (action === 'handover-rewash' &&
      !RECLEANING_REASONS.includes(explanation as RecleaningReason))
    throw new Error('재세탁 사유를 선택해 주세요.');
  if (action === 'handover-rewash' && detailedReason.length > 500)
    throw new Error('재세탁 상세 사유는 500자 이내로 입력해 주세요.');
  if (action === 'resume-qc' && !garment.qcHoldReason)
    throw new Error('추가 확인 중인 의류가 아닙니다.');
  if (garment.qcHoldReason && !['resume-qc', 'qc-hold'].includes(action))
    throw new Error('추가 확인을 해제한 뒤 작업해 주세요.');
  if (action === 'qc-hold' && garment.qcHoldReason)
    throw new Error('이미 추가 확인 중입니다.');
  const timestamp = at.toISOString();
  const newStatus = transition[1];
  const revised: GarmentRecord = { ...garment, processStatus: newStatus, processUpdatedAt: timestamp,
    ...(action === 'start' ? { inspectionStatus: 'complete' as const, cleaningStatus: 'in-progress' as const } : {}),
    ...(action === 'complete' ? { cleaningStatus: 'complete' as const } : {}),
    ...(action === 'qc-rewash' ? { cleaningStatus: 'pending' as const, completionStatus: 'pending' as const,
      rewashCount: (garment.rewashCount ?? 0) + 1 } : {}),
    ...(action === 'handover-rewash' ? {
      cleaningStatus: 'pending' as const, completionStatus: 'pending' as const,
      handoverStatus: 'pending' as const, status: undefined, completedAt: undefined,
      scannedAt: undefined, lastScannedAt: undefined, completionMethod: undefined,
      rewashCount: (garment.rewashCount ?? 0) + 1,
    } : {}),
    ...(action === 'inspect' ? { completionStatus: 'in-progress' as const } : {}),
    ...(action === 'handover' ? { handoverStatus: 'complete' as const } : {}),
    ...(action === 'qc-hold' ? { qcHoldReason: explanation } :
      action === 'resume-qc' || action === 'qc-rewash' ? { qcHoldReason: undefined } : {}),
    // QC makes the garment eligible for the ready scan; it is not the scan itself.
    ...(action === 'qc-pass' ? { completionStatus: 'in-progress' as const } : {}),
    auditEvents: [...(garment.auditEvents ?? []), {
      at: timestamp, type: 'laundry-process', status: newStatus, orderId: order.id, garmentId,
      previousStatus: previous, newStatus, source,
      ...(action === 'handover-rewash' ? {
        action: '재세탁 등록', reason: explanation, detail: detailedReason,
        rewashCycle: (garment.rewashCount ?? 0) + 1, details: '재세탁 등록',
      } : { details: `${action}${explanation ? ` · ${explanation}` : ''}` }),
    }],
  };
  const updatedGarments = garments.map((item) => item.garmentId === garmentId ? revised : item);
  let updated: ConfirmedOrder = { ...order, garments: updatedGarments };
  if (action === 'handover-rewash' && order.status === ORDER_READY_STATUS) {
    updated = { ...updated, status: '세탁 진행 승인', orderCompletedAt: undefined,
      preCompletionStage: undefined,
      completionMessage: order.completionMessage
        ? { ...order.completionMessage, status: '취소됨', actuallySent: false } : undefined,
      operations: { ...stage, stage: '세탁중', updatedAt: timestamp },
      history: [...(order.history ?? []), {
        at: timestamp, kind: 'operations-update',
        details: { action: 'recleaning-started', previous: stage.stage, revised: '세탁중',
          garmentId, reason: explanation, detail: detailedReason },
      }],
    };
  }
  return updated;
}