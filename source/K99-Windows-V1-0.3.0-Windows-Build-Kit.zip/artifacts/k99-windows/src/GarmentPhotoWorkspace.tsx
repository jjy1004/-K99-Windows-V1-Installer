import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import './garment-photo-workspace.css';
import {
  DEFAULT_CARE_PROCESSES, addActualCareProcess, addGarmentPhoto, createAnnotationHistory,
  eraseAnnotation, generateCareSummary, moveAnnotation, pushAnnotationSnapshot, redoAnnotation,
  saveAnnotation, selectPhoto, undoAnnotation, updateCareSummary, updateCompletionComment,
  type AnnotationHistory,
} from './garment-care';
import type { GarmentAnnotationShape, GarmentPhotoMetadata, GarmentRecord } from './garment-record';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { useLocation } from 'wouter';
import CareResultCard from './CareResultCard';
import { getCustomerSafeResult } from './garment-care';
import {
  approveCustomerNotification, createCustomerNotification, prepareCustomerNotification,
} from './notification-workflow';
import { listRecentPhotos, loadPhotoPreview, photoSourceMode, verifiedStorePhotoBridge, type PhotoSourceItem } from './photo-source';
import { activePhotosOf, assertPhotoNotLinkedToAnotherGarment, linkManualPhoto, unlinkManualPhoto } from './manual-photo-link';

type Tool = 'pen' | 'circle' | 'rectangle' | 'arrow' | 'text' | 'eraser' | 'select';
type Point = { x: number; y: number };
type CardPreviews = {
  before: string | null;
  after: string | null;
  beforeStatus: 'pending' | 'available' | 'missing' | 'failed';
  afterStatus: 'pending' | 'available' | 'missing' | 'failed';
  beforeSimulated: boolean;
  afterSimulated: boolean;
};
const pct = (value: number) => `${value * 100}%`;
const imageSpace = { width: 1000, height: 700 };
const previewCache = new Map<string, Promise<string>>();

function cachedPreview(id: string, origin: 'bridge' | 'simulation'): Promise<string> {
  const key = `${origin}:${id}`;
  let pending = previewCache.get(key);
  if (!pending) {
    pending = loadPhotoPreview(id, origin).catch((cause: unknown) => {
      previewCache.delete(key);
      throw cause;
    });
    previewCache.set(key, pending);
  }
  return pending;
}

function PhotoImage({ id, origin, className = '', onReady }: {
  id?: string;
  origin: GarmentPhotoMetadata['origin'];
  className?: string;
  onReady?: (width: number, height: number) => void;
}) {
  const [src, setSrc] = useState('');
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let alive = true;
    setSrc('');
    setError('');
    if (!id || origin === 'legacy') return;
    cachedPreview(id, origin).then((url) => { if (alive) setSrc(url); })
      .catch((cause: unknown) => { if (alive) setError(cause instanceof Error ? cause.message : '미리보기를 읽지 못했습니다.'); });
    return () => { alive = false; };
  }, [id, origin, retry]);
  return <div className={`gpw-photo-image ${className}`}>
    {src ? <img src={src} alt={origin === 'simulation' ? 'SAMPLE 예시 사진, 실제 의류 사진 아님' : '연결된 원본 사진 미리보기'}
      onLoad={(event) => onReady?.(event.currentTarget.naturalWidth, event.currentTarget.naturalHeight)} /> :
      <span className="gpw-image-fallback">{error || (id && origin !== 'legacy' ? '미리보기 읽는 중…' : '미리보기 없는 이전 기록')}</span>}
    {error && !className.includes('gallery') && !className.includes('stage') &&
      <button type="button" onClick={() => setRetry((value) => value + 1)}>다시 시도</button>}
    {origin === 'simulation' && <span className="gpw-sample-stamp">SAMPLE</span>}
  </div>;
}

function latestShapes(garment: GarmentRecord, requestId?: string): GarmentAnnotationShape[] {
  return garment.annotationRevisions?.filter((revision) => revision.photoRequestId === requestId).at(-1)?.shapes.map((shape) =>
    shape.type === 'pen' ? { ...shape, points: shape.points.map((point) => ({ ...point })) } : { ...shape }) ?? [];
}

function PhotoMetadata({ photo }: { photo: GarmentPhotoMetadata }) {
  return <div className="gpw-photo-meta">
    <span>{photo.role === 'intake' ? '접수 원본' : '완성 사진'}</span>
    <strong>{new Date(photo.timestamp).toLocaleString('ko-KR')}</strong>
    <small>{photo.origin === 'simulation' || photo.status === 'simulated' ? '시뮬레이션 저장 · 실제 사진 파일 아님' : '사진 메타데이터 연결'}</small>
    {photo.path && <code hidden>{photo.path}</code>}
  </div>;
}

function AnnotationLayer({ shapes, hidden, selectedId, onShapeClick }: {
  shapes: readonly GarmentAnnotationShape[];
  hidden: boolean;
  selectedId?: string;
  onShapeClick?: (id: string) => void;
}) {
  if (hidden) return null;
  return <svg className="gpw-annotation-layer" viewBox="0 0 1000 700" preserveAspectRatio="none" aria-label="사진 주석 미리보기">
    {shapes.map((shape) => {
      const common = {
        onClick: () => onShapeClick?.(shape.id),
        'data-shape-id': shape.id,
        className: shape.id === selectedId ? 'gpw-mark gpw-mark--selected' : 'gpw-mark',
      };
      if (shape.type === 'pen') return <polyline key={shape.id} {...common} points={shape.points.map((point) =>
        `${point.x * imageSpace.width},${point.y * imageSpace.height}`).join(' ')} />;
      if (shape.type === 'text') return <text key={shape.id} {...common} x={shape.x * imageSpace.width}
        y={shape.y * imageSpace.height} className={`${common.className} gpw-mark-text`}>{shape.text}</text>;
      if (shape.type === 'circle') return <ellipse key={shape.id} {...common} cx={(shape.x + shape.width / 2) * imageSpace.width}
        cy={(shape.y + shape.height / 2) * imageSpace.height} rx={shape.width * imageSpace.width / 2}
        ry={shape.height * imageSpace.height / 2} />;
      if (shape.type === 'arrow') return <line key={shape.id} {...common} x1={shape.x * imageSpace.width}
        y1={shape.y * imageSpace.height} x2={(shape.x + shape.width) * imageSpace.width}
        y2={(shape.y + shape.height) * imageSpace.height} markerEnd="url(#gpw-arrow)" />;
      return <rect key={shape.id} {...common} x={shape.x * imageSpace.width} y={shape.y * imageSpace.height}
        width={shape.width * imageSpace.width} height={shape.height * imageSpace.height} />;
    })}
    <defs><marker id="gpw-arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="currentColor" />
    </marker></defs>
  </svg>;
}

export function GarmentPhotoWorkspace({ orderId, initialGarmentId, selectedGarmentId, onSelectionChange, onOrderChange, onBack, onShowCustomer }: {
  orderId: string;
  initialGarmentId?: string;
  selectedGarmentId?: string;
  onSelectionChange?: (garmentId: string) => void;
  onOrderChange?: () => void;
  onBack: () => void;
  onShowCustomer: (orderId: string, garmentId: string) => void;
}) {
  const [, navigate] = useLocation();
  const [order, setOrder] = useState<ConfirmedOrder | null>(null);
  const orderRef = useRef<ConfirmedOrder | null>(null);
  const [garmentId, setGarmentId] = useState('');
  const [lookup, setLookup] = useState(initialGarmentId ?? '');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [history, setHistory] = useState<AnnotationHistory>(() => createAnnotationHistory());
  const [tool, setTool] = useState<Tool>('pen');
  const [showAnnotations, setShowAnnotations] = useState(true);
  const [originalView, setOriginalView] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [comment, setComment] = useState('');
  const [summary, setSummary] = useState('');
  const [process, setProcess] = useState<string>(DEFAULT_CARE_PROCESSES[0]);
  const [source, setSource] = useState('직원 기록');
  const [staffNote, setStaffNote] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const [resultOpen, setResultOpen] = useState(false);
  const [cardPreviews, setCardPreviews] = useState<CardPreviews | undefined>();
  const [sourceMode, setSourceMode] = useState<'bridge' | 'simulation'>(photoSourceMode);
  const [recentPhotos, setRecentPhotos] = useState<PhotoSourceItem[]>([]);
  const [galleryLoading, setGalleryLoading] = useState(true);
  const [galleryError, setGalleryError] = useState('');
  const [selectedPhotoId, setSelectedPhotoId] = useState('');
  const [identityConfirmed, setIdentityConfirmed] = useState(false);
  const [previewViewed, setPreviewViewed] = useState(false);
  const [linking, setLinking] = useState(false);
  const linkInProgress = useRef(false);
  const currentSelection = useRef({ photoId: '', garmentId: '' });
  const [manualRole, setManualRole] = useState<'intake' | 'completion'>('intake');
  const [beforeAspect, setBeforeAspect] = useState('10 / 7');
  const pointer = useRef<{ start: Point; last: Point; shapeId?: string } | null>(null);

  async function refreshGallery() {
    const mode = photoSourceMode();
    setSourceMode(mode);
    setGalleryLoading(true);
    setGalleryError('');
    setRecentPhotos([]);
    setSelectedPhotoId('');
    setIdentityConfirmed(false);
    setPreviewViewed(false);
    try {
      const items = await listRecentPhotos();
      if (mode !== photoSourceMode() || items.some((item) => item.origin !== mode))
        throw new Error('사진 도우미 연결 상태가 바뀌었습니다. 목록을 다시 불러와 주세요.');
      setRecentPhotos(items);
    } catch (cause) {
      setGalleryError(cause instanceof Error ? cause.message : '최근 사진을 불러오지 못했습니다.');
    } finally { setGalleryLoading(false); }
  }
  useEffect(() => { void refreshGallery(); }, []);

  useEffect(() => {
    try {
      const saved = readConfirmedOrders().find((item) => item.id === orderId);
      if (!saved) throw new Error('해당 주문번호의 저장된 접수 내역을 찾지 못했습니다.');
      orderRef.current = saved;
      setOrder(saved);
      const initial = initialGarmentId ? saved.garments?.find((item) => item.garmentId === initialGarmentId) : undefined;
      if (initialGarmentId && !initial) setError('요청한 의류 ID가 저장 주문에 없습니다. 다른 의류를 자동 선택하지 않았습니다.');
      const start = initialGarmentId ? initial?.garmentId ?? '' : saved.garments?.[0]?.garmentId ?? '';
      setGarmentId(start);
      setLookup(start);
    } catch (cause) { setError(cause instanceof Error ? cause.message : '저장 주문을 읽지 못했습니다.'); }
  }, [orderId, initialGarmentId]);

  useEffect(() => {
    if (selectedGarmentId && order?.garments?.some((item) => item.garmentId === selectedGarmentId)) {
      setGarmentId(selectedGarmentId);
      setLookup(selectedGarmentId);
    }
  }, [selectedGarmentId, order?.id]);
  useEffect(() => {
    if (garmentId) onSelectionChange?.(garmentId);
  }, [garmentId, onSelectionChange]);

  const garment = order?.garments?.find((item) => item.garmentId === garmentId);
  const photos = useMemo(() => garment ? activePhotosOf(garment) : [], [garment]);
  const beforePhotos = photos.filter((photo) => photo.role === 'intake');
  const afterPhotos = photos.filter((photo) => photo.role === 'completion');
  const selectedSource = recentPhotos.find((item) => item.id === selectedPhotoId);
  currentSelection.current = { photoId: selectedPhotoId, garmentId };
  const deliveryNotice = order?.customerNotifications?.filter((item) =>
    item.garmentId === garmentId && item.type === '세탁 완료').at(-1);
  const representative = beforePhotos.find((photo) => photo.requestId === garment?.representativeBeforePhotoId)
    ?? beforePhotos[0];

  useEffect(() => {
    if (!resultOpen || !garment) return;
    let alive = true;
    const active = activePhotosOf(garment);
    const before = active.find((photo) => photo.role === 'intake' &&
      photo.requestId === garment.representativeBeforePhotoId)
      ?? active.find((photo) => photo.role === 'intake');
    const after = active.filter((photo) => photo.role === 'completion')
      .reduce<GarmentPhotoMetadata | undefined>((latest, photo) =>
        !latest || Date.parse(photo.timestamp) >= Date.parse(latest.timestamp) ? photo : latest, undefined);
    setCardPreviews({
      before: null, after: null,
      beforeStatus: before ? 'pending' : 'missing',
      afterStatus: after ? 'pending' : 'missing',
      beforeSimulated: before?.origin === 'simulation',
      afterSimulated: after?.origin === 'simulation',
    });
    const resolve = async (photo?: GarmentPhotoMetadata) => {
      if (!photo) return { url: null, status: 'missing' as const };
      if (!photo.sourcePhotoId || (photo.origin !== 'bridge' && photo.origin !== 'simulation'))
        return { url: null, status: 'failed' as const };
      try {
        return { url: await loadPhotoPreview(photo.sourcePhotoId, photo.origin), status: 'available' as const };
      } catch {
        return { url: null, status: 'failed' as const };
      }
    };
    void Promise.all([resolve(before), resolve(after)]).then(([beforeResult, afterResult]) => {
      if (!alive) return;
      setCardPreviews({
        before: beforeResult.url, after: afterResult.url,
        beforeStatus: beforeResult.status, afterStatus: afterResult.status,
        beforeSimulated: before?.origin === 'simulation',
        afterSimulated: after?.origin === 'simulation',
      });
    });
    return () => { alive = false; };
  }, [resultOpen, garment]);

  useEffect(() => {
    setHistory(createAnnotationHistory(garment ? latestShapes(garment, representative?.requestId) : []));
    setComment(garment?.completionComment ?? '');
    setSummary(garment?.careSummary?.editedText ?? garment?.careSummary?.generatedText ?? (garment ? generateCareSummary(garment) : ''));
    setSelectedId('');
  }, [garment?.garmentId, representative?.requestId]);
  useEffect(() => {
    setSelectedPhotoId('');
    setIdentityConfirmed(false);
    setPreviewViewed(false);
  }, [garmentId]);
  useEffect(() => { setBeforeAspect('10 / 7'); }, [representative?.requestId]);

  function persist(nextGarment: GarmentRecord, message: string) {
    const current = orderRef.current;
    if (!current) return;
    try {
      const currentGarments = current.garments ?? [];
      const revised = { ...current, garments: currentGarments.map((item) =>
        item.garmentId === nextGarment.garmentId ? nextGarment : item) };
      updateSavedOrder(revised, current);
      orderRef.current = revised;
      setOrder(revised);
      onOrderChange?.();
      setError('');
      setNotice(message);
    } catch (cause) { setError(cause instanceof Error ? cause.message : '변경 사항을 저장하지 못했습니다.'); }
  }
  function persistOrder(revised: ConfirmedOrder, message: string) {
    const current = orderRef.current;
    if (!current) return;
    try {
      updateSavedOrder(revised, current);
      orderRef.current = revised;
      setOrder(revised);
      onOrderChange?.();
      setError('');
      setNotice(message);
    } catch (cause) { setError(cause instanceof Error ? cause.message : '주문 변경 사항을 저장하지 못했습니다.'); }
  }

  function freshGarment(): { savedOrders: ConfirmedOrder[]; current: ConfirmedOrder; target: GarmentRecord } {
    const savedOrders = readConfirmedOrders();
    const current = savedOrders.find((item) => item.id === orderId);
    const target = current?.garments?.find((item) => item.garmentId === garmentId);
    if (!current || !target) throw new Error('저장된 주문의 의류 ID를 찾을 수 없습니다. 다시 확인해 주세요.');
    return { savedOrders, current, target };
  }
  function saveFreshPhotoChange(current: ConfirmedOrder, target: GarmentRecord, message: string) {
    const revised = { ...current, garments: (current.garments ?? []).map((item) =>
      item.garmentId === target.garmentId ? target : item) };
    updateSavedOrder(revised, current);
    orderRef.current = revised;
    setOrder(revised);
    onOrderChange?.();
    setError('');
    setNotice(message);
  }
  async function manualLink() {
    if (linkInProgress.current) return;
    if (!selectedSource || !garment || !previewViewed || !identityConfirmed) {
      setError('사진 미리보기를 확인하고 선택한 의류와 동일한지 명시적으로 확인해 주세요.');
      return;
    }
    try {
      if (selectedSource.origin === 'bridge' && !verifiedStorePhotoBridge())
        throw new Error('PENDING STORE-PC LOCAL BRIDGE TEST · 매장 PC에서 도우미 검증이 끝나기 전에는 실제 사진 연결을 저장하지 않습니다.');
      if (photoSourceMode() !== sourceMode || selectedSource.origin !== sourceMode)
        throw new Error('사진 도우미 연결 상태가 바뀌었습니다. 목록을 새로고침해 주세요.');
      if (selectedSource.origin === 'bridge' && !selectedSource.sourcePath)
        throw new Error('실제 사진의 원본 경로가 없습니다. 연결하지 않았습니다.');
      if (manualRole === 'completion' &&
        !['세탁 완료', '완성 검수', '출고 대기', '반출 완료'].includes(garment.processStatus ?? ''))
        throw new Error('완성 사진은 세탁 완료 이후에만 연결할 수 있습니다.');
      linkInProgress.current = true;
      setLinking(true);
      // The gallery preview can be cached: read the immutable ID again before saving.
      if (selectedSource.origin === 'bridge') await loadPhotoPreview(selectedSource.id, 'bridge');
      if (photoSourceMode() !== sourceMode || selectedSource.id !== currentSelection.current.photoId ||
          garment.garmentId !== currentSelection.current.garmentId)
        throw new Error('대상 사진이나 의류 선택이 바뀌었습니다. 다시 확인해 주세요.');
      const { savedOrders, current, target } = freshGarment();
      assertPhotoNotLinkedToAnotherGarment(savedOrders, selectedSource.id, current.id, target.garmentId);
      const now = new Date().toISOString();
      const linked = linkManualPhoto(target, {
        garmentId: target.garmentId,
        requestId: crypto.randomUUID(),
        sourcePhotoId: selectedSource.id,
        role: manualRole,
        origin: selectedSource.origin,
        status: selectedSource.origin === 'bridge' ? 'saved' : 'simulated',
        timestamp: now,
        path: selectedSource.origin === 'bridge' ? selectedSource.sourcePath : `mock://gallery/${selectedSource.id}`,
      }, now);
      saveFreshPhotoChange(current, linked, selectedSource.origin === 'bridge'
        ? '선택한 원본 사진을 해당 의류에 수동 연결했습니다. Windows 매장 PC 검증은 별도 진행해야 합니다.'
        : 'SAMPLE 예시 사진을 시뮬레이션으로 연결했습니다. 실제 매장 사진이 아닙니다.');
      setIdentityConfirmed(false);
      setPreviewViewed(false);
      setSelectedPhotoId('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '사진 연결에 실패했습니다.'); }
    finally { linkInProgress.current = false; setLinking(false); }
  }
  function unlinkPhoto(photo: GarmentPhotoMetadata) {
    if (!window.confirm(`이 의류의 ${photo.role === 'intake' ? '접수' : '완성'} 사진 연결을 해제하시겠습니까?\n이력과 감사 기록은 보존되며, 다시 연결할 때 새 요청 ID가 생성됩니다.`)) return;
    try {
      const { current, target } = freshGarment();
      const unlinked = unlinkManualPhoto(target, photo.requestId);
      saveFreshPhotoChange(current, unlinked, '사진 연결을 해제했습니다. 이전 연결 이력과 감사 기록은 보존됩니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '사진 연결을 해제하지 못했습니다.'); }
  }

  function lookupGarment() {
    const found = order?.garments?.find((item) => item.garmentId === lookup.trim() || item.barcodeValue === lookup.trim());
    if (!found) { setError('이 주문에서 해당 바코드 또는 의류 ID를 찾지 못했습니다. 선택한 의류는 변경되지 않았습니다.'); return; }
    setError('');
    setGarmentId(found.garmentId);
    setNotice('해당 의류 기록을 열었습니다.');
  }

  function changeAnnotations(shapes: GarmentAnnotationShape[]) {
    setHistory((current) => pushAnnotationSnapshot(current, shapes));
  }
  function coords(event: ReactPointerEvent<SVGSVGElement>): Point {
    const bounds = event.currentTarget.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width)),
      y: Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height)),
    };
  }
  function pointerDown(event: ReactPointerEvent<SVGSVGElement>) {
    if (!representative || originalView) return;
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = coords(event);
    const id = crypto.randomUUID();
    const hitId = (event.target as Element).closest('[data-shape-id]')?.getAttribute('data-shape-id') ?? undefined;
    pointer.current = { start: point, last: point, shapeId: (tool === 'select' || tool === 'eraser') ? hitId : id };
    if (tool === 'select' && hitId) {
      setSelectedId(hitId);
      setHistory((current) => pushAnnotationSnapshot(current, current.present));
    } else if (tool === 'text') {
      const text = window.prompt('사진에 표시할 내용을 입력해 주세요.');
      if (text?.trim()) changeAnnotations([...history.present, { id, type: 'text', x: point.x, y: point.y, text: text.trim() }]);
      pointer.current = null;
    } else if (tool === 'eraser' || tool === 'select') pointer.current.shapeId = undefined;
    else if (tool === 'pen') changeAnnotations([...history.present, { id, type: 'pen', points: [point] }]);
    else changeAnnotations([...history.present, { id, type: tool, x: point.x, y: point.y, width: 0, height: 0 } as GarmentAnnotationShape]);
  }
  function pointerMove(event: ReactPointerEvent<SVGSVGElement>) {
    const active = pointer.current;
    if (!active) return;
    const point = coords(event);
    if (tool === 'pen' && active.shapeId) {
      setHistory((current) => {
        const shapes = current.present.map((shape) => shape.id === active.shapeId && shape.type === 'pen'
          ? { ...shape, points: [...shape.points, point] } : shape);
        return { ...current, present: shapes };
      });
    } else if (tool === 'select') {
      if (!active.shapeId) return;
      const dx = point.x - active.last.x; const dy = point.y - active.last.y;
      if (dx || dy) {
        setHistory((current) => {
          try { return { ...current, present: moveAnnotation(current.present, active.shapeId!, dx, dy) }; }
          catch { return current; }
        });
      }
      active.last = point;
    } else if (active.shapeId) {
      const width = Math.abs(point.x - active.start.x); const height = Math.abs(point.y - active.start.y);
      const x = Math.min(point.x, active.start.x); const y = Math.min(point.y, active.start.y);
      setHistory((current) => ({ ...current, present: current.present.map((shape) =>
        shape.id === active.shapeId && shape.type !== 'pen' && shape.type !== 'text'
          ? { ...shape, x, y, width: Math.min(width, 1 - x), height: Math.min(height, 1 - y) } : shape) }));
    }
  }
  function pointerUp(event: ReactPointerEvent<SVGSVGElement>) {
    const active = pointer.current;
    if (active && (tool === 'select' || tool === 'eraser')) {
      const point = coords(event);
      const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-shape-id]')?.getAttribute('data-shape-id');
      const hit = active.shapeId || target;
      if (hit && tool === 'eraser') changeAnnotations(eraseAnnotation(history.present, hit));
      else if (hit && tool === 'select') setSelectedId(hit);
    }
    pointer.current = null;
  }

  function saveAnnotations() {
    if (!garment || !representative) { setError('주석을 저장할 접수 원본 사진이 없습니다.'); return; }
    try { persist(saveAnnotation(garment, representative.requestId, history.present), '주석을 별도 revision으로 저장했습니다. 원본 사진은 변경되지 않았습니다.'); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '주석 저장에 실패했습니다.'); }
  }
  function recordProcess() {
    if (!garment) return;
    try {
      const updated = addActualCareProcess(garment, {
        id: crypto.randomUUID(), process, source, note: staffNote,
      });
      if (updated === garment) return;
      persist(updated, '실제로 수행한 공정을 기록했습니다.');
      setStaffNote('');
      setSummary(updated.careSummary?.generatedText ?? '');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '공정을 기록하지 못했습니다.'); }
  }
  function saveComment() {
    if (garment) persist(updateCompletionComment(garment, comment), '완성 코멘트를 저장했습니다.');
  }
  function saveSummary() {
    if (!garment) return;
    try {
      const updated = updateCareSummary(garment, summary);
      persist(updated, '고객용 케어 요약을 저장했습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '케어 요약을 저장하지 못했습니다.'); }
  }
  function addSimulatedAfterPhoto() {
    if (!garment) return;
    if (!['세탁 완료', '완성 검수', '출고 대기', '반출 완료'].includes(garment.processStatus ?? '')) {
      setError('완성 사진은 세탁 완료 이후에만 연결할 수 있습니다.');
      return;
    }
    const now = new Date().toISOString();
    try {
      const updated = addGarmentPhoto(garment, {
        garmentId: garment.garmentId, requestId: crypto.randomUUID(), role: 'completion',
        status: 'simulated', timestamp: now, origin: 'simulation',
        path: `mock://completion/${garment.garmentId}/${Date.now()}`,
      });
      persist(updated, '완성 사진 메타데이터를 시뮬레이션으로 연결했습니다. 실제 촬영이나 파일 저장은 하지 않았습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '완성 사진 정보를 연결하지 못했습니다.'); }
  }
  function prepareDeliveryCard() {
    if (!order || !garment) return;
    const existing = order.customerNotifications?.find((item) =>
      item.garmentId === garment.garmentId && item.type === '세탁 완료');
    if (existing) {
      setNotice('이 의류의 고객 결과 안내 초안이 이미 있습니다. 기존 검토 상태를 이어갑니다.');
      return;
    }
    const safeResult = getCustomerSafeResult(garment);
    const processes = safeResult.careProcesses.length ? safeResult.careProcesses.join(', ') : '기록된 공정 없음';
    const draft = `[K99 품격세탁소 과천점]\n${safeResult.garmentName} 케어 결과 안내\n${safeResult.careSummary}\n실제 케어 공정: ${processes}${safeResult.completionComment ? `\n완성 코멘트: ${safeResult.completionComment}` : ''}\n직원 검토 및 승인 후 발송 준비할 초안입니다. 실제 발송은 수행되지 않습니다.`;
    try {
      persistOrder(createCustomerNotification(order, '세탁 완료', garment.garmentId, draft), '고객 결과 안내 초안을 준비했습니다. 직원 검토가 필요하며 자동 발송되지 않습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '결과 안내 초안을 준비하지 못했습니다.'); }
  }
  function approveDeliveryDraft() {
    if (!order || !deliveryNotice) return;
    try { persistOrder(approveCustomerNotification(order, deliveryNotice.id), '직원 승인을 기록했습니다. 실제 고객 메시지는 발송되지 않았습니다.'); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '직원 승인을 기록하지 못했습니다.'); }
  }
  function prepareDeliverySend() {
    if (!order || !deliveryNotice) return;
    try { persistOrder(prepareCustomerNotification(order, deliveryNotice.id), '발송 준비 단계를 기록했습니다. 실제 SMS/카카오톡은 발송되지 않았습니다.'); }
    catch (cause) { setError(cause instanceof Error ? cause.message : '발송 준비를 기록하지 못했습니다.'); }
  }

  if (!order) return <main className="gpw"><div className="gpw-message" role="alert">{error || '저장 주문을 불러오는 중입니다.'}</div><button onClick={onBack}>뒤로</button></main>;
  if (resultOpen && garment) return <CareResultCard result={getCustomerSafeResult(garment, {
    intakeCondition: [
      order.items[garment.itemIndex - 1]?.intakeDetails?.stain && `접수 오염: ${order.items[garment.itemIndex - 1].intakeDetails?.stain}`,
      order.items[garment.itemIndex - 1]?.intakeDetails?.damage && `접수 손상: ${order.items[garment.itemIndex - 1].intakeDetails?.damage}`,
    ].filter(Boolean).join(' · '),
  })} imagePreviews={cardPreviews}
    customerName={order.customerName} onClose={() => setResultOpen(false)} />;
  const intake = order.items[garment?.itemIndex ? garment.itemIndex - 1 : 0]?.intakeDetails;
  const toolLabels: Array<[Tool, string]> = [
    ['pen', '펜'], ['circle', '원형'], ['rectangle', '사각형'], ['arrow', '화살표'],
    ['text', '텍스트'], ['eraser', '지우개'], ['select', '선택·이동'],
  ];

  return <main className="gpw">
    <div className="gpw-wrap">
      <header className="gpw-top">
        <div><span className="gpw-eyebrow">K99 GARMENT CARE · PHASE 08</span><h1>세탁 전후 사진 워크스페이스</h1>
          <p>의류별 접수 상태, 실제 공정과 고객 안내를 관리합니다.</p></div>
        <button className="gpw-button" onClick={onBack}>돌아가기</button>
      </header>
      <section className="gpw-lookup">
        <label htmlFor="gpw-barcode">바코드 또는 의류 ID</label>
        <input id="gpw-barcode" value={lookup} onChange={(event) => setLookup(event.target.value)}
          onKeyDown={(event) => { if (event.key === 'Enter') lookupGarment(); }} placeholder="바코드/의류 ID 입력 후 Enter" />
        <button className="gpw-primary" onClick={lookupGarment}>의류 열기</button>
      </section>
      {error && <div className="gpw-message gpw-message--error" role="alert">{error}</div>}
      {notice && <div className="gpw-message" role="status">{notice}</div>}
      <section className="gpw-panel" hidden>
        <h2>Windows 사진 도우미 설정</h2>
        <p className="gpw-hint">원본·대상 경로는 통합관리센터의 관리자 설정에서만 입력합니다. 이 화면에서는 경로를 편집하지 않습니다.</p>
        <p className="gpw-hint">아래 사진 경로 중 mock:// 또는 시뮬레이션으로 표시된 기록은 메타데이터용 가상 경로이며 실제 파일이나 폴더가 아닙니다. 기존 사진 주석과 케어 기록은 그대로 유지됩니다.</p>
        <button type="button" className="gpw-button" onClick={() => navigate('/management/photo-settings')}>관리자 사진 경로 설정으로 이동</button>
      </section>
      <section className="gpw-panel gpw-source" aria-labelledby="gpw-gallery-title">
        <div className="gpw-panel-heading">
          <div><span className="gpw-eyebrow">MANUAL PHOTO LINK · SELECT & VERIFY</span><h2 id="gpw-gallery-title">최근 사진에서 수동 연결</h2>
            <p>의류 선택 → 사진 미리보기 확인 → 동일 의류 확인 → 역할 선택 → 수동 연결. 사진 원본 바이트는 변경하지 않습니다.</p></div>
          <button type="button" onClick={() => void refreshGallery()} disabled={galleryLoading} data-testid="button-refresh-photo-gallery">목록 새로고침</button>
        </div>
        <div className="gpw-source-status" hidden role="status" data-testid="status-bridge-validation">
          PENDING STORE-PC LOCAL BRIDGE TEST · Windows 매장 PC 미검증
        </div>
        {sourceMode === 'bridge' && !verifiedStorePhotoBridge() && <div className="gpw-message gpw-message--error" role="status">
          실제 사진 목록은 확인할 수 있지만 매장 PC의 최종 검증이 끝날 때까지 저장 연결은 잠겨 있습니다.
          검증 후 관리자 환경에서 VITE_K99_STORE_PHOTO_BRIDGE_VERIFIED=true를 명시적으로 설정해야 활성화됩니다.
        </div>}
        {sourceMode === 'simulation' && <div className="gpw-source-status gpw-source-status--sample" role="status" data-testid="status-photo-source">
          SAMPLE · 시뮬레이션 목록 · 실제 촬영 사진 아님
        </div>}
        <div className="gpw-source-controls">
          <label htmlFor="gpw-garment-choice">연결할 의류</label>
          <select id="gpw-garment-choice" value={garmentId} data-testid="select-photo-target-garment"
            onChange={(event) => { setGarmentId(event.target.value); setLookup(event.target.value); }}>
            <option value="">의류 선택</option>
            {(order.garments ?? []).map((item) =>
              <option key={item.garmentId} value={item.garmentId}>{item.itemName} · {item.sequence}/{item.totalSequence}</option>)}
          </select>
          {garment && <span className="gpw-hint" hidden data-testid="text-selected-garment-id">{garment.garmentId}</span>}
        </div>
        {galleryError && <div className="gpw-message gpw-message--error" role="alert" data-testid="status-gallery-error">
          {galleryError} {sourceMode === 'bridge' && '실패 상태입니다. SAMPLE 목록으로 대체하지 않았습니다.'}
          <button type="button" onClick={() => void refreshGallery()}>다시 시도</button>
        </div>}
        {galleryLoading ? <div className="gpw-gallery" aria-label="사진 목록 로딩 중">
          {Array.from({ length: 6 }, (_, index) => <div key={index} className="gpw-gallery-skeleton" />)}
        </div> : !galleryError && !recentPhotos.length ? <div className="gpw-empty">최근 사진이 없습니다. 새 사진이 들어오면 목록을 다시 불러와 주세요.</div>
          : <div className="gpw-gallery" aria-label={sourceMode === 'simulation' ? 'SAMPLE 예시 사진 목록' : '최근 실제 사진 목록'}>
            {recentPhotos.map((item) => <button type="button" key={item.id}
              className={`gpw-gallery-item ${selectedPhotoId === item.id ? 'is-selected' : ''}`}
              aria-pressed={selectedPhotoId === item.id} data-testid={`button-select-source-photo-${item.id}`}
              onClick={() => { setSelectedPhotoId(item.id); setPreviewViewed(false); setIdentityConfirmed(false); }}>
              <PhotoImage id={item.id} origin={item.origin} className="gpw-photo-image--gallery" />
              <strong>{item.filename}</strong><small>{new Date(item.timestamp).toLocaleString('ko-KR')}</small>
            </button>)}
          </div>}
        {selectedSource && <div className="gpw-selection" key={`${garmentId}:${selectedSource.id}`}>
          <div className="gpw-selection-preview">
            <PhotoImage id={selectedSource.id} origin={selectedSource.origin}
              onReady={() => setPreviewViewed(true)} />
          </div>
          <div className="gpw-selection-info">
            <h3>{selectedSource.origin === 'simulation' ? 'SAMPLE 미리보기' : '선택 사진 검토'}</h3>
            <p>{selectedSource.filename} · {new Date(selectedSource.timestamp).toLocaleString('ko-KR')}</p>
            <p>{selectedSource.origin === 'simulation' ? '이것은 실제 매장의 사진이 아닙니다. 연결하면 simulated 기록으로만 저장됩니다.' :
              'Windows 사진 도우미에서 읽은 미리보기입니다. 실제 매장 PC 동작은 아직 검증되지 않았습니다.'}</p>
            <div className="gpw-role" role="radiogroup" aria-label="사진 역할">
              <label><input type="radio" name="gpw-photo-role" checked={manualRole === 'intake'}
                onChange={() => setManualRole('intake')} /> INTAKE · 접수</label>
              <label><input type="radio" name="gpw-photo-role" checked={manualRole === 'completion'}
                onChange={() => setManualRole('completion')} /> COMPLETION · 완성</label>
            </div>
            <label className="gpw-check"><input type="checkbox" checked={identityConfirmed} disabled={!previewViewed || !garment}
              onChange={(event) => setIdentityConfirmed(event.target.checked)} data-testid="checkbox-confirm-photo-identity" />
              <span>이 사진이 선택한 의류 <strong>{garment?.itemName ?? '미선택'}</strong>의 사진임을 확인했습니다.</span></label>
            <button type="button" className="gpw-primary" disabled={!garment || !previewViewed || !identityConfirmed || !!galleryError || linking || (sourceMode === 'bridge' && !verifiedStorePhotoBridge())}
              onClick={() => void manualLink()} data-testid="button-manually-link-photo">{linking ? '사진 다시 확인 중…' : '선택 사진 수동 연결'}</button>
          </div>
        </div>}
      </section>
      {garment ? <>
        <div className="gpw-layout">
          <section className="gpw-panel">
            <div className="gpw-panel-heading"><div><span className="gpw-eyebrow">BEFORE · ORIGINAL INTAKE</span>
              <h2>{garment.itemName}<small>{garment.sequence}/{garment.totalSequence}</small></h2></div>
              <select aria-label="대표 BEFORE 사진 선택" value={representative?.requestId ?? ''}
                onChange={(event) => {
                  if (!event.target.value) return;
                  try { persist(selectPhoto(garment, event.target.value), '대표 BEFORE 사진을 선택했습니다.'); }
                  catch (cause) { setError(cause instanceof Error ? cause.message : '대표 사진을 선택하지 못했습니다.'); }
                }}>
                <option value="">접수 원본 선택</option>{beforePhotos.map((photo, index) =>
                  <option key={photo.requestId} value={photo.requestId}>접수 사진 {index + 1} · {new Date(photo.timestamp).toLocaleDateString('ko-KR')}</option>)}
              </select>
            </div>
            <div className="gpw-intake">
              {(['brand', 'material', 'color', 'stain', 'damage'] as const).map((key) =>
                intake?.[key] ? <div key={key}><span>{{ brand: '브랜드', material: '소재', color: '색상', stain: '오염', damage: '손상' }[key]}</span><strong>{intake[key]}</strong></div> : null)}
            </div>
            {representative ? <PhotoMetadata photo={representative} /> : <div className="gpw-empty">연결된 접수 원본 사진이 없습니다.</div>}
            {!!beforePhotos.length && <div className="gpw-before-list" aria-label="연결된 접수 사진">
              {beforePhotos.map((photo) => <div className="gpw-linked-row" key={photo.requestId}>
                <PhotoImage id={photo.sourcePhotoId} origin={photo.origin} className="gpw-photo-image--linked" />
                <PhotoMetadata photo={photo} />
                <button type="button" onClick={() => unlinkPhoto(photo)} aria-label={`접수 사진 ${photo.requestId} 연결 해제`}
                  data-testid={`button-unlink-photo-${photo.requestId}`}>연결 해제</button>
              </div>)}
            </div>}
            <div className="gpw-toolrow">
              {toolLabels.map(([key, label]) => <button key={key} className={tool === key ? 'is-active' : ''}
                onClick={() => setTool(key)}>{label}</button>)}
              <button onClick={() => setHistory((current) => undoAnnotation(current))} disabled={!history.past.length}>실행 취소</button>
              <button onClick={() => setHistory((current) => redoAnnotation(current))} disabled={!history.future.length}>다시 실행</button>
            </div>
            <div className="gpw-toolrow gpw-toolrow--secondary">
              <button onClick={() => setZoom((value) => Math.min(2.5, value + .2))}>확대</button>
              <button onClick={() => setZoom((value) => Math.max(.5, value - .2))}>축소</button>
              <button onClick={() => setZoom(1)}>전체 맞춤</button>
              <button onClick={() => setShowAnnotations((value) => !value)}>{showAnnotations ? '주석 숨기기' : '주석 표시'}</button>
              <button onClick={() => setHistory((current) => pushAnnotationSnapshot(current, []))}>주석 전체 삭제</button>
              <button onClick={() => setOriginalView((value) => !value)}>{originalView ? '편집 보기' : '원본 보기'}</button>
              <button className="gpw-primary" onClick={saveAnnotations} disabled={!representative}>주석 별도 저장</button>
            </div>
            <div className="gpw-preview-shell">
              <div className="gpw-preview-stage" style={{ transform: `scale(${zoom})`, aspectRatio: beforeAspect }}>
                {representative ? <>
                  <PhotoImage key={representative.requestId} id={representative.sourcePhotoId} origin={representative.origin}
                    className="gpw-photo-image--stage" onReady={(width, height) => setBeforeAspect(`${width} / ${height}`)} />
                  <svg className="gpw-edit-layer" viewBox="0 0 1000 700" preserveAspectRatio="none" onPointerDown={pointerDown}
                    onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp}
                    style={{ touchAction: 'none', cursor: tool === 'select' ? 'move' : tool === 'eraser' ? 'crosshair' : 'crosshair' }}>
                    <AnnotationLayer shapes={history.present} hidden={originalView || !showAnnotations}
                      selectedId={selectedId} onShapeClick={setSelectedId} />
                  </svg>
                </> : <div className="gpw-placeholder"><strong>BEFORE 사진 없음</strong><span>접수 사진이 연결되면 여기에서 주석을 관리할 수 있습니다.</span></div>}
              </div>
            </div>
            <p className="gpw-hint">주석 좌표는 이미지 기준 0–1로 저장합니다. 마우스와 일반 포인터 입력을 지원합니다.</p>
          </section>
          <section className="gpw-panel">
            <div className="gpw-panel-heading"><div><span className="gpw-eyebrow">AFTER · CARE RECORD</span><h2>완성 결과 및 케어</h2></div>
              <button className="gpw-button" hidden onClick={addSimulatedAfterPhoto}>별도 시뮬레이션 완성 메타데이터 추가</button></div>
            <div className="gpw-after-list">{afterPhotos.length ? afterPhotos.map((photo) => <div className="gpw-linked-row" key={photo.requestId}>
              <PhotoImage id={photo.sourcePhotoId} origin={photo.origin} className="gpw-photo-image--linked" />
              <PhotoMetadata photo={photo} />
              <button type="button" onClick={() => unlinkPhoto(photo)} aria-label={`완성 사진 ${photo.requestId} 연결 해제`}
                data-testid={`button-unlink-photo-${photo.requestId}`}>연결 해제</button>
            </div>)
              : <div className="gpw-empty">연결된 AFTER 사진이 없습니다.</div>}</div>
            <div className="gpw-compare"><div><span>BEFORE</span>{representative && <PhotoMetadata photo={representative} />}
              {representative ? <PhotoImage id={representative.sourcePhotoId} origin={representative.origin} className="gpw-photo-image--compare" />
                : <div className="gpw-compare-placeholder">접수 사진 미등록</div>}</div>
              <div><span>AFTER</span>{afterPhotos[0] && <PhotoMetadata photo={afterPhotos[0]} />}
                {afterPhotos[0] ? <PhotoImage id={afterPhotos[0].sourcePhotoId} origin={afterPhotos[0].origin} className="gpw-photo-image--compare" />
                  : <div className="gpw-compare-placeholder">완성 사진 미등록</div>}</div></div>
            <h3>실제 수행 공정 기록</h3>
            <div className="gpw-process-form">
              <select value={process} onChange={(event) => setProcess(event.target.value)}>{DEFAULT_CARE_PROCESSES.map((item) => <option key={item}>{item}</option>)}</select>
              <input value={source} onChange={(event) => setSource(event.target.value)} aria-label="기록 출처" placeholder="기록 출처" />
              <input value={staffNote} onChange={(event) => setStaffNote(event.target.value)} aria-label="직원 참고 메모" placeholder="선택 메모" />
              <button className="gpw-primary" onClick={recordProcess}>공정 기록</button>
            </div>
            <div className="gpw-process-list">{(garment.careProcesses ?? []).map((item) => <article key={item.id}>
              <strong>{item.process}</strong><span>{new Date(item.at).toLocaleString('ko-KR')} · {item.source}</span>
              {item.note && <small>직원 메모 · {item.note}</small>}</article>)}</div>
            <label className="gpw-field">고객용 케어 요약<textarea value={summary} maxLength={2000} onChange={(event) => setSummary(event.target.value)} /></label>
            <button className="gpw-button" onClick={saveSummary}>케어 요약 저장</button>
            <label className="gpw-field">완성 코멘트<textarea value={comment} maxLength={2000} onChange={(event) => setComment(event.target.value)} placeholder="고객에게 안내할 완성 상태를 입력하세요." /></label>
            <button className="gpw-button" onClick={saveComment}>완성 코멘트 저장</button>
            <div className="gpw-actions"><button className="gpw-primary" onClick={() => onShowCustomer(order.id, garment.garmentId)}>고객 화면에 표시</button>
              <button className="gpw-button" onClick={() => setResultOpen(true)}>결과 카드 미리보기</button></div>
            <section className="gpw-delivery">
              <h3>배달 고객 결과 안내 준비</h3>
              <p>시스템 초안 준비 → 직원 검토 → 직원 승인 → 발송 준비 순서입니다. 발송 기능은 연결되어 있지 않습니다.</p>
              {!deliveryNotice ? <button className="gpw-button" onClick={prepareDeliveryCard}>결과 안내 초안 준비</button> : <>
                <label className="gpw-field">직원 검토용 초안<textarea readOnly value={deliveryNotice.draftText} /></label>
                <div className="gpw-delivery-status">
                  <span>초안 준비 {new Date(deliveryNotice.createdAt).toLocaleString('ko-KR')}</span>
                  <span>직원 승인 {deliveryNotice.approvalAt ? new Date(deliveryNotice.approvalAt).toLocaleString('ko-KR') : '대기'}</span>
                  <span>발송 준비 {deliveryNotice.sendPreparationAt ? new Date(deliveryNotice.sendPreparationAt).toLocaleString('ko-KR') : '대기'}</span>
                </div>
                {!deliveryNotice.approvalAt && <button className="gpw-button" onClick={approveDeliveryDraft}>직원 검토 및 승인</button>}
                {deliveryNotice.approvalAt && !deliveryNotice.sendPreparationAt && <button className="gpw-button" onClick={prepareDeliverySend}>발송 준비 기록</button>}
                <small>실제 SMS/카카오톡 발송은 하지 않으며, 준비 기록만 저장합니다.</small>
              </>}
            </section>
          </section>
        </div>
        <section className="gpw-audit" hidden><h2>의류 기록 이력</h2>
          {[...garment.auditEvents].reverse().slice(0, 12).map((event, index) => <div key={`${event.at}-${index}`}>
            <time>{new Date(event.at).toLocaleString('ko-KR')}</time><strong>{event.type}</strong><span>{event.details ?? event.status}</span></div>)}
        </section>
      </> : <div className="gpw-empty">이 주문에 등록된 의류 기록이 없습니다.</div>}
      <footer className="gpw-footer">K99 품격세탁소 · 과천점</footer>
    </div>
  </main>;
}

export default GarmentPhotoWorkspace;