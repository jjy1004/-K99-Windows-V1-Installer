import { useEffect, useState } from 'react';
import { directoryRequest } from './customer-directory-client';
import './photo-retention.css';

type Days = 30 | 60 | 90 | null;
type Status = {
  native: boolean; running: boolean; days: Days; pendingCount: number;
  lastResult: null | { at: string; days: Days; deletedFolders: number; skippedFolders: number;
    failedFolders: number; disabled: boolean; error: string | null };
};
const readStatus = () => directoryRequest<Status>('GET', '/api/photo-retention/status');

export function PhotoRetentionSettings() {
  const native = typeof window !== 'undefined' && Boolean(window.k99Desktop);
  const [status, setStatus] = useState<Status | null>(null);
  const [days, setDays] = useState<Days>(60);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    if (!native) return;
    let live = true, loading = false, initial = true;
    const refresh = async () => {
      if (loading) return; loading = true;
      try {
        const value = await readStatus();
        if (live) { setStatus(value); if (initial) { setDays(value.days); initial = false; } }
      } catch (cause) { if (live) setError(cause instanceof Error ? cause.message : '설정을 읽지 못했습니다.'); }
      finally { loading = false; }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 5000);
    return () => { live = false; window.clearInterval(timer); };
  }, [native]);
  async function save() {
    setBusy(true); setError(''); setMessage('');
    try {
      const value = await directoryRequest<Status>('POST', '/api/photo-retention/settings', { days });
      setStatus(value); setDays(value.days); setMessage('자동 정리 설정을 SQLite에 저장했습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '저장하지 못했습니다.'); }
    finally { setBusy(false); }
  }
  async function run() {
    if (!status || status.days === null || days !== status.days) return;
    if (!window.confirm(`출고 완료 후 ${status.days}일 이상 지난 접수 사진 폴더를 지금 영구 삭제하시겠습니까?\n휴지통으로 이동하지 않습니다.\n출고 대기·비교 사진·장부·기존 백업은 보존됩니다.`)) return;
    setBusy(true); setError(''); setMessage('');
    try {
      const value = await directoryRequest<Status>('POST', '/api/photo-retention/run', { confirmed: true });
      setStatus(value);
      setMessage(value.lastResult?.error ? '일부 폴더를 보존했습니다. 아래 결과를 확인하세요.' : '접수 사진 폴더 정리를 마쳤습니다.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : '정리하지 못했습니다.'); }
    finally { setBusy(false); }
  }
  const locked = !native || !status?.native || busy || status.running;
  const last = status?.lastResult;
  return <section className="eq-card photo-retention-card" data-testid="card-photo-retention">
    <h2>출고 완료 접수 사진 자동 삭제</h2>
    <p>실제 출고 완료일로부터 경과한 기간을 기준으로, 앱 시작 후 하루 한 번 정리합니다. 기본값은 60일입니다.</p>
    <div className="mtw__stack">
      <label className="eq-field">접수 사진 보관 기간
        <select value={days === null ? 'off' : String(days)} disabled={locked}
          data-testid="select-photo-retention" onChange={event => {
            setDays(event.target.value === 'off' ? null : Number(event.target.value) as 30 | 60 | 90);
            setMessage(''); setError('');
          }}>
          <option value="30">30일 경과 후 자동 삭제</option>
          <option value="60">60일 경과 후 자동 삭제</option>
          <option value="90">90일 경과 후 자동 삭제</option>
          <option value="off">사용 안 함</option>
        </select>
      </label>
      <div className="mc-side-actions">
        <button type="button" className="eq-btn" disabled={locked} onClick={() => void save()} data-testid="button-save-photo-retention">설정 저장</button>
        <button type="button" className="eq-btn" disabled={locked || days === null || days !== status?.days}
          onClick={() => void run()} data-testid="button-run-photo-retention">{busy || status?.running ? '처리 중…' : '지금 즉시 정리 실행'}</button>
      </div>
      <p>변경한 기간은 먼저 저장하세요. 출고 대기·배달 중·취소·출고일 불명 주문과 미확정 촬영 자료는 정리하지 않습니다.
        같은 폴더를 공유하는 주문은 모두 기간이 지나야 삭제됩니다.</p>
      <p><strong>삭제 대상은 01_고객세탁사진의 해당 폴더뿐입니다.</strong> 휴지통을 거치지 않습니다.
        고객·주문 장부, 02_세탁전후사진, 내부 사진 보존 사본 및 기존 백업은 유지합니다.</p>
      {!native && <p role="status">이 설정과 실제 정리는 Windows 설치형 앱에서 사용할 수 있습니다.</p>}
      <p role="status" data-testid="status-photo-retention-result">
        {last ? `${new Date(last.at).toLocaleString('ko-KR')} · ${last.disabled ? '사용 안 함 · ' : ''}삭제된 폴더 ${last.deletedFolders}개 · 보존/대상 아님 ${last.skippedFolders}개 · 실패 ${last.failedFolders}개`
          : '아직 정리한 기록이 없습니다.'}
      </p>
      {last?.error && <p className="eq-error" role="alert">{last.error}</p>}
      {!!status?.pendingCount && <p className="eq-error">중단된 정리 {status.pendingCount}건의 복구 확인이 필요합니다. 해당 자료는 자동 삭제하지 않습니다.</p>}
      {message && <p className="eq-msg" role="status" data-testid="status-photo-retention-message">{message}</p>}
      {error && <p className="eq-error" role="alert">{error}</p>}
    </div>
  </section>;
}
