import {retireIriunContext} from './iriun-camera';

export type IriunContext = {
  media: MediaDevices;
  dispose: () => void;
};

/** A disposable same-origin document owns native media requests, not the POS
 * document. Removing it makes the requesting document inactive before its
 * acquisition lock is retired. Never reload the POS or clear its storage. */
export function createIriunContext(signal: AbortSignal): Promise<IriunContext> {
  return new Promise((resolve, reject) => {
    signal.throwIfAborted();
    const frame = document.createElement('iframe');
    frame.title = '카메라 연결 전용 환경';
    frame.setAttribute('aria-hidden', 'true');
    frame.allow = 'camera';
    frame.tabIndex = -1;
    Object.assign(frame.style, {
      position: 'fixed', width: '2px', height: '2px', bottom: '0',
      right: '0', opacity: '0.01', pointerEvents: 'none', border: '0',
    });
    let settled = false, disposed = false, media: MediaDevices | undefined;
    const dispose = () => {
      if (disposed) return;
      disposed = true;
      frame.remove();
      // The old document is now inactive. A new attempt gets a NEW navigator.
      if (media) retireIriunContext(media);
    };
    const fail = (error: Error) => {
      if (settled) return;
      settled = true; cleanup(); dispose(); reject(error);
    };
    const abort = () => fail(new DOMException('촬영 창이 닫혔습니다.', 'AbortError'));
    const timer = setTimeout(() => fail(Error('촬영 전용 환경을 준비하지 못했습니다.')), 6000);
    const cleanup = () => {
      clearTimeout(timer); signal.removeEventListener('abort', abort);
      frame.onload = null; frame.onerror = null;
    };
    frame.onload = () => {
      try {
        if (signal.aborted) { abort(); return; }
        media = frame.contentWindow?.navigator.mediaDevices;
        if (!media?.enumerateDevices || !media.getUserMedia)
          throw Error('이 PC에서 카메라 기능을 사용할 수 없습니다. Windows 카메라 권한을 확인해 주세요.');
        settled = true; cleanup(); resolve({media, dispose});
      } catch (error) { fail(error instanceof Error ? error : Error('촬영 환경 준비 실패')); }
    };
    frame.onerror = () => fail(Error('촬영 전용 환경을 불러오지 못했습니다.'));
    signal.addEventListener('abort', abort, {once: true});
    frame.src = `${import.meta.env.BASE_URL}camera-context.html`;
    document.body.append(frame);
    if (signal.aborted) abort();
  });
}
