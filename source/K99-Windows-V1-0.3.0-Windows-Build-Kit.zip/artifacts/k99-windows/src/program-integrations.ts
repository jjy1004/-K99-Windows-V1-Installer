export type IntegrationSettings = { luxuryTarget: string; prescriptionUrl: string };
export type LuxuryResult = { itemName: string; finalPrice: number };
const KEY = 'k99-program-integrations-v1';
export const DEFAULT_PRESCRIPTION_URL = 'https://k-99-washcare-ai.replit.app';
export const DEFAULT_LUXURY_URL = 'https://k-99-luxury-laundry-pricing.replit.app';
function https(value: string) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password) throw new Error('인증정보 없는 HTTPS 주소를 입력해 주세요.');
  return url;
}
export function readIntegrationSettings(): IntegrationSettings {
  const raw = window.localStorage.getItem(KEY);
  if (!raw) return { luxuryTarget: DEFAULT_LUXURY_URL, prescriptionUrl: DEFAULT_PRESCRIPTION_URL };
  const value: unknown = JSON.parse(raw);
  if (!value || typeof value !== 'object' || !('luxuryTarget' in value) || !('prescriptionUrl' in value) ||
    typeof value.luxuryTarget !== 'string' || typeof value.prescriptionUrl !== 'string') throw new Error('저장된 연동 설정을 확인해 주세요.');
  return { luxuryTarget: value.luxuryTarget.trim() || DEFAULT_LUXURY_URL, prescriptionUrl: value.prescriptionUrl ||
    (!('prescriptionConfigured' in value) || value.prescriptionConfigured !== true ? DEFAULT_PRESCRIPTION_URL : '') };
}
export function saveIntegrationSettings(value: IntegrationSettings) {
  const settings = { luxuryTarget: value.luxuryTarget.trim(), prescriptionUrl: value.prescriptionUrl.trim() };
  if (settings.luxuryTarget.length > 2048 || settings.prescriptionUrl.length > 2048) throw new Error('연동 주소가 너무 깁니다.');
  if (settings.luxuryTarget && !/^[A-Za-z]:\\[^<>|"?*\r\n]+\.exe$/i.test(settings.luxuryTarget)) https(settings.luxuryTarget);
  if (settings.prescriptionUrl) https(settings.prescriptionUrl);
  // Desktop runtime maps localStorage to synchronous SQLite, including backups.
  window.localStorage.setItem(KEY, JSON.stringify({ ...settings, prescriptionConfigured: true }));
  window.dispatchEvent(new Event('k99:program-integrations-changed'));
}
export async function openIntegration(kind: 'luxury' | 'prescription', label: { material: string; color: string }) {
  if (window.k99Desktop?.openProgram) {
    const result = await window.k99Desktop.openProgram({ kind, ...label });
    if (!result.success) throw new Error(result.error || '연동 프로그램을 열지 못했습니다.');
    if (result.warning) throw new Error(result.warning);
    return;
  }
  const settings = readIntegrationSettings();
  const target = kind === 'luxury' ? settings.luxuryTarget : settings.prescriptionUrl;
  if (!target) throw new Error(kind === 'luxury' ? '통합관리센터에서 명품 세탁비 계산기 경로/URL을 먼저 저장해 주세요.' : '추후 연동 예정입니다.');
  if (!/^https:/i.test(target)) throw new Error('실행 파일 연결은 Windows 앱에서 사용할 수 있습니다.');
  const url = https(target);
  if (kind === 'prescription') { url.searchParams.set('material', label.material); url.searchParams.set('color', label.color); }
  const child = window.open(url.href, '_blank', 'noopener,noreferrer');
  // noopener intentionally isolates the web preview; native Windows provides results.
  void child;
}
export function subscribeLuxuryResult(callback: (result: LuxuryResult) => void): () => void {
  return window.k99Desktop?.onLuxuryResult?.(callback) ?? (() => {});
}
