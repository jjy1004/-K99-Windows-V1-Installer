import { readPhotoBridgeSession } from './passive-photo-client.ts';
import { withPhotoReadDeadline } from './photo-read-deadline.ts';

const API = 'k99-disabled://hardware';
const MAX_PREVIEW_BYTES = 40 * 1024 * 1024;

export type PhotoSourceItem = {
  id: string;
  filename: string;
  timestamp: string;
  sourcePath?: string;
  origin: 'simulation' | 'bridge';
};

const sampleNames = ['1030-01.jpg', '1058-01.jpg', '1058-02.jpg', '1214-01.jpg', '1352-01.jpg', '1430-01.jpg'];

function simulatedItems(): PhotoSourceItem[] {
  const now = Date.now();
  return sampleNames.map((filename, index) => ({
    id: `sim-k99-${index + 1}`,
    filename: `예시-${filename}`,
    timestamp: new Date(now - (index + 1) * 12 * 60_000).toISOString(),
    origin: 'simulation',
  }));
}

export function photoSourceMode(): 'simulation' | 'bridge' {
  return readPhotoBridgeSession() ? 'bridge' : 'simulation';
}

/** Enabled only after the final Windows PC source-preservation and identity test. */
export function verifiedStorePhotoBridge(): boolean {
  return import.meta.env.VITE_K99_STORE_PHOTO_BRIDGE_VERIFIED === 'true';
}

export async function listRecentPhotos(): Promise<PhotoSourceItem[]> {
  const session = readPhotoBridgeSession();
  if (!session) return simulatedItems();
  const data: unknown = await withPhotoReadDeadline(async (signal) => {
    let response: Response;
    try {
      response = await fetch(`${API}/v1/photos?limit=30`, {
        headers: { 'X-K99-Bridge-Token': session.token, Accept: 'application/json' },
        cache: 'no-store',
        signal,
      });
    } catch {
      throw new Error('Windows 사진 도우미에 연결할 수 없습니다. 실제 사진 대신 예시를 표시하지 않습니다.');
    }
    if (!response.ok) throw new Error(`최근 촬영 사진을 읽지 못했습니다 (${response.status}). 실제 사진 대신 예시를 표시하지 않습니다.`);
    return await response.json();
  });
  if (!data || typeof data !== 'object' || !Array.isArray((data as { photos?: unknown }).photos))
    throw new Error('사진 도우미 목록 응답이 올바르지 않습니다.');
  return (data as { photos: unknown[] }).photos.map((item) => {
    if (!item || typeof item !== 'object') throw new Error('사진 목록 항목이 올바르지 않습니다.');
    const photo = item as Record<string, unknown>;
    if (typeof photo.photoId !== 'string' || !/^[a-f0-9]{64}$/.test(photo.photoId)
      || typeof photo.filename !== 'string' || typeof photo.timestamp !== 'string'
      || !Number.isFinite(Date.parse(photo.timestamp))
      || typeof photo.sourcePath !== 'string' || !photo.sourcePath.trim()) {
      throw new Error('사진 도우미가 유효하지 않은 사진 식별자를 반환했습니다.');
    }
    return {
      id: photo.photoId,
      filename: photo.filename,
      timestamp: photo.timestamp,
      sourcePath: photo.sourcePath,
      origin: 'bridge' as const,
    };
  });
}

function simulationPreview(id: string): string {
  const match = /^sim-k99-([1-6])$/.exec(id);
  if (!match) throw new Error('예시 사진 식별자를 찾을 수 없습니다.');
  const index = Number(match[1]);
  const hue = [205, 32, 132, 15, 245, 190][index - 1];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480">
    <rect width="640" height="480" fill="hsl(${hue} 18% 24%)"/>
    <rect x="48" y="38" width="544" height="404" rx="16" fill="hsl(${hue} 18% 34%)"/>
    <path d="M250 90 L284 125 L356 125 L390 90 L495 150 L455 240 L403 220 L403 390 L237 390 L237 220 L185 240 L145 150 Z"
      fill="hsl(${hue} 32% 67%)" stroke="hsl(${hue} 26% 80%)" stroke-width="8"/>
    <text x="320" y="340" font-family="sans-serif" text-anchor="middle" font-size="26" fill="#18323b">SAMPLE ${index}</text>
    <rect x="74" y="394" width="492" height="36" rx="5" fill="#17272e"/>
    <text x="320" y="420" text-anchor="middle" font-family="sans-serif" font-size="20" fill="#fff">SIMULATION ONLY</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

/**
 * Render a small browser-only preview; no original bytes are saved or changed.
 * The token is sent in a header, never in an image URL or the customer popup.
 */
export async function loadPhotoPreview(id: string, origin: PhotoSourceItem['origin']): Promise<string> {
  if (origin === 'simulation') return simulationPreview(id);
  if (!/^[a-f0-9]{64}$/.test(id)) throw new Error('사진 식별자가 올바르지 않습니다.');
  const session = readPhotoBridgeSession();
  if (!session) throw new Error('Windows 사진 도우미의 현재 탭 연결이 필요합니다.');
  const blob = await withPhotoReadDeadline(async (signal) => {
    let response: Response;
    try {
      response = await fetch(`${API}/v1/photos/${id}/image`, {
        headers: { 'X-K99-Bridge-Token': session.token, Accept: 'image/jpeg, image/png' },
        cache: 'no-store',
        signal,
      });
    } catch {
      throw new Error('사진 도우미에서 미리보기를 가져오지 못했습니다.');
    }
    const contentType = response.headers.get('content-type')?.toLowerCase().split(';', 1)[0].trim();
    if (!response.ok || !['image/jpeg', 'image/png', 'image/bmp', 'image/webp'].includes(contentType ?? ''))
      throw new Error(`원본 사진을 읽을 수 없습니다 (${response.status}).`);
    return await response.blob();
  });
  if (blob.size < 24 || blob.size > MAX_PREVIEW_BYTES) throw new Error('사진 크기가 허용 범위를 벗어납니다.');
  const url = URL.createObjectURL(blob);
  try {
    const image = new Image();
    image.src = url;
    await withPhotoReadDeadline(() => image.decode());
    const scale = Math.min(1, 640 / image.naturalWidth, 480 / image.naturalHeight);
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('미리보기 캔버스를 만들 수 없습니다.');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.8);
  } finally {
    URL.revokeObjectURL(url);
  }
}