import type { ConfirmedOrder } from './order-record';
import { currentOperations } from './order-operations';
import { isDeletedOrder } from './order-deletion-policy';
import { isGarmentComplete, listGarments } from './garment-scanner';
import { garmentProcessStatus } from './laundry-process';
import { staffHandoverBlockers } from './order-handover';

export function canRestoreHandover(order: ConfirmedOrder): boolean {
  const ops = currentOperations(order);
  return !isDeletedOrder(order) && !ops.cancelledAt &&
    ['매장수령완료', '배달중', '배달완료'].includes(ops.stage);
}

export function latestHandedOrder(orders: ConfirmedOrder[]): ConfirmedOrder | undefined {
  const moment = (order: ConfirmedOrder) => {
    const ops = currentOperations(order);
    const dates = [ops.completedAt, ...(order.history ?? []).filter(event =>
      event.kind === 'operations-update' && (event.details?.action === 'handover-confirmed' ||
        event.details?.action === 'stage' && ['매장수령완료','배달중','배달완료'].includes(String(event.details?.revised))))
      .map(event => event.at)].map(value => Date.parse(value || '')).filter(Number.isFinite);
    return dates.length ? Math.max(...dates) : Date.parse(ops.updatedAt);
  };
  return orders.filter(canRestoreHandover).filter(order => Number.isFinite(moment(order)))
    .sort((a,b) => moment(b) - moment(a))[0];
}

/** Logistics correction only: never reverse payment, erase notices, or recreate deleted photos. */
export function restoreHandover(order: ConfirmedOrder, actor = '매장 직원', at = new Date()): ConfirmedOrder {
  if (!canRestoreHandover(order)) throw new Error('출고 완료 또는 배달 출고 상태의 정상 주문만 복구할 수 있습니다.');
  const garments = listGarments(order);
  if (!garments.length || garments.some(g => !isGarmentComplete(g) || g.qcHoldReason ||
      !['출고 대기','반출 완료'].includes(garmentProcessStatus(order,g))))
    throw new Error('완성 검수 기록을 확인할 수 없습니다. 미완성 의류를 임의로 출고 대기로 변경하지 않았습니다.');
  const ops = currentOperations(order), timestamp = at.toISOString();
  const restored: ConfirmedOrder = { ...order,
    operations: { ...ops, stage: order.choices.deliveryRequested ? '배달대기' : '포장완료',
      completedAt: undefined, updatedAt: timestamp },
    garments: garments.map(g => ({ ...g, handoverStatus: 'pending', processStatus: '출고 대기',
      processUpdatedAt: timestamp, auditEvents: [...(g.auditEvents ?? []), {
        at: timestamp, type: 'laundry-process', status: '출고 대기', orderId: order.id,
        garmentId: g.garmentId, previousStatus: garmentProcessStatus(order,g), newStatus: '출고 대기',
        source: 'manual', action: '출고 대기 복구',
      }] })),
    history: [...(order.history ?? []), { at: timestamp, kind: 'operations-update', details: {
      action: 'handover-restored', actor: actor.trim() || '매장 직원', previous: ops.stage,
      previousCompletedAt: ops.completedAt ?? null, paymentPreserved: true,
    } }],
  };
  const blockers = staffHandoverBlockers(restored);
  if (blockers.length) throw new Error(blockers.join('\n'));
  return restored;
}
