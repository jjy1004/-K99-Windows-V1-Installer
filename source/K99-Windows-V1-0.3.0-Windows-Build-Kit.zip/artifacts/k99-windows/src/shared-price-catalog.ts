import { PRICE_STORAGE_KEY, validateCatalog, type CatalogEntry } from './price-catalog';

export const SHARED_PRICE_EVENT = 'k99-shared-price-updated';
let revision: number | null = null;
export const sharedPriceRevision = () => revision;
let warning = '';
export const sharedPriceWarning = () => warning;
async function request(init?: RequestInit) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(`${import.meta.env.BASE_URL.replace(/\/$/, '')}/api/price-catalog`,
      { ...init, cache: 'no-store', signal: controller.signal });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || `공통 가격표 요청 실패 (${response.status})`);
    if (!Number.isSafeInteger(body.revision) || body.revision < 0 || !Array.isArray(body.entries))
      throw new Error('공통 가격표 응답을 확인할 수 없습니다.');
    return body as {revision: number; entries: (Partial<CatalogEntry> & {id: string; generalPrice: number})[]; settingsWarning?: string};
  } finally { clearTimeout(timer); }
}
function accept<T extends CatalogEntry>(defaults: readonly T[], response: Awaited<ReturnType<typeof request>>) {
  if (revision !== null && response.revision < revision) throw new Error('이전 가격 응답을 무시했습니다. 최신 가격을 다시 확인하세요.');
  const catalog = validateCatalog(defaults, response.entries);
  revision = response.revision;
  warning = response.settingsWarning ?? '';
  // A convenience cache only: all successful saves below require server persistence.
  try { window.localStorage.setItem(PRICE_STORAGE_KEY, JSON.stringify(response.entries)); } catch {}
  return catalog;
}
export async function readSharedCatalog<T extends CatalogEntry>(defaults: readonly T[]) {
  return accept(defaults, await request());
}
export async function saveSharedCatalog<T extends CatalogEntry>(
  defaults: readonly T[], entries: readonly T[], password: string, expectedRevision: number | null,
) {
  if (expectedRevision === null) throw new Error('로컬 가격표를 먼저 불러오세요.');
  const editable = entries.filter(e => e.userAdded || !e.legacy && !e.derivedFrom && !e.custom)
    .map(e => e.userAdded ? e : ({id:e.id, generalPrice:e.generalPrice}));
  validateCatalog(defaults, editable);
  const result = await request({ method: 'PUT', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({revision: expectedRevision, entries: editable, password}) });
  const catalog = accept(defaults, result);
  window.dispatchEvent(new Event(SHARED_PRICE_EVENT));
  return catalog;
}
