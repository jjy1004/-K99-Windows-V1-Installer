import { savedIntakeUrl } from './order-entry';

/** Seed one previous K99 screen for a direct/bookmarked staff entry, never trap Back. */
export function workflowEntryFallback(path: string, search = ''): string | null {
  if (/^\/customer(?:-result)?\/?$/.test(path)) return null;
  const order = /^\/(?:orders|laundry-process|photo)\/([^/]+)/.exec(path);
  if (order) {
    try { return savedIntakeUrl(decodeURIComponent(order[1])); } catch { return '/'; }
  }
  if (path === '/' && new URLSearchParams(search).get('stage') === 'final') return '/';
  return '/';
}

export function seedWorkflowHistory(base: string): void {
  const path = window.location.pathname.slice(base.replace(/\/$/, '').length) || '/';
  const fallback = workflowEntryFallback(path, window.location.search);
  if (fallback === null || window.history.state?.k99WorkflowEntry) return;
  const current = window.location.href;
  const state = { ...window.history.state, k99WorkflowEntry: true };
  window.history.replaceState(state, '', `${base.replace(/\/$/, '')}${fallback}`);
  window.history.pushState(state, '', current);
}
