import { PiggyBank } from 'lucide-react';
import './customer-savings-banner.css';

/** A reception session, not each item/price revision, owns the seven gentle pulses. */
export function CustomerSavingsBanner({sessionKey}:{sessionKey:string}){
  return <div key={sessionKey} className="csb-banner" role="note"
    data-testid="customer-voucher-banner" data-session-key={sessionKey}>
    <PiggyBank className="csb-icon" aria-hidden="true"/>
    <strong className="csb-title">세탁비 절약 방법</strong>
    <div className="csb-cards">
      <div className="csb-card" data-testid="customer-saving-100k"><b>10만 원</b> 적립금 <span>11만 원 이용</span></div>
      <div className="csb-card" data-testid="customer-saving-200k"><b>20만 원</b> 적립금 <span>23만 원 이용</span></div>
    </div>
  </div>;
}
