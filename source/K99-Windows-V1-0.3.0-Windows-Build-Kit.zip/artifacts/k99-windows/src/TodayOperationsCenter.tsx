import { useCallback, useEffect, useMemo, useState } from 'react';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import { ArrowLeft, ArrowRight, ClipboardList, Download, ExternalLink, RefreshCw, ShieldAlert } from 'lucide-react';
import { readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from './order-record';
import { useLocation } from 'wouter';
import { prepareOperationalNoticeReview, pendingCustomerNotices } from './notification-queue';
import { currentOperations } from './order-operations';
import { koreaCalendarDate } from './storage-policy';
import {
  recommendedNextActions, todayAttentionWarnings, todayDataQualityReport,
  todayOperationsSummary, todayPickupDeliveryBoard,
  type TodayCardKey, type TodayFilterRecord,
} from './today-operations-data';
import { createManagementExport, type ManagementExport } from './management-export';
import type { GarmentRecord } from './garment-record';
import { PickupNoticeStage } from './PickupNoticeStage';
import './today-operations-center.css';

export type TodayOperationsCenterProps = {
  onBack: () => void;
  onOpenHistory: (orderId: string) => void;
  onOpenOrder: (orderId: string) => void;
  onOpenPhoto: (orderId: string, garmentId: string) => void;
  onOpenStoreTest: () => void;
};

type Selection = { orderId: string; garmentId?: string };
type ExportKind = 'json' | 'customers' | 'orders' | 'garments';
const missing = '기록 없음';
const won = (amount: number | null | undefined) =>
  amount == null || !Number.isFinite(amount) ? missing : `${amount.toLocaleString('ko-KR')}원`;
const text = (value: string | null | undefined) => value?.trim() || missing;
const errorText = (cause: unknown) => cause instanceof Error ? cause.message : '작업을 완료하지 못했습니다.';
const intakeDate = (value: string | undefined) => {
  if (!value) return missing;
  try { return koreaCalendarDate(value); } catch { return missing; }
};
const photoAvailability = (garment: GarmentRecord | undefined, role: 'intake' | 'completion') => {
  if (!garment) return missing;
  const unlinked = new Set(garment.unlinkedPhotoIds ?? []);
  const photo = role === 'intake' ? garment.beforePhoto : garment.completionPhoto;
  const all = [photo, ...(garment.photoHistory ?? []).filter((entry) => entry.role === role)]
    .filter((entry) => entry && !unlinked.has(entry.requestId));
  if (all.some((entry) => entry?.status === 'saved')) return '저장 기록 있음 · 이미지 미확인';
  if (all.some((entry) => entry?.status === 'simulated')) return '시뮬레이션 기록만 있음 · 실물 미확인';
  return '사진 기록 없음';
};
const selectionKey = (ref: Selection) => `${ref.orderId}::${ref.garmentId ?? ''}`;

function Fact({ label, value }: { label: string; value: string }) {
  return <div className="toc-fact"><span>{label}</span><strong>{value}</strong></div>;
}

export function TodayOperationsCenter(props: TodayOperationsCenterProps) {
  const [, navigate] = useLocation();
  const [orders, setOrders] = useState<ConfirmedOrder[] | null>(null);
  const [readError, setReadError] = useState('');
  const [exportError, setExportError] = useState('');
  const [exportMessage, setExportMessage] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [asOf, setAsOf] = useState(() => koreaCalendarDate(new Date()));
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [filter, setFilter] = useState<TodayCardKey | null>(null);
  const [selected, setSelected] = useState<Selection | null>(null);

  const refresh = useCallback(() => {
    try {
      const next = readConfirmedOrders();
      setOrders(next);
      setAsOf(koreaCalendarDate(new Date()));
      setUpdatedAt(new Date().toLocaleString('ko-KR'));
      setReadError('');
    } catch (cause) {
      setReadError(errorText(cause));
      // Keep the last successfully read snapshot visible, clearly marked as stale.
    }
  }, []);
  useEffect(() => {
    refresh();
    window.addEventListener('focus', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener('focus', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, [refresh]);

  const summary = useMemo(() => orders === null ? null : todayOperationsSummary(orders, asOf), [orders, asOf]);
  // Completion and uncollected reminders are listed once in the customer notice stage (latest stage only).
  const pendingNotices = useMemo(() => orders === null ? [] : pendingCustomerNotices(orders,
    new Date(`${asOf}T12:00:00+09:00`)), [orders, asOf]);
  const warnings = useMemo(() => orders === null ? [] : todayAttentionWarnings(orders, asOf), [orders, asOf]);
  const quality = useMemo(() => orders === null ? null : todayDataQualityReport(orders), [orders]);
  const board = useMemo(() => orders === null ? [] : todayPickupDeliveryBoard(orders, asOf), [orders, asOf]);
  const nextActions = useMemo(() => orders === null ? [] : recommendedNextActions(orders), [orders]);
  const activeCard = summary?.cards.find((card) => card.key === filter);
  const tasks: TodayFilterRecord[] = activeCard?.records ?? nextActions.map((action) => ({
    orderId: action.orderId, garmentId: action.garmentId, customerName: action.customerName,
    itemName: action.itemName, currentStatus: action.currentStatus,
  }));

  const chosenOrder = selected && orders?.find((order) => order.id === selected.orderId);
  const chosenGarment = selected?.garmentId
    ? chosenOrder?.garments?.find((garment) => garment.garmentId === selected.garmentId)
    : chosenOrder?.garments?.length === 1 ? chosenOrder.garments[0] : undefined;
  const chosenAction = selected && (nextActions.find((action) =>
    action.orderId === selected.orderId && action.garmentId === (chosenGarment?.garmentId ?? selected.garmentId))
    ?? nextActions.find((action) => action.orderId === selected.orderId));
  const operations = chosenOrder ? currentOperations(chosenOrder) : null;
  const service = chosenGarment?.serviceType
    ?? (chosenOrder?.choices.unitServiceLevels ? '세탁물별 선택 · 의류를 선택해 확인' : chosenOrder?.choices?.serviceLevel);
  const fulfillment = chosenOrder
    ? [chosenOrder.choices.pickupRequested ? '수거' : null,
      chosenOrder.choices.deliveryRequested ? '배달' : chosenOrder.choices.directPickup ? '직접수령' : null]
      .filter(Boolean).join(' · ') || missing
    : missing;
  const approval = chosenOrder?.inspection
    ? chosenOrder.inspection.needsApproval
      ? chosenOrder.inspection.response?.choice
        ? `${chosenOrder.inspection.response.choice} · ${chosenOrder.inspection.response.decisions?.join(', ') || '세부 동의 기록 없음'}`
        : '고객 승인 기록 없음'
      : '추가 승인 요구 없음'
    : '전문 검수 기록 없음';
  const paid = operations?.paymentStatus === '결제완료' && operations.paidAt
    ? won(operations.paidAmount) : missing;

  const download = (kind: ExportKind) => {
    setExportMessage('');
    setExportError('');
    if (!confirmed) {
      setExportError('개인정보 및 사진 백업 범위를 확인하고 내보내기에 동의해 주세요.');
      return;
    }
    try {
      // Re-read immediately before export: never silently download an old screen snapshot.
      const latest = readConfirmedOrders();
      const data: ManagementExport = createManagementExport(latest);
      const suffix = `${koreaCalendarDate(new Date())}-${new Date().toISOString().replace(/\D/g, '').slice(8, 14)}`;
      const payload = kind === 'json' ? data.json : `\uFEFF${data.csv[kind]}`;
      const filename = `k99-management-${kind}-${suffix}.${kind === 'json' ? 'json' : 'csv'}`;
      const url = URL.createObjectURL(new Blob([payload], {
        type: kind === 'json' ? 'application/json;charset=utf-8' : 'text/csv;charset=utf-8',
      }));
      try {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setExportMessage(`${filename} 다운로드를 요청했습니다. 파일 저장 위치를 확인해 주세요.`);
      } finally {
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
    } catch (cause) {
      setExportError(`내보내기 실패: ${errorText(cause)}. 저장된 기록을 다시 확인해 주세요.`);
    }
  };

  return <main className="today-operations" data-testid="today-operations-center">
    <div className="toc-wrap">
      <header className="toc-top">
        <div className="toc-brand"><span className="toc-brand-mark">K99</span><div><strong>품격세탁소 · 과천점</strong><small>STAFF / OPERATIONS CENTER</small></div></div>
        <div className="toc-top-actions">
          <button type="button" onClick={refresh} data-testid="button-refresh-today"><RefreshCw /> 기록 새로고침</button>
          <button type="button" onClick={props.onBack} data-testid="button-back-today"><ArrowLeft /> 관리센터로</button>
        </div>
      </header>
      <div className="toc-heading">
        <div><h1>오늘의 업무센터</h1><p>조회·새로고침은 저장 기록을 변경하지 않습니다. 안내 초안은 직원이 준비를 선택할 때만 저장하며 자동 발송하지 않습니다.</p></div>
        <div className="toc-heading-actions"><span className="toc-asof" data-testid="text-today-asof">{asOf} 기준<br />{updatedAt ? `마지막 확인 ${updatedAt}` : '기록 확인 중'}</span><button type="button" onClick={props.onOpenStoreTest} data-testid="button-open-store-test"><ClipboardList /> 매장 장비 테스트 <ArrowRight /></button></div>
      </div>
      {readError && <div className="toc-alert" role="alert" data-testid="status-today-read-error"><span>저장 기록 읽기 실패: {readError}. {orders ? '이전 읽기 결과를 표시 중이며 최신 기록이 아닐 수 있습니다.' : '표시할 기록이 없습니다.'}</span><button type="button" onClick={refresh} data-testid="button-retry-today">다시 시도</button></div>}
      {orders && <section className="toc-panel toc-stages" aria-label="고객 안내 단계" data-testid="today-message-stages">
        <h2>고객 안내 단계</h2>
        <PickupNoticeStage orders={orders} asOf={asOf} disabled={!!readError} onChanged={refresh} />
        <ol>{(() => {
          const all = orders.flatMap((o) => o.customerNotifications ?? []);
          const rows: [string, number][] = [
            ['초안 · 직원 검토 대기', all.filter((n) => !n.approvalAt && !n.externalSendConfirmation).length],
            ['직원 승인 · 미발송', all.filter((n) => n.approvalAt && !n.sendPreparationAt && !n.externalSendConfirmation).length],
            ['발송 준비 · 실제 발송 미확인', all.filter((n) => n.sendPreparationAt && !n.externalSendConfirmation).length],
            ['직원이 외부 발송 확인', all.filter((n) => n.externalSendConfirmation && !n.manualReply).length],
            ['고객 회신 기록됨', all.filter((n) => n.manualReply).length],
          ];
          return rows.map(([label, n]) => <li key={label}><span>{label}</span><strong>{n}건</strong></li>);
        })()}</ol>
        <p>발송 확인은 직원이 직접 기록한 경우만 집계합니다. 이 앱은 문자를 보내지 않습니다.</p>
      </section>}
      <section className="toc-panel" aria-labelledby="pending-sns-title" data-testid="pending-customer-sns">
        <h2 id="pending-sns-title">SNS 미발송 고객 · {pendingNotices.length}건</h2>
        <p>수거 예약·배달 일정 안내입니다. 세탁 완료 후 수거·배달 안내와 9·13일차 미수거 안내는 위 고객 안내 단계에 표시됩니다. 승인·발송 준비·문안 복사만으로는 목록에서 제외하지 않습니다.
          외부 발송을 실제 확인한 직원의 기록이 있어야 제외됩니다. 자동 발송하지 않습니다.</p>
        {orders === null ? <p>저장 기록 확인 중</p> : pendingNotices.length === 0 ? <p>현재 대상인 미발송 안내가 없습니다.</p> :
          pendingNotices.map(({ orderId, customerName, customerPhone, notification, label }) => <div
            key={`${orderId}-${notification.id}`} data-testid={`pending-sns-${notification.id}`}>
            <strong>{customerName} · {customerPhone} · {label}</strong>
            <p>{notification.sendPreparationAt ? '발송 준비됨 · 실제 발송 미확인'
              : notification.approvalAt ? '직원 승인됨 · 미발송' : '직원 검토 대기 · 미발송'}</p>
            <button type="button" disabled={!!readError} onClick={() => {
              try {
                const original = readConfirmedOrders().find(order => order.id === orderId);
                if (!original) throw new Error('주문이 변경되었습니다. 기록을 새로고침해 주세요.');
                const prepared = prepareOperationalNoticeReview(original, notification);
                if (prepared.order !== original) updateSavedOrder(prepared.order, original);
                navigate(`/?operations=1&orderId=${encodeURIComponent(orderId)}&noticeId=${encodeURIComponent(prepared.noticeId)}`);
              } catch (cause) { setReadError(errorText(cause)); }
            }}>초안 준비·검토 열기</button>
          </div>)}
      </section>
      {orders === null && !readError && <div className="toc-cards" aria-label="기록을 읽는 중">{Array.from({ length: 4 }, (_, i) => <div key={i} className="toc-skeleton" />)}</div>}
      {summary && <section className="toc-summary" aria-labelledby="toc-summary-title">
        <div className="toc-section-heading"><div><h2 id="toc-summary-title">오늘 한눈에</h2><p>각 숫자는 해당 의류·주문 기록 수입니다. 카드를 누르면 아래 작업 목록이 좁혀집니다.</p></div><span className="toc-count">12 CATEGORIES</span></div>
        <div className="toc-cards">{summary.cards.map((card) =>
          <button key={card.key} type="button" className="toc-card" data-active={filter === card.key} aria-pressed={filter === card.key}
            onClick={() => { setFilter(card.key); setSelected(null); document.getElementById('toc-tasks')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}
            data-testid={`button-today-card-${card.key}`}>
            <span className="toc-card-top"><span>{card.label}</span><ArrowRight /></span>
            <strong data-testid={`count-today-${card.key}`}>{card.count}</strong><small>{card.count ? '해당 기록 보기' : '해당 기록 없음'}</small>
          </button>)}</div>
      </section>}
      {orders !== null && <div className="toc-layout">
        <div className="toc-main">
          <section className="toc-panel" id="toc-tasks" aria-labelledby="toc-tasks-title">
            <div className="toc-panel-title"><div><h2 id="toc-tasks-title">{activeCard ? activeCard.label : '전체 작업 기록'}</h2><p>{activeCard ? '선택한 지표에 해당하는 저장 기록' : '의류별 현재 상태와 다음 확인 지점'}</p></div>
              <div className="toc-top-actions"><span className="toc-count" data-testid="count-today-tasks">{tasks.length}건</span>{filter && <button type="button" className="toc-ghost" onClick={() => { setFilter(null); setSelected(null); }} data-testid="button-clear-today-filter">전체 보기</button>}</div></div>
            <div className="toc-list">{tasks.length ? tasks.map((record, index) => {
              const ref = { orderId: record.orderId, garmentId: record.garmentId };
              const action = nextActions.find((item) => item.orderId === ref.orderId && item.garmentId === ref.garmentId);
              return <button type="button" className="toc-row" data-selected={selected ? selectionKey(selected) === selectionKey(ref) : false}
                key={`${selectionKey(ref)}-${index}`} onClick={() => setSelected(ref)} data-testid={`button-today-task-${index}`}>
                <span className="toc-row-top"><strong>{text(record.customerName)} · {text(record.itemName)}</strong><small>{record.currentStatus}</small></span>
                <em>다음 확인 · {action?.action ?? '현재 상태 확인 필요'}</em>
              </button>;
            }) : <div className="toc-empty" data-testid="status-today-tasks-empty">{activeCard ? '이 항목에 해당하는 기록이 없습니다.' : '저장된 작업 기록이 없습니다.'}</div>}</div>
          </section>
          <details className="toc-panel toc-attention" aria-labelledby="toc-attention-title" data-testid="today-attention">
            <summary className="toc-panel-title"><div><h2 id="toc-attention-title">확인 필요 {warnings.length}건 ▾</h2><p>알림은 직원 확인용입니다. 기록을 자동 수정하지 않습니다.</p></div><span className="toc-count" data-testid="count-today-warnings">{warnings.length}건</span></summary>
            <div className="toc-list">{warnings.length ? warnings.map((warning, index) => {
              const ref = { orderId: warning.orderId, garmentId: warning.garmentId };
              return <button type="button" className="toc-row" key={`${warning.type}-${selectionKey(ref)}-${index}`}
                data-selected={selected ? selectionKey(selected) === selectionKey(ref) : false} onClick={() => setSelected(ref)}
                data-testid={`button-today-warning-${index}`}>
                <span className="toc-row-top"><strong>{warning.title}</strong><small>확인 필요</small></span>
                <em>{warning.message}</em>
              </button>;
            }) : <div className="toc-empty" data-testid="status-today-warnings-empty">현재 감지된 확인 항목이 없습니다.</div>}</div>
          </details>
          <section className="toc-panel" aria-labelledby="toc-board-title">
            <div className="toc-panel-title"><div><h2 id="toc-board-title">오늘 수거·배달</h2><p>기록된 날짜가 오늘인 건만 표시합니다. 일정이 없는 건은 임의로 배정하지 않습니다.</p></div><span className="toc-count" data-testid="count-today-board">{board.length}건</span></div>
            {board.length ? board.map((record, index) => <article className="toc-board-row" key={`${record.orderId}-${index}`} data-testid={`row-today-board-${index}`}>
              <div className="toc-row-top"><strong>{text(record.customerName)} <span className="toc-muted">· {record.customerPhoneLast4 || missing}</span></strong><small>{record.kind}</small></div>
              <div className="toc-board-meta">
                <span>주소 · {text(record.address)}</span>
                <span>요청 · {record.requestedDate || missing}{record.requestedTime ? ` ${record.requestedTime}` : ' · 시간 미기록'}</span><span>세탁물 · {record.itemCount}점</span>
                <span>준비 · {record.readiness}</span><span>결제 · {record.paymentStatus}{record.additionalAmount != null ? ` · 검수 추가금 ${won(record.additionalAmount)}` : ''}</span>
              </div>
              <p>직원 참고 메모 · {text(record.staffNote)}</p>
              <button type="button" onClick={() => setSelected({ orderId: record.orderId })} data-testid={`button-today-board-${index}`}>빠른 보기 <ArrowRight /></button>
            </article>) : <div className="toc-empty" data-testid="status-today-board-empty">오늘로 기록된 수거·배달 일정이 없습니다.</div>}
          </section>
          <details className="toc-panel toc-admin" data-testid="today-admin-menu"><summary><h2>관리자 메뉴 · 데이터 점검·내보내기</h2></summary>
          <section className="toc-panel toc-quality" aria-labelledby="toc-quality-title">
            <div className="toc-panel-title"><div><h2 id="toc-quality-title">데이터 점검</h2><p>발견된 문제만 표시합니다. 고객 정보를 자동 수정하거나 삭제하지 않습니다.</p></div><span className="toc-count" data-testid="count-today-quality">{quality?.totalFindings ?? 0}건</span></div>
            <div className="toc-quality-list">{quality?.checks.map((check) => <details key={check.key} data-testid={`quality-check-${check.key}`}>
              <summary>{check.label}<strong>{check.count}건</strong></summary>
              <ul>{check.affectedRecords.length ? check.affectedRecords.map((finding, index) => <li key={`${finding.orderId}-${finding.garmentId ?? ''}-${index}`}>
                <button type="button" className="toc-quality-record" onClick={() => setSelected({ orderId: finding.orderId, garmentId: finding.garmentId })} data-testid={`button-quality-${check.key}-${index}`}>
                  기록 {index + 1} 확인 <ArrowRight />
                </button><p>{finding.message}</p>
              </li>) : <li className="toc-muted">해당 기록 없음</li>}</ul>
            </details>)}</div>
          </section>
          <section className="toc-panel" aria-labelledby="toc-export-title">
            <div className="toc-panel-title"><div><h2 id="toc-export-title">데이터 백업/내보내기</h2><p>이 브라우저의 저장 기록을 휴대 가능한 파일로 내보냅니다.</p></div><Download /></div>
            <p className="toc-export-copy">JSON에는 주문·고객·의류 및 검수, 승인, 세탁·재세탁, 수거·배달, 인도, 사진·주석 메타데이터와 감사 이력이 포함됩니다. CSV는 고객 / 주문 / 의류를 각각 별도 파일로 제공합니다.</p>
            <div className="toc-export-warning"><ShieldAlert size={15} /> 내보낸 로컬 파일에는 이름, 전화번호, 주소 등 개인정보가 포함됩니다. 안전한 위치에 보관하세요. 이 파일에는 사진 메타데이터만 있으며 Windows의 실제 사진 파일은 백업되지 않습니다. 이 작업은 매장 PC 백업 완료를 의미하지 않습니다.</div>
            <label className="toc-confirm"><input type="checkbox" checked={confirmed} onChange={(event) => setConfirmed(event.target.checked)} data-testid="input-confirm-export" /><span>개인정보 포함 및 Windows 사진 파일 미백업을 확인했습니다. 파일 다운로드에 동의합니다.</span></label>
            <div className="toc-export-actions">
              {([['json', '전체 JSON'], ['customers', '고객 CSV'], ['orders', '주문 CSV'], ['garments', '의류 CSV']] as const).map(([kind, label]) =>
                <button type="button" key={kind} disabled={!confirmed || !!readError} onClick={() => download(kind)}
                  className={kind === 'json' ? 'toc-primary' : ''} data-testid={`button-export-${kind}`}><Download /> {label}</button>)}
            </div>
            <p className="toc-export-note">접수 예상금액·검수 변경 예상금액과 실제 결제액은 구분된 필드입니다. 예상금액을 매출로 간주하지 마세요.</p>
            {exportError && <div className="toc-alert" role="alert" data-testid="status-today-export-error">{exportError}</div>}
            {exportMessage && <p role="status" data-testid="status-today-export-success">{exportMessage}</p>}
          </section>
          </details>
        </div>
        <aside className="toc-side">
          <section className="toc-panel toc-quick" aria-labelledby="toc-quick-title">
            <div className="toc-panel-title"><div><h2 id="toc-quick-title">주문 빠른 보기</h2></div></div>
            {!selected ? <div className="toc-quick-empty">작업, 확인 항목, 수거·배달 또는 점검 기록을 선택하면 상세 내용을 볼 수 있습니다.</div>
              : !chosenOrder ? <div className="toc-quick-empty" role="status">이 주문을 현재 읽은 기록에서 찾을 수 없습니다. 새로고침해 주세요.</div>
                : <>
                  <div className="toc-quick-name"><div><strong data-testid="text-today-customer">{text(chosenOrder.customerName)}</strong><span> · 전화번호 뒤 4자리 {(chosenOrder.customerPhone || '').replace(/\D/g, '').slice(-4) || missing}</span></div></div>
                  <div className="toc-facts">
                    
                    <Fact label="접수일" value={intakeDate(chosenOrder.intakeAt)} />
                    <Fact label="품목" value={chosenGarment?.itemName || chosenOrder.items?.map((item) => item.displayNameKo).join(', ') || missing} />
                    <Fact label="대상" value={chosenGarment ? chosenGarment.itemName : (chosenOrder.garments?.length ? '주문 전체 · 의류 선택 필요' : missing)} />
                    <Fact label="현재 상태" value={chosenGarment
                      ? garmentDisplayStatus(chosenOrder, chosenGarment, chosenAction?.currentStatus || chosenGarment.processStatus || chosenOrder.status)
                      : orderDisplayStatus(chosenOrder)} />
                    <Fact label="서비스 종류" value={service || missing} />
                    <Fact label="현재 금액 · 주문 접수 예상" value={won(chosenOrder.estimatedTotal)} />
                    <Fact label="변경 금액 · 검수 후 예상" value={chosenOrder.inspection && chosenOrder.inspection.revisedPrice !== chosenOrder.inspection.originalPrice ? won(chosenOrder.inspection.revisedPrice) : '변경 기록 없음'} />
                    <Fact label="실제 결제액" value={paid} />
                    <Fact label="고객 승인" value={approval} />
                    <Fact label="세탁 전 사진" value={photoAvailability(chosenGarment, 'intake')} />
                    <Fact label="세탁 후 사진" value={photoAvailability(chosenGarment, 'completion')} />
                    <Fact label="수령 방식" value={fulfillment} />
                    <Fact label="결제 상태" value={operations?.paymentStatus || missing} />
                  </div>
                  <div className="toc-next"><small>권장 다음 행동 · 안내만 제공</small><strong data-testid="text-today-next-action">{chosenAction?.action || '현재 상태 확인 필요'}</strong><span>이 화면에서 주문이나 의류 상태를 변경하지 않습니다.</span></div>
                  <div className="toc-quick-actions">
                    <button type="button" className="toc-primary" onClick={() => props.onOpenHistory(chosenOrder.id)} data-testid="button-today-open-history">전체 이력 보기 <ExternalLink /></button>
                    <button type="button" onClick={() => props.onOpenOrder(chosenOrder.id)} data-testid="button-today-open-order">주문 열기 <ArrowRight /></button>
                    {chosenGarment?.garmentId && <button type="button" onClick={() => props.onOpenPhoto(chosenOrder.id, chosenGarment.garmentId)} data-testid="button-today-open-photo">사진 보기 <ArrowRight /></button>}
                  </div>
                </>}
          </section>
        </aside>
      </div>}
    </div>
  </main>;
}

export default TodayOperationsCenter;