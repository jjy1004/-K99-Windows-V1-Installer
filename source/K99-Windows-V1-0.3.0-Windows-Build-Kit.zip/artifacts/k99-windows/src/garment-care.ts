import type {
  GarmentAnnotationRevision,
  GarmentAnnotationShape,
  GarmentAuditEvent,
  GarmentCareProcess,
  GarmentCareSummary,
  GarmentPhotoMetadata,
  GarmentRecord,
  NormalizedPoint,
} from './garment-record.ts';
import { activePhotosOf } from './manual-photo-link.ts';

export const DEFAULT_CARE_PROCESSES = [
  '색빠짐 방지 가공', '이염 방지 가공', '자연건조', '맞춤 물세탁', '드라이클리닝',
  '특수 얼룩 제거', '복원 세탁', '탈취 가공', '항균 가공', '형태 안정 가공',
  '발수 가공', '수작업 마무리', '다림질', '기타',
] as const;

const timestamp = (at: Date | string): string => {
  const value = at instanceof Date ? at.toISOString() : at;
  if (!Number.isFinite(Date.parse(value))) throw new Error('기록 시각을 확인해 주세요.');
  return new Date(value).toISOString();
};

function validateGarment(garment: GarmentRecord): void {
  if (!garment.garmentId || !garment.orderId) throw new Error('의류 ID와 주문 연결 정보를 확인해 주세요.');
}

function allPhotosOf(garment: GarmentRecord): readonly GarmentPhotoMetadata[] {
  const photos = garment.photoHistory ?? [];
  return [
    ...(garment.beforePhoto && !photos.some((photo) => photo.requestId === garment.beforePhoto!.requestId)
      ? [garment.beforePhoto] : []),
    ...photos,
    ...(garment.completionPhoto && !photos.some((photo) => photo.requestId === garment.completionPhoto!.requestId)
      ? [garment.completionPhoto] : []),
  ];
}

function findPhoto(garment: GarmentRecord, photoRequestId: string): GarmentPhotoMetadata {
  const photo = activePhotosOf(garment).find((item) => item.requestId === photoRequestId);
  if (!photo || photo.garmentId !== garment.garmentId)
    throw new Error('현재 의류에 연결된 사진을 찾을 수 없습니다.');
  return photo;
}

/** Add photo metadata only; image bytes are never accepted or persisted by this module. */
export function addGarmentPhoto(garment: GarmentRecord, photo: GarmentPhotoMetadata): GarmentRecord {
  validateGarment(garment);
  if (photo.garmentId !== garment.garmentId || !photo.requestId ||
      !['intake', 'completion'].includes(photo.role) || !['saved', 'simulated'].includes(photo.status))
    throw new Error('사진 메타데이터와 의류 연결 정보를 확인해 주세요.');
  if (!Number.isFinite(Date.parse(photo.timestamp))) throw new Error('사진 촬영 시각을 확인해 주세요.');
  const existing = allPhotosOf(garment).find((item) => item.requestId === photo.requestId);
  if (existing) {
    if (JSON.stringify(existing) === JSON.stringify(photo)) return garment;
    throw new Error('같은 사진 요청 ID에 다른 메타데이터를 연결할 수 없습니다.');
  }
  const metadata = Object.freeze({
    ...photo,
    ...(photo.annotations ? { annotations: Object.freeze(structuredClone(photo.annotations)) } : {}),
  });
  const photoHistory = [...(garment.photoHistory ?? []), metadata];
  const audit: GarmentAuditEvent = {
    at: timestamp(photo.timestamp), type: photo.role === 'completion' ? 'completion-photo' : 'photo',
    status: photo.status, details: photo.origin === 'simulation' ? '시뮬레이션 저장' : '사진 메타데이터 연결',
    orderId: garment.orderId, garmentId: garment.garmentId,
  };
  return {
    ...garment,
    photoHistory,
    ...(photo.role === 'intake' && !garment.beforePhoto ? { beforePhoto: metadata } : {}),
    ...(photo.role === 'completion' ? { completionPhoto: metadata } : {}),
    // Legacy photoStatus describes the intake capture. Completion metadata must
    // not make the existing camera/tag flow think an intake photo was captured.
    photoStatus: photo.role === 'intake' ? photo.status : garment.photoStatus,
    auditEvents: [...garment.auditEvents, audit],
  };
}

/** Select a representative BEFORE photo without modifying any photo metadata. */
export function selectPhoto(garment: GarmentRecord, photoRequestId: string, at = new Date()): GarmentRecord {
  const photo = findPhoto(garment, photoRequestId);
  if (photo.role !== 'intake') throw new Error('대표 BEFORE 사진은 접수 사진에서 선택해 주세요.');
  if (garment.representativeBeforePhotoId === photoRequestId) return garment;
  const savedAt = timestamp(at);
  return {
    ...garment,
    representativeBeforePhotoId: photoRequestId,
    auditEvents: [...garment.auditEvents, {
      at: savedAt, type: 'photo-selection', status: 'selected', orderId: garment.orderId,
      garmentId: garment.garmentId, details: '대표 BEFORE 사진 선택',
    }],
  };
}

function point(value: NormalizedPoint): boolean {
  return Number.isFinite(value.x) && Number.isFinite(value.y) && value.x >= 0 && value.x <= 1 && value.y >= 0 && value.y <= 1;
}

function validateShape(shape: GarmentAnnotationShape): void {
  if (!shape.id || !['pen', 'circle', 'rectangle', 'arrow', 'text'].includes(shape.type))
    throw new Error('주석 도형 정보를 확인해 주세요.');
  if (shape.type === 'pen') {
    if (shape.points.length < 1 || shape.points.some((item) => !point(item)))
      throw new Error('펜 좌표는 0~1 사이의 정규화 좌표여야 합니다.');
  } else if (!point({ x: shape.x, y: shape.y })) {
    throw new Error('주석 좌표는 0~1 사이의 정규화 좌표여야 합니다.');
  }
  if (shape.type === 'circle' || shape.type === 'rectangle' || shape.type === 'arrow') {
    if (![shape.width, shape.height].every((size) => Number.isFinite(size) && size >= 0 && size <= 1)
      || shape.x + shape.width > 1 || shape.y + shape.height > 1)
      throw new Error('주석 크기는 이미지 범위 안의 정규화 값이어야 합니다.');
  }
  if (shape.type === 'text' && !shape.text.trim()) throw new Error('텍스트 주석을 입력해 주세요.');
}

function cloneShape(shape: GarmentAnnotationShape): GarmentAnnotationShape {
  return shape.type === 'pen'
    ? Object.freeze({ ...shape, points: Object.freeze(shape.points.map((item) => Object.freeze({ ...item }))) })
    : Object.freeze({ ...shape });
}

/** Append a per-photo immutable annotation snapshot. Image/photo metadata is untouched. */
export function saveAnnotation(
  garment: GarmentRecord,
  photoRequestId: string,
  shapes: readonly GarmentAnnotationShape[],
  at = new Date(),
): GarmentRecord {
  const photo = findPhoto(garment, photoRequestId);
  if (photo.role !== 'intake') throw new Error('주석은 접수 원본 사진에만 저장할 수 있습니다.');
  shapes.forEach(validateShape);
  if (new Set(shapes.map((shape) => shape.id)).size !== shapes.length)
    throw new Error('한 주석 버전 안에서 도형 ID는 서로 달라야 합니다.');
  const previous = (garment.annotationRevisions ?? []).filter((item) => item.photoRequestId === photoRequestId);
  const latest = previous.at(-1);
  if (latest && JSON.stringify(latest.shapes) === JSON.stringify(shapes)) return garment;
  const revision: GarmentAnnotationRevision = Object.freeze({
    garmentId: garment.garmentId, photoRequestId, revision: (latest?.revision ?? 0) + 1,
    savedAt: timestamp(at), shapes: Object.freeze(shapes.map(cloneShape)),
  });
  return {
    ...garment,
    annotationRevisions: [...(garment.annotationRevisions ?? []), revision],
    auditEvents: [...garment.auditEvents, {
      at: revision.savedAt, type: 'annotation-save', status: 'saved', orderId: garment.orderId,
      garmentId: garment.garmentId, details: `사진 주석 revision ${revision.revision}`,
    }],
  };
}

/** UI-local selection helper; it does not persist a selection or modify a saved revision. */
export function selectAnnotation(shapes: readonly GarmentAnnotationShape[], shapeId: string): GarmentAnnotationShape | null {
  return shapes.find((shape) => shape.id === shapeId) ?? null;
}

/** UI-local move helper returning a replacement array with normalized coordinates. */
export function moveAnnotation(
  shapes: readonly GarmentAnnotationShape[], shapeId: string, dx: number, dy: number,
): GarmentAnnotationShape[] {
  if (![dx, dy].every(Number.isFinite)) throw new Error('이동 거리를 확인해 주세요.');
  return shapes.map((shape) => {
    if (shape.id !== shapeId) return shape;
    const moved = shape.type === 'pen'
      ? { ...shape, points: shape.points.map((item) => ({ x: item.x + dx, y: item.y + dy })) }
      : { ...shape, x: shape.x + dx, y: shape.y + dy };
    validateShape(moved);
    return moved;
  });
}

/** UI-local erase helper. Persist removal as a new saved snapshot, not an in-place edit. */
export function eraseAnnotation(shapes: readonly GarmentAnnotationShape[], shapeId: string): GarmentAnnotationShape[] {
  return shapes.filter((shape) => shape.id !== shapeId);
}

/** UI-local undo/redo snapshots suitable for a component state stack. */
export type AnnotationHistory = Readonly<{
  past: readonly (readonly GarmentAnnotationShape[])[];
  present: readonly GarmentAnnotationShape[];
  future: readonly (readonly GarmentAnnotationShape[])[];
}>;

export function createAnnotationHistory(shapes: readonly GarmentAnnotationShape[] = []): AnnotationHistory {
  return { past: [], present: shapes.map(cloneShape), future: [] };
}

export function pushAnnotationSnapshot(history: AnnotationHistory, shapes: readonly GarmentAnnotationShape[]): AnnotationHistory {
  return { past: [...history.past, history.present], present: shapes.map(cloneShape), future: [] };
}

export function undoAnnotation(history: AnnotationHistory): AnnotationHistory {
  const previous = history.past.at(-1);
  return previous ? { past: history.past.slice(0, -1), present: previous, future: [history.present, ...history.future] } : history;
}

export function redoAnnotation(history: AnnotationHistory): AnnotationHistory {
  const next = history.future[0];
  return next ? { past: [...history.past, history.present], present: next, future: history.future.slice(1) } : history;
}

export function generateCareSummary(garment: GarmentRecord): string {
  const processes = garment.careProcesses ?? [];
  if (processes.length === 0) return '기록된 케어 공정이 없습니다.';
  const names = processes.map((item) => item.process);
  return `실제 기록된 케어 공정: ${names.join(', ')}. 총 ${names.length}단계의 케어를 기록했습니다.`;
}

export function addActualCareProcess(
  garment: GarmentRecord,
  input: { id: string; process: string; source: string; note?: string; staff?: string },
  at = new Date(),
): GarmentRecord {
  validateGarment(garment);
  const id = input.id.trim();
  const processName = input.process.trim();
  const source = input.source.trim();
  const note = input.note?.trim() ?? '';
  const staff = input.staff?.trim() ?? '';
  if (!id || !processName || !source || processName.length > 100 || source.length > 100
    || (input.note?.length ?? 0) > 500 || (input.staff?.length ?? 0) > 100)
    throw new Error('실제로 수행한 공정과 기록 출처를 확인해 주세요.');
  const existing = (garment.careProcesses ?? []).find((item) => item.id === id);
  if (existing) {
    const same = existing.garmentId === garment.garmentId && existing.process === processName
      && existing.source === source && existing.note === (note || undefined) && existing.staff === (staff || undefined);
    if (same) return garment;
    throw new Error('같은 케어 기록 ID에 다른 공정을 중복 연결할 수 없습니다.');
  }
  const process: GarmentCareProcess = Object.freeze({
    id, garmentId: garment.garmentId, process: processName, at: timestamp(at), source,
    ...(note ? { note } : {}),
    ...(staff ? { staff } : {}),
  });
  const careProcesses = [...(garment.careProcesses ?? []), process];
  const generatedText = generateCareSummary({ ...garment, careProcesses });
  const careSummary: GarmentCareSummary = {
    generatedText, updatedAt: process.at,
  };
  return {
    ...garment, careProcesses, careSummary,
    auditEvents: [...garment.auditEvents, {
      at: process.at, type: 'care-process', status: 'recorded', orderId: garment.orderId,
      garmentId: garment.garmentId, source: 'manual',
      details: `${processName}${process.note ? ` · ${process.note}` : ''}`,
    }],
  };
}

export function updateCareSummary(garment: GarmentRecord, editedText: string, at = new Date()): GarmentRecord {
  if (editedText.length > 2000) throw new Error('고객 안내 케어 요약은 2,000자 이내로 입력해 주세요.');
  const generatedText = generateCareSummary(garment);
  const edited = editedText.trim();
  if (garment.careSummary?.generatedText === generatedText && garment.careSummary.editedText === edited) return garment;
  const savedAt = timestamp(at);
  return {
    ...garment, careSummary: { generatedText, editedText: edited, updatedAt: savedAt },
    auditEvents: [...garment.auditEvents, {
      at: savedAt, type: 'care-summary', status: 'updated', orderId: garment.orderId,
      garmentId: garment.garmentId, details: '고객용 케어 요약 수정',
    }],
  };
}

export function updateCompletionComment(garment: GarmentRecord, comment: string, at = new Date()): GarmentRecord {
  if (comment.length > 2000) throw new Error('완성 코멘트는 2,000자 이내로 입력해 주세요.');
  const savedAt = timestamp(at);
  const trimmed = comment.trim();
  if (trimmed === (garment.completionComment ?? '')) return garment;
  return {
    ...garment, completionComment: trimmed,
    auditEvents: [...garment.auditEvents, {
      at: savedAt, type: 'completion-comment', status: 'updated', orderId: garment.orderId,
      garmentId: garment.garmentId, details: '완성 코멘트 수정',
    }],
  };
}

export type CustomerSafeCareResult = Readonly<{
  brand: string;
  garmentName: string;
  beforePhoto: { role: 'intake'; timestamp: string; simulated: boolean } | null;
  afterPhotos: readonly { role: 'completion'; timestamp: string; simulated: boolean }[];
  beforeAnnotations: readonly PublicAnnotationShape[];
  careProcesses: readonly string[];
  careSummary: string;
  completionComment: string;
  intakeCondition: string;
}>;

type PublicAnnotationShape = GarmentAnnotationShape extends infer Shape
  ? Shape extends { id: string } ? Omit<Shape, 'id'> : never
  : never;

/** Explicit allowlist for a customer screen/result card; no IDs, paths, sources or staff notes. */
export function getCustomerSafeResult(
  garment: GarmentRecord,
  context: { garmentName?: string; intakeCondition?: string; storeName?:string } = {},
): CustomerSafeCareResult {
  const allPhotos = activePhotosOf(garment);
  const representativeId = garment.representativeBeforePhotoId
    ?? garment.beforePhoto?.requestId
    ?? allPhotos.find((photo) => photo.role === 'intake')?.requestId;
  const before = representativeId ? allPhotos.find((photo) =>
    photo.requestId === representativeId && photo.role === 'intake' && photo.garmentId === garment.garmentId) : undefined;
  const revision = before ? (garment.annotationRevisions ?? []).filter((item) =>
    item.garmentId === garment.garmentId && item.photoRequestId === before.requestId).at(-1) : undefined;
  const publicShape = (shape: GarmentAnnotationShape): PublicAnnotationShape => {
    if (shape.type === 'pen') return { type: shape.type, points: shape.points.map((item) => ({ ...item })) };
    if (shape.type === 'text') return { type: shape.type, x: shape.x, y: shape.y, text: shape.text };
    return { type: shape.type, x: shape.x, y: shape.y, width: shape.width, height: shape.height };
  };
  return {
    brand: context.storeName?.trim()||'K99세탁매장',
    garmentName: context.garmentName ?? garment.itemName,
    beforePhoto: before ? {
      role: 'intake', timestamp: before.timestamp, simulated: before.status === 'simulated',
    } : null,
    afterPhotos: allPhotos.filter((photo) => photo.role === 'completion' && photo.garmentId === garment.garmentId)
      .sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp))
      .map((photo) => ({ role: 'completion' as const, timestamp: photo.timestamp, simulated: photo.status === 'simulated' })),
    beforeAnnotations: (revision?.shapes ?? []).map(publicShape),
    careProcesses: (garment.careProcesses ?? []).filter((item) => item.garmentId === garment.garmentId)
      .map((item) => item.process),
    careSummary: garment.careSummary?.editedText ?? garment.careSummary?.generatedText ?? generateCareSummary(garment),
    completionComment: garment.completionComment ?? '',
    intakeCondition: context.intakeCondition ?? '',
  };
}