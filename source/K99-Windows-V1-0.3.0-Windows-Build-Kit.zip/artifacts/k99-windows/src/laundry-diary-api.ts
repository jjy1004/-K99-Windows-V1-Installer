import { directoryRequest } from './customer-directory-client';
import { noticeApi, type StoreProfile } from './notice-api';

export type Diary = {
  id: string; customer_id: string | null; customer_name: string; customer_phone_last4: string;
  store_name: string; created_at: string; updated_at: string; raw_voice_text: string; content: string;
  customer_summary: string; keywords: string[]; synced_at: string | null;
  ai_voice_text?: string;
};
export type DiaryCustomer = { id: string; name: string; phone: string };
export type DiarySaveInput = {
  id?: string; updated_at?: string; customer_id?: string; store_name: string;
  raw_voice_text: string; content: string; keywords: string[];
  ai_voice_text?: string;
};

export const listDiaries = (query: string) =>
  directoryRequest<{ diaries: Diary[]; pending: number }>('POST', '/api/diaries/list', { query });
export const searchDiaryCustomers = (query: string) =>
  directoryRequest<{ customers: DiaryCustomer[] }>('POST', '/api/diaries/customers', { query });
export const extractDiaryKeywords = (content: string) =>
  directoryRequest<{ keywords: string[] }>('POST', '/api/diaries/keywords', { content });
export const saveDiary = (input: DiarySaveInput) =>
  directoryRequest<{ diary: Diary }>('POST', '/api/diaries/save', input);

export async function loadStoreName(): Promise<string> {
  try { return (await noticeApi<{profile:StoreProfile}>('GET', '/profile')).profile.storeName?.trim() || ''; }
  catch { return ''; }
}
