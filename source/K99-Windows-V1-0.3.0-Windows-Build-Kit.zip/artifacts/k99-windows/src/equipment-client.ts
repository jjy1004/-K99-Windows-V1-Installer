export type EquipmentConfig = {
  mode:'mock'|'real'; printerName:string; labelWidthMm:number; labelHeightMm:number;
  labelVerified:boolean; cameraDeviceId:string; hardwareConfirmed:boolean;
  /** Fixed photo archive root on the store PC. */
  photoArchiveRoot?:string;
  /** Store foot switch is fixed to Enter. */
  footSwitchKey?:import('./desktop-runtime').FootSwitchKey;
};
export const DEFAULT_PHOTO_ARCHIVE_ROOT='C:\\K99세탁매장';
export const DEFAULT_FOOT_SWITCH_KEY='F7' as const;
export type PhotoFolderKind='intake'|'comparison';
/** Opens the customer's archive folder in Windows Explorer (Main uses shell.openPath). */
export function openPhotoFolder(orderId:string,kind:PhotoFolderKind){
  return equipmentRequest<{opened:boolean; folder:string; kind:PhotoFolderKind}>('open-photo-folder',{orderId,kind});
}
/** Saves a rendered Before/After card into the comparison folder of the order. */
export function saveComparison(orderId:string,imageDataUrl:string){
  return equipmentRequest<{photo?:unknown; archive:{folder:string; fileName:string}; job:null}>('save-comparison',{orderId,imageDataUrl});
}
export type EquipmentPhoto = {id:string; orderId:string; garmentId:string; role:'intake'|'completion';
  mode:'mock'|'real'; createdAt:string; url:string; sha256:string};
export type EquipmentJob = {id:string; orderId:string; garmentId:string; requestId:string;
  kind:'auto'|'reprint'; mode:'mock'|'real'; status:'pending'|'submitting'|'simulated'|'submitted'|'failed'|'unknown';
  reason:string; createdAt:string; error:string|null; printerName:string; payload: {
    customerName:string; itemName:string; garmentId:string; serviceType:string;
  }};
export type EquipmentOrder = {id:string; customerName:string; estimatedTotal:number; garments:{
  garmentId:string; itemName:string; barcodeValue:string; serviceType:string;
}[]};
export type EquipmentState = {config:EquipmentConfig; orders:EquipmentOrder[]; photos:EquipmentPhoto[];
  jobs:EquipmentJob[]; native:boolean; display:{connected:boolean; displayId?:string; note?:string};
  printers:{name:string; displayName:string}[]; monitors:{id:string; label:string; primary:boolean}[]};
export type CustomerSnapshot = {revision:number; updatedAt:string; customerName:string;
  orderId:string|null; items:{name:string; quantity:number; amount:number}[];
  total:number; mode:'mock'|'real'; note:string};
export async function equipmentRequest<T = Record<string, unknown>>(action:string, input:Record<string,unknown> = {}):Promise<T> {
  const response = await fetch('/api/equipment/command',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action,...input})});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '장비 작업 실패');
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new StorageEvent('storage',{key:'k99-confirmed-orders-v1'}));
    window.dispatchEvent(new Event('k99-equipment-changed'));
  }
  return result as T;
}
export async function getEquipmentState():Promise<EquipmentState> {
  const response=await fetch('/api/equipment/state');
  if(!response.ok) throw new Error('장비 상태를 읽지 못했습니다.');
  return response.json();
}
export async function getCustomerSnapshot():Promise<CustomerSnapshot> {
  const response=await fetch('/api/equipment/display');
  if(!response.ok) throw new Error('직원 화면 연결을 확인하세요.');
  return response.json();
}
