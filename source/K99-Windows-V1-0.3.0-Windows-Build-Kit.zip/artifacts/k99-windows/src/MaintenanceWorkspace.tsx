import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { NativeLedgerImportPanel } from './NativeLedgerImportPanel';
import { maintenanceCommand, maintenanceStatus, type MaintenanceStatus } from './maintenance-client';
import './equipment.css';
import './maintenance.css';

const PHRASE = 'K99 복구';
const MIN = 16, MAX = 1024;
const errText = (c: unknown, f: string) => (c instanceof Error && c.message ? c.message : f);
const size = (n: number) => n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1024).toFixed(1)} KB`;
const when = (s: string | null) => s ? new Date(s).toLocaleString('ko-KR') : '없음';
const pwInvalid = (p: string, c: string) => p.length < MIN ? `비밀번호는 ${MIN}자 이상이어야 합니다.` : p.length > MAX ? `비밀번호는 ${MAX}자 이하여야 합니다.` : p !== c ? '비밀번호 확인이 일치하지 않습니다.' : '';

export function MaintenanceWorkspace() {
  const [status, setStatus] = useState<MaintenanceStatus | null>(null);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState('');
  const [password, setPassword] = useState('');
  const [selected, setSelected] = useState('');
  const [backupKeyInput, setBackupKeyInput] = useState('');
  const [phrase, setPhrase] = useState('');
  const [restoreCheck, setRestoreCheck] = useState(false);
  const [revealedKey, setRevealedKey] = useState('');
  const [recoveryCode, setRecoveryCode] = useState('');
  const [savedOffline, setSavedOffline] = useState(false);
  const [recInput, setRecInput] = useState('');
  const [newPw, setNewPw] = useState('');
  const [newPw2, setNewPw2] = useState('');
  const [setupPw, setSetupPw] = useState('');
  const [setupPw2, setSetupPw2] = useState('');
  const [schedEnabled, setSchedEnabled] = useState(true);
  const [schedHours, setSchedHours] = useState(24);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const [copyMsg, setCopyMsg] = useState('');
  const draftInit = useRef(false);
  const pollRun = useRef(0);
  const inFlight = useRef(false);
  const busyRef = useRef('');
  busyRef.current = busy;

  const refresh = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    const run = ++pollRun.current;
    try {
      const next = await maintenanceStatus();
      if (run !== pollRun.current) return;
      setStatus(next); setLoadError('');
      if (!draftInit.current) {
        draftInit.current = true;
        setSchedEnabled(next.schedule?.enabled ?? true);
        setSchedHours(next.schedule?.intervalHours || 24);
        setAutoEnabled(!!next.autostart?.enabled);
      }
    } catch (c) { if (run === pollRun.current) setLoadError(errText(c, '보존 상태를 읽지 못했습니다.')); }
    finally { inFlight.current = false; }
  }, []);

  useEffect(() => {
    void refresh();
    const t = window.setInterval(() => { if (!busyRef.current) void refresh(); }, 10000);
    return () => clearInterval(t);
  }, [refresh]);

  const locked = !!busy || !!status?.busy;
  const restoring = busy === '복원';

  async function run<T>(label: string, fn: () => Promise<T>, after?: (r: T) => string | void, onFail?: () => void) {
    if (busyRef.current) return undefined;
    setBusy(label); busyRef.current = label; setMessage(null);
    try {
      const r = await fn();
      const text = after?.(r);
      if (text) setMessage({ kind: 'ok', text });
      return r;
    } catch (c) { onFail?.(); setMessage({ kind: 'error', text: errText(c, `${label} 실패`) }); return undefined; }
    finally {
      setBusy(''); busyRef.current = '';
      pollRun.current++; inFlight.current = false; void refresh();
    }
  }
  const needPw = () => { if (!password) { setMessage({ kind: 'error', text: '관리자 비밀번호를 먼저 입력하세요.' }); return false; } return true; };

  async function setup(e: FormEvent) {
    e.preventDefault();
    const p = setupPw, c = setupPw2; setSetupPw(''); setSetupPw2('');
    const bad = pwInvalid(p, c); if (bad) { setMessage({ kind: 'error', text: bad }); return; }
    await run('관리자 설정', async () => {
      const r = await fetch('/api/desktop/admin/setup', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: p }) });
      if (!r.ok) { let t = ''; try { const b = await r.json(); t = b?.error ?? b?.message ?? ''; } catch { /* none */ } throw new Error(t || `관리자 설정 실패 (HTTP ${r.status})`); }
      return true;
    }, () => '관리자 비밀번호를 설정했습니다. 이어서 복구 코드를 생성해 오프라인으로 보관하세요.');
  }

  const createBackup = () => needPw() && void run('백업', () => maintenanceCommand('backup', { password }),
    r => `암호화 통합 백업 완료 · ${r.backupId}${r.verified ? ' · 검증됨' : ''}`);
  const verify = () => selected && needPw() && void run('검증', () => maintenanceCommand('verify', { password, backupId: selected, ...(backupKeyInput ? { backupKey: backupKeyInput } : {}) }),
    r => `백업 ${selected} 검증 ${r.verified === false ? '실패' : '통과'}`);
  async function restore() {
    if (!selected || phrase !== PHRASE || !restoreCheck || !needPw()) return;
    const r = await run('복원', () => maintenanceCommand('restore', { backupId: selected, ...(backupKeyInput ? { backupKey: backupKeyInput } : {}), confirmation: PHRASE, password }),
      undefined, () => { setPhrase(''); setRestoreCheck(false); });
    if (r && r.restored) {
      setPassword(''); setBackupKeyInput(''); setRevealedKey(''); setRecoveryCode(''); setPhrase(''); setRestoreCheck(false);
      setBusy('복원'); busyRef.current = '복원';
      setMessage({ kind: 'ok', text: `복원 완료. 복원 직전 안전 백업: ${r.safetyBackupId ?? '-'} · 잠시 후 첫 화면으로 다시 불러옵니다.` });
      window.setTimeout(() => window.location.replace('/'), 2500);
    }
  }
  const showKey = () => needPw() && void run('백업 키 표시', () => maintenanceCommand('backup-key', { password }), r => { setRevealedKey(String(r.backupKey ?? '')); setCopyMsg(''); return '백업 키를 표시했습니다. 오프라인으로 기록한 뒤 숨기세요.'; });
  const genRecovery = () => needPw() && void run('복구 코드 생성', () => maintenanceCommand('recovery-key', { password }), r => { setRecoveryCode(String(r.recoveryCode ?? '')); setSavedOffline(false); return '새 복구 코드를 생성했습니다. 이전 복구 코드는 더 이상 쓸 수 없습니다.'; });
  async function recoverPw(e: FormEvent) {
    e.preventDefault();
    const code = recInput.trim(), p = newPw, c = newPw2; setNewPw(''); setNewPw2('');
    const bad = !code ? '복구 코드를 입력하세요.' : pwInvalid(p, c); if (bad) { setMessage({ kind: 'error', text: bad }); return; }
    await run('비밀번호 재설정', () => maintenanceCommand('recover-password', { recoveryCode: code, newPassword: p }), r => {
      setRecInput(''); setPassword(''); setRecoveryCode(String(r.recoveryCode ?? '')); setSavedOffline(false);
      return `비밀번호를 재설정했습니다. 데이터는 삭제되지 않았습니다.${r.safeBackupId ? ` 안전 백업: ${r.safeBackupId}` : ''} 아래 새 복구 코드를 보관하세요.`;
    });
  }
  const saveSchedule = () => needPw() && void run('일정 저장', () => maintenanceCommand('schedule', { password, enabled: schedEnabled, intervalHours: Math.min(24, Math.max(1, Math.round(schedHours) || 24)) }), () => '자동 백업 일정을 저장했습니다.');
  const saveAutostart = () => status?.autostart.supported && needPw() && void run('자동 시작 저장', () => maintenanceCommand('autostart', { password, enabled: autoEnabled }), () => '자동 시작 설정을 저장했습니다.');
  const nativeImport = () => needPw() && void run('가져오기', () => maintenanceCommand('import', { password }), r => `백업을 가져왔습니다 · ${r.backupId}`);
  const nativeExport = () => selected && needPw() && void run('내보내기', () => maintenanceCommand('export', { password, backupId: selected }), () => '저장 대화상자에서 선택한 위치로 백업을 복사했습니다.');
  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); setCopyMsg('클립보드에 복사했습니다. 붙여넣은 뒤 클립보드를 비우세요.'); }
    catch { setCopyMsg('복사 실패: 클립보드 권한이 없습니다. 화면에서 직접 옮겨 적으세요.'); }
  }

  const s = status;
  return (
    <main className="eqw" data-testid="page-maintenance">
      <span className="eyebrow">K99 Windows · 3단계</span>
      <h1>데이터 보존 · 복구</h1>
      <NativeLedgerImportPanel />
      <p className="eqw__lead">이 PC의 로컬 데이터만 암호화 백업·검증·복원합니다. 원격 동기화나 외부 DB 연결은 없습니다.</p>
      {restoring && <div className="eq-error mtw__lock" role="alert">복원 처리 중입니다. 모든 작업이 잠겼습니다. 창을 닫지 마세요.</div>}
      <div className="eq-row" style={{ marginBottom: 12 }} data-testid="maintenance-status">
        {!s ? <span className="eq-pill">상태 확인 중</span> : <>
          <span className={`eq-pill ${s.native ? 'is-ok' : 'is-warn'}`}>{s.native ? 'Windows 네이티브' : '브라우저 미리보기'}</span>
          <span className={`eq-pill ${s.packaged ? 'is-ok' : 'is-warn'}`}>{s.packaged ? '설치판' : '개발/미설치 실행'}</span>
          <span className="eq-pill">키 보호 · {s.keyProtection}</span>
          <span className={`eq-pill ${s.adminConfigured ? 'is-ok' : 'is-bad'}`}>{s.adminConfigured ? '관리자 설정됨' : '관리자 미설정'}</span>
          <span className={`eq-pill ${s.recoveryConfigured ? 'is-ok' : 'is-warn'}`}>{s.recoveryConfigured ? '복구 코드 있음' : '복구 코드 없음'}</span>
          <span className={`eq-pill ${s.backupKeyExported ? 'is-ok' : 'is-warn'}`}>{s.backupKeyExported ? '백업 키 표시 이력 있음 · 외부 보관 확인 필요' : '백업 키 미확인'}</span>
          {s.busy && <span className="eq-pill is-warn">서버 작업 중</span>}
        </>}
        {busy && <span className="eq-pill is-warn">{busy} 중</span>}
      </div>
      {loadError && <div className="eq-error" role="alert" data-testid="text-maintenance-load-error">{loadError} <button type="button" className="eq-btn" onClick={() => void refresh()}>다시 시도</button></div>}
      {s?.lastError && <div className="eq-error" role="alert" data-testid="text-maintenance-last-error">최근 오류: {s.lastError}</div>}
      {message && <div className={message.kind === 'error' ? 'eq-error' : 'eq-msg'} role={message.kind === 'error' ? 'alert' : 'status'} data-testid="text-maintenance-message">{message.text}</div>}

      <div className="eqw__grid">
        <div className="eqw__col">
          <section className="eq-card">
            <h2>저장 위치</h2>
            {!s ? <><div className="eq-skel" /><div className="eq-skel short" /></> : <dl className="mtw__dl">
              <dt>데이터</dt><dd className="eq-mono" data-testid="text-data-location">{s.dataLocation}</dd>
              <dt>백업</dt><dd className="eq-mono" data-testid="text-backup-location">{s.backupLocation}</dd>
              <dt>최근 백업</dt><dd>{when(s.lastBackupAt)}</dd>
            </dl>}
            <p className="mtw__warn" style={{ marginTop: 10 }}>프로그램을 삭제해도 데이터는 남습니다. 백업이 같은 디스크에 있으면 디스크 고장 시 함께 사라지므로, 외부 USB 등으로 정기적으로 내보내세요.</p>
          </section>

          <section className="eq-card">
            <h2>관리자 확인</h2>
            {s && !s.adminConfigured ? <form className="mtw__stack" onSubmit={setup} autoComplete="off">
              <p>관리자 비밀번호가 없습니다. 먼저 이 PC 전용 비밀번호를 설정하세요.</p>
              <label className="eq-field">새 비밀번호 · {MIN}자 이상<input type="password" autoComplete="new-password" maxLength={MAX} value={setupPw} onChange={e => setSetupPw(e.target.value)} data-testid="input-admin-setup-password" /></label>
              <label className="eq-field">비밀번호 확인<input type="password" autoComplete="new-password" maxLength={MAX} value={setupPw2} onChange={e => setSetupPw2(e.target.value)} data-testid="input-admin-setup-confirm" /></label>
              <button className="eq-btn is-primary" type="submit" disabled={locked} data-testid="button-admin-setup">관리자 설정</button>
            </form> : <label className="eq-field">관리자 비밀번호 (모든 보존 작업에 필요)
              <input type="password" autoComplete="current-password" maxLength={MAX} value={password} disabled={restoring} onChange={e => setPassword(e.target.value)} data-testid="maintenance-password" /></label>}
          </section>

          <section className="eq-card">
            <h2>복구 코드</h2>
            <p>새로 만들면 이전 복구 코드는 즉시 무효가 됩니다. 한 번만 표시됩니다.</p>
            <button className="eq-btn is-primary" type="button" disabled={locked || !s?.adminConfigured} onClick={genRecovery} data-testid="recovery-generate">복구 코드 생성</button>
            {recoveryCode && <div className="mtw__stack" style={{ marginTop: 10 }}>
              <div className="mtw__secret" data-testid="text-recovery-code">{recoveryCode}</div>
              <div className="eq-row"><button className="eq-btn" type="button" onClick={() => void copy(recoveryCode)} data-testid="button-copy-recovery">복사</button>
                <button className="eq-btn" type="button" disabled={!savedOffline} onClick={() => { setRecoveryCode(''); setCopyMsg(''); }} data-testid="button-hide-recovery">보관 완료 · 숨기기</button></div>
              <label className="eq-check"><input type="checkbox" checked={savedOffline} onChange={e => setSavedOffline(e.target.checked)} data-testid="checkbox-recovery-saved" />종이 등 오프라인에 보관했습니다. 다시 볼 수 없습니다.</label>
            </div>}
            <form className="mtw__stack" style={{ marginTop: 14 }} onSubmit={recoverPw} autoComplete="off">
              <b style={{ fontSize: 13 }}>비밀번호 분실 시 재설정</b>
              <label className="eq-field">복구 코드<input value={recInput} onChange={e => setRecInput(e.target.value)} autoComplete="off" spellCheck={false} data-testid="input-recovery-code" /></label>
              <label className="eq-field">새 비밀번호 · {MIN}~{MAX}자<input type="password" autoComplete="new-password" maxLength={MAX} value={newPw} onChange={e => setNewPw(e.target.value)} data-testid="input-recover-new-password" /></label>
              <label className="eq-field">새 비밀번호 확인<input type="password" autoComplete="new-password" maxLength={MAX} value={newPw2} onChange={e => setNewPw2(e.target.value)} data-testid="input-recover-confirm" /></label>
              <button className="eq-btn" type="submit" disabled={locked} data-testid="button-recover-password">비밀번호 재설정 (데이터 유지)</button>
            </form>
          </section>

          <section className="eq-card">
            <h2>백업 키</h2>
            <p className="mtw__info">백업 키는 이 PC의 Windows DPAPI로 보호됩니다. 다른 PC나 Windows 재설치 후 복원하려면 이 키가 필요합니다. 오프라인으로만 보관하세요. 노출되면 백업 속 민감 데이터가 해독될 수 있습니다.</p>
            <div className="eq-row"><button className="eq-btn" type="button" disabled={locked} onClick={showKey} data-testid="backup-key-show">백업 키 보기</button>
              {revealedKey && <><button className="eq-btn" type="button" onClick={() => void copy(revealedKey)} data-testid="button-copy-backup-key">복사</button>
                <button className="eq-btn" type="button" onClick={() => { setRevealedKey(''); setCopyMsg(''); }} data-testid="button-hide-backup-key">숨기기</button></>}</div>
            {revealedKey && <div className="mtw__secret" style={{ marginTop: 10 }} data-testid="text-backup-key">{revealedKey}</div>}
          </section>
          {copyMsg && <div className={copyMsg.startsWith('복사 실패') ? 'eq-error' : 'eq-msg'} role="status" data-testid="text-copy-result">{copyMsg}</div>}
        </div>

        <div className="eqw__col">
          <section className="eq-card">
            <h2>백업 목록 <span className="eq-pill">{s?.backups.length ?? 0}개</span></h2>
            <div className="eq-row" style={{ marginBottom: 10 }}>
              <button className="eq-btn is-primary" type="button" disabled={locked} onClick={createBackup} data-testid="backup-create">지금 암호화 통합 백업</button>
              <button className="eq-btn" type="button" disabled={locked || !s?.native} onClick={nativeImport} data-testid="button-backup-import">파일에서 가져오기</button>
              <button className="eq-btn" type="button" disabled={locked || !s?.native || !selected} onClick={nativeExport} data-testid="button-backup-export">선택 백업 내보내기</button>
            </div>
            {s && !s.native && <p style={{ color: 'hsl(var(--muted-foreground))' }}>브라우저 미리보기에서는 가져오기·내보내기를 지원하지 않습니다. Windows 앱에서 파일 선택 창으로만 진행합니다.</p>}
            {!s ? <><div className="eq-skel" /><div className="eq-skel short" /></> : s.backups.length === 0
              ? <div className="eq-empty" data-testid="empty-backups">아직 백업이 없습니다. 위 버튼으로 첫 백업을 만드세요.</div>
              : <div className="eq-list" data-testid="backup-select" role="listbox">{s.backups.map(b => (
                <button key={b.id} type="button" role="option" aria-selected={b.id === selected} aria-pressed={b.id === selected} disabled={restoring}
                  onClick={() => { setSelected(b.id); setPhrase(''); setRestoreCheck(false); }} data-testid={`option-backup-${b.id}`}>
                  <span><b className="eq-mono">{b.id}</b><br /><small>{when(b.createdAt)} · {b.reason}</small></span><small>{size(b.size)}</small>
                </button>))}</div>}
          </section>

          <section className="eq-card">
            <h2>검증 · 복원</h2>
            {!selected ? <div className="eq-empty">위 목록에서 백업을 선택하세요.</div> : <div className="mtw__stack">
              <p>선택: <span className="eq-mono">{selected}</span></p>
              <label className="eq-field">백업 키 (다른 PC에서 만든 백업일 때만)<input type="password" autoComplete="off" value={backupKeyInput} onChange={e => setBackupKeyInput(e.target.value)} data-testid="input-backup-key" /></label>
              <button className="eq-btn" type="button" disabled={locked} onClick={verify} data-testid="backup-verify">백업 검증</button>
              <div className="mtw__warn">복원하면 현재 주문·사진·설정이 모두 이 백업으로 <b>덮어써집니다</b>. 복원 직전 안전 백업은 자동으로 만들어집니다. 태그 출력 중에는 복원하지 마세요.</div>
              <label className="eq-field">확인 문구 "{PHRASE}" 입력<input value={phrase} onChange={e => setPhrase(e.target.value)} autoComplete="off" disabled={restoring} data-testid="backup-confirmation" /></label>
              <label className="eq-check"><input type="checkbox" checked={restoreCheck} disabled={restoring} onChange={e => setRestoreCheck(e.target.checked)} data-testid="backup-restore-check" />현재 데이터 덮어쓰기를 이해했고, 출력 중인 작업이 없음을 확인했습니다.</label>
              <button className="eq-btn is-primary" type="button" disabled={locked || phrase !== PHRASE || !restoreCheck || !password} onClick={() => void restore()} data-testid="backup-restore">이 백업으로 복원</button>
            </div>}
          </section>

          <section className="eq-card">
            <h2>자동 백업 일정</h2>
            <div className="mtw__stack">
              <label className="eq-check"><input type="checkbox" checked={schedEnabled} onChange={e => setSchedEnabled(e.target.checked)} data-testid="checkbox-schedule-enabled" />자동 백업 사용</label>
              <label className="eq-field">간격(시간, 1~24)<input type="number" min={1} max={24} value={schedHours} onChange={e => setSchedHours(Number(e.target.value))} data-testid="input-schedule-hours" /></label>
              {s && <p style={{ color: 'hsl(var(--muted-foreground))' }}>저장된 값: {s.schedule.enabled ? `${s.schedule.intervalHours}시간마다` : '꺼짐'}</p>}
              <button className="eq-btn is-primary" type="button" disabled={locked || schedHours < 1 || schedHours > 24} onClick={saveSchedule} data-testid="schedule-save">일정 저장</button>
            </div>
          </section>

          <section className="eq-card">
            <h2>Windows 로그인 시 자동 시작</h2>
            {s && !s.autostart.supported ? <p data-testid="text-autostart-unsupported">설치된 Windows 앱에서만 지원합니다. 현재 실행 환경에서는 설정할 수 없습니다.</p> : <div className="mtw__stack">
              <label className="eq-check"><input type="checkbox" checked={autoEnabled} onChange={e => setAutoEnabled(e.target.checked)} data-testid="checkbox-autostart" />로그인 시 K99 자동 실행</label>
              {s && <p style={{ color: 'hsl(var(--muted-foreground))' }}>현재: {s.autostart.enabled ? '켜짐' : '꺼짐'}</p>}
            </div>}
            <button className="eq-btn" type="button" disabled={locked || !s?.autostart.supported} onClick={saveAutostart} data-testid="autostart-save">자동 시작 저장</button>
          </section>
        </div>
      </div>
    </main>
  );
}

export default MaintenanceWorkspace;
