import { useCallback, useEffect, useRef, useState } from 'react';
import { NativeLedgerImportPanel } from './NativeLedgerImportPanel';
import { ProgramIntegrationSettings } from './ProgramIntegrationSettings';
import {StorageLayoutSettings} from './StorageLayoutSettings';
import {ObsAutomationSettings} from './ObsAutomationSettings';
import { PhotoRetentionSettings } from './PhotoRetentionSettings';
import { maintenanceCommand, maintenanceStatus, type MaintenanceStatus } from './maintenance-client';
import './equipment.css';
import './maintenance.css';

const PHRASE = 'K99 복구';
const errText = (c: unknown, f: string) => (c instanceof Error && c.message ? c.message : f);
const size = (n: number) => n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1024).toFixed(1)} KB`;
const when = (s: string | null) => s ? new Date(s).toLocaleString('ko-KR') : '없음';

export function MaintenanceWorkspace() {
  const [status, setStatus] = useState<MaintenanceStatus | null>(null);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState('');
  const [selected, setSelected] = useState('');
  const [backupKeyInput, setBackupKeyInput] = useState('');
  const [phrase, setPhrase] = useState('');
  const [restoreCheck, setRestoreCheck] = useState(false);
  const [revealedKey, setRevealedKey] = useState('');
  const [schedEnabled, setSchedEnabled] = useState(true);
  const [schedHours, setSchedHours] = useState(24);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const [copyMsg, setCopyMsg] = useState('');
  const [videoMessage, setVideoMessage] = useState('');
  const [videoBusy, setVideoBusy] = useState(false);
  async function manageVideos(action:'open'|'refresh') {
    if (videoBusy) return;
    setVideoBusy(true);
    try {
      const reply = await window.k99Desktop?.idleVideos?.(action);
      if (!reply?.success) throw new Error(reply?.error || 'Windows 앱에서 사용할 수 있습니다.');
      setVideoMessage(action === 'open' ? '영상 폴더를 열었습니다. 파일을 넣은 뒤 목록을 새로고침하세요.' :
        `영상 ${reply.files?.length ?? 0}개를 확인하고 고객 화면에 반영했습니다.`);
    } catch (error) { setVideoMessage(errText(error, '영상 폴더 작업 실패')); }
    finally { setVideoBusy(false); }
  }
  const draftInit = useRef(false);
  const pollRun = useRef(0);
  const inFlight = useRef(false);
  const busyRef = useRef('');
  busyRef.current = busy;

  const refresh = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    const run = ++pollRun.current;
    try {
      const next = await maintenanceStatus();
      if (run !== pollRun.current) return;
      setStatus(next); setLoadError('');
      if (!draftInit.current) {
        draftInit.current = true;
        setSchedEnabled(next.schedule?.enabled ?? true);
        setSchedHours(next.schedule?.intervalHours || 24);
        setAutoEnabled(!!next.autostart?.enabled);
      }
    } catch (c) { if (run === pollRun.current) setLoadError(errText(c, '보존 상태를 읽지 못했습니다.')); }
    finally { inFlight.current = false; }
  }, []);

  useEffect(() => {
    void refresh();
    const t = window.setInterval(() => { if (!busyRef.current) void refresh(); }, 10000);
    return () => clearInterval(t);
  }, [refresh]);

  const locked = !!busy || !!status?.busy || !status?.native;
  const restoring = busy === '복원';

  async function run<T>(label: string, fn: () => Promise<T>, after?: (r: T) => string | void, onFail?: () => void) {
    if (busyRef.current) return undefined;
    setBusy(label); busyRef.current = label; setMessage(null);
    try {
      const r = await fn();
      const text = after?.(r);
      if (text) setMessage({ kind: 'ok', text });
      return r;
    } catch (c) { onFail?.(); setMessage({ kind: 'error', text: errText(c, `${label} 실패`) }); return undefined; }
    finally {
      setBusy(''); busyRef.current = '';
      pollRun.current++; inFlight.current = false; void refresh();
    }
  }
  const createBackup = () => void run('백업', () => maintenanceCommand('backup'),
    r => `암호화 통합 백업 완료 · ${r.backupId}${r.verified ? ' · 검증됨' : ''}`);
  const verify = () => selected && void run('검증', () => maintenanceCommand('verify', { backupId: selected, ...(backupKeyInput ? { backupKey: backupKeyInput } : {}) }),
    r => `백업 ${selected} 검증 ${r.verified === false ? '실패' : '통과'}`);
  async function restore() {
    if (!selected || phrase !== PHRASE || !restoreCheck || locked) return;
    const r = await run('복원', () => maintenanceCommand('restore', { backupId: selected, ...(backupKeyInput ? { backupKey: backupKeyInput } : {}), confirmation: PHRASE }),
      undefined, () => { setPhrase(''); setRestoreCheck(false); });
    if (r && r.restored) {
      setBackupKeyInput(''); setRevealedKey(''); setPhrase(''); setRestoreCheck(false);
      setBusy('복원'); busyRef.current = '복원';
      setMessage({ kind: 'ok', text: `복원 완료. 복원 직전 안전 백업: ${r.safetyBackupId ?? '-'} · 잠시 후 첫 화면으로 다시 불러옵니다.` });
      window.setTimeout(() => window.location.replace('/'), 2500);
    }
  }
  const showKey = () => void run('백업 키 표시', () => maintenanceCommand('backup-key'), r => { setRevealedKey(String(r.backupKey ?? '')); setCopyMsg(''); return '백업 키를 표시했습니다. 오프라인으로 기록한 뒤 숨기세요.'; });
  const saveSchedule = () => void run('일정 저장', () => maintenanceCommand('schedule', { enabled: schedEnabled, intervalHours: Math.min(24, Math.max(1, Math.round(schedHours) || 24)) }), () => '자동 백업 일정을 저장했습니다.');
  const saveAutostart = () => status?.autostart.supported && void run('자동 시작 저장', () => maintenanceCommand('autostart', { enabled: autoEnabled }), () => '자동 시작 설정을 저장했습니다.');
  const nativeImport = () => void run('가져오기', () => maintenanceCommand('import'), r => `백업을 가져왔습니다 · ${r.backupId}`);
  const nativeExport = () => selected && void run('내보내기', () => maintenanceCommand('export', { backupId: selected }), () => '저장 대화상자에서 선택한 위치로 백업을 복사했습니다.');
  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); setCopyMsg('클립보드에 복사했습니다. 붙여넣은 뒤 클립보드를 비우세요.'); }
    catch { setCopyMsg('복사 실패: 클립보드 권한이 없습니다. 화면에서 직접 옮겨 적으세요.'); }
  }

  const s = status;
  return (
    <main className="eqw" data-testid="page-maintenance">
      <span className="eyebrow">K99 Windows · 3단계</span>
      <h1>데이터 보존 · 복구</h1>
      <NativeLedgerImportPanel />
      <section className="eq-card">
        <h2>기존 V1 DB 가져오기</h2>
        <p>같은 Windows 사용자에서는 기존 K99WindowsV1 장부를 자동으로 이어 사용합니다. 다른 위치의 DB는 원본을 보존하고 사본만 검증·변환합니다. 현재 장부와 합치기가 아닌 안전 백업 후 전환입니다.</p>
        <button type="button" className="eq-btn" disabled={locked||!s?.native}
          onClick={()=>void run('V1 DB 가져오기',()=>maintenanceCommand('v1-import',{}),
            result=>result.cancelled?'취소했습니다.':result.alreadyConnected?'이미 연결된 V1 장부입니다.':'V1 장부 복구를 완료했습니다. 화면을 다시 불러옵니다.')}
          data-testid="button-v1-import">기존 V1 DB 가져오기</button>
      </section>
      <p className="eqw__lead">이 PC의 로컬 데이터만 암호화 백업·검증·복원합니다. 원격 동기화나 외부 DB 연결은 없습니다.</p>
      {restoring && <div className="eq-error mtw__lock" role="alert">복원 처리 중입니다. 모든 작업이 잠겼습니다. 창을 닫지 마세요.</div>}
      <div className="eq-row" style={{ marginBottom: 12 }} data-testid="maintenance-status">
        {!s ? <span className="eq-pill">상태 확인 중</span> : <>
          <span className={`eq-pill ${s.native ? 'is-ok' : 'is-warn'}`}>{s.native ? 'Windows 네이티브' : '브라우저 미리보기'}</span>
          <span className={`eq-pill ${s.packaged ? 'is-ok' : 'is-warn'}`}>{s.packaged ? '설치판' : '개발/미설치 실행'}</span>
          <span className="eq-pill">키 보호 · {s.keyProtection}</span>
          <span className="eq-pill is-ok">매장 PC · Zero-Auth</span>
          <span className={`eq-pill ${s.backupKeyExported ? 'is-ok' : 'is-warn'}`}>{s.backupKeyExported ? '백업 키 표시 이력 있음 · 외부 보관 확인 필요' : '백업 키 미확인'}</span>
          {s.busy && <span className="eq-pill is-warn">서버 작업 중</span>}
        </>}
        {busy && <span className="eq-pill is-warn">{busy} 중</span>}
      </div>
      {loadError && <div className="eq-error" role="alert" data-testid="text-maintenance-load-error">{loadError} <button type="button" className="eq-btn" onClick={() => void refresh()}>다시 시도</button></div>}
      {s?.lastError && <div className="eq-error" role="alert" data-testid="text-maintenance-last-error">최근 오류: {s.lastError}</div>}
      {message && <div className={message.kind === 'error' ? 'eq-error' : 'eq-msg'} role={message.kind === 'error' ? 'alert' : 'status'} data-testid="text-maintenance-message">{message.text}</div>}

      <div className="eqw__grid">
        <StorageLayoutSettings/>
        <ObsAutomationSettings/>
        <ProgramIntegrationSettings />
        <PhotoRetentionSettings />
        <div className="eqw__col">
          <section className="eq-card">
            <h2>저장 위치</h2>
            {!s ? <><div className="eq-skel" /><div className="eq-skel short" /></> : <dl className="mtw__dl">
              <dt>데이터</dt><dd className="eq-mono" data-testid="text-data-location">{s.dataLocation}</dd>
              <dt>백업</dt><dd className="eq-mono" data-testid="text-backup-location">{s.backupLocation}</dd>
              <dt>최근 백업</dt><dd>{when(s.lastBackupAt)}</dd>
            </dl>}
            <p className="mtw__warn" style={{ marginTop: 10 }}>프로그램을 삭제해도 데이터는 남습니다. 백업이 같은 디스크에 있으면 디스크 고장 시 함께 사라지므로, 외부 USB 등으로 정기적으로 내보내세요.</p>
          </section>

          <section className="eq-card">
            <h2>매장 단독 PC · Zero-Auth</h2>
            <p>장부 가져오기와 로컬 설정·백업은 로그인 없이 사용합니다. 이 PC를 사용할 수 있는 사람은 데이터와 백업 키에도 접근할 수 있으므로 Windows 화면 잠금을 사용하세요.</p>
            <p>백업 암호화·무결성 검사·복구 확인 문구·복구 직전 안전 백업은 유지합니다. 브라우저에서는 보존 작업을 실행하지 않습니다.</p>
          </section>

          <section className="eq-card">
            <h2>백업 키</h2>
            <p className="mtw__info">백업 키는 이 PC의 Windows DPAPI로 보호됩니다. 다른 PC나 Windows 재설치 후 복원하려면 이 키가 필요합니다. 오프라인으로만 보관하세요. 노출되면 백업 속 민감 데이터가 해독될 수 있습니다.</p>
            <div className="eq-row"><button className="eq-btn" type="button" disabled={locked} onClick={showKey} data-testid="backup-key-show">백업 키 보기</button>
              {revealedKey && <><button className="eq-btn" type="button" onClick={() => void copy(revealedKey)} data-testid="button-copy-backup-key">복사</button>
                <button className="eq-btn" type="button" onClick={() => { setRevealedKey(''); setCopyMsg(''); }} data-testid="button-hide-backup-key">숨기기</button></>}</div>
            {revealedKey && <div className="mtw__secret" style={{ marginTop: 10 }} data-testid="text-backup-key">{revealedKey}</div>}
          </section>
          {copyMsg && <div className={copyMsg.startsWith('복사 실패') ? 'eq-error' : 'eq-msg'} role="status" data-testid="text-copy-result">{copyMsg}</div>}
        </div>

        <div className="eqw__col">
          <section className="eq-card">
            <h2>백업 목록 <span className="eq-pill">{s?.backups.length ?? 0}개</span></h2>
            <div className="eq-row" style={{ marginBottom: 10 }}>
              <button className="eq-btn is-primary" type="button" disabled={locked} onClick={createBackup} data-testid="backup-create">지금 암호화 통합 백업</button>
              <button className="eq-btn" type="button" disabled={locked || !s?.native} onClick={nativeImport} data-testid="button-backup-import">파일에서 가져오기</button>
              <button className="eq-btn" type="button" disabled={locked || !s?.native || !selected} onClick={nativeExport} data-testid="button-backup-export">선택 백업 내보내기</button>
            </div>
            {s && !s.native && <p style={{ color: 'hsl(var(--muted-foreground))' }}>브라우저 미리보기에서는 가져오기·내보내기를 지원하지 않습니다. Windows 앱에서 파일 선택 창으로만 진행합니다.</p>}
            {!s ? <><div className="eq-skel" /><div className="eq-skel short" /></> : s.backups.length === 0
              ? <div className="eq-empty" data-testid="empty-backups">아직 백업이 없습니다. 위 버튼으로 첫 백업을 만드세요.</div>
              : <div className="eq-list" data-testid="backup-select" role="listbox">{s.backups.map(b => (
                <button key={b.id} type="button" role="option" aria-selected={b.id === selected} aria-pressed={b.id === selected} disabled={restoring}
                  onClick={() => { setSelected(b.id); setPhrase(''); setRestoreCheck(false); }} data-testid={`option-backup-${b.id}`}>
                  <span><b className="eq-mono">{b.id}</b><br /><small>{when(b.createdAt)} · {b.reason}</small></span><small>{size(b.size)}</small>
                </button>))}</div>}
          </section>

          <section className="eq-card">
            <h2>검증 · 복원</h2>
            {!selected ? <div className="eq-empty">위 목록에서 백업을 선택하세요.</div> : <div className="mtw__stack">
              <p>선택: <span className="eq-mono">{selected}</span></p>
              <label className="eq-field">백업 키 (다른 PC에서 만든 백업일 때만)<input type="password" autoComplete="off" value={backupKeyInput} onChange={e => setBackupKeyInput(e.target.value)} data-testid="input-backup-key" /></label>
              <button className="eq-btn" type="button" disabled={locked} onClick={verify} data-testid="backup-verify">백업 검증</button>
              <div className="mtw__warn">복원하면 현재 주문·사진·설정이 모두 이 백업으로 <b>덮어써집니다</b>. 복원 직전 안전 백업은 자동으로 만들어집니다. 태그 출력 중에는 복원하지 마세요.</div>
              <label className="eq-field">확인 문구 "{PHRASE}" 입력<input value={phrase} onChange={e => setPhrase(e.target.value)} autoComplete="off" disabled={restoring} data-testid="backup-confirmation" /></label>
              <label className="eq-check"><input type="checkbox" checked={restoreCheck} disabled={restoring} onChange={e => setRestoreCheck(e.target.checked)} data-testid="backup-restore-check" />현재 데이터 덮어쓰기를 이해했고, 출력 중인 작업이 없음을 확인했습니다.</label>
              <button className="eq-btn is-primary" type="button" disabled={locked || phrase !== PHRASE || !restoreCheck} onClick={() => void restore()} data-testid="backup-restore">이 백업으로 복원</button>
            </div>}
          </section>

          <section className="eq-card">
            <h2>자동 백업 일정</h2>
            <div className="mtw__stack">
              <label className="eq-check"><input type="checkbox" checked={schedEnabled} onChange={e => setSchedEnabled(e.target.checked)} data-testid="checkbox-schedule-enabled" />자동 백업 사용</label>
              <label className="eq-field">간격(시간, 1~24)<input type="number" min={1} max={24} value={schedHours} onChange={e => setSchedHours(Number(e.target.value))} data-testid="input-schedule-hours" /></label>
              {s && <p style={{ color: 'hsl(var(--muted-foreground))' }}>저장된 값: {s.schedule.enabled ? `${s.schedule.intervalHours}시간마다` : '꺼짐'}</p>}
              <button className="eq-btn is-primary" type="button" disabled={locked || schedHours < 1 || schedHours > 24} onClick={saveSchedule} data-testid="schedule-save">일정 저장</button>
            </div>
          </section>

          <section className="eq-card">
            <h2>Windows 로그인 시 자동 시작</h2>
            {s && !s.autostart.supported ? <p data-testid="text-autostart-unsupported">설치된 Windows 앱에서만 지원합니다. 현재 실행 환경에서는 설정할 수 없습니다.</p> : <div className="mtw__stack">
              <label className="eq-check"><input type="checkbox" role="switch" checked={autoEnabled} onChange={e => setAutoEnabled(e.target.checked)} data-testid="checkbox-autostart" />윈도우 시작 시 자동 실행</label>
              {s && <p style={{ color: 'hsl(var(--muted-foreground))' }}>현재: {s.autostart.enabled ? '켜짐' : '꺼짐'}</p>}
            </div>}
            <button className="eq-btn" type="button" disabled={locked || !s?.autostart.supported} onClick={saveAutostart} data-testid="autostart-save">자동 시작 저장</button>
          </section>
          <section className="eq-card">
            <h2>고객 모니터 대기 영상</h2>
            <p>저장 루트의 03_고객모니터영상 폴더에 MP4·WebM 파일을 넣으세요. 파일명 오름차순으로 연속 순환하며, 빈 폴더는 기본 홍보 영상을 사용합니다. 순서를 정하려면 01_, 02_처럼 이름 앞에 번호를 붙이세요.</p>
            <div className="mtw__stack">
              <button className="eq-btn" type="button" disabled={videoBusy || !window.k99Desktop?.idleVideos}
                onClick={() => void manageVideos('open')} data-testid="button-open-idle-videos">고객 모니터 영상 폴더 열기</button>
              <button className="eq-btn" type="button" disabled={videoBusy || !window.k99Desktop?.idleVideos}
                onClick={() => void manageVideos('refresh')} data-testid="button-refresh-idle-videos">영상 목록 새로고침</button>
              {videoMessage && <p role="status">{videoMessage}</p>}
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}

export default MaintenanceWorkspace;
