import {useCallback,useEffect,useState,useRef} from 'react';
import {maintenanceCommand,maintenanceStatus,type MaintenanceStatus} from './maintenance-client';
import {OwnerSecurityPanel} from './OwnerSecurityPanel';
import {IdleVideoGuide} from './IdleVideoGuide';
import './equipment.css';
import './maintenance.css';

const PHRASE='K99 복구';
export function MaintenanceWorkspace(){
  const [status,setStatus]=useState<MaintenanceStatus|null>(null);
  const [busy,setBusy]=useState('');
  const [message,setMessage]=useState('');
  const [error,setError]=useState('');
  const [selected,setSelected]=useState('');
  const [key,setKey]=useState('');
  const [phrase,setPhrase]=useState('');
  const [consent,setConsent]=useState(false);
  const [revealed,setRevealed]=useState('');
  const pending=useRef(false);
  const reloading=useRef(false);
  const load=useCallback(()=>{maintenanceStatus().then(setStatus).catch(e=>setError(e.message));},[]);
  useEffect(load,[load]);
  const locked=!!busy||!!status?.busy||!status?.native;
  async function run(label:string,fn:()=>Promise<string>){
    if(pending.current)return;
    pending.current=true;setBusy(label);setError('');setMessage('');
    try{setMessage(await fn());}
    catch(e){setError(e instanceof Error?e.message:'처리하지 못했습니다. 기존 데이터는 보존됩니다.');}
    finally{if(!reloading.current){pending.current=false;setBusy('');load();}}
  }
  const backup=()=>void run('전체 백업',async()=>{
    const r=await maintenanceCommand('backup');
    if(!r.backupId||r.verified!==true)throw Error('백업 무결성을 확인하지 못했습니다. 기존 데이터는 변경하지 않았습니다.');
    const saved=await maintenanceCommand('export',{backupId:r.backupId});
    return saved.cancelled?'안전 백업은 이 PC에 만들었습니다. 외부 파일 저장은 취소했습니다.':'전체 데이터 안전 백업을 만들고 선택한 위치에 복사했습니다.';
  });
  const importBackup=()=>void run('백업 파일 선택',async()=>{
    const r=await maintenanceCommand('import');
    if(r.cancelled)return '파일 선택을 취소했습니다.';
    if(typeof r.backupId!=='string'||!r.backupId)throw Error('불러온 백업 파일을 확인하지 못했습니다.');
    setSelected(r.backupId);setPhrase('');setConsent(false);
    return '백업을 불러왔습니다. 아래에서 복원할 파일과 안내를 확인하세요. 아직 현재 장부는 바뀌지 않았습니다.';
  });
  const restore=()=>void run('복원',async()=>{
    if(!selected||phrase!==PHRASE||!consent)throw Error('복원 대상과 확인 문구를 확인하세요.');
    const verified=await maintenanceCommand('verify',{backupId:selected,...(key?{backupKey:key}:{})});
    if(verified.verified!==true)throw Error('백업 검증에 실패했습니다. 복원하지 않았습니다.');
    const r=await maintenanceCommand('restore',{backupId:selected,...(key?{backupKey:key}:{}),confirmation:PHRASE});
    if(!r.restored)throw Error('복원 완료를 확인하지 못했습니다.');
    reloading.current=true;
    setKey('');setRevealed('');setSelected('');setPhrase('');setConsent(false);
    window.setTimeout(()=>window.location.replace(import.meta.env.BASE_URL),2500);
    return `복원을 완료했습니다. 복원 직전 안전 백업: ${r.safetyBackupId||'상태에서 확인'} · 화면을 다시 불러옵니다.`;
  });
  return <main className="eqw" data-testid="page-maintenance">
    <h1>관리자 설정</h1>
    <p className="eqw__lead">홍보 영상, 전체 데이터 백업, 보안 비밀번호를 관리합니다.</p>
    <IdleVideoGuide/>
    <section className="eq-card" aria-label="전체 데이터 안전 백업 및 복원">
      <h2>전체 데이터 안전 백업 및 복원</h2>
      <p>고객 명부·접수 내역·설정·사진과 태그 이력을 함께 보관합니다. 외장 저장장치에도 백업 파일을 보관해 주세요.</p>
      {!status?.native&&<p>백업 파일 작업은 매장 PC의 Windows 설치 앱에서 실행해 주세요.</p>}
      <div className="eq-row">
        <button type="button" className="eq-btn is-primary" disabled={locked} onClick={backup} data-testid="backup-create">지금 전체 데이터 백업하기</button>
        <button type="button" className="eq-btn" disabled={locked} onClick={importBackup} data-testid="button-backup-import">백업 파일 불러오기(복원)</button>
      </div>
      <p>최근 백업: {status?.lastBackupAt?new Date(status.lastBackupAt).toLocaleString('ko-KR'):'아직 없음'}</p>
      <label className="eq-field">복원할 백업 선택
        <select value={selected} disabled={locked} onChange={e=>{setSelected(e.target.value);setPhrase('');setConsent(false);}}>
          <option value="">선택하세요</option>
          {status?.backups.map(b=><option key={b.id} value={b.id}>{new Date(b.createdAt).toLocaleString('ko-KR')} · {b.id}</option>)}
        </select>
      </label>
      {selected&&<div className="mtw__stack">
        <p className="mtw__warn">복원하면 현재 주문·사진·설정이 선택한 백업 내용으로 바뀝니다. 복원 직전 안전 백업과 실패 시 원상복구 보호는 그대로 유지됩니다.</p>
        <label className="eq-field">다른 PC의 백업일 때만 백업 키 입력
          <input type="password" autoComplete="off" disabled={locked} value={key} onChange={e=>setKey(e.target.value)}/></label>
        <label className="eq-field">확인 문구 "{PHRASE}" 입력
          <input disabled={locked} value={phrase} onChange={e=>setPhrase(e.target.value)} data-testid="backup-confirmation"/></label>
        <label className="eq-check"><input type="checkbox" disabled={locked} checked={consent} onChange={e=>setConsent(e.target.checked)} data-testid="backup-restore-check"/>현재 장부가 선택한 백업으로 바뀌는 것을 이해했습니다.</label>
        <button type="button" className="eq-btn is-primary" disabled={locked||phrase!==PHRASE||!consent} onClick={restore} data-testid="backup-restore">안전 검사 후 복원</button>
      </div>}
      <details style={{marginTop:16}}><summary>백업 키 보관 · 기존 장부 가져오기</summary>
        <p>Windows를 다시 설치하거나 다른 PC에서 복원할 때 백업 키가 필요합니다. 안전한 별도 장소에 보관하세요.</p>
        <button type="button" className="eq-btn" disabled={locked} onClick={()=>void run('백업 키 확인',async()=>{
          const r=await maintenanceCommand('backup-key');setRevealed(String(r.backupKey||''));return '백업 키를 다른 사람에게 보여 주지 마세요.';
        })}>백업 키 확인</button>
        {revealed&&<p style={{overflowWrap:'anywhere'}}>{revealed}<button type="button" onClick={()=>setRevealed('')}>숨기기</button></p>}
        <p>기존 장부 가져오기는 병합이 아니라 안전 백업 후 전환입니다. 원본 DB는 변경하지 않습니다.</p>
        <button type="button" className="eq-btn" disabled={locked} data-testid="button-v1-import" onClick={()=>void run('기존 장부 가져오기',async()=>{
          const r=await maintenanceCommand('v1-import',{});
          return r.cancelled?'취소했습니다.':r.alreadyConnected?'이미 연결된 장부입니다.':'기존 장부를 불러왔습니다.';
        })}>기존 V1 DB 가져오기</button>
      </details>
    </section>
    <OwnerSecurityPanel/>
    {busy&&<p role="status">{busy} 중입니다. 잠시 기다려 주세요.</p>}
    {message&&<p className="eq-msg" role="status">{message}</p>}
    {error&&<p className="eq-error" role="alert">{error}</p>}
  </main>;
}
export default MaintenanceWorkspace;
