import { useEffect, useState } from 'react';
import type { ConfirmedOrder } from './order-record';
import {
  STAGED_RESPONSES, recordStagedResponse, updateStagedMessage,
  type ApprovalStep, type StagedResponse,
} from './staged-approval';

type Props = { order: ConfirmedOrder; onSave: (order: ConfirmedOrder) => void };
const steps: ApprovalStep[] = [1, 2, 3];
const titles = { 1: '얼룩 제거 의사', 2: '세탁방법과 위험 확인', 3: '추가요금과 진행 확인' };
const outcomes = {
  'in-progress': '고객 회신 확인 중',
  'care-label-requested': '고객 요청에 따라 케어라벨 기준 세탁 진행',
  'method-declined': '변경 세탁방법 동의하지 않음',
  'price-declined': '추가요금 확인 후 진행하지 않음',
  approved: '고객 승인 완료 / 세탁 진행 가능',
};
const formatDate = (date: string) => new Date(date).toLocaleString('ko-KR');

export function StagedApprovalPanel({ order, onSave }: Props) {
  const staged = order.inspection?.stagedApproval;
  const activeStep = staged?.activeStep;
  const activeMessage = activeStep ? staged?.steps[activeStep]?.message ?? '' : '';
  const [message, setMessage] = useState(activeMessage);
  const [staffName, setStaffName] = useState('');
  const [choice, setChoice] = useState<StagedResponse | ''>('');
  const [respondedAt, setRespondedAt] = useState('');
  const [content, setContent] = useState('');
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    setMessage(activeMessage);
    setChoice('');
    setRespondedAt('');
    setContent('');
    setError('');
    setFeedback('');
  }, [activeStep, activeMessage]);

  if (!staged) return null;

  function changeMessage(step: ApprovalStep, action: 'edit' | 'regenerate' | 'ready') {
    try {
      const updated = updateStagedMessage(order, step, message, action, staffName);
      onSave(updated);
      setMessage(updated.inspection!.stagedApproval!.steps[step]!.message);
      setError('');
      setFeedback(action === 'ready'
        ? '발송 준비를 기록했습니다. 실제 발송은 되지 않았습니다.'
        : action === 'regenerate' ? '현재 검수 내용으로 문안을 다시 생성했습니다.' : '문안을 저장했습니다. 발송 준비 기록은 다시 필요합니다.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '문안을 기록하지 못했습니다.');
      setFeedback('');
    }
  }

  function confirmResponse(step: ApprovalStep) {
    try {
      const updated = recordStagedResponse(order, step, choice as StagedResponse, content, staffName,
        respondedAt || undefined);
      onSave(updated);
      setError('');
      setFeedback('직원이 고객 회신을 확인해 기록했습니다.');
      setChoice('');
      setRespondedAt('');
      setContent('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '고객 회신을 기록하지 못했습니다.');
      setFeedback('');
    }
  }

  return (
    <section className="professional-inspection__panel professional-inspection__staged" data-testid="inspection-staged-approval">
      <div className="professional-inspection__section-heading">
        <h2>단계별 고객 확인</h2><span>직원 확인 · 순서대로 진행</span>
      </div>
      <p className="professional-inspection__staged-intro">고객에게는 현재 단계의 문안만 안내합니다. 발송 준비는 기록만 남기며, 메시지를 실제로 보내거나 회신을 자동 해석하지 않습니다.</p>
      <div className={`professional-inspection__staged-outcome${staged.outcome === 'approved' ? ' professional-inspection__staged-outcome--approved' : ''}`}
        role="status" data-testid="status-staged-outcome">
        <span>현재 진행 상태</span><strong>{outcomes[staged.outcome]}</strong>
        {staged.outcome === 'care-label-requested' && <p>고객 요청에 따라 케어라벨 기준 세탁 진행 — 직원 검토 대기. 제안한 변경 세탁방법은 승인되지 않았습니다. 작업 전 방법을 다시 확인해 주세요.</p>}
        {staged.outcome === 'method-declined' && <p>고객이 변경 세탁방법과 위험 안내에 동의하지 않았습니다. 추가요금을 안내하거나 변경 작업을 시작하지 마세요.</p>}
        {staged.outcome === 'price-declined' && <p>고객이 추가요금을 확인하고 진행하지 않기로 했습니다. 세탁 작업을 시작하지 마세요.</p>}
      </div>
      <div className="professional-inspection__staged-steps">
        {steps.map((step) => {
          const record = staged.steps[step];
          const locked = !record;
          const active = staged.outcome === 'in-progress' && activeStep === step;
          return <section key={step}
            className={`professional-inspection__staged-step${locked ? ' professional-inspection__staged-step--locked' : ''}${active ? ' professional-inspection__staged-step--active' : ''}`}
            aria-label={`${step}단계 ${titles[step]}`} data-testid={`staged-step-${step}`}>
            <div className="professional-inspection__staged-step-head">
              <span className="professional-inspection__staged-number">{String(step).padStart(2, '0')}</span>
              <div><h3>{titles[step]}</h3><span>{locked ? '이전 단계 회신 확인 후 열림' : record.response && !active ? '고객 회신 확인됨' : active ? '현재 확인 단계' : '확인 완료'}</span></div>
            </div>
            {locked ? <p className="professional-inspection__staged-locked">이전 단계 고객 회신을 직원이 확인하면 문안이 열립니다.</p> : <>
              {record.response && <div className="professional-inspection__staged-response-history" data-testid={`staged-response-history-${step}`}>
                <strong>확인한 고객 회신 · {record.response.choice}</strong>
                <p>고객 회신 {formatDate(record.response.respondedAt)} · 직원 확인 {formatDate(record.response.confirmedAt)} · {record.response.staffName}</p>
                {record.response.content && <p>기록: {record.response.content}</p>}
              </div>}
              {active && <>
                <label className="professional-inspection__field">고객 안내 문안 · 직원 검토 후 저장
                  <textarea rows={7} value={message} onChange={(event) => { setMessage(event.target.value); setFeedback(''); }}
                    data-testid={`staged-message-${step}`} />
                </label>
                <label className="professional-inspection__field">확인 직원 · 필수
                  <input value={staffName} onChange={(event) => setStaffName(event.target.value)}
                    autoComplete="name" placeholder="담당 직원 이름" data-testid={`staged-staff-name-${step}`} />
                </label>
                <div className="professional-inspection__actions">
                  <button type="button" onClick={() => changeMessage(step, 'edit')} data-testid={`button-staged-save-${step}`}>문안 저장</button>
                  <button type="button" onClick={() => changeMessage(step, 'regenerate')} data-testid={`button-staged-regenerate-${step}`}>문안 다시 생성</button>
                  <button type="button" className="professional-inspection__primary" onClick={() => changeMessage(step, 'ready')}
                    data-testid={`button-staged-ready-${step}`}>발송 준비</button>
                </div>
                {record.readyAt
                  ? <p className="professional-inspection__staged-prepared" role="status">발송 준비 기록: {formatDate(record.readyAt)} · {record.readyBy} · 실제 발송 아님{message !== record.message && ' · 수정 중인 문안을 다시 준비해 주세요.'}</p>
                  : <p className="professional-inspection__staged-hint">발송 준비를 기록한 뒤에만 실제 고객 회신을 확인할 수 있습니다.</p>}
                <div className="professional-inspection__staged-reply">
                  <h4>고객 회신 직접 확인</h4>
                  <p>직원이 실제 회신을 확인하고 선택합니다. 자동 응답 처리나 고객 발송은 하지 않습니다.</p>
                  <label className="professional-inspection__field">고객 회신 선택
                    <select value={choice} onChange={(event) => setChoice(event.target.value as StagedResponse | '')}
                      data-testid={`staged-choice-${step}`}>
                      <option value="">선택해 주세요</option>
                      {STAGED_RESPONSES[step].map((option) => <option key={option} value={option}>{option}</option>)}
                    </select>
                  </label>
                  <label className="professional-inspection__field">실제 고객 회신 일시
                    <input type="datetime-local" value={respondedAt} onChange={(event) => setRespondedAt(event.target.value)}
                      data-testid={`staged-responded-at-${step}`} />
                  </label>
                  <label className="professional-inspection__field">회신 내용 · 확인 메모
                    <textarea value={content} onChange={(event) => setContent(event.target.value)}
                      placeholder="고객이 남긴 말이나 확인 경위를 기록해 주세요." data-testid={`staged-response-content-${step}`} />
                  </label>
                  <button type="button" className="professional-inspection__primary" onClick={() => confirmResponse(step)}
                    disabled={!record.readyAt || message !== record.message} data-testid={`button-staged-confirm-${step}`}>고객 회신 확인 기록</button>
                </div>
              </>}
              {!active && <p className="professional-inspection__staged-past-message">확인 당시 문안: {record.message}</p>}
              {!active && record.readyAt && <p className="professional-inspection__staged-hint">발송 준비: {formatDate(record.readyAt)} · {record.readyBy} · 실제 발송 아님</p>}
            </>}
          </section>;
        })}
      </div>
      {feedback && <p className="professional-inspection__staged-feedback" role="status">{feedback}</p>}
      {error && <p className="professional-inspection__error" role="alert" data-testid="staged-error">{error}</p>}
    </section>
  );
}