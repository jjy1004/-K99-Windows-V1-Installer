import { useState, type ReactNode } from 'react';
import type { CustomerSafeCareResult } from './garment-care';
import './care-result-card.css';
import {printCareCard} from './general-print';

type PublicShape =
  | { type: 'pen'; points: readonly { x: number; y: number }[] }
  | { type: 'circle' | 'rectangle' | 'arrow'; x: number; y: number; width: number; height: number }
  | { type: 'text'; x: number; y: number; text: string };

type PhotoPreviewStatus = 'pending' | 'available' | 'missing' | 'failed';

type CareResultImagePreviews = {
  before: string | null;
  after: string | null;
  beforeStatus: PhotoPreviewStatus;
  afterStatus: PhotoPreviewStatus;
  beforeSimulated: boolean;
  afterSimulated: boolean;
};

function MetadataPhoto({ label, photo, preview, status, simulated, children }: {
  label: string;
  photo: { timestamp: string; simulated: boolean } | null;
  preview?: string | null;
  status?: PhotoPreviewStatus;
  simulated?: boolean;
  children?: ReactNode;
}) {
  const emptyTitle = status === 'missing' ? '등록된 사진 없음'
    : status === 'failed' ? '사진 미리보기 실패'
      : status === 'pending' ? '사진 미리보기 준비 중'
        : photo ? '사진 이미지 미제공' : '등록된 사진 없음';
  const emptyDescription = status === 'failed' ? 'PENDING STORE-PC LOCAL BRIDGE TEST'
    : status === 'missing' ? '활성 연결 사진 없음 · PENDING STORE-PC LOCAL BRIDGE TEST'
      : status === 'pending' ? '직원 화면에서 사진 미리보기를 확인하고 있습니다.'
        : photo ? '저장된 메타데이터만 표시합니다. 이미지 파일은 포함되지 않습니다.' : '사진 메타데이터가 없습니다.';
  return <div className="crc-photo">
    <span className="crc-photo-label">{label}</span>
    <div className="crc-photo-image-frame">
      {preview
        ? <img className="crc-photo-image" src={preview} alt={label} />
        : <div className="crc-photo-empty"><strong>{emptyTitle}</strong><small>{emptyDescription}</small></div>}
      {preview && simulated && <span className="crc-sample-badge">시뮬레이션 샘플</span>}
      {children}
    </div>
    {photo && <p>{new Date(photo.timestamp).toLocaleString('ko-KR')} · {photo.simulated ? '시뮬레이션 저장' : '사진 기록 있음 · 이미지 미제공'}</p>}
  </div>;
}

function SafeAnnotations({ shapes, hidden }: { shapes: readonly PublicShape[]; hidden: boolean }) {
  if (hidden || !shapes.length) return null;
  return <svg className="crc-annotations" viewBox="0 0 1000 700" aria-label="고객 안내 사진 주석">
    {shapes.map((shape, index) => {
      const key = `${shape.type}-${index}`;
      if (shape.type === 'pen') return <polyline key={key} points={shape.points.map((point) =>
        `${point.x * 1000},${point.y * 700}`).join(' ')} />;
      if (shape.type === 'text') return <text key={key} x={shape.x * 1000} y={shape.y * 700}>{shape.text}</text>;
      if (shape.type === 'circle') return <ellipse key={key} cx={(shape.x + shape.width / 2) * 1000}
        cy={(shape.y + shape.height / 2) * 700} rx={shape.width * 500} ry={shape.height * 350} />;
      if (shape.type === 'arrow') return <line key={key} x1={shape.x * 1000} y1={shape.y * 700}
        x2={(shape.x + shape.width) * 1000} y2={(shape.y + shape.height) * 700} markerEnd="url(#crc-arrow)" />;
      return <rect key={key} x={shape.x * 1000} y={shape.y * 700}
        width={shape.width * 1000} height={shape.height * 700} />;
    })}
    <defs><marker id="crc-arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="currentColor" />
    </marker></defs>
  </svg>;
}

export function CareResultCard({ result, customerName, imagePreviews, onPrevious, onNext, onClose }: {
  result: CustomerSafeCareResult;
  customerName?: string;
  imagePreviews?: CareResultImagePreviews;
  onPrevious?: () => void;
  onNext?: () => void;
  onClose?: () => void;
}) {
  const [annotationsVisible, setAnnotationsVisible] = useState(true);
  const [compare, setCompare] = useState(true);
  const latestAfter = result.afterPhotos.at(-1) ?? null;

  return <main className="crc">
    <article className="crc-card">
      <header className="crc-header">
        <div><span className="crc-kicker">K99 · CARE RESULT</span><p className="crc-brand">{result.brand}</p></div>
        {onClose && <button type="button" className="crc-close" onClick={onClose}>고객 화면 종료</button>}
      </header>
      <section className="crc-intro">
        <span>GARMENT CARE RECORD</span>
        <h1>세탁 결과 안내</h1>
        <p>{result.garmentName}</p>
        {customerName && <small>{customerName} 고객님</small>}
      </section>
      <section className="crc-care"><h2>접수 당시 상태</h2><p>{result.intakeCondition || '접수 상태 기록 없음'}</p></section>
      <div className="crc-controls">
        <button type="button" onClick={() => setAnnotationsVisible((value) => !value)}>
          {annotationsVisible ? '주석 숨기기' : '주석 표시'}
        </button>
        <button type="button" onClick={() => setCompare((value) => !value)}>
          {compare ? '사진 비교 끄기' : '전·후 비교 보기'}
        </button>
      </div>
      <section className={`crc-photo-grid ${compare ? '' : 'crc-photo-grid--single'}`}>
        <div className="crc-before-wrap">
          <MetadataPhoto label="[세탁 전] BEFORE · 접수 시" photo={result.beforePhoto}
            preview={imagePreviews?.before} status={imagePreviews?.beforeStatus}
            simulated={imagePreviews?.beforeSimulated}>
            <SafeAnnotations shapes={result.beforeAnnotations as readonly PublicShape[]} hidden={!annotationsVisible} />
          </MetadataPhoto>
        </div>
        {compare && <div className="crc-after-stack">
          <MetadataPhoto label="[세탁 후] AFTER · 완성" photo={latestAfter}
            preview={imagePreviews?.after} status={imagePreviews?.afterStatus}
            simulated={imagePreviews?.afterSimulated} />
          {result.afterPhotos.length > 1 && <p className="crc-count">완성 사진 {result.afterPhotos.length}건이 연결되어 있습니다.</p>}
        </div>}
      </section>
      <section className="crc-care">
        <h2>실제 케어 공정</h2>
        {result.careProcesses.length
          ? <ul>{result.careProcesses.map((item, index) => <li key={`${item}-${index}`}>{item}</li>)}</ul>
          : <p>기록된 케어 공정이 없습니다.</p>}
        <h2>케어 안내</h2><p className="crc-summary">{result.careSummary}</p>
        {result.completionComment && <><h2>완성 코멘트</h2><p className="crc-summary">{result.completionComment}</p></>}
      </section>
      <footer className="crc-footer">
        <span>본 카드는 고객 안내용입니다. 실제 사진 전송 또는 메시지 발송은 수행되지 않습니다.</span>
        <button type="button" onClick={() => {void printCareCard().catch(error=>window.alert(error.message));}}>고객용 카드 인쇄 · PDF 저장</button>
        <nav>{onPrevious && <button type="button" onClick={onPrevious}>이전 세탁물</button>}
          {onNext && <button type="button" onClick={onNext}>다음 세탁물</button>}</nav>
      </footer>
    </article>
  </main>;
}

export default CareResultCard;