import { useEffect, useRef, useState } from 'react';
import bwipjs from 'bwip-js/browser';
import type { GarmentTagData } from './garment-record';
import type { PhotoBridgeTagTemplate } from './passive-photo-client';
import { resolvePhotoBridgeTagElements } from './photo-tag-jobs';

const textTestIds: Record<string, string> = {
  customerName: 'text-tag-customer-name',
  itemName: 'text-tag-item-name',
  garmentId: 'text-tag-garment-number',
  orderNumber: 'text-tag-order-number',
  serviceLabel: 'text-tag-service-type',
};

export function GarmentTagPreview({ tag, template }: {
  tag: GarmentTagData;
  template: PhotoBridgeTagTemplate;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState('');
  let elements: ReturnType<typeof resolvePhotoBridgeTagElements> = [];
  let resolutionError = '';
  try {
    elements = resolvePhotoBridgeTagElements(template, tag);
  } catch (cause) {
    resolutionError = cause instanceof Error ? cause.message : '태그 템플릿의 의류 ID를 확인할 수 없습니다.';
  }
  const barcode = elements.find(({ element }) => element.type === 'code');

  useEffect(() => {
    if (resolutionError || !canvasRef.current || barcode?.element.type !== 'code') return;
    try {
      bwipjs.toCanvas(canvasRef.current, {
        bcid: barcode.element.kind === 'qr' ? 'qrcode' : 'code128',
        // The barcode contains only this garment's opaque identifier, never customer data.
        text: tag.garmentId,
        scale: barcode.element.kind === 'qr' ? 3 : 2,
        height: barcode.element.heightMm,
        includetext: false,
      });
      setError('');
    } catch {
      setError('바코드 미리보기를 만들지 못했습니다.');
    }
  }, [tag.garmentId, barcode?.element.type === 'code' ? barcode.element.kind : undefined,
    barcode?.element.type === 'code' ? barcode.element.widthMm : undefined,
    barcode?.element.type === 'code' ? barcode.element.heightMm : undefined, resolutionError]);

  if (resolutionError) return <div role="alert" data-testid="preview-garment-tag">{resolutionError}</div>;

  return <div
    style={{
      position: 'relative', boxSizing: 'border-box', width: `min(100%, ${template.page.widthMm}mm)`,
      aspectRatio: `${template.page.widthMm} / ${template.page.heightMm}`, overflow: 'hidden',
      background: '#fff', color: '#17232c', border: '1px solid #d5dadd', borderRadius: 4,
      boxShadow: '0 2px 8px #17232c18',
    }}
    data-testid="preview-garment-tag"
    data-template-id={template.id}
  >
    {elements.map(({ element, value }) => {
      const position = {
        position: 'absolute' as const,
        left: `${element.xMm}mm`,
        top: `${element.yMm}mm`,
        width: `${element.widthMm}mm`,
        height: `${element.heightMm}mm`,
        boxSizing: 'border-box' as const,
        overflow: 'hidden',
      };
      if (element.type === 'code') {
        return <canvas
          key={element.field}
          ref={canvasRef}
          style={{ ...position, maxWidth: '100%' }}
          aria-label={`${element.kind === 'qr' ? 'QR' : 'Code 128'} · garmentId ${tag.garmentId}`}
          data-testid="preview-garment-barcode"
        />;
      }
      return <div
        key={element.field}
        style={{
          ...position,
          fontSize: `${element.fontSizePt}pt`,
          fontWeight: element.bold ? 700 : 400,
          lineHeight: 1.08,
          overflowWrap: 'anywhere',
          whiteSpace: 'pre-wrap',
        }}
        data-testid={textTestIds[element.field]}
      >{value}</div>;
    })}
    {error && <div role="alert" data-testid="status-tag-barcode-preview-error">{error}</div>}
    <small style={{ position: 'absolute', left: 3, bottom: 1, fontSize: 8 }} data-testid="text-tag-preview-verification">
      {template.verification} · 외부 JSON 서식 · 실물 크기와 인쇄 결과 미확인
    </small>
  </div>;
}