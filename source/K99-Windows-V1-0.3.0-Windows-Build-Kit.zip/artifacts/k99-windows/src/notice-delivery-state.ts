import {useCallback, useSyncExternalStore} from 'react';
import {noticeApi, NOTICE_DELIVERY_CHANGED, type NoticeDeliveryState} from './notice-api';

type Snapshot = {states: NoticeDeliveryState[]; failed: boolean};
const EMPTY: Snapshot = {states: [], failed: false};
const cache = new Map<string, Snapshot>();
const listeners = new Map<string, Set<() => void>>();
const queued = new Set<string>();
const versions = new Map<string, number>();
let timer: ReturnType<typeof setTimeout> | undefined;
function queue(ids: Iterable<string>) {
  for (const id of ids) { queued.add(id); versions.set(id, (versions.get(id) || 0) + 1); }
  if (!timer && queued.size) timer = setTimeout(() => { timer = undefined; void flush(); }, 5);
}
function publish(id: string, next: Snapshot) {
  if (JSON.stringify(next) === JSON.stringify(cache.get(id) || EMPTY)) return;
  cache.set(id, next); listeners.get(id)?.forEach(fn => fn());
}
async function flush() {
  const ids = [...queued]; queued.clear();
  for (let i = 0; i < ids.length; i += 200) {
    const batch = ids.slice(i, i + 200), revisions = batch.map(id => versions.get(id));
    try {
      const result = await noticeApi<{states: NoticeDeliveryState[]}>('POST', '/delivery-status', {orderIds: batch});
      batch.forEach((id, n) => {
        if (versions.get(id) === revisions[n])
          publish(id, {states: result.states.filter(state => state.orderId === id), failed: false});
      });
    } catch {
      batch.forEach((id, n) => {
        if (versions.get(id) === revisions[n]) publish(id, {...(cache.get(id) || EMPTY), failed: true});
      });
    }
  }
}
const refresh = () => queue(listeners.keys());
function subscribe(id: string, fn: () => void) {
  const first = !listeners.size;
  const set = listeners.get(id) || new Set<() => void>(); set.add(fn); listeners.set(id, set);
  if (first) {
    window.addEventListener(NOTICE_DELIVERY_CHANGED, refresh);
    window.addEventListener('focus', refresh); window.addEventListener('storage', refresh);
  }
  queue([id]);
  return () => {
    set.delete(fn); if (!set.size) listeners.delete(id);
    if (!listeners.size) {
      window.removeEventListener(NOTICE_DELIVERY_CHANGED, refresh);
      window.removeEventListener('focus', refresh); window.removeEventListener('storage', refresh);
    }
  };
}
export function deliveryView(states: NoticeDeliveryState[], templateIds?: readonly string[]) {
  const relevant = states.filter(state => !templateIds || templateIds.includes(state.templateId));
  const sent = relevant.filter(state => state.sentAt).sort((a, b) => b.sentAt!.localeCompare(a.sentAt!))[0];
  const prepared = [...relevant].sort((a, b) => b.preparedAt.localeCompare(a.preparedAt))[0];
  return sent ? {kind: 'sent' as const, at: sent.sentAt!, summaryOnly: sent.summaryOnly,
    preparingAgain: !!prepared && prepared.preparedAt > sent.sentAt!}
    : prepared ? {kind: 'prepared' as const, at: prepared.preparedAt, summaryOnly: prepared.summaryOnly, preparingAgain: false}
    : {kind: 'none' as const, at: '', summaryOnly: false, preparingAgain: false};
}
export function deliveryTime(at: string) {
  const date = new Date(at);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('ko-KR', {
    timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
  });
}
export function useNoticeDelivery(orderId: string | undefined, templateIds?: readonly string[]) {
  const connect = useCallback((fn: () => void) => orderId ? subscribe(orderId, fn) : () => {}, [orderId]);
  const snapshot = useSyncExternalStore(connect, () => orderId ? cache.get(orderId) || EMPTY : EMPTY, () => EMPTY);
  return {...deliveryView(snapshot.states, templateIds), failed: snapshot.failed, records: snapshot.states};
}
