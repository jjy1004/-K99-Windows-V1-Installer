import {useEffect,useState,useSyncExternalStore} from 'react';
import {CameraConnectionBadge,CameraPermissionDialog,CameraSetupGuide} from './CameraSetupGuide';
import {cameraHealth,checkCameraEnvironment} from './camera-health';
import './camera-care.css';

export function CameraHealthNotice(){
  const health=useSyncExternalStore(cameraHealth.subscribe,cameraHealth.state,cameraHealth.state);
  useEffect(()=>{
    void checkCameraEnvironment();
    const refresh=()=>{void checkCameraEnvironment();};
    const events=['focus','online','offline','k99-camera-resume'];
    events.forEach(event=>window.addEventListener(event,refresh));
    return ()=>events.forEach(event=>window.removeEventListener(event,refresh));
  },[]);
  return <CameraPermissionDialog open={health.dialogOpen} onClose={cameraHealth.close}
    onOpenSettings={()=>void cameraHealth.settings()} opening={health.opening} error={health.error}/>;
}

export function CameraCareControls({connected,connecting,mock,onGuideChange}:{
  connected:boolean;connecting?:boolean;mock:boolean;onGuideChange?:(open:boolean)=>void;
}){
  const [guide,setGuide]=useState(false);
  const health=useSyncExternalStore(cameraHealth.subscribe,cameraHealth.state,cameraHealth.state);
  useEffect(()=>{onGuideChange?.(guide||health.dialogOpen);return ()=>onGuideChange?.(false);},[guide,health.dialogOpen,onGuideChange]);
  useEffect(()=>{if(!connected)return;cameraHealth.close();},[connected]);
  return <div className="camera-care" data-camera-help-open={guide||health.dialogOpen?'true':undefined}>
    <CameraConnectionBadge connected={connected} connecting={connecting} mock={mock}/>
    <button type="button" className="camera-care__guide" onClick={()=>setGuide(true)}>촬영 준비 그림 안내 (딱 1번만)</button>
    {health.report?.permission.state==='denied'&&<button type="button" className="camera-care__permission"
      onClick={()=>{cameraHealth.show();void cameraHealth.settings();}}>카메라 권한 켜기</button>}
    {health.report&&<span className="camera-care__network" role="status">{health.report.network.note}</span>}
    <CameraSetupGuide open={guide} onClose={()=>setGuide(false)}/>
  </div>;
}
