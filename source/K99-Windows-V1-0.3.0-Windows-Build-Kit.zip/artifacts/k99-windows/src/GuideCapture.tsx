import { useEffect, useState } from 'react';
import { Camera, ImageOff, Pointer } from 'lucide-react';
import type { CaptureId } from './guide-data';
import bundledManifest from './guide-captures.json';

/**
 * public/guide-captures/manifest.json (확정 형식)
 * { "main": { "src": "main.jpg", "width": 1920, "height": 1080, "label": "실제 프로그램 화면",
 *             "targets": { "settings": { "x": 95, "y": 7, "label": "매장 맞춤 설정" } } } }
 * x·y = 이미지 전체 대비 0~100 백분율, 실제 버튼 중앙. manifest 에 없는 좌표는 표시하지 않는다.
 */
type Target = { x: number; y: number; label?: string };
export type CaptureEntry = { src: string; width: number; height: number; label?: string; targets?: Record<string, Target> };
type Manifest = Record<string, CaptureEntry>;

const BASE = `${import.meta.env.BASE_URL.replace(/\/?$/, '/')}guide-captures/`;
// Bundle the manifest: Electron file:// does not reliably allow fetching
// local JSON. Help must remain available offline without any IPC or DB access.
function loadManifest() {
  return Promise.resolve(bundledManifest as Manifest);
}

const valid = (e?: CaptureEntry): e is CaptureEntry => !!e && typeof e.src === 'string' &&
  /^[a-z0-9-]+\.(jpg|png|webp)$/.test(e.src) && e.width > 0 && e.height > 0;
const inRange = (n: unknown) => typeof n === 'number' && n >= 0 && n <= 100;

export function useCapture(id?: CaptureId) {
  const [st, setSt] = useState<{ state: 'loading' | 'ready' | 'missing'; entry?: CaptureEntry }>({ state: id ? 'loading' : 'missing' });
  useEffect(() => {
    if (!id) { setSt({ state: 'missing' }); return; }
    let live = true; setSt({ state: 'loading' });
    loadManifest().then(m => {
      if (!live) return;
      const e = m?.[id];
      setSt(valid(e) ? { state: 'ready', entry: e } : { state: 'missing' });
    });
    return () => { live = false; };
  }, [id]);
  return st;
}

const CIRCLED = ['①', '②', '③', '④', '⑤', '⑥'];

export function CaptureView({ entry, targetKeys, label, onFail }: { entry: CaptureEntry; targetKeys: string[]; label: string; onFail: () => void }) {
  const pins = targetKeys.map(k => entry.targets?.[k]).filter((t): t is Target => !!t && inRange(t.x) && inRange(t.y));
  return (
    <div>
    <figure className={`pg-shot${entry.height > entry.width ? ' is-portrait' : ''}`} style={{ aspectRatio: `${entry.width} / ${entry.height}` }}>
        <img src={`${BASE}${entry.src}`} alt={`${entry.label ?? '실제 화면'}: ${label}`} onError={onFail} draggable={false} data-testid="img-guide-capture" />
        {pins.map((p, i) => (
          <span key={i} className="pg-pin" style={{ left: `${p.x}%`, top: `${p.y}%` }} aria-hidden>
            <i className="pg-pin-ring" /><b>{i + 1}</b><Pointer className="pg-pin-touch" />
          </span>
        ))}
        <figcaption className="pg-badge pg-badge-real"><Camera aria-hidden />{entry.label ?? '실제 화면'}</figcaption>
      </figure>
      {pins.some(p => p.label) && <ol className="pg-pin-list">
        {pins.map((p, i) => p.label && <li key={i}><b>{CIRCLED[i] ?? i + 1}</b>{p.label}</li>)}
      </ol>}
    </div>
  );
}

export function CaptureMissing() {
  return (
    <p className="pg-missing" role="status" data-testid="text-guide-capture-missing">
      <ImageOff aria-hidden />실제 화면 사진이 아직 없거나 불러오지 못했습니다. 아래는 이해를 돕는 그림이며 실제 화면과 다를 수 있습니다.
    </p>
  );
}
