import {useEffect,useRef,useState} from 'react';
import {Monitor,Smartphone} from 'lucide-react';
import {noticeApi,type StoreProfile} from './notice-api';

export type SmsMode='MS'|'KDE';
export const KDE_SMS_WARNING="⚠️ 주의: [휴대폰으로 문자 보내기]를 누르면 중간 확인 창 없이 고객에게 문자가 즉시 발송됩니다. 위의 '보낼 글' 내용과 금액을 먼저 확인한 후 눌러 주세요.";
export function useSmsMode(){
  const [state,setState]=useState<{mode:SmsMode|null;error:string}>({mode:null,error:''});
  useEffect(()=>{
    let alive=true,revision=0;
    const load=()=>{
      const current=++revision;
      void noticeApi<{profile:StoreProfile}>('GET','/profile').then(({profile})=>{
        const mode=profile.smsMode??'MS';
        if(mode!=='MS'&&mode!=='KDE')throw Error('문자 발송 방식이 올바르지 않습니다.');
        if(alive&&current===revision)setState({mode,error:''});
      }).catch(()=>{if(alive&&current===revision)setState({mode:null,error:'문자 발송 방식을 불러오지 못했습니다.'});});
    };
    load();window.addEventListener('k99-store-profile-changed',load);window.addEventListener('focus',load);
    return()=>{alive=false;window.removeEventListener('k99-store-profile-changed',load);window.removeEventListener('focus',load);};
  },[]);
  return state;
}

export function SmsModeSettings(){
  const {mode,error}=useSmsMode();
  const [busy,setBusy]=useState(false),[saveError,setSaveError]=useState('');
  const locked=useRef(false);
  async function choose(next:SmsMode){
    if(locked.current||mode===next)return;
    locked.current=true;setBusy(true);setSaveError('');
    try{
      const current=await noticeApi<{profile:StoreProfile;revision:number}>('GET','/profile');
      await noticeApi('PUT','/profile',{profile:{...current.profile,smsMode:next},revision:current.revision});
    }catch(error){setSaveError(error instanceof Error?error.message:'문자 발송 방식을 저장하지 못했습니다.');}
    finally{locked.current=false;setBusy(false);}
  }
  return <section aria-label="문자 발송 방식">
    <div className="sh-actions" role="radiogroup" aria-label="문자 발송 방식">
      {(['MS','KDE'] as const).map(value=><button key={value} type="button" role="radio" aria-checked={mode===value}
        className={`sh-btn ${mode===value?'gold':'ghost'}`} disabled={busy||!mode}
        onClick={()=>void choose(value)} data-testid={`sms-mode-${value}`}>
        {value==='MS'?<Monitor aria-hidden/>:<Smartphone aria-hidden/>}{value}
      </button>)}
    </div>
    {(saveError||error)&&<p role="alert" className="lnd-msg err">{saveError||error}</p>}
  </section>;
}
