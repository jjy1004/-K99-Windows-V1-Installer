import { directoryRequest } from './customer-directory-client';
export type ComparisonMobileSession = {
  id: string; urls: string[]; expiresAt: number; uploadedCount: number;
  lastResult: null | { photo: { id: string; url: string; [k: string]: unknown }; archive: { folder: string; fileName: string } };
};
export const startComparisonMobile = (orderId: string, garmentId: string) =>
  directoryRequest<ComparisonMobileSession>('POST', '/api/comparison-mobile/start', { orderId, garmentId });
export const comparisonMobileStatus = (id: string) =>
  directoryRequest<ComparisonMobileSession>('GET', `/api/comparison-mobile/status?id=${encodeURIComponent(id)}`);
export const stopComparisonMobile = (id: string) =>
  directoryRequest<{ closed: boolean }>('POST', '/api/comparison-mobile/stop', { id });
