import type { VoucherReceipt } from './vouchers';
/** 출력·문자·카카오톡은 저장된 같은 정액권 영수증을 표시하며 잔액을 다시 계산하지 않는다. */
export function voucherReceiptText(r: VoucherReceipt): string {
  const won=(n:number)=>n.toLocaleString('ko-KR')+'원';
  const lines=[r.plan==='DEDUCT'?'결제 구분 : 정액권 차감 결제':
    `결제 구분 : ${r.label} 결제 (결제액 ${won(r.paidAmount)} / 이용 한도 ${won(r.credit)})`];
  if(r.laundryTotal>0){
    if(r.shortfall)lines.push(`오늘 세탁비 : ${won(r.laundryTotal)}`,`정액권 차감액 : ${won(r.debit)}`,`부족 차액 (별도 결제) : ${won(r.shortfall)}`);
    else lines.push(`오늘 세탁비 (정액권 차감) : ${won(r.debit)}`);
  }
  lines.push(`남은 정액권 잔액 : ${won(r.balanceAfter)}`);
  return lines.join('\n');
}
