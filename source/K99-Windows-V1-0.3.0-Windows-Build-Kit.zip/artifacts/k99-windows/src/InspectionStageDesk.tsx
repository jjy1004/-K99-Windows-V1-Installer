import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Copy, FolderOpen, Images } from 'lucide-react';
import { PROCESS_STAGES, updateSavedOrder, type ConfirmedOrder, type ProcessNoticeKind, type ProcessNoticeRecord } from './order-record';
import { currentProcessStage, moveProcessStage, nextProcessStage, noticeDraft, NOTICE_LABELS } from './process-stage';
import { garmentProcessStatus, advanceGarmentInOrder, type LaundryAction } from './laundry-process';
import type { LaundryProcessStatus } from './garment-record';
import { noticeFeeOf, recordFeeConsent, completeFieldInspection, fieldConsentPending, fieldReviewNeeds, recordFieldConsent, requiredAcknowledgements, type FieldItemReview } from './field-inspection';
import { IntakePhotoStrip } from './IntakePhotoStrip';
import { openPhotoFolder } from './equipment-client';
import { BeforeAfterComposer } from './BeforeAfterComposer';
import './inspection-stage-desk.css';

const won = (v: number) => `${v.toLocaleString('ko-KR')}원`;
const NOTICE_KINDS: ProcessNoticeKind[] = ['waiver', 'fee', 'both'];

type Props = { order: ConfirmedOrder; onSaved: (order: ConfirmedOrder) => void; onBack: () => void };

/** Direct-entry inspection desk: core facts, four freely navigable process tabs, one-step notice draft. */
export function InspectionStageDesk({ order, onSaved, onBack }: Props) {
  const stage = currentProcessStage(order);
  const reached = order.processStage?.reached ?? '접수';
  const saved = order.processNotice;
  const pending = fieldConsentPending(order);
  const [kind, setKind] = useState<ProcessNoticeKind | null>(saved?.kind ?? null);
  const [fee, setFee] = useState(saved?.technicalFee ?? 0);
  const [message, setMessage] = useState(saved?.message ?? order.inspection?.shortCustomerMessage ?? order.inspection?.customerMessage ?? '');
  // Never defaulted: staff must explicitly pick one.
  const [consent, setConsent] = useState<ProcessNoticeRecord['consent']>(null);
  const needs = order.inspection ? [] : fieldReviewNeeds(order);
  const [reviews, setReviews] = useState<Record<number, FieldItemReview>>({});
  const review = (i: number) => reviews[i] ?? { confirmed: false, memo: '' };
  const patchReview = (i: number, p: Partial<FieldItemReview>) => setReviews((r) => ({ ...r, [i]: { ...review(i), ...p } }));
  const [status, setStatus] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [composing, setComposing] = useState(false);

  function persist(apply: (o: ConfirmedOrder) => ConfirmedOrder, ok: string) {
    try {
      const updated = apply(order);
      updateSavedOrder(updated, order);
      onSaved(updated);
      setStatus({ kind: 'ok', text: ok });
      return true;
    } catch (c) {
      setStatus({ kind: 'error', text: c instanceof Error ? c.message : '저장하지 못했습니다. 원본은 보존했습니다.' });
      return false;
    }
  }

  function chooseKind(k: ProcessNoticeKind) {
    setKind(k);
    setMessage(noticeDraft(order, k, k === 'waiver' ? 0 : fee));
  }

  function saveNotice() {
    if (!message.trim()) return;
    const at = new Date();
    persist((o) => {
      let updated: ConfirmedOrder = { ...o, processNotice: { kind: kind ?? o.processNotice?.kind ?? 'waiver', message: message.trim(),
        technicalFee: kind && kind !== 'waiver' ? fee : 0, consent, savedAt: at.toISOString(), actuallySent: false } };
      if (fieldConsentPending(o) && consent) updated = recordFieldConsent(updated, { consent, message }, at);
      else if (consent && (noticeFeeOf(updated) > 0 || updated.feeAdjustment)) updated = recordFeeConsent(updated, { consent, message }, at);
      return updated;
    }, consent
      ? `${consent} 기록을 저장했습니다.${consent === '동의 완료' && kind && kind !== 'waiver' ? ' 추가 기술료를 최종 금액에 반영했습니다.' : ' 금액은 바뀌지 않았습니다.'} 매장 직원 확인 기록이며 문자 발송이나 고객 서명이 아닙니다.`
      : '안내 문안을 저장했습니다. 문자 발송은 매장 휴대폰에서 직접 해 주세요.');
    setConsent(null);
  }

  async function copyNotice() {
    try { await navigator.clipboard.writeText(message); setStatus({ kind: 'ok', text: '문안을 복사했습니다. 문자 앱에 붙여 넣어 발송해 주세요.' }); }
    catch { setStatus({ kind: 'error', text: '클립보드에 복사하지 못했습니다. 문안을 직접 선택해 복사해 주세요.' }); }
  }

  /** Real garment transitions for the step being confirmed. Any failure aborts the whole move. */
  function progressGarments(o: ConfirmedOrder, target: string): ConfirmedOrder {
    const order_: LaundryProcessStatus[] = ['접수 완료', '촬영/태그 완료', '전문검수 완료', '세탁 대기', '세탁 중', '세탁 완료', '완성 검수', '출고 대기', '반출 완료'];
    const goal: LaundryProcessStatus = target === '세탁 후' ? '세탁 완료' : '완성 검수';
    const plan: [LaundryProcessStatus, LaundryAction][] = target === '세탁 후'
      ? [['세탁 대기', 'start'], ['세탁 중', 'complete']] : [['세탁 완료', 'inspect']];
    let updated = o;
    for (const g of o.garments ?? []) {
      for (const [from, action] of plan) {
        const cur = updated.garments!.find((x) => x.garmentId === g.garmentId)!;
        if (garmentProcessStatus(updated, cur) === from) updated = advanceGarmentInOrder(updated, g.garmentId, action);
      }
      const cur = updated.garments!.find((x) => x.garmentId === g.garmentId)!;
      const status = garmentProcessStatus(updated, cur);
      if (order_.indexOf(status) < order_.indexOf(goal))
        throw new Error(`${g.itemName} 의류가 현재 ${status} 상태라 ${target} 단계로 넘어갈 수 없습니다.`);
    }
    return updated;
  }

  function goNext() {
    const target = nextProcessStage(stage);
    if (!target) return;
    persist((o) => {
      let updated = o;
      if (target === '세탁 전' && !updated.inspection)
        updated = completeFieldInspection(updated, reviews);
      if (target === '세탁 후' || target === '완료 검수') {
        if (updated.inspection?.needsApproval && updated.status !== '세탁 진행 승인')
          throw new Error('세탁 전 단계에서 고객 동의 완료를 먼저 기록해 주세요.');
        updated = progressGarments(updated, target);
      }
      return moveProcessStage(updated, target, 'next');
    }, `${target} 단계로 전진했습니다.`);
  }

  async function openFolder(k: 'intake' | 'comparison') {
    try { const r = await openPhotoFolder(order.id, k); setStatus({ kind: 'ok', text: `탐색기에서 열었습니다 · ${r.folder}` }); }
    catch (c) { setStatus({ kind: 'error', text: c instanceof Error ? c.message : '폴더를 열지 못했습니다.' }); }
  }

  const next = nextProcessStage(stage);
  const garments = order.garments ?? [];

  return (
    <main className="isd" data-testid="screen-inspection-stage-desk">
      <div className="isd__wrap">
        <header className="isd__top">
          <button type="button" className="isd__ghost" onClick={onBack} data-testid="button-isd-back-top"><ArrowLeft aria-hidden="true" />뒤로 가기</button>
          <nav className="isd__tabs" aria-label="공정 단계">
            {PROCESS_STAGES.map((s, i) => (
              <button key={s} type="button" aria-current={s === stage ? 'step' : undefined}
                className={PROCESS_STAGES.indexOf(reached) >= i ? 'is-reached' : ''}
                onClick={() => s !== stage && persist((o) => moveProcessStage(o, s, 'tab'), `${s} 화면으로 이동했습니다.`)}
                data-testid={`tab-process-${i}`}><span>{i + 1}</span>{s}</button>
            ))}
          </nav>
        </header>

        <section className="isd__facts" aria-label="기본 정보">
          <div><span>고객명</span><strong data-testid="text-isd-customer">{order.customerName}</strong></div>
          <div><span>연락처</span><strong data-testid="text-isd-phone">{order.customerPhone}</strong></div>
          <div className="isd__wide"><span>품목</span><strong data-testid="text-isd-items">{order.items.map((i) => `${i.displayNameKo} × ${i.quantity}`).join(', ')}</strong></div>
          <div><span>주문번호</span><strong className="isd__mono" data-testid="text-isd-order">{order.id}</strong></div>
        </section>

        <section className="isd__panel" key={stage}>
          {stage === '접수' && <>
            <h2>접수 상태 확인</h2>
            <IntakePhotoStrip garments={garments} />
            {!order.inspection && needs.length > 0 && <div className="isd__draft" data-testid="section-isd-item-review">
              <strong>개별 확인이 필요한 품목</strong>
              {needs.map((n) => {
                const item = order.items[n.index]; const r = review(n.index);
                return <div key={n.index} className="isd__garments" data-testid={`row-isd-review-${n.index}`}>
                  <span>{item.displayNameKo} × {item.quantity} · {n.reasons.join(', ')}</span>
                  {!item.isSneaker && <div className="isd__consent">
                    <span>세탁 방법</span>
                    {(['물세탁', '드라이세탁'] as const).map((m) => <button key={m} type="button" role="radio"
                      aria-checked={(r.method ?? item.plannedCleaningMethod) === m} onClick={() => patchReview(n.index, { method: m })}
                      data-testid={`toggle-review-method-${n.index}-${m}`}>{m}</button>)}
                  </div>}
                  <div className="isd__consent">
                    <span>검수 결과</span>
                    {(['이상 없음', '주의 필요'] as const).map((v) => <button key={v} type="button" role="radio" aria-checked={r.result === v}
                      onClick={() => patchReview(n.index, { result: v })} data-testid={`toggle-review-result-${n.index}-${v}`}>{v}</button>)}
                    <button type="button" role="checkbox" aria-checked={r.confirmed} onClick={() => patchReview(n.index, { confirmed: !r.confirmed })}
                      data-testid={`toggle-review-confirmed-${n.index}`}>실물 확인함</button>
                  </div>
                  <input value={r.memo} onChange={(e) => patchReview(n.index, { memo: e.target.value })}
                    placeholder="메모 (주의 필요 또는 방법 변경 시 내용)" data-testid={`input-review-memo-${n.index}`} />
                </div>;
              })}
            </div>}
            <div className="isd__row">
              <button type="button" className="isd__ghost" onClick={() => void openFolder('intake')} data-testid="button-isd-intake-folder"><FolderOpen aria-hidden="true" />세탁 접수 사진 폴더</button>
            </div>
          </>}

          {stage === '세탁 전' && <>
            <h2>이상 세탁물 고객 안내</h2>
            <div className="isd__kinds" role="group" aria-label="안내 유형">
              {NOTICE_KINDS.map((k) => <button key={k} type="button" aria-pressed={kind === k} onClick={() => chooseKind(k)}
                data-testid={`button-notice-${k}`}>{NOTICE_LABELS[k]}</button>)}
            </div>
            {pending && <p className="isd__meta" data-testid="text-isd-consent-needed">
              고객 동의가 필요한 주문입니다. 아래 문안으로 안내한 뒤 고객 의사를 직접 확인하고 하나를 선택해 저장하세요.
              동의 완료는 다음 항목 확인으로 기록됩니다: {requiredAcknowledgements(order).join(', ')}</p>}
            {(kind || pending) && <div className="isd__draft">
              {kind && kind !== 'waiver' && <label className="isd__fee">추가 기술료
                <input inputMode="numeric" value={fee || ''} placeholder="0"
                  onChange={(e) => { const v = Number(e.target.value.replace(/\D/g, '')) || 0; setFee(v); setMessage(noticeDraft(order, kind, v)); }}
                  data-testid="input-notice-fee" /> 원 <small>동의 완료 시 최종 {won((order.feeAdjustment?.baseEstimatedTotal ?? order.estimatedTotal) + fee)} · 현재 {won(order.estimatedTotal)}</small></label>}
              <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={7} data-testid="input-notice-message" />
              <div className="isd__consent" role="radiogroup" aria-label="고객 사전 동의 여부">
                <span>고객 사전 동의</span>
                {(['동의 완료', '미동의'] as const).map((c) => <button key={c} type="button" role="radio" aria-checked={consent === c}
                  onClick={() => setConsent(c)} data-testid={`toggle-consent-${c === '동의 완료' ? 'yes' : 'no'}`}>{c}</button>)}
              </div>
              <div className="isd__row">
                <button type="button" className="isd__ghost" onClick={() => void copyNotice()} data-testid="button-notice-copy"><Copy aria-hidden="true" />문안 복사</button>
                <button type="button" className="isd__primary" onClick={saveNotice} disabled={!message.trim()} data-testid="button-notice-save"><Check aria-hidden="true" />저장</button>
              </div>
              {saved && <p className="isd__meta" data-testid="text-notice-saved">마지막 저장 {new Date(saved.savedAt).toLocaleString('ko-KR')} · {NOTICE_LABELS[saved.kind]} · {saved.consent} · 앱에서 문자를 보내지 않습니다</p>}
            </div>}
            {!kind && !pending && <p className="isd__meta">안내가 필요 없으면 바로 다음 단계로 진행하세요.</p>}
          </>}

          {(stage === '세탁 후' || stage === '완료 검수') && <>
            <h2>{stage === '세탁 후' ? '세탁 결과 확인' : '완료 검수'}</h2>
            <ul className="isd__garments">
              {garments.map((g) => <li key={g.garmentId} data-testid={`row-isd-garment-${g.garmentId}`}>
                <span>{g.itemName}</span><em>{garmentProcessStatus(order, g)}</em></li>)}
            </ul>
            <div className="isd__row">
              <button type="button" className="isd__ghost" onClick={() => void openFolder('comparison')} data-testid="button-isd-comparison-folder"><FolderOpen aria-hidden="true" />세탁 전후 사진 폴더</button>
              <button type="button" className="isd__ghost" onClick={() => setComposing(true)} data-testid="button-isd-before-after"><Images aria-hidden="true" />세탁 전·후 사진 만들기</button>
            </div>
          </>}
        </section>

        {status && <p className={status.kind === 'ok' ? 'isd__ok' : 'isd__err'} role="status" data-testid="status-isd">{status.text}</p>}

        <footer className="isd__foot">
          <button type="button" className="isd__ghost" onClick={() => {
            const i = PROCESS_STAGES.indexOf(stage);
            if (i > 0) persist((o) => moveProcessStage(o, PROCESS_STAGES[i - 1], 'tab'), `${PROCESS_STAGES[i - 1]} 화면으로 이동했습니다.`);
            else onBack();
          }} data-testid="button-isd-back"><ArrowLeft aria-hidden="true" />뒤로 가기</button>
          {next ? <button type="button" className="isd__primary" onClick={goNext} data-testid="button-isd-next">확인 완료 · 다음 단계 ({next})<ArrowRight aria-hidden="true" /></button>
            : <span className="isd__done" data-testid="status-isd-complete">완료 검수 단계입니다</span>}
        </footer>
      </div>
      {composing && <BeforeAfterComposer order={order} onClose={() => setComposing(false)} />}
    </main>
  );
}
