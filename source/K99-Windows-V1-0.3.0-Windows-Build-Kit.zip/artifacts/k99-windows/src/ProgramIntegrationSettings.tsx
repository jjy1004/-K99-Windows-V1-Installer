import { useEffect, useState } from 'react';
import { DEFAULT_LUXURY_URL, readIntegrationSettings, saveIntegrationSettings } from './program-integrations';
import './program-launchers.css';

const isHttps = (v: string) => { try { return new URL(v).protocol === 'https:'; } catch { return false; } };
const isExe = (v: string) => /^(?:[a-zA-Z]:\\|\\\\).+\.exe$/i.test(v);

export function ProgramIntegrationSettings() {
  const [luxuryTarget, setLuxury] = useState('');
  const [prescriptionUrl, setPresc] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    try { const s = readIntegrationSettings(); setLuxury(s.luxuryTarget); setPresc(s.prescriptionUrl); }
    catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : '설정을 읽지 못했습니다.' }); }
  }, []);

  function save() {
    const l = luxuryTarget.trim(), p = prescriptionUrl.trim();
    if (l && !isExe(l) && !isHttps(l)) { setMsg({ ok: false, text: '명품 세탁비 산정: .exe 전체 경로 또는 https:// 주소를 입력하세요.' }); return; }
    if (p && !isHttps(p)) { setMsg({ ok: false, text: 'AI 세탁 처방: https:// 주소만 사용할 수 있습니다.' }); return; }
    try {
      saveIntegrationSettings({ luxuryTarget: l, prescriptionUrl: p });
      setLuxury(l || DEFAULT_LUXURY_URL); setPresc(p);
      setMsg({ ok: true, text: '연동 설정을 저장했습니다. 접수 화면에 바로 반영됩니다.' });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error && e.message ? e.message : '저장 실패' }); }
  }

  return (
    <section className="eq-card" id="program-integrations" data-testid="card-program-integrations">
      <h2>외부 프로그램 연동</h2>
      <div className="mtw__stack">
        <label className="eq-field">💎 명품 세탁비 산정 (exe 경로 또는 HTTPS URL)
          <input value={luxuryTarget} placeholder={DEFAULT_LUXURY_URL} spellCheck={false}
            onChange={e => { setLuxury(e.target.value); setMsg(null); }} data-testid="input-luxury-target" />
        </label>
        <p>표준 폴더의 실행 파일을 우선합니다. 실행 파일이 없으면 위 주소를 열며, 주소를 비우면 기본 명품 계산기 웹앱으로 연결합니다.</p>
        <label className="eq-field">🧪 AI 세탁 처방 (HTTPS URL, 비우면 준비 중)
          <input value={prescriptionUrl} placeholder="https://" spellCheck={false}
            onChange={e => { setPresc(e.target.value); setMsg(null); }} data-testid="input-prescription-url" />
        </label>
        <button type="button" className="eq-btn is-primary" onClick={save} data-testid="button-save-integrations">연동 설정 저장</button>
        {msg && <div className={msg.ok ? 'eq-msg' : 'eq-error'} role={msg.ok ? 'status' : 'alert'} data-testid="text-integration-message">{msg.text}</div>}
      </div>
    </section>
  );
}

export default ProgramIntegrationSettings;
