const MARKER='k99.iriun-cache-migration.v2';
const OLD_KEYS=['k99-camera-device-id','k99.cameraDeviceId','k99.camera-device-id',
  'k99-camera-device','k99.selectedCameraId','k99.camera.selectedDeviceId','cameraDeviceId','selectedCameraId'];
/** Remove only obsolete camera selectors. Never clear localStorage, orders,
 * credentials, colour preferences, phone mode or the customer's data. */
export function migrateCameraCache(storage:Pick<Storage,'getItem'|'setItem'|'removeItem'>){
  try{
    if(storage.getItem(MARKER)==='done')return;
    for(const key of OLD_KEYS)storage.removeItem(key);
    storage.setItem(MARKER,'done');
  }catch{/* Storage may be blocked/read-only. Iriun discovery ignores all old IDs. */}
}
