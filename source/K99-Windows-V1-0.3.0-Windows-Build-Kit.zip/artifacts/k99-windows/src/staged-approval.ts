import type { ConfirmedOrder } from './order-record';
import type { InspectionDraft, InspectionRecord, OrderHistoryEvent } from './inspection-record';
import { actualCleaningMethodChanged, careLabelConflict } from './inspection-record.ts';
import { describedRisks, inspectionItemExplanation } from './inspection-message-wording.ts';

export type ApprovalStep = 1 | 2 | 3;
export const STAGED_RESPONSES = {
  1: ['적극적인 얼룩 제거 희망', '케어라벨 기준 세탁 희망', '답변 대기', '기타'],
  2: ['위험 확인 및 변경 세탁 동의', '동의하지 않음', '답변 대기', '기타'],
  3: ['금액 확인 및 진행 동의', '진행하지 않음', '답변 대기', '기타'],
} as const;
export type StagedResponse = (typeof STAGED_RESPONSES)[ApprovalStep][number];
export type StagedStep = {
  message: string;
  readyAt?: string;
  readyBy?: string;
  response?: { choice: StagedResponse; content: string; respondedAt: string; confirmedAt: string; staffName: string };
};
export type StagedApproval = {
  activeStep: ApprovalStep | null;
  outcome: 'in-progress' | 'care-label-requested' | 'method-declined' | 'price-declined' | 'approved';
  itemIndex: number;
  steps: Partial<Record<ApprovalStep, StagedStep>>;
};

const won = (amount: number) => `${amount.toLocaleString('ko-KR')}원`;

function targetIndex(order: ConfirmedOrder, draft: InspectionDraft): number {
  return draft.items.findIndex((item, index) =>
    !order.items[index].isSneaker
    && (item.checks['오염/얼룩 상태'] === '주의' || item.checks['오염/얼룩 상태'] === '문제 있음')
    && careLabelConflict(item));
}

export function validateStagedInspection(order: ConfirmedOrder, draft: InspectionDraft): void {
  const index = targetIndex(order, draft);
  if (index < 0) throw new Error('단계별 확인에는 얼룩 특이사항과 케어라벨에 맞지 않는 대안 세탁방법이 필요합니다.');
  const item = draft.items[index];
  if (!item.methodChangeReason?.trim() || !item.riskDetails?.trim() || !item.riskFactors?.length)
    throw new Error('단계별 확인 전 세탁방법 변경 사유와 구체적 위험 요소·설명을 기록해 주세요.');
  if (!draft.additionalCharge || draft.additionalCharge <= 0
    || draft.revisedPrice !== order.estimatedTotal + draft.additionalCharge)
    throw new Error('단계별 확인에는 직원이 입력한 추가요금과 일치하는 최종 예상금액이 필요합니다.');
  if (draft.waiverRequired && (draft.waiverNotice?.trim().length ?? 0) > 160)
    throw new Error('단계별 위험 동의 문안은 160자 이내로 구체적으로 적어 주세요.');
}

export function generateStagedMessage(order: ConfirmedOrder, inspection: InspectionRecord, step: ApprovalStep): string {
  const index = inspection.stagedApproval?.itemIndex ?? targetIndex(order, inspection);
  if (index < 0) throw new Error('단계별 안내 대상 품목을 찾지 못했습니다.');
  const item = inspection.items[index];
  if (step === 1) return [
    '[K99 품격세탁소]',
    `${order.customerName} 고객님, 맡겨주신 ${order.items[index].displayNameKo}의 전문 검수 결과를 안내드립니다.`,
    ...inspectionItemExplanation({
      name: order.items[index].displayNameKo, item, originalService: inspection.originalMethods[index],
      conflict: careLabelConflict(item), actualMethodChanged: actualCleaningMethodChanged(order, inspection, index),
      riskNotice: inspection.items.length === 1 ? inspection.riskNotice : '',
    }),
    '얼룩 제거를 위해 안내드린 방법으로 진행해 드릴까요?',
    '① 네, 진행해주세요.  ② 아니요, 케어라벨 기준으로 진행해주세요.  ③ 상담 후 결정하겠습니다.',
  ].join('\n');
  if (step === 2) return [
    '[K99 품격세탁소]',
    `얼룩 제거를 위해 케어라벨(${item.careLabelMethod === '기타' ? item.careLabelOther : item.careLabelMethod})과 다른 ${item.actualCleaningMethod}을 권장드립니다.`,
    ...(item.methodChangeReason?.trim()
      ? [`${item.methodChangeReason.trim().replace(/[.!?]$/, '')}.`] : []),
    describedRisks(item).length ? `세심히 작업하겠지만 ${describedRisks(item).join('·')} 가능성을 완전히 배제할 수 없습니다.`
      : /염색약.*제거 불가/.test(item.riskDetails ?? '')
        ? '염색약 얼룩은 완전히 제거하기 어려워 일부 흔적이 남을 수 있습니다.'
        : `${item.riskDetails?.trim().replace(/[.!?]$/, '')}.`,
    ...(inspection.waiverRequired ? [`안내한 위험 범위: ${inspection.waiverNotice}`] : []),
    '이 방법과 안내한 위험을 확인하고 동의하시겠습니까?',
    '① 동의  ② 기존 방법 유지',
  ].join('\n');
  return [
    '[K99 품격세탁소]',
    '감사합니다. 안내드린 작업의 추가비용은 ' + won(inspection.additionalCharge ?? 0) + '이며',
    `기존 ${won(inspection.originalPrice)} → 최종 예상금액 ${won(inspection.revisedPrice)}입니다.`,
    '진행할까요?',
    '① 금액 확인 및 진행  ② 진행하지 않음',
  ].join('\n');
}

export function createStagedApproval(order: ConfirmedOrder, inspection: InspectionRecord): StagedApproval {
  const itemIndex = targetIndex(order, inspection);
  if (itemIndex < 0) throw new Error('단계별 안내 대상 품목을 찾지 못했습니다.');
  const staged: StagedApproval = { activeStep: 1, outcome: 'in-progress', itemIndex, steps: {} };
  const message = generateStagedMessage(order, { ...inspection, stagedApproval: staged }, 1);
  staged.steps[1] = { message };
  return staged;
}

function validateStagedDisclosure(order: ConfirmedOrder, step: ApprovalStep, message: string): void {
  const inspection = order.inspection!;
  const item = inspection.items[inspection.stagedApproval!.itemIndex];
  if (step === 1 && !['얼룩', '케어라벨', '제거'].every((word) => message.includes(word)))
    throw new Error('1단계 안내에는 얼룩, 케어라벨 기준 세탁과 적극적인 제거 선택이 포함되어야 합니다.');
  if (step === 2) {
    const label = item.careLabelMethod === '기타' ? item.careLabelOther : item.careLabelMethod;
    if (!label || !message.includes(label) || !message.includes(item.actualCleaningMethod!)
      || !describedRisks(item).every((risk) => message.includes(risk))
      || (inspection.waiverRequired && !message.includes(inspection.waiverNotice ?? '')))
      throw new Error('2단계 안내에는 케어라벨, 제안한 세탁방법, 확인된 위험 및 면책 범위가 포함되어야 합니다.');
  }
  if (step === 3 && ![inspection.originalPrice, inspection.additionalCharge, inspection.revisedPrice]
    .every((amount) => amount !== undefined && message.includes(won(amount))))
    throw new Error('3단계 안내에는 원래 금액, 직원 입력 추가요금 및 최종 예상금액이 포함되어야 합니다.');
}

function active(order: ConfirmedOrder, step: ApprovalStep) {
  const staged = order.inspection?.stagedApproval;
  if (!staged || staged.activeStep !== step || staged.outcome !== 'in-progress'
    || order.status !== '고객 회신 대기' || !staged.steps[step])
    throw new Error('이전 단계의 고객 답변 확인 전에는 다음 단계를 열 수 없습니다.');
  return staged;
}

export function updateStagedMessage(order: ConfirmedOrder, step: ApprovalStep,
  message: string, action: 'edit' | 'regenerate' | 'ready', staffName: string, at = new Date()): ConfirmedOrder {
  const staged = active(order, step);
  if (!staffName.trim()) throw new Error('메시지 확인 직원을 입력해 주세요.');
  const updatedMessage = action === 'regenerate'
    ? generateStagedMessage(order, order.inspection!, step) : message.trim();
  if (!updatedMessage) throw new Error('고객 안내 메시지를 입력해 주세요.');
  validateStagedDisclosure(order, step, updatedMessage);
  const timestamp = at.toISOString();
  const current = staged.steps[step]!;
  const updated: StagedStep = { ...current, message: updatedMessage,
    ...(action === 'ready' ? { readyAt: timestamp, readyBy: staffName.trim() }
      : { readyAt: undefined, readyBy: undefined }) };
  return { ...order, inspection: { ...order.inspection!,
    stagedApproval: { ...staged, steps: { ...staged.steps, [step]: updated } } },
  history: [...(order.history ?? []), { at: timestamp,
    kind: action === 'ready' ? 'staged-message-prepared' : 'staff-message-review',
    details: { step, action, message: updatedMessage, staffName: staffName.trim(), actuallySent: false } }] };
}

export function recordStagedResponse(order: ConfirmedOrder, step: ApprovalStep, choice: StagedResponse,
  content: string, staffName: string, respondedAt?: string, at = new Date()): ConfirmedOrder {
  const staged = active(order, step);
  const current = staged.steps[step]!;
  if (!current.readyAt) throw new Error('직원이 메시지를 검토하고 발송 준비를 기록한 뒤 답변을 확인해 주세요.');
  if (!staffName.trim()) throw new Error('고객 회신 확인 직원을 입력해 주세요.');
  if (!(STAGED_RESPONSES[step] as readonly string[]).includes(choice))
    throw new Error('현재 단계에 맞는 고객 답변을 선택해 주세요.');
  if (respondedAt && !Number.isFinite(Date.parse(respondedAt)))
    throw new Error('고객 회신 일시를 확인해 주세요.');
  const confirmedAt = at.toISOString();
  const response = { choice, content: content.trim(), staffName: staffName.trim(),
    respondedAt: respondedAt ? new Date(respondedAt).toISOString() : confirmedAt, confirmedAt };
  const steps: StagedApproval['steps'] = { ...staged.steps, [step]: { ...current, response } };
  let activeStep: ApprovalStep | null = step;
  let outcome: StagedApproval['outcome'] = 'in-progress';
  let status: ConfirmedOrder['status'] = '고객 회신 대기';
  if (step === 1 && choice === '적극적인 얼룩 제거 희망') activeStep = 2;
  if (step === 1 && choice === '케어라벨 기준 세탁 희망') {
    activeStep = null; outcome = 'care-label-requested'; status = '보류';
  }
  if (step === 2 && choice === '위험 확인 및 변경 세탁 동의') activeStep = 3;
  if (step === 2 && choice === '동의하지 않음') {
    activeStep = null; outcome = 'method-declined'; status = '보류';
  }
  if (step === 3 && choice === '금액 확인 및 진행 동의') {
    activeStep = null; outcome = 'approved'; status = '세탁 진행 승인';
  }
  if (step === 3 && choice === '진행하지 않음') {
    activeStep = null; outcome = 'price-declined'; status = '보류';
  }
  const history: OrderHistoryEvent[] = [...(order.history ?? []),
    { at: confirmedAt, kind: 'staged-customer-response', details: {
      step, choice, content: response.content, respondedAt: response.respondedAt,
      confirmedAt, staffName: response.staffName } }];
  if (activeStep !== step && activeStep !== null) {
    const nextMessage = generateStagedMessage(order, order.inspection!, activeStep);
    steps[activeStep] = { message: nextMessage };
    history.push({ at: confirmedAt, kind: 'staged-message-draft',
      details: { step: activeStep, message: nextMessage, actuallySent: false } });
  }
  if (outcome === 'care-label-requested')
    history.push({ at: confirmedAt, kind: 'staged-care-label-request',
      details: { note: '고객 요청에 따라 케어라벨 기준 세탁 진행', staffName: response.staffName,
        requiresStaffReview: true, proposedMethodNotApproved: true } });
  if (outcome === 'approved') {
    history.push({ at: confirmedAt, kind: 'customer-consent', details: {
      method: '위험 확인 및 변경 세탁 동의', price: '금액 확인 및 진행 동의',
      stainRemoval: '적극적인 얼룩 제거 희망', risks: order.inspection!.items[staged.itemIndex].riskFactors,
      waiver: order.inspection!.waiverRequired ? order.inspection!.waiverNotice : undefined,
      originalPrice: order.inspection!.originalPrice, additionalCharge: order.inspection!.additionalCharge,
      revisedPrice: order.inspection!.revisedPrice, staffName: response.staffName, respondedAt: response.respondedAt } });
  }
  if (outcome !== 'in-progress') history.push({ at: confirmedAt, kind: 'approval-status',
    details: { status, outcome, staffName: response.staffName, confirmedAt,
      cleaningAllowed: outcome === 'approved' } });
  return { ...order, status, inspection: { ...order.inspection!,
    stagedApproval: { ...staged, activeStep, outcome, steps } }, history };
}