import {useEffect,useRef,useState} from 'react';
import {neutralCameraColor,makeColorTransform,type CameraColorProfile} from './camera-color';
export function useCameraColorPreview(video:React.RefObject<HTMLVideoElement|null>,enabled:boolean,profile:CameraColorProfile){
  const canvas=useRef<HTMLCanvasElement|null>(null);
  const effective=useRef(profile);
  const [error,setError]=useState('');
  const [ready,setReady]=useState(false);
  useEffect(()=>{
    setError('');
    effective.current=profile;setReady(false);
    if(!enabled||neutralCameraColor(profile))return;
    const transform=makeColorTransform(profile);
    let frame=0,last=0;
    const draw=(time:number)=>{
      frame=requestAnimationFrame(draw);
      const v=video.current,c=canvas.current;
      if(!v||!c||!v.videoWidth||v.readyState<2||time-last<100)return;
      last=time;
      // Keep native FHD/2K detail, including enlarged fabric/stain previews.
      // Work is throttled to 10 fps and bypassed entirely at neutral settings.
      const width=v.videoWidth,height=v.videoHeight;
      if(c.width!==width||c.height!==height){c.width=width;c.height=height;}
      try{
        const context=c.getContext('2d',{willReadFrequently:true});if(!context)throw Error('카메라 미리보기 캔버스 생성 실패');
        context.drawImage(v,0,0,width,height);
        const image=context.getImageData(0,0,width,height);
        transform(image);context.putImageData(image,0,0);
        // Capture adopts new coefficients only after that preview was drawn.
        effective.current=profile;setError('');setReady(true);
      }catch{setReady(false);setError('색감 미리보기를 처리하지 못해 기본 카메라 영상을 표시합니다.');}
    };
    frame=requestAnimationFrame(draw);
    return()=>cancelAnimationFrame(frame);
  },[video,enabled,profile]);
  return {canvas,effective,error,ready};
}
