import {useEffect,useRef,useState} from 'react';
import {automaticWhiteProfile,makeColorTransform,type CameraColorProfile} from './camera-color';
export function useCameraColorPreview(video:React.RefObject<HTMLVideoElement|null>,enabled:boolean,profile:CameraColorProfile){
  const canvas=useRef<HTMLCanvasElement|null>(null);
  const effective=useRef(profile);
  const [error,setError]=useState('');
  const [ready,setReady]=useState(false);
  useEffect(()=>{
    setError('');
    if(!enabled){effective.current=profile;setReady(false);return;}
    let processing=profile;
    let transform=makeColorTransform(profile);
    let frame=0,last=0,lastWhite=-1000,first=true;
    const draw=(time:number)=>{
      frame=requestAnimationFrame(draw);
      const v=video.current,c=canvas.current;
      if(!v||!c||!v.videoWidth||v.readyState<2||time-last<100)return;
      last=time;
      // Bound CPU work on older shop PCs; full-resolution correction is saved at capture.
      const width=Math.min(960,v.videoWidth),height=Math.round(width*v.videoHeight/v.videoWidth);
      if(c.width!==width||c.height!==height){c.width=width;c.height=height;}
      try{
        const context=c.getContext('2d',{willReadFrequently:true});if(!context)throw Error('카메라 미리보기 캔버스 생성 실패');
        context.drawImage(v,0,0,width,height);
        const image=context.getImageData(0,0,width,height);
        if(time-lastWhite>=1000){
          lastWhite=time;
          try{
            processing=automaticWhiteProfile(image,processing,profile,first);
            first=false;transform=makeColorTransform(processing);
          }catch{/* No trustworthy white border: keep the last good software coefficients. */}
        }
        transform(image.data);context.putImageData(image,0,0);
        // Capture adopts new coefficients only after that preview was drawn.
        effective.current=processing;setError('');setReady(true);
      }catch{setReady(false);setError('색감 미리보기를 처리하지 못해 기본 카메라 영상을 표시합니다.');}
    };
    frame=requestAnimationFrame(draw);
    return()=>cancelAnimationFrame(frame);
  },[video,enabled,profile]);
  return {canvas,effective,error,ready};
}
