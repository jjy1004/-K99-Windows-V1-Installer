import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import {Smartphone} from 'lucide-react';
import { buildSmsUri } from './accountless-message';
import { messenger, noticeApi, type NoticePrepared, type NoticeContext } from './notice-api';
import { SmsComposeContents } from './SmsComposeContents';
import { NoticeDeliveryBadge } from './NoticeDeliveryBadge';
import { useNoticeDelivery } from './notice-delivery-state';
import { savedLocalNotice, prepareLocalDelivery, confirmLocalDelivery } from './local-notice-preparation';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import { searchSavedOrders } from './SavedOrderLookup';
import './local-notice-dialogs.css';

const FOCUSABLE = 'button:not([disabled]),[href],input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])';

export function NoticeDialog({ title, onClose, children, className = '' }: {
  title: string; onClose: () => void; children: ReactNode; className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>(FOCUSABLE)?.focus();
    return () => { if(prev?.isConnected)prev.focus({preventScroll:true}); };
  }, []);
  const onKeyDown = (e: React.KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) { e.preventDefault(); closeRef.current(); return; }
    if (e.key !== 'Tab' || !ref.current) return;
    const els = [...ref.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(el=>el.getClientRects().length>0);
    if (!els.length) { e.preventDefault(); return; }
    const first = els[0], last = els[els.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  return createPortal(
    <div className="lnd-backdrop" data-notice-modal="true" onKeyDown={onKeyDown} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} className={`lnd-modal ${className}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="lnd-head">
          <h2>{title}</h2>
          <button type="button" className="lnd-close" onClick={onClose}>✕ 닫기</button>
        </div>
        <div className="lnd-body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

type Snap = {
  recipient: string; body: string; notice: NoticePrepared | null; customerName?: string;
  attemptId?: string; copied: boolean; confirmed: boolean; status?: string;
};
type KakaoState = { kind: 'ok' | 'warn' | 'err'; text: string };

export function AccountlessNoticeActions({ recipient, body, onPrepare, disabled,launchLabel,
  orderId, templateId = 'inspection-consent', customerName }: {
  recipient: string; body: string; onPrepare?: () => Promise<boolean | NoticePrepared>; disabled?: boolean;launchLabel?:string;
  orderId?: string; templateId?: string; customerName?: string;
}) {
  const [choosing,setChoosing]=useState(false);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [sms, setSms] = useState<Snap | null>(null);
  const [kakao, setKakao] = useState<(Snap & KakaoState) | null>(null);
  const [prepError, setPrepError] = useState('');
  const [kakaoAnnouncement,setKakaoAnnouncement]=useState<KakaoState|null>(null);
  const [popupError, setPopupError] = useState('');
  const delivery = useNoticeDelivery(orderId, [templateId]);

  const run = async (kind: 'sms' | 'kakao', prior?: Snap) => {
    if (busyRef.current) return;
    busyRef.current = true; setBusy(true); setPrepError('');
    try {
      const fullBody = prior?.body ?? body, phone = prior?.recipient ?? recipient;
      if (!fullBody.trim()) { setPrepError('보낼 문구가 비어 있습니다.'); return false; }
      let copied = false;
      if(kind==='kakao'){
        setKakaoAnnouncement(null);
        try{await navigator.clipboard.writeText(fullBody);copied=true;}catch{/* Native clipboard is tried below. */}
      }
      if (kind === 'sms') buildSmsUri(phone, fullBody);
      const prepared = !prior && onPrepare ? await onPrepare() : undefined;
      if (prepared === false) { setPrepError('문구 저장·준비가 끝나지 않아 진행하지 않았습니다.'); return false; }
      const notice = prior?.notice ?? await savedLocalNotice(orderId, fullBody, templateId, prepared);
      const context = orderId ? await noticeApi<{context: NoticeContext}>('GET', `/context?orderId=${encodeURIComponent(orderId)}`) : null;
      const snap: Snap = {recipient: phone, body: fullBody, notice, copied: false, confirmed: false,
        customerName:prior?.customerName || context?.context.customerName || customerName};
      setPopupError('');
      if (kind === 'sms') {
        setSms(snap); return true;
      }
      const r = await messenger({ action: 'kakao-compose', body: snap.body, recipient: snap.recipient, customerName:snap.customerName });
      copied=copied||r.copied===true;
      const state:KakaoState={kind:r.success&&r.searchPrepared?'ok':copied||r.manualRequired?'warn':'err',
        text:r.detail||r.error||'카카오톡에서 고객을 직접 검색하고, 복사된 안내문을 붙여넣어 주세요.'};
      setKakaoAnnouncement(state);
      if (copied) snap.attemptId = await prepareLocalDelivery(notice, phone, 'kakao-clipboard', fullBody);
      setKakao({...snap,...state});
      return true;
    } catch (e) {
      setPrepError(e instanceof Error ? e.message : '준비 중 오류가 발생했습니다.');
      return false;
    } finally { busyRef.current = false; setBusy(false); }
  };

  const popupAction = async (action: () => Promise<void>) => {
    if (busyRef.current) return;
    busyRef.current = true; setBusy(true); setPopupError('');
    try { await action(); }
    catch (error) { setPopupError(error instanceof Error ? error.message : '기록을 저장하지 못했습니다.'); }
    finally { busyRef.current = false; setBusy(false); }
  };
  const inputSms = () => void popupAction(async () => {
    if (!sms) return;
    buildSmsUri(sms.recipient, sms.body);
    const notice = await savedLocalNotice(orderId, sms.body, templateId);
    const result = await messenger({action:'sms-compose',recipient:sms.recipient,body:sms.body});
    setSms(current => current ? {...current,notice,copied:result.copied===true,
      attemptId:undefined,confirmed:false,status:result.detail||result.error} : null);
    if (result.copied !== true) throw Error(result.error || result.detail || '전체 문구 복사를 확인하지 못했습니다.');
    // Reuse the existing full-body clipboard channel. No schema/channel
    // migration, and historical summary-only QR deliveries remain unchanged.
    const attemptId = await prepareLocalDelivery(notice, sms.recipient, 'full-clipboard', sms.body);
    setSms(current => current ? {...current, attemptId} : null);
  });
  const confirmSms = () => void popupAction(async () => {
    if (!sms) return;
    await confirmLocalDelivery(sms.attemptId);
    setSms(current => current ? {...current, confirmed: true} : null);
  });

  return (
    <>
      {kakaoAnnouncement&&createPortal(<aside className={`lnd-kakao-top ${kakaoAnnouncement.kind}`} role="status" aria-live="polite">
        <span>{kakaoAnnouncement.text}</span><button type="button" onClick={()=>setKakaoAnnouncement(null)} aria-label="카카오톡 준비 안내 닫기">✕ 닫기</button>
      </aside>,document.body)}
      {launchLabel&&<button type="button" className="lnd-btn gold lnd-send-launcher"
        data-message-state={delivery.kind}
        disabled={disabled||busy} aria-expanded={choosing} data-testid="button-message-send-launcher"
        onClick={()=>setChoosing(value=>!value)}><Smartphone aria-hidden="true"/>{launchLabel}</button>}
      <NoticeDeliveryBadge orderId={orderId} templateIds={[templateId]}/>
      {(!launchLabel||choosing)&&<div className="lnd-actions" data-message-state={delivery.kind}>
        <button type="button" className="lnd-btn" disabled={disabled || busy} onClick={() => run('kakao')}>💬 PC 카카오톡 발송 준비</button>
        <button type="button" className="lnd-btn gold" disabled={disabled || busy} onClick={() => run('sms')}>휴대폰으로 문자 보내기</button>
      </div>}
      {launchLabel&&choosing&&<p className="nc-hint">보낼 방법을 골라 주세요. 문자 앱이나 카카오톡에서 내용을 확인하고 최종 전송을 눌러 주세요.</p>}
      {busy && <p className="lnd-msg info" role="status">준비 중입니다…</p>}
      {prepError && <p className="lnd-msg err" role="alert">{prepError}</p>}

      {sms && (
        <NoticeDialog title="📱 휴대폰으로 문자 보내기" className="lnd-sms-modal" onClose={() => setSms(null)}>
          <SmsComposeContents recipient={sms.recipient} body={sms.body}
            onChange={value => {setSms({...sms,body:value,copied:false,confirmed:false,attemptId:undefined,status:undefined});setPopupError('');}}
            onInput={inputSms} copied={sms.copied} onConfirm={confirmSms} canConfirm={!!sms.attemptId}
            confirmed={sms.confirmed} busy={busy} error={popupError} status={sms.status}/>
        </NoticeDialog>
      )}

      {kakao && (
        <NoticeDialog title="💬 PC 카카오톡 발송 준비" onClose={() => setKakao(null)}>
          <p className={`lnd-msg ${kakao.kind}`} role="status">{kakao.kind === 'ok' ? '✔ ' : '⚠ '}{kakao.text}</p>
          <p className="lnd-msg info">아직 발송된 것이 아닙니다. 카카오톡에서 직접 [전송]을 눌러야 고객에게 전달됩니다.</p>
          <p className="lnd-msg info">카카오톡 친구 목록에 고객이 없으면 아래 [휴대폰으로 문자 보내기]를 이용하세요. 문자 앱에서 번호·본문을 확인하고 직접 전송해 주세요.</p>
          <button type="button" className="lnd-btn gold" disabled={busy} onClick={async()=>{
            if(await run('sms',kakao))setKakao(null);
          }}>휴대폰으로 문자 보내기</button>
          <button type="button" className="lnd-btn" disabled={busy || !kakao.attemptId || kakao.confirmed}
            onClick={()=>void popupAction(async()=>{
              await confirmLocalDelivery(kakao.attemptId);
              setKakao(current=>current?{...current,confirmed:true}:null);
            })}>{kakao.confirmed?'✅ 메시지 발송 확인 저장됨':'카카오톡에서 발송 완료 확인'}</button>
          {popupError&&<p role="alert" className="lnd-msg err">{popupError}</p>}
          <div className="lnd-field" style={{ marginTop: 18 }}><b>고객 번호</b><span className="lnd-phone">{kakao.recipient || '번호 없음'}</span></div>
          <div className="lnd-field"><b>완성 문구</b><pre className="lnd-text">{kakao.body}</pre></div>
        </NoticeDialog>
      )}
    </>
  );
}

const won = (v: number) => `${(v || 0).toLocaleString('ko-KR')}원`;
const day = (iso: string) => { const d = new Date(iso); return isNaN(+d) ? '-' : `${d.getMonth() + 1}월 ${d.getDate()}일`; };

export function PickupOrderPicker({ onClose, onSelect }: { onClose: () => void; onSelect: (orderId: string) => void }) {
  const [q, setQ] = useState('');
  const loaded = useMemo<{ orders: ConfirmedOrder[]; error: string }>(() => {
    try { return { orders: [...readConfirmedOrders()].sort((a, b) => b.intakeAt.localeCompare(a.intakeAt)), error: '' }; }
    catch (e) { return { orders: [], error: e instanceof Error ? e.message : '주문 기록을 읽지 못했습니다.' }; }
  }, []);
  const shown = useMemo(() => q.trim() ? searchSavedOrders(loaded.orders, q) : loaded.orders.slice(0, 50), [q, loaded]);

  return (
    <NoticeDialog title="안내 보낼 주문 고르기" onClose={onClose}>
      <label style={{ display: 'block', fontWeight: 800, marginBottom: 8 }} htmlFor="lnd-search">고객 이름 또는 전화 뒷자리 4개</label>
      <input id="lnd-search" className="lnd-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="예: 김순자 / 1234" autoComplete="off" />
      {loaded.error && <p className="lnd-msg err" role="alert">주문 기록을 불러오지 못했습니다. {loaded.error}</p>}
      {!loaded.error && !loaded.orders.length && <p className="lnd-msg info">아직 저장된 주문이 없습니다. 접수를 먼저 완료해 주세요.</p>}
      {!!loaded.orders.length && !shown.length && <p className="lnd-msg warn">찾는 주문이 없습니다. 이름이나 번호 4자리를 다시 확인해 주세요.</p>}
      <ul className="lnd-list">
        {shown.map((o) => (
          <li key={o.id}>
            <button type="button" className="lnd-order" onClick={() => onSelect(o.id)}>
              <strong>{o.customerName} ({o.customerPhone.replace(/\D/g, '').slice(-4)})</strong>
              <span className="amt">{won(o.estimatedTotal)}</span>
              <span>{day(o.intakeAt)} 접수 · {o.items.map((i) => `${i.displayNameKo} ${i.quantity}`).join(', ')}</span>
              <span>총 {o.totalQuantity}점</span>
            </button>
          </li>
        ))}
      </ul>
    </NoticeDialog>
  );
}
