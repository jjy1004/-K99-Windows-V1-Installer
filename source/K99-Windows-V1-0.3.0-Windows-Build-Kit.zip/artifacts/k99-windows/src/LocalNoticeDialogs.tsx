import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import {Smartphone} from 'lucide-react';
import { buildSmsUri } from './accountless-message';
import { messenger, noticeApi, type NoticePrepared, type NoticeContext } from './notice-api';
import { NoticeDeliveryBadge } from './NoticeDeliveryBadge';
import { useNoticeDelivery } from './notice-delivery-state';
import {useSmsMode,KDE_SMS_WARNING} from './SmsModeSettings';
import { savedLocalNotice, prepareLocalDelivery, confirmLocalDelivery } from './local-notice-preparation';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import { searchSavedOrders } from './SavedOrderLookup';
import './local-notice-dialogs.css';
import { NumUnit } from './NumUnit';

const FOCUSABLE = 'button:not([disabled]),[href],input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])';

export function NoticeDialog({ title, onClose, children, className = '' }: {
  title: string; onClose: () => void; children: ReactNode; className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>(FOCUSABLE)?.focus();
    return () => { if(prev?.isConnected)prev.focus({preventScroll:true}); };
  }, []);
  const onKeyDown = (e: React.KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) { e.preventDefault(); closeRef.current(); return; }
    if (e.key !== 'Tab' || !ref.current) return;
    const els = [...ref.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(el=>el.getClientRects().length>0);
    if (!els.length) { e.preventDefault(); return; }
    const first = els[0], last = els[els.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  return createPortal(
    <div className="lnd-backdrop" data-notice-modal="true" onKeyDown={onKeyDown} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} className={`lnd-modal ${className}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="lnd-head">
          <h2>{title}</h2>
          <button type="button" className="lnd-close" onClick={onClose}>✕ 닫기</button>
        </div>
        <div className="lnd-body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

export function AccountlessNoticeActions({ recipient, body, onPrepare, onCompleted, disabled,launchLabel,
  orderId, templateId = 'inspection-consent', customerName,resolveBody }: {
  recipient: string; body: string; onPrepare?: () => Promise<boolean | NoticePrepared>; disabled?: boolean;launchLabel?:string;
  onCompleted?: () => void | Promise<void>;
  orderId?: string; templateId?: string; customerName?: string;
  resolveBody?:()=>string;
}) {
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [prepError, setPrepError] = useState('');
  const [status,setStatus]=useState('');
  const delivery = useNoticeDelivery(orderId, [templateId]);
  const smsMode=useSmsMode();
  async function share(source:'order'|'file'){
    if(busyRef.current||smsMode.mode!=='KDE')return;
    busyRef.current=true;setBusy(true);setPrepError('');setStatus('');
    try{
      const result=await messenger({action:'kde-share',source,orderId,expectedSmsMode:'KDE'});
      if(!result.success)throw Error(result.error||result.detail||'사진 전송을 요청하지 못했습니다.');
      setStatus(result.detail||'사진 전송을 요청했습니다.');
    }catch(error){setPrepError(error instanceof Error?error.message:'사진 전송을 요청하지 못했습니다.');}
    finally{busyRef.current=false;setBusy(false);}
  }

  const run = async (kind: 'sms' | 'kakao') => {
    if (busyRef.current) return;
    busyRef.current = true; setBusy(true); setPrepError('');
    try {
      const fullBody = resolveBody?resolveBody():body, phone = recipient;
      if(kind==='sms'&&!smsMode.mode)throw Error(smsMode.error||'문자 발송 방식을 확인 중입니다.');
      if (!fullBody.trim()) { setPrepError('보낼 문구가 비어 있습니다.'); return false; }
      setStatus('');
      if (kind === 'sms') buildSmsUri(phone, fullBody);
      const prepared = onPrepare ? await onPrepare() : undefined;
      if (prepared === false) { setPrepError('문구 저장·준비가 끝나지 않아 진행하지 않았습니다.'); return false; }
      const notice = await savedLocalNotice(orderId, fullBody, templateId, prepared);
      const context = orderId ? await noticeApi<{context: NoticeContext}>('GET', `/context?orderId=${encodeURIComponent(orderId)}`) : null;
      const attemptId=await prepareLocalDelivery(notice,phone,kind==='sms'?'full-clipboard':'kakao-clipboard',fullBody);
      // Start native copying/activation and the durable click record together.
      // A window-discovery timeout must not delay the requested badge update.
      const native=messenger({action:kind==='sms'?'sms-compose':'kakao-compose',
        body:fullBody,recipient:phone,customerName:context?.context.customerName||customerName,
        ...(kind==='sms'&&smsMode.mode?{expectedSmsMode:smsMode.mode}:{})})
        .catch((error:unknown)=>({success:false,copied:false,error:error instanceof Error?error.message:'외부 앱을 열지 못했습니다.',detail:''}));
      if(attemptId)await confirmLocalDelivery(attemptId,'button-click');
      if(onCompleted)await onCompleted();
      const result=await native;
      if(result.copied!==true)throw Error(result.error||result.detail||'전체 문구를 복사하지 못했습니다. 외부 앱에서 직접 확인해 주세요.');
      if(!result.success)throw Error(result.error||result.detail||'메시지 앱 요청을 완료하지 못했습니다.');
      setStatus(`${attemptId?`${kind==='sms'?'문자':'카카오톡'} 발송 완료로 기록했습니다. `:''}${result.detail||'외부 앱에서 실제 전송을 완료해 주세요.'}`);
      return true;
    } catch (e) {
      setPrepError(e instanceof Error ? e.message : '준비 중 오류가 발생했습니다.');
      return false;
    } finally { busyRef.current = false; setBusy(false); }
  };

  return (
    <>
      <NoticeDeliveryBadge orderId={orderId} templateIds={[templateId]}/>
      <div className="lnd-actions" data-message-state={delivery.kind} aria-label={launchLabel}>
        <button type="button" className="lnd-btn" disabled={disabled || busy} onClick={() => run('kakao')}>💬 카카오톡으로 보내기</button>
        <div>
          <button type="button" className="lnd-btn gold" disabled={disabled || busy || !smsMode.mode} onClick={() => run('sms')}><Smartphone aria-hidden="true"/>휴대폰으로 문자 보내기</button>
          {smsMode.mode==='KDE'&&<p className="lnd-msg warn" role="note">{KDE_SMS_WARNING}</p>}
          {smsMode.mode==='KDE'&&<div className="lnd-actions">
            <button type="button" className="lnd-btn" disabled={disabled||busy||!orderId} onClick={()=>void share('order')}>접수 사진 보내기</button>
            <button type="button" className="lnd-btn" disabled={disabled||busy} onClick={()=>void share('file')}>사진 파일 선택</button>
          </div>}
          {smsMode.error&&<p className="lnd-msg err" role="alert">{smsMode.error}</p>}
        </div>
      </div>
      {busy && <p className="lnd-msg info" role="status">준비 중입니다…</p>}
      {prepError && <p className="lnd-msg err" role="alert">{prepError}</p>}

      {status&&<p className="lnd-msg info" role="status">{status}</p>}
    </>
  );
}

const won = (v: number) => `${(v || 0).toLocaleString('ko-KR')}원`;
const day = (iso: string) => { const d = new Date(iso); return isNaN(+d) ? '-' : `${d.getMonth() + 1}월 ${d.getDate()}일`; };

export function PickupOrderPicker({ onClose, onSelect }: { onClose: () => void; onSelect: (orderId: string) => void }) {
  const [q, setQ] = useState('');
  const loaded = useMemo<{ orders: ConfirmedOrder[]; error: string }>(() => {
    try { return { orders: [...readConfirmedOrders()].sort((a, b) => b.intakeAt.localeCompare(a.intakeAt)), error: '' }; }
    catch (e) { return { orders: [], error: e instanceof Error ? e.message : '주문 기록을 읽지 못했습니다.' }; }
  }, []);
  const shown = useMemo(() => q.trim() ? searchSavedOrders(loaded.orders, q) : loaded.orders.slice(0, 50), [q, loaded]);

  return (
    <NoticeDialog title="안내 보낼 주문 고르기" onClose={onClose}>
      <label style={{ display: 'block', fontWeight: 800, marginBottom: 8 }} htmlFor="lnd-search">고객 이름 또는 전화 뒷자리 4개</label>
      <input id="lnd-search" className="lnd-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="예: 김순자 / 1234" autoComplete="off" />
      {loaded.error && <p className="lnd-msg err" role="alert">주문 기록을 불러오지 못했습니다. {loaded.error}</p>}
      {!loaded.error && !loaded.orders.length && <p className="lnd-msg info">아직 저장된 주문이 없습니다. 접수를 먼저 완료해 주세요.</p>}
      {!!loaded.orders.length && !shown.length && <p className="lnd-msg warn">찾는 주문이 없습니다. 이름이나 번호 4자리를 다시 확인해 주세요.</p>}
      <ul className="lnd-list">
        {shown.map((o) => (
          <li key={o.id}>
            <button type="button" className="lnd-order" onClick={() => onSelect(o.id)}>
              <strong>{o.customerName} ({o.customerPhone.replace(/\D/g, '').slice(-4)})</strong>
              <span className="amt">{won(o.estimatedTotal)}</span>
              <span>{day(o.intakeAt)} 접수 · {o.items.map((i) => `${i.displayNameKo} ${i.quantity}`).join(', ')}</span>
              <span>총 <NumUnit>{o.totalQuantity}점</NumUnit></span>
            </button>
          </li>
        ))}
      </ul>
    </NoticeDialog>
  );
}
