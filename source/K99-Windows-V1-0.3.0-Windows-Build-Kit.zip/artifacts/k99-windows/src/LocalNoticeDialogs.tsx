import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import bwipjs from 'bwip-js/browser';
import { buildSmsUri } from './accountless-message';
import { messenger } from './notice-api';
import { readConfirmedOrders, type ConfirmedOrder } from './order-record';
import { searchSavedOrders } from './SavedOrderLookup';
import './local-notice-dialogs.css';

const FOCUSABLE = 'button:not([disabled]),[href],input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])';

export function NoticeDialog({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>(FOCUSABLE)?.focus();
    return () => { if(prev?.isConnected)prev.focus({preventScroll:true}); };
  }, []);
  const onKeyDown = (e: React.KeyboardEvent) => {
    e.stopPropagation();
    if (e.key === 'Escape' && !e.nativeEvent.isComposing) { e.preventDefault(); closeRef.current(); return; }
    if (e.key !== 'Tab' || !ref.current) return;
    const els = [...ref.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(el=>el.getClientRects().length>0);
    if (!els.length) { e.preventDefault(); return; }
    const first = els[0], last = els[els.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  return createPortal(
    <div className="lnd-backdrop" data-notice-modal="true" onKeyDown={onKeyDown} onKeyUp={(e) => e.stopPropagation()}>
      <div ref={ref} className="lnd-modal" role="dialog" aria-modal="true" aria-label={title}>
        <div className="lnd-head">
          <h2>{title}</h2>
          <button type="button" className="lnd-close" onClick={onClose}>✕ 닫기</button>
        </div>
        <div className="lnd-body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

function QrCanvas({ text, onError }: { text: string; onError: (m: string) => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const errRef = useRef(onError);
  errRef.current = onError;
  useEffect(() => {
    if (!ref.current) return;
    // eclevel은 BWIPP QR 옵션이다. 공급자 RenderOptions 타입은 심볼별 옵션을 열거하지 않는다.
    const options={bcid:'qrcode',text,scale:5,padding:4,eclevel:'L',backgroundcolor:'FFFFFF'};
    try { bwipjs.toCanvas(ref.current, options); }
    catch (e) { errRef.current(e instanceof Error ? e.message : String(e)); }
  }, [text]);
  return <canvas ref={ref} role="img" aria-label="문자 발송 QR 코드" />;
}

type Snap = { recipient: string; body: string };
type KakaoState = { kind: 'ok' | 'warn' | 'err'; text: string };

export function AccountlessNoticeActions({ recipient, body, onPrepare, disabled }: {
  recipient: string; body: string; onPrepare?: () => Promise<boolean>; disabled?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [sms, setSms] = useState<Snap | null>(null);
  const [qrError, setQrError] = useState('');
  const [kakao, setKakao] = useState<(Snap & KakaoState) | null>(null);
  const [prepError, setPrepError] = useState('');

  const run = async (kind: 'sms' | 'kakao') => {
    if (busyRef.current) return;
    const snap = { recipient, body };
    busyRef.current = true; setBusy(true); setPrepError('');
    try {
      if (!snap.body.trim()) { setPrepError('보낼 문구가 비어 있습니다.'); return; }
      if (kind === 'sms') buildSmsUri(snap.recipient,snap.body);
      if (onPrepare && !(await onPrepare())) { setPrepError('문구 저장·준비가 끝나지 않아 진행하지 않았습니다.'); return; }
      if (kind === 'sms') { setQrError(''); setSms(snap); return; }
      const r = await messenger({ action: 'kakao-compose', body: snap.body });
      setKakao(r.success
        ? { ...snap, kind: r.channel==='kakao-download'?'warn':'ok', text: r.detail||'문구가 복사되었습니다. 카카오톡에서 고객 이름(전화번호) 검색 후 붙여넣기(Ctrl+V) 하세요.' }
        : { ...snap, kind: r.manualRequired ? 'warn' : 'err', text: r.error || r.detail || '카카오톡 실행 또는 문구 복사에 실패했습니다.' });
    } catch (e) {
      setPrepError(e instanceof Error ? e.message : '준비 중 오류가 발생했습니다.');
    } finally { busyRef.current = false; setBusy(false); }
  };

  const smsUri = useMemo(() => {
    if (!sms) return '';
    return buildSmsUri(sms.recipient, sms.body);
  }, [sms]);

  return (
    <>
      <div className="lnd-actions">
        <button type="button" className="lnd-btn" disabled={disabled || busy} onClick={() => run('kakao')}>💬 PC 카카오톡 발송</button>
        <button type="button" className="lnd-btn gold" disabled={disabled || busy} onClick={() => run('sms')}>📱 휴대폰 문자 QR 발송</button>
      </div>
      {busy && <p className="lnd-msg info" role="status">준비 중입니다…</p>}
      {prepError && <p className="lnd-msg err" role="alert">{prepError}</p>}

      {sms && (
        <NoticeDialog title="📱 휴대폰으로 문자 보내기" onClose={() => setSms(null)}>
          <div className="lnd-qr-wrap">
            <div className="lnd-qr">
              {smsUri && !qrError ? <QrCanvas text={smsUri} onError={setQrError} /> : <div style={{ width: 240, color: '#3d1f1b' }}>QR 없음</div>}
            </div>
            <div>
              <div className="lnd-field"><b>받는 번호</b><span className="lnd-phone">{sms.recipient}</span></div>
              <p className="lnd-msg info">스마트폰 카메라로 QR을 비추면 문자 앱이 열립니다. 내용을 확인한 뒤 <b>스마트폰에서 직접 [전송]</b>을 누르세요. 이 프로그램은 문자를 보내지 않습니다.</p>
            </div>
          </div>
          {qrError && <p className="lnd-msg err" role="alert">문구가 길어 QR을 만들지 못했습니다. 문구를 줄이거나 [💬 PC 카카오톡 발송]을 이용하세요. ({qrError})</p>}
          <div className="lnd-field" style={{ marginTop: 18 }}><b>완성 문구 (전체 {sms.body.length}자)</b><pre className="lnd-text">{sms.body}</pre></div>
        </NoticeDialog>
      )}

      {kakao && (
        <NoticeDialog title="💬 PC 카카오톡 발송 준비" onClose={() => setKakao(null)}>
          <p className={`lnd-msg ${kakao.kind}`} role="status">{kakao.kind === 'ok' ? '✔ ' : '⚠ '}{kakao.text}</p>
          <p className="lnd-msg info">아직 발송된 것이 아닙니다. 카카오톡에서 직접 [전송]을 눌러야 고객에게 전달됩니다.</p>
          <p className="lnd-msg info">카카오톡 친구 목록에 고객이 없는 경우 아래 [📱 휴대폰 문자 QR 발송]으로 즉시 문자 발송하세요. 스마트폰에서 내용을 확인하고 전송을 눌러 주세요.</p>
          <button type="button" className="lnd-btn gold" onClick={()=>{
            try{buildSmsUri(kakao.recipient,kakao.body);setQrError('');setSms({recipient:kakao.recipient,body:kakao.body});setKakao(null);}
            catch(e){setKakao({...kakao,kind:'err',text:e instanceof Error?e.message:'전화번호를 확인해 주세요.'});}
          }}>📱 휴대폰 문자 QR 발송</button>
          <div className="lnd-field" style={{ marginTop: 18 }}><b>고객 번호</b><span className="lnd-phone">{kakao.recipient || '번호 없음'}</span></div>
          <div className="lnd-field"><b>완성 문구</b><pre className="lnd-text">{kakao.body}</pre></div>
        </NoticeDialog>
      )}
    </>
  );
}

const won = (v: number) => `${(v || 0).toLocaleString('ko-KR')}원`;
const day = (iso: string) => { const d = new Date(iso); return isNaN(+d) ? '-' : `${d.getMonth() + 1}월 ${d.getDate()}일`; };

export function PickupOrderPicker({ onClose, onSelect }: { onClose: () => void; onSelect: (orderId: string) => void }) {
  const [q, setQ] = useState('');
  const loaded = useMemo<{ orders: ConfirmedOrder[]; error: string }>(() => {
    try { return { orders: [...readConfirmedOrders()].sort((a, b) => b.intakeAt.localeCompare(a.intakeAt)), error: '' }; }
    catch (e) { return { orders: [], error: e instanceof Error ? e.message : '주문 기록을 읽지 못했습니다.' }; }
  }, []);
  const shown = useMemo(() => q.trim() ? searchSavedOrders(loaded.orders, q) : loaded.orders.slice(0, 50), [q, loaded]);

  return (
    <NoticeDialog title="안내 보낼 주문 고르기" onClose={onClose}>
      <label style={{ display: 'block', fontWeight: 800, marginBottom: 8 }} htmlFor="lnd-search">고객 이름 또는 전화 뒷자리 4개</label>
      <input id="lnd-search" className="lnd-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="예: 김순자 / 1234" autoComplete="off" />
      {loaded.error && <p className="lnd-msg err" role="alert">주문 기록을 불러오지 못했습니다. {loaded.error}</p>}
      {!loaded.error && !loaded.orders.length && <p className="lnd-msg info">아직 저장된 주문이 없습니다. 접수를 먼저 완료해 주세요.</p>}
      {!!loaded.orders.length && !shown.length && <p className="lnd-msg warn">찾는 주문이 없습니다. 이름이나 번호 4자리를 다시 확인해 주세요.</p>}
      <ul className="lnd-list">
        {shown.map((o) => (
          <li key={o.id}>
            <button type="button" className="lnd-order" onClick={() => onSelect(o.id)}>
              <strong>{o.customerName} ({o.customerPhone.replace(/\D/g, '').slice(-4)})</strong>
              <span className="amt">{won(o.estimatedTotal)}</span>
              <span>{day(o.intakeAt)} 접수 · {o.items.map((i) => `${i.displayNameKo} ${i.quantity}`).join(', ')}</span>
              <span>총 {o.totalQuantity}점</span>
            </button>
          </li>
        ))}
      </ul>
    </NoticeDialog>
  );
}
