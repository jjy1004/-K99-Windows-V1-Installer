import {openCustomerNotice} from './notice-api';

export const INSPECTION_NOTICES = [
  ['inspection-consent','② 면책 동의'],
  ['additional-fee','③ 세탁비 인상'],
  ['inspection-consent-fee','④ 면책+인상'],
  ['complete-pickup','⑤ 완료 수령'],
] as const;
export const RELEASE_NOTICES = [
  ['complete-pickup','⑤ 방문 수령'],
  ['complete-delivery','⑥ 배송 안내'],
  ['reminder-7','⑦ 2차 수거'],
  ['storage-15','⑧ 보관료 안내'],
] as const;

/** 조회/편집만 연다. 주문 상태·가격·결제·출고 및 발송 완료 기록을 변경하지 않는다. */
export function NoticeQuickActions({orderId,stage='inspection'}:{orderId:string;stage?:'inspection'|'release'}){
  const entries=stage==='release'?RELEASE_NOTICES:INSPECTION_NOTICES;
  return <div role="group" aria-label="고객 안내 메시지 빠른 선택"
    style={{display:'flex',flexDirection:'row',flexWrap:'wrap',gap:6,margin:'8px 0',alignItems:'center'}}>
    <button type="button" className="cdir-btn" style={{minHeight:40,fontSize:16}}
      onClick={()=>openCustomerNotice(orderId,entries[0][0])}>💬 안내 메시지 발송</button>
    {entries.map(([id,label])=><button type="button" className="cdir-btn" style={{minHeight:40,fontSize:16}}
      key={id} data-testid={`notice-quick-${orderId}-${id}`} onClick={()=>openCustomerNotice(orderId,id)}>{label}</button>)}
  </div>;
}
