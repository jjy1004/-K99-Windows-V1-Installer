import {MessageSquareText} from 'lucide-react';
import {openCustomerNotice} from './notice-api';
import {NoticeDeliveryBadge} from './NoticeDeliveryBadge';
import {deliveryTime,deliveryView,useNoticeDelivery} from './notice-delivery-state';

export const INSPECTION_NOTICES = [
  ['inspection-consent','② 면책 동의'],
  ['additional-fee','③ 세탁비 인상'],
  ['inspection-consent-fee','④ 면책+인상'],
] as const;
export const RELEASE_NOTICES = [
  ['complete-pickup','⑤ 방문 수령'],
  ['complete-delivery','⑥ 배송 안내'],
  ['reminder-7','⑦ 2차 수거'],
  ['storage-15','⑧ 보관료 안내'],
] as const;

/** 조회/편집만 연다. 주문 상태·가격·결제·출고 및 발송 완료 기록을 변경하지 않는다. */
export function NoticeQuickActions({orderId,stage='inspection',compact=false}:{orderId:string;stage?:'inspection'|'release';compact?:boolean}){
  const entries=stage==='release'?RELEASE_NOTICES:INSPECTION_NOTICES;
  const delivery=useNoticeDelivery(orderId,stage==='release'?RELEASE_NOTICES.map(([id])=>id):undefined);
  const time=delivery.at&&compact?new Date(delivery.at).toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',hour12:false}):deliveryTime(delivery.at);
  const status=delivery.kind==='sent'?`✅ 메시지 발송됨 ${time}`:
    delivery.kind==='prepared'?`발송 준비됨 ${time}`:'알림 선택';
  if(compact) return <label className="notice-compact" data-message-state={delivery.kind}
    title={delivery.kind==='none'?'고객 안내 메시지 선택 후 편집·발송 화면이 열립니다':
      `${status} · ${delivery.kind==='sent'?'직원이 외부 전송 확인':'실제 전송 미확인'} · 다시 선택하면 재발송할 수 있습니다.`}>
    <MessageSquareText aria-hidden="true"/>
    <select value="" aria-label="고객 안내 메시지 빠른 선택" data-testid={`notice-select-${orderId}`}
      onChange={event=>{const id=event.target.value;event.target.value='';if(id)openCustomerNotice(orderId,id);}}>
      <option value="" disabled>{status}</option>
      {entries.map(([id,label])=><option key={id} value={id} data-testid={`notice-quick-${orderId}-${id}`}>{label}</option>)}
    </select>
  </label>;
  return <div role="group" className="notice-message-group" data-message-state={delivery.kind} aria-label="고객 안내 메시지 빠른 선택"
    style={{display:'grid',gridTemplateColumns:'repeat(2,minmax(0,1fr))',gap:6,margin:'6px 0',alignItems:'stretch'}}>
    <button type="button" className="cdir-btn" data-message-state={delivery.kind} style={{minHeight:36,fontSize:15,padding:'6px 8px',gridColumn:'1 / -1'}}
      onClick={()=>openCustomerNotice(orderId,entries[0][0])}><MessageSquareText aria-hidden="true" size={16}/>
      {delivery.kind==='none'?'안내 메시지 발송':status}</button>
    <NoticeDeliveryBadge orderId={orderId} templateIds={stage==='release'?RELEASE_NOTICES.map(([id])=>id):undefined}/>
    {entries.map(([id,label])=><button type="button" className="cdir-btn" style={{minHeight:36,fontSize:15,padding:'6px 8px'}}
      key={id} data-message-state={deliveryView(delivery.records,[id]).kind}
      data-testid={`notice-quick-${orderId}-${id}`} onClick={()=>openCustomerNotice(orderId,id)}>{label}</button>)}
  </div>;
}
