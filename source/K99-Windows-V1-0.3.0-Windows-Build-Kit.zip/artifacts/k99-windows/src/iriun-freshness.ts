/** Read-only, low-resolution health sampling. Never filters the saved image. */
export type FrameSample = {
  usable: boolean; pixelAvailable: boolean; frozenForMs: number; stalledForMs: number;
};
export type IriunFreshness = ReturnType<typeof createIriunFreshness>;
export function createPixelSampler() {
  let canvas: HTMLCanvasElement | undefined;
  return (video: HTMLVideoElement): Uint8ClampedArray | null => {
    try {
      canvas ??= document.createElement('canvas');
      if (canvas.width !== 32) canvas.width = 32;
      if (canvas.height !== 18) canvas.height = 18;
      const g = canvas.getContext('2d', {willReadFrequently: true});
      if (!g) return null;
      g.drawImage(video, 0, 0, 32, 18);
      return g.getImageData(0, 0, 32, 18).data;
    } catch {return null;}
  };
}
export function createIriunFreshness(options: {
  now?: () => number; readPixels?: ReturnType<typeof createPixelSampler>;
} = {}) {
  const now = options.now ?? (() => globalThis.performance?.now() ?? Date.now());
  const read = options.readPixels ?? createPixelSampler();
  let pixels: Uint8ClampedArray | undefined, pixelAt = now(), frameAt = now();
  let source: MediaStream | undefined, progress: number | undefined;
  return {
    frame() {frameAt = now();},
    sample(video: HTMLVideoElement, stream: MediaStream): FrameSample {
      const time = now(), track = stream.getVideoTracks()[0];
      if (time < pixelAt) pixelAt = time;
      if (time < frameAt) frameAt = time;
      const usable = !!track && track.readyState !== 'ended' && !track.muted &&
        video.srcObject === stream && video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0;
      if (source !== stream) {
        source = stream; progress = undefined; frameAt = time;
        // Keep the last *image* across reconnects. Reopening an Iriun driver
        // that repeats the old garment must not make that image "fresh".
      }
      if (!usable) return {usable: false, pixelAvailable: false, frozenForMs: time - pixelAt, stalledForMs: time - frameAt};
      const next = video.getVideoPlaybackQuality?.().totalVideoFrames ?? video.currentTime;
      if (Number.isFinite(next) && next !== progress) {progress = next; frameAt = time;}
      const data = read(video);
      let sum = 0, max = 0, count = 0;
      if (data) for (let i = 0; i + 2 < data.length; i += 4) for (let c = 0; c < 3; c++) {
        const v = data[i + c]; sum += v; max = Math.max(max, v); count++;
      }
      const available = count > 0 && !(max <= 4 && sum / count <= 1);
      if (data && available) {
        let changed = !pixels || pixels.length !== data.length;
        if (!changed) for (let i = 0; i < data.length; i++) {
          if (i % 4 !== 3 && data[i] !== pixels![i]) {changed = true; break;}
        }
        if (changed) {pixels = new Uint8ClampedArray(data); pixelAt = time;}
      }
      return {usable, pixelAvailable: available, frozenForMs: time - pixelAt, stalledForMs: time - frameAt};
    },
  };
}
export const IRIUN_RECONNECT_MESSAGE = '🔄 Wi-Fi 카메라 신호 재연결 중... (자동 복구됩니다)';
