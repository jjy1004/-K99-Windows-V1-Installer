import type { ConfirmedOrder } from './order-record';
import type { GarmentRecord } from './garment-record';

export type Eligibility = { ok: true } | { ok: false; reason: string };

const APPROVED = ['세탁 진행 승인', '전체 세탁 완료 / 반출 대기'];

/**
 * Photo (and therefore first tag) is allowed only after professional inspection
 * and, for garments covered by a required consent, after that consent is approved.
 * Normal sibling garments outside an explicit affectedGarmentIds scope may proceed.
 * Enforced in the capture workspace for direct routes and actions, not just buttons.
 */
export function photoEligibility(order: ConfirmedOrder, garmentId: string | undefined): Eligibility {
  const garment = order.garments?.find((g) => g.garmentId === garmentId && g.orderId === order.id);
  if (!garment) return { ok: false, reason: '이 주문에 속한 의류를 확인할 수 없습니다.' };
  return orderStatusGate(order, garment.garmentId);
}

/** Order-level check used before garment records exist (they are created on first capture). */
export function orderPhotoEligible(order: ConfirmedOrder): boolean {
  if (order.garments?.length) return order.garments.some((g) => photoEligibility(order, g.garmentId).ok);
  return orderStatusGate(order, undefined).ok;
}

function orderStatusGate(order: ConfirmedOrder, garmentId: string | undefined): Eligibility {
  if (order.operations?.cancelledAt) return { ok: false, reason: '취소된 주문입니다.' };
  const inspection = order.inspection;
  // The saved order status is the authority: completeInspection / recorded customer
  // responses (face-to-face or message) move it to 세탁 진행 승인. An inspection object
  // alone is not approval.
  if (!inspection || !inspection.inspectedAt) return { ok: false, reason: '전문검수 완료 전에는 사진·태그를 진행할 수 없습니다.' };
  if (APPROVED.includes(order.status)) return { ok: true };
  const scope = inspection.affectedGarmentIds;
  if (garmentId && scope?.length && new Set(scope).size === scope.length &&
      scope.every(id => order.garments?.some(g => g.orderId === order.id && g.garmentId === id)) &&
      !scope.includes(garmentId) && ['고객 회신 대기', '보류', '세탁 진행 거절'].includes(order.status))
    return { ok: true };
  if (order.status === '세탁 진행 거절') return { ok: false, reason: '고객이 변경 작업을 거절했습니다. 해당 의류는 보류합니다.' };
  if (order.status === '보류') return { ok: false, reason: '해당 의류가 보류 상태입니다.' };
  if (order.status === '고객 회신 대기') return { ok: false, reason: '추가 요금·방법 변경·위험 동의 회신을 기록하기 전에는 사진·태그를 진행할 수 없습니다.' };
  return { ok: false, reason: '전문검수 결과가 저장되지 않았습니다.' };
}

export type TagIssuance = { label: string; kind: 'first' | 'reprint' | 'status' | 'retry'; disabledReason?: string };

/** Distinguishes first issuance (never printed) from reprint; status check never dispatches. */
export function tagIssuance(order: ConfirmedOrder, g: GarmentRecord | undefined, hasVerifiedHistory: boolean): TagIssuance {
  if (!g) return { label: '태그 발행', kind: 'first', disabledReason: '의류를 선택해 주세요.' };
  const gate = photoEligibility(order, g.garmentId);
  const job = g.photoBridgeReprintRequestId ? g.photoBridgeReprintStatus : g.photoBridgeAutoTagStatus;
  if (['pending', 'submitted', 'unknown'].includes(job ?? '')) return { label: '출력 여부 확인', kind: 'status' };
  if (!gate.ok) return { label: '태그 발행', kind: 'first', disabledReason: gate.reason };
  if (job === 'failed' || g.tagStatus === 'failed') return { label: '태그 발행 재시도', kind: 'retry' };
  const printedBefore = job === 'printed' || g.tagStatus === 'printed';
  if (printedBefore) return hasVerifiedHistory
    ? { label: '기존 태그 재출력', kind: 'reprint' }
    : { label: '기존 태그 재출력', kind: 'reprint', disabledReason: '검증된 출력 이력을 확인할 수 없어 재출력을 막았습니다.' };
  if (g.photoStatus !== 'saved') return { label: '최초 태그 발행', kind: 'first', disabledReason: '접수 사진 저장 후 최초 태그를 발행합니다.' };
  return { label: '최초 태그 발행', kind: 'first' };
}

/** Postwash-inspected and ironed garments may be marked READY by scan. Never delivered. */
export function readyScanEligibility(postwashDone: boolean, ironed: boolean, alreadyReady: boolean, delivered: boolean): Eligibility {
  if (delivered) return { ok: false, reason: '이미 인도된 의류입니다.' };
  if (alreadyReady) return { ok: false, reason: '이미 출고 준비 완료로 기록되어 있습니다.' };
  if (!postwashDone) return { ok: false, reason: '세탁 후 검수가 끝나지 않았습니다.' };
  if (!ironed) return { ok: false, reason: '다림질 완료 기록이 없습니다.' };
  return { ok: true };
}

export type DraftKind = 'fee' | 'method' | 'risk' | 'combined' | 'hold';
export function consentDraft(kind: DraftKind, p: {
  store: string; customer: string; garment: string; findings: string; before: number; add: number; method?: string;
}): string {
  const w = (n: number) => `${n.toLocaleString('ko-KR')}원`;
  const head = `[${p.store}] ${p.customer} 고객님, 맡기신 ${p.garment} 전문검수 결과 안내드립니다.\n확인 내용: ${p.findings}`;
  const fee = `\n기존 ${w(p.before)} + 추가 ${w(p.add)} = 변경 후 ${w(p.before + p.add)}`;
  const method = p.method ? `\n변경 세탁 방법: ${p.method}` : '';
  const ask = {
    fee: '\n추가 요금에 동의하시면 "동의"로 회신 부탁드립니다.',
    method: '\n세탁 방법 변경에 동의하시면 "동의"로 회신 부탁드립니다.',
    risk: '\n위 위험을 확인하시고 진행을 원하시면 "동의"로 회신 부탁드립니다.',
    combined: '\n추가 요금, 방법 변경, 위험 안내 모두에 동의하시면 "동의"로 회신 부탁드립니다.',
    hold: '\n안전한 세탁이 어려워 해당 의류는 작업하지 않고 보관 중입니다. 반환 또는 상담을 원하시면 회신 부탁드립니다.',
  }[kind];
  return head + (kind === 'fee' || kind === 'combined' ? fee : '') + (kind === 'method' || kind === 'combined' ? method : '') + ask
    + (kind === 'hold' ? '' : '\n회신 전에는 해당 의류 작업을 진행하지 않습니다.');
}
