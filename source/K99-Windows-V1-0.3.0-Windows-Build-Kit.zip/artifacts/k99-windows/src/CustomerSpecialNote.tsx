import {useEffect,useRef,useState} from 'react';
import {customerHistory,searchCustomers,type DirectoryCustomer} from './customer-directory-client';
import {NoticeDialog} from './LocalNoticeDialogs';

const OPEN='k99:edit-customer-special-note';
const SAVED='k99:customer-special-note-saved';

/** 직원 전용 표시. 고객용 문안/고객 모니터에는 전달하지 않는다. */
export function CustomerSpecialNote({customer,onSaved}:{customer:DirectoryCustomer;onSaved:(note:string)=>void}){
  useEffect(()=>{
    const saved=(event:Event)=>{
      const d=(event as CustomEvent<{id:string;note:string}>).detail;
      if(d?.id===customer.id)onSaved(d.note);
    };
    window.addEventListener(SAVED,saved);
    return()=>window.removeEventListener(SAVED,saved);
  },[customer.id,onSaved]);
  return <section aria-label="고객별 직원 전용 특이사항" style={{width:'100%',marginBottom:12}}>
    {customer.specialNote&&<div role="note" data-testid="customer-special-note-warning"
      style={{background:'#fef2f2',color:'#dc2626',border:'2px solid #dc2626',padding:18,fontWeight:800,fontSize:21,whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>
      ⚠️ 고객 특이사항: {customer.name}<br/>{customer.specialNote}
    </div>}
    <button type="button" className="cdir-btn" style={{fontSize:20,marginTop:8}}
      onClick={()=>window.dispatchEvent(new CustomEvent(OPEN,{detail:customer.id}))}>▲ 특이사항 기록</button>
  </section>;
}

function SpecialNoteEditor({initialId,onClose}:{initialId:string;onClose:()=>void}){
  const [customer,setCustomer]=useState<DirectoryCustomer|null>(null);
  const [query,setQuery]=useState(''),[results,setResults]=useState<DirectoryCustomer[]>([]);
  const [note,setNote]=useState(''),[expected,setExpected]=useState(''),[error,setError]=useState('');
  const [busy,setBusy]=useState(false),[loading,setLoading]=useState(false);
  const seq=useRef(0),live=useRef(true),editor=useRef<HTMLTextAreaElement>(null);
  useEffect(()=>{live.current=true;return()=>{live.current=false;seq.current++;};},[]);
  async function choose(id:string){
    const my=++seq.current;setLoading(true);setError('');
    try{
      const data=await customerHistory(id);
      if(!live.current||my!==seq.current)return;
      setCustomer(data.customer);setNote(data.customer.specialNote||'');setExpected(data.customer.specialNote||'');setResults([]);
    }catch(e){if(live.current&&my===seq.current)setError(e instanceof Error?e.message:'고객 정보를 읽지 못했습니다.');}
    finally{if(live.current&&my===seq.current)setLoading(false);}
  }
  useEffect(()=>{if(initialId)void choose(initialId);},[initialId]);
  useEffect(()=>{if(customer)editor.current?.focus({preventScroll:true});},[customer]);
  useEffect(()=>{
    let cancelled=false;
    if(customer||query.trim().length<2){setResults([]);return;}
    const timer=setTimeout(()=>void searchCustomers(query.trim()).then(r=>{
      if(!cancelled){setResults(r.customers);setError(r.customers.length?'':'일치하는 고객이 없습니다. 이름이나 전화번호 뒷4자리를 확인해 주세요.');}
    }).catch(e=>{if(!cancelled)setError(e instanceof Error?e.message:'검색하지 못했습니다.');}),180);
    return()=>{cancelled=true;clearTimeout(timer);};
  },[query,customer]);
  const close=()=>{
    if(busy)return;
    if(note!==expected&&!window.confirm('작성 중인 특이사항을 저장하지 않고 닫을까요?'))return;
    onClose();
  };
  async function reload(){
    if(!customer)return;
    try{
      const data=await customerHistory(customer.id);
      if(!live.current)return;
      setExpected(data.customer.specialNote||'');
      setError(`현재 저장된 기록: ${data.customer.specialNote||'(없음)'}\n작성 중인 내용은 유지했습니다. 내용을 합친 뒤 다시 저장해 주세요.`);
    }catch(e){if(live.current)setError(e instanceof Error?e.message:'최신 내용을 읽지 못했습니다.');}
  }
  async function save(){
    if(busy||!customer||loading)return;
    const id=customer.id;setBusy(true);setError('');
    try{
      const r=await fetch(`/api/customers/${encodeURIComponent(id)}/special-note`,{
        method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({note,expected})});
      const data=await r.json();if(!r.ok)throw Error(data.error||'저장하지 못했습니다.');
      if(!live.current)return;
      window.dispatchEvent(new CustomEvent(SAVED,{detail:{id,note:data.specialNote}}));
      onClose();
    }catch(e){if(live.current)setError(e instanceof Error?e.message:'저장에 실패했습니다.');}
    finally{if(live.current)setBusy(false);}
  }
  return <NoticeDialog title="고객 특이사항 기록 (직원 전용)" onClose={close}>
    {!customer&&<>
      <label>기록할 고객 이름 또는 전화번호 뒷4자리
        <input aria-label="특이사항 대상 고객 검색" lang="ko" className="nc-input" value={query} onChange={e=>setQuery(e.target.value)}/>
      </label>
      <p>기존 고객을 선택하면 해당 고객의 기록을 열어 드립니다. 새 주문이나 고객을 임의 생성하지 않습니다.</p>
      {results.map(c=><button type="button" className="nc-big" key={c.id} onClick={()=>void choose(c.id)}>{c.name} · {c.phone}</button>)}
    </>}
    {loading&&<p role="status">고객 기록을 읽는 중입니다.</p>}
    {customer&&<>
      <h3>{customer.name} · {customer.phone}</h3>
      <label>직원만 보는 고객별 주의사항
        <textarea ref={editor} aria-label="고객 특이사항 입력" lang="ko" maxLength={4000} value={note} onChange={e=>setNote(e.target.value)}
          style={{display:'block',width:'100%',minHeight:180,fontSize:20,padding:12,color:'#17212a',background:'#fff'}}/>
      </label>
      <p>고객 메시지·QR·고객 모니터에는 자동 포함되지 않습니다.</p>
      <div className="nc-row">
        <button type="button" className="nc-big gold" disabled={busy||loading} onClick={()=>void save()}>{busy?'저장 중':'특이사항 저장'}</button>
        <button type="button" className="nc-big" disabled={busy} onClick={()=>void reload()}>최신 기록 확인 · 입력 유지</button>
        <button type="button" className="nc-big" disabled={busy} onClick={close}>취소</button>
      </div>
    </>}
    {error&&<p role="alert" style={{color:'#b91c1c',whiteSpace:'pre-wrap'}}>{error}</p>}
  </NoticeDialog>;
}

/** 선택 전에도 즉시 모달을 연다. 선택된 고객 ID가 있으면 그 고객만 조회한다. */
export function SpecialNoteHost(){
  const [request,setRequest]=useState<{id:string;key:number}|null>(null);
  useEffect(()=>{
    let key=0;
    const open=(e:Event)=>{const id=(e as CustomEvent).detail;setRequest({id:typeof id==='string'?id:'',key:++key});};
    window.addEventListener(OPEN,open);
    return()=>window.removeEventListener(OPEN,open);
  },[]);
  return request?<SpecialNoteEditor key={request.key} initialId={request.id} onClose={()=>setRequest(null)}/>:null;
}
