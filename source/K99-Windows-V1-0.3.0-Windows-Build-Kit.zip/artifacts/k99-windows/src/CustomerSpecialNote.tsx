import {useEffect,useRef,useState} from 'react';
import type {DirectoryCustomer} from './customer-directory-client';
export function CustomerSpecialNote({customer,onSaved}:{customer:DirectoryCustomer;onSaved:(note:string)=>void}){
  const [editing,setEditing]=useState(false),[note,setNote]=useState(''),[expected,setExpected]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const current=useRef(customer.id);current.current=customer.id;
  const editor=useRef<HTMLTextAreaElement>(null);
  useEffect(()=>{setEditing(false);setNote(customer.specialNote||'');setExpected(customer.specialNote||'');setError('');},[customer.id,customer.specialNote]);
  useEffect(()=>{
    const open=(e:Event)=>{if((e as CustomEvent).detail===customer.id){
      setNote(customer.specialNote||'');setExpected(customer.specialNote||'');setEditing(true);setError('');
    }};
    window.addEventListener('k99:edit-customer-special-note',open);
    return()=>window.removeEventListener('k99:edit-customer-special-note',open);
  },[customer.id,customer.specialNote]);
  useEffect(()=>{if(editing){editor.current?.scrollIntoView({block:'nearest',behavior:'smooth'});editor.current?.focus();}},[editing]);
  async function reload(){
    try{
      const r=await fetch(`/api/customers/${encodeURIComponent(customer.id)}/history`),data=await r.json();
      if(!r.ok)throw Error(data.error||'최신 내용을 읽지 못했습니다.');
      if(current.current!==customer.id)return;
      setExpected(data.customer.specialNote||'');
      setError(`현재 저장된 기록: ${data.customer.specialNote||'(없음)'}\n작성 중인 내용은 유지했습니다. 위 내용을 합쳐 수정한 뒤 저장해 주세요.`);
    }catch(e){setError(e instanceof Error?e.message:'최신 내용을 읽지 못했습니다.');}
  }
  async function save(){
    if(busy)return;const id=customer.id;setBusy(true);setError('');
    try{
      const r=await fetch(`/api/customers/${encodeURIComponent(id)}/special-note`,{
        method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({note,expected})});
      const data=await r.json();if(!r.ok)throw Error(data.error||'저장하지 못했습니다.');
      if(current.current===id){onSaved(data.specialNote);setEditing(false);}
    }catch(e){if(current.current===id)setError(e instanceof Error?e.message:'저장에 실패했습니다.');}
    finally{setBusy(false);}
  }
  return <section aria-label="고객별 직원 전용 특이사항" style={{width:'100%',marginBottom:12}}>
    {customer.specialNote&&<div role="note" data-testid="customer-special-note-warning"
      style={{background:'#fef2f2',color:'#dc2626',border:'2px solid #dc2626',padding:18,fontWeight:800,fontSize:21,whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>
      🚨 {customer.name} 고객 특이사항<br/>{customer.specialNote}
    </div>}
    <button type="button" className="cdir-btn" style={{fontSize:20,marginTop:8}}
      onClick={()=>{setNote(customer.specialNote||'');setExpected(customer.specialNote||'');setEditing(v=>!v);setError('');}}>🚨 특이사항 기록</button>
    {editing&&<div style={{padding:12,background:'#fff',color:'#17212a'}}>
      <label>직원만 보는 고객별 주의사항<textarea ref={editor} lang="ko" maxLength={4000} value={note} onChange={e=>setNote(e.target.value)}
        style={{display:'block',width:'100%',minHeight:110,fontSize:20,padding:12}}/></label>
      <p>객관적으로 확인한 업무상 주의사항만 적어 주세요. 이 내용은 고객 안내·광고·휴대폰 화면으로 전달되지 않습니다.</p>
      <button type="button" className="cdir-btn" disabled={busy} onClick={()=>void save()}>{busy?'저장 중':'특이사항 저장'}</button>
      <button type="button" className="cdir-btn" onClick={()=>setEditing(false)}>취소</button>
      <button type="button" className="cdir-btn" onClick={()=>void reload()}>최신 기록 확인 · 입력 유지</button>
      {error&&<p role="alert" style={{color:'#b91c1c'}}>{error}</p>}
    </div>}
  </section>;
}
