import * as React from 'react';
import { orderDisplayStatus, garmentDisplayStatus } from './handover-display';
import type { ConfirmedOrder } from './order-record';
import { currentOperations } from './order-operations';
import { isGarmentComplete, listGarments } from './garment-scanner';
import { garmentProcessStatus } from './laundry-process';
import { handoverScanCount, handoverScanFingerprint, type HandoverScans } from './order-handover';

/** Read-only presentation: persisted departure is not a fresh scan receipt. */
export function ScannerOrderProgress({ order, scans }: { order: ConfirmedOrder; scans: HandoverScans }) {
  const garments = listGarments(order);
  const operation = currentOperations(order);
  const departed = Boolean(operation.completedAt || operation.stage === '배달중');
  return <>
    <p data-testid="text-scanner-order-progress">{departed
      ? `${orderDisplayStatus(order, operation.stage)} · ${garments.length}벌`
      : `완성 확인 ${handoverScanCount(order, scans)} / ${garments.length}벌`}</p>
    <ul>{garments.map((item) => <li key={item.garmentId}>
      {item.itemName} {item.sequence}/{item.totalSequence} · {departed
        ? garmentDisplayStatus(order, item, garmentProcessStatus(order, item))
        : item.qcHoldReason || garmentProcessStatus(order,item) !== '출고 대기' ? '검수 필요'
        : !isGarmentComplete(item) ? '스캔 대기'
        : scans[item.garmentId] === handoverScanFingerprint(item) ? '스캔 확인' : '스캔 대기'}
    </li>)}</ul>
  </>;
}

export function scannerCustomerChoices(orders: ConfirmedOrder[], query: string, orderScope?: string) {
  const term = query.trim();
  if (!term) return [];
  return orders.filter((order) => (!orderScope || order.id === orderScope) &&
    `${order.customerName} ${order.customerPhone}`.includes(term));
}
