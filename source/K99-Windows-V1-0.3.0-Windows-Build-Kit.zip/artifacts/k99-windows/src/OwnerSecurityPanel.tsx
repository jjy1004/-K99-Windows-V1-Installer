import { useEffect, useRef, useState, type FormEvent, type RefObject, type ReactNode } from 'react';
import { directoryRequest } from './customer-directory-client';
import './notice-center.css';
import './release-settings.css';

export const SECURITY_CHANGED = 'k99-security-changed';
type SecurityState = { registered: boolean; initial: boolean; phone: string; migrationNeeded: boolean };
type Mode = 'identity' | 'change' | 'recover' | null;
const PATH = '/api/admin/security';

function Pw({ label, inputRef, id, auto, max }: { label: string; inputRef: RefObject<HTMLInputElement | null>; id: string; auto: string; max?: number }) {
  return <label className="nc-label">{label}
    <input ref={inputRef} className="nc-input" type="password" autoComplete={auto} maxLength={max ?? 1024}
      inputMode={max === 6 ? 'numeric' : undefined} data-testid={id} /></label>;
}

export function OwnerSecurityPanel({ onSecurityChanged,backupOnly=false,children }: { onSecurityChanged?: () => void;backupOnly?:boolean;children?:ReactNode }) {
  const native = typeof window !== 'undefined' && !!window.k99Desktop;
  const [state, setState] = useState<SecurityState | null>(null);
  const [phone, setPhone] = useState('');
  const [mode, setMode] = useState<Mode>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const dob = useRef<HTMLInputElement>(null);
  const cur = useRef<HTMLInputElement>(null);
  const next = useRef<HTMLInputElement>(null);
  const conf = useRef<HTMLInputElement>(null);
  const composing=useRef(false);
  const cbRef = useRef(onSecurityChanged); cbRef.current = onSecurityChanged;

  const load = () => {
    if (!native) return;
    directoryRequest<SecurityState>('GET', PATH)
      .then(s => { setState(s); setPhone(s.phone); setError(''); })
      .catch(e => setError(e instanceof Error ? e.message : '보안 상태를 읽지 못했습니다.'));
  };
  useEffect(()=>{
    load();
    window.addEventListener(SECURITY_CHANGED,load);
    return()=>window.removeEventListener(SECURITY_CHANGED,load);
  }, [native]);

  const clear = () => { for (const r of [dob, cur, next, conf]) if (r.current) r.current.value = ''; };
  const v = (r: RefObject<HTMLInputElement | null>) => r.current?.value ?? '';

  async function submit(action: 'register' | 'identity' | 'change' | 'recover', e: FormEvent) {
    e.preventDefault();
    if (busy || !native || composing.current) return;
    setError(''); setStatus('');
    try {
      const birth = v(dob).trim();
      if ((action === 'register' || action === 'recover') && !/^\d{6}$/.test(birth)) throw new Error('생년월일은 숫자 6자리(예: 580312)로 입력해 주세요.');
      if (action === 'identity' && birth && !/^\d{6}$/.test(birth)) throw new Error('생년월일은 숫자 6자리로 입력하거나 비워 두세요.');
      if ((action === 'register' || action === 'identity') && phone.replace(/\D/g, '').length < 10 && !(action === 'identity' && !phone)) throw new Error('휴대전화 번호를 정확히 입력해 주세요.');
      if (action === 'change' || action === 'recover') {
        if (v(next).trim().length < 8) throw new Error('새 비밀번호는 8자 이상이어야 합니다.');
        if (v(next) !== v(conf)) throw new Error('새 비밀번호와 확인 입력이 다릅니다.');
      }
      setBusy(true);
      const body = action === 'register' ? { action, phone, birthDate: birth }
        : action === 'identity' ? { action, phone, birthDate: birth, currentPassword: v(cur) }
        : action === 'change' ? { action, currentPassword: v(cur), newPassword: v(next) }
        : { action, birthDate: birth, newPassword: v(next) };
      await directoryRequest('POST', PATH, body);
      clear();
      setStatus(action === 'register' ? '전환을 마쳤습니다. 이제 관리자 비밀번호는 K와 등록한 전화번호 뒷자리 4개입니다.'
        : action === 'identity' ? '등록 정보를 저장했습니다.'
        : action === 'change' ? '새 비밀번호로 바꿨습니다.' : '비밀번호를 새로 정했습니다.');
      setMode(null);
      window.dispatchEvent(new Event(SECURITY_CHANGED));
      cbRef.current?.();
    } catch (err) {
      clear();
      setError(err instanceof Error ? err.message : '처리하지 못했습니다.');
    } finally { setBusy(false); }
  }

  const dis = busy || !native;
  // Store settings now exposes backups only. Existing export-password recovery
  // callers retain their original protected controls and stored credentials.
  if(backupOnly)return <section className="nc-section" aria-label="전체 데이터 안전 백업 및 복원">{children}</section>;
  return <section className="nc-section rs-panel" aria-label="사장님 보안 설정" data-testid="owner-security-panel"
    onCompositionStartCapture={()=>{composing.current=true;}} onCompositionEndCapture={()=>{composing.current=false;}}>
    <h3>사장님 본인 확인 · 관리자 비밀번호</h3>
    {!native && <div className="nc-msg warn" role="alert" data-testid="text-security-native-required">이 설정은 매장 PC에 설치된 Windows 앱에서만 할 수 있습니다. 지금 화면에서는 버튼이 잠겨 있습니다.</div>}
    {native && !state && !error && <p data-testid="text-security-loading">보안 상태를 확인하는 중입니다...</p>}
    {state && <div className="rs-status" data-testid="status-security">
      <span className={`rs-pill ${state.registered ? 'gold' : 'warn'}`}>{state.registered ? '본인 정보 등록됨' : '본인 정보 미등록'}</span>
      {state.initial && <span className="rs-pill warn">초기 비밀번호 사용 중</span>}
      {state.phone && <span className="rs-pill" data-testid="text-security-phone">등록 전화 {state.phone}</span>}
      {state.migrationNeeded && <span className="rs-pill warn">전환 필요</span>}
    </div>}

    {(!state || !state.registered || state.migrationNeeded) && <form className="rs-form" onSubmit={e => void submit('register', e)}>
      <h4>처음 한 번만: 새 방식으로 전환</h4>
      <div className="nc-msg info"><span>
        전환 버튼을 누르면 지금 쓰던 관리자 비밀번호가 <b>대문자 K + 전화번호 뒷자리 4개</b>(예: K5678)로 바뀝니다. 소문자 k로 입력해도 됩니다.
        이 전환은 딱 한 번만 일어나며, 프로그램을 새로 업데이트해도 비밀번호가 다시 초기화되지 않습니다.
      </span></div>
      <label className="nc-label">사장님 휴대전화 번호
        <input className="nc-input" type="tel" value={phone} onChange={e => setPhone(e.target.value)} autoComplete="tel" maxLength={20} placeholder="010-1234-5678" data-testid="input-security-phone" /></label>
      <Pw label="생년월일 6자리 (예: 580312)" inputRef={dob} id="input-security-birth" auto="off" max={6} />
      <p className="nc-hint">생년월일은 화면에 보이지 않게 입력되며, PC에는 알아볼 수 없는 형태(해시)로만 저장됩니다.</p>
      <div className="nc-row"><button className="nc-big gold" type="submit" disabled={dis} data-testid="button-security-register">새 방식으로 전환하기</button></div>
    </form>}

    {state?.registered && !state.migrationNeeded && <>
      <div className="rs-tabs">
        <button className="nc-big" type="button" aria-pressed={mode === 'change'} disabled={dis} onClick={() => { clear(); setMode(mode === 'change' ? null : 'change'); }} data-testid="button-security-mode-change">비밀번호 바꾸기</button>
        <button className="nc-big" type="button" aria-pressed={mode === 'identity'} disabled={dis} onClick={() => { clear(); setPhone(''); setMode(mode === 'identity' ? null : 'identity'); }} data-testid="button-security-mode-identity">등록 정보 수정</button>
        <button className="nc-big ghost" type="button" aria-pressed={mode === 'recover'} disabled={dis} onClick={() => { clear(); setMode(mode === 'recover' ? null : 'recover'); }} data-testid="button-security-mode-recover">비밀번호를 잊었어요</button>
      </div>
      {mode === 'change' && <form className="rs-form" onSubmit={e => void submit('change', e)}>
        <h4>비밀번호 바꾸기</h4>
        <Pw label={state.initial ? '현재 비밀번호 (K + 전화 뒷자리 4개, k도 가능)' : '현재 비밀번호'} inputRef={cur} id="input-security-current" auto="current-password" />
        <Pw label="새 비밀번호 (8자 이상)" inputRef={next} id="input-security-new" auto="new-password" />
        <Pw label="새 비밀번호 다시 입력" inputRef={conf} id="input-security-confirm" auto="new-password" />
        <div className="nc-row"><button className="nc-big gold" type="submit" disabled={dis} data-testid="button-security-change">비밀번호 저장</button></div>
      </form>}
      {mode === 'identity' && <form className="rs-form" onSubmit={e => void submit('identity', e)}>
        <h4>등록 정보 수정</h4>
        <p className="nc-hint">바꾸지 않을 칸은 비워 두면 기존 정보가 그대로 유지됩니다.</p>
        <label className="nc-label">새 휴대전화 번호
          <input className="nc-input" type="tel" value={phone} onChange={e => setPhone(e.target.value)} maxLength={20} placeholder={state.phone || '010-1234-5678'} data-testid="input-security-identity-phone" /></label>
        <Pw label="새 생년월일 6자리" inputRef={dob} id="input-security-identity-birth" auto="off" max={6} />
        <Pw label="현재 관리자 비밀번호" inputRef={cur} id="input-security-identity-current" auto="current-password" />
        <div className="nc-row"><button className="nc-big gold" type="submit" disabled={dis} data-testid="button-security-identity">등록 정보 저장</button></div>
      </form>}
      {mode === 'recover' && <form className="rs-form" onSubmit={e => void submit('recover', e)}>
        <h4>비밀번호 다시 정하기</h4>
        <div className="nc-msg warn"><span>생년월일 6자리는 강력한 본인 확인 수단이 아닙니다. 자리를 비울 때는 꼭 Windows 화면 잠금(Windows 키 + L)을 해 주세요.</span></div>
        <Pw label="등록한 생년월일 6자리" inputRef={dob} id="input-security-recover-birth" auto="off" max={6} />
        <Pw label="새 비밀번호 (8자 이상)" inputRef={next} id="input-security-recover-new" auto="new-password" />
        <Pw label="새 비밀번호 다시 입력" inputRef={conf} id="input-security-recover-confirm" auto="new-password" />
        <div className="nc-row"><button className="nc-big gold" type="submit" disabled={dis} data-testid="button-security-recover">새 비밀번호 저장</button></div>
      </form>}
    </>}

    {status && <div className="nc-msg ok" role="status" data-testid="text-security-status">{status}</div>}
    {error && <div className="nc-msg err" role="alert" data-testid="text-security-error"><span>{error}</span>
      {native && <button className="nc-close" type="button" onClick={load} data-testid="button-security-reload">다시 불러오기</button>}</div>}
  </section>;
}
export default OwnerSecurityPanel;
