export type DeliveryPolicy = {
  freeFromQuantity: number;
  feeBelowThreshold: number;
};

export const DEFAULT_DELIVERY_POLICY: DeliveryPolicy = Object.freeze({
  freeFromQuantity: 4,
  feeBelowThreshold: 10000,
});
const POLICY_KEY = 'k99-delivery-policy-v1';

export function validateDeliveryPolicy(value: unknown): DeliveryPolicy {
  if (!value || typeof value !== 'object') throw new Error('수거·배달 정책을 읽을 수 없습니다.');
  const policy = value as Partial<DeliveryPolicy>;
  if (!Number.isSafeInteger(policy.freeFromQuantity) || policy.freeFromQuantity! < 1 || policy.freeFromQuantity! > 999
      || !Number.isSafeInteger(policy.feeBelowThreshold) || policy.feeBelowThreshold! < 0 || policy.feeBelowThreshold! > 1000000) {
    throw new Error('무료 기준은 1~999점, 수거·배달비는 0~1,000,000원으로 입력해 주세요.');
  }
  return { freeFromQuantity: policy.freeFromQuantity!, feeBelowThreshold: policy.feeBelowThreshold! };
}

export function readDeliveryPolicy(): DeliveryPolicy {
  if (typeof window === 'undefined') return DEFAULT_DELIVERY_POLICY;
  const raw = window.localStorage.getItem(POLICY_KEY);
  return raw ? validateDeliveryPolicy(JSON.parse(raw)) : DEFAULT_DELIVERY_POLICY;
}

export function saveDeliveryPolicy(value: DeliveryPolicy): DeliveryPolicy {
  const policy = validateDeliveryPolicy(value);
  window.localStorage.setItem(POLICY_KEY, JSON.stringify(policy));
  return policy;
}