import { LIVE_VIDEO_CHANNEL, StaffVideoChannel } from './customer-video-channel';
import type { CustomerMediaCommand } from './customer-media';

export const CUSTOMER_IDLE_REQUEST = 'k99:customer-idle-request';

/** Shared staff-button/ESC command, including routes without the intake component. */
export function requestCustomerIdle() {
  const request = new Event(CUSTOMER_IDLE_REQUEST, { cancelable: true });
  if (!window.dispatchEvent(request)) return;
  const command: CustomerMediaCommand = { id: crypto.randomUUID(), video: 'idle', issuedAt: Date.now() };
  if (window.k99Desktop) {
    window.k99Desktop.customerAction({ type: 'video', command });
    return;
  }
  try {
    const payload = JSON.parse(localStorage.getItem('k99-laundry-display-state') || 'null');
    if (!payload?.sourceId || !('BroadcastChannel' in window)) throw Error('고객 화면을 먼저 열어 주세요.');
    const link = new StaffVideoChannel(new BroadcastChannel(LIVE_VIDEO_CHANNEL), {
      source: () => payload.sourceId, onLink: () => {}, onAck: () => {}, onStatus: () => {},
    });
    void link.send(command).catch(error => console.warn('[K99 idle]', error))
      .finally(() => link.close());
  } catch (error) {
    console.warn('[K99 idle]', error);
  }
}
