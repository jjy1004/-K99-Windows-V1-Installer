import { useEffect, useRef, useState } from 'react';
import { dispatchFootCapture, FOOT_CAPTURE_EVENT, type FootSwitchKey } from './desktop-runtime';
export const FOOT_SWITCH_KEYS = [
  'F7','Enter',
] as FootSwitchKey[];
export function fullHdCameraConstraints(deviceId = ''): MediaStreamConstraints {
  return safeCameraConstraints(deviceId);
}
import { customerKeyboardOwnsEnter } from './customer-autofill';
import {acquireCamera,safeCameraConstraints,stopCameraStream,cameraAbort,cameraDelay} from './camera-device';
const ownedStreams=new Set<MediaStream>();
let requestVersion=0;
let pending:AbortController|null=null;
let queue:Promise<unknown>=Promise.resolve();
let warming:Promise<void>|null=null;
export function warmPreferredCamera():Promise<void>{
  if(warming)return warming;
  // Detect devices without keeping a hidden stream that can lock UVC drivers.
  warming=navigator.mediaDevices.enumerateDevices().then(()=>{}).catch(()=>{}).finally(()=>{warming=null;});
  return warming;
}
export function releaseCameraStreams(){
  requestVersion++;pending?.abort();pending=null;
  ownedStreams.forEach(stopCameraStream);ownedStreams.clear();
}
export function openPreferredCamera(deviceId=''):Promise<MediaStream>{
  releaseCameraStreams();
  const version=requestVersion,controller=new AbortController();pending=controller;
  const result=queue.catch(()=>{}).then(async()=>{
    if(version!==requestVersion)throw cameraAbort();
    // A single owner and cooldown cover rapid dropdown changes and switches
    // between the reception and equipment camera screens.
    await cameraDelay(300);
    if(version!==requestVersion)throw cameraAbort();
    const stream=await acquireCamera(navigator.mediaDevices,deviceId,controller.signal);
    if(version!==requestVersion){stopCameraStream(stream);throw cameraAbort();}
    ownedStreams.add(stream);
    return stream;
  });
  queue=result.then(()=>{},()=>{});
  return result;
}
window.addEventListener('pagehide',releaseCameraStreams);
export async function playCameraVideo(video:HTMLVideoElement,stream:MediaStream,timeoutMs=6000){
  // The decoder must not depend on a React "camera ready" flag that itself
  // waits for this function. Always show the real video before waiting.
  video.hidden=false;video.autoplay=true;video.muted=true;video.playsInline=true;
  video.srcObject=stream;
  let interval:ReturnType<typeof setInterval>|undefined,timer:ReturnType<typeof setTimeout>|undefined;
  try{
    await new Promise<void>((resolve,reject)=>{
      const check=()=>{if(video.srcObject===stream&&video.readyState>=2&&video.videoWidth>0&&video.videoHeight>0)resolve();};
      interval=setInterval(check,50);check();
      timer=setTimeout(()=>reject(new Error('카메라가 영상을 보내지 않습니다. USB 연결·권한과 OBS 등 다른 앱의 카메라 점유를 확인해 주세요.')),timeoutMs);
      // A decoded frame is enough even if an older Chromium leaves play()
      // pending. Keep explicit playback rejection visible to the operator.
      try{Promise.resolve(video.play()).then(check,reject);}catch(error){reject(error);}
    });
  }finally{clearInterval(interval);clearTimeout(timer);}
}
export function useFootCapture(ready: boolean, key: FootSwitchKey, capture: () => void) {
  const action = useRef(capture); action.current = capture;
  const [registrationError, setRegistrationError] = useState('');
  useEffect(() => {
    setRegistrationError('');
    if (!ready) return;
    let live = true;
    const onCapture = () => action.current();
    const onKey = (event: KeyboardEvent) => {
      const input = event.target as HTMLInputElement | null;
      const field = input?.getAttribute?.('data-testid');
      if ((field === 'input-customer-name' || field === 'input-customer-phone') &&
          customerKeyboardOwnsEnter(event.key, input?.value || '', field === 'input-customer-name' ? 'name' : 'phone',
            input?.getAttribute('data-k99-customer-selection') ?? null, !!document.getElementById('k99-customer-suggestions'))) return;
      const pressed = event.code === 'Space' ? 'Space' : event.key.length === 1 ? event.key.toUpperCase() : event.key;
      if (pressed !== key || event.isComposing || event.keyCode === 229 ||
        (event.target instanceof HTMLElement && event.target.dataset.koreanComposing === 'true') ||
        event.ctrlKey || event.altKey || event.metaKey) return;
      event.preventDefault(); event.stopImmediatePropagation();
      if (!event.repeat) dispatchFootCapture(key);
    };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener(FOOT_CAPTURE_EVENT, onCapture);
    // Enter is captured in this window, including focused inputs. Do not try
    // to reserve a system-wide Enter/F12 shortcut or show registration errors.
    void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: true, accelerator: key }))
      .catch(error => {
        if (live) setRegistrationError(`Windows 전역 촬영 키 등록 실패: ${String(error)}. 앱 창 내부 키만 동작합니다.`);
      });
    return () => {
      live = false;
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener(FOOT_CAPTURE_EVENT, onCapture);
      void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: false, accelerator: key }))
        .catch(error => console.error('풋 스위치 해제 실패', error));
    };
  }, [ready, key]);
  return registrationError;
}
