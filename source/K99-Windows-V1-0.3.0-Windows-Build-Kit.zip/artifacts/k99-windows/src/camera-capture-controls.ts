import { useEffect, useRef, useState } from 'react';
import { dispatchFootCapture, FOOT_CAPTURE_EVENT, type FootSwitchKey } from './desktop-runtime';
export const FOOT_SWITCH_KEYS = [
  'Enter',
] as FootSwitchKey[];
export function fullHdCameraConstraints(deviceId = ''): MediaStreamConstraints {
  return { video: { width: { ideal: 1920, min: 1280 }, height: { ideal: 1080, min: 720 },
    ...(deviceId ? { deviceId: { exact: deviceId } } : {}) }, audio: false };
}
export async function openPreferredCamera(deviceId=''):Promise<MediaStream>{
  const preferred=async()=> (await navigator.mediaDevices.enumerateDevices())
    .find(d=>d.kind==='videoinput'&&d.label.toLowerCase().includes('obs virtual camera'));
  let obs=await preferred();
  let stream:MediaStream;
  try{stream=await navigator.mediaDevices.getUserMedia(fullHdCameraConstraints(obs?.deviceId||deviceId));}
  catch(error){
    if(obs||!deviceId||!(error instanceof DOMException)||!['NotFoundError','OverconstrainedError'].includes(error.name))throw error;
    stream=await navigator.mediaDevices.getUserMedia(fullHdCameraConstraints());
  }
  if(!obs){
    obs=await preferred();
    if(obs&&stream.getVideoTracks()[0]?.getSettings().deviceId!==obs.deviceId){
      stream.getTracks().forEach(t=>t.stop());
      stream=await navigator.mediaDevices.getUserMedia(fullHdCameraConstraints(obs.deviceId));
    }
  }
  return stream;
}
export function useFootCapture(ready: boolean, key: FootSwitchKey, capture: () => void) {
  const action = useRef(capture); action.current = capture;
  const [registrationError, setRegistrationError] = useState('');
  useEffect(() => {
    setRegistrationError('');
    if (!ready) return;
    let live = true;
    const onCapture = () => action.current();
    const onKey = (event: KeyboardEvent) => {
      const pressed = event.code === 'Space' ? 'Space' : event.key.length === 1 ? event.key.toUpperCase() : event.key;
      if (pressed !== key || event.isComposing || event.ctrlKey || event.altKey || event.metaKey) return;
      event.preventDefault(); event.stopImmediatePropagation();
      if (!event.repeat) dispatchFootCapture(key);
    };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener(FOOT_CAPTURE_EVENT, onCapture);
    // Enter is captured in this window, including focused inputs. Do not try
    // to reserve a system-wide Enter/F12 shortcut or show registration errors.
    void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: true, accelerator: key }))
      .catch(error => {
        if (live) setRegistrationError(`Windows 전역 촬영 키 등록 실패: ${String(error)}. 앱 창 내부 키만 동작합니다.`);
      });
    return () => {
      live = false;
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener(FOOT_CAPTURE_EVENT, onCapture);
      void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: false, accelerator: key }))
        .catch(error => console.error('풋 스위치 해제 실패', error));
    };
  }, [ready, key]);
  return registrationError;
}
