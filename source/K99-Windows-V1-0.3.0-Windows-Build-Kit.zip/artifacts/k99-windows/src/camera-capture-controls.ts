import { useEffect, useRef, useState } from 'react';
import { dispatchFootCapture, FOOT_CAPTURE_EVENT, type FootSwitchKey } from './desktop-runtime';
export const FOOT_SWITCH_KEYS = [
  'F7','Enter',
] as FootSwitchKey[];
export function fullHdCameraConstraints(deviceId = ''): MediaStreamConstraints {
  return { video: { width: { ideal: 1920 }, height: { ideal: 1080 },
    ...(deviceId ? { deviceId } : {}) }, audio: false };
}
import { customerKeyboardOwnsEnter } from './customer-autofill';
import { acquireCamera } from './camera-device';
let warmStream:MediaStream|null=null;
let warming:Promise<void>|null=null;
export function warmPreferredCamera():Promise<void>{
  if(warming)return warming;
  warming=(async()=>{
    try{warmStream=await acquireCamera(navigator.mediaDevices);}catch{/* QR-only shops require no camera or error dialog. */}
  })().finally(()=>{warming=null;});
  return warming;
}
export async function openPreferredCamera(deviceId=''):Promise<MediaStream>{
  if(warming)await warming;
  const track=warmStream?.getVideoTracks()[0];
  if(track?.readyState==='live'&&(!deviceId||track.getSettings().deviceId===deviceId)){
    // Transfer ownership: no hidden warm stream holds a USB camera open.
    const stream=warmStream!;warmStream=null;return stream;
  }
  warmStream?.getTracks().forEach(t=>t.stop());warmStream=null;
  return acquireCamera(navigator.mediaDevices,deviceId);
}
window.addEventListener('pagehide',()=>{warmStream?.getTracks().forEach(t=>t.stop());warmStream=null;});
export function useFootCapture(ready: boolean, key: FootSwitchKey, capture: () => void) {
  const action = useRef(capture); action.current = capture;
  const [registrationError, setRegistrationError] = useState('');
  useEffect(() => {
    setRegistrationError('');
    if (!ready) return;
    let live = true;
    const onCapture = () => action.current();
    const onKey = (event: KeyboardEvent) => {
      const input = event.target as HTMLInputElement | null;
      const field = input?.getAttribute?.('data-testid');
      if ((field === 'input-customer-name' || field === 'input-customer-phone') &&
          customerKeyboardOwnsEnter(event.key, input?.value || '', field === 'input-customer-name' ? 'name' : 'phone',
            input?.getAttribute('data-k99-customer-selection') ?? null, !!document.getElementById('k99-customer-suggestions'))) return;
      const pressed = event.code === 'Space' ? 'Space' : event.key.length === 1 ? event.key.toUpperCase() : event.key;
      if (pressed !== key || event.isComposing || event.keyCode === 229 ||
        (event.target instanceof HTMLElement && event.target.dataset.koreanComposing === 'true') ||
        event.ctrlKey || event.altKey || event.metaKey) return;
      event.preventDefault(); event.stopImmediatePropagation();
      if (!event.repeat) dispatchFootCapture(key);
    };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener(FOOT_CAPTURE_EVENT, onCapture);
    // Enter is captured in this window, including focused inputs. Do not try
    // to reserve a system-wide Enter/F12 shortcut or show registration errors.
    void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: true, accelerator: key }))
      .catch(error => {
        if (live) setRegistrationError(`Windows 전역 촬영 키 등록 실패: ${String(error)}. 앱 창 내부 키만 동작합니다.`);
      });
    return () => {
      live = false;
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener(FOOT_CAPTURE_EVENT, onCapture);
      void Promise.resolve(key==='Enter'?undefined:window.k99Desktop?.setFootCaptureActive?.({ active: false, accelerator: key }))
        .catch(error => console.error('풋 스위치 해제 실패', error));
    };
  }, [ready, key]);
  return registrationError;
}
