import { ArrowRight, MonitorUp } from 'lucide-react';
import type { IntakeMode } from './intake-mode';
import { StoreName } from './StoreName';
import { NumUnit } from './NumUnit';

export const intakeModes: Array<{ id: IntakeMode; title: string; description: string }> = [
  { id: 'garment', title: '일반 세탁물 접수', description: '의류와 생활 세탁물을 접수합니다.' },
  { id: 'sneaker', title: '운동화 접수', description: '운동화 서비스를 안내한 뒤 접수합니다.' },
  { id: 'combined', title: '일반 세탁물 + 운동화 동시 접수', description: '한 고객의 세탁물과 운동화를 한 주문에 함께 접수합니다.' },
];

type CommonInfoProps = {
  onConfirm: () => void;
  onShowCustomer?: () => void;
};

export function CommonPreIntakeInfo({ onConfirm, onShowCustomer }: CommonInfoProps) {
  return (
    <main className="sneaker-intro-screen common-info-screen" data-testid="common-pre-intake-screen">
      <div className="sneaker-intro-content">
        <div className="sneaker-intro-top">
          <span className="sneaker-intro-brand"><StoreName /></span>
          <span className="sneaker-intro-tag">접수 전 안내</span>
        </div>
        <header className="sneaker-intro-header">
          <span>접수 전 고객 안내</span>
          <h1>세탁 접수 전 안내</h1>
        </header>
        <div className="common-info-copy">
          <p>현재 표시되는 세탁비는 접수 단계의 예상 금액입니다.</p>
          <p>세탁물의 케어라벨에 표시된 세탁방법, 소재와 형태, 얼룩 및 오염 정도, 변색·이염 가능성, 부속품 상태 및 명품 여부 등을 한양대학교 유기나노공학과 정재윤 교수가 정밀 검수한 후 최종 세탁방법과 세탁비가 달라질 수 있습니다.</p>
          <p>K99 품격세탁소에서는 구입가격 <NumUnit>50만 원</NumUnit> 이상의 의류 및 운동화를 명품 세탁물로 분류하여 더욱 세밀하게 검수합니다.</p>
          <p>검수 결과 세탁방법 또는 세탁비의 변경이 필요한 경우 SNS로 먼저 안내해 드립니다. 안내 내용을 확인하신 후 세탁 진행 여부를 확정해 주시면 세탁을 시작합니다.</p>
          <p>고객님의 확인 없이 변경된 금액으로 임의 진행하지 않습니다.</p>
        </div>
        <div className="sneaker-intro-actions">
          {onShowCustomer && (
            <button type="button" className="sneaker-intro-customer" data-testid="button-show-common-info-customer" onClick={onShowCustomer}>
              <MonitorUp aria-hidden="true" /> 고객 화면에서 보기
            </button>
          )}
          <button type="button" className="sneaker-intro-confirm" data-testid="button-confirm-common-info" onClick={onConfirm}>
            안내 확인 후 접수하기 <ArrowRight aria-hidden="true" />
          </button>
        </div>
      </div>
    </main>
  );
}