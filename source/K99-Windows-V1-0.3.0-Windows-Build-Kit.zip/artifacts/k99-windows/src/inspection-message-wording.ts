import type { InspectionItem } from './inspection-record';

type ItemContext = {
  name: string;
  item: InspectionItem;
  originalService: string;
  conflict: boolean;
  actualMethodChanged: boolean;
  riskNotice: string;
};

export function describedRisks(item: InspectionItem): string[] {
  return (item.riskFactors ?? []).filter((factor) => factor !== '기타');
}

export function inspectionItemExplanation({
  name, item, originalService, conflict, actualMethodChanged, riskNotice,
}: ItemContext): string[] {
  const work = item.additionalWork.filter((entry) => entry !== '추가 작업 없음');
  const reason = item.additionalWorkDescription.trim();
  const dyeStain = (work.includes('특수 얼룩 제거') || item.memo.includes('얼룩'))
    && /염색약/.test(`${reason} ${item.memo}`);
  const stain = dyeStain ? '염색약 얼룩'
    : work.includes('특수 얼룩 제거') || ['주의', '문제 있음'].includes(item.checks['오염/얼룩 상태'] ?? '')
      ? '얼룩' : '';
  const label = item.careLabelMethod === '기타' ? item.careLabelOther : item.careLabelMethod;
  const recordedReason = `${item.methodChangeReason ?? ''} ${riskNotice}`;
  const labelLimitation = conflict && !!label
    && /케어라벨|드라이세탁|물세탁|손세탁/.test(recordedReason)
    && /제거 불가|제거.*어렵|충분한 제거가 어렵|얼룩.*남을/.test(recordedReason);
  const recommended = item.method === '기타' ? item.customMethod.trim() : item.method;
  const serviceChanged = item.method !== '기존 방법 유지' && recommended !== originalService;
  const proposed = [
    ...(serviceChanged
      ? [`${actualMethodChanged && item.actualCleaningMethod
        ? `${item.actualCleaningMethod}을 포함한 ` : ''}${recommended}`]
      : actualMethodChanged && item.actualCleaningMethod ? [`${item.actualCleaningMethod} 방식`] : []),
    ...work.filter((entry) => !serviceChanged || entry !== recommended)
      .map((entry) => dyeStain && entry === '특수 얼룩 제거'
        ? '추가 얼룩 제거 작업(특수 얼룩 제거)' : `${entry} 작업`),
  ].join('과 ');
  const lines: string[] = [];

  if (stain && labelLimitation) {
    const labelMethod = label!.replace(/(만 가능| 권장)$/, '');
    lines.push(`${name}에서 확인된 ${stain}은 케어라벨에 표시된 ${labelMethod}만으로는 충분히 제거하기 어렵습니다.`);
  } else {
    if (stain) lines.push(`${name}에서 ${stain}을 확인했습니다.`);
    if (conflict && label) lines.push(`케어라벨에는 ${label}으로 표시되어 있지만, 검수 결과 다른 방법이 필요하다고 판단했습니다.`);
  }
  if (conflict && !labelLimitation && item.methodChangeReason?.trim())
    lines.push(`${item.methodChangeReason.trim().replace(/[.!?]$/, '')}.`);
  if (actualMethodChanged && !conflict && item.plannedCleaningMethod && item.actualCleaningMethod)
    lines.push(`기존에 예정된 ${item.plannedCleaningMethod} 대신 ${item.actualCleaningMethod}을 권장드립니다.`
      + (item.methodChangeReason?.trim() ? ` ${item.methodChangeReason.trim()}` : ''));
  if (proposed && (!actualMethodChanged || conflict || serviceChanged || work.length)) {
    lines.push(stain ? `${stain}을 최대한 제거하기 위해 ${proposed}을 권장드립니다.`
      : reason ? `${reason}을 위해 ${proposed}을 권장드립니다.`
        : `검수 결과 ${name}에 ${proposed}을 권장드립니다.`);
  }
  if (stain && /제거 불가|완전.*제거.*어렵/.test(item.riskDetails ?? ''))
    lines.push('작업 결과에 따라 일부 얼룩 흔적이 남을 수 있습니다.');
  if (conflict) {
    const risks = describedRisks(item);
    lines.push(risks.length
      ? `다만 ${item.actualCleaningMethod}은 케어라벨(${label})과 다른 방식이므로 ${risks.join('·')} 가능성을 별도로 안내드리겠습니다.`
      : `다만 ${item.actualCleaningMethod}은 케어라벨(${label})과 다른 방식이므로 예상되는 위험을 별도로 안내드리겠습니다.`);
  }
  if (!lines.length && describedRisks(item).length)
    lines.push(`${name}의 검수에서 ${describedRisks(item).join('·')} 가능성을 확인했습니다.`);
  return lines;
}