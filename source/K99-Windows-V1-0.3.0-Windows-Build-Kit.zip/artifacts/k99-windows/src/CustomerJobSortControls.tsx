import {ArrowDownAZ, CalendarDays} from 'lucide-react';
import type {CustomerJobSort} from './customer-job-sort';

export function CustomerJobSortControls({value,onChange}:{
  value:CustomerJobSort;onChange:(value:CustomerJobSort)=>void;
}){
  return <div className="job-sort-controls" role="group" aria-label="고객 카드 정렬">
    <button type="button" className="job-sort-button" aria-pressed={value === 'name'}
      data-testid="job-sort-name" onClick={()=>onChange('name')}>
      <ArrowDownAZ aria-hidden="true"/>이름순
    </button>
    <button type="button" className="job-sort-button" aria-pressed={value === 'date'}
      data-testid="job-sort-date" onClick={()=>onChange('date')}>
      <CalendarDays aria-hidden="true"/>날짜순
    </button>
  </div>;
}
