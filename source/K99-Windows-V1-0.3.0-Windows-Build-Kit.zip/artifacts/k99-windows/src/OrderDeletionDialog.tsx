import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import type { ConfirmedOrder } from './order-record';
import { deleteOrderAsStaff, settlementBlockReason } from './order-deletion';
import './order-deletion.css';

export default function OrderDeletionDialog({ order, onClose, onDeleted }: {
  order: ConfirmedOrder; onClose: () => void; onDeleted: () => void;
}) {
  const [ack, setAck] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const block = settlementBlockReason(order);
  const ref = useRef<HTMLDivElement>(null);
  const busyRef = useRef(busy); busyRef.current = busy;
  const closeRef = useRef(onClose); closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const controls = () => Array.from(ref.current?.querySelectorAll<HTMLElement>('input:not(:disabled),button:not(:disabled)') ?? []);
    controls()[0]?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); if (!busyRef.current) closeRef.current(); }
      if (e.key === 'Tab') {
        const all = controls(), first = all[0], last = all.at(-1);
        if (!first) { e.preventDefault(); return; }
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('keydown', key); previous?.focus(); };
  }, []);
  const reason = block ? block : !ack ? '한 주문만 삭제함을 확인해 주세요.' : '';

  async function submit() {
    if (busy || reason) return;
    setBusy(true); setError('');
    let ok = false;
    try { await deleteOrderAsStaff(order); ok = true; }
    catch (cause) { setError(cause instanceof Error ? cause.message : '주문을 삭제하지 못했습니다.'); }
    finally { setBusy(false); }
    if (ok) onDeleted();
  }

  return createPortal(
    <div className="order-deletion__overlay" onClick={e => { if (e.target === e.currentTarget && !busy) onClose(); }}>
      <div ref={ref} className="order-deletion__dialog" role="dialog" aria-modal="true" aria-labelledby="order-deletion-title"
        data-scanner-input data-testid="order-deletion-dialog">
        <h2 id="order-deletion-title">주문 삭제</h2>
        <p><strong>{order.customerName}</strong> · 주문번호 <code data-testid="order-deletion-order-id">{order.id}</code></p>
        <ul>{order.items.map((item, i) => <li key={i}>{item.displayNameKo} · {item.quantity}벌</li>)}</ul>
        <p>총 {order.totalQuantity}벌. 이 주문 1건만 삭제 표시되며 고객의 다른 주문과 원본 사진·태그는 보존됩니다. 운영 관리에서 복원할 수 있습니다.</p>
        {block && <p className="order-deletion__block" role="alert" data-testid="order-deletion-block-reason">{block}</p>}
        <label className="order-deletion__check">
          <input type="checkbox" checked={ack} disabled={busy || !!block} onChange={e => setAck(e.target.checked)} data-testid="order-deletion-ack" />
          <span>고객 전체가 아니라 이 주문 한 건만 삭제함을 확인합니다.</span>
        </label>
        <p>직원 확인으로 처리하며 삭제 일시와 처리 이력을 남깁니다. 복구 시에도 주문 상태와 충돌 여부를 확인합니다.</p>
        {reason && !block && <p data-testid="order-deletion-disabled-reason">{reason}</p>}
        {error && <p role="alert" className="order-deletion__error" data-testid="order-deletion-feedback">{error}</p>}
        <div className="order-deletion__actions">
          <button type="button" disabled={busy} onClick={onClose} data-testid="order-deletion-cancel">닫기</button>
          <button type="button" className="order-deletion__danger" disabled={busy || !!reason} onClick={() => void submit()} data-testid="order-deletion-submit">{busy ? '삭제 중…' : '삭제'}</button>
        </div>
      </div>
    </div>, document.body);
}
