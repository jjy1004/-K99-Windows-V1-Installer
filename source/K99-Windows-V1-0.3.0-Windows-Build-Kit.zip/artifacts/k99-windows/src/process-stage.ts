import { PROCESS_STAGES, type ConfirmedOrder, type ProcessNoticeKind, type ProcessStage, type ProcessStageRecord } from './order-record';

const won = (v: number) => `${v.toLocaleString('ko-KR')}원`;
const rank = (s: ProcessStage) => PROCESS_STAGES.indexOf(s);

export function currentProcessStage(order: ConfirmedOrder): ProcessStage {
  return order.processStage?.current ?? '접수';
}

export function nextProcessStage(stage: ProcessStage): ProcessStage | null {
  return PROCESS_STAGES[rank(stage) + 1] ?? null;
}

/** Moves the process tab. 'next' confirms the step; 'tab' is free navigation. History is append-only. */
export function moveProcessStage(order: ConfirmedOrder, stage: ProcessStage, via: 'next' | 'tab', at = new Date()): ConfirmedOrder {
  if (!PROCESS_STAGES.includes(stage)) throw new Error('알 수 없는 공정 단계입니다.');
  const prev = order.processStage;
  const base = prev?.reached ?? '접수';
  const reached = via === 'next' && rank(stage) > rank(base) ? stage : base;
  const record: ProcessStageRecord = {
    current: stage,
    reached,
    updatedAt: at.toISOString(),
    history: [...(prev?.history ?? []), { stage, at: at.toISOString(), via }].slice(-200),
  };
  return { ...order, processStage: record };
}

export const NOTICE_LABELS: Record<ProcessNoticeKind, string> = {
  waiver: '면책동의',
  fee: '추가 기술료',
  both: '면책동의 + 추가 기술료',
};

/** Complete, ready-to-edit customer message for the chosen notice type. */
export function noticeDraft(order: ConfirmedOrder, kind: ProcessNoticeKind, technicalFee: number): string {
  const items = order.items.map((i) => `${i.displayNameKo} ${i.quantity}점`).join(', ');
  const head = `[K99 품격세탁소 과천점] ${order.customerName} 고객님, 맡겨 주신 ${items} 검수 결과를 안내드립니다.`;
  const waiver = '소재와 오염 상태상 세탁 과정에서 변색, 수축, 이염 등의 변화가 생길 수 있습니다. 이 점에 동의해 주시면 세탁을 진행하겠습니다.';
  const fee = `오염 제거를 위한 특수 처리가 필요하여 추가 기술료 ${won(technicalFee)}이 발생합니다. 최종 금액은 ${won((order.feeAdjustment?.baseEstimatedTotal ?? order.estimatedTotal) + technicalFee)}입니다.`;
  const body = kind === 'waiver' ? waiver : kind === 'fee' ? fee : `${waiver}\n${fee}`;
  return `${head}\n${body}\n동의 여부를 회신해 주시면 바로 작업하겠습니다. 감사합니다.`;
}
