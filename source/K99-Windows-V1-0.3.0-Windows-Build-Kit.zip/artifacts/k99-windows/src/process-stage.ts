import { PROCESS_STAGES, type ConfirmedOrder, type ProcessNoticeKind, type ProcessStage, type ProcessStageRecord } from './order-record';
import { careNoticeTemplate } from './care-notice-templates';

const rank = (s: ProcessStage) => PROCESS_STAGES.indexOf(s);

export function currentProcessStage(order: ConfirmedOrder): ProcessStage {
  return order.processStage?.current ?? '접수';
}

export function nextProcessStage(stage: ProcessStage): ProcessStage | null {
  return PROCESS_STAGES[rank(stage) + 1] ?? null;
}

/** Moves the process tab. 'next' confirms the step; 'tab' is free navigation. History is append-only. */
export function moveProcessStage(order: ConfirmedOrder, stage: ProcessStage, via: 'next' | 'tab', at = new Date()): ConfirmedOrder {
  if (!PROCESS_STAGES.includes(stage)) throw new Error('알 수 없는 공정 단계입니다.');
  const prev = order.processStage;
  const base = prev?.reached ?? '접수';
  const reached = via === 'next' && rank(stage) > rank(base) ? stage : base;
  const record: ProcessStageRecord = {
    current: stage,
    reached,
    updatedAt: at.toISOString(),
    history: [...(prev?.history ?? []), { stage, at: at.toISOString(), via }].slice(-200),
  };
  return { ...order, processStage: record };
}

export const NOTICE_LABELS: Record<ProcessNoticeKind, string> = {
  waiver: '면책동의',
  fee: '추가 기술료',
  both: '면책동의 + 추가 기술료',
};

/** Complete, ready-to-edit customer message for the chosen notice type. */
export function noticeDraft(order: ConfirmedOrder, kind: ProcessNoticeKind, technicalFee: number): string {
  const items = order.items.map((i) => `${i.displayNameKo} ${i.quantity}점`).join(', ');
  return careNoticeTemplate(kind, order.customerName, items, technicalFee);
}
