import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getPhotoSettings } from './passive-photo-client';
import {
  inspectPhotoBridgeConnection, readPhotoBridgeConnectionSession,
} from './photo-bridge-session';
import { fetchStorePhotoHelper, STORE_PHOTO_HELPER_FILENAME } from './photo-bridge-download';
import { recoverPhotoBridge } from './photo-bridge-recovery';
import { createSerializedPoller } from './serialized-poller';
import { listRecentPhotos, loadPhotoPreview, type PhotoSourceItem } from './photo-source';
import { isDraftPhotoIdAvailable, type DraftPhotoAssociation } from './intake-draft';
import { readConfirmedOrders } from './order-record';
import './intake-photo-bridge.css';

export type IntakePhotoTarget = {
  garmentId: string;
  rowId: number;
  itemId: string;
  rowQuantity: number;
  unitIndex: number;
  label: string;
};

function filenameIsSupported(
  photo: PhotoSourceItem,
): photo is PhotoSourceItem & { sourcePath: string } {
  return photo.origin === 'bridge' && /\.(?:png|jpe?g|bmp|webp)$/i.test(photo.filename)
    && typeof photo.sourcePath === 'string' && photo.sourcePath.trim().length > 0
    && photo.sourcePath.split(/[\\/]/).at(-1)?.toLowerCase() === photo.filename.toLowerCase();
}

function friendlyPhotoError(error: unknown): string {
  return error instanceof Error ? error.message : '사진 도우미 상태를 확인하지 못했습니다.';
}

function photoAlreadyLinkedToSavedOrder(photoId: string): boolean {
  try {
    return readConfirmedOrders().some((order) => (order.garments ?? []).some((garment) =>
      garment.beforePhoto?.sourcePhotoId === photoId ||
      garment.photoHistory?.some((photo) => photo.sourcePhotoId === photoId)));
  } catch {
    // If order ownership cannot be checked, do not guess and risk a cross-order link.
    return true;
  }
}

export function IntakePhotoBridge({
  draftId,
  targets,
  associations,
  usedPhotoIds,
  canImport,
  conflict,
  onAssociationsChange,
  onPhotoUsed,
}: {
  draftId: string;
  targets: IntakePhotoTarget[];
  associations: DraftPhotoAssociation[];
  usedPhotoIds: string[];
  canImport: boolean;
  conflict: boolean;
  onAssociationsChange: (value: DraftPhotoAssociation[]) => void;
  onPhotoUsed: (photoId: string) => void;
}) {
  const [connection, setConnection] = useState('Windows 사진 도우미 연결을 확인하는 중입니다.');
  const [waitStatus, setWaitStatus] = useState('사진 도우미를 연결하면 새 사진을 찾습니다.');
  const [configured, setConfigured] = useState(false);
  const [photos, setPhotos] = useState<PhotoSourceItem[]>([]);
  const [selectedTarget, setSelectedTarget] = useState('');
  const [reviewPhotoId, setReviewPhotoId] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [previewError, setPreviewError] = useState('');
  const [previewRetry, setPreviewRetry] = useState(0);
  const previewFailedRef = useRef(false);
  const [identityConfirmed, setIdentityConfirmed] = useState(false);
  const [identityConfirmationKey, setIdentityConfirmationKey] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [pollError, setPollError] = useState('');
  const [helperDownloadError, setHelperDownloadError] = useState('');
  const [downloadingHelper, setDownloadingHelper] = useState(false);
  const watchStartedAtRef = useRef(Date.now());
  const photoRequestRevisionRef = useRef(0);
  const pollerRef = useRef<ReturnType<typeof createSerializedPoller> | null>(null);

  const availablePhotos = useMemo(() => photos.filter(filenameIsSupported), [photos]);
  const newPhotos = useMemo(() => availablePhotos.filter((photo) =>
    Date.parse(photo.timestamp) >= watchStartedAtRef.current), [availablePhotos]);
  const selectedPhoto = availablePhotos.find((photo) => photo.id === reviewPhotoId) ?? null;
  const selectedTargetRecord = targets.find((target) => target.garmentId === selectedTarget);
  const selectedTargetIsValid = !!selectedTargetRecord;
  const currentReviewKey = selectedPhoto && selectedTargetRecord
    ? JSON.stringify([draftId, selectedPhoto.id, selectedTargetRecord.garmentId, selectedTargetRecord.rowId,
      selectedTargetRecord.itemId, selectedTargetRecord.rowQuantity, selectedTargetRecord.unitIndex]) : '';
  const reviewConfirmedForCurrentContext =
    identityConfirmed && !!currentReviewKey && identityConfirmationKey === currentReviewKey;
  const linkedDraftAssociation = selectedPhoto
    ? associations.find((association) => association.sourcePhotoId === selectedPhoto.id) : undefined;
  const photoLinkedToSavedOrder = selectedPhoto && photoAlreadyLinkedToSavedOrder(selectedPhoto.id);
  const photoReservedButUnlinked = selectedPhoto && usedPhotoIds.includes(selectedPhoto.id) && !linkedDraftAssociation;
  const photoAlreadyLinked = selectedPhoto &&
    (!isDraftPhotoIdAvailable(usedPhotoIds, selectedPhoto.id) ||
      !!linkedDraftAssociation || !!photoLinkedToSavedOrder);
  const targetAlreadyLinked = associations.some((association) => association.garmentId === selectedTarget);

  useEffect(() => {
    setIdentityConfirmed(false);
    setIdentityConfirmationKey('');
  }, [currentReviewKey]);

  const recheck = useCallback(async () => {
    const revision = ++photoRequestRevisionRef.current;
    const session = readPhotoBridgeConnectionSession();
    const diagnostic = await inspectPhotoBridgeConnection();
    if (revision !== photoRequestRevisionRef.current) return;
    if (!session) {
      if (diagnostic.status === 'unpaired') {
        setConnection('로컬 Photo Bridge 응답 확인 · 이 탭은 아직 인증되지 않았습니다. STORE 도우미가 연 탭에서 연결을 완료해 주세요.');
        setWaitStatus('사진 촬영 대기 · 인증되지 않은 상태에서는 사진 목록을 조회하지 않습니다.');
      } else if (diagnostic.status === 'offline') {
        setConnection('로컬 Photo Bridge 응답 없음 · Windows 도우미 실행과 로컬 네트워크 연결을 확인해 주세요.');
        setWaitStatus('사진 촬영 대기 · 로컬 도우미 연결 확인 필요');
      } else {
        setConnection(`로컬 주소 응답은 받았지만 Photo Bridge health를 확인할 수 없습니다 (HTTP ${diagnostic.httpStatus}).`);
        setWaitStatus('사진 촬영 대기 · 호환되는 Photo Bridge인지 확인해 주세요.');
      }
      setConfigured(false);
      setPhotos([]);
      setPollError(diagnostic.status === 'offline' ? 'Windows V1 1단계에서는 사진 장치 연동이 비활성화되어 있습니다.' : '');
      return;
    }
    if (diagnostic.status !== 'connected') {
      setConnection(diagnostic.status === 'offline'
        ? 'Photo Bridge 로컬 health 응답이 없습니다. 연결을 확인해 주세요.'
        : `Photo Bridge 인증 health를 확인하지 못했습니다 (HTTP ${diagnostic.httpStatus}).`);
      setWaitStatus('사진 촬영 대기 · 연결 또는 인증 상태를 확인해 주세요.');
      setConfigured(false);
      setPhotos([]);
      setPollError(diagnostic.status === 'offline'
        ? '기존 매장 도우미에 연결하지 않습니다. 사진 연동은 2단계에서 별도로 검증합니다.'
        : '현재 탭의 인증 상태와 도우미 응답이 일치하지 않습니다. 도우미가 연 탭에서 다시 연결해 주세요.');
      return;
    }
    if (session.mode !== 'STORE') {
      setConnection(`Photo Bridge ${session.mode} 연결 health 확인 · 매장 사진 조회는 STORE 연결에서만 가능합니다.`);
      setWaitStatus('STORE 사진 연결 대기 · 카메라·사진 작업은 실행하지 않음');
      setConfigured(false);
      setPhotos([]);
      setPollError('');
      return;
    }

    // Health is the connection signal. Photo settings and scans are separate
    // operations: their failures must not turn an authenticated session offline.
    setConnection('Photo Bridge STORE 연결됨 · 인증 health 확인');
    setConfigured(diagnostic.photoConfigured);
    if (!diagnostic.photoConfigured) {
      setWaitStatus('사진 촬영 대기 · 확인할 저장 폴더가 없습니다.');
      setPhotos([]);
      setPollError('');
      return;
    }

    let settings: Awaited<ReturnType<typeof getPhotoSettings>>;
    try {
      settings = await getPhotoSettings();
      if (revision !== photoRequestRevisionRef.current) return;
      setConfigured(settings.configured);
      if (!settings.configured) {
        setConnection('Photo Bridge 연결됨 · STORE 사진 저장 폴더가 설정되지 않았습니다.');
        setWaitStatus('사진 촬영 대기 · 확인할 저장 폴더가 없습니다.');
        setPhotos([]);
        setPollError('');
        return;
      }
    } catch (error) {
      if (revision !== photoRequestRevisionRef.current) return;
      setPhotos([]);
      setPollError(`사진 설정을 확인하지 못했습니다. 자동으로 다시 확인합니다. ${friendlyPhotoError(error)}`);
      setWaitStatus('Photo Bridge 인증 연결됨 · 사진 설정을 자동으로 다시 확인하는 중입니다.');
      return;
    }

    try {
      const recent = await listRecentPhotos();
      if (revision !== photoRequestRevisionRef.current) return;
      setConnection('Photo Bridge STORE 연결됨 · 인증 health 확인');
      setPhotos(recent.filter(filenameIsSupported).slice(0, 30));
      if (previewFailedRef.current) {
        previewFailedRef.current = false;
        setPreviewRetry((attempt) => attempt + 1);
      }
      setPollError('');
      setWaitStatus('사진 촬영 대기 · OBS·풋스위치 동작과 별도로 새 저장 파일을 확인합니다.');
    } catch (error) {
      if (revision !== photoRequestRevisionRef.current) return;
      setPhotos([]);
      setPollError(`사진 목록을 불러오지 못했습니다. 자동으로 다시 확인합니다. ${friendlyPhotoError(error)}`);
      setWaitStatus('Photo Bridge 인증 연결됨 · 사진 목록을 자동으로 다시 확인하는 중입니다.');
    }
  }, []);

  useEffect(() => {
    let live = true;
    const poller = createSerializedPoller(() => recheck(), 1000);
    pollerRef.current = poller;
    const update = () => { if (live) poller.trigger(); };
    const visibilityUpdate = () => {
      if (live && document.visibilityState === 'visible') poller.trigger();
    };
    poller.start();
    window.addEventListener('k99-photo-bridge-session-changed', update);
    window.addEventListener('online', update);
    document.addEventListener('visibilitychange', visibilityUpdate);
    return () => {
      live = false;
      photoRequestRevisionRef.current++;
      poller.stop();
      if (pollerRef.current === poller) pollerRef.current = null;
      window.removeEventListener('k99-photo-bridge-session-changed', update);
      window.removeEventListener('online', update);
      document.removeEventListener('visibilitychange', visibilityUpdate);
    };
  }, [recheck]);

  useEffect(() => {
    setReviewPhotoId('');
    setPreviewUrl('');
    setPreviewError('');
    setIdentityConfirmed(false);
    setIdentityConfirmationKey('');
    watchStartedAtRef.current = Date.now();
  }, [draftId]);

  useEffect(() => {
    let live = true;
    previewFailedRef.current = false;
    if (!selectedPhoto || selectedPhoto.origin !== 'bridge') {
      setPreviewUrl('');
      setPreviewError('');
      return;
    }
    setPreviewUrl('');
    setPreviewError('');
    setIdentityConfirmed(false);
    setIdentityConfirmationKey('');
    void loadPhotoPreview(selectedPhoto.id, 'bridge')
      .then((url) => { if (live) setPreviewUrl(url); })
      .catch((error: unknown) => {
        if (live) {
          previewFailedRef.current = true;
          setPreviewError(friendlyPhotoError(error));
        }
      });
    return () => { live = false; };
  }, [selectedPhoto?.id, selectedPhoto?.origin, previewRetry]);

  const selectPhoto = (id: string) => {
    setReviewPhotoId(id);
    setPreviewUrl('');
    setPreviewError('');
    setIdentityConfirmed(false);
    setIdentityConfirmationKey('');
    setExpanded(true);
  };

  const linkReviewedPhoto = () => {
    if (!selectedPhoto || !previewUrl || !reviewConfirmedForCurrentContext || !canImport || conflict ||
        !selectedTargetIsValid || photoAlreadyLinked || targetAlreadyLinked ||
        selectedPhoto.origin !== 'bridge' || !filenameIsSupported(selectedPhoto)) return;
    const target = targets.find((item) => item.garmentId === selectedTarget);
    if (!target) return;
    const association: DraftPhotoAssociation = {
      garmentId: selectedTarget,
      rowId: target.rowId,
      itemId: target.itemId,
      rowQuantity: target.rowQuantity,
      unitIndex: target.unitIndex,
      sourcePhotoId: selectedPhoto.id,
      filename: selectedPhoto.filename,
      sourcePath: selectedPhoto.sourcePath,
      capturedAt: selectedPhoto.timestamp,
      requestId: crypto.randomUUID(),
    };
    // A real image can belong to only one order/garment. The existing history
    // storage is checked again at association time, not from a stale mount snapshot.
    if (photoAlreadyLinkedToSavedOrder(selectedPhoto.id)) {
      setPollError('이 사진은 이미 저장된 다른 세탁물에 연결되어 있습니다.');
      setIdentityConfirmed(false);
      return;
    }
    // Never persist image bytes, an object URL, or a Windows file URL.
    onPhotoUsed(selectedPhoto.id);
    onAssociationsChange([...associations, association]);
    setReviewPhotoId('');
    setPreviewUrl('');
    setIdentityConfirmed(false);
    setIdentityConfirmationKey('');
  };

  const removeAssociation = (garmentId: string) => {
    if (conflict) return;
    onAssociationsChange(associations.filter((item) => item.garmentId !== garmentId));
  };

  const base = (import.meta.env.BASE_URL || '/').replace(/\/?$/, '/');
  const recoverStoreHelper = async () => {
    if (downloadingHelper) return;
    setDownloadingHelper(true);
    setHelperDownloadError('');
    try {
      await recoverPhotoBridge();
      pollerRef.current?.trigger();
    } catch (error) {
      setHelperDownloadError(error instanceof Error ? error.message : '사진 도우미 연결을 확인하지 못했습니다.');
    } finally { setDownloadingHelper(false); }
  };

  const downloadStoreHelper = async () => {
    setDownloadingHelper(true);
    setHelperDownloadError('');
    try {
      const blob = await fetchStorePhotoHelper(`${base}${STORE_PHOTO_HELPER_FILENAME}`);
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = objectUrl;
      anchor.download = STORE_PHOTO_HELPER_FILENAME;
      anchor.style.display = 'none';
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    } catch (error) {
      setHelperDownloadError(friendlyPhotoError(error));
    } finally {
      setDownloadingHelper(false);
    }
  };

  return (
    <section className="intake-photo-bridge" data-testid="intake-photo-bridge" aria-labelledby="intake-photo-bridge-title">
      <div className="intake-photo-bridge__toolbar">
        <strong id="intake-photo-bridge-title">사진촬영</strong>
        <span role="status" data-testid="intake-photo-bridge-status">
          <span aria-hidden="true" style={{ color: configured ? '#359477' : '#bd8753' }}>●</span>
          {' '}{configured ? '연결됨' : '연결 확인 필요'}
        </span>
        <button type="button" data-testid="button-toggle-recent-photos" disabled={!configured && !photos.length}
          onClick={() => setExpanded((value) => !value)}>최근사진{expanded ? ' 접기' : ''}</button>
        <button type="button" className="intake-photo-bridge__recheck" data-testid="button-photo-bridge-recheck"
          onClick={() => pollerRef.current?.trigger()}>연결 확인</button>
      </div>
      {!configured && <p className="intake-photo-bridge__error" role="alert">
        매장 사진 연결을 확인해 주세요.
        <button type="button" onClick={() => void recoverStoreHelper()} disabled={downloadingHelper}>
          {downloadingHelper ? '자동 복구 중…' : '연결 도우미'}
        </button>
        {helperDownloadError && <span role="alert"> {helperDownloadError}</span>}
      </p>}
      <div className="intake-photo-bridge__details" hidden={!expanded}>
      <section aria-labelledby="intake-photo-bridge-connection-title">
        <h3 id="intake-photo-bridge-connection-title">Photo Bridge 연결 상태</h3>
        <p>{connection}</p>
      </section>

      <section aria-labelledby="intake-photo-wait-title">
        <h3 id="intake-photo-wait-title">사진 촬영 대기</h3>
        <p data-testid="intake-photo-bridge-wait">{waitStatus}</p>
        {!configured && <button type="button" className="intake-photo-bridge__download" data-testid="link-store-photo-helper"
          onClick={() => void downloadStoreHelper()} disabled={downloadingHelper}>
          {downloadingHelper ? '매장 Photo Bridge 도우미 확인 중…' : '매장 Photo Bridge 연결 도우미 다운로드'}
        </button>}
        {!configured && <p>매장 최종본: {STORE_PHOTO_HELPER_FILENAME} · 기존 LAB/TEST 파일은 사용하지 마세요.</p>}
        {helperDownloadError && <p role="alert" className="intake-photo-bridge__error" data-testid="store-photo-helper-download-error">
          {helperDownloadError}
        </p>}
      </section>

      <section aria-labelledby="intake-photo-review-title">
        <div className="intake-photo-bridge__list-heading">
          <h3 id="intake-photo-review-title">최근 촬영 사진 확인</h3>
          <button type="button" disabled={!configured || !photos.length}
            onClick={() => setExpanded((value) => !value)}>
             {expanded ? '사진 목록 접기' : `새로 감지 ${newPhotos.length}장 · 최근 사진`}
          </button>
        </div>
        {pollError && <p className="intake-photo-bridge__error" role="alert" data-testid="intake-photo-bridge-error">{pollError}</p>}
        {photos.length === 0 && <p data-testid="intake-photo-bridge-empty">
          {configured ? '현재 확인 가능한 JPG·PNG 사진이 없습니다. [사진 촬영 대기] 상태에서 촬영 후 목록을 확인해 주세요.' :
            'STORE 사진 도우미의 폴더 연결을 확인하면 JPG·PNG 사진이 표시됩니다.'}
        </p>}
        {!!newPhotos.length && <ul className="intake-photo-bridge__new-list" aria-label="연결 이후 새로 감지한 사진">
          {newPhotos.map((photo) => (
            <li key={photo.id}>
              <button type="button" data-testid="new-intake-photo" onClick={() => selectPhoto(photo.id)}>
                <strong>{photo.filename}</strong><span>{new Date(photo.timestamp).toLocaleString()}</span>
              </button>
            </li>
          ))}
        </ul>}
        {!!photos.length && <details open={expanded} className="intake-photo-bridge__gallery"
          onToggle={(event) => setExpanded(event.currentTarget.open)}>
          <summary data-testid="recent-photo-summary">최근 저장 파일 ({photos.length})</summary>
          <ul>
            {photos.map((photo) => {
              const linked = associations.find((association) => association.sourcePhotoId === photo.id);
              return (
                <li key={photo.id} className={linked ? 'intake-photo-bridge__linked' : undefined}>
                  <button type="button" data-testid="review-intake-photo" onClick={() => selectPhoto(photo.id)}>
                    <strong>{photo.filename}</strong>
                    <span>{new Date(photo.timestamp).toLocaleString()}</span>
                    {linked && <small>초안 의류 {linked.garmentId.split('-').at(-1)}번에 확인 연결됨</small>}
                  </button>
                </li>
              );
            })}
          </ul>
        </details>}

        {selectedPhoto && <div className="intake-photo-bridge__review" data-testid="intake-photo-review">
          <div className="intake-photo-bridge__photo-meta">
            <strong>{selectedPhoto.filename}</strong>
            <time dateTime={selectedPhoto.timestamp}>{new Date(selectedPhoto.timestamp).toLocaleString()}</time>
            <span>실제 원본 미리보기 · 아직 의류 연결 전</span>
          </div>
          {previewUrl ? <img data-testid="intake-photo-preview" src={previewUrl} alt={`${selectedPhoto.filename} 실제 촬영 사진 미리보기`} />
            : <p role={previewError ? 'alert' : 'status'}>{previewError || '인증된 사진 도우미에서 미리보기를 불러오는 중입니다.'}</p>}
          {photoAlreadyLinked ? <p role="status">{linkedDraftAssociation
            ? '이 사진은 이미 이 접수 초안의 다른 의류에 연결되어 있습니다.'
            : photoLinkedToSavedOrder ? '이 사진은 이미 저장된 다른 접수 의류에 연결되어 있습니다.'
              : photoReservedButUnlinked ? '이 사진은 이 접수에서 연결을 취소했거나 변경된 의류에 사용한 사진입니다. 다른 의류에 다시 연결할 수 없습니다.'
                : '이 사진은 이미 접수에서 사용되었습니다.'}</p>
            : <>
              <label className="intake-photo-bridge__target">
                <span>사진을 연결할 접수 세탁물</span>
                <select data-testid="select-intake-photo-target" value={selectedTarget}
                  onChange={(event) => { setSelectedTarget(event.target.value); setIdentityConfirmed(false); }}
                  disabled={!canImport || conflict || !targets.length}>
                  <option value="">세탁물을 선택해 주세요</option>
                  {targets.map((target) => <option key={target.garmentId} value={target.garmentId}
                    disabled={associations.some((item) => item.garmentId === target.garmentId)}>
                    {target.label}{associations.some((item) => item.garmentId === target.garmentId) ? ' · 사진 확인 연결됨' : ''}
                  </option>)}
                </select>
              </label>
              {targetAlreadyLinked && <p role="alert">선택한 세탁물에는 이미 확인된 사진이 있습니다.</p>}
              <label className="intake-photo-bridge__identity">
                <input data-testid="checkbox-intake-photo-identity" type="checkbox" checked={identityConfirmed}
                  onChange={(event) => {
                    setIdentityConfirmed(event.target.checked);
                    setIdentityConfirmationKey(event.target.checked ? currentReviewKey : '');
                  }}
                  disabled={!canImport || conflict || !previewUrl || !selectedTargetIsValid || targetAlreadyLinked || !!previewError} />
                미리보기에서 이 사진이 선택한 세탁물의 사진임을 직접 확인했습니다.
              </label>
              {!!identityConfirmed && !reviewConfirmedForCurrentContext &&
                <p role="alert">선택한 사진 또는 의류의 품목·수량이 변경되었습니다. 현재 미리보기에서 다시 확인해 주세요.</p>}
              {(!canImport || conflict) && <p role="alert">
                {conflict ? '다른 탭에서 접수가 변경됐습니다. 새로고침하여 현재 접수를 확인하세요.'
                  : '저장된 접수 건에는 초안 사진을 연결할 수 없습니다. 새 접수를 선택하거나 저장 주문의 검증된 촬영 화면을 이용해 주세요.'}
              </p>}
              <button type="button" data-testid="button-link-reviewed-photo" onClick={linkReviewedPhoto}
                disabled={!previewUrl || !identityConfirmed || !selectedTargetIsValid || !canImport || conflict ||
                  !reviewConfirmedForCurrentContext || !!targetAlreadyLinked || !!photoAlreadyLinked || !!previewError}>
                미리보기를 확인한 뒤 현재 접수에 사진 연결
              </button>
            </>}
        </div>}
      </section>

      {!!associations.length && <section aria-labelledby="intake-photo-linked-title">
        <h3 id="intake-photo-linked-title">현재 접수에서 확인한 사진</h3>
        <ul className="intake-photo-bridge__linked-list">
          {associations.map((item) => (
            <li key={item.garmentId} data-testid="linked-intake-photo">
              <span><strong>{item.filename}</strong><small>{targets.find((target) => target.garmentId === item.garmentId)?.label ?? '접수 의류'}</small></span>
              <button type="button" onClick={() => removeAssociation(item.garmentId)}
                disabled={conflict} aria-label={`${item.filename} 연결 취소`}>연결 취소</button>
            </li>
          ))}
        </ul>
      </section>}
      {conflict && <p role="alert" className="intake-photo-bridge__error">다른 탭에서 접수가 변경됐습니다. 사진 연결과 저장을 중지했습니다.</p>}
      {!targets.length && <p>사진을 연결하려면 접수 품목을 한 개 이상 입력하세요.</p>}
      </div>
      <details className="intake-photo-bridge__help"><summary>사진 연결 도움말</summary>
        <p>{connection}</p><p>{waitStatus}</p>
        {!configured && <p>관리용 연결 파일: {STORE_PHOTO_HELPER_FILENAME}</p>}
        {helperDownloadError && <p role="alert">{helperDownloadError}</p>}
      </details>
    </section>
  );
}