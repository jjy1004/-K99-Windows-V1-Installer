/** 촬영 엔진·장치 설정을 변경하지 않는 안내 전용 데이터. */
export const IRIUN_PLAY_URL = 'https://play.google.com/store/apps/details?id=com.jacksoftw.webcam';
export const IRIUN_OFFICIAL_URL = 'https://iriun.com';
export const IRIUN_WINDOWS_DOWNLOAD_URL = 'https://github.com/jjy1004/-K99-Windows-V1-Installer/releases/download/v2.4.30/IriunWebcam-2.9.9.exe';
export const USB_CAMERA_STANDARD = '※ 안정적인 무인 촬영을 위해 촬영용 휴대폰은 Wi-Fi를 끄고 반드시 USB 데이터 케이블로 PC 본체 뒷면에 직접 연결해 사용합니다.';
export const USB_CAMERA_STEPS = [
  {
    title: '숨겨진 개발자 옵션 열기',
    body: '휴대폰 설정 → 휴대전화 정보 → 소프트웨어 정보에서 [빌드번호]를 7번 연속 터치하세요. 휴대폰 잠금번호를 물으면 직접 입력하세요.',
    scene: 'buildNumber', bar: '소프트웨어 정보', rows: ['휴대전화 정보', '소프트웨어 정보', '빌드번호 · 7번 터치'], hit: 2,
  },
  {
    title: '개발자 옵션 필수 2가지 켜기',
    body: '설정 → 개발자 옵션에서 [USB 디버깅]과 [충전 중 화면 켜짐 유지]를 켜세요.',
    scene: 'usbDeveloper', bar: '개발자 옵션', rows: ['USB 디버깅 켜기', '충전 중 화면 켜짐 유지'], hit: 0,
  },
  {
    title: '기본 USB 구성 고정',
    body: '개발자 옵션 → 기본 USB 구성에서 [파일 전송 / Android Auto]를 선택하세요. 기종에 따라 연결 알림은 계속 표시될 수 있습니다.',
    scene: 'usbDefault', bar: '기본 USB 구성', rows: ['파일 전송 / Android Auto', 'USB 테더링', '충전만'], hit: 0,
  },
  {
    title: '화면 밝기 최소로 내리기',
    body: '휴대폰 상단 바를 내려 화면 밝기 막대를 맨 왼쪽(가장 어둡게)으로 낮추고 [절전 모드]를 끄세요.',
    scene: 'usbBrightness', bar: '빠른 설정', rows: ['화면 밝기 가장 어둡게', '절전 모드 끄기'], hit: 0,
  },
  {
    title: 'Iriun 앱 화면 어둡게 설정',
    body: '휴대폰에서 Iriun Webcam 앱을 여세요. 오른쪽 위 톱니바퀴(설정) → [Dim screen(화면 어둡게)]을 체크하세요. 버전에 따라 메뉴가 다르거나 없을 수 있으며, 밝기를 낮춰도 거치대 주변 통풍은 확보해 주세요.',
    scene: 'iriunDim', bar: 'Iriun 설정', rows: ['톱니바퀴 설정', 'Dim screen 켜기'], hit: 1,
  },
  {
    title: 'Wi-Fi 끄고 PC 본체 뒷면 USB 연결',
    body: '휴대폰 상단 바에서 Wi-Fi(와이파이)를 끄세요. 데이터 전송용 USB 케이블을 PC 본체 뒷면(메인보드) USB 단자에 직접 꽂으세요. 우리 매장 PC가 맞을 때만 [이 컴퓨터에서 항상 허용] 체크 → [허용]을 누르세요. 충전 전용 케이블·USB 허브는 피하세요.',
    scene: 'usbDirect', bar: 'USB 직접 연결', rows: ['Wi-Fi 끄기', '본체 뒷면 USB 직접 연결', '이 컴퓨터에서 항상 허용'], hit: 1,
  },
  {
    title: '매일 영업 시작 사용법',
    body: 'PC는 부팅 시 기존 설정대로 자동 준비됩니다. 매일 아침 매장 문을 열 때 촬영용 휴대폰에서 [Iriun Webcam] 앱 아이콘만 한 번 터치하세요. PC 촬영창을 열면 자동 연결을 시도하고 신호가 잠시 끊겨도 기존 자동 복구가 동작합니다.',
    scene: 'iriun', bar: '매일 아침', rows: ['Iriun Webcam 앱 한 번 터치'], hit: 0,
  },
] as const;
