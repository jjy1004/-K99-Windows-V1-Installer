import { useState } from 'react';
import { requiredIntakeIdentity } from './customer-input';
import { ImeTextInput } from './ImeTextInput';

export type CustomerIdentity = { customerName: string; customerPhone: string; customerAddress: string };
export default function CustomerIdentityEditor({ value, onSave }: {
  value: CustomerIdentity; onSave: (value: CustomerIdentity) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [error, setError] = useState('');
  return <section className="final-intake__panel">
    <button type="button" onClick={() => { setDraft(value); setEditing(true); setError(''); }}>고객정보 수정</button>
    {editing && <div>
      {([['customerName', '고객 이름'], ['customerPhone', '전화번호'], ['customerAddress', '주소']] as const).map(([key, label]) =>
        <label key={key} style={{ display: 'block', margin: '12px 0' }}>{label}
          {key === 'customerPhone'
            ? <input aria-label={`수정 ${label}`} value={draft[key]} type="tel"
              onChange={e => { const text = e.target.value; setDraft(previous => ({ ...previous, [key]: text })); }} />
            : <ImeTextInput koreanFirst aria-label={`수정 ${label}`} value={draft[key]}
              onValue={text => setDraft(previous => ({ ...previous, [key]: text }))} />}</label>)}
      <button type="button" onClick={() => {
        try {
          if (!requiredIntakeIdentity(draft.customerName, draft.customerPhone)) throw new Error('고객명과 유효한 휴대전화번호를 확인하세요.');
          onSave({ customerName: draft.customerName.trim(), customerPhone: draft.customerPhone.trim(), customerAddress: draft.customerAddress.trim() });
          setEditing(false);
        } catch (e) { setError(e instanceof Error ? e.message : '고객정보 저장 실패'); }
      }}>고객정보 저장</button>
      <button type="button" onClick={() => setEditing(false)}>취소</button>
      {error && <p role="alert">{error}</p>}
    </div>}
  </section>;
}
