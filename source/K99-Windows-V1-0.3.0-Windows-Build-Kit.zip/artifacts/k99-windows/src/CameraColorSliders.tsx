import type {CameraColorProfile} from './camera-color';
export function CameraColorSliders({profile,onChange}:{profile:CameraColorProfile;onChange:(p:CameraColorProfile)=>void}){
  return <div style={{display:'flex',gap:20,flexWrap:'wrap',padding:'8px 0',fontSize:18}} aria-label="소프트웨어 색감 미세 조정">
    <label>밝기 {profile.brightnessAdjustment||0}%
      <input type="range" min={-30} max={30} step={1} value={profile.brightnessAdjustment||0}
        aria-label="밝기 보정" onChange={e=>onChange({...profile,brightnessAdjustment:Number(e.target.value)})}/></label>
    <label>색온도 {profile.temperatureAdjustment||0} · 차갑게 ↔ 따뜻하게
      <input type="range" min={-50} max={50} step={1} value={profile.temperatureAdjustment||0}
        aria-label="색온도 보정" onChange={e=>onChange({...profile,temperatureAdjustment:Number(e.target.value)})}/></label>
    <label>대비 {profile.contrastAdjustment||0}%
      <input type="range" min={-30} max={30} step={1} value={profile.contrastAdjustment||0}
        aria-label="대비 보정" onChange={e=>onChange({...profile,contrastAdjustment:Number(e.target.value)})}/></label>
  </div>;
}
