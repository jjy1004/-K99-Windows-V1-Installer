import {Contrast,Focus,Minus,Monitor,Palette,Plus,RotateCcw,SlidersHorizontal,Sun,Thermometer} from 'lucide-react';
import {CAMERA_RESOLUTIONS,type CameraColorProfile,type CameraResolution} from './camera-color';
import './camera-manual.css';
const controls=[
  {key:'brightness',label:'밝기',Icon:Sun,min:-50,max:50},
  {key:'contrast',label:'명암 / 대비',Icon:Contrast,min:-50,max:50},
  {key:'temperature',label:'색온도 / 화이트밸런스',Icon:Thermometer,min:-50,max:50},
  {key:'saturation',label:'채도',Icon:Palette,min:-50,max:50},
  {key:'sharpness',label:'선명도',Icon:Focus,min:0,max:100},
] as const;
export function CameraColorSliders({profile,onChange,onReset,onResolution,note,changing,dimensions}:{
  profile:CameraColorProfile;onChange:(p:CameraColorProfile)=>void;onReset:()=>void;
  onResolution:(r:CameraResolution)=>void;note:string;changing:boolean;dimensions:string;
}){
  return <section className="camera-manual" aria-label="카메라 수동 화질 설정" data-testid="camera-manual-controls">
    <header><strong><SlidersHorizontal aria-hidden="true"/>수동 화질 맞춤</strong>
      <button type="button" onClick={onReset} disabled={changing} data-testid="camera-standard-reset"><RotateCcw aria-hidden="true"/>표준(기본) 복원</button></header>
    <p>표준은 원본 색감입니다. 자동 보정 없이 직접 맞추며, 조절값은 다음 실행에도 유지됩니다.</p>
    <details open><summary>해상도 · 밝기 · 색감 · 선명도 조절</summary>
      <div className="camera-manual__resolution"><strong><Monitor aria-hidden="true"/>해상도</strong>
        <div>{Object.entries(CAMERA_RESOLUTIONS).map(([name,size])=><button key={name} type="button"
          disabled={changing} aria-pressed={profile.resolution===name} onClick={()=>onResolution(name as CameraResolution)}>
          {name}<small>{size[0]}×{size[1]}</small></button>)}</div>
        <small>현재 영상 {dimensions||'연결 대기'} · 지원하지 않으면 기존 정상 화면을 유지합니다.</small>
      </div>
      <div className="camera-manual__grid">{controls.map(({key,label,Icon,min,max})=>{
        const value=profile[key],set=(n:number)=>onChange({...profile,[key]:Math.max(min,Math.min(max,n))});
        return <label key={key}><span><Icon aria-hidden="true"/>{label}<output>{value>0?'+':''}{value}</output></span>
          <div><button type="button" aria-label={`${label} 줄이기`} onClick={()=>set(value-1)}><Minus aria-hidden="true"/></button>
            <input type="range" aria-label={label} min={min} max={max} step={1} value={value} onChange={e=>set(Number(e.target.value))}/>
            <button type="button" aria-label={`${label} 늘리기`} onClick={()=>set(value+1)}><Plus aria-hidden="true"/></button></div>
        </label>;
      })}</div>
    </details>
    {note&&<p role="status">{note}</p>}
  </section>;
}
