import {Contrast,Focus,Minus,Monitor,Palette,Plus,RotateCcw,SlidersHorizontal,Sun,Thermometer,Sparkles,Camera,Zap} from 'lucide-react';
import {CAMERA_RESOLUTIONS,type CameraColorProfile,type CameraResolution} from './camera-color';
import type {useCameraHardware} from './use-camera-hardware';
import './camera-manual.css';
const controls=[
  {key:'brightness',label:'밝기',Icon:Sun,min:-50,max:50},
  {key:'contrast',label:'명암 / 대비',Icon:Contrast,min:-50,max:50},
  {key:'temperature',label:'색온도 / 화이트밸런스',Icon:Thermometer,min:-50,max:50},
  {key:'saturation',label:'채도',Icon:Palette,min:-50,max:50},
  {key:'sharpness',label:'선명도',Icon:Focus,min:0,max:100},
] as const;
export function CameraColorSliders({profile,onChange,onReset,onResolution,note,changing,dimensions,hardware,onNatural,calibrating}:{
  profile:CameraColorProfile;onChange:(p:CameraColorProfile)=>void;onReset:()=>void;
  onResolution:(r:CameraResolution)=>void;note:string;changing:boolean;dimensions:string;
  hardware:ReturnType<typeof useCameraHardware>;onNatural:()=>void;calibrating:boolean;
}){
  return <section className="camera-manual" aria-label="카메라 수동 화질 설정" data-testid="camera-manual-controls">
    <header><strong><SlidersHorizontal aria-hidden="true"/>수동 화질 맞춤</strong>
      <button type="button" onClick={onReset} disabled={changing} data-testid="camera-standard-reset"><RotateCcw aria-hidden="true"/>표준(기본) 복원</button></header>
    <button className="camera-manual__natural" type="button" onClick={onNatural}
      disabled={calibrating||changing||hardware.busy} data-testid="camera-natural-calibrate">
      <Sparkles aria-hidden="true"/>{calibrating?'흰 배경·노출 확인 중…':'실제 원본 색감 자동 맞춤'}
    </button>
    <p>흰 바탕이 화면 상·하·좌·우에 충분히 보이게 놓고 눌러 주세요. 자동 맞춤 중에도 촬영할 수 있습니다. 표준 복원은 소프트웨어 보정을 해제합니다.</p>
    <div className="camera-manual__sensor-status" role="status">
      노출: {hardware.state?.modes.exposureMode==='continuous'?'자동':hardware.state?.modes.exposureMode==='manual'?'수동':'장치 확인 불가'}
      {' · '}화이트밸런스: {hardware.state?.modes.whiteBalanceMode==='continuous'?'자동':'지원/적용 확인 필요'}
      {' · '}초점: {hardware.state?.modes.focusMode==='continuous'?'자동':'수동 CS 렌즈는 렌즈 링으로 조절'}
      <br/>수동 CS 렌즈의 광학 초점은 자동 설정 지원 여부와 관계없이 렌즈 링으로 직접 맞춰 주세요.
    </div>
    <div className="camera-manual__grid">
      {([{key:'exposureTime',label:'센서 노출 시간',Icon:Camera},{key:'gain',label:'센서 게인',Icon:Zap},
        ...(hardware.state?.controls.iso?[{key:'iso' as const,label:'감도 ISO (게인과 별도)',Icon:Sun}]:[])] as const).map(({key,label,Icon})=>{
        const range=hardware.state?.controls[key],disabled=!range?.enabled||hardware.busy;
        const min=range?.min??0,max=range?.max??100,step=range?.step??1,value=range?.value??0;
        const set=(v:number)=>hardware.onValue(key,Math.max(min,Math.min(max,v)));
        return <label key={key}><span><Icon aria-hidden="true"/>{label}
          <output>{range?Number(value.toFixed(4)):'미지원'}</output></span>
          <div><button type="button" disabled={disabled} aria-label={`${label} 줄이기`} onClick={()=>set(value-step)}><Minus aria-hidden="true"/></button>
            <input type="range" aria-label={label} min={min} max={max} step={step} value={value} disabled={disabled}
              onChange={e=>set(Number(e.target.value))}/>
            <button type="button" disabled={disabled} aria-label={`${label} 늘리기`} onClick={()=>set(value+step)}><Plus aria-hidden="true"/></button></div>
          <small>{range?.reason||(!range?'이 장치·드라이버가 브라우저에 해당 하드웨어 제어를 제공하지 않습니다.':'장치 보고값 기준 · 조절 시 수동 노출로 전환하며, 실제 적용값 확인 후 저장합니다.')}</small>
        </label>;
      })}
    </div>
    <details open><summary>해상도 · 밝기 · 색감 · 선명도 조절</summary>
      <div className="camera-manual__resolution"><strong><Monitor aria-hidden="true"/>해상도</strong>
        <div>{Object.entries(CAMERA_RESOLUTIONS).map(([name,size])=><button key={name} type="button"
          disabled={changing} aria-pressed={profile.resolution===name} onClick={()=>onResolution(name as CameraResolution)}>
          {name}<small>{size[0]}×{size[1]}</small></button>)}</div>
        <small>현재 영상 {dimensions||'연결 대기'} · 지원하지 않으면 기존 정상 화면을 유지합니다.</small>
      </div>
      <div className="camera-manual__grid">{controls.map(({key,label,Icon,min,max})=>{
        const value=profile[key],set=(n:number)=>onChange({...profile,[key]:Math.max(min,Math.min(max,n))});
        return <label key={key}><span><Icon aria-hidden="true"/>{label}<output>{value>0?'+':''}{value}</output></span>
          <div><button type="button" aria-label={`${label} 줄이기`} onClick={()=>set(value-1)}><Minus aria-hidden="true"/></button>
            <input type="range" aria-label={label} min={min} max={max} step={1} value={value} onChange={e=>set(Number(e.target.value))}/>
            <button type="button" aria-label={`${label} 늘리기`} onClick={()=>set(value+1)}><Plus aria-hidden="true"/></button></div>
        </label>;
      })}</div>
    </details>
    {note&&<p role="status">{note}</p>}
  </section>;
}
