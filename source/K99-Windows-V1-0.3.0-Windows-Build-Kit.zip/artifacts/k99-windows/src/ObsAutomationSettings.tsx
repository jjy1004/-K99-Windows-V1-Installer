import {useEffect,useState} from 'react';
export function ObsAutomationSettings(){
  const [message,setMessage]=useState(''),[busy,setBusy]=useState(false);
  useEffect(()=>{void window.k99Desktop?.obsAutomation?.('status').then(r=>setMessage(r.note))
    .catch(()=>setMessage('OBS 자동 실행 상태를 확인하지 못했습니다.'));},[]);
  async function apply(action:'enable'|'disable'){
    setBusy(true);
    try{const result=await window.k99Desktop?.obsAutomation?.(action);
      setMessage(result?.note||'Windows 설치 앱에서 사용할 수 있습니다.');
    }catch(error){setMessage(error instanceof Error?error.message:'OBS 설정 적용 실패');}
    finally{setBusy(false);}
  }
  return <section className="eq-card" data-testid="obs-automation-settings">
    <h2>USB 웹캠 직접 연결</h2>
    <p>OBS 설치·자동 실행 없이 USB 웹캠으로 미리보기와 촬영을 사용합니다. 이전 K99 자동 등록은 앱 시작 시 해제합니다.</p>
    <button className="eq-btn" type="button" disabled={busy||!window.k99Desktop?.obsAutomation} onClick={()=>void apply('disable')}>
      이전 OBS 자동 실행 등록 해제</button>
    <p role="status">{message}</p>
    <small>OBS가 USB 카메라를 점유하면 직접 연결이 안 될 수 있습니다. 이미 실행 중인 OBS는 이 버튼으로 강제 종료하지 않습니다.</small>
  </section>;
}
