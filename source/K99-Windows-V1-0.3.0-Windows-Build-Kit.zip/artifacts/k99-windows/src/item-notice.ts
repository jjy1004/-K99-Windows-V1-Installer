import { buildTechnicalFeeMessage, usesTechnicalFeeTemplate } from './technical-fee-notice.ts';
import type { ConfirmedOrder } from './order-record';
import type { InspectionDraft, InspectionRecord, OrderHistoryEvent } from './inspection-record';
import { actualCleaningMethodChanged, careLabelConflict, inspectionApprovalRequirements, originalCleaningMethod, originalMethod } from './inspection-record.ts';
import { describedRisks, inspectionItemExplanation } from './inspection-message-wording.ts';
import { guidanceMessage } from './inspection-guidance.ts';

export type NoticeStage = 1 | 2 | 3;
export type NoticeStep = {
  message: string;
  reviewedAt?: string;
  reviewedBy?: string;
  readyAt?: string;
  readyBy?: string;
  response?: { choice: string; content: string; respondedAt: string; confirmedAt: string; staffName: string; message: string };
};
export type ItemNotice = {
  itemIndexes: number[];
  activeStep: NoticeStage | null;
  outcome: 'informational' | 'in-progress' | 'approved' | 'held';
  riskConsent: boolean;
  waiverConsent: boolean;
  priceConsent: boolean;
  steps: Partial<Record<NoticeStage, NoticeStep>>;
};

const won = (amount: number) => `${amount.toLocaleString('ko-KR')}원`;
const works = (inspection: InspectionRecord, index: number) =>
  inspection.items[index].additionalWork.filter((work) => work !== '추가 작업 없음');
const waiverScope = (inspection: InspectionRecord, order: ConfirmedOrder, indexes: number[]) =>
  inspection.waiverNotice?.trim() || indexes.filter((index) =>
    careLabelConflict(inspection.items[index]) || inspection.items[index].riskFactors?.length
    || inspection.items[index].riskDetails?.trim()).map((index) => {
    const item = inspection.items[index];
    const detail = item.riskDetails?.trim();
    const scope = /염색약.*제거 불가/.test(detail ?? '')
      ? '염색약 얼룩이 완전히 제거되지 않을 수 있는 점'
      : detail || `${describedRisks(item).join('·') || inspection.riskNotice} 가능성`;
    return `${order.items[index].displayNameKo}의 ${scope}`;
  }).join('; ');

export function itemNoticeIndexes(inspection: InspectionRecord): number[] {
  const triggers = inspection.items.flatMap((item, index) =>
    item.riskFactors?.length || works(inspection, index).length || careLabelConflict(item)
      || (item.plannedCleaningMethod && item.actualCleaningMethod
        && item.actualCleaningMethod !== item.plannedCleaningMethod) ? [index] : []);
  if (!triggers.length) return [];
  return inspection.items.flatMap((item, index) => triggers.includes(index)
    || careLabelConflict(item)
    || (item.method !== '기존 방법 유지'
      && (item.method === '기타' ? item.customMethod : item.method) !== inspection.originalMethods[index])
    || (!!item.plannedCleaningMethod && !!item.actualCleaningMethod
      && item.actualCleaningMethod !== item.plannedCleaningMethod)
    ? [index] : []);
}

function details(order: ConfirmedOrder, inspection: InspectionRecord, indexes: number[]) {
  return indexes.map((index) => ({
    index, name: order.items[index].displayNameKo, item: inspection.items[index],
    selectedWork: works(inspection, index),
  }));
}

export function technicalFeeItemName(order: ConfirmedOrder, inspection: Pick<InspectionRecord, 'feeItemName'>, indexes: number[]): string {
  return inspection.feeItemName?.trim()
    || indexes.map((index) => order.items[index]?.displayNameKo).filter(Boolean).join('·')
    || order.items.map((item) => item.displayNameKo).join('·');
}

export function technicalFeeStageOneMessage(order: ConfirmedOrder,
  inspection: Pick<InspectionRecord, 'feeItemName' | 'additionalCharge' | 'riskRequired' | 'riskNotice'>, indexes: number[]): string {
  return buildTechnicalFeeMessage({
    itemName: technicalFeeItemName(order, inspection, indexes), fee: inspection.additionalCharge ?? 0,
    riskRequired: inspection.riskRequired, risk: inspection.riskNotice,
  });
}

export function generateItemNotice(order: ConfirmedOrder, inspection: InspectionRecord, step: NoticeStage): string {
  const notice = inspection.itemNotice!;
  const affected = details(order, inspection, notice.itemIndexes);
  const header = '[K99 품격세탁소]';
  if (step === 1 && inspection.guidanceKind) return guidanceMessage(order, inspection, notice.itemIndexes);
  if (step === 1 && notice.outcome !== 'informational' && usesTechnicalFeeTemplate(inspection.additionalCharge))
    return technicalFeeStageOneMessage(order, inspection, notice.itemIndexes);
  if (step === 1) {
    const explanations = affected.flatMap(({ index, name, item }) =>
      inspectionItemExplanation({
        name, item, originalService: inspection.originalMethods[index],
        conflict: careLabelConflict(item),
        actualMethodChanged: actualCleaningMethodChanged(order, inspection, index),
        riskNotice: affected.length === 1 ? inspection.riskNotice : '',
      }));
    const greeting = order.customerName.endsWith('고객') ? `${order.customerName}님` : `${order.customerName} 고객님`;
    if (notice.outcome === 'informational') return [
      header, `${greeting}, 맡겨주신 세탁물을 전문 검수했습니다.`,
      ...affected.map(({ name, item }) =>
        `${name}에서 ${describedRisks(item).join('·') || item.riskDetails?.trim() || '주의할 상태'}를 확인했습니다.`),
      '확인된 상태를 고려해 주의하여 세탁하겠습니다.',
    ].join('\n');
    const hasWork = affected.some(({ selectedWork }) => selectedWork.length);
    const hasMethodChange = affected.some(({ index, item }) => careLabelConflict(item)
      || actualCleaningMethodChanged(order, inspection, index)
      || (item.method !== '기존 방법 유지'
        && (item.method === '기타' ? item.customMethod : item.method) !== inspection.originalMethods[index]));
    const conflict = affected.some(({ item }) => careLabelConflict(item));
    const names = affected.map(({ name }) => name).join('·');
    return [header, `${greeting}, 맡겨주신 ${names}의 전문 검수 결과를 안내드립니다.`,
      ...explanations,
      hasWork || hasMethodChange ? '안내드린 방법과 작업으로 진행해 드릴까요?'
        : '검수 내용을 확인하고 세탁을 진행해 드릴까요?',
      '① 네, 진행해주세요.',
      conflict ? '② 아니요, 케어라벨 기준 세탁을 원합니다.' : '② 아니요, 진행하지 않을게요.',
      '③ 상담 후 결정하겠습니다.',
      '감사합니다. K99 품격세탁소'].join('\n');
  }
  if (step === 2) return [
    header, `${order.customerName} 고객님, 선택하신 작업의 위험을 안내드립니다.`,
    ...affected.map(({ name, item }) => {
      const risks = describedRisks(item);
      const detail = item.riskDetails?.trim();
      const warning = risks.length ? `${risks.join('·')} 가능성이 있습니다.`
        : /염색약.*제거 불가/.test(detail ?? '')
          ? '염색약 얼룩은 완전히 제거하기 어려워 일부 흔적이 남을 수 있습니다.'
          : detail ? `${detail.replace(/[.!?]$/, '')}.`
            : `${inspection.riskNotice || inspection.waiverNotice} 가능성이 있습니다.`;
      return `${name}: ${warning}${careLabelConflict(item)
        ? ` 케어라벨(${item.careLabelMethod})과 다른 ${item.actualCleaningMethod}으로 작업합니다.` : ''}`;
    }),
    ...(notice.waiverConsent ? [`면책 동의 범위: ${waiverScope(inspection, order, notice.itemIndexes)}`] : []),
    '세심히 작업하겠습니다. 안내한 위험에 동의하시겠습니까?',
    '① 동의합니다  ② 동의하지 않습니다',
  ].join('\n');
  const charge = inspection.additionalCharge ?? 0;
  return [
    header, `${order.customerName} 고객님, 확인해 주셔서 감사합니다. ${affected.map(({ name }) => name).join('·')} 작업 안내입니다.`,
    `추가 작업비 ${won(charge)}`,
    `기존 ${won(inspection.originalPrice)} → 최종 예상금액 ${won(inspection.revisedPrice)}입니다.`,
    '금액을 확인하고 진행할까요?', '① 동의합니다  ② 진행하지 않습니다',
  ].join('\n');
}

export function createItemNotice(order: ConfirmedOrder, inspection: InspectionRecord): ItemNotice | undefined {
  const triggered = itemNoticeIndexes(inspection);
  const itemIndexes = inspection.guidanceKind && !triggered.length ? inspection.items.map((_, i) => i) : triggered;
  if (!itemIndexes.length) return undefined;
  const hasWork = itemIndexes.some((index) => works(inspection, index).length);
  const changedService = itemIndexes.some((index) => {
    const item = inspection.items[index];
    return item.method !== '기존 방법 유지'
      && (item.method === '기타' ? item.customMethod : item.method) !== inspection.originalMethods[index];
  });
  const riskConsent = !!(inspection.waiverRequired || inspection.riskRequired
    || itemIndexes.some((index) => careLabelConflict(inspection.items[index]) || actualCleaningMethodChanged(order, inspection, index)));
  const waiverConsent = !!inspection.waiverRequired
    || itemIndexes.some((index) => careLabelConflict(inspection.items[index]));
  const priceConsent = inspection.revisedPrice !== inspection.originalPrice;
  const informational = !hasWork && !changedService && !riskConsent && !priceConsent;
  const notice: ItemNotice = {
    itemIndexes, activeStep: informational ? null : 1,
    outcome: informational ? 'informational' : 'in-progress',
    riskConsent, waiverConsent, priceConsent, steps: {},
  };
  notice.steps[1] = { message: generateItemNotice(order, { ...inspection, itemNotice: notice }, 1) };
  return notice;
}

// Preview the same first-stage trigger while the inspection form is still unsaved.
// A draft is not an approval record; final review and send preparation are recorded after completion.
export function previewItemNotice(order: ConfirmedOrder, draft: InspectionDraft): ItemNotice | undefined {
  const inspection: InspectionRecord = {
    ...draft,
    items: draft.items.map((item, index) => ({
      ...item, plannedCleaningMethod: originalCleaningMethod(order, draft, index),
    })),
    originalMethods: order.items.map((item) => originalMethod(order, item)),
    originalPrice: order.estimatedTotal,
    priceDifference: draft.revisedPrice - order.estimatedTotal,
    inspectedAt: '', needsApproval: false, customerMessage: '',
    // A revised estimate alone is not an entered additional-work charge.
    revisedPrice: (draft.additionalCharge ?? 0) > 0 ? draft.revisedPrice : order.estimatedTotal,
  };
  const itemNotice = createItemNotice(order, inspection);
  if (itemNotice) return itemNotice;
  const requirements = inspectionApprovalRequirements(order, draft);
  if (!Object.values(requirements).some(Boolean)) return undefined;
  const changedIndexes = draft.items.flatMap((item, index) =>
    (item.method !== '기존 방법 유지'
      && (item.method === '기타' ? item.customMethod : item.method) !== inspection.originalMethods[index])
    || actualCleaningMethodChanged(order, draft, index) ? [index] : []);
  const itemIndexes = changedIndexes.length ? changedIndexes : draft.items.map((_, index) => index);
  const itemNames = itemIndexes.map((index) => order.items[index].displayNameKo).join('·');
  const message = usesTechnicalFeeTemplate(draft.additionalCharge)
    ? technicalFeeStageOneMessage(order, draft, itemIndexes)
    : changedIndexes.length
    ? `[K99 품격세탁소]\n${changedIndexes.map((index) => {
      const item = draft.items[index];
      const proposed = item.actualCleaningMethod && actualCleaningMethodChanged(order, draft, index)
        ? item.actualCleaningMethod : item.method === '기타' ? item.customMethod : item.method;
      return `${order.items[index].displayNameKo}의 세탁방법을 ${proposed}으로 변경할 필요가 있습니다.`;
    }).join('\n')}\n안내한 방법으로 진행할까요?`
    : requirements.price || requirements.otherPriceChange
      ? `[K99 품격세탁소]\n${order.customerName} 고객님, ${itemNames}의 검수 후 예상금액은 기존 ${won(order.estimatedTotal)}에서 ${won(draft.revisedPrice)}으로 변경됩니다.\n이 금액으로 진행할까요?`
      : `[K99 품격세탁소]\n${order.customerName} 고객님, ${itemNames}의 검수 중 추가 안내가 필요한 위험을 확인했습니다. ${draft.riskNotice.trim()}\n내용을 확인하고 진행할까요?`;
  return {
    itemIndexes, activeStep: 1, outcome: 'in-progress',
    riskConsent: requirements.risk || requirements.waiver,
    waiverConsent: !!draft.waiverRequired,
    priceConsent: (draft.additionalCharge ?? 0) > 0,
    steps: { 1: { message } },
  };
}

export function noticeResponses(notice: ItemNotice, step: NoticeStage): string[] {
  if (step === 1) return ['진행 동의', '진행 거절', '문의/보류', '직접 입력'];
  if (step === 2) return notice.waiverConsent
    ? ['면책 동의', '면책 거절', '문의/보류', '직접 입력']
    : ['위험 확인 및 진행 동의', '진행 거절', '문의/보류', '직접 입력'];
  return ['추가금액 동의', '추가금액 거절', '문의/보류', '직접 입력'];
}

function requireActive(order: ConfirmedOrder, step: NoticeStage): { inspection: InspectionRecord; notice: ItemNotice; current: NoticeStep } {
  const inspection = order.inspection;
  const notice = inspection?.itemNotice;
  const current = notice?.steps[step];
  if (!inspection || !notice || notice.activeStep !== step || notice.outcome !== 'in-progress'
    || order.status !== '고객 회신 대기' || !current)
    throw new Error('앞 단계의 고객 확인 전에는 다음 안내를 열 수 없습니다.');
  return { inspection, notice, current };
}

function validateMessage(order: ConfirmedOrder, inspection: InspectionRecord, notice: ItemNotice, step: NoticeStage, message: string) {
  if (step === 1 && inspection.guidanceKind) {
    const names = inspection.feeItemName?.trim() ? [inspection.feeItemName.trim()]
      : notice.itemIndexes.map(i => order.items[i].displayNameKo);
    if (names.some(name => !message.includes(name))) throw new Error('안내 문안에 대상 품목명을 포함하세요.');
    if (inspection.guidanceKind !== 'waiver' && (![inspection.additionalCharge ?? 0, inspection.revisedPrice]
      .every(amount => message.includes(`${amount.toLocaleString('ko-KR')}원`))))
      throw new Error('안내 문안에 추가 기술료와 최종 금액을 포함하세요.');
    return;
  }
  if (step === 1 && notice.outcome !== 'informational' && usesTechnicalFeeTemplate(inspection.additionalCharge)) {
    if (!message.includes(technicalFeeItemName(order, inspection, notice.itemIndexes)))
      throw new Error('1단계 문안에 대상 품목(세탁물명)을 포함해 주세요.');
    if (!message.includes(`${(inspection.additionalCharge ?? 0).toLocaleString('ko-KR')}원`))
      throw new Error('1단계 문안에 입력한 추가 기술료를 포함해 주세요.');
    return;
  }
  for (const { index, name, item, selectedWork } of details(order, inspection, notice.itemIndexes)) {
    if (!message.includes(name)) throw new Error('안내 문안에 대상 품목을 포함해 주세요.');
    if (step === 1 && (!selectedWork.every((work) => message.includes(work))
      || (careLabelConflict(item) && (!message.includes('케어라벨') || !message.includes(item.actualCleaningMethod!)))
      || (item.plannedCleaningMethod && item.actualCleaningMethod !== item.plannedCleaningMethod
        && !message.includes(item.actualCleaningMethod!))
      || (item.method !== '기존 방법 유지'
        && (item.method === '기타' ? item.customMethod : item.method) !== inspection.originalMethods[index]
        && !message.includes(item.method === '기타' ? item.customMethod : item.method))
      || (notice.outcome === 'informational' && !item.riskFactors?.every((risk) => message.includes(risk)))))
      throw new Error('1단계 문안에 추가 작업과 케어라벨과 다른 세탁방법을 포함해 주세요.');
    if (step === 2 && (!describedRisks(item).every((risk) => message.includes(risk))
      || (careLabelConflict(item) && !message.includes(item.actualCleaningMethod!))))
      throw new Error('2단계 문안에 확인된 위험과 변경된 방법을 포함해 주세요.');
  }
  if (step === 2 && notice.waiverConsent && !message.includes(waiverScope(inspection, order, notice.itemIndexes)))
    throw new Error('2단계 문안에 면책 범위를 포함해 주세요.');
  if (step === 3 && (!message.includes(won(inspection.originalPrice)) || !message.includes(won(inspection.revisedPrice))
    || ((inspection.additionalCharge ?? 0) > 0 && !message.includes(won(inspection.additionalCharge!)))))
    throw new Error('3단계 문안에 실제 기존 금액·추가요금·최종 예상금액을 포함해 주세요.');
}

export function updateItemNotice(order: ConfirmedOrder, step: NoticeStage, action: 'generate' | 'edit' | 'review' | 'ready',
  message: string, staffName: string, at = new Date()): ConfirmedOrder {
  const inspection = order.inspection!;
  const notice = inspection.itemNotice!;
  if (!notice) throw new Error('안내 대상 검수가 아닙니다.');
  const informational = notice.outcome === 'informational' && step === 1;
  const current = informational ? notice.steps[1] : requireActive(order, step).current;
  if (!current) throw new Error('현재 단계의 안내 문안이 없습니다.');
  if (action === 'review' || action === 'ready') {
    if (!staffName.trim()) throw new Error('확인 직원을 입력해 주세요.');
  }
  const next = action === 'generate' ? generateItemNotice(order, inspection, step) : message.trim();
  if (!next) throw new Error('고객 안내 문안을 입력해 주세요.');
  validateMessage(order, inspection, notice, step, next);
  if (action === 'ready' && (!current.reviewedAt || current.message !== next))
    throw new Error('현재 문안을 직원이 먼저 확인해 주세요.');
  const timestamp = at.toISOString();
  const updated: NoticeStep = { ...current, message: next,
    ...(action === 'generate' || action === 'edit'
      ? { reviewedAt: undefined, reviewedBy: undefined, readyAt: undefined, readyBy: undefined } : {}),
    ...(action === 'review' ? { reviewedAt: timestamp, reviewedBy: staffName.trim(), readyAt: undefined, readyBy: undefined } : {}),
    ...(action === 'ready' ? { readyAt: timestamp, readyBy: staffName.trim() } : {}),
  };
  return { ...order, inspection: { ...inspection,
    ...(step === 1 ? { customerMessage: next, shortCustomerMessage: next } : {}),
    itemNotice: { ...notice, steps: { ...notice.steps, [step]: updated } } },
    history: [...(order.history ?? []), { at: timestamp, kind: action === 'generate' || action === 'edit' ? 'item-notice-draft'
      : action === 'review' ? 'item-notice-review' : 'item-notice-prepared',
    details: { stage: step, message: next, staffName: staffName.trim(), actuallySent: false } }] };
}

export function recordItemNoticeResponse(order: ConfirmedOrder, step: NoticeStage, choice: string,
  content: string, staffName: string, respondedAt?: string, at = new Date()): ConfirmedOrder {
  const { inspection, notice, current } = requireActive(order, step);
  if (!current.reviewedAt || !current.readyAt) throw new Error('직원 확인과 발송 준비를 먼저 기록해 주세요.');
  if (!staffName.trim()) throw new Error('회신 확인 직원을 입력해 주세요.');
  if (!noticeResponses(notice, step).includes(choice)) throw new Error('현재 단계에 맞는 회신을 선택해 주세요.');
  if (choice === '직접 입력' && !content.trim()) throw new Error('직접 입력한 고객 회신 내용을 기록해 주세요.');
  if (respondedAt && !Number.isFinite(Date.parse(respondedAt))) throw new Error('고객 회신 일시를 확인해 주세요.');
  const timestamp = at.toISOString();
  const response = { choice, content: content.trim(), respondedAt: respondedAt
    ? new Date(respondedAt).toISOString() : timestamp, confirmedAt: timestamp,
  staffName: staffName.trim(), message: current.message };
  const steps: ItemNotice['steps'] = { ...notice.steps, [step]: { ...current, response } };
  const positive = step === 1 ? choice === '진행 동의'
    : step === 2 ? choice === (notice.waiverConsent ? '면책 동의' : '위험 확인 및 진행 동의')
      : choice === '추가금액 동의';
  const next: NoticeStage | null = !positive ? null : step === 1
    ? notice.riskConsent ? 2 : notice.priceConsent ? 3 : null
    : step === 2 && notice.priceConsent ? 3 : null;
  const outcome = positive ? next ? 'in-progress' : 'approved' : 'held';
  const status: ConfirmedOrder['status'] = outcome === 'approved' ? '세탁 진행 승인'
    : outcome === 'held' ? '보류' : '고객 회신 대기';
  const history: OrderHistoryEvent[] = [...(order.history ?? []),
    { at: timestamp, kind: 'item-notice-response', details: { stage: step, ...response } }];
  if (next) {
    const nextMessage = generateItemNotice(order, inspection, next);
    steps[next] = { message: nextMessage };
    history.push({ at: timestamp, kind: 'item-notice-draft',
      details: { stage: next, message: nextMessage, actuallySent: false } });
  }
  if (outcome !== 'in-progress') history.push({ at: timestamp, kind: 'approval-status',
    details: { status, outcome, staffName: response.staffName, cleaningAllowed: outcome === 'approved' } });
  return { ...order, status, inspection: { ...inspection,
    itemNotice: { ...notice, activeStep: next, outcome, steps } }, history };
}