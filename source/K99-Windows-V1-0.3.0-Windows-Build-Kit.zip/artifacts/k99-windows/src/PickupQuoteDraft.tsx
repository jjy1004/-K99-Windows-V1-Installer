import {useEffect,useState} from 'react';
import {noticeApi,calculateStoreQuote,type StoreProfile,type NoticeTemplate} from './notice-api';
const won=(n:number)=>`${n.toLocaleString('ko-KR')}원`;
export function PickupQuoteDraft({name,phone,address,items}:{name:string;phone:string;address:string;items:{name:string;quantity:number;amount:number}[]}){
  const [source,setSource]=useState<{profile:StoreProfile;template:NoticeTemplate}|null>(null),[error,setError]=useState(''),[copy,setCopy]=useState('');
  useEffect(()=>{
    let live=true,version=0;
    const load=()=>{const v=++version;void Promise.all([
      noticeApi<{profile:StoreProfile}>('GET','/profile'),noticeApi<{templates:NoticeTemplate[]}>('GET','/templates'),
    ]).then(([p,t])=>{if(live&&v===version){
      const template=t.templates.find(x=>x.id==='pickup-quote');if(!template)throw Error('수거 안내 기본 문구가 없습니다.');
      setSource({profile:p.profile,template});setError('');
    }}).catch(e=>{if(live&&v===version){setSource(null);setError(e instanceof Error?e.message:'견적 설정을 읽지 못했습니다.');}});};
    load();window.addEventListener('k99-store-profile-changed',load);window.addEventListener('k99-notice-templates-changed',load);
    return()=>{live=false;window.removeEventListener('k99-store-profile-changed',load);window.removeEventListener('k99-notice-templates-changed',load);};
  },[]);
  if(error)return <p role="alert">수거 견적 미리보기: {error} · 기존 접수·촬영 기능은 계속 사용할 수 있습니다.</p>;
  if(!source)return <p role="status">매장 수거 안내 설정을 읽는 중입니다.</p>;
  const p=source.profile,q=calculateStoreQuote(items.reduce((n,i)=>n+i.amount,0),p);
  const values:Record<string,string>={'매장명':p.storeName,'고객명':name||'고객','연락처':phone,'주소':address,
    '소개글':p.introduction,'매장소개':p.introduction,'담당자':p.defaultStaff,
    '품목내역':items.map(i=>`${i.name} ${i.quantity}점: ${won(i.amount)}`).join('\n'),
    '견적내역':`품목 합계: ${won(q.subtotal)}\n금액 할인(${q.rate}%): -${won(q.discount)}\n리뷰 확인 할인: -${won(q.reviewDiscount)}\n견적 합계: ${won(q.total)}`,
    '주문합계':won(q.total),'결제안내':'결제 방식과 최종 금액은 접수 최종 확인에서 확정합니다.'};
  const body=`${p.storeName} · ${name||'고객'} 고객님\n\n${source.template.text.replace(/\{([^{}]+)\}/g,(m,k)=>values[k]??m)}\n\n담당: ${p.defaultStaff}`;
  return <details open style={{gridColumn:'1/-1',border:'2px solid #e7c45e',borderRadius:10,padding:14,fontSize:19,color:'#eff6ff',background:'#13252e'}}>
    <summary style={{fontWeight:800,cursor:'pointer'}}>방문 수거 · 최신 품목 단가 자동 견적 고지</summary>
    <textarea lang="ko" readOnly aria-label="방문 수거 자동 견적 미리보기" value={body}
      style={{width:'100%',minHeight:260,fontSize:20,padding:14,marginTop:12,color:'#16242e',background:'#fff'}}/>
    <p>품목·단가·매장 할인 설정이 바뀌면 즉시 다시 계산합니다. 수거·배달비, 직원 수정 금액, 리뷰 작성 확인은 최종 접수 화면에서 확정하며, 저장 후 고객용 문안을 자유롭게 편집·발송합니다.</p>
    <button type="button" onClick={()=>void navigator.clipboard.writeText(body).then(()=>setCopy('복사했습니다. 발송한 것은 아닙니다.')).catch(()=>setCopy('복사하지 못했습니다. 문안을 선택해 직접 복사해 주세요.'))}>견적 문안 복사</button>
    {copy&&<span role="status"> {copy}</span>}
  </details>;
}
