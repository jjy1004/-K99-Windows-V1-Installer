/** A monitor may recover its own newer snapshot, never another staff tab's. */
export const customerSnapshotKey = (sourceId: string) => `k99-customer-snapshot:${sourceId}`;
export function newerCustomerSnapshot<T extends { sourceId: string; revision: number }>(
  opening: T, cached: T | null,
): T {
  return cached && cached.sourceId === opening.sourceId && cached.revision > opening.revision
    ? cached : opening;
}
