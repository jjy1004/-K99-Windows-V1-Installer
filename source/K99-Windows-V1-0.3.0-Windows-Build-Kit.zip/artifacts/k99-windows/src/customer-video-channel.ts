import { isMediaCommand, type CustomerMediaCommand } from './customer-media';

// Live messages only. Never put commands in customer snapshots or browser storage.
export const LIVE_VIDEO_CHANNEL = 'k99-customer-video-live-v1';
const DISCOVER = 'video-discover';
const DISPLAY = 'video-display';
const PLAY = 'video-play';
const ACK = 'video-ack';
const STATUS = 'video-status';
const LINK_TTL = 6000;
const SETTLE_MS = 150;
export type LiveVideoStatus = {
  error: string;
  diagnostic: { commandId?: string | null; event: string; [key: string]: unknown };
};

export class StaffVideoChannel {
  private staffId = crypto.randomUUID();
  private probeId = '';
  private probeSource = '';
  private probeAt = 0;
  private displays = new Set<string>();
  private selected: { id: string; source: string; at: number } | undefined;
  private active: { command: CustomerMediaCommand; source: string; displayId?: string } | undefined;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private closed = false;

  constructor(private channel: BroadcastChannel, private options: {
    source: () => string;
    onLink: (connected: boolean) => void;
    onAck: (commandId: string) => void;
    onStatus: (status: LiveVideoStatus) => void;
  }) {
    channel.addEventListener('message', this.receive);
  }

  private receive = (event: MessageEvent) => {
    const data = event.data;
    if (!data || data.staffId !== this.staffId || data.sourceId !== this.options.source()) return;
    if (data.type === DISPLAY && data.probeId === this.probeId &&
        this.probeSource === data.sourceId && Date.now() - this.probeAt <= LINK_TTL &&
        typeof data.displayId === 'string' && data.displayId.length > 0) {
      this.displays.add(data.displayId);
      return;
    }
    if (!this.active || data.displayId !== this.active.displayId ||
        data.sourceId !== this.active.source || data.commandId !== this.active.command.id) return;
    if (data.type === ACK) this.options.onAck(data.commandId);
    if (data.type === STATUS && typeof data.status?.error === 'string' &&
        data.status.diagnostic?.commandId === data.commandId &&
        typeof data.status.diagnostic.event === 'string') this.options.onStatus(data.status);
  };

  probe() {
    if (this.closed) return;
    this.probeId = crypto.randomUUID();
    this.probeSource = this.options.source();
    this.probeAt = Date.now();
    this.displays.clear();
    clearTimeout(this.timer);
    this.channel.postMessage({ type: DISCOVER, staffId: this.staffId,
      sourceId: this.probeSource, probeId: this.probeId });
    this.timer = setTimeout(() => {
      this.selected = this.displays.size === 1
        ? { id: [...this.displays][0], source: this.probeSource, at: Date.now() } : undefined;
      this.options.onLink(Boolean(this.selected));
    }, SETTLE_MS);
  }

  async send(command: CustomerMediaCommand) {
    const attempt = { command, source: this.options.source(), displayId: undefined as string | undefined };
    this.active = attempt;
    if (!this.selected || this.selected.source !== attempt.source ||
        Date.now() - this.selected.at > LINK_TTL) {
      this.probe();
      await new Promise((resolve) => setTimeout(resolve, SETTLE_MS + 30));
    }
    if (this.closed || this.active !== attempt || this.options.source() !== attempt.source) return;
    if (!this.selected || this.selected.source !== attempt.source) {
      throw new Error(this.displays.size > 1
        ? '같은 접수의 고객 화면이 여러 개여서 영상 대상을 선택하지 않았습니다.'
        : '현재 접수의 기존 고객 화면이 응답하지 않습니다. 이미 열린 고객 화면을 새로고침해 주세요.');
    }
    if (!isMediaCommand(command)) throw new Error('영상 명령의 유효시간이 지났습니다. 버튼을 다시 눌러 주세요.');
    attempt.displayId = this.selected.id;
    this.channel.postMessage({ type: PLAY, staffId: this.staffId,
      sourceId: attempt.source, displayId: attempt.displayId, command });
  }

  close() {
    this.closed = true;
    clearTimeout(this.timer);
    this.channel.removeEventListener('message', this.receive);
    this.channel.close();
  }
}

export class CustomerVideoChannel {
  private displayId = crypto.randomUUID();
  private probes = new Map<string, { id: string; at: number; source: string }>();
  private active: { staffId: string; commandId: string; source: string } | undefined;

  constructor(private channel: BroadcastChannel, private options: {
    source: () => string | null; onCommand: (command: CustomerMediaCommand) => void;
  }) {
    channel.addEventListener('message', this.receive);
  }

  private receive = (event: MessageEvent) => {
    const data = event.data;
    if (!data || !this.options.source() || data.sourceId !== this.options.source() ||
        typeof data.staffId !== 'string' || !data.staffId) return;
    if (data.type === DISCOVER && typeof data.probeId === 'string' && data.probeId) {
      this.probes.set(data.staffId, { id: data.probeId, at: Date.now(), source: data.sourceId });
      if (this.probes.size > 20) this.probes.delete(this.probes.keys().next().value!);
      this.channel.postMessage({ type: DISPLAY, staffId: data.staffId,
        sourceId: data.sourceId, probeId: data.probeId, displayId: this.displayId });
      return;
    }
    const probe = this.probes.get(data.staffId);
    if (data.type !== PLAY || data.displayId !== this.displayId || !probe ||
        probe.source !== data.sourceId || Date.now() - probe.at > LINK_TTL ||
        !isMediaCommand(data.command)) return;
    this.active = { staffId: data.staffId, commandId: data.command.id, source: data.sourceId };
    this.options.onCommand(data.command);
    this.channel.postMessage({ type: ACK, staffId: data.staffId, sourceId: data.sourceId,
      displayId: this.displayId, commandId: data.command.id });
  };

  status(status: LiveVideoStatus) {
    if (!this.active || this.active.source !== this.options.source() ||
        status.diagnostic.commandId !== this.active.commandId) return;
    this.channel.postMessage({ type: STATUS, staffId: this.active.staffId,
      sourceId: this.active.source, displayId: this.displayId,
      commandId: this.active.commandId, status });
  }

  close() {
    this.channel.removeEventListener('message', this.receive);
    this.channel.close();
  }
}
