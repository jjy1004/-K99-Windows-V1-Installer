import {showCameraVideo} from './camera-video';
import {createIriunFreshness, type IriunFreshness} from './iriun-freshness';

/** Pixel inspection only. It never changes exposure, colours or saved photos. */
export function isEmptyBlackFrame(data:ArrayLike<number>){
  if(!data.length)return false;
  let sum=0,max=0,count=0;
  for(let i=0;i+2<data.length;i+=4)for(let c=0;c<3;c++){
    const value=data[i+c];sum+=value;max=Math.max(max,value);count++;
  }
  // A black garment or a still subject is NOT a frozen camera. Reject only
  // essentially zero-filled frames, not ordinary dark fabric or low contrast.
  return count>0&&max<=4&&sum/count<=1;
}
export function createFrameReader(){
  let canvas:HTMLCanvasElement|undefined;
  return (video:HTMLVideoElement):'image'|'black'|'unavailable'=>{
    try{
      canvas??=document.createElement('canvas');canvas.width=32;canvas.height=18;
      const g=canvas.getContext('2d',{willReadFrequently:true});if(!g)return 'unavailable';
      g.drawImage(video,0,0,32,18);
      return isEmptyBlackFrame(g.getImageData(0,0,32,18).data)?'black':'image';
    }catch{return 'unavailable';}
  };
}
export async function inspectIriunStream(stream:MediaStream,signal?:AbortSignal){
  if(typeof document==='undefined')return; // Node engine tests inject a decoder.
  const video=document.createElement('video'),read=createFrameReader();
  // Keep the probe renderable: some Chromium versions throttle a detached
  // video after one frame. The temporary 2px element never changes layout.
  if(video.style)Object.assign(video.style,{position:'fixed',right:'0',bottom:'0',width:'2px',height:'2px',opacity:'0.01',pointerEvents:'none'});
  video.setAttribute?.('aria-hidden','true');document.body?.append(video);
  const detach=()=>{video.pause();video.srcObject=null;video.remove?.();};
  signal?.addEventListener('abort',detach,{once:true});
  try{
    signal?.throwIfAborted();
    await showCameraVideo(video,stream);
    for(let i=0;i<3;i++){
      const track=stream.getVideoTracks()[0];
      if(!track||track.readyState==='ended'||track.muted)throw Error('Iriun 영상 연결이 중단되었습니다.');
      const result=read(video);
      if(result==='image'){await waitForFrameProgress(video,track);return;}
      if(result==='unavailable')throw Error('Iriun 영상 내용을 확인하지 못했습니다. 다시 연결해 주세요.');
      await new Promise(resolve=>setTimeout(resolve,150));
    }
    throw Error('Iriun에서 검은 화면만 수신됩니다. 다른 Iriun 수신기를 확인합니다.');
  }finally{signal?.removeEventListener('abort',detach);detach();}
}
/** A cached single frame is not a running receiver. No pixel motion test. */
function waitForFrameProgress(video:HTMLVideoElement,track:MediaStreamTrack){
  return new Promise<void>((resolve,reject)=>{
    let frames=0,changes=0,id:number|undefined,settled=false;
    let previous=video.getVideoPlaybackQuality?.().totalVideoFrames??video.currentTime;
    const finish=(error?:Error)=>{
      if(settled)return;settled=true;clearInterval(checker);clearTimeout(timeout);
      try{if(id!==undefined)video.cancelVideoFrameCallback?.(id);}catch{}
      if(error)reject(error);else resolve();
    };
    const frame=()=>{
      if(settled)return;
      if(++frames>=2){finish();return;}
      try{id=video.requestVideoFrameCallback(frame);}catch{}
    };
    const checker=setInterval(()=>{
      try{
        if(track.readyState==='ended'||track.muted){finish(Error('Iriun 영상 신호가 중단되었습니다.'));return;}
        const progress=video.getVideoPlaybackQuality?.().totalVideoFrames??video.currentTime;
        if(Number.isFinite(progress)&&progress>previous){
          previous=progress;if(++changes>=2)finish();
        }
      }catch{finish(Error('Iriun 프레임 상태를 읽지 못했습니다.'));}
    },50);
    const timeout=setTimeout(()=>finish(Error('Iriun에서 새 영상 프레임이 도착하지 않습니다.')),1500);
    try{if(video.requestVideoFrameCallback)id=video.requestVideoFrameCallback(frame);}catch{}
  });
}

type Options={
  isCurrent:()=>boolean;recover:(reason:string)=>void;
  now?:()=>number;readFrame?:ReturnType<typeof createFrameReader>;
  every?:(run:()=>void,ms:number)=>()=>void;
  events?:EventTarget;page?:EventTarget&{hidden?:boolean};
  freshness?:IriunFreshness;
};
/** One monitor per owned stream. Sample pixels and frame progress every 250ms.
 * Exact repeated images are suspicious even if a receiver advances its clock. */
export function watchIriunStream(video:HTMLVideoElement,stream:MediaStream,options:Options){
  const now=options.now||Date.now,read=options.readFrame||createFrameReader();
  const freshness=options.freshness??createIriunFreshness({now});
  const track=stream.getVideoTracks()[0],events=options.events??globalThis.window;
  const page=options.page??globalThis.document;
  let disposed=false,bad=0,black=0,unreadable=0,frameAt=now(),lastTick=now(),lastProgress=-1,callbackId:number|undefined;
  freshness.sample(video,stream);
  const removers:(()=>void)[]=[];
  const listen=(target:EventTarget|undefined,name:string,fn:()=>void)=>{
    target?.addEventListener(name,fn);removers.push(()=>target?.removeEventListener(name,fn));
  };
  function dispose(){
    if(disposed)return;disposed=true;cancelTimer?.();
    try{if(callbackId!==undefined)video.cancelVideoFrameCallback?.(callbackId);}catch{}
    for(const remove of removers)remove();
  }
  function recover(reason:string){
    if(disposed)return;
    const current=options.isCurrent();dispose();
    if(current)options.recover(reason);
  }
  const frame=()=>{
    if(disposed)return;
    if(!options.isCurrent()){dispose();return;}
    frameAt=now();
    freshness.frame();
    try{callbackId=video.requestVideoFrameCallback(frame);}catch{/* Playback counters remain available. */}
  };
  try{if(video.requestVideoFrameCallback)callbackId=video.requestVideoFrameCallback(frame);}catch{}
  function tick(){
    try{
    if(disposed)return;
    if(!options.isCurrent()){dispose();return;}
    const time=now(),gap=time-lastTick;lastTick=time;
    if(page?.hidden){frameAt=time;bad=0;black=0;unreadable=0;return;}
    if(gap>15000){recover('PC 절전 복귀 후 Iriun 영상을 다시 연결합니다.');return;}
    if(gap<0){frameAt=time;lastProgress=-1;}
    if(!track||track.readyState==='ended'){recover('Iriun 연결이 종료되어 다시 연결합니다.');return;}
    const ready=video.srcObject===stream&&video.readyState>=2&&video.videoWidth>0&&video.videoHeight>0&&!track?.muted;
    const sample=freshness.sample(video,stream);
    if(track.muted){recover('Iriun 신호가 중단되어 다시 연결합니다.');return;}
    if(sample.usable&&sample.pixelAvailable&&sample.frozenForMs>=1500){
      recover('같은 영상이 1.5초 이상 반복되어 Iriun을 다시 연결합니다.');return;
    }
    if(ready){
      const quality=video.getVideoPlaybackQuality?.();
      const progress=quality?.totalVideoFrames??video.currentTime;
      if(progress!==lastProgress){lastProgress=progress;frameAt=time;}
      const pixels=read(video);
      if(pixels==='black')black++;else black=0;
      if(pixels==='unavailable')unreadable++;else unreadable=0;
    }
    if(!ready)bad++;else bad=0;
    if(black>=6||bad>=6||unreadable>=6||(ready&&time-frameAt>=1500))
      recover(black>=3?'Iriun 검은 화면이 지속되어 다시 연결합니다.':'Iriun 영상이 멈추거나 확인되지 않아 다시 연결합니다.');
    }catch(error){
      if(disposed)throw error;
      recover('카메라 상태를 읽지 못해 Iriun을 다시 연결합니다.');
    }
  }
  const every=options.every||((fn:()=>void,ms:number)=>{const id=setInterval(fn,ms);return()=>clearInterval(id);});
  const cancelTimer=every(tick,250);
  listen(track,'ended',()=>recover('Iriun 연결이 종료되어 다시 연결합니다.'));
  listen(track,'mute',tick);listen(track,'unmute',()=>{frameAt=now();bad=0;tick();});
  listen(events,'k99-camera-resume',()=>recover('PC 절전 복귀 후 Iriun 영상을 다시 연결합니다.'));
  listen(events,'online',tick);listen(events,'pageshow',tick);
  listen(page,'visibilitychange',tick);
  return dispose;
}
