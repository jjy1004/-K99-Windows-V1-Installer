import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createConfirmedOrder, type ConfirmedOrder} from '../src/order-record';
import {buildFieldInspectionDraft, completeFieldInspection, fieldReviewNeeds, recordFieldConsent, requiredAcknowledgements} from '../src/field-inspection';
import {createGarmentRecords} from '../src/garment-record';

const choices={serviceLevel:'general' as const,pickupRequested:false,deliveryRequested:false,directPickup:true,
  requestedPickupDate:'',waiver:'not-requested' as const,luxuryItem:false,customerRequests:'없음',totalOverride:12340};
function make(planned?:'물세탁'|'드라이세탁'):ConfirmedOrder {
  const o=createConfirmedOrder({id:'F-1',customerName:'박서준',customerPhone:'010-1234-5678',customerAddress:'',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false,
      ...(planned?{plannedCleaningMethod:planned}:{})}]},choices);
  return {...o,garments:createGarmentRecords(o)};
}

test('unknown method is never assumed; explicit per-item choice is required', () => {
  const o=make();
  assert.deepEqual(fieldReviewNeeds(o).map(n=>n.needsMethod),[true]);
  assert.throws(()=>buildFieldInspectionDraft(o,{}),/실물을 확인/);
  assert.throws(()=>buildFieldInspectionDraft(o,{0:{confirmed:true,memo:'',result:'이상 없음'}}),/세탁 방법/);
  assert.throws(()=>buildFieldInspectionDraft(o,{0:{confirmed:true,memo:'',result:'주의 필요',method:'물세탁'}}),/메모/);
  const done=completeFieldInspection(o,{0:{confirmed:true,memo:'',result:'이상 없음',method:'드라이세탁'}});
  assert.equal(done.inspection?.items[0].actualCleaningMethod,'드라이세탁');
  assert.equal(done.status,'세탁 진행 승인');
  assert.equal(done.estimatedTotal,12340);
  assert.equal(done.inspection?.revisedPrice,12340);
});

test('planned item with no review need proceeds; method change requires consent', () => {
  const o=make('물세탁');
  assert.equal(fieldReviewNeeds(o).length,0);
  assert.equal(completeFieldInspection(o,{}).status,'세탁 진행 승인');
  const changed=completeFieldInspection(o,{0:{confirmed:true,memo:'얼룩',result:'주의 필요',method:'드라이세탁'}});
  assert.equal(changed.inspection?.needsApproval,true);
  assert.notEqual(changed.status,'세탁 진행 승인');
  assert.ok(requiredAcknowledgements(changed).includes('변경 세탁방법 동의'));
});

test('no approval without explicit yes; prior records retained verbatim', () => {
  const o=completeFieldInspection(make('물세탁'),{0:{confirmed:true,memo:'얼룩',result:'주의 필요',method:'드라이세탁'}});
  const legacy={...o,inspection:{...o.inspection!,stagedApproval:{legacy:true} as never,
    response:{decisions:['문의 있음' as const],content:'옛 회신',confirmedAt:'2025-01-01',staffName:'이전'}}};
  const before=JSON.stringify({s:legacy.inspection.stagedApproval,r:legacy.inspection.response,i:legacy.inspection.itemNotice,h:legacy.history});
  assert.throws(()=>recordFieldConsent(legacy,{consent:null,message:'안내'}),/직접 선택/);
  assert.throws(()=>recordFieldConsent(legacy,{consent:undefined,message:'안내'}),/직접 선택/);
  assert.throws(()=>recordFieldConsent(legacy,{consent:'동의 완료',message:'  '}),/문안/);
  const no=recordFieldConsent(legacy,{consent:'미동의',message:'안내 문안 A'},new Date('2026-02-01T00:00:00Z'));
  assert.equal(no.status,'세탁 진행 거절');
  const yes=recordFieldConsent(no,{consent:'동의 완료',message:'수정 문안 B'},new Date('2026-02-02T00:00:00Z'));
  assert.equal(yes.status,'세탁 진행 승인');
  const fc=yes.inspection!.fieldConsents!;
  assert.equal(fc.length,2);
  assert.equal(fc[1].message,'수정 문안 B');
  assert.equal(fc[1].recordedAt,'2026-02-02T00:00:00.000Z');
  assert.equal(fc[1].actuallySent,false);
  assert.equal(fc[1].customerSignature,false);
  assert.ok(fc[1].acknowledged.includes('변경 세탁방법 동의'));
  assert.equal(JSON.stringify({s:yes.inspection!.stagedApproval,r:yes.inspection!.response,i:yes.inspection!.itemNotice,h:yes.history!.slice(0,legacy.history!.length)}),before);
  assert.throws(()=>recordFieldConsent(yes,{consent:'동의 완료',message:'x'}),/이미 승인/);
});

test('notice fee applies only after explicit yes; resave replaces; base override preserved', async () => {
  const {recordFeeConsent}=await import('../src/field-inspection');
  const withNotice=(o:ConfirmedOrder,fee:number):ConfirmedOrder=>({...o,processNotice:{kind:'both',message:'m',technicalFee:fee,consent:null,savedAt:'t',actuallySent:false}});
  // Pending approval order (method change) with fee notice.
  let o=withNotice(completeFieldInspection(make('물세탁'),{0:{confirmed:true,memo:'얼룩',result:'주의 필요',method:'드라이세탁'}}),3000);
  assert.equal(o.estimatedTotal,12340);
  const no=recordFieldConsent(o,{consent:'미동의',message:'안내'});
  assert.equal(no.estimatedTotal,12340); assert.equal(no.feeAdjustment,undefined);
  o=recordFieldConsent(no,{consent:'동의 완료',message:'안내'});
  assert.equal(o.estimatedTotal,15340);
  assert.equal(o.laundryTotal,12340+3000);
  assert.ok(requiredAcknowledgements(withNotice(no,3000)).includes('추가요금 동의'));
  assert.equal(o.feeAdjustment?.baseEstimatedTotal,12340);
  assert.equal(o.feeAdjustment?.baseChoices.totalOverride,12340);
  assert.equal(o.choices.totalOverride,12340);
  const consentsBefore=JSON.stringify(o.inspection!.fieldConsents);
  // Resave same fee on approved order: replaces, never stacks.
  o=recordFeeConsent(o,{consent:'동의 완료',message:'재안내'});
  assert.equal(o.estimatedTotal,15340);
  // Edit amount: notice alone does not change totals.
  o=withNotice(o,5000);
  assert.equal(o.estimatedTotal,15340);
  const declined=recordFeeConsent(o,{consent:'미동의',message:'변경 안내'});
  assert.equal(declined.estimatedTotal,15340);
  assert.throws(()=>recordFeeConsent(o,{consent:null,message:'x'}),/직접 선택/);
  o=recordFeeConsent(declined,{consent:'동의 완료',message:'변경 안내'});
  assert.equal(o.estimatedTotal,17340);
  assert.equal(o.feeAdjustment?.history.length,3);
  assert.equal(o.status,'세탁 진행 승인');
  assert.ok(o.inspection!.fieldConsents!.every(c=>c.actuallySent===false));
  assert.equal(JSON.stringify(o.inspection!.fieldConsents!.slice(0,2)),consentsBefore);
  assert.deepEqual(o.garments,make('물세탁').garments);
});

test('approved work with no inspection approval need: fee consent appended without status/garment change', async () => {
  const {recordFeeConsent}=await import('../src/field-inspection');
  const base=completeFieldInspection(make('물세탁'),{});
  const o={...base,processNotice:{kind:'fee' as const,message:'m',technicalFee:2000,consent:null,savedAt:'t',actuallySent:false as const}};
  const r=recordFeeConsent(o,{consent:'동의 완료',message:'추가 기술료 안내'});
  assert.equal(r.estimatedTotal,14340);
  assert.equal(r.status,base.status);
  assert.deepEqual(r.garments,base.garments);
  assert.deepEqual(r.history!.slice(0,base.history!.length),base.history);
});
