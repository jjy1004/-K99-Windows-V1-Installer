'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createUpdateNotice,noticeText,updateNoticeHtml}=require('../electron/update-notice.cjs');
const {createAutoUpdate}=require('../electron/auto-update.cjs');
require('./update-notice-recovery.test.cjs');
test('senior notice has Korean title, large readable text, no scripts or external resources',()=>{
  const html=updateNoticeHtml();
  assert.match(html,/새로운 기능이 업데이트되었습니다/);assert.match(html,/잠시만 기다려 주세요/);
  assert.match(html,/font-size:29px/);assert.match(html,/font-size:21px/);
  assert.match(html,/default-src 'none'/);assert.doesNotMatch(html,/<script|https?:|<iframe/i);
  assert.match(noticeText({phase:'installing'}).details,/백업/);
  assert.match(noticeText({phase:'ready',deferred:true}).details,/업무를 계속/);
  assert.equal(noticeText({phase:'downloading',percent:123}).progress,'다운로드 100%');
  assert.match(html,/html\{color-scheme:dark;background:#0f172a\}/);
  assert.match(html,/h1\{color:#fff/);
  assert.match(html,/\.dismiss\{[^}]*background:#f8fafc;color:#0f172a/);
  assert.match(html,/href="k99-update-notice:close"/);
  assert.match(html,/확인 · 닫기/);
  assert.match(html,/forced-colors:active/);
});
test('안내창 닫기는 업데이트를 중단하지 않고 같은 진행률 창이 다시 튀어나오지 않는다',()=>{
  const windows=[];
  class FakeWindow extends EventEmitter{
    constructor(options){super();this.options=options;this.webContents=new EventEmitter();
      this.webContents.setWindowOpenHandler=()=>{};this.webContents.executeJavaScript=async()=>{};windows.push(this);}
    center(){}isDestroyed(){return false;}async loadURL(){}showInactive(){}destroy(){this.emit('closed');}
  }
  const notice=createUpdateNotice({BrowserWindow:FakeWindow});
  notice.show({phase:'downloading',percent:10});
  assert.equal(windows[0].options.backgroundColor,'#0f172a');
  let denied=0;
  windows[0].webContents.emit('will-navigate',{preventDefault(){denied++;}},'https://example.com');
  notice.show({phase:'downloading',percent:15});assert.equal(windows.length,1);
  windows[0].webContents.emit('will-navigate',{preventDefault(){denied++;}},'k99-update-notice:close');
  notice.show({phase:'downloading',percent:20});assert.equal(windows.length,1);
  notice.show({phase:'ready',deferred:true});assert.equal(windows.length,2);
  assert.equal(denied,2);notice.close();
});
test('native notice uses a sandbox, centers without stealing staff focus and updates text safely',async()=>{
  const windows=[];
  class FakeWindow extends EventEmitter{
    constructor(options){super();this.options=options;this.webContents=new EventEmitter();
      this.webContents.setWindowOpenHandler=fn=>this.open=fn;
      this.webContents.executeJavaScript=async js=>{this.lastScript=js;};
      windows.push(this);}
    center(){this.centered=true;}isDestroyed(){return false;}
    async loadURL(url){this.url=url;}showInactive(){this.visible=true;}
    destroy(){this.emit('closed');}
  }
  const parent={isDestroyed:()=>false};
  const n=createUpdateNotice({BrowserWindow:FakeWindow,parent:()=>parent,
    later:(fn,ms)=>ms===1200?queueMicrotask(fn):setTimeout(fn,ms)});
  n.show({phase:'downloading',percent:3});
  const w=windows[0];
  assert.equal(w.options.parent,parent);assert.equal(w.options.webPreferences.nodeIntegration,false);
  assert.equal(w.options.webPreferences.sandbox,true);assert.ok(w.centered);
  w.webContents.emit('did-finish-load');
  await new Promise(r=>setImmediate(r));
  assert.ok(w.visible);assert.match(w.lastScript,/textContent/);
  assert.deepEqual(w.open(),{action:'deny'});
  n.show({phase:'downloading',percent:50});
  await new Promise(r=>setImmediate(r));
  assert.match(w.lastScript,/50%/);
  await n.waitForPaint();assert.match(w.lastScript,/백업/);
  n.close();
});
test('download detection/progress/completion and safe installation publish elder-friendly states',async()=>{
  const u=new EventEmitter(),states=[],events=[];
  u.setFeedURL=()=>{};u.checkForUpdates=async()=>{};u.quitAndInstall=()=>events.push('install');
  const c=createAutoUpdate({updater:u,enabled:true,canInstall:()=>true,
    onState:s=>states.push(s),beforeInstall:async()=>events.push('notice'),
    backup:async()=>{events.push('backup');return {verified:true};},
    setTimeout:()=>({}),clearTimeout(){},setInterval:()=>({}),clearInterval(){}});
  c.start();u.emit('update-available',{version:'2.4.12'});u.emit('download-progress',{percent:45});
  c.noteUserActivity();u.emit('update-downloaded');
  assert.deepEqual(states.map(s=>s.phase),['downloading','downloading','ready']);
  assert.equal(states.at(-1).deferred,true);
  c.beforeQuit({preventDefault(){}},()=>{});
  await new Promise(r=>setImmediate(r));
  assert.deepEqual(events,['notice','backup','install']);
  c.dispose();
});
test('work beginning while installation notice is painted defers before creating a backup',async()=>{
  let release,c,backups=0;
  const u=new EventEmitter(),timers=[];
  u.setFeedURL=()=>{};u.quitAndInstall=()=>assert.fail('must not install');
  c=createAutoUpdate({updater:u,enabled:true,canInstall:()=>true,
    beforeInstall:()=>new Promise(r=>release=r),backup:async()=>{backups++;return {verified:true};},
    setTimeout:(fn,ms)=>{timers.push({fn,ms});return {};},clearTimeout(){},setInterval(){},clearInterval(){}});
  c.start();u.emit('update-downloaded');timers.find(t=>t.ms===60000).fn();
  await new Promise(r=>setImmediate(r));c.noteUserActivity();release();
  await new Promise(r=>setImmediate(r));assert.equal(backups,0);c.dispose();
});
