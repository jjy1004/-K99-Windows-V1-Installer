import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {createStore}=require('../../../lib/k99-local/index.cjs');
const {createEquipmentApi}=require('../../../lib/k99-local/equipment-api.cjs');
const {createPhotoArchive}=require('../electron/photo-archive.cjs');
const {createMobilePhotoController}=require('../electron/mobile-photo-controller.cjs');
const {privateIPv4,filename}=require('../electron/mobile-photo-bridge.cjs');
const {createBundle,extractBundle}=require('../../../lib/k99-local/backup-bundle.cjs');
const JPEG=Buffer.concat([Buffer.from([255,216]),Buffer.alloc(100,42),Buffer.from([255,217])]);
const KEY='k99-active-staff-intake-v1';

function fixture(t: {after:(cb:()=>void)=>void}) {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-mobile-http-'));
  const db=path.join(root,'k99.db');
  let store=createStore(db,'test-only',{nativeDesktop:true}),prints=0,events=0,clock=Date.now();
  store.equipment.configure({mode:'real',printerName:'TSC TE210',labelWidthMm:60,labelHeightMm:40,
    labelVerified:true,cameraDeviceId:'test-camera',hardwareConfirmed:true},true);
  const archive=createPhotoArchive({getRoot:()=>path.join(root,'test-D'),openPath:async()=>'',encodeJpeg:()=>JPEG});
  const adapters={native:true,archivePhoto:archive.photo,print:async()=>{prints++;}};
  const equipment=()=>createEquipmentApi(store,adapters);
  let eq=equipment();
  const bridge=createMobilePhotoController({get store(){return store;},equipmentApi:eq,archivePhoto:archive.photo,native:true,
    // OS image decoder and printer are explicit test adapters. HTTP, files and SQLite are real.
    nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:1,height:1})})},
    changed:()=>events++,host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1'],now:()=>clock});
  adapters.archivePhoto=bridge.archivePhoto;
  const target={orderId:'mobile-draft-order-1',unitKey:'1:1',itemId:'shirt',itemName:'셔츠',customerName:'단위검증',customerPhone:'01000001234'};
  function activate(value=target){
    store.storage({op:'set',key:KEY,value:JSON.stringify({version:1,draftId:value.orderId,revision:0,
      updatedAt:new Date().toISOString(),data:{customerName:value.customerName,customerPhone:value.customerPhone,
        rows:[{id:1,itemId:value.itemId,quantity:1}]}}),expected:store.storage({op:'get',key:KEY})});
  }
  activate();
  t.after(()=>{bridge.close();store.close();fs.rmSync(root,{recursive:true,force:true});});
  return {root,db,target,activate,bridge,archive,get store(){return store;},get eq(){return eq;},
    get prints(){return prints;},get events(){return events;},expire(){clock+=11*60*1000;},
    reopen(){bridge.close();store.close();store=createStore(db,'test-only',{nativeDesktop:true});eq=equipment();}};
}
async function upload(session:{urls:string[]},id:string,bytes:Buffer=JPEG,headers:Record<string,string>={}){
  const url=new URL(session.urls[0]);
  return fetch(`${url.origin}/api/upload-mobile-photo`,{method:'POST',headers:{
    'Content-Type':'image/jpeg','X-K99-Session-Token':url.searchParams.get('token')!,
    'X-K99-Upload-Id':id,...headers},body:new Uint8Array(bytes)});
}

test('real LAN HTTP transport joins existing PC draft, archives mobile files in same folder, deduplicates retry and never repeats first tag',async t=>{
  const f=fixture(t);
  const pc=await f.eq.api('POST','/api/equipment/command',{...f.target,action:'capture-draft',expectedMode:'real',
    requestId:'pc-photo-first',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`});
  assert.equal(f.prints,1);
  const session=await f.bridge.api('POST','/api/mobile-photo/start',f.target);
  assert.ok(session.urls[0].includes('/mobile-upload?token='));
  assert.ok(!session.urls[0].includes('targetPath'));
  const page=await fetch(session.urls[0]);assert.equal(page.status,200);assert.match(await page.text(),/capture="environment"/);
  const response=await upload(session,'mobile-upload-first');assert.equal(response.status,200);
  const result=await response.json();assert.equal(result.uploadedCount,1);
  assert.match(result.fileName,/^MOBILE_\d{8}_\d{6}_001_[a-f0-9]{8}\.jpg$/);
  assert.deepEqual(fs.readFileSync(path.join(pc.archive.folder,result.fileName)),JPEG,'JPEG bytes preserved, no recompression');
  assert.equal(f.prints,1,'additional mobile photo must not print another first tag');
  assert.equal(f.events,1);
  const duplicate=await upload(session,'mobile-upload-first');assert.equal(duplicate.status,200);
  assert.equal((await duplicate.json()).reused,true);assert.equal(f.events,1);
  const second=await upload(session,'mobile-upload-second');assert.equal(second.status,200);
  const status=await f.bridge.api('GET',`/api/mobile-photo/status?id=${session.id}`);
  assert.equal(status.uploadedCount,2);assert.equal(status.lastResult.garment.photoHistory.length,3);
  assert.equal(status.lastResult.archive.folder,pc.archive.folder);
  assert.equal(f.store.status().orderCount,0,'no fabricated confirmed order');
  const canonical=await f.bridge.api('GET',`/api/mobile-photo/draft?orderId=${f.target.orderId}`);
  assert.equal(canonical.units[0].garment.photoHistory.length,3);
  // Closing the QR revokes the phone only, not the garment or PC capture session.
  await f.bridge.api('POST','/api/mobile-photo/stop',{id:session.id});
  const pcAfter=await f.eq.api('POST','/api/equipment/command',{...f.target,action:'capture-draft',expectedMode:'real',
    requestId:'pc-after-qr-close',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`});
  assert.equal(pcAfter.garment.photoHistory.length,4);
  assert.equal(pcAfter.archive.folder,pc.archive.folder);
  assert.deepEqual(pcAfter.garment.photoHistory.slice(0,3).map((p:{requestId:string})=>p.requestId),
    status.lastResult.garment.photoHistory.map((p:{requestId:string})=>p.requestId));
  assert.ok(pcAfter.garment.photoHistory.every((p:{archiveFile:string})=>
    typeof p.archiveFile==='string' && fs.existsSync(path.join(pc.archive.folder,p.archiveFile))));
  assert.equal(f.prints,1,'QR close and subsequent PC shot cannot repeat the first-photo tag');
  const file=path.join(pc.archive.folder,result.fileName);
  f.reopen();
  assert.ok(fs.existsSync(file));
  assert.equal(f.store.equipment.drafts.state(f.target.orderId).units[0].garment.photoHistory.length,4);
  assert.equal(f.prints,1);
});

test('mobile first creates archive safely; expired, revoked, stale customer, wrong origin/host and invalid image never commit',async t=>{
  const f=fixture(t);
  const session=await f.bridge.api('POST','/api/mobile-photo/start',f.target),url=new URL(session.urls[0]);
  assert.equal(fs.existsSync(path.join(f.root,'test-D')),false);
  assert.equal((await upload(session,'bad-image-upload',Buffer.from('not an image'))).status,413);
  assert.equal((await upload(session,'bad-origin-photo',JPEG,{Origin:'http://evil.example'})).status,403);
  const badHost=await new Promise<number>((resolve,reject)=>{
    const request=http.request(`${url.origin}/api/upload-mobile-photo`,{method:'POST',headers:{
      Host:'evil.example','Content-Type':'image/jpeg','Content-Length':JPEG.length,
      'X-K99-Session-Token':url.searchParams.get('token')!,'X-K99-Upload-Id':'bad-host-photo12'}},
      response=>{response.resume();resolve(response.statusCode!);});
    request.on('error',reject);request.end(JPEG);
  });
  assert.equal(badHost,403);
  const wrong=await fetch(`${url.origin}/api/upload-mobile-photo`,{method:'POST',headers:{
    'Content-Type':'image/jpeg','X-K99-Session-Token':'invalid','X-K99-Upload-Id':'wrong-token-1234'},body:new Uint8Array(JPEG)});
  assert.equal(wrong.status,410);
  assert.equal(f.store.equipment.drafts.state(f.target.orderId).units.length,0);
  const first=await upload(session,'mobile-first-alone');assert.equal(first.status,200);
  const status=await f.bridge.api('GET',`/api/mobile-photo/status?id=${session.id}`);
  assert.ok(fs.existsSync(path.join(status.lastResult.archive.folder,(await first.json()).fileName)));
  assert.equal(path.basename(path.dirname(status.lastResult.archive.folder)),'01_고객세탁사진');
  assert.equal(path.basename(status.lastResult.archive.folder),session.folderIdentifier);
  assert.equal(f.prints,1,'mobile-first uses existing first-photo tag rule, mocked spooler');
  const changed=Buffer.from(JPEG);changed[10]=12;
  assert.equal((await upload(session,'mobile-first-alone',changed)).status,409);
  f.activate({...f.target,customerName:'변경고객'});
  assert.equal((await upload(session,'stale-target-photo')).status,409);
  assert.equal(f.store.equipment.drafts.state(f.target.orderId).units[0].garment.photoHistory.length,1);
  f.activate();
  f.expire();
  assert.equal((await upload(session,'expired-session-photo')).status,410);
  await f.bridge.api('POST','/api/mobile-photo/stop',{id:session.id});
  await assert.rejects(()=>f.bridge.api('GET',`/api/mobile-photo/status?id=${session.id}`),/종료/);
});

test('scope and packaging contracts keep LAN narrow, reuse existing IPC, and include every new runtime module',()=>{
  assert.equal(privateIPv4('192.168.0.10'),true);assert.equal(privateIPv4('::ffff:10.0.0.2'),true);
  assert.equal(privateIPv4('8.8.8.8'),false);assert.equal(privateIPv4('172.32.1.2'),false);
  assert.match(filename(new Date('2026-11-05T15:00:00Z'),1,'request123'),/^MOBILE_20261106_000000_001_/);
  const stage=fs.readFileSync(new URL('../../../scripts/stage-windows-app.cjs',import.meta.url),'utf8');
  for(const n of ['mobile-photo-controller.cjs','mobile-photo-bridge.cjs','mobile-upload-page.cjs'])assert.ok(stage.includes(n));
  const main=fs.readFileSync(new URL('../electron/main.cjs',import.meta.url),'utf8');
  assert.match(main,/input\.path\.startsWith\('\/api\/mobile-photo\/'\)/);
  assert.match(main,/mobilePhotoBridge\.close\(\)/);
  const pc=fs.readFileSync(new URL('../src/NativeDraftCamera.tsx',import.meta.url),'utf8');
  assert.match(pc,/captureShortcut\(event\)/);
  assert.match(pc,/key==='F7'&&keysRef\.current\.footReady/);
});

test('concurrent PC/mobile identical images retain independent filenames, then confirm and survive existing integrated backup',async t=>{
  const f=fixture(t);
  const session=await f.bridge.api('POST','/api/mobile-photo/start',f.target);
  const first=upload(session,'overlap-mobile-first');
  const pc=f.eq.api('POST','/api/equipment/command',{...f.target,action:'capture-draft',expectedMode:'real',
    requestId:'overlap-pc-image',imageDataUrl:`data:image/jpeg;base64,${JPEG.toString('base64')}`});
  const [phoneResult,pcResult]=await Promise.all([first,pc]);
  assert.equal(phoneResult.status,200);
  const mobile=await phoneResult.json();
  assert.match(mobile.fileName,/^MOBILE_/);
  assert.ok(!pcResult.archive.fileName.startsWith('MOBILE_'),'async mobile context must not rename a PC shot');
  assert.equal(f.prints,1);
  const draft=await f.bridge.api('GET',`/api/mobile-photo/draft?orderId=${f.target.orderId}`);
  const garment=draft.units[0].garment;
  assert.equal(garment.photoHistory.length,2);
  const order={id:f.target.orderId,customerName:f.target.customerName,customerPhone:f.target.customerPhone,customerAddress:'',
    createdAt:new Date().toISOString(),items:[{displayNameKo:'셔츠',quantity:1}],estimatedTotal:3000,laundryTotal:3000,
    garments:[{...garment,sequence:1,itemIndex:1,unitIndex:1,totalSequence:1}]};
  f.store.storage({op:'set',key:'k99-confirmed-orders-v1',value:JSON.stringify([order]),
    expected:f.store.storage({op:'get',key:'k99-confirmed-orders-v1'})});
  assert.equal(f.store.status().orderCount,1);
  assert.equal(f.store.equipment.state().photos.length,2);
  assert.equal(f.store.equipment.drafts.state(f.target.orderId).units.length,0);
  assert.equal((await upload(session,'after-confirm-blocked')).status,409);
  const snapshot=path.join(f.root,'snapshot.sqlite'),backup=path.join(f.root,'mobile.k99backup'),secret='b'.repeat(64);
  f.store.snapshot(snapshot);
  createBundle({snapshot,dataDir:f.root,target:backup,secret});
  const restored=extractBundle({file:backup,secret,destination:path.join(f.root,'extracted')});
  assert.equal(restored.counts.photos,2,'original integrated backup includes mobile canonical photo');
});
