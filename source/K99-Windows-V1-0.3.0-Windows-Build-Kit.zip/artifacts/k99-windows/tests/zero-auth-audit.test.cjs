'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
test('all UI files are scanned for residual admin password elements',()=>{
  const root=path.join(__dirname,'../src'),checked=[];
  function walk(folder){
    for(const entry of fs.readdirSync(folder,{withFileTypes:true})){
      const p=path.join(folder,entry.name);
      if(entry.isDirectory())walk(p);
      else if(/\.[jt]sx?$/.test(entry.name)){
        const source=fs.readFileSync(p,'utf8');checked.push(p);
        if(!/type=["']password["']/.test(source))continue;
        // These are encryption/helper keys, never application login fields.
        assert.ok(['MaintenanceWorkspace.tsx','PhotoBridgeSettings.tsx','AiAccountSettings.tsx'].includes(entry.name),p);
        const inputs=source.match(/<input\b[^>]*type=["']password["'][^>]*>/g)||[];
        for(const input of inputs)assert.match(input,entry.name==='AiAccountSettings.tsx'?/value=\{password\}/:/value=\{(?:backupKeyInput|token)\}/);
      }
    }
  }
  walk(root);assert.ok(checked.length>50);
});
test('all customer import UI and local handlers have no password gate',()=>{
  for(const name of ['src/NativeLedgerImportPanel.tsx','src/CustomerDirectory.tsx','src/customer-directory-client.ts',
    'src/DesktopStatusStrip.tsx','src/AdminPasswordPanel.tsx']){
    const s=read(name);
    assert.doesNotMatch(s,/type=["']password["']|isPasswordValid|verifyPassword|needPw|admin\/setup/);
  }
  const maintenance=read('src/MaintenanceWorkspace.tsx');
  assert.doesNotMatch(maintenance,/current-password|new-password|needPw|admin\/setup|maintenance-password/);
  assert.match(maintenance,/backupKeyInput/);assert.match(maintenance,/PHRASE/);
  const directory=read('../../lib/k99-local/customer-directory.cjs');
  assert.doesNotMatch(directory,/verifyAdmin|body\.password/);
});
test('management and reception both expose customer lookup/history and native photo lookup is packaged',()=>{
  assert.match(read('src/SimpleStatisticsCenter.tsx'),/<ManagementCustomerPanel/);
  const panel=read('src/ManagementCustomerPanel.tsx');
  assert.match(panel,/listCustomerDirectory\(\)/);
  assert.match(panel,/filterCustomerDirectory\(list, q\)/);
  assert.match(panel,/selected\.visits\.map/);
  assert.match(panel,/<CustomerPhotoFolders/);
  assert.match(read('src/App.tsx'),/<ReceptionCustomerLookup/);
  assert.match(read('src/CustomerDirectory.tsx'),/<RecentYearBlock/);
  assert.match(read('src/CustomerDirectory.tsx'),/<CustomerPhotoFolders/);
  assert.match(read('electron/main.cjs'),/k99:customer-photos/);
  assert.match(read('../../scripts/stage-windows-app.cjs'),/customer-photo-library\.cjs/);
});
