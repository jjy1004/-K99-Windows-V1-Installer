import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderToStaticMarkup} from 'react-dom/server';
import {createElement} from 'react';
import {createConfirmedOrder,type ConfirmedOrder} from '../src/order-record';
import {listGarments} from '../src/garment-scanner';
import {currentOperations} from '../src/order-operations';
import {confirmStaffHandover} from '../src/order-handover';
import {restoreHandover} from '../src/handover-recovery';
import {sortCustomerJobs} from '../src/customer-job-sort';
import {HANDOVER_AGE_BANDS,handoverAgeDays,handoverIntakeDate,partitionHandoverOrders} from '../src/handover-age';
import {ArchivedHandoverGrid,HandoverAgeTabs} from '../src/HandoverAgeBoard';

const today=new Date(2026,10,24,12);
function ready(age:number,id=`AGE-${age}`,name=id):ConfirmedOrder{
  const at=new Date(today.getFullYear(),today.getMonth(),today.getDate()-age,10);
  const base=createConfirmedOrder({id,customerName:name,customerPhone:'01000000000',customerAddress:'검증용 주소',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
    {serviceLevel:'general',paymentType:'POSTPAID',pickupRequested:false,deliveryRequested:false,directPickup:true,
      requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''},at);
  return {...base,status:'전체 세탁 완료 / 반출 대기',
    garments:listGarments(base).map(g=>({...g,processStatus:'출고 대기',completionStatus:'complete',completedAt:at.toISOString(),processUpdatedAt:at.toISOString()})),
    operations:{...currentOperations(base),stage:'세탁완료',updatedAt:at.toISOString()}};
}
test('접수일 0/30/31/90/91/180/181/365/366/730/731일 경계가 겹치거나 빠지지 않는다',()=>{
  const values=[0,30,31,90,91,180,181,365,366,730,731];
  const input=values.map(n=>ready(n)),snapshot=JSON.stringify(input);
  const g=partitionHandoverOrders(Object.freeze(input),today);
  for(const [key,expected] of Object.entries({recent:[0,30],'31-90':[31,90],'91-180':[91,180],'181-365':[181,365],'366-730':[366,730],over730:[731]})){
    assert.deepEqual(g[key as keyof typeof g].map(o=>Number(o.id.slice(4))),expected);
  }
  assert.equal(new Set(Object.values(g).flat().map(o=>o.id)).size,values.length);
  assert.equal(JSON.stringify(input),snapshot,'분류는 주문·날짜·금액을 저장하거나 변경하지 않는다');
});
test('엑셀 날짜(YYYY-MM-DD/압축 날짜)와 신규 접수 ISO 시각에 같은 접수일 기준을 적용한다',()=>{
  const native=ready(31),date=handoverIntakeDate(native.intakeAt);
  const imported={...native,id:'EXCEL-1',intakeAt:date};
  const compact={...native,id:'EXCEL-2',intakeAt:date.replaceAll('-','')};
  const g=partitionHandoverOrders([native,imported,compact],today);
  assert.deepEqual(g['31-90'].map(o=>o.id),[native.id,'EXCEL-1','EXCEL-2']);
  assert.equal(g.recent.length,0);
});
test('경과일은 완료일이나 수정일이 아닌 접수일로만 계산한다',()=>{
  const order=ready(91),ops=currentOperations(order);
  const g=partitionHandoverOrders([{...order,orderCompletedAt:today.toISOString(),operations:{...ops,updatedAt:today.toISOString()}}],today);
  assert.equal(g['91-180'].length,1);
});
test('빈 날짜·잘못된 날짜·미래 날짜를 최근 주문으로 섞거나 조용히 없애지 않는다',()=>{
  for(const date of ['', 'not-a-date','2026-02-30','2026-1124','202611-24','2026/11/24','2026-13-01']){
    assert.equal(handoverAgeDays(date,today),null,date);
    assert.equal(partitionHandoverOrders([{...ready(1),intakeAt:date}],today).invalidDate.length,1);
  }
  assert.equal(partitionHandoverOrders([ready(-1)],today).invalidDate.length,1);
  assert.equal(handoverAgeDays('2024-02-29',new Date(2024,2,1,1)),1,'윤년');
});
test('현지 자정 경계 및 DST 변경일에도 24시간 나눗셈 없이 달력 일수로 분류한다',()=>{
  const tz=process.env.TZ;
  try{
    process.env.TZ='America/New_York';
    assert.equal(handoverAgeDays('2026-03-07T23:55:00-05:00',new Date('2026-03-09T00:01:00-04:00')),2);
    assert.equal(handoverAgeDays('2026-11-01T00:01:00-04:00',new Date('2026-11-02T00:01:00-05:00')),1);
    process.env.TZ='Asia/Seoul';
    assert.equal(handoverIntakeDate('2026-11-23T17:00:00Z'),'2026-11-24');
    assert.equal(handoverAgeDays('2026-11-23T17:00:00Z',new Date('2026-11-24T14:59:00Z')),0);
    assert.equal(handoverAgeDays('2026-11-23T17:00:00Z',new Date('2026-11-24T15:00:00Z')),1);
  }finally{if(tz===undefined)delete process.env.TZ;else process.env.TZ=tz;}
});
test('하루가 지나면 30→31/90→91/180→181/365→366/730→731 구간이 자동으로 바뀐다',()=>{
  const orders=[30,90,180,365,730].map(n=>ready(n)),next=new Date(2026,10,25,0);
  const g=partitionHandoverOrders(orders,next);
  assert.equal(g.recent.length,0);
  assert.deepEqual([g['31-90'],g['91-180'],g['181-365'],g['366-730'],g.over730].map(a=>a.length),[1,1,1,1,1]);
});
test('출고·배달 출고·취소·검수 미완료는 모든 보관 구간에서 제외하고 복구하면 같은 구간으로 돌아온다',()=>{
  const base=ready(91),shipped=confirmStaffHandover(base,{paymentConfirmed:true,at:today});
  const delivery={...base,id:'delivery',operations:{...currentOperations(base),stage:'배달중' as const}};
  const cancel={...base,id:'cancel',operations:{...currentOperations(base),cancelledAt:today.toISOString()}};
  const unfinished={...base,id:'unfinished',operations:{...currentOperations(base),stage:'세탁중' as const}};
  const held={...base,id:'held',garments:base.garments!.map(g=>({...g,qcHoldReason:'검수 확인 필요'}))};
  assert.equal(Object.values(partitionHandoverOrders([shipped,delivery,cancel,unfinished,held],today)).flat().length,0);
  const restored=restoreHandover(shipped,'검증',today);
  assert.equal(partitionHandoverOrders([restored],today)['91-180'].length,1);
  assert.equal(restored.payment_status,'PAID','물류 복구가 결제를 취소하지 않는다');
});
test('네 아이콘의 건수는 주문 카드 기준이며 1개월 기본 아이콘은 만들지 않는다',()=>{
  const groups=partitionHandoverOrders([ready(0),ready(31),ready(32),ready(91),ready(181),ready(366)],today);
  const html=renderToStaticMarkup(createElement(HandoverAgeTabs,{value:'31-90',groups,onChange:()=>{}}));
  assert.equal((html.match(/<button/g)||[]).length,4);
  for(const b of HANDOVER_AGE_BANDS)assert.ok(html.includes(`handover-age-count-${b.id}`));
  assert.ok(html.includes('aria-pressed="true"'));
  assert.ok(!html.includes('handover-age-recent'));
  assert.equal(groups['31-90'].length,2);
});
test('보관 카드는 가나다순·실제 청구액·후불 경고·네 핵심 정보만 표시하고 상세 팝업으로 연결한다',()=>{
  const orders=sortCustomerJobs([ready(31,'z','하도윤'),ready(32,'a','강가람'),ready(33,'b','나하늘')],'name','release');
  assert.deepEqual(orders.map(o=>o.customerName),['강가람','나하늘','하도윤']);
  const html=renderToStaticMarkup(createElement(ArchivedHandoverGrid,{orders,onOpen:()=>{},registerCard:()=>{}}));
  assert.equal((html.match(/class="handover-archive-card"/g)||[]).length,3);
  for(const value of ['강가람','와이셔츠','5,000원','data-unpaid="true"','후불','aria-haspopup="dialog"'])assert.ok(html.includes(value),value);
  assert.ok(!html.includes('01000000000'));
  assert.ok(!html.includes('검증용 주소'));
  assert.ok(!html.includes('삭제'));
});
