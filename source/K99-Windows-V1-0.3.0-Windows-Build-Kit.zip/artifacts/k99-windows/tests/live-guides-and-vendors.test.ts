import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {RECEPTION_HELP} from '../src/guide-data';
import {CATALOG_DEFAULTS,receptionGroups} from '../src/price-catalog';

const src=(name:string)=>fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
test('접수용 일반 의류는 표시명만 변경하고 기존 품목 식별자·가격·순서를 보존한다',()=>{
  const rows=CATALOG_DEFAULTS.map(x=>({...x})),before=JSON.stringify(rows);
  const top=receptionGroups(rows).find(x=>x.category==='top')!;
  assert.equal(top.label,'일반 의류');
  assert.deepEqual(top.items.slice(0,6).map(x=>x.id),
    ['cardigan','shirt_casual','blouse','sweater','suit_jacket','suit_pants']);
  assert.equal(JSON.stringify(rows),before);
  for(const row of top.items){
    const original=rows.find(x=>x.id===row.id)!;
    assert.equal(row.generalPrice,original.generalPrice);
    assert.equal(row.premiumPrice,original.premiumPrice);
  }
});
test('ZIP 도움말 목록은 Electron 오프라인 번들에 포함하며 네트워크 JSON fetch를 요구하지 않는다',()=>{
  const manifest=JSON.parse(src('reception-help.json'));
  assert.deepEqual(RECEPTION_HELP,manifest.entries);
  assert.match(src('guide-data.ts'),/import manifest from '.\/reception-help.json'/);
  assert.doesNotMatch(src('guide-data.ts')+src('PictureGuide.tsx'),/fetch\(/);
  assert.equal(RECEPTION_HELP.flatMap(e=>e.pages).length,13);
});
test('여섯 항목은 ZIP 이름을 표시하며 구버전 로그인·좌표·도해 설명을 합성하지 않는다',()=>{
  assert.equal(RECEPTION_HELP.length,6);
  for(const entry of RECEPTION_HELP)assert.equal(entry.name,entry.path.split('/')[1]);
  assert.match(src('PictureGuide.tsx'),/guideImageUrl/);
  assert.doesNotMatch(src('PictureGuide.tsx'),/처음이면 영문|pg-pin-touch|GuideScene|OriginalGuideImage/);
});
test('회사 선택·상세 설정 분리와 USB 촬영 안내는 기존 실행 API를 호출하지 않는다',()=>{
  const hw=src('HardwareSettings.tsx'),nc=src('NoticeCenter.tsx');
  for(const vendor of ['easycheck','kis','nice'])assert.ok(hw.includes(`['${vendor}',`));
  assert.match(hw,/\{receiptDetails && <section/);
  // Same-company clicks must no longer disable a configured terminal.
  assert.match(hw,/action: 'select-receipt-vendor', vendor \}/);
  assert.doesNotMatch(hw,/selectedVendor === vendor \? 'none' : vendor/);
  assert.match(hw,/aria-pressed=\{selectedVendor === id\} disabled=\{!!busy\}/);
  assert.doesNotMatch(hw,/aria-pressed=\{selectedVendor === id\} disabled=\{[^}]*available/);
  const camera=nc.slice(nc.indexOf('function CameraPhoneBody'),nc.indexOf('const DISCOUNT_FIELDS'));
  assert.doesNotMatch(camera,/button-iriun-open|Iriun 설치·드라이버|cameraConnection/);
  assert.match(camera,/<IriunUsbGuide \/>/);assert.match(camera,/USB 표준 7단계/);
  assert.match(camera,/앱 설치 QR·주소 보기/);
});
