import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GUIDE_THEMES} from '../src/guide-data';
import {CATALOG_DEFAULTS,receptionGroups} from '../src/price-catalog';

const src=(name:string)=>fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
test('접수용 일반 의류는 표시명만 변경하고 기존 품목 식별자·가격·순서를 보존한다',()=>{
  const rows=CATALOG_DEFAULTS.map(x=>({...x})),before=JSON.stringify(rows);
  const top=receptionGroups(rows).find(x=>x.category==='top')!;
  assert.equal(top.label,'일반 의류');
  assert.deepEqual(top.items.slice(0,6).map(x=>x.id),
    ['cardigan','shirt_casual','blouse','sweater','suit_jacket','suit_pants']);
  assert.equal(JSON.stringify(rows),before);
  for(const row of top.items){
    const original=rows.find(x=>x.id===row.id)!;
    assert.equal(row.generalPrice,original.generalPrice);
    assert.equal(row.premiumPrice,original.premiumPrice);
  }
});
test('실사 도움말은 실제 파일과 좌표만 사용하고 Electron 오프라인에서 JSON fetch를 요구하지 않는다',()=>{
  const root=new URL('../public/guide-captures/',import.meta.url);
  const manifest=JSON.parse(fs.readFileSync(new URL('manifest.json',root),'utf8'));
  assert.deepEqual(JSON.parse(src('guide-captures.json')),manifest);
  for(const key of ['main','settings','hardware','receipt','phone','tag','excel','backup','ai-login']){
    const e=manifest[key];assert.ok(e,key);
    const b=fs.readFileSync(new URL(e.src,root));assert.ok(b.length>10000,key);
    assert.ok(e.width>0&&e.height>0);
    for(const point of Object.values(e.targets) as {x:number;y:number}[]){
      assert.ok(point.x>=0&&point.x<=100&&point.y>=0&&point.y<=100,key);
    }
  }
  const s=src('GuideCapture.tsx');
  assert.match(s,/import bundledManifest/);assert.doesNotMatch(s,/fetch\(/);
  assert.match(s,/pg-pin-touch/);
});
test('다섯 주제는 지정된 줄 단위로 표시하며 AI 초기 암호와 실제 설치 안내를 구분한다',()=>{
  assert.deepEqual(GUIDE_THEMES.map(t=>t.titleLines),[
    ['휴대폰','AI 도우미'],['PC 프로그램','설치'],['장비 · 매장','설정'],['실전 접수'],['엑셀 · 백업'],
  ]);
  const cards=GUIDE_THEMES.flatMap(t=>t.topics.flatMap(p=>p.cards));
  assert.doesNotMatch(cards.map(c=>c.body+c.title).join('\n'),/5자리 번호로 로그인|번호 5자리 입력/);
  assert.match(cards.find(c=>c.title==='로그인하기')!.body,/처음이면 영문 소문자 k/);
  assert.match(cards.find(c=>c.title==='로그인하기')!.body,/바꾼 분은 본인 비밀번호/);
  assert.match(src('PictureGuide.tsx'),/k99-ai-icon\.png/);
});
test('회사 선택·상세 설정 분리와 USB 촬영 안내는 기존 실행 API를 호출하지 않는다',()=>{
  const hw=src('HardwareSettings.tsx'),nc=src('NoticeCenter.tsx');
  for(const vendor of ['easycheck','kis','nice'])assert.ok(hw.includes(`['${vendor}',`));
  assert.match(hw,/\{receiptDetails && <section/);
  assert.match(hw,/selectedVendor === vendor \? 'none' : vendor/);
  const camera=nc.slice(nc.indexOf('function CameraPhoneBody'),nc.indexOf('const DISCOUNT_FIELDS'));
  assert.doesNotMatch(camera,/button-iriun-open|Iriun 설치·드라이버|cameraConnection/);
  assert.match(camera,/<IriunUsbGuide \/>/);assert.match(camera,/USB 표준 7단계/);
  assert.match(camera,/앱 설치 QR·주소 보기/);
});
