import { test } from 'node:test';
import assert from 'node:assert/strict';
import { composeKoreanEdit, composeKoreanInput, convertKoreanSearch } from '../src/korean-input-conversion';
import { koreanFieldPolicy } from '../src/korean-field-policy';
import { koreanEnabled } from '../src/korean-input-controls';

test('rkdgksmf 고객명은 연속 입력·즉시 입력 모두 강하늘로 변환된다', () => {
  assert.equal(composeKoreanInput('rkdgksmf'), '강하늘');
  let display = '';
  for (const key of 'rkdgksmf') display = composeKoreanEdit(display, display + key);
  assert.equal(display, '강하늘');
  assert.equal(convertKoreanSearch('rkdgksmf'), '강하늘');
  assert.equal(composeKoreanInput('tpxkr'), '세탁');
});
test('영문 모드로 넣은 모델명은 한글 모드 복귀 후에도 보존된다', () => {
  let text = 'TS-167 ';
  for (const key of 'tpxkr') text = composeKoreanEdit(text, text + key);
  assert.equal(text, 'TS-167 세탁');
  assert.equal(composeKoreanEdit('앞 뒤', '앞 rkdgksmf뒤'), '앞 강하늘뒤');
  assert.equal(composeKoreanEdit('강하늘 메모', '강 메모'), '강 메모');
});
test('각 텍스트 영역은 기본 한글, 숫자·암호·기술 식별자는 그대로 유지한다', () => {
  for (const signature of ['고객 이름 검색', '품목명', '소재 직접 입력', '색상', '특이사항 기록', '메모', '일기 찾기', '일기 내용'])
    assert.ok(koreanFieldPolicy({tag:'TEXTAREA',signature}), signature);
  for (const type of ['number','tel','password','email','url','date'])
    assert.equal(koreanFieldPolicy({tag:'INPUT',type}),null,type);
  for (const text of ['010-1234-5678','K99_123','D:\\K99과천매장\\01_고객세탁사진'])
    assert.equal(convertKoreanSearch(text),text);
  assert.equal(koreanEnabled({dataset:{koreanMode:'english'}} as unknown as HTMLElement),false);
  assert.equal(koreanEnabled({dataset:{}} as HTMLElement),true);
});
