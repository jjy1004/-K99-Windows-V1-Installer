import test from 'node:test';
import assert from 'node:assert/strict';
import {editDateBindings,refreshDateBindings,type NoticeDateBinding} from '../src/notice-date-bindings';
const body='고객님, 12월 31일까지 수거 / 1월 2일부터 보관료';
const bindings:NoticeDateBinding[]=[{start:5,end:13,token:'수거기한',value:'12월 31일'},{start:21,end:26,token:'보관료시작일',value:'1월 2일'}]
 .map(b=>({...b,start:body.indexOf(b.value),end:body.indexOf(b.value)+b.value.length}));
test('열어 둔 창도 발송 버튼 클릭 날짜로 +5/+7일을 다시 계산한다',()=>{
 const r=refreshDateBindings(body,bindings,new Date('2026-12-31T15:01:00Z'));
 assert.equal(r.body,'고객님, 1월 6일까지 수거 / 1월 8일부터 보관료');
 for(const b of r.dateBindings)assert.equal(r.body.slice(b.start,b.end),b.value);
});
test('직접 고친 날짜 하나는 보존하고 다른 자동 날짜만 갱신한다',()=>{
 const edited=body.replace('12월 31일','2월 15일'),tracked=editDateBindings(body,edited,bindings);
 assert.equal(tracked.length,1);const r=refreshDateBindings(edited,tracked,new Date('2026-12-31T15:01:00Z'));
 assert.equal(r.body,'고객님, 2월 15일까지 수거 / 1월 8일부터 보관료');
});
test('날짜 앞뒤 문구 편집·모바일 추가 시 날짜 범위를 유지한다',()=>{
 const edited='추가 설명: '+body+'\n고객 회신';
 const first='추가 설명: '+body;
 const tracked=editDateBindings(first,edited,editDateBindings(body,first,bindings));
 assert.equal(tracked.length,2);assert.match(refreshDateBindings(edited,tracked,new Date('2026-12-31T15:01:00Z')).body,/1월 6일까지.*1월 8일부터/);
});
test('전체 직접 교체·추적 정보 없는 과거 문안·고정 일정은 자동으로 덮어쓰지 않는다',()=>{
 const next='수거 약속은 12월 31일입니다.';
 assert.deepEqual(editDateBindings(body,next,bindings),[]);
 assert.equal(refreshDateBindings(next,[],new Date()).body,next);
 assert.equal(refreshDateBindings(body,[],new Date()).body,body);
});
test('동일 본문·반복 발송 갱신은 멱등이고 날짜 길이 변화도 추적한다',()=>{
 const same=editDateBindings(body,body,bindings);assert.deepEqual(same,bindings);
 const now=new Date('2026-12-31T15:01:00Z'),one=refreshDateBindings(body,same,now);
 assert.deepEqual(refreshDateBindings(one.body,one.dateBindings,now),one);
});
