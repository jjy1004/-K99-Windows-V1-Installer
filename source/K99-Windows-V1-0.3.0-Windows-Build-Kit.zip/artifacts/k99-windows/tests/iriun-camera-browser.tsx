// Isolated synthetic-stream harness. No operational API, DB, printer or phone.
import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {NativeDraftCamera,type DraftNativeUnit} from '../src/NativeDraftCamera';
const audit={streams:[] as MediaStream[],captures:[] as Record<string,unknown>[],sessions:[] as unknown[],final:0};
(window as any).iriunAudit=audit;
window.k99Desktop={iriunSession:async input=>{audit.sessions.push(input);return {installed:true,running:true};}};
const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=720;
const context=canvas.getContext('2d')!;
setInterval(()=>{
  context.fillStyle='#d4f1f9';context.fillRect(0,0,1280,720);
  context.fillStyle='#3184a3';context.fillRect(360,80,560,580);
  context.fillStyle='white';context.font='bold 32px sans-serif';context.fillText('검사용 합성 영상 · 실제 휴대폰 아님',340,190);
  context.fillText(String(Date.now()),400,270);
},80);
Object.defineProperty(navigator.mediaDevices,'enumerateDevices',{value:async()=>[
  {kind:'videoinput',deviceId:'usb',label:'SU200MB USB Webcam'},
  {kind:'videoinput',deviceId:'phone',label:'Iriun Webcam'},
]});
Object.defineProperty(navigator.mediaDevices,'getUserMedia',{value:async()=>{
  const stream=canvas.captureStream(15),track=stream.getVideoTracks()[0];
  Object.defineProperty(track,'label',{value:'Iriun Webcam'});
  track.getSettings=()=>({deviceId:'phone',width:1280,height:720});
  audit.streams.push(stream);return stream;
}});
window.fetch=async(input,init)=>{
  const url=String(input);
  if(url==='/api/equipment/state')return Response.json({native:true,config:{mode:'real'},orders:[],photos:[],jobs:[]});
  const body=JSON.parse(String(init?.body||'{}'));
  if(url==='/api/equipment/command'&&body.action==='tag-policy')return Response.json({mode:'printer',lastNumber:'1-0'});
  if(url==='/api/equipment/command'&&body.action==='capture-draft'){
    audit.captures.push(body);
    return Response.json({garment:{garmentId:body.unitKey,orderId:body.orderId,...body,
      photoHistory:audit.captures.filter(c=>c.unitKey===body.unitKey).map(c=>({requestId:c.requestId}))},job:{status:'submitted'}});
  }
  return Response.json({error:'검사용 통신 격리: 외부·장부 API 접근 금지'},{status:403});
};
function App(){
  useEffect(()=>{const timer=setTimeout(()=>window.dispatchEvent(new Event('k99:open-intake-camera')),100);return()=>clearTimeout(timer);},[]);
  const [units,setUnits]=useState<DraftNativeUnit[]>([]);
  const [label,setLabel]=useState({manualMaterial:'폴리에스테르',manualColor:'유색'} as const);
  return <NativeDraftCamera orderId="iriun-ui-audit" customerName="검증고객" customerPhone="01000000000"
    targets={[{rowId:1,itemId:'shirt',itemName:'와이셔츠',unitIndex:1,rowQuantity:1},
      {rowId:2,itemId:'coat',itemName:'코트',unitIndex:1,rowQuantity:1}]}
    units={units} labelSelection={label} onSelectLabel={v=>setLabel(v as typeof label)}
    onCaptured={u=>setUnits(old=>[...old.filter(x=>x.unitKey!==u.unitKey),u])}
    onFinalConfirm={()=>{audit.final++;}}/>;
}
createRoot(document.getElementById('root')!).render(<App/>);
