import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createConfirmedOrder, readAllConfirmedOrders, readConfirmedOrders } from '../src/order-record';
import { createGarmentRecords } from '../src/garment-record';
import { completeFieldInspection } from '../src/field-inspection';
import { advanceGarmentInOrder } from '../src/laundry-process';
import { completeFieldQuality } from '../src/field-quality';
import { deleteOrderAsStaff } from '../src/order-deletion';
import { isReadyForHandover } from '../src/order-handover';
import { findSavedGarment } from '../src/garment-scanner';
const require = createRequire(import.meta.url);
const {createStore} = require('../../../lib/k99-local/index.cjs');
const KEY = 'k99-confirmed-orders-v1';
const choices = {serviceLevel:'general' as const,pickupRequested:false,deliveryRequested:false,directPickup:true,
  requestedPickupDate:'',waiver:'not-requested' as const,luxuryItem:false,customerRequests:''};

function ready(id:string, at:Date) {
  const base = createConfirmedOrder({id,customerName:`검증${id}`,customerPhone:'01000001234',customerAddress:'',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},choices,at);
  let order = completeFieldInspection({...base,garments:createGarmentRecords(base)}, {}, at);
  for (const g of order.garments!) {
    order = advanceGarmentInOrder(order,g.garmentId,'start','manual','',at);
    order = advanceGarmentInOrder(order,g.garmentId,'complete','manual','',at);
  }
  return completeFieldQuality(order,undefined,at);
}

test('release soft delete commits to real SQLite and excludes order from every period, notices, directory and barcode after reopen', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(),'k99-release-delete-')),filename=path.join(root,'k99.db');
  let store = createStore(filename,'test-only',{nativeDesktop:true});
  const oldWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),oldEvent=Object.getOwnPropertyDescriptor(globalThis,'StorageEvent');
  t.after(()=>{
    if(oldWindow)Object.defineProperty(globalThis,'window',oldWindow);else Reflect.deleteProperty(globalThis,'window');
    if(oldEvent)Object.defineProperty(globalThis,'StorageEvent',oldEvent);else Reflect.deleteProperty(globalThis,'StorageEvent');
    store.close();fs.rmSync(root,{recursive:true,force:true});
  });
  // Only renderer storage/event transport is substituted; all writes and queries use the real temporary SQLite store.
  const bus=new EventTarget(),seen=new Map<string,string|null>();
  const storage={
    getItem:(key:string)=>{const v=store.storage({op:'get',key});seen.set(key,v);return v;},
    setItem:(key:string,value:string)=>{if(!seen.has(key))storage.getItem(key);store.storage({op:'set',key,value,expected:seen.get(key)});seen.set(key,value);},
    removeItem:(key:string)=>{if(!seen.has(key))storage.getItem(key);store.storage({op:'remove',key,expected:seen.get(key)});seen.set(key,null);},
  };
  Object.defineProperty(globalThis,'window',{configurable:true,value:{localStorage:storage,k99Desktop:{},
    dispatchEvent:bus.dispatchEvent.bind(bus)}});
  Object.defineProperty(globalThis,'StorageEvent',{configurable:true,value:class extends Event {
    key:string;constructor(type:string,init:{key:string}){super(type);this.key=init.key;}
  }});
  const at=new Date(),target=ready('DELETE-TARGET',at),control=ready('KEEP-CONTROL',at);
  storage.setItem(KEY,JSON.stringify([target,control]));
  let refreshEvents=0;bus.addEventListener('storage',()=>refreshEvents++);
  const date=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(at);
  const stats=(mode:string,period:string)=>store.api('GET',`/api/customers/statistics?mode=${mode}&period=${period}`).summary;
  assert.equal(readConfirmedOrders().filter(isReadyForHandover).length,2);
  assert.equal(store.api('GET','/api/pickup-notices').recommendedCount,2);
  assert.ok(findSavedGarment(target.garments![0].barcodeValue));
  await deleteOrderAsStaff(target);
  assert.equal(refreshEvents,1,'immediate same-renderer refresh notification');
  assert.equal(readConfirmedOrders().filter(isReadyForHandover).length,1);
  assert.equal(findSavedGarment(target.garments![0].barcodeValue),null);
  assert.equal(store.api('GET','/api/pickup-notices').recommendedCount,1);
  assert.ok(!store.api('GET','/api/pickup-notices').orders.some((o:{id:string})=>o.id===target.id));
  for(const [mode,period] of [['day',date],['month',date.slice(0,7)],['year',date.slice(0,4)]]){
    const summary=stats(mode,period);
    assert.equal(summary.orderCount,1);assert.equal(summary.itemCount,2);assert.equal(summary.totalAmount,control.laundryTotal);
  }
  const all=readAllConfirmedOrders(),deleted=all.find(o=>o.id===target.id)!;
  assert.ok(deleted.orderDeletion?.deletedAt);
  assert.deepEqual(deleted.garments,target.garments,'garment/photo/tag metadata retained');
  assert.deepEqual(all.find(o=>o.id===control.id),JSON.parse(JSON.stringify(control)),'other order not modified');
  assert.ok(!store.api('GET','/api/customers/directory').customers.flatMap((c:{visits:unknown[]})=>c.visits).some((v:{id:string})=>v.id===target.id));
  await assert.rejects(()=>deleteOrderAsStaff(target),/변경/,'stale card cannot delete or overwrite twice');
  store.close();store=createStore(filename,'test-only',{nativeDesktop:true});seen.clear();
  assert.equal(readAllConfirmedOrders().length,2,'logical deletion retains recoverable original');
  assert.equal(readConfirmedOrders().length,1);
  assert.equal(store.api('GET','/api/pickup-notices').recommendedCount,1);
  assert.equal(stats('day',date).orderCount,1);
  const paid={...control,operations:{...control.operations!,paidAmount:10000,paymentStatus:'결제완료' as const}};
  storage.setItem(KEY,JSON.stringify([deleted,paid]));
  const before=storage.getItem(KEY);
  await assert.rejects(()=>deleteOrderAsStaff(paid),/결제·환불/);
  assert.equal(storage.getItem(KEY),before,'existing financial history safeguard retained');
});

test('release deletion confirmation and refresh wiring never bypass existing persistence and safety checks',()=>{
  const source=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
  const screen=source('GarmentScannerWorkspace.tsx');
  assert.match(screen,/button-delete-ready-order-/);
  assert.match(screen,/통계 및 알림 대상에서 완전히 제외됩니다/);
  assert.match(screen,/<OrderDeletionDialog/);
  assert.match(screen,/if \(deleting\) \{ burst\.current/);
  assert.match(screen,/setHandoverScans\(\{\}\); setBarcode\(''\)/);
  for(const file of ['PickupNoticeActions.tsx','SimpleStatisticsCenter.tsx','ManagementCustomerPanel.tsx']){
    const s=source(file);
    assert.match(s,/addEventListener\('storage'/);assert.match(s,/removeEventListener\('storage'/);
  }
});
