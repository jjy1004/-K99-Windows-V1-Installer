import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createConfirmedOrder } from '../src/order-record';
import { createGarmentRecords } from '../src/garment-record';
import { completeFieldInspection } from '../src/field-inspection';
import { completeFieldQuality } from '../src/field-quality';
import { duePickupNoticeStage, pickupNoticeText, markPickupNoticeSent, pickupCompletionDates } from '../src/customer-pickup-notices';
import { completionNoticeText } from '../src/customer-notice-text';
import { careNoticeTemplate } from '../src/care-notice-templates';
import { noticeDraft } from '../src/process-stage';
import { guidanceMessage } from '../src/inspection-guidance';
import { advanceGarmentInOrder } from '../src/laundry-process';

const choices = { serviceLevel: 'general' as const, pickupRequested: false, deliveryRequested: false,
  directPickup: true, requestedPickupDate: '', waiver: 'not-requested' as const, luxuryItem: false, customerRequests: '없음' };
const at = new Date('2026-10-20T15:10:00Z'); // Oct 21 KST
function readyForQC() {
  const base = createConfirmedOrder({ id: 'QC-1', customerName: '고객', customerPhone: '5678', customerAddress: '',
    items: [{ itemId: 'shirt_dress', displayNameKo: '와이셔츠', quantity: 2, generalPrice: 5000, premiumPrice: 9000, isSneaker: false }] },
  choices, new Date('2026-09-01T03:00:00Z'));
  let order = completeFieldInspection({ ...base, garments: createGarmentRecords(base) }, {}, at);
  for (const g of order.garments!) {
    order = advanceGarmentInOrder(order, g.garmentId, 'start', 'manual', '', at);
    order = advanceGarmentInOrder(order, g.garmentId, 'complete', 'manual', '', at);
  }
  return order;
}

test('manual final QC needs no completion/comparison photos or scanner; bulk is idempotent', () => {
  const order = readyForQC();
  const before = JSON.stringify(order);
  const one = completeFieldQuality(order, order.garments![0].garmentId, at);
  assert.equal(one.garments![0].completionStatus, 'complete');
  assert.notEqual(one.garments![1].completionStatus, 'complete');
  assert.equal(one.orderCompletedAt, undefined);
  const done = completeFieldQuality(one, undefined, at);
  assert.equal(done.status, '전체 세탁 완료 / 반출 대기');
  assert.equal(done.operations?.stage, '세탁완료');
  assert.equal(done.orderCompletedAt, at.toISOString());
  assert.equal(done.estimatedTotal, order.estimatedTotal);
  assert.ok(done.garments!.every(g => g.completionStatus === 'complete' && g.processStatus === '출고 대기'));
  assert.ok(done.garments!.every(g => !g.completionPhoto && !g.scannedAt && g.completionMethod === 'manual'));
  assert.equal(JSON.stringify(completeFieldQuality(done, undefined, new Date('2026-11-01'))), JSON.stringify(done));
  assert.equal(JSON.stringify(order), before, 'pure transform does not mutate input');
});

test('final QC never fakes unfinished work or partially commits a failed bulk', () => {
  const order = readyForQC();
  order.garments![1].processStatus = '세탁 중';
  const before = JSON.stringify(order);
  assert.throws(() => completeFieldQuality(order, undefined, at), /세탁 완료/);
  assert.equal(JSON.stringify(order), before);
  assert.throws(() => completeFieldQuality({ ...order, operations: { ...order.operations!, cancelledAt: at.toISOString() } }, undefined, at), /취소/);
  assert.throws(() => completeFieldQuality(order, 'not-in-order', at), /없는/);
});

test('one bulk final action completes every eligible garment without individual QC clicks', () => {
  const order = readyForQC();
  const before = JSON.stringify(order);
  assert.ok(order.garments!.every(g => g.completionStatus !== 'complete'));
  const done = completeFieldQuality(order, undefined, at);
  assert.ok(done.garments!.every(g => g.completionStatus === 'complete' && g.processStatus === '출고 대기'));
  assert.equal(done.status, '전체 세탁 완료 / 반출 대기');
  assert.equal(done.orderCompletedAt, at.toISOString());
  assert.equal(done.estimatedTotal, order.estimatedTotal);
  assert.equal(JSON.stringify(order), before);
  assert.equal(JSON.stringify(completeFieldQuality(done, undefined, at)), JSON.stringify(done));
});

test('one-click final QC does not override an existing hold or partially mutate the order', () => {
  const order = readyForQC();
  order.garments![1].qcHoldReason = '직원 재확인 필요';
  const before = JSON.stringify(order);
  assert.throws(() => completeFieldQuality(order, undefined, at), /보류|추가 확인/);
  assert.equal(JSON.stringify(order), before);
});

test('completion eligibility with intake +7/+12 Seoul boundaries and no fabricated earlier sends', () => {
  const older = completeFieldQuality(readyForQC(), undefined, at);
  assert.equal(duePickupNoticeStage(older, at), 'day12');
  const done = { ...older, intakeAt: '2026-10-20T15:00:00Z' };
  assert.deepEqual(pickupCompletionDates(done), { completed: '2026-10-21', day7: '2026-10-28', day12: '2026-11-02' });
  assert.equal(duePickupNoticeStage(done, '2026-10-20T14:59:00Z'), null);
  assert.equal(duePickupNoticeStage(done, at), 'completion');
  assert.equal(duePickupNoticeStage(done, '2026-10-27T14:59:59Z'), 'completion');
  assert.equal(duePickupNoticeStage(done, '2026-10-27T15:00:00Z'), 'day7');
  assert.equal(duePickupNoticeStage(done, '2026-11-01T14:59:59Z'), 'day7');
  assert.equal(duePickupNoticeStage(done, '2026-11-01T15:00:00Z'), 'day12');
  const sent = markPickupNoticeSent(done, 'day12', 'day12', new Date('2026-11-01T15:00:00Z'));
  assert.equal(sent.pickupNoticeLog?.length, 1);
  assert.equal(duePickupNoticeStage(sent, '2026-11-10'), null);
  for (const kind of ['direct-pickup', 'delivery', 'day7', 'day12'] as const)
    assert.match(pickupNoticeText(done, kind), kind==='day12'?/^안녕하세요, 고객님\. K99 /:/^안녕하세요, K99 /);
  assert.equal(completionNoticeText(done), pickupNoticeText(done, 'direct-pickup'));
});

test('all three official templates share field/guidance paths; variables and fee placeholder preserved', () => {
  const o = readyForQC();
  for (const kind of ['waiver', 'fee', 'both'] as const) {
    const expected = careNoticeTemplate(kind, o.customerName, '와이셔츠 2점', 3000);
    assert.equal(noticeDraft(o, kind, 3000), expected);
    assert.equal(guidanceMessage(o, { ...o.inspection!, feeItemName: '와이셔츠 2점', guidanceKind: kind, additionalCharge: 3000 }), expected);
    assert.match(expected, /\[와이셔츠 2점\]/);
    assert.ok(!expected.includes('${'));
    if (kind !== 'waiver') {
      assert.match(expected, /3,000원/);
      assert.match(careNoticeTemplate(kind, '고객', '품목', 0), /00,000원/);
    }
  }
  assert.match(noticeDraft(o, 'waiver', 0), /관련 법령에 따릅니다/);
  assert.match(noticeDraft(o, 'both', 3000), /특별 케어 동의합니다/);
});
