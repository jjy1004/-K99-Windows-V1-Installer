import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {CustomerPrivacySettings, maskCustomerPhone, IMPORT_PRIVACY_NOTICE} from '../src/CustomerPrivacySettings';
const source=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');

test('phone masking changes display only, preserves last4 and never leaks short or malformed values',()=>{
  assert.equal(maskCustomerPhone('010-0000-1234',true),'010-****-1234');
  assert.equal(maskCustomerPhone('01000001234',true),'010-****-1234');
  assert.equal(maskCustomerPhone('1234',true),'****');
  assert.equal(maskCustomerPhone('',true),'');
  assert.equal(maskCustomerPhone('010-0000-1234',false),'010-0000-1234');
});
test('privacy settings use credential password inputs without Korean automata or browser credential storage',()=>{
  const html=renderToStaticMarkup(React.createElement(CustomerPrivacySettings));
  assert.equal((html.match(/type="password"/g)||[]).length,2);
  assert.match(html,/고객 명부 엑셀\(CSV\) 저장 시에만/);
  assert.match(html,/DB 암호화가 아닙니다/);
  const security=source('CustomerPrivacySettings.tsx');
  assert.doesNotMatch(security,/localStorage|sessionStorage|console\.log/);
  assert.match(security,/composing\.current/);
  assert.match(security,/current\.current\?\.value/);
});
test('settings are placed only in store settings, not the phone helper, and export authorises before save',()=>{
  const center=source('NoticeCenter.tsx'),start=center.indexOf('function StoreSettings(');
  assert.ok(center.indexOf('<CustomerPrivacySettings />')>start);
  const main=fs.readFileSync(new URL('../electron/main.cjs',import.meta.url),'utf8');
  assert.match(main,/authorize:password=>store\.api\('POST','\/api\/admin\/password\/check',\{password\}\)/);
  const panel=source('ManagementCustomerPanel.tsx');
  assert.match(panel,/downloadCustomerDirectory\(filtered, password\)/);
  assert.match(panel,/maskCustomerPhone\(c\.phone, maskPhones\)/);
  assert.match(panel,/maskCustomerPhone\(selected\.phone, maskPhones\)/);
});
test('both successful ledger import paths prompt to delete source copies, with no automatic deletion',()=>{
  assert.equal(IMPORT_PRIVACY_NOTICE,'고객 정보 등록이 완료되었습니다. 매장 내 개인정보 유출 방지를 위해 PC에 남아 있는 원본 엑셀 파일은 반드시 삭제해 주세요.');
  for(const file of ['CustomerDirectory.tsx','NativeLedgerImportPanel.tsx'])
    assert.match(source(file),/window\.alert\(IMPORT_PRIVACY_NOTICE\)/);
});
