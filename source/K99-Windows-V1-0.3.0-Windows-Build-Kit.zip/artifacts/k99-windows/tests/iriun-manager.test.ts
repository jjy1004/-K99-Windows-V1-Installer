import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createIriunManager, type CameraState} from '../src/iriun-manager';
import {openIriunCamera, retireIriunContext} from '../src/iriun-camera';
import type {IriunContext} from '../src/iriun-context';

function fixture(id: string) {
  const track = {label: 'Iriun Webcam', readyState: 'live', stops: 0,
    getSettings: () => ({deviceId: id}),
    stop() {this.stops++; this.readyState = 'ended';}};
  const stream = {getVideoTracks: () => [track], getTracks: () => [track]} as unknown as MediaStream;
  return {track, stream};
}
function setup(overrides: Parameters<typeof createIriunManager>[0] = {}) {
  const states: CameraState[] = [], contexts: {retired: boolean; media: MediaDevices}[] = [];
  const video = {srcObject: null} as unknown as HTMLVideoElement;
  const streams: ReturnType<typeof fixture>[] = [];
  const manager = createIriunManager({
    events: new EventTarget(),
    context: async () => {
      const id = `fresh-${contexts.length}`;
      const media = {enumerateDevices: async () => [{kind: 'videoinput', label: 'Iriun Webcam', deviceId: id}],
        getUserMedia: async () => {const f = fixture(id); streams.push(f); return f.stream;}} as unknown as MediaDevices;
      const record = {retired: false, media}; contexts.push(record);
      return {media, dispose() {record.retired = true; retireIriunContext(media);}};
    },
    open: (media, signal, _inspect, _timeout, options) =>
      openIriunCamera(media, signal, async () => {}, 25, options),
    show: async (v, stream) => {v.srcObject = stream;},
    watch: () => () => {},
    freshness: () => ({frame(){},sample:()=>({usable:true,pixelAvailable:true,frozenForMs:0,stalledForMs:0})}),
    delay: async () => {},
    schedule: () => () => {},
    ...overrides,
  });
  const owner = {};
  const binding = {video: () => video, change: (s: CameraState) => states.push(s)};
  return {manager, owner, binding, contexts, streams, video, states};
}
test('a hung native request retires ONLY its capture context; late results cannot steal the new stream', async () => {
  const retired: boolean[] = [];
  const late = fixture('old');
  let finish!: (stream: MediaStream) => void, count = 0;
  const f = setup({context: async () => {
    const index = count++, media = {
      enumerateDevices: async () => [{kind: 'videoinput', label: 'Iriun Webcam', deviceId: index ? 'new' : 'old'}],
      getUserMedia: () => index ? Promise.resolve(fixture('new').stream) : new Promise<MediaStream>(r => {finish = r;}),
    } as unknown as MediaDevices;
    if (index) assert.equal(retired[0], true, 'old document must be inactive before another native request');
    return {media, dispose() {retired[index] = true; retireIriunContext(media);}};
  }});
  const posDraft = {customer: '보존 고객', items: [{id: 'unchanged', price: 19000}], payment: 'postpaid'};
  const before = JSON.stringify(posDraft);
  await f.manager.start(f.owner, f.binding);
  assert.equal(count, 2); assert.equal(f.manager.state().phase, 'ready');
  const live = f.video.srcObject;
  finish(late.stream); await new Promise(r => setImmediate(r));
  assert.equal(late.track.readyState, 'ended');
  assert.equal(f.video.srcObject, live); assert.equal(JSON.stringify(posDraft), before);
  f.manager.stop(f.owner); assert.equal(f.video.srcObject, null); assert.equal(retired[1], true);
});
test('15회 후에도 1초 간격의 취소 가능한 다음 탐색을 계속한다', async () => {
  const waits: number[] = [], timers: {fn: () => void; ms: number; cancelled: boolean}[] = [];
  let opens = 0;
  const f = setup({
    open: async () => {opens++; throw Error('수신기 대기');},
    delay: async (_signal, ms) => {waits.push(ms);},
    schedule: (fn, ms) => {const t = {fn, ms, cancelled: false}; timers.push(t); return () => {t.cancelled = true;};},
  });
  await f.manager.start(f.owner, f.binding);
  assert.equal(opens, 15); assert.deepEqual(waits, Array(14).fill(1000));
  assert.equal(f.manager.state().phase, 'connecting'); assert.equal(timers[0].ms, 1000);
  assert.ok(f.contexts.every(c => c.retired));
  f.manager.stop(f.owner); assert.equal(timers[0].cancelled, true);
  timers[0].fn(); await new Promise(r => setImmediate(r)); assert.equal(opens, 15);
});
test('permission denial never launches 15 retries or a popup/cooldown storm', async () => {
  let opens = 0, schedules = 0;
  const f = setup({open: async () => {opens++; throw new DOMException('차단', 'NotAllowedError');},
    schedule: () => {schedules++; return () => {};},
  });
  await f.manager.start(f.owner, f.binding);
  assert.equal(opens, 1); assert.equal(schedules, 0); assert.equal(f.manager.state().phase, 'blocked');
  assert.ok(f.contexts[0].retired); f.manager.stop(f.owner);
});
test('two capture surfaces cannot occupy the camera together; repeated start deduplicates pending opens', async () => {
  let release!: () => void;
  const f = setup({show: () => new Promise<void>(r => {release = r;})});
  const pending = f.manager.start(f.owner, f.binding);
  await new Promise(r => setImmediate(r));
  const repeated = f.manager.start(f.owner, f.binding);
  let other: CameraState | undefined;
  await f.manager.start({}, {...f.binding, change: state => {other = state;}});
  assert.equal(other?.phase, 'error'); assert.equal(f.contexts.length, 1);
  f.manager.stop({}); assert.equal(f.streams[0].track.readyState, 'live');
  release(); await Promise.all([pending, repeated]);
  assert.equal(f.manager.state().phase, 'ready'); f.manager.stop(f.owner);
});
test('closing while a capture document loads disposes the late context without opening its camera', async () => {
  let ready!: (ctx: IriunContext) => void, disposed = 0, opened = 0;
  const f = setup({context: () => new Promise(r => {ready = r;}),
    open: async () => {opened++; return fixture('late').stream;}});
  const pending = f.manager.start(f.owner, f.binding);
  f.manager.stop(f.owner);
  ready({media: {} as MediaDevices, dispose() {disposed++;}});
  await pending; assert.equal(disposed, 1); assert.equal(opened, 0);
  assert.equal(f.manager.state().phase, 'idle');
});
test('watchdog recovery and Windows resume share one controller and release every old track', async () => {
  const events = new EventTarget();
  let fault!: (reason: string) => void, removed = 0;
  const f = setup({events, watch: (_video, _stream, options) => {
    fault = options.recover; return () => {removed++;};
  }});
  await f.manager.start(f.owner, f.binding);
  fault('영상 멈춤');
  await f.manager.start(f.owner, f.binding);
  assert.equal(f.streams[0].track.readyState, 'ended'); assert.equal(f.contexts.length, 2);
  events.dispatchEvent(new Event('k99-camera-resume'));
  await f.manager.start(f.owner, f.binding);
  assert.equal(f.streams[1].track.readyState, 'ended'); assert.equal(f.contexts.length, 3);
  assert.equal(f.manager.state().phase, 'ready');
  f.manager.stop(f.owner); assert.equal(removed, 3);
  events.dispatchEvent(new Event('online')); assert.equal(f.contexts.length, 3);
});
test('returning to a visible window retries failed connection without waiting for cooldown', async () => {
  const page=Object.assign(new EventTarget(),{hidden:true});
  let fail=true,opened=0,prepared=0,released=0;
  const f=setup({page,open:async()=>{
    opened++;if(fail)throw Error('전화 수신 대기');return fixture('resumed').stream;
  }});
  const binding={...f.binding,prepare:()=>{prepared++;},released:()=>{released++;}};
  await f.manager.start(f.owner,binding);assert.equal(opened,15);
  fail=false;page.hidden=false;page.dispatchEvent(new Event('visibilitychange'));
  await f.manager.start(f.owner,binding);
  assert.equal(f.manager.state().phase,'ready');assert.equal(opened,16);assert.equal(prepared,2);
  f.manager.stop(f.owner);assert.equal(released,1);
});
