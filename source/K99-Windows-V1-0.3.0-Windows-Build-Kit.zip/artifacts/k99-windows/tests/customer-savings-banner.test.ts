import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('../src/CustomerSavingsBanner.tsx',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/customer-savings-banner.css',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
test('고객 상단 절약 안내는 적립금 두 종류와 실제 이용 혜택을 크게 표시한다',()=>{
 for(const label of ['세탁비 절약 방법','10만 원','11만 원 이용','20만 원','23만 원 이용'])assert.ok(source.includes(label),label);
 assert.match(css,/position:sticky;top:0/);assert.match(css,/\.csb-title\{font-size:32px/);
});
test('느린 밝기 페이드는 유한 7회 후 선명한 상태로 종료하고 동작 줄이기를 존중한다',()=>{
 assert.match(css,/animation:csb-soft 3\.6s ease-in-out 0s 7 forwards/);
 assert.match(css,/0%,100%\{opacity:1;filter:brightness\(1\)/);
 assert.match(css,/prefers-reduced-motion:reduce/);assert.match(css,/animation:none/);
});
test('일반 품목·금액 변경이 아닌 새 접수 세션에서만 7회가 다시 시작한다',()=>{
 assert.match(app,/<CustomerSavingsBanner sessionKey=\{payload\.sourceId\}/);
 assert.match(source,/key=\{sessionKey\}/);assert.doesNotMatch(source,/payload\.revision|rows\.length/);
});
