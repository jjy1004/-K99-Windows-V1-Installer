import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {NumUnit} from '../src/NumUnit';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const css=fs.readFileSync(path.join(root,'src/readability.css'),'utf8');
test('가독성 보완의 모든 규칙은 화면 매체에만 적용한다',()=>{
  const req=createRequire(path.join(root,'package.json'));
  const postcss=createRequire(req.resolve('vite'))('postcss');
  const ast=postcss.parse(css);
  for(const n of ast.nodes)if(n.type!=='comment')assert.equal(n.type==='atrule'&&n.name==='media'&&n.params==='screen',true);
  assert.doesNotMatch(css,/@page|:\s*(?:30|10)mm/);
});
test('숫자와 단위 묶음은 텍스트·금액·공백·날짜를 변경하지 않는다',()=>{
  for(const text of ['10만 원','+2,000원','1점당','7일 차','11월 28일','23시 59분','10000명']){
    const out=renderToStaticMarkup(createElement(NumUnit,null,text));
    assert.match(out,/k99-num-unit/);
    assert.equal(out.replace(/<[^>]+>/g,''),text);
  }
  const out=renderToStaticMarkup(createElement(NumUnit,null,['+',2000,'원']));
  assert.equal(out.replace(/<[^>]+>/g,''),'+2000원');
});
test('표시 전용 묶음은 입력값·저장소·메시지를 수정하지 않는다',()=>{
  const source=fs.readFileSync(path.join(root,'src/NumUnit.tsx'),'utf8');
  assert.doesNotMatch(source,/MutationObserver|innerHTML|textContent|localStorage|sessionStorage|fetch\s*\(|noticeApi|onChange/);
  assert.match(css,/white-space:\s*nowrap/);
});
test('원본 애니메이션의 7회·3.6초·고정 종료를 유지한다',()=>{
  const source=fs.readFileSync(path.join(root,'src/customer-savings-banner.css'),'utf8');
  assert.match(source,/animation:csb-soft 3\.6s ease-in-out 0s 7 forwards/);
  assert.match(source,/0%,100%\{opacity:1;filter:brightness\(1\)/);
  assert.match(source,/@media\(prefers-reduced-motion:reduce\)/);
});
test('업무 카드는 열 수와 글씨 크기 변경 없이 필요한 높이로 확장한다',()=>{
  assert.match(css,/grid-auto-rows:\s*minmax\(var\(--job-card-h\),\s*max-content\)/);
  assert.match(css,/\.customer-job-grid\s*>\s*\.customer-job-card\s*\{[^}]*height:\s*auto;[^}]*min-height:\s*var\(--job-card-h\)/);
  assert.match(css,/\.jc-body\s*\{[^}]*flex:\s*1 0 auto;[^}]*min-height:\s*max-content/);
  assert.match(css,/\.jc-who\s*\{[^}]*padding-right:\s*70px/);
  const cardRules=css.slice(css.indexOf('html .job-page .customer-job-grid'));
  assert.doesNotMatch(cardRules,/font-size:|grid-template-columns:|order:/);
});
