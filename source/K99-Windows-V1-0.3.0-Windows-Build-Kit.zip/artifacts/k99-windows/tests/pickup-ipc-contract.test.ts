import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { listPickupNotices, markPickupNotice } from '../src/pickup-notices-client';
const require = createRequire(import.meta.url);
const { createStore } = require('../../../lib/k99-local/index.cjs');

test('renderer request contract reaches real temporary SQLite and refreshes persisted sent state', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'k99-notice-contract-'));
  const store = createStore(path.join(root, 'k99.db'), 'unit-contract', { nativeDesktop: true });
  const old = Object.getOwnPropertyDescriptor(globalThis, 'window');
  t.after(() => {
    if (old) Object.defineProperty(globalThis, 'window', old); else Reflect.deleteProperty(globalThis, 'window');
    store.close(); fs.rmSync(root, { recursive: true, force: true });
  });
  // Only the IPC transport is substituted. Customer/order persistence and queries are actual SQLite.
  Object.defineProperty(globalThis, 'window', { configurable: true, value: { k99Desktop: {
    request: async (input: { method: string; path: string; body: unknown }) => {
      try { return { ok: true, result: store.api(input.method, input.path, input.body) }; }
      catch (e) { return { ok: false, error: (e as Error).message }; }
    },
  } } });
  const now = new Date().toISOString();
  const order = { id: 'contract-order', customerName: '단위검증', customerPhone: '01000001234', customerAddress: '',
    intakeAt: now, orderCompletedAt: now, status: '전체 세탁 완료 / 반출 대기', totalQuantity: 1, estimatedTotal: 5000,
    choices: { deliveryRequested: false }, items: [{ displayNameKo: '셔츠', quantity: 1 }] };
  store.storage({ op: 'set', key: 'k99-confirmed-orders-v1', value: JSON.stringify([order]), expected: null });
  const first = await listPickupNotices();
  assert.equal(first.recommendedCount, 1);
  const marked = await markPickupNotice(order.id, 'direct-pickup', first.orders[0].cards[0].text);
  assert.equal(marked.recommendedCount, 0);
  const refreshed = await listPickupNotices();
  assert.ok(refreshed.orders[0].cards[0].sentAt);
  assert.equal(refreshed.orders[0].cards[0].text, first.orders[0].cards[0].text);
});
