// 실제 공통 안내 컴포넌트 검사용. 제품 진입점·DB·카메라·장비 API에 접근하지 않는다.
import { createRoot } from 'react-dom/client';
import { IriunDownloads, IriunUsbGuide } from '../src/IriunUsbGuide';
import { CameraSetupGuide } from '../src/CameraSetupGuide';
import { PictureGuide } from '../src/PictureGuide';
import '../src/picture-guide.css';

const downloads = new URLSearchParams(location.search).get('view') === 'downloads';
const view = new URLSearchParams(location.search).get('view');
document.body.style.cssText = 'margin:0;padding:30px;background:#172b35;font-family:"Malgun Gothic",sans-serif';
createRoot(document.getElementById('root')!).render(view === 'originals'
  ? <PictureGuide onClose={() => {}} />
  : view === 'camera'
  ? <CameraSetupGuide open onClose={() => {}} />
  :
  <main style={{ maxWidth: 1160, margin: '0 auto', padding: 30, background: '#fffdf7', borderRadius: 20 }}>
    <h1 style={{ fontSize: 34, color: '#172a31' }}>촬영용 휴대폰 · USB 데이터 케이블 표준 안내</h1>
    {downloads ? <IriunDownloads /> : <IriunUsbGuide slides />}
  </main>,
);
