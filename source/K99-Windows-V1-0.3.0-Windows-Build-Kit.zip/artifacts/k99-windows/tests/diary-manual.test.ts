import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { LaundryDiary } from '../src/LaundryDiary';

test('세탁 일기는 음성·AI·키워드 확인 팝업 없이 본문과 선택 키워드 다섯 칸을 표시한다', () => {
  const html = renderToStaticMarkup(React.createElement(LaundryDiary, { onClose() {} }));
  assert.match(html, /input-diary-content/);
  assert.doesNotMatch(html, /말로 기록하기|음성 파일|AI 정리본 보기|원문 근거|추출된 키워드|dialog-diary-keywords/);
  assert.equal((html.match(/data-testid="input-diary-keyword-\d"/g) || []).length, 5);
  for (let i = 0; i < 5; i++) {
    assert.match(html, new RegExp(`for="ldy-keyword-${i}"`));
    assert.ok(html.includes(`id="ldy-keyword-${i}"`));
  }
  assert.match(html, /모두 비워 두어도 저장할 수 있습니다/);
  assert.doesNotMatch(html, /readonly=""|onpaste=|required=""/i);
});

test('직접 본문을 저장 요청에 그대로 보내고 키워드 변경도 미저장 확인에 포함한다', () => {
  const src = fs.readFileSync(new URL('../src/LaundryDiary.tsx', import.meta.url), 'utf8');
  assert.doesNotMatch(src, /DiaryVoiceControls|extractDiaryKeywords|MediaRecorder|SpeechRecognition|ai_voice_text|setEditing/);
  assert.match(src, /content: form\.content, keywords: form\.keywords/);
  assert.match(src, /input_mode: 'manual'/);
  assert.match(src, /JSON\.stringify\(a\.keywords\) === JSON\.stringify\(b\.keywords\)/);
  assert.match(src, /onChange=\{e => setForm\(f => \(\{ \.\.\.f, content: e\.target\.value \}\)\)\}/);
  assert.doesNotMatch(src, /onPaste|onCopy|navigator\.clipboard|preventDefault\(\).*clipboard/);
});
