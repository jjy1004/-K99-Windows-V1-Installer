'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createRequire}=require('node:module');
const app=path.resolve(__dirname,'..'),root=path.resolve(app,'../..');
const req=createRequire(path.join(app,'package.json')),config=require('../electron-builder.cjs');
const nsis=fs.readFileSync(path.join(app,'installer/data-preservation.nsh'),'utf8');
test('trial keeps independent stable app ID and retains local data',()=>{
  assert.equal(config.appId,'com.k99.windows.v1');
  assert.equal(config.productName,'K99-Windows-V1');
  assert.equal(config.nsis.deleteAppDataOnUninstall,false);
  assert.equal(config.nsis.allowToChangeInstallationDirectory,false);
  assert.equal(config.publish,null);
  assert.equal(config.artifactName,'K99-Windows-V1-Setup-${version}-${arch}.${ext}');
});
test('assisted installer owns two optional Korean shortcuts, never forced default links',()=>{
  assert.equal(config.nsis.oneClick,false);
  assert.equal(config.nsis.shortcutName,'K99 스마트 접수 시스템');
  assert.equal(config.nsis.createDesktopShortcut,false);
  assert.equal(config.nsis.createStartMenuShortcut,false);
  assert.match(nsis,/NSD_GetState.*\$k99DesktopChoice/);
  assert.match(nsis,/NSD_GetState.*\$k99MenuChoice/);
  assert.match(nsis,/StrCpy \$launchLink "\$INSTDIR\\\$\{APP_EXECUTABLE_FILENAME\}"/);
});
test('shortcut conflicts are preserved and uninstall does not recursively delete user folders',()=>{
  assert.match(nsis,/\$\{FileExists\} "\$DESKTOP/);
  assert.match(nsis,/\$\{FileExists\} "\$SMPROGRAMS/);
  assert.match(nsis,/ReadRegStr.*DesktopShortcut/);
  assert.match(nsis,/ReadRegStr.*MenuShortcut/);
  assert.doesNotMatch(nsis,/\bRMDir\s+\/r/i);
  assert.doesNotMatch(nsis,/\bDelete\s+.*(?:sqlite|photos|backups|K99WindowsV1\\data)/i);
});
test('dedicated ICO contains valid 32-bit multi-resolution resources including 256px',()=>{
  const bytes=fs.readFileSync(config.win.icon);
  assert.equal(bytes.readUInt16LE(0),0);assert.equal(bytes.readUInt16LE(2),1);
  const count=bytes.readUInt16LE(4),sizes=[];
  assert.equal(count,7);
  for(let i=0;i<count;i++){
    const p=6+16*i,offset=bytes.readUInt32LE(p+12),length=bytes.readUInt32LE(p+8);
    sizes.push(bytes[p]||256);assert.ok(length>0&&offset>=6+16*count&&offset+length<=bytes.length);
    assert.equal(bytes.readUInt16LE(p+6),32);
  }
  assert.deepEqual(sizes.sort((a,b)=>a-b),[16,24,32,48,64,128,256]);
  assert.equal(config.win.signAndEditExecutable,true);
  assert.equal(config.nsis.installerIcon,config.win.icon);
});
test('workflow cannot run on push, public repositories or without cost acknowledgement',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  assert.deepEqual(Object.keys(workflow.on),['workflow_dispatch']);
  assert.equal(workflow.on.workflow_dispatch.inputs.usage_approved.default,false);
  const job=workflow.jobs['windows-installer'];
  assert.match(job.if,/usage_approved/);assert.match(job.if,/repository.private == true/);
  assert.equal(job['runs-on'],'windows-2022');assert.equal(job['timeout-minutes'],40);
  assert.deepEqual(workflow.permissions,{contents:'read'});
  for(const step of job.steps)if(step.uses)assert.match(step.uses,/@[a-f0-9]{40}$/);
  assert.equal(job.steps[0].with['persist-credentials'],false);
  const abi=job.steps.findIndex(s=>s.run?.includes('verify-packaged-native'));
  const hash=job.steps.findIndex(s=>s.run?.includes('verify-windows-installer'));
  const upload=job.steps.findIndex(s=>s.uses?.startsWith('actions/upload-artifact'));
  assert.ok(abi<hash&&hash<upload);assert.equal(job.steps[upload].with['retention-days'],7);
});
test('Windows native and installer verifiers are syntactically valid',()=>{
  const {spawnSync}=require('node:child_process');
  for(const name of ['verify-packaged-native.cjs','verify-windows-installer.cjs']){
    assert.equal(spawnSync(process.execPath,['--check',path.join(root,'scripts',name)]).status,0);
  }
});
test('fresh checkout builds library declarations before React and Windows packaging',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  const steps=workflow.jobs['windows-installer'].steps;
  const libs=steps.findIndex(s=>s.id==='libraries'),react=steps.findIndex(s=>s.id==='react_types');
  const pack=steps.findIndex(s=>s.id==='packaging');
  assert.ok(libs>=0&&libs<react&&react<pack);
  assert.equal(steps[libs].run,'node scripts/build-desktop-declarations.cjs');
  assert.match(steps[react].run,/build-desktop-declarations.cjs --verify-only/);
  const declarations=fs.readFileSync(path.join(root,'scripts/build-desktop-declarations.cjs'),'utf8');
  assert.match(declarations,/require.resolve\('typescript\/bin\/tsc'\)/);
  assert.match(declarations,/'--build'.*'--force'/);
  assert.match(declarations,/Required declaration not generated/);
  assert.doesNotMatch(steps[libs].run,/lib\/db/);
  assert.equal(config.npmRebuild,true);assert.equal(config.buildDependenciesFromSource,true);
  const appTs=JSON.parse(fs.readFileSync(path.join(app,'tsconfig.json')));
  assert.ok(appTs.references.some(r=>r.path==='../../lib/api-client-react'));
  const libTs=JSON.parse(fs.readFileSync(path.join(root,'lib/api-client-react/tsconfig.json')));
  assert.equal(libTs.compilerOptions.composite,true);
  assert.equal(libTs.compilerOptions.emitDeclarationOnly,true);
  assert.equal(libTs.compilerOptions.outDir,'dist');
  assert.ok(steps.some(s=>s.if==='failure()'&&s.name.includes('repair target')));
});
test('declaration generation never relies on a missing package build script',()=>{
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'lib/api-client-react/package.json')));
  assert.equal(manifest.scripts?.build,undefined);
  const workflow=fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8');
  assert.doesNotMatch(workflow,/--filter[^\n]*api-client-react[^\n]*(?:run\s+)?build/);
  const desktop=fs.readFileSync(path.join(root,'scripts/build-windows-installer.cjs'),'utf8');
  assert.ok(desktop.indexOf("require('./build-desktop-declarations.cjs')")<desktop.indexOf("run('React TypeScript check'"));
});
test('electron-builder accepts the installer schema without starting a build',async()=>{
  const builderRequire=createRequire(req.resolve('electron-builder/package.json'));
  const {validateConfiguration}=builderRequire('app-builder-lib/out/util/config/config');
  await validateConfiguration(config,{isEnabled:false});
});
