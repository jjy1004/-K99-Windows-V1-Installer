'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createRequire}=require('node:module');
const app=path.resolve(__dirname,'..'),root=path.resolve(app,'../..');
const req=createRequire(path.join(app,'package.json')),config=require('../electron-builder.cjs');
const nsis=fs.readFileSync(path.join(app,'installer/data-preservation.nsh'),'utf8');
test('trial keeps independent stable app ID and retains local data',()=>{
  assert.equal(config.appId,'com.k99.windows.v1');
  assert.equal(config.productName,'K99-Laundry-V2');
  assert.equal(config.nsis.deleteAppDataOnUninstall,false);
  assert.equal(config.nsis.allowToChangeInstallationDirectory,false);
  assert.deepEqual(config.publish,{provider:'github',owner:'jjy1004',repo:'-K99-Windows-V1-Installer',private:false});
  assert.equal(config.artifactName,'K99-Smart-Laundry-V2-Setup.${ext}');
});
test('one-click installer creates Korean shortcuts and runs after installation',()=>{
  assert.equal(config.nsis.oneClick,true);
  assert.equal(config.nsis.shortcutName,'K99 스마트 접수 시스템');
  assert.equal(config.nsis.createDesktopShortcut,'always');
  assert.equal(config.nsis.createStartMenuShortcut,true);
  assert.equal(config.nsis.perMachine,false);
  assert.equal(config.nsis.runAfterFinish,true);
  assert.equal(config.nsis.allowElevation,false);
  assert.equal(config.win.requestedExecutionLevel,'asInvoker');
  assert.match(nsis,/SetShellVarContext current/);
  assert.match(nsis,/CreateShortCut "\$DESKTOP\\\$\{SHORTCUT_NAME\}\.lnk"/);
  assert.match(nsis,/DesktopShortcutError/);
  assert.doesNotMatch(nsis,/\b(?:Exec|ExecShell)\s/);
  assert.doesNotMatch(nsis,/Page custom|NSD_Create/);
});
test('uninstall only clears installer metadata and never deletes shop folders',()=>{
  assert.match(nsis,/DeleteRegValue HKCU.*V2InstallLocation/);
  assert.doesNotMatch(nsis,/\bRMDir\s+\/r/i);
  assert.doesNotMatch(nsis,/\bDelete\s+.*(?:sqlite|photos|backups|K99WindowsV1\\data)/i);
});
test('official NSIS post-install launch uses the desktop user, not elevated Exec',()=>{
  const builderRequire=createRequire(req.resolve('electron-builder/package.json'));
  const tools=builderRequire('app-builder-lib/out/targets/nsis/nsisUtil');
  const common=fs.readFileSync(path.join(tools.nsisTemplatesDir,'common.nsh'),'utf8');
  const installer=fs.readFileSync(path.join(tools.nsisTemplatesDir,'installer.nsi'),'utf8');
  const startApp=common.match(/!macro StartApp\b[\s\S]*?!macroend/)[0];
  assert.match(startApp,/\$\{StdUtils\.ExecShellAsUser\}/);
  assert.doesNotMatch(startApp,/"runas"|\bExec\s/);
  assert.match(installer,/!else\s+RequestExecutionLevel user\s+!endif/);
});
test('dedicated ICO contains valid 32-bit multi-resolution resources including 256px',()=>{
  const bytes=fs.readFileSync(config.win.icon);
  assert.equal(bytes.readUInt16LE(0),0);assert.equal(bytes.readUInt16LE(2),1);
  const count=bytes.readUInt16LE(4),sizes=[];
  assert.equal(count,7);
  for(let i=0;i<count;i++){
    const p=6+16*i,offset=bytes.readUInt32LE(p+12),length=bytes.readUInt32LE(p+8);
    sizes.push(bytes[p]||256);assert.ok(length>0&&offset>=6+16*count&&offset+length<=bytes.length);
    assert.equal(bytes.readUInt16LE(p+6),32);
  }
  assert.deepEqual(sizes.sort((a,b)=>a-b),[16,24,32,48,64,128,256]);
  assert.equal(config.win.signAndEditExecutable,true);
  assert.equal(config.nsis.installerIcon,config.win.icon);
});
test('workflow requires explicit dispatch approval even in the user-approved public installer repository',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  assert.deepEqual(Object.keys(workflow.on),['workflow_dispatch']);
  assert.equal(workflow.on.workflow_dispatch.inputs.usage_approved.default,false);
  const job=workflow.jobs['windows-installer'];
  assert.match(job.if,/usage_approved/);assert.doesNotMatch(job.if,/repository.private/);
  assert.equal(job['runs-on'],'windows-2022');assert.equal(job['timeout-minutes'],40);
  assert.deepEqual(workflow.permissions,{contents:'read'});
  for(const step of job.steps)if(step.uses)assert.match(step.uses,/@[a-f0-9]{40}$/);
  assert.equal(job.steps[0].with['persist-credentials'],false);
  const abi=job.steps.findIndex(s=>s.run?.includes('verify-packaged-native'));
  const hash=job.steps.findIndex(s=>s.run?.includes('verify-windows-installer'));
  const upload=job.steps.findIndex(s=>s.uses?.startsWith('actions/upload-artifact'));
  assert.ok(abi<hash&&hash<upload);assert.equal(job.steps[upload].with['retention-days'],7);
});
test('latest release advances only after verified bytes and complete draft upload; artifact quota is non-blocking',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  const job=workflow.jobs['windows-installer'],steps=job.steps;
  assert.deepEqual(job.permissions,{contents:'write'});
  const publish=steps.findIndex(s=>s.id==='public_release'),hash=steps.findIndex(s=>s.id==='installer_hash');
  const upload=steps.findIndex(s=>s.uses?.startsWith('actions/upload-artifact'));
  assert(hash<publish&&publish<upload);
  assert.equal(steps[upload]['continue-on-error'],true);
  const script=steps[publish].run;
  assert(script.indexOf('gh release create')<script.indexOf('gh release upload'));
  assert(script.indexOf('$asset[0].size')<script.indexOf('gh release edit'));
  assert.match(script,/--draft=false --latest/);assert.match(script,/git\/ref\/heads\/main/);
  assert.match(script,/releases\?per_page=100/);
  assert.match(script,/Expected exactly one draft/);
  assert.doesNotMatch(script,/gh api "repos\/\$env:GITHUB_REPOSITORY\/releases\/tags\//);
  assert.match(script,/K99-Smart-Laundry-V2-Setup\.exe/);
  assert(steps.some(s=>s.run?.includes('download-release-media.cjs source source/customer-videos.release.json')));
});
test('Windows native and installer verifiers are syntactically valid',()=>{
  const {spawnSync}=require('node:child_process');
  for(const name of ['verify-packaged-native.cjs','verify-windows-installer.cjs']){
    assert.equal(spawnSync(process.execPath,['--check',path.join(root,'scripts',name)]).status,0);
  }
});
test('Windows packaged runtime probe follows the configured V2 executable name',()=>{
  const probe=fs.readFileSync(path.join(root,'scripts/verify-packaged-native.cjs'),'utf8');
  assert.equal(config.executableName,'K99-Laundry-V2');
  assert.match(probe,/builder\.executableName/);
  assert.doesNotMatch(probe,/K99-Windows-V1\.exe/);
});
test('2.4.6 workflow verifies the canonical EXE before publishing the requested Setup.2 alias',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  const steps=workflow.jobs['windows-installer'].steps;
  const hash=steps.findIndex(s=>s.id==='installer_hash'),alias=steps.findIndex(s=>s.id==='requested_installer');
  const upload=steps.findIndex(s=>s.uses?.startsWith('actions/upload-artifact'));
  assert.ok(hash>=0&&hash<alias&&alias<upload);
  assert.match(steps[alias].run,/verified\.sha256/);
  assert.match(steps[alias].run,/verified\.bytes/);
  assert.match(steps[upload].with.path,/K99-Smart-Laundry-V2-Setup\.2\.exe/);
  assert.match(steps[alias].run,/physicalCameraVerified = \$false/);
});
test('fresh checkout builds library declarations before React and Windows packaging',()=>{
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  const steps=workflow.jobs['windows-installer'].steps;
  const libs=steps.findIndex(s=>s.id==='libraries'),react=steps.findIndex(s=>s.id==='react_types');
  const pack=steps.findIndex(s=>s.id==='packaging');
  assert.ok(libs>=0&&libs<react&&react<pack);
  const inputTest=steps.findIndex(s=>s.id==='declaration_tests');
  assert.ok(inputTest>=0&&inputTest<libs);
  assert.equal(steps[inputTest].run,'node --test scripts/tests/desktop-declarations.test.cjs');
  assert.equal(steps[libs].run,'node scripts/build-desktop-declarations.cjs');
  assert.match(steps[react].run,/build-desktop-declarations.cjs --verify-only/);
  const declarations=fs.readFileSync(path.join(root,'scripts/build-desktop-declarations.cjs'),'utf8');
  assert.match(declarations,/require.resolve\('typescript\/bin\/tsc'\)/);
  assert.match(declarations,/'--build'.*'--force'/);
  assert.match(declarations,/Required declaration not generated/);
  assert.doesNotMatch(steps[libs].run,/lib\/db/);
  assert.equal(config.npmRebuild,true);assert.equal(config.buildDependenciesFromSource,true);
  const appTs=JSON.parse(fs.readFileSync(path.join(app,'tsconfig.json')));
  assert.ok(appTs.references.some(r=>r.path==='../../lib/api-client-react'));
  const libTs=JSON.parse(fs.readFileSync(path.join(root,'lib/api-client-react/tsconfig.json')));
  assert.equal(libTs.compilerOptions.composite,true);
  assert.equal(libTs.compilerOptions.emitDeclarationOnly,true);
  assert.equal(libTs.compilerOptions.outDir,'dist');
  assert.ok(steps.some(s=>s.if==='failure()'&&s.name.includes('repair target')));
});
test('declaration generation never relies on a missing package build script',()=>{
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'lib/api-client-react/package.json')));
  assert.equal(manifest.scripts?.build,undefined);
  const workflow=fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8');
  assert.doesNotMatch(workflow,/--filter[^\n]*api-client-react[^\n]*(?:run\s+)?build/);
  const desktop=fs.readFileSync(path.join(root,'scripts/build-windows-installer.cjs'),'utf8');
  assert.ok(desktop.indexOf("require('./build-desktop-declarations.cjs')")<desktop.indexOf("run('React TypeScript check'"));
});
test('electron-builder accepts the installer schema without starting a build',async()=>{
  const builderRequire=createRequire(req.resolve('electron-builder/package.json'));
  const {validateConfiguration}=builderRequire('app-builder-lib/out/util/config/config');
  await validateConfiguration(config,{isEnabled:false});
});
test('one-click header has no obsolete custom pages or unused installer variables',()=>{
  assert.doesNotMatch(nsis,/MUI_HEADER_TEXT|Function |^Var |Page custom/m);
  assert.match(nsis,/!macro customInstall/);
  assert.match(nsis,/!macro customUnInstall/);
});
test('native rebuild, output paths, packaged ABI check and diagnostic logs remain explicit',()=>{
  assert.equal(config.directories.output,path.join(root,'generated-artifacts/windows-installer'));
  assert.equal(config.npmRebuild,true);assert.equal(config.buildDependenciesFromSource,true);
  const abi=fs.readFileSync(path.join(root,'scripts/verify-packaged-native.cjs'),'utf8');
  assert.match(abi,/spawnSync\(exe,/);assert.match(abi,/report.electron!==expectedElectron/);
  const workflow=req('yaml').parse(fs.readFileSync(path.join(root,'.github/workflows/windows-installer.yml'),'utf8'));
  const steps=workflow.jobs['windows-installer'].steps;
  assert.ok(steps.findIndex(s=>s.id==='nsis_customization')<steps.findIndex(s=>s.id==='packaging'));
  const failure=steps.find(s=>s.name==='Preserve builder diagnostics on failure');
  assert.match(failure.with.path,/packaging-console.log/);
  const build=fs.readFileSync(path.join(root,'scripts/build-windows-installer.cjs'),'utf8');
  assert.match(build,/builderCli/);
  assert.doesNotMatch(build,/'exec','electron-builder'/);
});
test('customer videos are outside ASAR, both native IPC modules stage, and packaged media is checked',()=>{
  assert.ok(config.extraResources.some(item=>item.to==='videos'&&item.filter.includes('*.mp4')&&item.filter.includes('media-manifest.json')));
  const stage=fs.readFileSync(path.join(root,'scripts/stage-windows-app.cjs'),'utf8');
  for(const file of ['customer-display.cjs','customer-video.cjs'])assert.ok(stage.includes(file));
  const verify=fs.readFileSync(path.join(root,'scripts/verify-packaged-native.cjs'),'utf8');
  assert.match(verify,/resources\/videos/);assert.match(verify,/report\.originalVideosVerified/);
});
