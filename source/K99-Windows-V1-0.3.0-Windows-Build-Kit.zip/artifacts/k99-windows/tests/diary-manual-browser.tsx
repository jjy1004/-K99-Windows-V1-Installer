// 실제 접수·고객 DB에 접근하지 않는 검증 전용 진입점.
// 통합 검사에서는 문서 로드 전에 임시 SQLite 요청 어댑터를 주입한다.
import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { LaundryDiary } from '../src/LaundryDiary';

function Fixture() {
  const [open, setOpen] = useState(true);
  return <main>
    <p>세탁 일기 격리 검증 화면 · 운영 데이터는 사용하지 않습니다.</p>
    <button type="button" onClick={() => setOpen(true)}>세탁 일기 열기</button>
    {open && <LaundryDiary onClose={() => setOpen(false)} />}
  </main>;
}
createRoot(document.getElementById('root')!).render(<Fixture />);
