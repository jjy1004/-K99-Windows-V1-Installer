import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildSmsUri} from '../src/accountless-message';
import {appendMobileNotice} from '../src/notice-text';

test('SMS QR URI contains the complete recipient and lossless Korean, newlines and reserved characters',()=>{
  const body='고객님 안녕하세요.\n패딩 2점 · 35,000원\n동의 & 문의? #확인 +감사합니다';
  const uri=buildSmsUri('010-1234-5678',body);
  assert(uri.startsWith('sms:01012345678?body='));
  assert.equal(decodeURIComponent(uri.split('?body=')[1]),body);
  assert.equal(uri.split('?').length,2);
  assert(!uri.includes('&'));assert(!uri.includes('#'));
  assert(buildSmsUri('+82 10-1234-5678',body).startsWith('sms:+821012345678?body='));
});
test('SMS QR rejects suffix-only numbers, URI injection and empty/oversized text rather than truncating or sending',()=>{
  for(const number of ['5678','','01012345678?body=다른문자','01012345678;01099999999','고객01012345678'])
    assert.throws(()=>buildSmsUri(number,'정상 본문'));
  for(const body of ['','  ','a'.repeat(12001),'문자\0누락'])
    assert.throws(()=>buildSmsUri('01012345678',body));
});
test('mobile prose appends at cursor or end without replacing any existing text, including Korean and emoji',()=>{
  assert.equal(appendMobileNotice('기존 안내','추가 안내').body,'기존 안내\n추가 안내');
  assert.equal(appendMobileNotice('앞글\n뒷글','휴대폰 글',3).body,'앞글\n휴대폰 글\n뒷글');
  const s='의류✨ 확인';const p=s.indexOf(' 확인');
  assert.equal(appendMobileNotice(s,'특별 고지',p).body,'의류✨\n특별 고지\n 확인');
  assert.equal(appendMobileNotice('본문','   ').body,'본문');
  assert.throws(()=>appendMobileNotice('가'.repeat(11990),'나'.repeat(30)),/12,000/);
});
