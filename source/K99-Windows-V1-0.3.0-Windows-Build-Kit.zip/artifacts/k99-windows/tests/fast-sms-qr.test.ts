import {test} from 'node:test';
import assert from 'node:assert/strict';
import jsQR from 'jsqr';
import {buildSmsUri,summarizeSmsBody} from '../src/accountless-message';
import {smsQrPixels} from '../src/FastSmsQr';
import {deliveryView} from '../src/notice-delivery-state';

const longBody='검증매장 고객님\n맡겨주신 세탁물이 완성되었습니다. 편하신 시간에 매장을 방문해 주세요.\n'+
  '평일 10:00~19:00, 토요일 11:00~16:00입니다. 일요일·공휴일은 쉽니다. 4벌 이상 무료 수거·배달을 이용하실 수 있습니다.\n'.repeat(3);
test('short QR prose stays within 80 code points and preserves shop, customer, phone and original full prose',()=>{
  const summary=summarizeSmsBody({body:longBody,storeName:'검증매장',customerName:'검증고객',
    storePhone:'010-0000-0001',templateId:'complete-pickup'});
  assert(Array.from(summary).length<=80);
  for(const token of ['검증매장','검증고객','010-0000-0001','완성되었습니다'])assert(summary.includes(token));
  assert(longBody.length>190);
  const original=longBody;
  summarizeSmsBody({body:longBody,storeName:'매장'.repeat(40),customerName:'고객'.repeat(30),storePhone:'01000000001'});
  assert.equal(longBody,original);
});
test('edited negative messages do not become a falsely positive completion preset',()=>{
  const summary=summarizeSmsBody({body:'아직 세탁물이 완성되지 않았습니다. 방문하지 마세요.',
    storeName:'검증매장',customerName:'검증고객',templateId:'complete-pickup'});
  assert(summary.includes('완성되지 않았습니다'));
  assert(!summary.includes('완성되었습니다'));
});
test('actual low-density QR pixels decode losslessly with >=320px modules and >=24px four-module white zone',()=>{
  const body=summarizeSmsBody({body:longBody,storeName:'검증매장',customerName:'검증고객',storePhone:'01000000001',templateId:'complete-pickup'});
  const uri=buildSmsUri('01000000002',body),layout=smsQrPixels(uri);
  const {matrix,scale,quiet,size}=layout;
  assert(matrix.pixx*scale>=320);assert(quiet>=24);assert(quiet>=4*scale);
  assert(matrix.pixx<smsQrPixels(buildSmsUri('01000000002',longBody)).matrix.pixx);
  const rgba=new Uint8ClampedArray(size*size*4).fill(255);
  for(let y=0;y<matrix.pixy;y++)for(let x=0;x<matrix.pixx;x++)if(matrix.pixs[y*matrix.pixx+x])
    for(let py=0;py<scale;py++)for(let px=0;px<scale;px++){
      const i=((quiet+y*scale+py)*size+quiet+x*scale+px)*4;
      rgba[i]=rgba[i+1]=rgba[i+2]=0;
    }
  const decoded=jsQR(rgba,size,size);
  assert(decoded);assert.equal(decoded.data,uri);
  assert.equal(decodeURIComponent(decoded.data.split('?body=')[1]),body);
  assert.deepEqual([...rgba.slice(0,size*4)],Array(size*4).fill(255));
});
test('release badges exclude inspection messages; preparing is not sending and re-preparation keeps confirmed time',()=>{
  const base={orderId:'test',preparedAt:'2026-11-24T09:00:00Z',channel:'sms-qr',summaryOnly:true};
  const inspection={...base,templateId:'inspection-consent',sentAt:'2026-11-24T09:01:00Z'};
  const release={...base,templateId:'complete-pickup',sentAt:null};
  assert.equal(deliveryView([inspection,release],['complete-pickup']).kind,'prepared');
  assert.equal(deliveryView([inspection],['complete-pickup']).kind,'none');
  assert.equal(deliveryView([release]).kind,'prepared');
  const sent={...release,sentAt:'2026-11-24T09:01:00Z',preparedAt:'2026-11-24T09:02:00Z'};
  assert.equal(deliveryView([sent]).kind,'sent');assert.equal(deliveryView([sent]).preparingAgain,true);
});
