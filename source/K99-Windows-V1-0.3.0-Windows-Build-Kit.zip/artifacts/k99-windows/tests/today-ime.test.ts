import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { publishImeValue } from '../src/ime-search-policy';
import { customerQuery } from '../src/customer-autofill';

test('IME name draft is published while composing; query waits for two characters and deletion invalidates', () => {
  assert.equal(publishImeValue(true, true), true);
  assert.equal(customerQuery('김', '', 'name'), null);
  assert.deepEqual(customerQuery('김신', '', 'name'), { keyword: '김신', kind: 'name' });
  assert.deepEqual(customerQuery('임선', '', 'name'), { keyword: '임선', kind: 'name' });
  assert.equal(publishImeValue(true, false), false);
  assert.equal(publishImeValue(false, false), true);
});
test('autocomplete has no ESC/defaultPrevented gate; global idle ESC remains and reset is explicit', () => {
  const read = (file: string) => fs.readFileSync(new URL('../src/' + file, import.meta.url), 'utf8');
  const customer = read('CustomerDirectory.tsx');
  const keyHandler = customer.slice(customer.indexOf('const onKey = (event: globalThis.KeyboardEvent)'), customer.indexOf("document.addEventListener('keydown', onKey)"));
  assert.ok(!keyHandler.includes('Escape') && !keyHandler.includes('defaultPrevented'));
  assert.ok(!customer.includes('!q || composing'));
  assert.match(customer, /}, 150\)/);
  const app = read('App.tsx');
  assert.match(app, /window\.addEventListener\('keydown', handler, true\)/);
  assert.match(app, /className="intake-reset-button".*onClick={resetIntake}/);
  assert.match(app, /NativeDraftCamera key={draftId}/);
  assert.match(app, /sourceIdRef\.current === draftId/);
});
