import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {createConfirmedOrder,insertConfirmedOrder,readConfirmedOrders,updateSavedOrder} from '../src/order-record';
const require=createRequire(import.meta.url);
const {createStore}=require('@workspace/k99-local');

test('original reception creation/pricing/garment rules persist to SQLite and reopen', () => {
  const folder=fs.mkdtempSync(path.join(os.tmpdir(),'k99-original-flow-'));
  const file=path.join(folder,'test.sqlite');
  let store=createStore(file);
  const seen=new Map<string,string|null>();
  // Same sync contract exposed by the Electron bridge. No browser history.
  const storage={
    getItem(key:string) {const value=store.storage({op:'get',key});seen.set(key,value);return value;},
    setItem(key:string,value:string) {
      if (!seen.has(key)) storage.getItem(key);
      store.storage({op:'set',key,value,expected:seen.get(key)});seen.set(key,value);
    },
  };
  const previous=globalThis.window;
  Object.assign(globalThis,{window:{localStorage:storage}});
  try {
    const order=createConfirmedOrder({
      id:'V1-INTEGRATION-001',customerName:'테스트고객',customerPhone:'01000000000',customerAddress:'',
      items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}],
    },{serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,
      requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:'테스트 전용'},
    new Date('2026-10-31T00:00:00Z'));
    assert.equal(order.estimatedTotal,10000);
    insertConfirmedOrder(order);
    assert.equal(readConfirmedOrders()[0].garments?.length,2);
    assert.throws(() => insertConfirmedOrder(order),/같은 접수번호/);
    const saved=readConfirmedOrders()[0];
    const photo=store.equipment.capture({orderId:saved.id,garmentId:saved.garments![0].garmentId,
      role:'intake',requestId:'source-photo-0001',
      imageDataUrl:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jVioAAAAASUVORK5CYII='});
    assert.equal(photo.photo.orderId,saved.id);
    seen.clear();
    const photographed=readConfirmedOrders()[0];
    assert.equal(photographed.garments?.[0].photoHistory?.length,1);
    assert.throws(()=>updateSavedOrder({...saved,customerAddress:'stale'},saved),/다른|변경|최신|저장/);
    updateSavedOrder({...photographed,customerAddress:'개발 검증용 주소'},photographed);
    store.close();store=createStore(file);seen.clear();
    const restored=readConfirmedOrders()[0];
    assert.equal(restored.id,order.id);
    assert.equal(restored.customerAddress,'개발 검증용 주소');
    assert.equal(restored.estimatedTotal,10000);
    assert.equal(restored.garments?.length,2);
    assert.equal(new Set(restored.garments?.map(g => g.garmentId)).size,2);
  } finally {
    store.close();fs.rmSync(folder,{recursive:true,force:true});
    Object.assign(globalThis,{window:previous});
  }
});
