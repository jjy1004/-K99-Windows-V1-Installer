'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');
const {createAutoMessenger,SCRIPT}=require('../electron/services/autoMessenger.js');
const {createNoticeMobile}=require('../electron/notice-mobile.cjs');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
function automation(results=[],installed=true,options={}){
  const opens=[],spawned=[],copied=[];let kills=0;
  const spawnProcess=(command,args)=>{
    spawned.push({command,args});
    const c=new EventEmitter();c.stdin=new PassThrough();c.stdout=new PassThrough();c.stderr=new PassThrough();
    c.unref=()=>{};c.kill=()=>{kills++;c.emit('close',1);};
    if(command==='powershell.exe'){
      const request=spawned[spawned.length-1];request.input='';
      c.stdin.setEncoding('utf8');c.stdin.on('data',part=>{request.input+=part;});
      c.stdin.on('finish',()=>{const action=results.shift();if(action==='timeout')return;
        queueMicrotask(()=>{c.stdout.end(JSON.stringify(action));c.emit('close',0);});});
    }else queueMicrotask(()=>{c.emit('spawn');if(command==='reg.exe')c.emit('close',options.missingPhone?1:0);});
    return c;
  };
  const client=createAutoMessenger({platform:'win32',spawnProcess,exists:()=>installed,environment:{ProgramFiles:'C:\\Program Files'},
    shell:{openExternal:async u=>{opens.push(u);}},clipboard:{writeText:s=>copied.push(s)},timeoutMs:30});
  return {client,opens,spawned,copied,kills:()=>kills};
}
const notice={customerPhone:'010-0000-0001',customerName:'검사고객',body:'검사 문안 $([위험한 명령 아님])'};
test('explicit Kakao self-test uses confirm mode only and never switches to an SMS recipient',async()=>{
  const a=automation([{status:'prepared',channel:'kakao'}]);
  assert.equal((await a.client.command({action:'test',channel:'kakao',phone:notice.customerPhone})).status,'prepared');
  const request=JSON.parse(a.spawned.find(x=>x.command==='powershell.exe').input);
  assert.equal(request.mode,'confirm');assert.equal(request.phone,'01000000001');
  assert(!a.opens.some(u=>u.startsWith('sms:')));
  const absent=automation([],false);
  const r=await absent.client.command({action:'test',channel:'kakao',phone:notice.customerPhone});
  assert.equal(r.status,'unconfirmed');assert(absent.opens[0].startsWith('https://www.kakaocorp.com/'));
  assert(!absent.opens.some(u=>u.startsWith('sms:')));
});
test('native helper never invokes PowerShell or OBS at startup; phone/store and Kakao official fallback are on-demand',async()=>{
  const a=automation([],false,{missingPhone:true});assert.equal(a.spawned.length,0);assert.equal(a.opens.length,0);
  await a.client.command({action:'phone'});assert.match(a.opens[0],/^ms-windows-store:/);
  await a.client.command({action:'kakao'});assert.match(a.opens[1],/^https:\/\/www.kakaocorp.com\//);
  assert(!a.spawned.some(p=>p.command==='powershell.exe'));
});
test('test button only opens own SMS composer, copies text, and never automates Enter/send',async()=>{
  const a=automation();const r=await a.client.command({action:'test',phone:'01000000001'});
  assert.equal(r.status,'opened');assert.match(a.opens[0],/^sms:01000000001/);assert.equal(a.spawned.length,0);
  assert(a.copied.length);assert.match(r.detail,/자동 발송하지 않았/);
});
test('Kakao confirm mode reports prepared only, message travels through stdin not command line',async()=>{
  const a=automation([{status:'prepared',channel:'kakao',detail:'입력 확인'}]);
  const r=await a.client.dispatch(notice,'confirm');assert.equal(r.status,'prepared');assert.equal(r.success,true);
  const p=a.spawned.find(p=>p.command==='powershell.exe');assert(p);
  assert(!JSON.stringify(p.args).includes(notice.body));
  assert(!JSON.stringify(p.args).includes('01000000001'));
  assert.match(SCRIPT,/RecipientVisible/);assert.match(SCRIPT,/Value/);
  assert.equal(a.opens.length,0);
});
test('only verified not-found friend result falls back to SMS, immediate result is a request not delivered',async()=>{
  const a=automation([{status:'not_found',channel:'kakao'},{status:'send_requested',channel:'sms'}]);
  const r=await a.client.dispatch(notice,'immediate');assert.equal(r.status,'send_requested');assert.equal(r.success,true);
  assert.match(a.opens[0],/^sms:01000000001\?body=/);assert.equal(a.spawned.filter(p=>p.command==='powershell.exe').length,2);
});
test('ambiguous or unsupported recipient never silently searches another person/channel',async()=>{
  const a=automation([{status:'unsupported',channel:'kakao'}]);const r=await a.client.dispatch(notice,'immediate');
  assert.equal(r.success,false);assert.equal(r.manualRequired,true);assert.equal(a.opens.length,0);
  assert.equal(a.spawned.filter(p=>p.command==='powershell.exe').length,1);
});
test('timeout stops worker, returns unconfirmed, and does not retry or fall back to another send',async()=>{
  const a=automation(['timeout']);const r=await a.client.dispatch(notice,'immediate');
  assert.equal(r.status,'unconfirmed');assert.equal(a.kills(),1);assert.equal(a.opens.length,0);
});
test('missing or incomplete recipient fails before any external action',async()=>{
  const a=automation();await assert.rejects(()=>a.client.dispatch({...notice,customerPhone:'0001'},'immediate'),/번호/);
  assert.equal(a.spawned.length,0);assert.equal(a.opens.length,0);
});
test('LAN notice QR scopes customer, rejects host/origin/expiry, deduplicates mobile submissions',async()=>{
  let tick=Date.now(),saved=0;
  const notices={
    context:id=>{if(id!=='order-a'&&id!=='order-b')throw Error('잘못된 주문');return{customerName:id==='order-a'?'검사고객':'다른고객',customerPhone:id==='order-a'?'01000000001':'01000000002'};},
    listOrders:()=>[{orderId:'order-a',customerName:'검사고객',phoneLast4:'0001',visitDate:'2026-11-21'},{orderId:'order-b',customerName:'다른고객',phoneLast4:'0002',visitDate:'2026-11-21'}],
    save:(x,source)=>{saved++;assert.equal(source,'mobile');return {notice:{id:'saved-'+saved,...x,source}};},
  };
  const bridge=createNoticeMobile({getNotices:()=>notices,native:true,addresses:()=>['127.0.0.1'],host:'127.0.0.1',now:()=>tick});
  try{
    const qr=await bridge.start({customerScope:{name:'검사고객',phone:'01000000001'}}),url=new URL(qr.url),token=url.searchParams.get('token');
    const root=url.origin,headers={'Content-Type':'application/json','X-K99-Notice-Token':token,Origin:root};
    const list=await (await fetch(root+'/api/mobile-notice/orders?token='+token)).json();assert.deepEqual(list.orders.map(o=>o.orderId),['order-a']);
    const page=await fetch(qr.url);assert.equal(page.status,200);assert.match(await page.text(),/휴대폰 키보드의 마이크/);
    const input={orderId:'order-a',body:'휴대폰에서 입력한 특별 고지',theme:'오염 안내',requestId:'mobile-test-1'};
    for(let i=0;i<2;i++){const r=await fetch(root+'/api/mobile-notice/save',{method:'POST',headers,body:JSON.stringify(input)});assert.equal(r.status,200);}
    assert.equal(saved,1);
    const other=await fetch(root+'/api/mobile-notice/save',{method:'POST',headers,body:JSON.stringify({...input,orderId:'order-b',requestId:'mobile-test-2'})});assert.equal(other.status,403);
    assert.equal((await fetch(root+'/api/mobile-notice/save',{method:'POST',headers:{...headers,Origin:'http://evil.test'},body:JSON.stringify(input)})).status,403);
    // fetch can ignore a caller-supplied Host; use an actual HTTP request.
    const badHost=await new Promise((resolve,reject)=>{
      const req=require('node:http').get(root+'/api/mobile-notice/orders?token='+token,{headers:{Host:'evil.test'}},r=>{r.resume();resolve(r.statusCode);});
      req.on('error',reject);
    });
    assert.equal(badHost,403);
    tick+=11*60*1000;assert.equal((await fetch(qr.url)).status,410);
  }finally{bridge.close();}
});
test('new runtime files are explicitly staged and checked; existing camera/printing modules are not replaced',()=>{
  const root=path.resolve(__dirname,'../../..'),stage=fs.readFileSync(path.join(root,'scripts/stage-windows-app.cjs'),'utf8');
  const verify=fs.readFileSync(path.join(root,'scripts/verify-windows-portable.cjs'),'utf8');
  for(const f of ['customer-notices.cjs','notice-mobile.cjs','notice-mobile-page.cjs']){assert(stage.includes(f));assert(verify.includes(f));}
  assert(verify.includes('services/autoMessenger.js'));assert(verify.includes('services/package.json'));
  assert(!fs.readFileSync(path.join(__dirname,'../electron/services/autoMessenger.js'),'utf8').includes('spawnSync'));
});
test('existing mobile photo QR exposes a scoped notice tab without closing capture or saving fake photos',async()=>{
  const {createMobilePhotoBridge}=require('../electron/mobile-photo-bridge.cjs');let pictures=0,linked;
  const input={orderId:'order-a',customerName:'검사고객',customerPhone:'01000000001'};
  const bridge=createMobilePhotoBridge({host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1'],
    validateTarget:i=>({...i,phoneLast4:'0001',itemName:'검사 의류',folderIdentifier:'검사폴더'}),
    capture:()=>{pictures++;},noticeLink:i=>{linked=i;return {url:'http://127.0.0.1:1234/mobile-notice?token=notice-test'};}});
  try{
    const q=await bridge.api('POST','/api/mobile-photo/start',input),url=new URL(q.urls[0]),token=url.searchParams.get('token');
    const r=await fetch(url.origin+'/api/mobile-notice-link?token='+token);assert.equal(r.status,200);
    assert.equal((await r.json()).url,'http://127.0.0.1:1234/mobile-notice?token=notice-test');
    assert.equal(linked.customerPhone,input.customerPhone);assert.equal(pictures,0);
    const status=await bridge.api('GET','/api/mobile-photo/status?id='+q.id);
    assert.equal(status.id,q.id);
  }finally{bridge.close();}
});
