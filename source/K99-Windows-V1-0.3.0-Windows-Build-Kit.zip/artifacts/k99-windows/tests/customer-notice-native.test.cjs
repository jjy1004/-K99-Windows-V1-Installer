'use strict';
// Compile and parse the actual Windows implementation without touching any UI.
const nativeChildProcess=require('node:child_process');
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events'),{PassThrough}=require('node:stream');
const {createAutoMessenger,SCRIPT}=require('../electron/services/autoMessenger.js');
const {createNoticeMobile}=require('../electron/notice-mobile.cjs');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
test('트레이 창도 소유 프로세스별로 탐색하고 포커스 입력 연결은 반드시 해제한다',()=>{
  for(const feature of ['EnumWindows','GetWindow(h,4)','GetWindowTextLength','Array.IndexOf(ids,pid)',
    'RestoreForeground','AttachThreadInput(current,target,false)','AttachThreadInput(current,active,false)'])assert(SCRIPT.includes(feature),feature);
  assert.doesNotMatch(SCRIPT,/Where-Object \{\$_\.MainWindowHandle -ne 0\}/);
  assert.match(SCRIPT,/finally \{/);assert.match(SCRIPT,/rootPid/);
  assert.doesNotMatch(SCRIPT,/SendKeys\('(%|\{ENTER\})/);
});
test('클릭한 외부 앱만 일시 최상단으로 복원하고 Alt와 최상단 상태는 반드시 해제한다',()=>{
  assert.match(SCRIPT,/ShowWindowAsync\(h,9\)/);
  assert.match(SCRIPT,/GetAsyncKeyState\(0x12\)/);
  assert.match(SCRIPT,/keybd_event\(0x12,0,2,UIntPtr.Zero\)/);
  assert.match(SCRIPT,/topmost=SetWindowPos\(h,new IntPtr\(-1\)/);
  assert.match(SCRIPT,/finally \{[\s\S]*if\(topmost\)SetWindowPos\(h,new IntPtr\(-2\)/);
  assert.doesNotMatch(SCRIPT,/SendKeys\('(%|\{ENTER\})/);
});
test('실제 Windows에서 메신저·포트 스크립트 파싱과 창 API C# 컴파일을 수행한다',
  {skip:process.platform!=='win32'},()=>{
    const {PROBE_SCRIPT}=require('../electron/services/terminal-connection.cjs');
    const csharp=SCRIPT.match(/Add-Type @'\r?\n([\s\S]*?)\r?\n'@/)[1];
    const ps="$ErrorActionPreference='Stop';[Console]::InputEncoding=New-Object System.Text.UTF8Encoding;$p=[Console]::In.ReadToEnd()|ConvertFrom-Json;foreach($s in $p.scripts){$t=$null;$e=$null;[System.Management.Automation.Language.Parser]::ParseInput($s,[ref]$t,[ref]$e)|Out-Null;if($e.Count){throw ($e|Out-String)}};Add-Type -TypeDefinition $p.cs;[Console]::Out.Write('K99_COMPILED')";
    const r=nativeChildProcess.spawnSync('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',
      Buffer.from(ps,'utf16le').toString('base64')],{input:JSON.stringify({cs:csharp,scripts:[SCRIPT,PROBE_SCRIPT]}),encoding:'utf8',timeout:30000,windowsHide:true});
    assert.equal(r.status,0,r.stderr);assert.equal(r.stdout,'K99_COMPILED');
  });
function automation(results=[],installed=true,options={}){
  const opens=[],spawned=[],copied=[];let kills=0;
  const spawnProcess=(command,args)=>{
    spawned.push({command,args});
    const c=new EventEmitter();c.stdin=new PassThrough();c.stdout=new PassThrough();c.stderr=new PassThrough();
    c.unref=()=>{};c.kill=()=>{kills++;c.emit('close',1);};
    if(command==='powershell.exe'){
      const script=Buffer.from(args.at(-1),'base64').toString('utf16le');
      if(script.includes('K99_KAKAO_STARTED')){
        c.stdin.on('finish',()=>queueMicrotask(()=>{c.stdout.end('K99_KAKAO_STARTED');c.emit('close',0);}));return c;
      }
      if(script.includes('Select-Object -Unique')){
        queueMicrotask(()=>{c.stdout.end(JSON.stringify(options.runningPath||[]));c.emit('close',0);});return c;
      }
      const request=spawned[spawned.length-1];request.input='';
      c.stdin.setEncoding('utf8');c.stdin.on('data',part=>{request.input+=part;});
      c.stdin.on('finish',()=>{const action=results.shift();if(action==='timeout')return;
        queueMicrotask(()=>{c.stdout.end(JSON.stringify(action));c.emit('close',0);});});
    }else queueMicrotask(()=>{
      if(options.launchError&&command.toLowerCase().endsWith('kakaotalk.exe')){c.emit('error',Error('실행 거부'));return;}
      c.emit('spawn');if(command==='reg.exe'){
        if(options.registryPath&&args[1].includes('App Paths'))c.stdout.end(`    (Default)    REG_EXPAND_SZ    ${options.registryPath}\r\n`);
        c.emit('close',options.missingPhone&&!(options.phonePackage&&args.includes('Microsoft.YourPhone_'))?1:0);
      }
      if(command==='explorer.exe'&&options.phonePackage)c.emit('close',0);
      if(command==='tasklist.exe'&&!options.processTimeout){
        c.stdout.end(options.running?'"KakaoTalk.exe","1234","Console","1","10,000 K"':'INFO: No tasks are running');
        c.emit('close',options.processFailure?1:0);
      }
    });
    return c;
  };
  const client=createAutoMessenger({platform:'win32',spawnProcess,exists:options.exists||(()=>installed),environment:{ProgramFiles:'C:\\Program Files',LOCALAPPDATA:'C:\\Users\\Fixture\\AppData\\Local'},
    shell:{openExternal:async u=>{opens.push(u);}},clipboard:{writeText:s=>copied.push(s)},timeoutMs:30});
  return {client,opens,spawned,copied,kills:()=>kills};
}
const notice={customerPhone:'010-0000-0001',customerName:'검사고객',body:'검사 문안 $([위험한 명령 아님])'};
test('삭제한 휴대폰 설정 요청은 앱·스토어·페어링 창을 열지 않는다',async()=>{
  const a=automation([],true,{missingPhone:true,phonePackage:true});
  await assert.rejects(()=>a.client.command({action:'phone'}),/허용되지 않은/);
  assert.equal(a.spawned.length,0);
  assert.equal(a.opens.length,0);
});
test('시작 시 카카오 상태 확인·최소화 실행만 수행하고 외부 앱 자동 입력은 하지 않는다',async()=>{
  for(const [installed,options,status,starts] of [[true,{},'started',1],[true,{running:true},'already-running',0],
    [false,{},'not-installed',0],[true,{processFailure:true},'unknown',0],[true,{processTimeout:true},'unknown',0]]){
    const a=automation([],installed,options);const r=await a.client.ensureKakao();
    assert.equal(r.status,status);assert.equal(a.spawned.filter(x=>x.command==='powershell.exe'&&
      Buffer.from(x.args.at(-1),'base64').toString('utf16le').includes('K99_KAKAO_STARTED')).length,starts);
    assert.equal(a.opens.length,0);assert.equal(a.copied.length,0);
    assert(!a.spawned.some(x=>x.command==='powershell.exe'&&
      Buffer.from(x.args.at(-1),'base64').toString('utf16le')===SCRIPT));
  }
});
test('accountless Kakao compose copies complete text and activates the native window without web or Phone Link',async()=>{
  const a=automation([{status:'prepared'}]);const r=await a.client.command({action:'kakao-compose',body:notice.body});
  assert.deepEqual(a.copied,[notice.body]);assert.equal(r.status,'prepared');assert.equal(r.manualRequired,true);
  assert(a.spawned.some(x=>x.command.toLowerCase().endsWith('kakaotalk.exe')));
  assert.equal(a.opens.length,0);assert.equal(r.searchPrepared,false);assert.equal(r.copied,true);
  assert.equal(JSON.parse(a.spawned.find(x=>x.command==='powershell.exe').input).mode,'focus-only');
  await assert.rejects(()=>a.client.command({action:'kakao-compose',body:''}));
  assert.equal(a.copied.length,1);
});
test('missing Kakao copies text and shows guidance without opening any browser; clipboard errors stop launch',async()=>{
  const a=automation([],false);const r=await a.client.command({action:'kakao-compose',body:notice.body});
  assert.equal(r.channel,'kakao-not-installed');assert.equal(r.status,'unconfirmed');assert.deepEqual(a.copied,[notice.body]);
  assert.equal(r.success,false);assert.equal(r.copied,true);assert.equal(r.searchPrepared,false);
  assert.equal(a.opens.length,0);assert(!a.spawned.some(x=>x.command.toLowerCase().endsWith('kakaotalk.exe')));
  let opened=false;
  const bad=createAutoMessenger({platform:'win32',clipboard:{writeText(){throw Error('복사 실패');}},shell:{openExternal:async()=>{opened=true;}}});
  await assert.rejects(()=>bad.command({action:'kakao-compose',body:notice.body}),/복사 실패/);assert.equal(opened,false);
});
test('explicit Kakao self-test uses confirm mode only and never switches to an SMS recipient',async()=>{
  const a=automation([{status:'prepared',channel:'kakao'}]);
  assert.equal((await a.client.command({action:'test',channel:'kakao',phone:notice.customerPhone})).status,'prepared');
  const request=JSON.parse(a.spawned.find(x=>x.command==='powershell.exe').input);
  assert.equal(request.mode,'confirm');assert.equal(request.phone,'01000000001');
  assert(!a.opens.some(u=>u.startsWith('sms:')));
  const absent=automation([],false);
  const r=await absent.client.command({action:'test',channel:'kakao',phone:notice.customerPhone});
  assert.equal(r.status,'unconfirmed');assert.equal(absent.opens.length,0);
  assert(!absent.opens.some(u=>u.startsWith('sms:')));
});
test('native helper never invokes PowerShell or OBS at startup; missing Kakao never opens web fallback',async()=>{
  const a=automation([],false,{missingPhone:true});assert.equal(a.spawned.length,0);assert.equal(a.opens.length,0);
  await assert.rejects(()=>a.client.command({action:'phone'}),/허용되지 않은/);
  const result=await a.client.command({action:'kakao'});assert.equal(result.success,false);
  assert.equal(a.opens.length,0);
});
test('test button only opens own SMS composer, copies text, and never automates Enter/send',async()=>{
  const a=automation();const r=await a.client.command({action:'test',phone:'01000000001'});
  assert.equal(r.status,'opened');assert.match(a.opens[0],/^sms:01000000001/);assert.equal(a.spawned.length,0);
  assert(a.copied.length);assert.match(r.detail,/자동 발송하지 않았/);
});
test('Kakao confirm mode reports prepared only, message travels through stdin not command line',async()=>{
  const a=automation([{status:'prepared',channel:'kakao',detail:'입력 확인'}]);
  const r=await a.client.dispatch(notice,'confirm');assert.equal(r.status,'prepared');assert.equal(r.success,true);
  const p=a.spawned.find(p=>p.command==='powershell.exe');assert(p);
  assert(!JSON.stringify(p.args).includes(notice.body));
  assert(!JSON.stringify(p.args).includes('01000000001'));
  assert.match(SCRIPT,/RecipientVisible/);assert.match(SCRIPT,/Value/);
  assert.equal(a.opens.length,0);
});
test('only verified not-found friend result falls back to SMS, immediate result is a request not delivered',async()=>{
  const a=automation([{status:'not_found',channel:'kakao'},{status:'send_requested',channel:'sms'}]);
  const r=await a.client.dispatch(notice,'immediate');assert.equal(r.status,'send_requested');assert.equal(r.success,true);
  assert.match(a.opens[0],/^sms:01000000001\?body=/);assert.equal(a.spawned.filter(p=>p.command==='powershell.exe').length,2);
});
test('ambiguous or unsupported recipient never silently searches another person/channel',async()=>{
  const a=automation([{status:'unsupported',channel:'kakao'}]);const r=await a.client.dispatch(notice,'immediate');
  assert.equal(r.success,false);assert.equal(r.manualRequired,true);assert.equal(a.opens.length,0);
  assert.equal(a.spawned.filter(p=>p.command==='powershell.exe').length,1);
});
test('timeout stops worker, returns unconfirmed, and does not retry or fall back to another send',async()=>{
  const a=automation(['timeout']);const r=await a.client.dispatch(notice,'immediate');
  assert.equal(r.status,'unconfirmed');assert.equal(a.kills(),1);assert.equal(a.opens.length,0);
});
test('missing or incomplete recipient fails before any external action',async()=>{
  const a=automation();await assert.rejects(()=>a.client.dispatch({...notice,customerPhone:'0001'},'immediate'),/번호/);
  assert.equal(a.spawned.length,0);assert.equal(a.opens.length,0);
});
test('accountless compose searches customer name, preserves the full clipboard and never selects or sends',async()=>{
  const a=automation([{status:'prepared',detail:'검색 입력 완료'}]);
  const r=await a.client.command({action:'kakao-compose',body:notice.body,recipient:notice.customerPhone,customerName:notice.customerName});
  assert.equal(r.searchPrepared,true);assert.match(r.detail,/\[검사고객\].*검색을 준비/);
  const request=JSON.parse(a.spawned.find(x=>x.command==='powershell.exe').input);
  assert.equal(request.mode,'search-only');assert.equal(request.phone,'01000000001');
  assert.equal(request.searchName,notice.customerName);assert.equal(request.body,'');assert.deepEqual(a.copied,[notice.body]);
  assert(!JSON.stringify(a.spawned.map(x=>x.args)).includes(notice.customerPhone));
  assert(SCRIPT.indexOf("if($p.mode -eq 'search-only')")<SCRIPT.indexOf('Never pick'));
  assert(SCRIPT.indexOf('GetForegroundWindow() -ne $handle')<SCRIPT.indexOf("$ws.SendKeys('^f')"));
  assert.equal(a.opens.length,0);
});
test('registry and running process paths find custom Kakao installations without launching URLs',async()=>{
  for(const source of ['registry','process']){
    const file='C:\\Users\\Fixture\\AppData\\Local\\Custom Kakao\\KakaoTalk.exe';
    const a=automation([{status:'prepared'}],false,{exists:p=>p===file,
      ...(source==='registry'?{registryPath:'%LOCALAPPDATA%\\Custom Kakao\\KakaoTalk.exe'}:{runningPath:file})});
    const r=await a.client.command({action:'kakao-compose',body:notice.body,customerName:'홍+길{동}'});
    assert.equal(r.success,true);assert.equal(r.searchPrepared,true);assert.equal(a.opens.length,0);
    assert(a.spawned.some(p=>p.command===file));
    assert.equal(JSON.parse(a.spawned.filter(p=>p.command==='powershell.exe').at(-1).input).searchName,'홍+길{동}');
    assert(!a.spawned.some(p=>p.args.some(v=>v.includes('홍+길'))));
  }
});
test('failed or timed-out search does not claim success and preserves copied message with no retry or send',async()=>{
  for(const result of [{status:'unsupported',detail:'검색창을 확인하지 못했습니다.'},'timeout']){
    const a=automation([result]);
    const r=await a.client.command({action:'kakao-compose',body:notice.body,customerName:'검사고객'});
    assert.equal(r.success,false);assert.equal(r.searchPrepared,false);assert.deepEqual(a.copied,[notice.body]);
    assert.equal(a.opens.length,0);assert.equal(a.spawned.filter(p=>p.command==='powershell.exe').length,1);
  }
  const a=automation();await assert.rejects(()=>a.client.command({action:'kakao-compose',body:notice.body,customerName:'고객\n이름'}),/이름/);
  assert.equal(a.copied.length,0);assert.equal(a.spawned.length,0);
});
test('an executable launch failure keeps the full clipboard and returns Korean manual guidance without opening web',async()=>{
  const a=automation([],true,{launchError:true});
  const r=await a.client.command({action:'kakao-compose',body:notice.body,customerName:notice.customerName});
  assert.equal(r.success,false);assert.equal(r.copied,true);assert.equal(r.searchPrepared,false);
  assert.match(r.detail,/문구는 복사되었습니다.*직접 열고/);assert.deepEqual(a.copied,[notice.body]);
  assert.equal(a.opens.length,0);assert(!a.spawned.some(p=>p.command==='powershell.exe'));
});
test('name-search branch checks ownership and focus, uses ValuePattern not clipboard or SendKeys data, and returns before any room or send action',()=>{
  const branch=SCRIPT.slice(SCRIPT.indexOf("if($p.mode -eq 'search-only' -and $p.searchName)"),SCRIPT.indexOf('$query=$p.phone.Substring'));
  assert.match(branch,/SetValue\(\[string\]\$p.searchName\)/);assert.match(branch,/Current.Value/);
  assert.match(branch,/Reply 'prepared'/);assert(!/SendKeys|Invoke|Clipboard|Enter/.test(branch));
  assert(SCRIPT.indexOf('GetForegroundWindow() -ne $handle')<SCRIPT.indexOf("$ws.SendKeys('^f')"));
});
test('삭제된 연결 대기·스토어 열기 요청은 더 이상 실행하지 않는다',async()=>{
  const a=automation();
  await assert.rejects(()=>a.client.command({action:'phone-status'}),/허용되지 않은/);
  assert.equal(a.spawned.length,0);assert.equal(a.opens.length,0);
});
test('LAN notice QR scopes customer, rejects host/origin/expiry, deduplicates mobile submissions',async()=>{
  let tick=Date.now(),saved=0;
  const notices={
    context:id=>{if(id!=='order-a'&&id!=='order-b')throw Error('잘못된 주문');return{customerName:id==='order-a'?'검사고객':'다른고객',customerPhone:id==='order-a'?'01000000001':'01000000002'};},
    listOrders:()=>[{orderId:'order-a',customerName:'검사고객',phoneLast4:'0001',visitDate:'2026-11-21'},{orderId:'order-b',customerName:'다른고객',phoneLast4:'0002',visitDate:'2026-11-21'}],
    save:(x,source)=>{saved++;assert.equal(source,'mobile');return {notice:{id:'saved-'+saved,...x,source}};},
  };
  const bridge=createNoticeMobile({getNotices:()=>notices,native:true,addresses:()=>['127.0.0.1'],host:'127.0.0.1',now:()=>tick});
  try{
    const qr=await bridge.start({customerScope:{name:'검사고객',phone:'01000000001'}}),url=new URL(qr.url),token=url.searchParams.get('token');
    const root=url.origin,headers={'Content-Type':'application/json','X-K99-Notice-Token':token,Origin:root};
    const list=await (await fetch(root+'/api/mobile-notice/orders?token='+token)).json();assert.deepEqual(list.orders.map(o=>o.orderId),['order-a']);
    const page=await fetch(qr.url);assert.equal(page.status,200);assert.match(await page.text(),/휴대폰 키보드의 마이크/);
    const input={orderId:'order-a',body:'휴대폰에서 입력한 특별 고지',theme:'오염 안내',requestId:'mobile-test-1'};
    for(let i=0;i<2;i++){const r=await fetch(root+'/api/mobile-notice/save',{method:'POST',headers,body:JSON.stringify(input)});assert.equal(r.status,200);}
    assert.equal(saved,1);
    const other=await fetch(root+'/api/mobile-notice/save',{method:'POST',headers,body:JSON.stringify({...input,orderId:'order-b',requestId:'mobile-test-2'})});assert.equal(other.status,403);
    assert.equal((await fetch(root+'/api/mobile-notice/save',{method:'POST',headers:{...headers,Origin:'http://evil.test'},body:JSON.stringify(input)})).status,403);
    // fetch can ignore a caller-supplied Host; use an actual HTTP request.
    const badHost=await new Promise((resolve,reject)=>{
      const req=require('node:http').get(root+'/api/mobile-notice/orders?token='+token,{headers:{Host:'evil.test'}},r=>{r.resume();resolve(r.statusCode);});
      req.on('error',reject);
    });
    assert.equal(badHost,403);
    tick+=11*60*1000;assert.equal((await fetch(qr.url)).status,410);
  }finally{bridge.close();}
});
test('new runtime files are explicitly staged and checked; existing camera/printing modules are not replaced',()=>{
  const root=path.resolve(__dirname,'../../..'),stage=fs.readFileSync(path.join(root,'scripts/stage-windows-app.cjs'),'utf8');
  const verify=fs.readFileSync(path.join(root,'scripts/verify-windows-portable.cjs'),'utf8');
  for(const f of ['customer-notices.cjs','notice-mobile.cjs','notice-mobile-page.cjs']){assert(stage.includes(f));assert(verify.includes(f));}
  assert(verify.includes('services/autoMessenger.js'));assert(verify.includes('services/package.json'));
  assert(!fs.readFileSync(path.join(__dirname,'../electron/services/autoMessenger.js'),'utf8').includes('spawnSync'));
});
test('existing mobile photo QR exposes a scoped notice tab without closing capture or saving fake photos',async()=>{
  const {createMobilePhotoBridge}=require('../electron/mobile-photo-bridge.cjs');let pictures=0,linked;
  const input={orderId:'order-a',customerName:'검사고객',customerPhone:'01000000001'};
  const bridge=createMobilePhotoBridge({host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1'],
    validateTarget:i=>({...i,phoneLast4:'0001',itemName:'검사 의류',folderIdentifier:'검사폴더'}),
    capture:()=>{pictures++;},noticeLink:i=>{linked=i;return {url:'http://127.0.0.1:1234/mobile-notice?token=notice-test'};}});
  try{
    const q=await bridge.api('POST','/api/mobile-photo/start',input),url=new URL(q.urls[0]),token=url.searchParams.get('token');
    const r=await fetch(url.origin+'/api/mobile-notice-link?token='+token);assert.equal(r.status,200);
    assert.equal((await r.json()).url,'http://127.0.0.1:1234/mobile-notice?token=notice-test');
    assert.equal(linked.customerPhone,input.customerPhone);assert.equal(pictures,0);
    const status=await bridge.api('GET','/api/mobile-photo/status?id='+q.id);
    assert.equal(status.id,q.id);
  }finally{bridge.close();}
});
