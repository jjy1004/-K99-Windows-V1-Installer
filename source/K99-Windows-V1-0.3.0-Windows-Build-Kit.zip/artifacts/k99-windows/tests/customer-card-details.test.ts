import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {CustomerNoticeOrderSummary,CustomerNoticeTemplateChoices} from '../src/CustomerNoticeDetails';
import {createConfirmedOrder} from '../src/order-record';
import {listGarments} from '../src/garment-scanner';
import {reviseInspectionPayment} from '../src/inspection-payment';
import {isCustomerCardControl,openCustomerCardDetails} from '../src/customer-card-details';
import {OPEN_CUSTOMER_NOTICE,openCustomerNotice,messenger,type NoticeContext,type NoticeTemplate} from '../src/notice-api';

function fixture(){
  const base=createConfirmedOrder({id:'DETAIL-TEST',customerName:'검증 고객',customerPhone:'01000000000',customerAddress:'검증 주소',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
    {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,
      requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''},new Date('2026-11-24T01:00:00Z'));
  return reviseInspectionPayment({...base,garments:listGarments(base)},'POSTPAID');
}
const context:NoticeContext={orderId:'DETAIL-TEST',customerName:'검증 고객',customerPhone:'01000000000',customerAddress:'검증 주소',
  items:[{name:'와이셔츠',quantity:2,amount:10000}],total:10000,paymentType:'POSTPAID'};
const source=(name:string)=>readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');

test('상세 요약은 실제 고객·품목·수량·청구금액과 후불 미결제 배지를 표시한다',()=>{
  const html=renderToStaticMarkup(createElement(CustomerNoticeOrderSummary,{context,order:fixture()}));
  for(const value of ['검증 고객','01000000000','검증 주소','와이셔츠','10,000원','후불(미결제)','notice-payment-unpaid'])
    assert.ok(html.includes(value),value);
  assert.ok(html.includes('data-unpaid="true"'));
});
test('선불 및 이미 수금한 후불은 상세창에서도 미결제 경고를 표시하지 않는다',()=>{
  const order=fixture();
  for(const saved of [reviseInspectionPayment(order,'PREPAID'),{...order,payment_status:'PAID' as const,
    payment:{type:'POSTPAID' as const,status:'PAID' as const,paidAmount:10000,updatedAt:order.intakeAt}}]){
    const html=renderToStaticMarkup(createElement(CustomerNoticeOrderSummary,{context,order:saved}));
    assert.ok(!html.includes('notice-payment-unpaid'));
    assert.ok(html.includes('data-unpaid="false"'));
  }
});
test('수기 택만 표시하며 프린터 태그와 과거 주문 데이터는 바꾸지 않는다',()=>{
  const order=fixture();
  const saved={...order,garments:order.garments!.map((g,i)=>({...g,tagMode:i===0?'roll' as const:'xprinter' as const,tagNumber:i===0?'22-1':'HIDDEN-PRINT'}))};
  const before=JSON.stringify(saved);
  const html=renderToStaticMarkup(createElement(CustomerNoticeOrderSummary,{context,order:saved}));
  assert.ok(html.includes('22-1'));assert.ok(!html.includes('HIDDEN-PRINT'));
  assert.equal(JSON.stringify(saved),before);
});
test('안내문 아이콘은 전달된 템플릿과 선택 상태를 그대로 사용하고 개인정보를 HTML로 실행하지 않는다',()=>{
  const templates:NoticeTemplate[]=[{id:'inspection-consent',title:'면책·동의',stage:'before',text:'기존 문구',revision:1},
    {id:'complete-pickup',title:'완성 수령',stage:'before',text:'기존 문구',revision:1}];
  const html=renderToStaticMarkup(createElement(CustomerNoticeTemplateChoices,{title:'세탁 전',templates,
    selectedId:'inspection-consent',busy:false,onSelect:()=>{}}));
  assert.equal((html.match(/<button/g)||[]).length,2);assert.equal((html.match(/<svg/g)||[]).length,2);
  assert.ok(html.includes('aria-pressed="true"'));
  const escaped=renderToStaticMarkup(createElement(CustomerNoticeOrderSummary,{context:{...context,customerName:'<script>금지</script>'},order:null}));
  assert.ok(!escaped.includes('<script>'));
});
test('카드 상세 열기는 기존 알림 이벤트를 확장하고 기존 호출의 계약은 보존한다',()=>{
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'window');
  const win=new EventTarget();Object.defineProperty(globalThis,'window',{configurable:true,value:win});
  try{
    const received:unknown[]=[];win.addEventListener(OPEN_CUSTOMER_NOTICE,e=>received.push((e as CustomEvent).detail));
    openCustomerCardDetails('검수');openCustomerCardDetails('출고','complete-pickup');openCustomerNotice('기존','additional-fee');
    assert.deepEqual(received,[{orderId:'검수',templateId:'inspection-consent',showOrderDetails:true},
      {orderId:'출고',templateId:'complete-pickup',showOrderDetails:true},{orderId:'기존',templateId:'additional-fee'}]);
  }finally{if(descriptor)Object.defineProperty(globalThis,'window',descriptor);else Reflect.deleteProperty(globalThis,'window');}
});
test('독립 버튼·선택 칸은 카드 클릭에서 제외하고 빈 영역만 허용한다',()=>{
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'Element');
  class Target extends EventTarget{constructor(private control:boolean){super();}closest(selector:string){assert.match(selector,/button,input,select/);return this.control?this:null;}}
  Object.defineProperty(globalThis,'Element',{configurable:true,value:Target});
  try{assert.equal(isCustomerCardControl(new Target(true)),true);assert.equal(isCustomerCardControl(new Target(false)),false);assert.equal(isCustomerCardControl(null),false);}
  finally{if(descriptor)Object.defineProperty(globalThis,'Element',descriptor);else Reflect.deleteProperty(globalThis,'Element');}
});
test('Windows 카카오톡 경계에는 수정 본문·고객 번호를 그대로 전달하며 미연결은 발송 성공으로 기록하지 않는다',async()=>{
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'window');
  const received:unknown[]=[];
  Object.defineProperty(globalThis,'window',{configurable:true,value:{k99Desktop:{messenger:async(input:unknown)=>{
    received.push(input);return {success:true,status:'prepared',channel:'kakao'};
  }}}});
  try{
    const command={action:'kakao-compose' as const,recipient:'01000000000',customerName:'검증고객',body:'직원이 수정한 안내문\n실제 발송은 하지 않습니다.'};
    const result=await messenger(command);
    assert.deepEqual(received,[command]);assert.equal(result.status,'prepared');
    Object.defineProperty(globalThis,'window',{configurable:true,value:{}});
    const unavailable=await messenger(command);
    assert.equal(unavailable.success,false);assert.equal(unavailable.manualRequired,true);
  }finally{if(descriptor)Object.defineProperty(globalThis,'window',descriptor);else Reflect.deleteProperty(globalThis,'window');}
});
test('두 목록의 상세 진입점과 원문은 보존하고 문자·카톡은 중간 팝업 없이 한 번에 연결한다',()=>{
  for(const name of ['LaundryDesk.tsx','GarmentScannerWorkspace.tsx']){
    const text=source(name);assert.match(text,/isCustomerCardControl\(event\.target\)/);assert.match(text,/openCustomerCardDetails\(/);
  }
  const editor=source('NoticeCenter.tsx');
  assert.match(editor,/CustomerNoticeOrderSummary context=\{ctx\}/);
  assert.match(editor,/showOrderDetails=\{notice\.showOrderDetails\}/);
  assert.match(editor,/launchLabel=\{showOrderDetails\?/);
  const actions=source('LocalNoticeDialogs.tsx');
  assert.doesNotMatch(actions,/aria-expanded=\{choosing\}|setChoosing|<SmsComposeContents/);
  assert.match(actions,/onPrepare \? await onPrepare\(\)/);
  assert.match(actions,/prepared === false/);
  assert.match(actions,/prepareLocalDelivery\(notice,phone,kind==='sms'\?'full-clipboard':'kakao-clipboard',fullBody\)/);
  assert.doesNotMatch(actions,/summarizeSmsBody|FastSmsQr|SmsQrContents/);
  assert.match(actions,/buildSmsUri\(phone, fullBody\)/);
  assert.match(actions,/body:fullBody,recipient:phone/);
  assert.match(actions,/action:kind==='sms'\?'sms-compose':'kakao-compose'/);
  assert.match(actions,/customerName:context\?\.context\.customerName\|\|customerName/);
  assert.match(actions,/confirmLocalDelivery\(attemptId,'button-click'\)/);
  assert.match(actions,/role="status"/);
  assert(!actions.includes('kakao-download'));
});
