import { test } from 'node:test';
import assert from 'node:assert/strict';
import { installKoreanInputs } from '../src/korean-inputs';

test('Korean hints cover existing/new inputs and focus without intercepting IME or scanner keys', () => {
  const previous = ['MutationObserver', 'HTMLInputElement', 'HTMLTextAreaElement'].map(key => [key, Object.getOwnPropertyDescriptor(globalThis, key)] as const);
  class Input { lang = 'en'; }
  class Textarea { lang = ''; }
  const inputs = [new Input(), new Textarea()];
  let mutate: () => void = () => {};
  let disconnected = false;
  const listeners = new Map<string, (event: unknown) => void>();
  const doc = { documentElement: { lang: '' }, querySelectorAll: () => inputs,
    addEventListener: (name: string, callback: (event: unknown) => void) => listeners.set(name, callback),
    removeEventListener: (name: string) => listeners.delete(name) };
  Object.assign(globalThis, { HTMLInputElement: Input, HTMLTextAreaElement: Textarea,
    MutationObserver: class {
      constructor(callback: () => void) { mutate = callback; }
      observe() {}
      disconnect() { disconnected = true; }
    } });
  try {
    const stop = installKoreanInputs(doc as unknown as Document);
    assert.equal(doc.documentElement.lang, 'ko');
    assert.ok(inputs.every(input => input.lang === 'ko'));
    const added = new Input(); inputs.push(added); mutate(); assert.equal(added.lang, 'ko');
    added.lang = 'en'; listeners.get('focusin')!({ target: added }); assert.equal(added.lang, 'ko');
    assert.deepEqual([...listeners.keys()], ['focusin'], 'no keyboard/composition handler is installed');
    stop(); assert.equal(disconnected, true); assert.equal(listeners.size, 0);
  } finally {
    for (const [key, descriptor] of previous) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
