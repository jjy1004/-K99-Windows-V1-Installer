import { test } from 'node:test';
import assert from 'node:assert/strict';
import { installKoreanInputs } from '../src/korean-inputs';

test('Korean hints cover existing/new inputs and focus without intercepting IME or scanner keys', () => {
  const previous = ['MutationObserver', 'HTMLInputElement', 'HTMLTextAreaElement'].map(key => [key, Object.getOwnPropertyDescriptor(globalThis, key)] as const);
  class Input {
    lang = 'en'; tagName = 'INPUT'; type = 'text'; inputMode = ''; readOnly = false;
    dataset: Record<string, string> = {}; id = ''; name = ''; placeholder = '';
    style = { getPropertyValue: () => '', setProperty() {} };
    getAttribute() { return null; }
    closest() { return null; }
  }
  class Textarea extends Input { lang = ''; tagName = 'TEXTAREA'; }
  const inputs = [new Input(), new Textarea()];
  let mutate: () => void = () => {};
  let disconnected = false;
  const listeners = new Map<string, (event: unknown) => void>();
  const doc = { documentElement: { lang: '' }, querySelectorAll: () => inputs,
    addEventListener: (name: string, callback: (event: unknown) => void) => listeners.set(name, callback),
    removeEventListener: (name: string) => listeners.delete(name) };
  Object.assign(globalThis, { HTMLInputElement: Input, HTMLTextAreaElement: Textarea,
    MutationObserver: class {
      constructor(callback: () => void) { mutate = callback; }
      observe() {}
      disconnect() { disconnected = true; }
    } });
  try {
    const stop = installKoreanInputs(doc as unknown as Document);
    assert.equal(doc.documentElement.lang, 'ko');
    assert.ok(inputs.every(input => input.lang === 'ko'));
    const added = new Input(); inputs.push(added); mutate(); assert.equal(added.lang, 'ko');
    added.lang = 'en'; listeners.get('focusin')!({ target: added }); assert.equal(added.lang, 'ko');
    assert.deepEqual([...listeners.keys()], ['focusin', 'compositionstart', 'compositionend', 'focusout', 'input', 'keydown']);
    listeners.get('compositionstart')!({target: added});
    assert.equal(added.dataset.koreanComposing,'true');
    let prevented = false;
    listeners.get('keydown')!({target: added,key:'F7',isComposing:true,preventDefault(){prevented=true;}});
    assert.equal(prevented,false,'native IME and scanner/function keys retain ownership');
    listeners.get('compositionend')!({target: added});
    assert.equal(added.dataset.koreanComposing,undefined);
    stop(); assert.equal(disconnected, true); assert.equal(listeners.size, 0);
  } finally {
    for (const [key, descriptor] of previous) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
test('first ASCII keystroke yields to native IME before compositionstart; 229 and commit never duplicate Korean', async () => {
  const names=['MutationObserver','HTMLInputElement','HTMLTextAreaElement'];
  const old=names.map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)] as const);
  const listeners=new Map<string,(e:unknown)=>void>();
  class Input {
    lang='';tagName='INPUT';type='text';inputMode='';readOnly=false;isConnected=true;
    dataset:Record<string,string>={};id='customer-address';name='';placeholder='주소';selectionStart=1;
    _value='';get value(){return this._value;}set value(v:string){this._value=v;}
    style={getPropertyValue:()=>'',setProperty(){}};
    getAttribute(){return null;}closest(){return null;}
    setSelectionRange(n:number){this.selectionStart=n;}
    dispatchEvent(e:Event){listeners.get(e.type)?.({target:this});return true;}
  }
  const input=new Input();
  Object.assign(globalThis,{HTMLInputElement:Input,HTMLTextAreaElement:class extends Input{},
    MutationObserver:class {observe(){}disconnect(){}}});
  const doc={documentElement:{lang:''},querySelectorAll:()=>[input],
    addEventListener:(k:string,f:(e:unknown)=>void)=>listeners.set(k,f),
    removeEventListener:(k:string)=>listeners.delete(k)};
  const wait=()=>new Promise(r=>setTimeout(r,60));
  const type=(value:string,data:string,isComposing=false)=>{
    input.value=value;listeners.get('input')!({target:input,inputType:'insertText',data,isComposing});
  };
  let stop:()=>void=()=>{};
  try{
    stop=installKoreanInputs(doc as unknown as Document);
    type('r','r');
    assert.equal(input.value,'r','do not rewrite before the browser can start IME');
    listeners.get('compositionstart')!({target:input});
    type('김용남','김용남',true);await wait();
    assert.equal(input.value,'김용남');
    listeners.get('compositionend')!({target:input});
    type('김용남','김용남');await wait();assert.equal(input.value,'김용남');
    listeners.get('keydown')!({target:input,key:'Process',keyCode:229});
    type('서울시 서초구','서초구',true);await wait();assert.equal(input.value,'서울시 서초구');
    listeners.get('compositionend')!({target:input});
    type('rla','a');await wait();assert.equal(input.value,'김','English-mode fallback still works');
  }finally{
    stop();
    for(const[k,d]of old){if(d)Object.defineProperty(globalThis,k,d);else Reflect.deleteProperty(globalThis,k);}
  }
});
