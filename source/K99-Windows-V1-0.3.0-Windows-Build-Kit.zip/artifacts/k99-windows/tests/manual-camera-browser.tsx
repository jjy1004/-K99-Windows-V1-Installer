/** Isolated browser QA only. Never imported by the application entrypoint. */
import React,{useEffect,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {CameraColorSliders} from '../src/CameraColorSliders';
import {useManualCamera} from '../src/use-manual-camera';
import {useCameraColorPreview} from '../src/use-camera-color-preview';
import {correctCameraCanvas} from '../src/camera-color';
import {openPreferredCamera} from '../src/camera-capture-controls';
import {showCameraVideo} from '../src/camera-video';
import {SmartphoneCameraHelp} from '../src/SmartphoneCameraHelp';
const device='qa-manual-camera',audit={calls:[] as unknown[],hardwareCalls:[] as unknown[],unsupported:false,error:'',captures:0};
const timers=new Set<ReturnType<typeof setInterval>>();
const synthetic={
  enumerateDevices:async()=>[{deviceId:device,kind:'videoinput',label:'SU200MB (2bc5:0529) · 검사 영상'}],
  getUserMedia:async(c:MediaStreamConstraints)=>{
    audit.calls.push(c);
    const request=typeof c.video==='object'?c.video:{};
    const ideal=(value:unknown,fallback:number)=>typeof value==='object'&&value&&'ideal'in value?Number(value.ideal):fallback;
    const w=audit.unsupported?640:ideal(request.width,1920),h=audit.unsupported?480:ideal(request.height,1080);
    const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
    const g=canvas.getContext('2d')!;
    g.fillStyle='#edf1ee';g.fillRect(0,0,w,h);
    g.fillStyle='#4066ac';g.fillRect(w*.15,h*.15,w*.35,h*.7);
    g.fillStyle='#a84c40';g.fillRect(w*.5,h*.15,w*.35,h*.7);
    const stream=canvas.captureStream(10),track=stream.getVideoTracks()[0];
    const settings=track.getSettings.bind(track),originalStop=track.stop.bind(track);
    const hardware={exposureMode:'manual',whiteBalanceMode:'manual',focusMode:'manual',exposureTime:20,gain:10};
    Object.defineProperty(track,'getSettings',{value:()=>({...settings(),deviceId:device,...hardware})});
    Object.defineProperty(track,'getCapabilities',{value:()=>({exposureMode:['manual','continuous'],
      whiteBalanceMode:['manual','continuous'],focusMode:['manual','continuous'],
      exposureTime:{min:1,max:200,step:1},gain:{min:0,max:24,step:1}})});
    Object.defineProperty(track,'applyConstraints',{value:async(c:MediaTrackConstraints)=>{
      audit.hardwareCalls.push(c);Object.assign(hardware,c.advanced?.[0]??{});
    }});
    let tick=false;
    const timer=setInterval(()=>{tick=!tick;g.fillStyle=tick?'#fff':'#000';g.fillRect(w-12,h-12,10,10);},100);
    timers.add(timer);
    Object.defineProperty(track,'stop',{value:()=>{clearInterval(timer);timers.delete(timer);originalStop();}});
    return stream;
  },
};
Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:synthetic});
function Fixture(){
  const video=useRef<HTMLVideoElement|null>(null),stream=useRef<MediaStream|null>(null);
  const [ready,setReady]=useState(false),[shot,setShot]=useState('');
  const [phone,setPhone]=useState(false),[help,setHelp]=useState(()=>new URLSearchParams(location.search).get('help')==='1');
  const manual=useManualCamera(video,stream,device,ready,phone?'Iriun Virtual Camera':'SU200MB (2bc5:0529)'),preview=useCameraColorPreview(video,ready,manual.profile);
  const current=useRef(manual);current.current=manual;
  useEffect(()=>{
    let live=true;
    void openPreferredCamera(device).then(async s=>{
      if(!live){s.getTracks().forEach(t=>t.stop());return;}
      stream.current=s;await showCameraVideo(video.current!,s);if(live)setReady(true);
    }).catch(error=>{audit.error=String(error);});
    return()=>{live=false;stream.current?.getTracks().forEach(t=>t.stop());};
  },[]);
  function capture(){
    const v=video.current!;if(!v.videoWidth)throw Error('검사 영상이 준비되지 않았습니다.');
    const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;
    const g=c.getContext('2d')!;g.drawImage(v,0,0);correctCameraCanvas(g,current.current.profile);
    audit.captures++;setShot(c.toDataURL('image/jpeg',.95));return c;
  }
  Object.assign(window,{k99CameraAudit:{
    state:()=>({profile:current.current.profile,note:current.current.note,changing:current.current.changing,
      ready,width:video.current?.videoWidth,height:video.current?.videoHeight,
      live:stream.current?.getVideoTracks()[0]?.readyState,calls:audit.calls,hardwareCalls:audit.hardwareCalls,
      hardware:current.current.hardware.state,hardwareBusy:current.current.hardware.busy,
      passthrough:current.current.passthrough,calibrating:current.current.calibrating,error:audit.error,captures:audit.captures}),
    parity:()=>{
      const v=video.current!,saved=capture(),s=saved.getContext('2d')!;
      const shown=current.current.profile.brightness===0&&current.current.profile.contrast===0&&
        current.current.profile.temperature===0&&current.current.profile.saturation===0&&current.current.profile.sharpness===0
        ?saved:preview.canvas.current!;
      const p=shown.getContext('2d')!;let max=0;
      for(const [x,y] of [[.3,.5],[.7,.5],[.5,.08]]){
        const a=s.getImageData(Math.floor(v.videoWidth*x),Math.floor(v.videoHeight*y),1,1).data;
        const b=p.getImageData(Math.floor(shown.width*x),Math.floor(shown.height*y),1,1).data;
        for(let i=0;i<4;i++)max=Math.max(max,Math.abs(a[i]-b[i]));
      }
      return {maxDifference:max,width:saved.width,height:saved.height,jpeg:!!shot||saved.toDataURL('image/jpeg').startsWith('data:image/jpeg;')};
    },
  }});
  return <main style={{maxWidth:1200,margin:'24px auto',padding:20,fontFamily:'sans-serif',color:'#fff'}}>
    <h1>카메라 수동 화질 검사</h1>
    <p>합성 USB 영상 검사 전용 · 실제 SU200MB / Windows 검증 아님 · 매장 DB 연결 없음</p>
    <button type="button" data-testid="audit-open-phone-help" onClick={()=>setHelp(true)}>휴대폰 카메라 연결 도우미</button>
    {help&&<SmartphoneCameraHelp onClose={()=>setHelp(false)} onAction={async action=>({message:`검사용 ${action} 요청 확인 · 실제 프로그램 실행·설치 없음`})}/>}
    <label><input type="checkbox" data-testid="audit-phone-mode" checked={phone} onChange={e=>setPhone(e.target.checked)}/>Iriun 원본 모드 모의</label>
    <div style={{position:'relative',height:300,background:'#111',overflow:'hidden'}}>
      <video ref={video} muted playsInline style={{width:'100%',height:'100%',objectFit:'contain'}}/>
      <canvas ref={preview.canvas} style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'contain',
        visibility:preview.ready?'visible':'hidden',pointerEvents:'none'}}/>
      {manual.freeze&&<img src={manual.freeze} alt="" style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'contain'}}/>}
    </div>
    {manual.passthrough?<p data-testid="audit-phone-raw">휴대폰 원본 화질 · PC 보정 없음</p>:<CameraColorSliders {...manual}/>}
    <label><input type="checkbox" data-testid="force-resolution-failure" onChange={e=>{audit.unsupported=e.target.checked;}}/>다음 해상도 요청 미지원 모의</label>
    <button type="button" onClick={capture} data-testid="audit-capture">검사 촬영</button>
    <p data-testid="audit-ready">{ready?'영상 준비 완료':'영상 준비 중'}</p>
    {shot&&<img src={shot} alt="수동 보정 저장 검사 사진" style={{width:200,display:'block'}}/>}
  </main>;
}
createRoot(document.getElementById('root')!).render(<Fixture/>);
