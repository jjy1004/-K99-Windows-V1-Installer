import test from 'node:test';
import assert from 'node:assert/strict';
import { convertEngToKor } from '../src/utils/koreanAutomata';
import { composeKoreanInput, convertKoreanSearch } from '../src/korean-input-conversion';

test('supplied two-set converter plus live adapter compose Korean names per keystroke', () => {
  assert.equal(convertEngToKor('rn'), '구');
  assert.equal(composeKoreanInput('kp'), 'ㅏㅔ');
  let display = '';
  for (const key of 'rlarntn') display = composeKoreanInput(display + key);
  assert.equal(display, '김구수');
  assert.equal(composeKoreanInput('ghdrlfehd'), '홍길동');
  assert.equal(composeKoreanInput('Rkrrn'), '깍구');
});
test('compound vowel/final transfer, isolated vowels and native Korean are preserved', () => {
  assert.equal(composeKoreanInput('rkqtdl'), '값이');
  assert.equal(composeKoreanInput('dlfrdj'), '읽어');
  assert.equal(composeKoreanInput('rhk'), '과');
  assert.equal(composeKoreanInput('hk'), 'ㅘ');
  assert.equal(composeKoreanInput('ㅗk'), 'ㅘ');
  assert.equal(composeKoreanInput('김민수 고객님'), '김민수 고객님');
  assert.equal(composeKoreanInput(''), '');
  assert.equal(composeKoreanInput('rla anstn'), '김 문수');
});
test('search phone/order/barcode punctuation stays literal; only human name letters convert', () => {
  for (const value of ['6789', '010-1234-5678', 'K99-AB12', 'garment_ABC', 'abc@example.com']) {
    assert.equal(convertKoreanSearch(value), value);
  }
  assert.equal(convertKoreanSearch('rlarntn'), '김구수');
});
