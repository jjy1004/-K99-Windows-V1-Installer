import {test} from 'node:test';
import assert from 'node:assert/strict';
import {showCameraVideo} from '../src/camera-video';

test('메타데이터 크기만 있고 첫 영상 프레임이 없으면 연결 성공으로 표시하지 않는다',async()=>{
  const stream={} as MediaStream;
  const video={srcObject:null,readyState:1,videoWidth:1920,videoHeight:1080,
    play:async()=>{}} as unknown as HTMLVideoElement;
  let shown=false;
  const open=showCameraVideo(video,stream,200).then(()=>{shown=true;});
  await new Promise(r=>setTimeout(r,10));
  assert.equal(shown,false);
  Object.assign(video,{readyState:2});
  await open;assert.equal(shown,true);
  assert.equal(video.srcObject,stream);
});
test('크기 0 또는 프레임이 오지 않는 수신기는 제한 시간 후 실패한다',async()=>{
  for(const [readyState,videoWidth] of [[2,0],[1,1920]]){
    const video={srcObject:null,readyState,videoWidth,videoHeight:1080,
      play:async()=>{}} as unknown as HTMLVideoElement;
    await assert.rejects(showCameraVideo(video,{} as MediaStream,20),/영상 프레임/);
  }
});
test('연결 도중 다른 요청으로 바뀐 비디오는 첫 요청의 성공으로 오인하지 않는다',async()=>{
  const video={srcObject:null,readyState:2,videoWidth:1920,videoHeight:1080,
    play:async()=>{video.srcObject={} as MediaStream;}} as unknown as HTMLVideoElement;
  await assert.rejects(showCameraVideo(video,{} as MediaStream,50),/취소/);
});
