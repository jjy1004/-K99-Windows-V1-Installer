import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (name: string) => fs.readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
test('하드웨어 실제 테스트는 미저장 영수증 설정을 전송하지 않고 라벨 인쇄 경로는 유지한다', () => {
  const source = read('HardwareSettings.tsx');
  const call = source.slice(source.indexOf("action: 'test'"), source.indexOf("action: 'test'") + 160);
  assert.match(call, /kind === 'label' \? \{ printerName \} : \{\}/);
  assert.doesNotMatch(call, /receiptConfig|config:/);
  assert.match(source, /savePart\('save-receipt', receiptConfig/);
});
test('실제 접수증 인쇄는 미리보기 폭과 설정을 전송하지 않고 저장 설정 안내를 표시한다', () => {
  const source = read('ReceiptPrintDialog.tsx');
  const call = source.slice(source.indexOf("action: 'receipt-print'"), source.indexOf("action: 'receipt-print'") + 150);
  assert.match(call, /receipt \? \{ receipt \} : \{\}/);
  assert.doesNotMatch(call, /config:|receiptWidth|JSON\.parse/);
  assert.match(source, /미리보기 전용/);
  assert.match(source, /config: \{ \.\.\.JSON\.parse\(cfgKey\), receiptWidth: width \}/, '미리보기 자체의 폭 선택은 유지');
});
