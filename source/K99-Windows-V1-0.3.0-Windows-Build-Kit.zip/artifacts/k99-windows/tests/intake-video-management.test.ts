import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { IntakeIdentity, intakeDateCode } from '../src/IntakeIdentity';
import { DEFAULT_GUIDE_SLOTS } from '../src/guide-videos';
import { ArchivedHandoverGrid } from '../src/HandoverAgeBoard';
import { createConfirmedOrder } from '../src/order-record';

test('접수 날짜는 기존 한국 매장 날짜 기준을 사용하고 누락·잘못된 값은 만들지 않는다',()=>{
  assert.equal(intakeDateCode('2026-11-17'),'261117');
  assert.equal(intakeDateCode('2026-11-16T15:30:00.000Z'),'261117');
  assert.equal(intakeDateCode('2026-11-16T14:59:59.000Z'),'261116');
  assert.equal(intakeDateCode('2026-11-17T00:00:00+09:00'),'261117');
  assert.equal(intakeDateCode('2026-11-17T00:00:00'),'261117');
  for(const value of ['',null,undefined,'잘못된 날짜','2026-02-31','2026-13-01',0,'2026-11-17T99:00:00Z'])assert.equal(intakeDateCode(value),null);
});
test('날짜·이름·전체 전화가 같은 식별 줄에 있고 날짜만 배지로 강조한다',()=>{
  const html=renderToStaticMarkup(React.createElement(IntakeIdentity,{order:{intakeAt:'2026-11-17',customerName:'홍길동',customerPhone:'010-1234-5678'}}));
  assert.match(html,/intake-date-badge/);
  assert.ok(html.indexOf('261117')<html.indexOf('홍길동'));
  assert.ok(html.includes('010-1234-5678'));
  const missing=renderToStaticMarkup(React.createElement(IntakeIdentity,{order:{customerName:'긴 고객 이름'.repeat(10),customerPhone:''}}));
  assert.ok(missing.includes('접수일 미상'));assert.ok(missing.includes('전화번호 미등록'));
  const css=fs.readFileSync(new URL('../src/intake-identity.css',import.meta.url),'utf8');
  assert.match(css,/font-weight:800/);assert.match(css,/flex-wrap:wrap/);
});
test('검수·진행·완성 출고의 목록과 상세에 공통 표시를 연결한다',()=>{
  for(const name of ['InspectionStageDesk','LaundryProcessView','GarmentScannerWorkspace','HandoverAgeBoard','OrderWorkflowView']){
    const source=fs.readFileSync(new URL(`../src/${name}.tsx`,import.meta.url),'utf8');
    assert.match(source,/<IntakeIdentity order=\{order\}/);
  }
  const scanner=fs.readFileSync(new URL('../src/GarmentScannerWorkspace.tsx',import.meta.url),'utf8');
  assert.match(scanner,/<IntakeIdentity order=\{item\}/);
  assert.match(fs.readFileSync(new URL('../src/LaundryDesk.tsx',import.meta.url),'utf8'),/<IntakeDateBadge intakeAt=\{order.intakeAt\}/);
});
test('기존 네 버튼·명령 식별자는 바꾸지 않고 여섯 번째 설정과 실제 전송 경로를 추가한다',()=>{
  assert.deepEqual(DEFAULT_GUIDE_SLOTS.map(slot=>slot.video),['value','process','water','sneakers']);
  const read=(file:string)=>fs.readFileSync(new URL(file,import.meta.url),'utf8');
  assert.match(read('../src/NoticeCenter.tsx'),/\['videos', '영상 관리'/);
  assert.match(read('../src/VideoManagement.tsx'),/video-slots-table/);
  assert.match(read('../src/VideoManagement.tsx'),/Promise\.allSettled/);
  assert.match(read('../electron/main.cjs'),/guideVideos\.response\(request\)/);
  assert.match(read('../electron/main.cjs'),/action !== 'list' && event\.sender !== mainWindow\.webContents/);
  assert.match(read('../electron/preload.cjs'),/k99:guide-videos-changed/);
  assert.match(read('../../../scripts/stage-windows-app.cjs'),/'guide-videos.cjs'/);
  assert.match(read('../src/CustomerMedia.tsx'),/guideSlots\.find/);
  assert.match(read('../src/App.tsx'),/guideSlots\.find/);
});

test('장기 보관의 기존 간략 표시 계약은 보존하고 실제 출고 화면은 전체 식별 표시를 선택한다',()=>{
  const order=createConfirmedOrder({id:'ARCHIVE-IDENTITY',customerName:'홍길동',customerPhone:'010-1234-5678',customerAddress:'',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
    {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''},
    new Date('2026-11-17T03:00:00+09:00'));
  const props={orders:[order],onOpen(){},registerCard(){}};
  const compact=renderToStaticMarkup(React.createElement(ArchivedHandoverGrid,props));
  assert.ok(!compact.includes('010-1234-5678'));
  const full=renderToStaticMarkup(React.createElement(ArchivedHandoverGrid,{...props,showIntakeIdentity:true}));
  assert.ok(full.includes('261117'));assert.ok(full.includes('010-1234-5678'));
  const scanner=fs.readFileSync(new URL('../src/GarmentScannerWorkspace.tsx',import.meta.url),'utf8');
  assert.match(scanner,/<ArchivedHandoverGrid[^>]+showIntakeIdentity/);
});
