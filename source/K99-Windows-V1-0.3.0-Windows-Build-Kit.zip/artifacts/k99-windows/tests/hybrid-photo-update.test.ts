import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createElement } from 'react';
import * as React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Router } from 'wouter';
import { BasketPopup } from '../src/components/BasketPopup';
import { mergeDraftCapture } from '../src/native-draft-state';
import type { DraftNativeUnit } from '../src/NativeDraftCamera';
import type { GarmentRecord, GarmentPhotoMetadata } from '../src/garment-record';

const photo = (requestId: string): GarmentPhotoMetadata => ({
  garmentId: 'draft-1-1', requestId, role: 'intake', status: 'saved',
  timestamp: '2026-11-06T00:00:00.000Z', origin: 'bridge',
});
const unit = (ids: string[]): DraftNativeUnit => ({
  unitKey: '1:1', rowId: 1, unitIndex: 1, itemId: 'shirt',
  garment: { garmentId: 'draft-1-1', photoHistory: ids.map(photo) } as GarmentRecord,
});

test('hybrid cumulative snapshots never lose PC/mobile shots when replies arrive in reverse order', () => {
  const pc = unit(['pc-001']);
  const mobile = unit(['pc-001', 'mobile-002']);
  const pcAgain = unit(['pc-001', 'mobile-002', 'pc-003']);
  let state = mergeDraftCapture([], pc);
  state = mergeDraftCapture(state, pcAgain);
  assert.equal(mergeDraftCapture(state, mobile), state);
  assert.equal(mergeDraftCapture(state, pc), state);
  assert.deepEqual(state[0].garment.photoHistory?.map(p => p.requestId), ['pc-001', 'mobile-002', 'pc-003']);
  const update = unit(['pc-001', 'mobile-002', 'pc-003', 'mobile-004']);
  state = mergeDraftCapture(state, update);
  assert.equal(state[0].garment.photoHistory?.length, 4);
  assert.equal(pc.garment.photoHistory?.length, 1, 'never mutate earlier snapshots');
});

test('snapshot merge preserves unit identity and rejects a different garment or missing photo IDs', () => {
  const initial = [unit(['pc-001', 'mobile-002'])];
  assert.equal(mergeDraftCapture(initial, unit(['pc-001', 'unrelated-003'])), initial);
  const wrongGarment = unit(['pc-001', 'mobile-002']);
  wrongGarment.garment.garmentId = 'another-garment';
  assert.equal(mergeDraftCapture(initial, wrongGarment), initial);
  const nextUnit = { ...unit(['next-001']), unitKey: '1:2', unitIndex: 2 };
  assert.equal(mergeDraftCapture(initial, nextUnit).length, 2);
  const changedItem = { ...unit(['changed-001']), itemId: 'coat' };
  assert.equal(mergeDraftCapture(initial, changedItem).length, 2, 'retain old unit evidence instead of reassigning');
});

test('management initially omits customer directory; fourth card opens a conditional modal', async () => {
  // SSR checks the actual initial JSX without a browser mock customer database.
  const { SimpleStatisticsCenter } = await import('../src/SimpleStatisticsCenter');
  // The standalone esbuild test harness uses classic JSX; Vite uses automatic JSX.
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'React');
  const windowDescriptor = Object.getOwnPropertyDescriptor(globalThis, 'window');
  Object.defineProperty(globalThis, 'React', { configurable: true, value: React });
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {} });
  let html: string;
  try {
    html = renderToStaticMarkup(createElement(Router, { ssrPath: '/management' },
      createElement(SimpleStatisticsCenter, { onBack() {}, onNewIntake() {} })));
  } finally {
    if (descriptor) Object.defineProperty(globalThis, 'React', descriptor);
    else Reflect.deleteProperty(globalThis, 'React');
    if (windowDescriptor) Object.defineProperty(globalThis, 'window', windowDescriptor);
    else Reflect.deleteProperty(globalThis, 'window');
  }
  assert.ok(html.includes('button-action-customers'));
  assert.ok(!html.includes('modal-management-customers'));
  assert.ok(!html.includes('management-customer-panel'));
  const source = fs.readFileSync('artifacts/k99-windows/src/SimpleStatisticsCenter.tsx', 'utf8');
  assert.match(source, /useState\(false\)/);
  assert.match(source, /const goCustomers = \(\) => setCustomersOpen\(true\)/);
  assert.match(source, /\{customersOpen && <Modal/);
  assert.equal((source.match(/<ManagementCustomerPanel\s*\/>/g) ?? []).length, 1);
  assert.match(source, /onClose=\{\(\) => setCustomersOpen\(false\)\}/);
  const camera = fs.readFileSync('artifacts/k99-windows/src/NativeDraftCamera.tsx', 'utf8');
  const css = fs.readFileSync('artifacts/k99-windows/src/native-draft-camera.css', 'utf8');
  assert.match(camera, /<strong>\{target.itemName\}/);
  assert.match(css, /\.ndc__count\{[^}]*background:#0f172a/);
  assert.match(css, /\.ndc__count em\{[^}]*color:#facc15/);
});

test('basket popup is advisory, touch dismissible and has a 3500ms cleaned-up timer without global key handlers', () => {
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'React');
  Object.defineProperty(globalThis,'React',{configurable:true,value:React});
  try{
    const html=renderToStaticMarkup(createElement(BasketPopup,{info:{id:'analysis-1',basketNo:'바구니 4',
      basketName:'유색 · 나일론 바구니',basketColor:'#DD6B20',materialTag:'PT20 면40 N40'},onClose(){}}));
    assert.ok(html.includes('바구니 4'));
    assert.ok(html.includes('PT20 면40 N40'));
    assert.ok(html.includes('직원 확인 필요'));
    assert.ok(html.includes('role="status"'));
    assert.ok(!html.includes('aria-modal="true"'));
  }finally{
    if(descriptor)Object.defineProperty(globalThis,'React',descriptor);else Reflect.deleteProperty(globalThis,'React');
  }
  const source=fs.readFileSync('artifacts/k99-windows/src/components/BasketPopup.tsx','utf8');
  assert.match(source,/DISMISS_MS = 3500/);
  assert.match(source,/clearTimeout\(timer\)/);
  assert.match(source,/onPointerDown=/);
  assert.doesNotMatch(source,/addEventListener|keydown|keyCode|preventDefault.*key/);
  const stage=fs.readFileSync('scripts/stage-windows-app.cjs','utf8');
  assert.match(stage,/electron\/services/);
  assert.match(stage,/'@google\/genai':/);
});

test('automatic tag finalize precedes existing synchronous confirmation and removes the manual material-print button',()=>{
  const final=fs.readFileSync('artifacts/k99-windows/src/FinalIntakeConfirmation.tsx','utf8');
  assert.ok(final.indexOf('await beforeConfirm?.()')<final.indexOf('const saved = onConfirm('));
  assert.match(final,/if\(!mounted\.current\)return/);
  const main=fs.readFileSync('artifacts/k99-windows/electron/main.cjs','utf8');
  assert.ok(main.indexOf('automaticTags?.assertReadyForOrders(input)')<main.indexOf('const output=store.storage(input)'));
  assert.match(main,/\/api\/care-label\/finalize/);
  assert.match(main,/adapters\.deferDraftTag=/);
  assert.equal(fs.existsSync('artifacts/k99-windows/src/components/CareLabelPanel.tsx'),false);
  const app=fs.readFileSync('artifacts/k99-windows/src/App.tsx','utf8');
  assert.doesNotMatch(app,/CareLabelPanel|button-print-material-tag/);
  assert.match(fs.readFileSync('artifacts/k99-windows/src/NativeDraftCamera.tsx','utf8'),/ReceptionSidebar/);
});
