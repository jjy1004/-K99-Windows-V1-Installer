import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {nativePhotoSource,analyzeLoadedCareLabel} from '../src/native-photo-client';
import {loadPhotoPreview,listRecentPhotos} from '../src/photo-source';
const holder=globalThis as unknown as {window:Window};
const source={photoId:'native-photo-001',url:'k99://app/api/equipment/photos/native-photo-001',careLabelEligible:true};
test('native photo reads bypass disabled helper, bridge tab sessions and simulated preview',async()=>{
  const previous=holder.window;
  const requests:unknown[]=[];
  holder.window={k99Desktop:{photoSource:async input=>{
    requests.push(input);
    return input.action==='list'?[{id:source.photoId,filename:'MOBILE_001.jpg',origin:'bridge',timestamp:'2026-11-09T00:00:00Z'}]:source;
  }}} as unknown as Window;
  try{
    assert.equal(await loadPhotoPreview(source.photoId,'simulation'),source.url);
    assert.equal((await listRecentPhotos())[0].id,source.photoId);
    assert.deepEqual(requests,[{photoId:source.photoId},{action:'list'}]);
  }finally{holder.window=previous;}
});
test('loaded care-label image triggers automatic native analysis, while an ordinary overall photo does not',async()=>{
  const previous=holder.window,calls:unknown[]=[];
  holder.window={k99Desktop:{photoSource:async()=>source,analyzeCareLabel:async(id,options)=>{calls.push({id,options});}}} as unknown as Window;
  try{
    const resolved=await nativePhotoSource({photoId:source.photoId,garmentId:'garment-001'});
    await analyzeLoadedCareLabel({...resolved,careLabelEligible:false});assert.equal(calls.length,0);
    await analyzeLoadedCareLabel(resolved);
    assert.deepEqual(calls,[{id:source.photoId,options:{automatic:true}}]);
  }finally{holder.window=previous;}
});
test('native photo source refuses raw disk/file/remote URLs and mismatched identities',async()=>{
  const previous=holder.window;
  try{
    for(const response of [{...source,url:'file:///D:/private.jpg'},{...source,url:'D:\\private.jpg'},
      {...source,url:'https://example.test/image.jpg'},{...source,photoId:'another-photo-id'},
      {...source,careLabelEligible:'yes'}]){
      holder.window={k99Desktop:{photoSource:async()=>response}} as unknown as Window;
      await assert.rejects(()=>nativePhotoSource({photoId:source.photoId}),/사진 연결 응답/);
    }
  }finally{holder.window=previous;}
});
test('photo UI load wiring preserves Electron protocol security and intake material badge',()=>{
  const read=(name:string)=>fs.readFileSync('artifacts/k99-windows/'+name,'utf8');
  assert.match(read('src/components/LocalGarmentPhoto.tsx'),/onLoad=.*\n?\s*.*analyzeLoadedCareLabel/);
  assert.match(read('src/NativeDraftCamera.tsx'),/status-ndc-label-material/);
  assert.match(read('src/IntakePhotoStrip.tsx'),/if\(native\)return/);
  const main=read('electron/main.cjs');
  assert.match(main,/localPhotos\.response\(request\)/);
  assert.match(main,/img-src 'self' data: blob:/);
  assert.doesNotMatch(main,/webSecurity\s*:\s*false|allowRunningInsecureContent\s*:\s*true/);
  assert.match(read('electron/care-label-controller.cjs'),/pipelineVersion==='local-photo-gateway-v1'/);
});
