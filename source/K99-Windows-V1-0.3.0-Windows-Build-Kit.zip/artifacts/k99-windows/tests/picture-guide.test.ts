import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { OriginalGuideImage, OriginalGuideImages } from '../src/OriginalGuideImages';
import { GUIDE_THEMES } from '../src/guide-data';
import { ORIGINAL_GUIDE_IMAGES, GUIDE_USB_NOTICE } from '../src/original-guide-images';
import crypto from 'node:crypto';

const src = (file: string) => fs.readFileSync(new URL('../src/' + file, import.meta.url), 'utf8');
test('단순 도형 안내 대신 원본 이미지를 사용하고 사진 없는 단계는 글로만 안내한다', () => {
  assert.equal(fs.existsSync(new URL('../src/PhoneGuideScene.tsx', import.meta.url)), false);
  assert.doesNotMatch(src('PictureGuide.tsx') + src('IriunUsbGuide.tsx'), /<svg|PhoneGuideScene|<rect|<path/);
  assert.match(src('PictureGuide.tsx'), /실제 화면 사진은 아직 제공되지/);
  assert.ok(GUIDE_THEMES[1].topics[0].cards[0].body.length > 0);
});
test('첨부한 7개 파일은 해시 목록과 일치하며 동일한 원본 순서를 보존한다', () => {
  const entries = JSON.parse(fs.readFileSync(new URL('../public/images/original-guides/integrity.json', import.meta.url), 'utf8'));
  assert.equal(entries.length, 7);
  ORIGINAL_GUIDE_IMAGES.forEach((image, i) => {
    assert.equal(entries[i].file, image.file);
    const bytes = fs.readFileSync(new URL('../public/images/original-guides/' + image.file, import.meta.url));
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), entries[i].sha256);
    assert.equal(bytes.length, entries[i].bytes);
    const html = renderToStaticMarkup(React.createElement(OriginalGuideImage, { index: i }));
    assert.ok(html.includes(`images/original-guides/${image.file}`));
    assert.match(html, /<img/);
    assert.doesNotMatch(html, /<svg|<canvas|data:image/);
  });
});
test('두 안내 진입점은 같은 원본 슬라이드와 큰 이전·다음 버튼 및 USB·별도 QR 주의문을 사용한다', () => {
  assert.match(src('CameraSetupGuide.tsx'), /<OriginalGuideImages \/>/);
  assert.match(src('PictureGuide.tsx'), /<OriginalGuideImages \/>/);
  const html = renderToStaticMarkup(React.createElement(OriginalGuideImages));
  assert.match(html, /1 \/ 7/);
  assert.match(html, /◀ 이전 그림/); assert.match(html, /다음 그림 ▶/);
  assert.ok(html.includes(GUIDE_USB_NOTICE));
  assert.match(html, /초기 비밀번호.*최초 로그인/);
  const css = src('original-guide-images.css');
  assert.match(css, /width:100%; height:auto/);
  assert.match(css, /overflow:auto/);
});
