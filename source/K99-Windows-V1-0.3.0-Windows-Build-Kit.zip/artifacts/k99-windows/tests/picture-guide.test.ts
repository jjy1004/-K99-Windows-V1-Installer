import {test} from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import fs from 'node:fs';
import {PhoneGuideScene} from '../src/PhoneGuideScene';
import {GUIDE_THEMES} from '../src/guide-data';

const cards=GUIDE_THEMES.flatMap(t=>t.topics.flatMap(p=>p.cards));
test('every phoneScene renders a detailed illustrated phone svg with finger',()=>{
  const kinds=new Set<string>();
  for(const c of cards.filter(c=>c.phoneScene)){
    const html=renderToStaticMarkup(React.createElement(PhoneGuideScene,{card:c}));
    assert.match(html,new RegExp('data-phone-scene="'+c.phoneScene+'"'));
    assert.match(html,/실제 화면 아님/);
    assert.match(html,/pg-finger/);
    if(c.phoneScene!=='lockCompare'){
      assert.match(html,/viewBox="100 0 400 440"/);
      assert.match(html,/<text x="300" y="430" text-anchor="middle"/);
      if(c.warn){
        assert.match(html,/translate\(408 26\)/);
        assert.match(html,/width="88" height="36"/);
        assert.ok(408+88<500&&26+36<440,'주의 배지를 확대 그림의 경계 안에 유지');
      }
    }
    kinds.add(c.phoneScene!);
  }
  for(const k of ['home','settings','connections','tethering','iriun','brightness','battery80','lockCompare']) assert.ok(kinds.has(k),k);
});
test('GuideScene branches phone topics to PhoneGuideScene and keeps PC legacy scene',()=>{
  const src=fs.readFileSync(new URL('../src/PictureGuide.tsx',import.meta.url),'utf8');
  assert.match(src,/card\.device === 'phone' && card\.phoneScene\) return <PhoneGuideScene/);
  assert.ok(cards.filter(c=>c.device==='pc').every(c=>!c.phoneScene));
});
