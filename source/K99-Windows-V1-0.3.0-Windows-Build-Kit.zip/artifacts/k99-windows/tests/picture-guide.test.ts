import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {RECEPTION_HELP,guideImageUrl} from '../src/guide-data';
import {CAMERA_GUIDE_IMAGES} from '../src/original-guide-images';
const root=new URL('../public/images/',import.meta.url);
const src=(name:string)=>fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
test('ZIP의 실제 4개 폴더와 PNG 2개는 원래 이름·순서·중첩 구조를 유지한다',()=>{
  assert.deepEqual(RECEPTION_HELP.map(e=>e.name),[
    'ai 세탁 처방 사용법 매뉴얼','ai세탁처방_휴대폰 설치 매뉴얼',
    'K99 스마트 접수 KDE Connect 사용 가이드.png','K99 스마트 접수 시스템 PC 설치 매뉴얼',
    '갤럭시와 PC 연결 한눈에 보기.png','촬영용 구식 휴대폰에 웹캠 설치 매뉴얼'
  ]);
  assert.equal(RECEPTION_HELP.filter(e=>e.kind==='folder').length,4);
  assert.equal(RECEPTION_HELP.filter(e=>e.kind==='image').length,2);
  assert.deepEqual(RECEPTION_HELP.map(e=>e.pages.length),[3,2,1,3,1,3]);
  assert.deepEqual(RECEPTION_HELP[0].pages.map(p=>p.name),['슬라이드3.PNG','슬라이드4.PNG','슬라이드5.PNG']);
  assert(RECEPTION_HELP[3].pages.every(p=>p.path.includes('/프레젠테이션6/')));
});
test('13장 모두 원본 SHA-256·PNG 해상도·파일 크기가 일치하고 한글 경로가 안전하게 연결된다',()=>{
  const pages=RECEPTION_HELP.flatMap(e=>e.pages);
  assert.equal(pages.length,13);assert.equal(new Set(pages.map(p=>p.path)).size,13);
  for(const p of pages){
    const bytes=fs.readFileSync(new URL(p.path.split('/').map(encodeURIComponent).join('/'),root));
    assert.equal(bytes.length,p.bytes);
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),p.sha256);
    assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
    assert.equal(bytes.readUInt32BE(16),p.width);assert.equal(bytes.readUInt32BE(20),p.height);
    const url=guideImageUrl(p);assert.equal(decodeURIComponent(url.slice('./images/'.length)),p.path);
    assert(!url.includes(' '));assert(!url.includes('data:'));
  }
});
test('새 접수 도움말은 구버전 텍스트·캡처·AI 그림 대신 ZIP 이미지 데이터만 사용한다',()=>{
  const viewer=src('PictureGuide.tsx');
  assert.match(viewer,/RECEPTION_HELP/);assert.match(viewer,/guideImageUrl/);
  assert.doesNotMatch(viewer,/GUIDE_THEMES|OriginalGuideImages|GuideScene|CaptureView|IriunDownloads|<canvas|<svg/);
  assert.equal(fs.existsSync(new URL('../public/guide-captures',import.meta.url)),false);
  for(const file of ['GuideCapture.tsx','guide-captures.json'])
    assert.equal(fs.existsSync(new URL('../src/'+file,import.meta.url)),false);
  const oldDir=new URL('original-guides/',root);
  assert.deepEqual(fs.readdirSync(oldDir).sort(),['08-usb-camera-part1.png','09-usb-camera-part2.png','integrity.json']);
});
test('촬영 설정이 공유하는 두 원본은 제거하지 않으며 해시를 유지한다',()=>{
  const entries=JSON.parse(fs.readFileSync(new URL('original-guides/integrity.json',root),'utf8'));
  assert.equal(entries.length,2);
  for(const image of CAMERA_GUIDE_IMAGES){
    const entry=entries.find((e:{file:string})=>e.file===image.file);
    const bytes=fs.readFileSync(new URL('original-guides/'+image.file,root));
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),entry.sha256);
  }
});
