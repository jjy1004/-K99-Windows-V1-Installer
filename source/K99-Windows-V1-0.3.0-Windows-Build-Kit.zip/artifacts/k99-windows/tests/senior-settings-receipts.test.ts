import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GUIDE_THEMES} from '../src/guide-data';
const source=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
test('그림 설명서는 5개 주제와 요청한 다중 단계·한글·터치 위치를 모두 제공한다',()=>{
  assert.deepEqual(GUIDE_THEMES.map(t=>t.id),['ai','pc','setup','work','excel']);
  const cards=GUIDE_THEMES.flatMap(t=>t.topics.flatMap(p=>p.cards));
  assert.ok(cards.length>=43);
  for(const t of GUIDE_THEMES){
    assert.equal(new Set(t.topics.map(p=>p.id)).size,t.topics.length);
    for(const p of t.topics)for(const c of p.cards){
      assert.ok(c.title&&c.body&&c.bar&&c.rows.length);
      assert.ok(c.hit>=-1&&c.hit<c.rows.length);
      assert.ok(['pc','phone'].includes(c.device));
    }
  }
  const topics=Object.fromEntries(GUIDE_THEMES.flatMap(t=>t.topics.map(p=>[p.id,p.cards])));
  for(const [id,min]of Object.entries({home:4,use:4,install:5,usb:5,heat:3,flow:6}))
    assert.ok(topics[id].length>=min,id);
  const all=cards.map(c=>c.body).join('\n');
  for(const word of ['USB 테더링만으로 연결이 보장되지는','Iriun','공식 설치본','80%','기종'])
    assert.ok(all.includes(word),word);
});
test('설정 화면은 5대 메뉴·하드웨어 4종·휴대폰 2종으로 들어가며 기존 저장 API를 보존한다',()=>{
  const s=source('NoticeCenter.tsx'),hardware=source('HardwareSettings.tsx');
  for(const id of ['store','price','owner','hardware','phone'])assert.ok(s.includes(id),id);
  for(const kind of ['label','receipt','camera','monitor'])assert.ok(hardware.includes(kind));
  for(const id of ['phone-camera','phone-message'])assert.ok(s.includes(id));
  assert.ok(s.includes("'/profile'")&&s.includes('revision: rev'));
  for(const command of ['save-tag','save-receipt','receipt-preview','receipt-print'])
    assert.ok((hardware+source('ReceiptPrintDialog.tsx')).includes(command),command);
  assert.ok(hardware.includes('Iriun Webcam 전용 자동 연결'));
  assert.doesNotMatch(hardware,/select-camera|button-save-camera/);
});
test('자유 품목 입력은 기존 추가 처리로 연결되고 접수증은 확정 결제·선택한 서비스 금액을 사용한다',()=>{
  const app=source('App.tsx'),free=source('FreeGarmentEntry.tsx');
  for(const text of ['세탁물 품목명을 적으세요','금액 입력 (예: 10000)','자유 품목 추가'])
    assert.ok(free.includes(text),text);
  assert.match(app,/onAdd=\{\(itemName,finalPrice\)=>applyLuxuryResult/);
  assert.ok(app.includes('row.selectedAmount??row.generalPrice*row.quantity'));
  assert.ok(app.includes('confirmedOrder?.payment_type??finalChoices?.paymentType'));
  assert.ok(app.includes('manualTagNumbers:finalNativeDraftUnits'));
  assert.ok(app.includes('totalAmount:payload.selectedTotal'));
  assert.ok(app.includes('CUSTOMER_VIDEO_BUTTONS.map'));
  assert.ok(app.includes('className="k99-display-controls"'));
});
test('촬영 안내 탭을 없애도 발판·촬영·확대·실제 스트림 연결과 저장 코드는 남는다',()=>{
  const camera=source('NativeDraftCamera.tsx');
  assert.ok(!camera.includes('Wi-Fi 무선 연결')&&!camera.includes('USB 유선 연결'));
  for(const kept of ['captureShortcut','useCameraViewport','openIriunCamera','capture-draft','onFinalConfirm'])
    assert.ok(camera.includes(kept),kept);
  const preview=source('ReceiptPrintDialog.tsx');
  assert.ok(preview.includes('previewSequence')&&preview.includes('receipt-preferences'));
  const illustration=source('PictureGuide.tsx');
  assert.ok(illustration.includes('pg-finger')&&illustration.includes('button-guide-next'));
});
