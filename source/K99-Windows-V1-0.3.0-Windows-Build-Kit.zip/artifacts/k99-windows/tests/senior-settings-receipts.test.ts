import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GUIDE_THEMES} from '../src/guide-data';
const source=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
test('그림 설명서는 5개 주제와 요청한 다중 단계·한글·터치 위치를 모두 제공한다',()=>{
  assert.deepEqual(GUIDE_THEMES.map(t=>t.id),['ai','pc','setup','work','excel']);
  const cards=GUIDE_THEMES.flatMap(t=>t.topics.flatMap(p=>p.cards));
  assert.ok(cards.length>=43);
  for(const t of GUIDE_THEMES){
    assert.equal(new Set(t.topics.map(p=>p.id)).size,t.topics.length);
    for(const p of t.topics)for(const c of p.cards){
      assert.ok(c.title&&c.body&&c.bar&&c.rows.length);
      assert.ok(c.hit>=-1&&c.hit<c.rows.length);
      assert.ok(['pc','phone'].includes(c.device));
    }
  }
  const topics=Object.fromEntries(GUIDE_THEMES.flatMap(t=>t.topics.map(p=>[p.id,p.cards])));
  for(const [id,min]of Object.entries({home:4,use:4,install:5,usb:7,heat:3,flow:6}))
    assert.ok(topics[id].length>=min,id);
  const all=cards.map(c=>c.body).join('\n');
  for(const word of ['파일 전송 / Android Auto','충전 중 화면 켜짐 유지','Iriun','공식 설치본','80%','기종'])
    assert.ok(all.includes(word),word);
});
test('설정 화면은 기존 하드웨어·촬영 휴대폰과 저장 API를 보존하며 메시지 연결 설정은 제거한다',()=>{
  const s=source('NoticeCenter.tsx'),hardware=source('HardwareSettings.tsx');
  for(const id of ['store','price','owner','hardware','phone'])assert.ok(s.includes(id),id);
  for(const kind of ['label','receipt','camera','monitor'])assert.ok(hardware.includes(kind));
  assert.ok(s.includes('phone-camera'));
  assert.doesNotMatch(s,/button-phone-message|<ConnectHelperBody/);
  assert.ok(s.includes("'/profile'")&&s.includes('revision: rev'));
  for(const command of ['save-tag','save-receipt','receipt-preview','receipt-print'])
    assert.ok((hardware+source('ReceiptPrintDialog.tsx')).includes(command),command);
  assert.ok(hardware.includes('Iriun Webcam 전용 자동 연결'));
  assert.doesNotMatch(hardware,/select-camera|button-save-camera/);
});
test('자유 품목 입력은 기존 추가 처리로 연결되고 접수증은 확정 결제·선택한 서비스 금액을 사용한다',()=>{
  const app=source('App.tsx'),free=source('FreeGarmentEntry.tsx');
  for(const text of ['세탁물 품목명을 적으세요','금액 입력 (예: 10000)','자유 품목 추가'])
    assert.ok(free.includes(text),text);
  assert.match(app,/onAdd=\{\(itemName,finalPrice\)=>applyLuxuryResult/);
  assert.ok(app.includes('row.selectedAmount??row.generalPrice*row.quantity'));
  assert.ok(app.includes('confirmedOrder?.payment_type??finalChoices?.paymentType'));
  assert.ok(app.includes('manualTagNumbers:finalNativeDraftUnits'));
  assert.ok(app.includes('totalAmount:payload.selectedTotal'));
  assert.ok(app.includes('CUSTOMER_VIDEO_BUTTONS.map'));
  assert.ok(app.includes('className="k99-display-controls"'));
});
test('촬영 안내 탭을 없애도 발판·촬영·확대·실제 스트림 연결과 저장 코드는 남는다',()=>{
  const camera=source('NativeDraftCamera.tsx');
  assert.ok(!camera.includes('Wi-Fi 무선 연결')&&!camera.includes('USB 유선 연결'));
  for(const kept of ['captureShortcut','useCameraViewport','useIriunCamera','capture-draft','onFinalConfirm'])
    assert.ok(camera.includes(kept),kept);
  const preview=source('ReceiptPrintDialog.tsx');
  assert.ok(preview.includes('previewSequence')&&preview.includes('receipt-preferences'));
  const illustration=source('PictureGuide.tsx');
  assert.ok(illustration.includes('OriginalGuideImages')&&illustration.includes('button-guide-next'));
});
test('영수증 통신 설정은 9600 기본값과 네 가지 속도·한글·안전 확인·저장 경로를 제공한다',()=>{
  const hardware=source('HardwareSettings.tsx');
  assert.match(hardware,/receiptBaudRate:9600/);
  assert.ok(hardware.includes('[9600,19200,38400,115200]'));
  for(const id of ['select-receipt-baud','select-receipt-transport','select-receipt-encoding','receipt-serial-safety'])
    assert.ok(hardware.includes(id),id);
  for(const text of ['receiptBaudRate:cfg.receiptBaudRate','receiptEncoding:cfg.receiptEncoding',
    'receiptEscPosVerified:cfg.receiptEscPosVerified',"savePart('save-receipt', receiptConfig",
    'TS-167','Windows 프린터 포트 설정도 별도로 확인'])
    assert.ok(hardware.includes(text),text);
  assert.ok(!hardware.includes('select-camera-device'));
});
