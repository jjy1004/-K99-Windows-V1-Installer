import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';

const read=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
const app=read('App.tsx');
const tree=ts.createSourceFile('App.tsx',app,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const zones=new Map<string,ts.JsxElement>();
function attr(open:ts.JsxOpeningElement,name:string){
  const value=open.attributes.properties.find(p=>ts.isJsxAttribute(p)&&p.name.getText(tree)===name);
  return value&&ts.isJsxAttribute(value)&&value.initializer&&ts.isStringLiteral(value.initializer)
    ?value.initializer.text:undefined;
}
function visit(node:ts.Node){
  if(ts.isJsxElement(node)){
    const zone=attr(node.openingElement,'data-intake-zone');
    if(zone){assert.ok(!zones.has(zone),`중복 구역: ${zone}`);zones.set(zone,node);}
  }
  ts.forEachChild(node,visit);
}
visit(tree);
const zone=(id:string)=>{const n=zones.get(id);assert.ok(n,`${id} 구역 누락`);return n.getText(tree);};

test('설계도의 왼쪽·중앙 6개 구역과 고대비 제목 배너가 각각 한 번씩 존재한다',()=>{
  assert.deepEqual([...zones.keys()].sort(),['customer','estimate','messages','orders','payment','video']);
  for(const [id,title] of Object.entries({customer:'고객 정보',estimate:'예상 금액',messages:'방문수거 견적 & 메시지',video:'영상',orders:'주문 내역',payment:'결제'})){
    const source=zone(id);
    assert.match(source,/<h2 className="k99-bp-title"/);
    assert.ok(source.includes(title)||source.includes(title.replace('&','&amp;')),title);
    assert.ok(zones.get(id)!.openingElement.attributes.properties.some(p=>ts.isJsxAttribute(p)&&p.name.getText(tree)==='aria-labelledby'));
  }
  const css=read('intake-blueprint.css');
  assert.match(css,/\.k99-bp-estimate \.summary-value\{[^}]*color:#153d35/);
  assert.match(css,/\.staff-card,main\.k99-bp \.staff-heading\{animation:none/);
});
test('고객 검색·특이사항·주소·IME·방문 요약을 같은 고객 구역에 보존한다',()=>{
  const customer=zone('customer');
  for(const component of ['SavedOrderLookup','ReceptionCustomerLookup','ImeTextInput','button-new-intake','input-customer-name','input-customer-phone','input-customer-address','k99:edit-customer-special-note'])
    assert.ok(customer.includes(component),component);
  assert.equal((customer.match(/<SavedOrderLookup\b/g)||[]).length,1);
  assert.ok(!customer.includes('<PickupQuoteDraft'));
});
test('예상 금액과 방문수거 메시지는 독립 구역으로 이동해 기존 금액과 발송 처리를 유지한다',()=>{
  const estimate=zone('estimate'),messages=zone('messages');
  assert.ok(estimate.includes('text-total-normal')&&estimate.includes('text-total-premium'));
  assert.ok(messages.includes('<PickupQuoteDraft')&&messages.includes('pickupRequested'));
  assert.ok(messages.includes('setPickupPickerOpen(true)'));
  assert.ok(app.includes("openCustomerNotice(id,'pickup-quote')"));
  assert.equal((app.match(/<PickupQuoteDraft\b/g)||[]).length,1);
});
test('영상 4종을 빠짐없이 복원하고 대기·고객 화면을 더해 2열 3행으로 배치한다',()=>{
  const video=zone('video'),css=read('intake-blueprint.css');
  assert.match(video,/CUSTOMER_VIDEO_BUTTONS\.map/);
  assert.ok(!video.includes('CUSTOMER_VIDEO_BUTTONS.filter'));
  for(const handler of ['playCustomerExplanation(video)','requestCustomerIdle','openCustomerView'])
    assert.ok(video.includes(handler),handler);
  assert.match(css,/k99-display-controls[^}]*grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
});
test('자유 품목은 주문 구역에, 선후불과 동일 가격의 접수증은 결제 구역에 존재한다',()=>{
  const orders=zone('orders'),payment=zone('payment');
  for(const kept of ['garment-intake-section','sneaker-intake-panel','<FreeGarmentEntry','applyLuxuryResult'])
    assert.ok(orders.includes(kept),kept);
  for(const kept of ['intake-tag-payment',"'PREPAID'","'POSTPAID'",'button-open-receipt','<ReceiptPrintDialog','row.selectedAmount??row.generalPrice*row.quantity','manualTagNumbers:finalNativeDraftUnits'])
    assert.ok(payment.includes(kept),kept);
  assert.equal((app.match(/<ReceiptPrintDialog\b/g)||[]).length,1);
  assert.ok(!orders.includes('intake-tag-payment'));
});
test('사진 구역은 실제 촬영·소재·색상·최종 확인 콜백을 유지하고 별도 제목을 제공한다',()=>{
  const sidebar=read('ReceptionSidebar.tsx'),camera=read('NativeDraftCamera.tsx');
  assert.match(sidebar,/data-intake-zone="photos"/);
  assert.ok(sidebar.includes('사진 촬영'));
  for(const kept of ['<PhotoStorageHint','mobilePanel','MANUAL_MATERIALS.map','onOpenCamera','onFinalConfirm','onLabelSelection'])
    assert.ok(sidebar.includes(kept),kept);
  for(const kept of ['captureShortcut','useCameraViewport','openIriunCamera','capture-draft'])
    assert.ok(camera.includes(kept),kept);
  assert.match(read('intake-blueprint.css'),/min-height:0/);
  assert.match(read('intake-blueprint.css'),/max-width:1100px/);
});
test('메인 메시지 구역은 제목 아래 열기 버튼 하나만 두고 긴 내용은 포털 모달로 이동한다',()=>{
  const node=zones.get('messages')!;
  const buttons=node.children.filter(n=>ts.isJsxElement(n)&&n.openingElement.tagName.getText(tree)==='button');
  assert.equal(buttons.length,1);
  assert.ok(buttons[0].getText(tree).includes('button-open-pickup-messages'));
  assert.ok(buttons[0].getText(tree).includes('setPickupMessageOpen(true)'));
  assert.match(zone('messages'),/pickupMessageOpen&&<NoticeDialog/);
  assert.match(zone('messages'),/onClose=\{\(\)=>setPickupMessageOpen\(false\)\}/);
  const dialog=read('LocalNoticeDialogs.tsx');
  for(const preserved of ['createPortal(','role="dialog"','aria-modal="true"','lnd-close','Escape'])
    assert.ok(dialog.includes(preserved),preserved);
});
test('모달에서도 기존 방문수거 선택과 접수된 고객의 안내문 편집 연결을 유지한다',()=>{
  const messages=zone('messages');
  assert.ok(messages.includes('setPickupMessageOpen(false);setPickupPickerOpen(true)'));
  assert.ok(messages.includes('setFinalChoices(old=>({...old,pickupRequested:checked}))'));
  assert.ok(messages.includes('<PickupQuoteDraft editable edit={pickupQuoteEdit} onEdit={setPickupQuoteEdit}'));
  assert.ok(app.includes("openCustomerNotice(id,'pickup-quote')"));
});
test('견적 편집값은 닫았다 열어도 부모에 유지하고 복사·문자·카톡에 같은 최종 문구를 전달한다',()=>{
  const quote=read('PickupQuoteDraft.tsx');
  assert.match(app,/useState<PickupQuoteEdit \| null>\(null\)/);
  assert.ok(quote.includes('editable=false'));
  assert.ok(quote.includes('edited?.source===body?edited.text:body'));
  assert.ok(quote.includes('readOnly={!editable}')&&quote.includes('onEdit?.(next)'));
  assert.ok(quote.includes('navigator.clipboard.writeText(outgoingBody)'));
  assert.match(quote,/<AccountlessNoticeActions recipient=\{phone\} body=\{outgoingBody\}[^>]*templateId="pickup-quote"/);
  assert.ok(quote.includes('calculateStoreQuote(items.reduce((n,i)=>n+i.amount,0),p)'));
});
