import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {calculateStoreQuote} from '../src/notice-api';
import {CustomerSpecialNote} from '../src/CustomerSpecialNote';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const {quote,DEFAULT_PROFILE}=createRequire(import.meta.url)('../../../lib/k99-local/customer-notices.cjs');
test('frontend and authoritative SQLite backend use identical decimal/disabled-tier discount arithmetic',()=>{
  for(const n of [0,49999,50000,99999,100000,199999,200000]){
    for(const patch of [{},{secondThreshold:0},{firstThreshold:0},{firstRate:12.5,secondRate:0},{reviewThreshold:0},{reviewDiscount:0}]){
      const p={...DEFAULT_PROFILE,discounts:{...DEFAULT_PROFILE.discounts,...patch}};
      for(const review of [false,true])assert.deepEqual(calculateStoreQuote(n,p,review),quote(n,p,review));
    }
  }
});
test('customer warning has requested red contrast, precedes its editor and escapes stored HTML',()=>{
  const html=renderToStaticMarkup(createElement(CustomerSpecialNote,{customer:{id:'a'.repeat(64),name:'검사고객',
    phone:'01000000001',address:'',totalVisits:0,nextVisit:1,specialNote:'<img src=x onerror=alert(1)> 확인'},onSaved:()=>{}}));
  assert(html.includes('#fef2f2'));assert(html.includes('#dc2626'));
  assert(html.indexOf('customer-special-note-warning')<html.indexOf('특이사항 기록'));
  assert(html.includes('&lt;img'));assert(!html.includes('<img src=x'));
});
test('notice dialogs escape navigation stacking and remain above camera windows with keyboard focus containment',()=>{
  const ui=readFileSync(new URL('../src/NoticeCenter.tsx',import.meta.url),'utf8');
  const css=readFileSync(new URL('../src/notice-center.css',import.meta.url),'utf8');
  assert.match(ui,/return createPortal\(/);assert.match(ui,/<\/div>,document\.body/);
  assert.match(css,/\.nc-backdrop\s*\{[^}]*z-index:2000/);
  assert.match(ui,/e\.key==='Tab'/);assert.match(ui,/previous\?\.isConnected/);
});
test('mobile drafts refresh for a valid selected order even when its QR originated in the photo page',()=>{
  const ui=readFileSync(new URL('../src/NoticeCenter.tsx',import.meta.url),'utf8');
  const poll=ui.slice(ui.indexOf('// 촬영 QR에서'),ui.indexOf('const curTpl'));
  assert.match(poll,/ctx\?\.orderId !== orderId/);assert.match(poll,/\[ctx\?\.orderId, orderId\]/);
  assert(!poll.includes('if (!mobile)'));assert.match(poll,/setNotices\(d.notices\)/);
  assert(!/setBody|setTheme|setTemplateId/.test(poll));
});
test('special-note search actions fit the intake column instead of overlapping the neighbouring item panel',()=>{
  const css=readFileSync(new URL('../src/v1-layout.css',import.meta.url),'utf8');
  assert.match(css,/\.saved-order-lookup__inner form\s*\{[^}]*grid-template-columns:minmax\(0,1fr\)/);
  assert.match(css,/\.saved-order-lookup form label\s*\{[^}]*white-space:normal/);
});
test('warning is inserted before any visit history and is never part of customer-facing notice context',()=>{
  const ui=readFileSync(new URL('../src/CustomerDirectory.tsx',import.meta.url),'utf8');
  assert(ui.indexOf('<CustomerSpecialNote')<ui.indexOf('<RecentYearBlock'));
  const core=readFileSync(new URL('../../../lib/k99-local/customer-notices.cjs',import.meta.url),'utf8');
  const context=core.slice(core.indexOf('function context('),core.indexOf('function dto('));
  assert(!context.includes('special_note'));assert(!context.includes('specialNote'));
});
