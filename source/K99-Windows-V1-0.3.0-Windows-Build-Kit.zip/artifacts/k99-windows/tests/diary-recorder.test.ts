import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DiaryRecorder, SilenceDetector, pcmWav, DIARY_SILENCE_MS } from '../src/diary-recorder';

test('연속 침묵은 정확히 4.5초부터 감지하고 말소리·이어서 말하기 시 초기화한다', () => {
  assert.equal(DIARY_SILENCE_MS, 4500);
  const detector = new SilenceDetector(0);
  assert.equal(detector.update(0, 4499), false);
  assert.equal(detector.update(0, 4500), true);
  assert.equal(detector.update(0.1, 4501), false);
  assert.equal(detector.update(0, 9000), false);
  assert.equal(detector.update(0, 9001), true);
});
test('WAV 변환은 16kHz 단일 채널 16비트이며 길이·포화 처리가 정확하다', () => {
  const bytes = pcmWav(new Float32Array([-2, -1, 0, 1, 2]));
  const v = new DataView(bytes.buffer);
  assert.equal(Buffer.from(bytes).subarray(0, 4).toString(), 'RIFF');
  assert.equal(v.getUint32(24, true), 16000);
  assert.equal(v.getUint16(22, true), 1);
  assert.equal(v.getUint16(34, true), 16);
  assert.equal(v.getUint32(40, true), 10);
  assert.equal(v.getInt16(44, true), -32768);
  assert.equal(v.getInt16(52, true), 32767);
});
test('일시 정지·재개는 같은 녹음 청크를 유지하고 마침·취소 시 마이크를 해제한다', async () => {
  const saved = new Map<string, PropertyDescriptor | undefined>();
  const set = (name: string, value: unknown) => { saved.set(name, Object.getOwnPropertyDescriptor(globalThis, name)); Object.defineProperty(globalThis, name, { configurable: true, value }); };
  let stopped = 0, contextClosed = 0, instances = 0, rec: any, constraints: any;
  class FakeRecorder extends EventTarget {
    static isTypeSupported() { return true; }
    state = 'inactive'; mimeType = 'audio/webm'; ondataavailable: any;
    constructor() { super(); rec = this; instances++; }
    start() { this.state = 'recording'; this.ondataavailable({ data: new Blob(['첫째']) }); }
    pause() { this.state = 'paused'; }
    resume() { this.state = 'recording'; this.ondataavailable({ data: new Blob(['둘째']) }); }
    stop() { this.state = 'inactive'; this.dispatchEvent(new Event('stop')); }
  }
  set('MediaRecorder', FakeRecorder);
  set('navigator', { mediaDevices: { getUserMedia: async (c: any) => { constraints = c; return {
    getTracks: () => [{ stop: () => stopped++ }], getAudioTracks: () => [{ readyState: 'live', addEventListener() {} }],
  }; } } });
  set('AudioContext', class {
    async resume() {} async close() { contextClosed++; }
    createMediaStreamSource() { return { connect() {} }; }
    createAnalyser() { return { fftSize: 1024, getFloatTimeDomainData() {} }; }
  });
  try {
    const recording = new DiaryRecorder(() => {}, () => {});
    await recording.start(); recording.pause(); assert.equal(rec.state, 'paused'); recording.resume();
    const blob = await recording.finish();
    assert.equal(await blob.text(), '첫째둘째');
    assert.equal(await recording.finish(), blob, '실패 후 재시도할 녹음을 보관한다');
    assert.deepEqual(constraints, { audio: true, video: false });
    assert.equal(instances, 1); assert.equal(stopped, 1); assert.equal(contextClosed, 1);
    recording.abort();
  } finally {
    for (const [name, descriptor] of saved) {
      if (descriptor) Object.defineProperty(globalThis, name, descriptor); else Reflect.deleteProperty(globalThis, name);
    }
  }
});
