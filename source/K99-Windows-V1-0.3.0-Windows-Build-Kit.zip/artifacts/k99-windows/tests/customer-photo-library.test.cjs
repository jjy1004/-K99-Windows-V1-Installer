'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createCustomerPhotoLibrary,dates}=require('../electron/customer-photo-library.cjs');
function fixture(t,tempBase=os.tmpdir()){
  // Windows TEMP may use RUNNER~1 while fs.promises.realpath returns the long
  // directory name. Match the native realpath implementation used by the
  // production security guard; do not weaken that guard to satisfy the test.
  const root=fs.realpathSync.native(fs.mkdtempSync(path.join(tempBase,'k99-photo-query-'))),opened=[];
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const library=createCustomerPhotoLibrary({roots:[root],now:()=>new Date('2026-11-04T12:00:00Z'),
    openPath:async folder=>{opened.push(folder);return '';}});
  return {root,opened,library,mkdir:name=>fs.mkdirSync(path.join(root,name))};
}
test('photo lookup matches BOTH name and last4, six calendar months, compact and ISO dates only',async t=>{
  const f=fixture(t);
  for(const n of ['20261104_테스트고객_1234','2026-06-15_테스트고객_1234','20260504_테스트고객_1234',
    '20260503_테스트고객_1234','20261105_테스트고객_1234','20261015_다른고객_1234',
    '20261015_테스트고객_5678','20260230_테스트고객_1234'])f.mkdir(n);
  const r=await f.library.list({name:'테스트고객',phone:'01000001234'});
  assert.deepEqual(r.notes,[],`사진 폴더 검사 진단: ${JSON.stringify({platform:process.platform,temp:os.tmpdir(),root:f.root,notes:r.notes})}`);
  assert.deepEqual(r.folders.map(x=>x.date),['2026-11-04','2026-06-15','2026-05-04']);
  assert.equal(f.opened.length,0);
  assert.equal((await f.library.open(r.folders[0].token)).opened,true);
  assert.equal(f.opened[0],path.join(f.root,'20261104_테스트고객_1234'));
  await assert.rejects(()=>f.library.open('..\\outside'),/만료/);
});
test('missing phone never scans or opens a folder',async t=>{
  const f=fixture(t),r=await f.library.list({name:'테스트고객',phone:''});
  assert.equal(r.folders.length,0);assert.equal(f.opened.length,0);
});
test('calendar cutoff clamps end-of-month and missing roots are explicit',async()=>{
  assert.equal(dates(new Date('2026-08-31T00:00:00Z')).start,'2026-02-28');
  assert.equal(dates(new Date('2024-08-31T00:00:00Z')).start,'2024-02-29');
  assert.deepEqual(dates(new Date('2026-11-04T15:00:00Z')),{today:'2026-11-05',start:'2026-05-05'});
  const library=createCustomerPhotoLibrary({roots:[path.join(os.tmpdir(),'k99-not-existing-'+Date.now())],openPath:async()=>''});
  const r=await library.list({name:'테스트고객',phone:'1234'});
  assert.equal(r.folders.length,0);assert.ok(r.notes[0].includes('폴더 없음'));
});
test('symbolic link or Windows junction replacement is refused before opening',async t=>{
  const f=fixture(t),name='20261104_테스트고객_1234';f.mkdir(name);
  const r=await f.library.list({name:'테스트고객',phone:'1234'});
  fs.rmdirSync(path.join(f.root,name));
  fs.symlinkSync(fs.realpathSync.native(os.tmpdir()),path.join(f.root,name),process.platform==='win32'?'junction':'dir');
  await assert.rejects(()=>f.library.open(r.folders[0].token),/연결/);assert.equal(f.opened.length,0);
});
test('fixture root agrees with asynchronous native realpath, including Windows short TEMP aliases',async t=>{
  const f=fixture(t);
  assert.equal(f.root,await fs.promises.realpath(f.root));
});
test('canonical fixture under a temporary alias works but production still rejects an alias root',async t=>{
  const parent=fs.realpathSync.native(fs.mkdtempSync(path.join(os.tmpdir(),'k99-temp-alias-')));
  t.after(()=>fs.rmSync(parent,{recursive:true,force:true}));
  const target=path.join(parent,'long-temporary-directory'),alias=path.join(parent,'temporary-alias');
  fs.mkdirSync(target);fs.symlinkSync(target,alias,process.platform==='win32'?'junction':'dir');
  const f=fixture(t,alias);f.mkdir('20261104_테스트고객_1234');
  const result=await f.library.list({name:'테스트고객',phone:'1234'});
  assert.deepEqual(result.notes,[]);
  assert.deepEqual(result.folders.map(p=>p.date),['2026-11-04']);
  const unsafe=createCustomerPhotoLibrary({roots:[path.join(alias,path.basename(f.root))],
    now:()=>new Date('2026-11-04T12:00:00Z'),openPath:async()=>assert.fail('보호된 별칭 경로를 열면 안 됩니다.')});
  const rejected=await unsafe.list({name:'테스트고객',phone:'1234'});
  assert.deepEqual(rejected.folders,[]);
  assert.ok(rejected.notes.some(note=>/연결|정션|불일치/.test(note)));
});
