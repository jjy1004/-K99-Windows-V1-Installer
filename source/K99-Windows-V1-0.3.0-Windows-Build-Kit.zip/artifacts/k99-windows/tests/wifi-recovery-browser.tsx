// Synthetic camera and capture endpoint only. No DB, disk photos, labels,
// permission settings, external messaging or operational server is accessed.
import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {NativeDraftCamera,type DraftNativeUnit} from '../src/NativeDraftCamera';
import '../src/index.css';
const audit={online:true,frozen:false,colour:'red',opens:[] as number[],streams:[] as MediaStream[],
  captures:[] as {colour:string;at:number}[],test:'대기'};
(window as any).wifiAudit=audit;
window.k99Desktop={iriunSession:async()=>({installed:true,running:true})};
const canvas=document.createElement('canvas'),still=document.createElement('canvas');
canvas.width=still.width=640;canvas.height=still.height=480;
const g=canvas.getContext('2d')!,saved=still.getContext('2d')!;let n=0;
setInterval(()=>{
  if(audit.frozen){g.drawImage(still,0,0);return;}
  g.fillStyle='#f0f8ff';g.fillRect(0,0,640,480);
  g.fillStyle=audit.colour==='red'?'#d03030':'#3050db';g.fillRect(140,90,360,330);
  g.fillStyle='white';g.fillRect(10+(n++%10)*35,10,30,30);
  g.fillStyle='#152432';g.font='20px sans-serif';g.fillText('합성 영상 검사 · 실제 휴대폰 아님',120,65);
  saved.drawImage(canvas,0,0);
},60);
function install(media:MediaDevices){
  Object.defineProperty(media,'enumerateDevices',{configurable:true,value:async()=>[
    {kind:'videoinput',deviceId:'current-test-iriun',label:'Iriun Webcam'}]});
  Object.defineProperty(media,'getUserMedia',{configurable:true,value:async()=>{
    audit.opens.push(performance.now());
    if(!audit.online)throw new DOMException('검사용 Wi-Fi 끊김','NotReadableError');
    const stream=canvas.captureStream(20),track=stream.getVideoTracks()[0];
    Object.defineProperty(track,'label',{value:'Iriun Webcam'});
    track.getSettings=()=>({deviceId:'current-test-iriun',width:640,height:480});
    audit.streams.push(stream);return stream;
  }});
}
install(navigator.mediaDevices);
const create=document.createElement.bind(document);
document.createElement=((tag:string,options?:ElementCreationOptions)=>{
  const element=create(tag,options);
  if(tag.toLowerCase()==='iframe')element.addEventListener('load',()=>{
    const media=(element as HTMLIFrameElement).contentWindow?.navigator.mediaDevices;
    if(media)install(media);
  },true);
  return element;
}) as typeof document.createElement;
window.fetch=async(input,init)=>{
  const pathname=new URL(String(input),location.href).pathname;
  if(pathname==='/api/equipment/state')return Response.json({native:true,config:{mode:'real'},orders:[],photos:[],jobs:[]});
  const body=JSON.parse(String(init?.body||'{}'));
  if(pathname==='/api/equipment/command'&&body.action==='tag-policy')return Response.json({mode:'none',lastNumber:'1-0'});
  if(pathname==='/api/equipment/command'&&body.action==='capture-draft'){
    const image=new Image();image.src=body.imageDataUrl;await image.decode();
    const c=create('canvas') as HTMLCanvasElement;c.width=c.height=1;
    const p=c.getContext('2d')!;p.drawImage(image,image.width/2,image.height/2,1,1,0,0,1,1);
    const rgb=p.getImageData(0,0,1,1).data;
    audit.captures.push({colour:rgb[2]>rgb[0]?'blue':'red',at:performance.now()});
    return Response.json({garment:{...body,garmentId:'test-only',tagMode:'none',
      photoHistory:audit.captures.map((_,i)=>({requestId:String(i)}))}});
  }
  return Response.json({error:'격리 검사: 실제 업무 API 접근 금지'},{status:403});
};
const wait=(ms:number)=>new Promise(r=>setTimeout(r,ms));
function App(){
  const [units,setUnits]=useState<DraftNativeUnit[]>([]),[status,setStatus]=useState('');
  const [label,setLabel]=useState({manualMaterial:'폴리에스테르',manualColor:'유색'} as const);
  async function staleTest(){
    const before=audit.captures.length;audit.frozen=true;setStatus('동일 픽셀 유지 중');
    await wait(1100);
    document.querySelector<HTMLButtonElement>('[data-testid="button-ndc-shoot"]')?.click();
    await wait(900);
    if(audit.captures.length!==before){audit.test='실패: 잔상 저장';setStatus(audit.test);return;}
    setStatus('잔상 저장 차단 확인 · 파란 영상으로 복귀 중');audit.colour='blue';audit.frozen=false;
    for(let i=0;i<150&&audit.captures.length===before;i++)await wait(100);
    audit.test=audit.captures.length===before+1&&audit.captures.at(-1)?.colour==='blue'?'통과: 파란 최신 사진만 1장 저장':'실패: 최신 사진 미수신';
    setStatus(audit.test);
  }
  return <>
    <div style={{position:'fixed',top:0,right:0,zIndex:999999,background:'#fff',color:'#111',padding:8,fontSize:16}}>
      <button onClick={()=>window.dispatchEvent(new Event('k99:open-intake-camera'))}>검사 촬영창 열기</button>
      <button onClick={()=>{audit.frozen=true;setStatus('프레임 픽셀 동결');}}>영상 정지</button>
      <button onClick={()=>{audit.frozen=false;audit.colour='blue';audit.online=true;setStatus('연결 복원');}}>파란 영상·연결 복원</button>
      <button onClick={()=>{audit.online=false;for(const s of audit.streams)for(const t of s.getTracks()){t.stop();t.dispatchEvent(new Event('ended'));}setStatus('Wi-Fi 끊김');}}>연결 끊기</button>
      <button onClick={()=>void staleTest()}>잔상 촬영 차단 시험</button>
      <p role="status" data-testid="wifi-test-status">{status}</p>
    </div>
    <NativeDraftCamera orderId="isolated-wifi-test" customerName="격리 검사" customerPhone="01000000000"
      targets={[{rowId:1,itemId:'shirt',itemName:'검사용 의류',unitIndex:1,rowQuantity:1}]}
      units={units} labelSelection={label} onSelectLabel={v=>setLabel(v as typeof label)}
      onCaptured={u=>setUnits([u])} onFinalConfirm={()=>{}}/>
  </>;
}
createRoot(document.getElementById('root')!).render(<App/>);
