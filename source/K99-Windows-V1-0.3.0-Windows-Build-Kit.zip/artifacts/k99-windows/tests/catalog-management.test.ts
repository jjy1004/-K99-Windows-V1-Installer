import test from 'node:test';
import assert from 'node:assert/strict';
import {CATALOG_DEFAULTS,groupByCategory,itemFamily,selectableEntries,validateCatalog,saveManagedCatalog,readManagedCatalog,type CatalogEntry} from '../src/price-catalog';
const make=(id:string,name:string,category:CatalogEntry['category']='outer'):CatalogEntry=>({
  id:`user_${id}`,displayNameKo:name,category,generalPrice:25000,premiumPrice:34000,userAdded:true,
});
test('category, family and Korean name sorting includes new entries without changing builtin identity',()=>{
  const additions=[make('long','롱 패딩'),make('half','하프 패딩'),make('trench','트렌치 코트'),make('moncler','몽클레어 패딩'),make('jacket','가죽 자켓')];
  const list=[...CATALOG_DEFAULTS,...additions];
  const groups=groupByCategory(selectableEntries(list));
  assert.deepEqual(groups.map(g=>g.category),['top','bottom','outer','etc','bedding','shoes']);
  const outer=groups.find(g=>g.category==='outer')!.items;
  for(const family of ['패딩','코트','자켓·점퍼']){
    const indices=outer.map((e,i)=>itemFamily(e)===family?i:-1).filter(i=>i>=0);
    assert.equal(indices.at(-1)!-indices[0]+1,indices.length,`${family} stays contiguous`);
    const names=indices.map(i=>outer[i].displayNameKo);
    assert.deepEqual(names,[...names].sort((a,b)=>a.localeCompare(b,'ko')));
  }
  assert.equal(CATALOG_DEFAULTS.find(e=>e.id==='half_padding')!.category,'top','existing raw IDs and categories preserved');
});
test('user-added fields survive validation/cache, archived IDs stay resolvable but hidden',()=>{
  const row=make('shirt','새 셔츠','top');
  const resolved=validateCatalog(CATALOG_DEFAULTS,[row]);
  assert.equal(resolved.find(e=>e.id===row.id)?.premiumPrice,34000);
  const archived=validateCatalog(CATALOG_DEFAULTS,[{...row,legacy:true,sortOrder:2}]);
  assert.equal(archived.find(e=>e.id===row.id)?.generalPrice,25000);
  assert.ok(!selectableEntries(archived).some(e=>e.id===row.id));
  assert.throws(()=>validateCatalog(CATALOG_DEFAULTS,[{...row,id:'arbitrary'}]));
  assert.throws(()=>validateCatalog(CATALOG_DEFAULTS,[{...row,category:'bad'}]));
});
test('manual order remains inside family and survives settings-cache reload',()=>{
  const before=Object.getOwnPropertyDescriptor(globalThis,'window');
  const values=new Map<string,string>();
  Object.defineProperty(globalThis,'window',{configurable:true,value:{localStorage:{
    getItem:(k:string)=>values.get(k)??null,setItem:(k:string,v:string)=>values.set(k,v),
  }}});
  try {
    const first={...make('first','하프 패딩'),sortOrder:1};
    const second={...make('second','롱 패딩'),sortOrder:2};
    const coat=make('coat','트렌치 코트');
    saveManagedCatalog(CATALOG_DEFAULTS,[...CATALOG_DEFAULTS,second,coat,first]);
    const restored=readManagedCatalog(CATALOG_DEFAULTS);
    const names=selectableEntries(restored).filter(e=>e.userAdded).map(e=>e.displayNameKo);
    assert.deepEqual(names,['트렌치 코트','하프 패딩','롱 패딩']);
    assert.equal(restored.find(e=>e.id===first.id)?.sortOrder,1);
    assert.equal(restored.find(e=>e.id===second.id)?.sortOrder,2);
  } finally {
    if(before)Object.defineProperty(globalThis,'window',before);
    else Reflect.deleteProperty(globalThis,'window');
  }
});
