'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createAutoUpdate,RELEASE_FEED}=require('../electron/auto-update.cjs');
const {verifyUpdateRelease}=require('../../../scripts/verify-update-release.cjs');
const crypto=require('node:crypto');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(options={}) {
  const updater=new EventEmitter(),timers=[],intervals=[],calls=[];
  updater.setFeedURL=feed=>calls.push(['feed',feed]);
  updater.checkForUpdates=async()=>calls.push(['check']);
  updater.quitAndInstall=(...args)=>calls.push(['install',...args]);
  const controller=createAutoUpdate({updater,enabled:true,
    canInstall:()=>true,backup:async()=>{calls.push(['backup']);return {verified:true};},
    onError:message=>calls.push(['error',message]),
    setTimeout:(fn,delay)=>{const t={fn,delay};timers.push(t);return t;},
    clearTimeout:t=>{if(t)t.cancelled=true;},
    setInterval:(fn,delay)=>{const t={fn,delay};intervals.push(t);return t;},
    clearInterval:t=>{if(t)t.cancelled=true;},...options});
  return {controller,updater,timers,intervals,calls};
}
test('development is offline; installed startup check is deferred and stable public GitHub only',async()=>{
  const off=fixture({enabled:false});off.controller.start();
  assert.equal(off.timers.length,0);assert.equal(off.calls.length,0);
  const f=fixture();f.controller.start();f.controller.start();
  assert.deepEqual(RELEASE_FEED,{provider:'github',owner:'jjy1004',repo:'-K99-Windows-V1-Installer',private:false});
  assert.equal(f.updater.autoDownload,true);assert.equal(f.updater.autoInstallOnAppQuit,false);
  assert.equal(f.updater.allowDowngrade,false);assert.equal(f.updater.allowPrerelease,false);
  assert.equal(f.timers[0].delay,15000);assert.equal(f.calls.some(c=>c[0]==='check'),false);
  await f.timers[0].fn();await tick();
  assert.equal(f.calls.filter(c=>c[0]==='check').length,1);
  assert.equal(f.intervals[0].delay,21600000);
});
test('offline check and error event never crash or stop local work',async()=>{
  const f=fixture();f.updater.checkForUpdates=async()=>{throw Error('offline');};
  f.controller.start();await f.controller.check();
  assert.doesNotThrow(()=>f.updater.emit('error',Error('offline')));
  assert.equal(f.calls.filter(c=>c[0]==='error').length,2);
  assert.equal(f.calls.some(c=>c[0]==='install'),false);
});
test('unused startup downloads install only after delay and verified backup, then restart',async()=>{
  const f=fixture();f.controller.start();f.updater.emit('update-downloaded');
  assert.equal(f.calls.some(c=>c[0]==='install'),false);
  const timer=f.timers.find(t=>t.delay===60000);assert.ok(timer);
  timer.fn();await tick();
  assert.deepEqual(f.calls.slice(-2),[['backup'],['install',true,true]]);
});
test('any work cancels automatic restart; normal exit backs up before installation',async()=>{
  const f=fixture();f.controller.start();f.updater.emit('update-downloaded');
  f.controller.noteUserActivity();
  assert.equal(f.timers.find(t=>t.delay===60000).cancelled,true);
  f.timers.find(t=>t.delay===60000).fn();await tick(); // already queued callback is harmless
  assert.equal(f.calls.some(c=>c[0]==='install'),false);
  let prevented=0,normalExit=0;
  f.controller.beforeQuit({preventDefault:()=>prevented++},()=>normalExit++);
  await tick();
  assert.equal(prevented,1);assert.equal(normalExit,0);
  assert.deepEqual(f.calls.slice(-2),[['backup'],['install',true,true]]);
});
test('backup failure, unverified backup or active writes never install; normal exit remains possible',async()=>{
  for(const options of [
    {backup:async()=>{throw Error('disk full');}},
    {backup:async()=>({verified:false})},
    {canInstall:()=>false},
  ]) {
    const f=fixture(options);f.controller.start();f.updater.emit('update-downloaded');
    let exits=0;
    f.controller.beforeQuit({preventDefault(){}},()=>exits++);
    await tick();assert.equal(exits,1);assert.equal(f.calls.some(c=>c[0]==='install'),false);
    assert.equal(f.controller.beforeQuit({preventDefault(){throw Error('must allow exit');}},()=>{}),false);
  }
});
test('input arriving during an asynchronous backup cancels idle installation',async()=>{
  let finish;
  const f=fixture({backup:()=>new Promise(resolve=>finish=resolve)});
  f.controller.start();f.updater.emit('update-downloaded');
  f.timers.find(t=>t.delay===60000).fn();await tick();
  f.controller.noteUserActivity();finish({verified:true});await tick();
  assert.equal(f.calls.some(c=>c[0]==='install'),false);
});
test('shutdown removes timers and listeners and does not schedule more checks',async()=>{
  const f=fixture();f.controller.start();f.controller.dispose();await f.controller.check();
  assert.equal(f.updater.listenerCount('update-downloaded'),0);
  assert.equal(f.calls.some(c=>c[0]==='check'),false);
  assert.equal(f.timers[0].cancelled,true);assert.equal(f.intervals[0].cancelled,true);
});
test('release validator rejects stale versions, wrong hashes, paths and missing blockmap',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-update-release-'));
  try{
    const name='K99-Smart-Laundry-V2-Setup.exe',payload=Buffer.from('test-only-not-a-real-installer');
    fs.writeFileSync(path.join(dir,name),payload);
    fs.writeFileSync(path.join(dir,name+'.blockmap'),'test blockmap');
    const sha512=crypto.createHash('sha512').update(payload).digest('base64');
    const info={version:'2.4.10',path:name,sha512,files:[{url:name,sha512,size:payload.length}]};
    const verify=()=>verifyUpdateRelease(dir,{version:'2.4.10',parse:JSON.parse});
    const save=()=>fs.writeFileSync(path.join(dir,'latest.yml'),JSON.stringify(info));
    save();assert.equal(verify().bytes,payload.length);
    info.version='2.4.9';save();assert.throws(verify,/버전/);
    info.version='2.4.10';info.path='../bad.exe';save();assert.throws(verify,/경로/);
    info.path=name;info.sha512='wrong';save();assert.throws(verify,/SHA-512/);
    info.sha512=sha512;save();fs.unlinkSync(path.join(dir,name+'.blockmap'));assert.throws(verify);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('staging and release pipeline include updater runtime, metadata and stable tags without changing data paths',()=>{
  const root=path.resolve(__dirname,'../../..');
  const read=p=>fs.readFileSync(path.join(root,p),'utf8');
  const stage=read('scripts/stage-windows-app.cjs'),main=read('artifacts/k99-windows/electron/main.cjs');
  assert.match(stage,/'auto-update.cjs'/);assert.match(stage,/'electron-updater':packageVersion/);
  assert.match(stage,/'electron-updater':\{\.\.\.source.dependencies/);
  assert.match(main,/'K99WindowsV1'/);
  assert.match(main,/backup:async.*await aiSession.flush\(\).*manager.createBackup/);
  assert.match(main,/Uninstall K99-Laundry-V2.exe/);
  const workflow=read('.github/workflows/windows-installer.yml');
  assert.match(workflow,/verify-update-release.cjs/);
  assert.match(workflow,/\$tag = "v\$version"/);
  assert.match(workflow,/gh release upload.*latest.yml.*exe.blockmap/);
  assert.match(read('scripts/build-windows-installer.cjs'),/'--publish','never'/);
  const config=require('../electron-builder.cjs');
  assert.equal(config.appId,'com.k99.windows.v1');
  assert.equal(config.nsis.deleteAppDataOnUninstall,false);
  assert.equal(config.win.requestedExecutionLevel,'asInvoker');
});
test('verified update backup leaves actual SQLite records and existing settings untouched after reopen',async()=>{
  const {createDesktopManager}=require('../../../lib/k99-local/desktop-manager.cjs');
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-update-preservation-'));
  let manager;
  try{
    manager=createDesktopManager(root,{nativeDesktop:true});
    manager.store.api('POST','/api/desktop/admin/setup',{password:'검증전용-업데이트-암호'});
    const seeded=manager.store.ensurePresentationCustomer();
    const orderKey='k99-confirmed-orders-v1';
    const order={id:'update-retain-order',customerName:'보존검사',customerPhone:'01000000000',
      items:[{displayNameKo:'남방',quantity:1,generalPrice:5000}],estimatedTotal:5000,
      payment_type:'POSTPAID',payment_status:'UNPAID',garments:[]};
    manager.store.storage({op:'set',key:orderKey,value:JSON.stringify([order]),expected:null});
    const ordersBefore=manager.store.storage({op:'get',key:orderKey});
    const customerBefore=manager.store.api('GET',`/api/customers/${seeded.customerId}/history`);
    const profileBefore=manager.store.api('GET','/api/notices/profile');
    fs.writeFileSync(path.join(root,'customer-display.json'),'{"selectedDisplayId":123}');
    const layout='{"root":"D:\\\\기존매장","intake":"D:\\\\기존매장\\\\01_고객세탁사진"}';
    fs.writeFileSync(path.join(root,'storage-layout.json'),layout);
    const f=fixture({backup:async()=>manager.createBackup('before-application-update')});
    f.controller.start();f.updater.emit('update-downloaded');
    f.controller.beforeQuit({preventDefault(){}},()=>{throw Error('backup must succeed');});
    await tick();
    assert.equal(f.calls.some(c=>c[0]==='error'),false);
    assert.ok(f.calls.some(c=>c[0]==='install'));
    manager.close();manager=createDesktopManager(root,{nativeDesktop:true});
    assert.deepEqual(manager.store.api('GET',`/api/customers/${seeded.customerId}/history`),customerBefore);
    assert.deepEqual(manager.store.api('GET','/api/notices/profile'),profileBefore);
    assert.equal(manager.store.storage({op:'get',key:orderKey}),ordersBefore);
    assert.equal(manager.store.api('POST','/api/admin/password/check',{password:'검증전용-업데이트-암호'}).verified,true);
    assert.equal(fs.readFileSync(path.join(root,'storage-layout.json'),'utf8'),layout);
    assert.equal(fs.readFileSync(path.join(root,'customer-display.json'),'utf8'),'{"selectedDisplayId":123}');
    assert.ok(fs.readdirSync(path.join(root,'backups')).some(n=>n.endsWith('.k99backup')));
  }finally{manager?.close();fs.rmSync(root,{recursive:true,force:true});}
});
