import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createConfirmedOrder} from '../src/order-record';
import {requiredIntakeIdentity} from '../src/customer-input';
import {moveProcessStage, noticeDraft} from '../src/process-stage';

const choices={serviceLevel:'general' as const,pickupRequested:false,deliveryRequested:false,directPickup:true,
  requestedPickupDate:'',waiver:'not-requested' as const,luxuryItem:false,customerRequests:'없음'};
const input={id:'T-1',customerName:'김하늘',customerPhone:'5678',customerAddress:'',
  items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]};

test('flexible phone and optional address', () => {
  assert.equal(requiredIntakeIdentity('김하늘','5678'),true);
  assert.equal(requiredIntakeIdentity('김하늘','12'),false);
  assert.match(createConfirmedOrder(input,choices,new Date('2026-01-02T03:00:00Z')).customerFolderName,/김하늘 5678$/);
});

test('staff total override becomes laundryTotal and estimatedTotal', () => {
  const o=createConfirmedOrder(input,{...choices,totalOverride:8500});
  assert.equal(o.estimatedTotal,8500);
  assert.equal(o.laundryTotal,8500);
  assert.equal(o.choices.computedLaundryTotal,10000);
  assert.equal(createConfirmedOrder(input,choices).laundryTotal,10000);
  assert.throws(()=>createConfirmedOrder(input,{...choices,totalOverride:-1}));
});

test('process stages navigate freely and record furthest confirmed step', () => {
  let o=createConfirmedOrder(input,choices);
  o=moveProcessStage(o,'세탁 전','next');
  o=moveProcessStage(o,'완료 검수','tab');
  assert.equal(o.processStage?.current,'완료 검수');
  assert.equal(o.processStage?.reached,'세탁 전');
  o=moveProcessStage(o,'접수','tab');
  assert.equal(o.processStage?.reached,'세탁 전');
  assert.equal(o.processStage?.history.length,3);
  assert.match(noticeDraft(o,'both',3000),/3,000원.*\n?/s);
});

test('native draft units merge photo/tag and reserved id but keep final metadata', async () => {
  const {createGarmentRecords}=await import('../src/garment-record');
  const o=createConfirmedOrder(input,choices);
  const photo={garmentId:'D-9',requestId:'r1',role:'intake' as const,status:'saved' as const,timestamp:'t',origin:'bridge' as const,sourcePhotoId:'src-1',path:'p'};
  o.nativeDraftUnits=[{itemIndex:1,unitIndex:2,garment:{garmentId:'DRAFT-77',barcodeValue:'DRAFT-77',orderId:'draft',itemType:'shirt_dress',itemName:'임시',
    photoStatus:'saved',photoHistory:[photo],tagStatus:'printed',tagPrintCount:1} as never}];
  const g=createGarmentRecords(o);
  assert.equal(g[1].garmentId,'DRAFT-77');
  assert.equal(g[1].orderId,o.id);
  assert.equal(g[1].itemName,'와이셔츠');
  assert.equal(g[1].sequence,2);
  assert.equal(g[1].photoHistory?.[0].sourcePhotoId,'src-1');
  assert.equal(g[1].tagStatus,'printed');
  assert.equal(g[0].photoStatus,'not-captured');
});
