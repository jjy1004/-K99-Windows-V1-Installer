import {test} from 'node:test';
import assert from 'node:assert/strict';
import {CATALOG_DEFAULTS,receptionGroups} from '../src/price-catalog';
import {captureTargets,draftUnitKey,nextCaptureKey} from '../src/capture-targets';
test('member reception exact ordering preserves identifiers and prices; free input is outside miscellaneous group',()=>{
  const extras=['롱패딩','버버리','막스마라'].map((displayNameKo,i)=>({
    id:`user_extra-${i}`,displayNameKo,category:'outer' as const,userAdded:true,generalPrice:55555,premiumPrice:64555,
  }));
  const original=JSON.stringify(CATALOG_DEFAULTS);
  const groups=receptionGroups([...CATALOG_DEFAULTS.filter(e=>!e.legacy&&!e.derivedFrom),...extras]);
  assert.deepEqual(groups.find(g=>g.category==='outer')?.items.map(e=>e.displayNameKo),
    ['가죽','롱패딩','하프패딩','몽클레어','아웃도어','인조가죽','롱코트','하프코트','버버리','막스마라']);
  assert.deepEqual(groups.find(g=>g.category==='etc')?.items.map(e=>e.displayNameKo),['넥타이','모자','목도리','스카프','커튼','한복']);
  const top=groups.find(g=>g.category==='top')!.items.map(e=>e.id);
  const at=top.indexOf('sweater');
  assert.deepEqual(top.slice(at,at+5),['sweater','suit_jacket','suit_pants','shirt_dress','vest']);
  for(const id of ['jacket','jumper','one_piece_dress'])assert.ok(top.includes(id));
  assert.ok(!groups.some(g=>g.items.some(e=>e.id==='other')));
  assert.equal(JSON.stringify(CATALOG_DEFAULTS),original);
  assert.equal(groups.flatMap(g=>g.items).find(e=>e.id==='user_extra-0')!.generalPrice,55555);
});
test('three shirts and one pair of trousers advance by garment unit, never by row; last unit never wraps',()=>{
  const targets=captureTargets([{id:4,itemId:'shirt_dress',quantity:3},{id:8,itemId:'suit_pants',quantity:1}],r=>r.itemId);
  const keys=targets.map(t=>draftUnitKey(t.rowId,t.unitIndex));
  assert.deepEqual(keys,['4:1','4:2','4:3','8:1']);
  assert.deepEqual(targets.map(t=>`${t.unitIndex}/${t.rowQuantity}`),['1/3','2/3','3/3','1/1']);
  let selected=keys[0];
  for(const expected of keys.slice(1)){selected=nextCaptureKey(keys,selected)!;assert.equal(selected,expected);}
  assert.equal(nextCaptureKey(keys,selected),null);
  assert.equal(nextCaptureKey(keys,'missing'),null);
});
