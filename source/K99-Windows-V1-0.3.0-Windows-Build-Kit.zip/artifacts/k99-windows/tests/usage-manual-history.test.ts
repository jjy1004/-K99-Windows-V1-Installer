import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {RECEPTION_HELP,RECEPTION_HELP_WITH_USAGE,guideImageUrl} from '../src/guide-data';
const src=(name:string)=>fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
test('실제 카드의 차단된 미발송 문구는 비우고 과거 발송 원문은 그대로 표시한다',()=>{
  const source=src('PickupNoticeActions.tsx');
  const expression=source.match(/const draftOf = \(c: NoticeCard\) => ([^\n]+);/)?.[1];
  assert.ok(expression);
  const actual=new Function('c','drafts',`return ${expression};`);
  assert.equal(actual({blockedReason:'차단',text:'옛 자동 문구',kind:'delivery'},{delivery:'옛 초안'}),'');
  assert.equal(actual({blockedReason:'차단',sentAt:'2026-11-28',text:'과거 실제 원문',kind:'delivery'},{}),'과거 실제 원문');
  assert.equal(actual({text:'새 자동 문구',kind:'delivery'},{}),'새 자동 문구');
  assert.equal(actual({text:'새 자동 문구',kind:'day12'},{day12:'직원 수정 원문'}),'직원 수정 원문');
  assert.match(source,/onClick=\{\(\) => copy\(c\)\} disabled=\{!text\}/);
});
test('추가 활용 매뉴얼은 기존 여섯 항목·13장 원본 계약을 유지하면서 마지막에 추가한다',()=>{
  assert.equal(RECEPTION_HELP.length,6);
  assert.deepEqual(RECEPTION_HELP_WITH_USAGE.slice(0,6),RECEPTION_HELP);
  const manual=RECEPTION_HELP_WITH_USAGE.at(-1)!;
  assert.equal(manual.name,'K99 스마트 접수 시스템 활용 매뉴얼');assert.equal(manual.pages.length,12);
  for(const page of manual.pages){
    const bytes=fs.readFileSync(new URL('../public/images/'+page.path,import.meta.url));
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),page.sha256);
    assert.equal(bytes.length,page.bytes);assert.equal(bytes.readUInt32BE(16),page.width);assert.equal(bytes.readUInt32BE(20),page.height);
    assert.ok(guideImageUrl(page).includes(encodeURIComponent(page.name)));
  }
  assert.deepEqual(manual.pages.map(p=>p.path),[...manual.pages].sort((a,b)=>a.name.localeCompare(b.name,'ko',{numeric:true})||a.path.localeCompare(b.path,'ko',{numeric:true})).map(p=>p.path));
  assert.match(src('PictureGuide.tsx'),/RECEPTION_HELP_WITH_USAGE as RECEPTION_HELP/);
});
test('세탁·검수·출고 카드의 빠른 발송은 읽기 전용 이력으로 바꾸고 상세창 발송 진입은 남긴다',()=>{
  assert.match(src('LaundryDesk.tsx'),/<NoticeQuickActions[^>]*historyOnly/);
  const release=src('GarmentScannerWorkspace.tsx');
  assert.match(release,/<NoticeQuickActions[^>]*historyOnly/);
  assert.doesNotMatch(release,/data-testid=\{`button-card-notice-/);
  assert.match(src('NoticeQuickActions.tsx'),/if\(historyOnly\)/);
  assert.match(src('NoticeCardHistory.tsx'),/메시지 발송 이력/);
  assert.match(release,/openCustomerNotice/);
});
