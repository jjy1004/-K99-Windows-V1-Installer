'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {EventEmitter}=require('node:events');
const {createCustomerDisplay}=require('../electron/customer-display.cjs');
const {videoResponse}=require('../electron/customer-video.cjs');
function harness(preferencesFile){
  const windows=[],staff=[];
  class Window extends EventEmitter {
    constructor(options){super();this.options=options;this.dead=false;this.sent=[];
      this.webContents=new EventEmitter();this.webContents.send=(channel,data)=>this.sent.push({channel,data});
      this.webContents.setWindowOpenHandler=fn=>{this.popup=fn;};windows.push(this);}
    async loadURL(url){this.url=url;}show(){this.visible=true;}isDestroyed(){return this.dead;}
    isMinimized(){return !!this.minimized;}restore(){this.minimized=false;this.restored=true;}
    focus(){this.focused=true;}setAlwaysOnTop(value,level){this.top=value;this.topLevel=level;}
    close(){this.emit('close');this.dead=true;this.emit('closed');}
    setBounds(bounds){this.bounds=bounds;}setFullScreen(value){this.fullscreen=value;}
  }
  const screen=new EventEmitter();
  let displays=[{id:1,label:'Staff',bounds:{x:0,y:0,width:1440,height:900}},
    {id:9,label:'LG FULL HD',bounds:{x:-1920,y:-80,width:1920,height:1080}}];
  screen.getAllDisplays=()=>displays;screen.getPrimaryDisplay=()=>displays[0];
  const display=createCustomerDisplay({BrowserWindow:Window,screen,preload:'mock-only',
    getMain:()=>({isDestroyed:()=>false,webContents:{send:(channel,data)=>staff.push({channel,data})}}),
    changed:()=>{},preferencesFile});
  return {display,windows,staff,screen,setDisplays:value=>{displays=value;},getDisplays:()=>displays};
}
test('explicit idle shares validated video IPC, foregrounds without pinning and ACK stays connected',async()=>{
  const h=harness();await h.display.restore();const win=h.windows[0];
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  h.display.action({type:'video',command:{id:'guide-before-idle',video:'process',issuedAt:Date.now()}});
  assert.equal(win.top,true);
  win.minimized=true;
  h.display.action({type:'video',command:{id:'idle-1',video:'idle',issuedAt:Date.now()}});
  assert.equal(win.top,false);assert.equal(win.restored,true);assert.equal(win.fullscreen,true);
  assert.equal(win.sent.at(-1).data.command.video,'idle');
  h.display.customerEvent(win.webContents,{type:'ACK',commandId:'idle-1'});
  assert.equal(h.staff.at(-1).data.commandId,'idle-1');
  assert.equal(h.display.displayStatus().connected,true);
  assert.throws(()=>h.display.action({type:'video',command:{id:'old',video:'idle',issuedAt:Date.now()-10000}}));
});
test('startup selects secondary by ID and true bounds, fullscreen; READY is required',async()=>{
  const h=harness();await h.display.restore();
  const win=h.windows[0];
  assert.equal(win.options.x,-1920);assert.equal(win.options.y,-80);assert.equal(win.options.fullscreen,true);
  assert.equal(win.url,'k99://app/customer');assert.equal(h.display.displayStatus().connected,false);
  h.display.customerEvent({}, {type:'CUSTOMER_READY'});
  assert.equal(h.display.displayStatus().connected,false);
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  assert.equal(h.display.displayStatus().connected,true);
  assert.equal(h.staff.at(-1).data.connected,true);
});
test('selection persists across process recreation, reuses one window, and primary is never automatic',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-monitor-'));
  try{
    const file=path.join(dir,'display.json'),h=harness(file);
    await h.display.openCustomer('9');await h.display.openCustomer('9');
    assert.equal(h.windows.length,1);
    const restarted=harness(file);await restarted.display.restore();
    assert.equal(restarted.display.displayStatus().displayId,'9');assert.equal(restarted.windows.length,1);
    restarted.display.closeCustomer();const closed=harness(file);await closed.display.restore();assert.equal(closed.windows.length,0);
    const solo=harness();solo.setDisplays([solo.getDisplays()[0]]);await solo.display.restore();assert.equal(solo.windows.length,0);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('snapshots survive staff remount/customer reload; video commands never replay on READY',async()=>{
  const h=harness();await h.display.openCustomer('9');const win=h.windows[0];
  h.display.action({type:'snapshot',payload:{sourceId:'draft-test',rows:[],revision:1}});
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  assert.equal(win.sent.at(-1).data.type,'snapshot');
  const command={id:'unique-live-video',video:'process',issuedAt:Date.now()};
  h.display.action({type:'video',command});
  assert.equal(win.sent.at(-1).data.command.id,command.id);
  h.display.customerEvent(win.webContents,{type:'ACK',commandId:'wrong'});
  assert.notEqual(h.staff.at(-1).data.type,'ACK');
  h.display.customerEvent(win.webContents,{type:'ACK',commandId:command.id});
  assert.equal(h.staff.at(-1).data.type,'ACK');
  win.webContents.emit('did-start-loading');
  assert.equal(h.display.displayStatus().connected,false);
  const count=win.sent.filter(e=>e.data.type==='video').length;
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  assert.equal(win.sent.filter(e=>e.data.type==='video').length,count);
  assert.equal(win.sent.at(-1).data.type,'snapshot');
});
test('unplug preserves selected ID, never opens staff display; replug and metrics restore placement',async()=>{
  const h=harness();await h.display.openCustomer('9');const displays=h.getDisplays();
  h.setDisplays([displays[0]]);h.screen.emit('display-removed',null,displays[1]);
  assert.equal(h.display.displayStatus().displayId,'9');assert.equal(h.display.displayStatus().connected,false);
  await h.display.restore();assert.equal(h.windows.length,1);
  h.setDisplays(displays);h.screen.emit('display-added',null,displays[1]);
  await new Promise(r=>setImmediate(r));assert.equal(h.windows.length,2);
  const changed={...displays[1],bounds:{x:1440,y:0,width:1280,height:720}};
  h.screen.emit('display-metrics-changed',null,changed);
  assert.deepEqual(h.windows[1].bounds,changed.bounds);assert.equal(h.windows[1].fullscreen,true);
});
test('invalid/expired videos, unrelated paths and unsupported commands remain rejected',async()=>{
  const h=harness();
  for(const video of ['../../secret','unknown'])assert.throws(()=>h.display.action({type:'video',command:{id:'x',video,issuedAt:Date.now()}}));
  assert.throws(()=>h.display.action({type:'video',command:{id:'x',video:'value',issuedAt:Date.now()-10000}}));
  assert.throws(()=>h.display.action({type:'snapshot',payload:{sourceId:'x'}}));
  assert.throws(()=>h.display.action({type:'delete-orders'}));
});
test('local video protocol supports streaming, byte ranges, HEAD and rejects traversal/missing clips',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-video-'));
  try{
    const bytes=Buffer.from('0123456789abcdef');fs.writeFileSync(path.join(dir,'value.mp4'),bytes);
    const request=(file='value.mp4',range,method='GET')=>new Request('k99://app/videos/'+file,{method,headers:range?{range}:{}});
    const full=await videoResponse(request(),dir);assert.equal(full.status,200);assert.equal(Buffer.from(await full.arrayBuffer()).compare(bytes),0);
    const partial=await videoResponse(request('value.mp4','bytes=2-5'),dir);
    assert.equal(partial.status,206);assert.equal(await partial.text(),'2345');assert.equal(partial.headers.get('Content-Range'),'bytes 2-5/16');
    const suffix=await videoResponse(request('value.mp4','bytes=-4'),dir);assert.equal(await suffix.text(),'cdef');
    const head=await videoResponse(request('value.mp4',undefined,'HEAD'),dir);assert.equal(head.headers.get('Content-Length'),'16');assert.equal(await head.text(),'');
    for(const range of ['bytes=999-','bytes=6-2','bytes=1-2,5-6','bytes=-0'])
      assert.equal((await videoResponse(request('value.mp4',range),dir)).status,416);
    assert.equal((await videoResponse(request('../secret'),dir)).status,404);
    assert.equal((await videoResponse(request('water.mp4'),dir)).status,404);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('only the four original receipt guide names are exposed; no placeholder detection remains',()=>{
  const media=require('../electron/customer-video.cjs');
  assert.deepEqual(Object.values(media.VIDEO_FILES),['value.mp4','process.mp4','water.mp4','sneakers.mp4']);
  assert.equal(media.placeholderFiles,undefined);
});
test('all four video commands restore, focus, pin and fullscreen; matching end unpins only',async()=>{
  const h=harness();await h.display.openCustomer('9');const win=h.windows[0];
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  for(const video of ['value','process','water','sneakers']){
    win.minimized=true;win.focused=false;win.visible=false;
    const command={id:`foreground-${video}`,video,issuedAt:Date.now()};
    h.display.action({type:'video',command});
    assert.equal(win.restored,true);assert.equal(win.minimized,false);
    assert.equal(win.focused,true);assert.equal(win.visible,true);
    assert.equal(win.top,true);assert.equal(win.topLevel,'screen-saver');assert.equal(win.fullscreen,true);
    h.display.customerEvent({}, {type:'STATUS',commandId:command.id,diagnostic:{event:'ended'}});
    h.display.customerEvent(win.webContents,{type:'STATUS',commandId:'old-command',diagnostic:{event:'ended'}});
    assert.equal(win.top,true,'untrusted and stale events cannot release current video');
    h.display.customerEvent(win.webContents,{type:'STATUS',commandId:command.id,diagnostic:{event:'ended'}});
    assert.equal(win.top,false);assert.equal(win.fullscreen,true,'receipt remains fullscreen');
    assert.equal(h.display.displayStatus().connected,true);
  }
});
test('error, staff return, new receipt, reload, crash and close release topmost without replay',async()=>{
  for(const reason of ['error','screen','snapshot','reload','crash','close']){
    const h=harness();await h.display.openCustomer('9');const win=h.windows[0];
    h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
    const command={id:'release-test',video:'value',issuedAt:Date.now()};
    h.display.action({type:'video',command});
    assert.equal(win.top,true);
    if(reason==='error')h.display.customerEvent(win.webContents,{type:'STATUS',commandId:command.id,error:'Playback failed'});
    if(reason==='screen')h.display.action({type:'screen',screen:'order'});
    if(reason==='snapshot')h.display.action({type:'snapshot',payload:{sourceId:'next-customer',rows:[]}});
    if(reason==='reload')win.webContents.emit('did-start-loading');
    if(reason==='crash')win.webContents.emit('render-process-gone');
    if(reason==='close')h.display.closeCustomer();
    assert.equal(win.top,false,reason);
    if(reason!=='close')assert.equal(win.fullscreen,true,reason);
  }
});
test('unready/invalid video never steals focus; native activation error clears topmost',async()=>{
  const h=harness();await h.display.openCustomer('9');const win=h.windows[0];
  const command={id:'activation-failure',video:'value',issuedAt:Date.now()};
  h.display.action({type:'video',command});assert.notEqual(win.top,true);assert.notEqual(win.focused,true);
  h.display.customerEvent(win.webContents,{type:'CUSTOMER_READY'});
  assert.throws(()=>h.display.action({type:'video',command:{...command,video:'unknown'}}));
  win.focus=()=>{throw Error('Native focus error');};
  assert.throws(()=>h.display.action({type:'video',command}),/Native focus error/);
  assert.equal(win.top,false);
  assert.equal(win.sent.filter(x=>x.data.type==='video').length,0);
});
