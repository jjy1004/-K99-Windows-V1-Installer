import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {initialIntakeChoices,INTAKE_PAYMENT_WARNING,isIntakePaymentType,matchesCardApproval} from '../src/intake-payment';

test('새 접수·앱 첫 진입은 미선택이며 다른 초안 정보와 과거 저장 결제는 보존한다',()=>{
  const draft={paymentType:'PREPAID' as const,pickupRequested:true,customerRequests:'기존 메모'};
  assert.equal(initialIntakeChoices(undefined).paymentType,undefined);
  assert.equal(initialIntakeChoices(draft).paymentType,undefined);
  assert.equal(initialIntakeChoices(draft).customerRequests,'기존 메모');
  assert.equal(draft.paymentType,'PREPAID');
  for(const type of ['PREPAID','POSTPAID'] as const)assert.equal(initialIntakeChoices(draft,type).paymentType,type);
});
test('결제 구분은 명시한 선불·후불만 통과하며 빈값과 임의 상태는 차단한다',()=>{
  for(const value of [undefined,null,'','선불','후불','COD',true,false])assert.equal(isIntakePaymentType(value),false);
  assert.equal(isIntakePaymentType('PREPAID'),true);assert.equal(isIntakePaymentType('POSTPAID'),true);
});
test('현재 접수와 동일 금액의 실제 승인 형식만 자동 선불 수신 조건을 통과한다',()=>{
  const approved={orderId:'draft-now',status:'APPROVED',approvalNumber:'승인-검증',approvedAt:new Date().toISOString(),amount:100000};
  assert.equal(matchesCardApproval(approved,'draft-now',100000),true);
  for(const patch of [{orderId:'past-order'},{status:'DECLINED'},{status:'CANCELLED'},{approvalNumber:''},{approvedAt:'잘못된 시각'},{amount:99999},{amount:100001},{status:'printed'}]){
    assert.equal(matchesCardApproval({...approved,...patch},'draft-now',100000),false);
  }
  assert.equal(matchesCardApproval({...approved,amount:0},'draft-now',0),false);
  assert.equal(matchesCardApproval(null,'draft-now',100000),false);
});
test('첫 화면 이동·실제 저장·접수증 모두 미선택을 차단하고 선불 기본 체크는 없다',()=>{
  const app=fs.readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
  assert.match(app,/checked=\{currentPayment==='PREPAID'\}/);
  assert(!app.includes("checked={finalChoices?.paymentType!=='POSTPAID'}"));
  assert.match(app,/onFinalConfirm=\{\(\) => \{\s*if\(!requirePaymentSelection\(\)\)return/);
  assert.match(app,/if \(estimateConfirmed && \(confirmedOrder\|\|isIntakePaymentType\(currentPayment\)\)\)/);
  assert.match(app,/!isIntakePaymentType\(choices\.paymentType\)/);
  assert.match(app,/onClick=\{\(\)=>\{if\(!requirePaymentSelection\(\)\)return;setReceiptOpen/);
  assert.match(app,/setPaymentInvalid\(false\);setPaymentWarningOpen\(false\);automaticCardApproval\.current=null/);
  const final=fs.readFileSync(new URL('../src/FinalIntakeConfirmation.tsx',import.meta.url),'utf8');
  assert(!final.includes("init.paymentType ?? 'PREPAID'"));
  assert.match(final,/!isIntakePaymentType\(paymentType\)/);
});
test('큰 빨간 경고·결제 박스 점멸·감소된 동작 설정을 제공한다',()=>{
  const css=fs.readFileSync(new URL('../src/intake-payment.css',import.meta.url),'utf8');
  assert.match(css,/font-size:30px/);assert.match(css,/animation:intake-payment-alert/);
  assert.match(css,/prefers-reduced-motion:reduce/);
  assert.equal(INTAKE_PAYMENT_WARNING,'⚠️ 결제 구분(선불 또는 후불)을 먼저 선택해 주세요! (카드 결제 완료 시 자동 선불 체크)');
});
test('카드 승인은 읽기 전용 IPC로만 받고 인쇄·브라우저 이벤트를 승인으로 쓰지 않는다',()=>{
  const preload=fs.readFileSync(new URL('../electron/preload.cjs',import.meta.url),'utf8');
  assert.match(preload,/onCardApproval:callback/);
  assert.match(preload,/ipcRenderer\.on\('k99:card-approved',handler\)/);
  assert(!/ipcRenderer\.(?:send|invoke)\('k99:card-approved'/.test(preload));
  const app=fs.readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
  assert.match(app,/onCardApproval\?\.\(approval=>/);
  assert(!/addEventListener\(['"](?:k99:)?card-approved/.test(app));
});
