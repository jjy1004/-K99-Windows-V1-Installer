import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {printCareCard} from '../src/general-print';
import {refreshTerminalConnection} from '../src/terminal-connection';
const root=path.join(process.cwd(),'artifacts/k99-windows');
const source=(name:string)=>fs.readFileSync(path.join(root,name),'utf8');
function classes(initial:string[]=[]){const set=new Set(initial);return {add:(s:string)=>set.add(s),remove:(s:string)=>set.delete(s),contains:(s:string)=>set.has(s)};}
test('일반 고객 카드만 인쇄하고 네이티브 실패·취소 후에도 원래 화면을 복원한다',async()=>{
  const oldDocument=Object.getOwnPropertyDescriptor(globalThis,'document'),oldWindow=Object.getOwnPropertyDescriptor(globalThis,'window');
  try{
    for(const fail of [false,true]){
      const body={classList:classes()},parent={classList:classes(),parentElement:body};
      const card={parentElement:parent};const calls:unknown[]=[];
      Object.defineProperty(globalThis,'document',{configurable:true,value:{body,querySelectorAll:()=>[card]}});
      Object.defineProperty(globalThis,'window',{configurable:true,value:{print:()=>assert.fail('라벨용 전역 인쇄를 우회하지 않는다'),
        k99Desktop:{hardwareSettings:async(input:unknown)=>{calls.push(input);assert(body.classList.contains('k99-care-print'));if(fail)throw Error('취소');return {};}}}});
      if(fail)await assert.rejects(printCareCard(),/취소/);else await printCareCard();
      assert.deepEqual(calls,[{action:'general-print'}]);
      assert(!body.classList.contains('k99-care-print'));assert(!parent.classList.contains('k99-print-ancestor'));
    }
  }finally{
    if(oldDocument)Object.defineProperty(globalThis,'document',oldDocument);else Reflect.deleteProperty(globalThis,'document');
    if(oldWindow)Object.defineProperty(globalThis,'window',oldWindow);else Reflect.deleteProperty(globalThis,'window');
  }
});
test('일반 출력 여백은 이름 붙인 페이지만 적용하며 라벨·전역 출력 제한은 보존한다',()=>{
  const css=source('src/care-result-card.css');
  assert.match(css,/@page k99-care\s*\{ size: A4; margin: 10mm;/);
  assert.match(css,/body\.k99-care-print \.crc \{ page: k99-care/);
  assert.match(source('src/desktop-runtime.ts'),/window\.print = \(\) => \{throw new Error/);
  const main=source('electron/main.cjs');
  assert.match(main,/margins:\{marginType:'custom',top:10,bottom:10,left:10,right:10\}/);
  assert.match(main,/void hardwareSettingsApi\(\{action:'terminal-check'\}\)\.catch/);
  for(const name of ['App.tsx','FinalIntakeConfirmation.tsx','OperationsDashboard.tsx'])assert(source('src/'+name).includes('void refreshTerminalConnection()'),name);
});
test('결제 전 재확인 실패는 승인으로 변환하지 않고 수동 기록 흐름을 바꾸지 않는다',async()=>{
  const descriptor=Object.getOwnPropertyDescriptor(globalThis,'window');
  try{
    Object.defineProperty(globalThis,'window',{configurable:true,value:{k99Desktop:{hardwareSettings:async(input:unknown)=>{
      assert.deepEqual(input,{action:'terminal-check'});throw Error('점유');}}}});
    const r=await refreshTerminalConnection();assert.equal(r.connected,false);assert.match(r.message,/수동 설정/);
  }finally{if(descriptor)Object.defineProperty(globalThis,'window',descriptor);else Reflect.deleteProperty(globalThis,'window');}
});
