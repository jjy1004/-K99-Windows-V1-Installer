import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = (name: string) => readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');

test('camera guidance follows preview and saved shots without changing capture IPC or shortcut bridges', () => {
  const camera = source('NativeDraftCamera.tsx');
  assert.match(camera, /!previewOn \? 'ndc__preview-guide'/);
  assert.match(camera, /disabled=\{!previewOn \|\| !target \|\| busy \|\| disabled \|\| targetConflict\}/);
  assert.match(camera, /추가 촬영 가능/);
  assert.match(camera, /captureShortcut\(event\)/);
  assert.match(camera, /key==='F7'&&keysRef\.current\.footReady/);
  assert.match(camera, /window\.addEventListener\('keydown',handler,true\)/);
  assert.match(camera, /equipmentRequest<CaptureResponse>\('capture-draft'/);
  assert.match(source('App.tsx'), /nativeUnits\.some\(unit => \(unit\.garment\.photoHistory\?\.length \?\? 0\) > 0\)/);
  assert.match(source('native-draft-camera.css'), /font-size:18px/);
});

test('final action uses existing atomic bulk QC and navigates only after successful synchronous persistence', () => {
  const desk = source('InspectionStageDesk.tsx');
  assert.match(desk, /if \(persist\(o => completeFieldQuality\(o\), [^\n]+\)\) onCompleted\?\.\(\)/);
  assert.match(desk, /updateSavedOrder\(updated, order\);\s+onSaved\(updated\)/);
  assert.doesNotMatch(desk, /disabled=[^>]+data-testid="button-isd-finish-all"/);
  assert.match(source('OrderWorkspace.tsx'), /onCompleted=\{\(\) => navigate\('\/scan'\)\}/);
  assert.match(source('inspection-stage-desk.css'), /isd__notice-title\{color:#dc2626/);
});
