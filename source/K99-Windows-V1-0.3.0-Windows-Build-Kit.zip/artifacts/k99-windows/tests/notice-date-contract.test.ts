import {test} from 'node:test';
import assert from 'node:assert/strict';
import {pickupNoticeText} from '../src/customer-pickup-notices';
import type {ConfirmedOrder} from '../src/order-record';
import templates from '../../../lib/k99-local/pickup-templates.json';
test('12일 안내의 화면 문구도 한국 발송일 기준 +5일·+7일을 계산한다',()=>{
  const at=new Date('2026-11-28T15:30:00Z');
  const expected=templates.day12.replace('{발송일+5일}','12월 4일').replace('{발송일+7일}','12월 6일');
  assert.equal(pickupNoticeText({} as ConfirmedOrder,'day12',at),expected);
});
