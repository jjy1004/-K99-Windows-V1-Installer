import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
import {downloadCustomerDirectory,customerDirectoryCsv} from '../src/customer-directory-export';
import type {MasterCustomer} from '../src/customer-directory-client';
const require=createRequire(import.meta.url);
const {createCustomerDirectoryExport,MAX_CSV_BYTES}=require('../electron/customer-directory-export.cjs');
const {createMobilePhotoBridge}=require('../electron/mobile-photo-bridge.cjs');

function temp(t:{after:(fn:()=>void)=>void}){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-integrity-audit-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  return dir;
}
const customer:MasterCustomer={id:'audit-only',name:'검증용 고객',phone:'01000001234',address:'=수식아님',
  totalVisits:0,nextVisit:1,totalItems:0,totalAmount:0,visits:[]};

test('native CSV frontend contract persists actual BOM/Unicode/formula-safe file without browser downloads',async t=>{
  const dir=temp(t),file=path.join(dir,'고객명부.csv');
  const nativeSave=createCustomerDirectoryExport({authorize:(password:string)=>assert.equal(password,'fixture-only'),pickFile:async()=>file});
  const old=Object.getOwnPropertyDescriptor(globalThis,'window');
  const requests:unknown[]=[];
  Object.defineProperty(globalThis,'window',{configurable:true,value:{k99Desktop:{request:async(input:{method:string;path:string;body:unknown})=>{
    requests.push(input);
    assert.equal(input.method,'POST');assert.equal(input.path,'/api/customer-directory/export');
    return {ok:true,result:await nativeSave(input.body)};
  }}}});
  try{
    const result=await downloadCustomerDirectory([customer],'fixture-only');
    assert.equal(result.saved,true);assert.equal(result.filePath,file);assert.equal(requests.length,1);
    const bytes=fs.readFileSync(file);
    assert.deepEqual([...bytes.subarray(0,3)],[239,187,191]);
    assert.equal(bytes.toString('utf8'),customerDirectoryCsv([customer]));
    assert.match(bytes.toString('utf8'),/'=수식아님/);
    assert.equal(result.bytes,bytes.length);
    assert.deepEqual(fs.readdirSync(dir),['고객명부.csv']);
  }finally{if(old)Object.defineProperty(globalThis,'window',old);else Reflect.deleteProperty(globalThis,'window');}
});

test('native CSV cancellation, invalid formats, DB extension and disk failure cannot report success or alter existing files',async t=>{
  const dir=temp(t),input={csv:customerDirectoryCsv([customer]),fileName:'K99_고객명부_접수이력_20261106.csv'};
  const db=path.join(dir,'k99.db');fs.writeFileSync(db,'original-protected-data');
  const cancelled=createCustomerDirectoryExport({authorize:()=>{},pickFile:async()=>null});
  assert.deepEqual(await cancelled(input),{saved:false,cancelled:true});
  const badExtension=createCustomerDirectoryExport({authorize:()=>{},pickFile:async()=>db});
  await assert.rejects(()=>badExtension(input),/csv/);
  assert.equal(fs.readFileSync(db,'utf8'),'original-protected-data');
  let called=false;
  const invalid=createCustomerDirectoryExport({authorize:()=>{},pickFile:async()=>{called=true;return path.join(dir,'x.csv');}});
  await assert.rejects(()=>invalid({...input,csv:'no BOM'}),/형식/);
  await assert.rejects(()=>invalid({...input,fileName:'../../k99.csv'}),/형식/);
  await assert.rejects(()=>invalid({...input,csv:'\uFEFF'+'a'.repeat(MAX_CSV_BYTES)}),/32MB/);
  assert.equal(called,false);
  const diskError=createCustomerDirectoryExport({authorize:()=>{},pickFile:async()=>path.join(dir,'missing-parent','output.csv')});
  await assert.rejects(()=>diskError(input),/CSV 저장 실패/);
  const file=path.join(dir,'existing.csv');fs.writeFileSync(file,'previous CSV');
  const save=createCustomerDirectoryExport({authorize:()=>{},pickFile:async()=>file});
  assert.equal((await save(input)).saved,true);
  assert.equal(fs.readFileSync(file,'utf8'),input.csv);
  assert.ok(!fs.readdirSync(dir).some(n=>n.endsWith('.tmp')));
});

test('occupied mobile LAN port fails explicitly and leaves the other server untouched',async t=>{
  const occupied=http.createServer((_req,res)=>res.end('other local app'));
  await new Promise<void>(resolve=>occupied.listen(0,'127.0.0.1',resolve));
  const port=(occupied.address() as {port:number}).port;
  const bridge=createMobilePhotoBridge({port,host:'127.0.0.1',addresses:()=>['127.0.0.1'],
    validateTarget:()=>({orderId:'audit-order',customerName:'검증',phoneLast4:'1234',itemName:'셔츠',folderIdentifier:'audit'}),
    capture:async()=>{throw new Error('must never capture while port is occupied');}});
  t.after(()=>{bridge.close();occupied.closeAllConnections();occupied.close();});
  await assert.rejects(()=>bridge.api('POST','/api/mobile-photo/start',{}),/EADDRINUSE/);
  const result=await fetch(`http://127.0.0.1:${port}/`);
  assert.equal(await result.text(),'other local app');
});

test('packaged export is included without relaxing network/download security or changing existing IPC channels',()=>{
  const main=fs.readFileSync(new URL('../electron/main.cjs',import.meta.url),'utf8');
  assert.match(main,/showSaveDialog\(mainWindow,\{title:'고객 명부/);
  assert.match(main,/will-download', event => event\.preventDefault\(\)/);
  assert.match(main,/cancel:!details\.url\.startsWith\('k99:\/\/app\/'\)/);
  assert.match(main,/ipcMain\.handle\('k99:request'/);
  assert.match(main,/input\.path==='\/api\/customer-directory\/export'/);
  const stage=fs.readFileSync(new URL('../../../scripts/stage-windows-app.cjs',import.meta.url),'utf8');
  assert.match(stage,/customer-directory-export\.cjs/);
  const panel=fs.readFileSync(new URL('../src/ManagementCustomerPanel.tsx',import.meta.url),'utf8');
  assert.match(panel,/await downloadCustomerDirectory\(filtered, password\)/);
  assert.match(panel,/CSV 저장 완료/);
});
