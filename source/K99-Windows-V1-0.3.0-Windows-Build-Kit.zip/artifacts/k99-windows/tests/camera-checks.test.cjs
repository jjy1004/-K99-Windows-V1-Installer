const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createCameraChecks,CAMERA_SETTINGS}=require('../electron/camera-checks.cjs');
const base={platform:'win32',appExecutable:'C:\\Program Files\\K99\\K99.exe',env:{SystemRoot:'C:\\Windows'},
  interfaces:()=>({wifi:[{address:'192.168.1.3',internal:false}]})};
test('Windows consent deny is found at user, desktop, machine and exact-app levels',async()=>{
  for(const blocked of ['HKCU-root','desktop','machine','app']){
    const seen=[];
    const api=createCameraChecks({...base,execute:async(file,args)=>{
      seen.push([file,args]);const key=args[1];
      const match=blocked==='HKCU-root'?key.startsWith('HKCU')&&key.endsWith('\\webcam'):
        blocked==='desktop'?key.endsWith('\\NonPackaged'):
        blocked==='machine'?key.startsWith('HKLM')&&key.endsWith('\\webcam'):key.includes('C:#Program Files#K99#K99.exe');
      return `\r\n Value    REG_SZ    ${match?'Deny':'Allow'}\r\n`;
    }});
    const result=await api.status();assert.equal(result.permission.state,'denied',blocked);
    assert.equal(result.network.state,'connected');
    assert(seen.every(([file,args])=>file==='C:\\Windows\\System32\\reg.exe'&&args[0]==='query'&&args.includes('/reg:64')));
  }
});
test('machine camera policy deny overrides user allow without changing the registry',async()=>{
  const api=createCameraChecks({...base,execute:async(_file,args)=>args[1].endsWith('AppPrivacy')?
    ' LetAppsAccessCamera REG_DWORD 0x2':' Value REG_SZ Allow'});
  const report=await api.status();assert.equal(report.permission.state,'denied');
  assert.deepEqual(report.permission.blocked,['PC 관리 정책']);
});
test('missing keys, blocked reg.exe and unrecognized output are unknown, never false success',async()=>{
  for(const execute of [async()=>{throw Error('정책 차단');},async()=>' Value REG_SZ Something']){
    const report=await createCameraChecks({...base,execute}).status();
    assert.equal(report.permission.state,'unknown');assert.equal(report.permission.checked,0);
  }
});
test('network checks do not require internet and disconnected/loopback/link-local are offline',async()=>{
  for(const rows of [{},{local:[{internal:true,address:'127.0.0.1'}]},
    {wifi:[{internal:false,address:'169.254.2.3'},{internal:false,address:'fe80::2'}]}]){
    const report=await createCameraChecks({...base,interfaces:()=>rows,execute:async()=>''}).status();
    assert.equal(report.network.state,'offline');assert.match(report.network.note,/USB/);
  }
  const result=await createCameraChecks({...base,interfaces:()=>{throw Error('차단');},execute:async()=>''}).status();
  assert.equal(result.network.state,'unknown');
});
test('concurrent checks share a bounded async query; cache refreshes network immediately',async()=>{
  let release,calls=0,online=true,time=10000;
  const wait=new Promise(r=>{release=r;});
  const api=createCameraChecks({...base,now:()=>time,interfaces:()=>online?base.interfaces():{},
    execute:async()=>{calls++;await wait;return ' Value REG_SZ Allow';}});
  const first=api.status();assert.equal(api.status(),first);release();
  assert.equal((await first).permission.state,'not-denied');assert.equal(calls,5);
  online=false;assert.equal((await api.status()).network.state,'offline');assert.equal(calls,5);
  time+=5001;await api.status();assert.equal(calls,10);
});
test('settings only opens the fixed camera privacy URI; failures do not write settings',async()=>{
  const opened=[];
  const api=createCameraChecks({...base,shell:{openExternal:async url=>opened.push(url)}});
  assert.deepEqual(await api.openSettings(),{opened:true});assert.deepEqual(opened,[CAMERA_SETTINGS]);
  await assert.rejects(createCameraChecks({...base,shell:{openExternal:async()=>{throw Error('차단');}}}).openSettings(),/시작 메뉴/);
  let calls=0;const other=createCameraChecks({platform:'linux',interfaces:()=>({}),execute:async()=>{calls++;}});
  assert.equal((await other.status()).permission.state,'unsupported');assert.equal(calls,0);
  await assert.rejects(other.openSettings(),/Windows/);
});
test('default OS commands are async with finite timeout and the new module is staged',()=>{
  const fs=require('node:fs'),path=require('node:path');
  const source=fs.readFileSync(path.join(__dirname,'../electron/camera-checks.cjs'),'utf8');
  assert.match(source,/timeout:1800/);assert.doesNotMatch(source,/spawnSync|execFileSync|powershell|netsh|writeFile|setItem/);
  const main=fs.readFileSync(path.join(__dirname,'../electron/main.cjs'),'utf8');
  assert.match(main,/void cameraChecks\.status\(\)/);
  assert.match(main,/event\.sender!==mainWindow\?\.webContents/);
  assert.match(main,/input\?\.action==='open-settings'/);
});
