import { test } from 'node:test';
import assert from 'node:assert/strict';
import { customerQuery, uniquePhoneCustomer, customerOptionIndex, customerPhoneDisplay, customerKeyboardOwnsEnter } from '../src/customer-autofill';

test('name waits for two characters, Korean and English preserve exact keyword', () => {
  assert.equal(customerQuery('김', '', 'name'), null);
  assert.deepEqual(customerQuery(' 김자동 ', '', 'name'), { keyword: '김자동', kind: 'name' });
  assert.deepEqual(customerQuery('Alice Kim', '', 'name'), { keyword: 'Alice Kim', kind: 'name' });
});
test('phone focus never falls back to an old name, and only four digits query', () => {
  for (const p of ['', '1', '123', '010-1234-5678', 'abc1234']) assert.equal(customerQuery('이전고객', p, 'phone'), null);
  assert.deepEqual(customerQuery('이전고객', '123-4', 'phone'), { keyword: '1234', kind: 'phone' });
  assert.deepEqual(customerQuery('1234', '', 'name'), { keyword: '1234', kind: 'phone' });
});
test('only a single phone result auto-selects; names and duplicates require explicit choice', () => {
  const people = [{ id: 'first' }, { id: 'second' }];
  const phone = { keyword: '1234', kind: 'phone' as const };
  assert.equal(uniquePhoneCustomer(phone, people.slice(0, 1)), people[0]);
  assert.equal(uniquePhoneCustomer(phone, people), null);
  assert.equal(uniquePhoneCustomer(phone, []), null);
  assert.equal(uniquePhoneCustomer({ keyword: '김자동', kind: 'name' }, people.slice(0, 1)), null);
});
test('keyboard wraps and complete numbers format without inventing missing digits', () => {
  assert.equal(customerOptionIndex(0, 'ArrowUp', 3), 2);
  assert.equal(customerOptionIndex(2, 'ArrowDown', 3), 0);
  assert.equal(customerOptionIndex(0, 'ArrowDown', 0), -1);
  assert.equal(customerPhoneDisplay('01012345678'), '010-1234-5678');
  assert.equal(customerPhoneDisplay('1234'), '1234');
});
test('camera Enter gives way only after explicit customer keyboard navigation, not stale queries', () => {
  assert.equal(customerKeyboardOwnsEnter('Enter', '김자동', 'name', '김자동', true), true);
  assert.equal(customerKeyboardOwnsEnter('Enter', '김자동', 'name', null, true), false);
  assert.equal(customerKeyboardOwnsEnter('Enter', '다른고객', 'name', '김자동', true), false);
  assert.equal(customerKeyboardOwnsEnter('Enter', '123-4', 'phone', '1234', true), true);
  assert.equal(customerKeyboardOwnsEnter('Enter', '12345', 'phone', '1234', true), false);
  assert.equal(customerKeyboardOwnsEnter('Enter', '김자동', 'name', '김자동', false), false);
});
