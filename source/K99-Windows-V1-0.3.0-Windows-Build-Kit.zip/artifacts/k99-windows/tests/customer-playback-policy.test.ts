import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import { customerMediaReducer, INITIAL_CUSTOMER_MEDIA, releaseCustomerGuide } from '../src/customer-media';

const source = readFileSync(new URL('../src/CustomerMedia.tsx', import.meta.url), 'utf8');
const tree = ts.createSourceFile('CustomerMedia.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const videos = new Map<string, ts.JsxAttributes>();
function visit(node: ts.Node) {
  if ((ts.isJsxSelfClosingElement(node) || ts.isJsxOpeningElement(node)) && node.tagName.getText(tree) === 'video') {
    const id = node.attributes.properties.find(prop =>
      ts.isJsxAttribute(prop) && prop.name.getText(tree) === 'data-testid');
    if (id && ts.isJsxAttribute(id) && id.initializer && ts.isStringLiteral(id.initializer))
      videos.set(id.initializer.text, node.attributes);
  }
  ts.forEachChild(node, visit);
}
visit(tree);
function attr(id: string, name: string) {
  const attrs = videos.get(id);
  assert.ok(attrs, `Missing video: ${id}`);
  return attrs.properties.find(prop => ts.isJsxAttribute(prop) && prop.name.getText(tree) === name);
}
test('idle promo alone loops; guide has explicit end handler and independent player identity', () => {
  assert.ok(attr('customer-promo-video', 'loop'));
  assert.equal(attr('customer-promo-video', 'onEnded'), undefined);
  for (const name of ['autoPlay', 'muted', 'playsInline']) assert.ok(attr('customer-promo-video', name));
  assert.equal(attr('customer-media-video', 'loop')!.getText(tree), 'loop={false}');
  assert.match(attr('customer-media-video', 'onEnded')!.getText(tree), /handleVideoFinish\(event.currentTarget\)/);
  assert.notEqual(attr('customer-promo-video', 'key')!.getText(tree),
    attr('customer-media-video', 'key')!.getText(tree));
  assert.match(source, /player\.loop = false/);
  assert.match(source, /player\.removeAttribute\('loop'\)/);
  assert.match(source, /onClick=\{\(\) => handleVideoFinish\(videoRef\.current\)\}/);
  assert.match(source, /state.viewMode === 'IDLE' && !promoFailed/);
  assert.doesNotMatch(source, /returnToPromo/);
});
test('all four manual guides end once and the same stale command cannot restart playback', () => {
  for (const video of ['process', 'value', 'water', 'sneakers'] as const) {
    const command = { id: `guide-${video}`, video };
    const playing = customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'manual', command });
    assert.equal(playing.activeGuideVideo, video);
    assert.equal(playing.viewMode, 'GUIDE_VIDEO');
    const ended = customerMediaReducer(playing, { type: 'ended' });
    assert.equal(ended.viewMode, 'RECEIPT');
    assert.equal(ended.activeGuideVideo, null);
    assert.deepEqual(customerMediaReducer(ended, { type: 'manual', command }), ended);
    assert.equal(customerMediaReducer(ended, {
      type: 'manual', command: { id: `${command.id}-again`, video },
    }).activeGuideVideo, video);
    assert.equal(customerMediaReducer(ended, { type: 'receipt' }).viewMode, 'RECEIPT');
    assert.equal(customerMediaReducer(playing, { type: 'playback-failed' }).viewMode, 'RECEIPT');
  }
});
test('guide disposal stops decoding and clears source, while receipt snapshots do not interrupt a guide', () => {
  const calls: string[] = [];
  releaseCustomerGuide({
    pause: () => { calls.push('pause'); },
    removeAttribute: name => { calls.push(`remove:${name}`); },
    load: () => { calls.push('load'); },
  });
  assert.deepEqual(calls, ['pause', 'remove:src', 'load']);
  const guide = customerMediaReducer(INITIAL_CUSTOMER_MEDIA, {
    type: 'manual', command: { id: 'test', video: 'value' },
  });
  assert.deepEqual(customerMediaReducer(guide, { type: 'receipt' }), guide);
  assert.equal(customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'receipt' }).viewMode, 'RECEIPT');
});
