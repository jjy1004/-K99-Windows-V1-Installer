import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import { customerMediaReducer, INITIAL_CUSTOMER_MEDIA, releaseCustomerGuide, isMediaCommand } from '../src/customer-media';

const source = readFileSync(new URL('../src/CustomerMedia.tsx', import.meta.url), 'utf8');
const tree = ts.createSourceFile('CustomerMedia.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const videos = new Map<string, ts.JsxAttributes>();
function visit(node: ts.Node) {
  if ((ts.isJsxSelfClosingElement(node) || ts.isJsxOpeningElement(node)) && node.tagName.getText(tree) === 'video') {
    const id = node.attributes.properties.find(prop =>
      ts.isJsxAttribute(prop) && prop.name.getText(tree) === 'data-testid');
    if (id && ts.isJsxAttribute(id) && id.initializer && ts.isStringLiteral(id.initializer))
      videos.set(id.initializer.text, node.attributes);
  }
  ts.forEachChild(node, visit);
}
visit(tree);
function attr(id: string, name: string) {
  const attrs = videos.get(id);
  assert.ok(attrs, `Missing video: ${id}`);
  return attrs.properties.find(prop => ts.isJsxAttribute(prop) && prop.name.getText(tree) === name);
}
test('idle promo alone loops; guide has explicit end handler and independent player identity', () => {
  assert.ok(attr('customer-promo-video', 'loop'));
  assert.equal(attr('customer-promo-video', 'onEnded'), undefined);
  for (const name of ['autoPlay', 'muted', 'playsInline']) assert.ok(attr('customer-promo-video', name));
  assert.equal(attr('customer-media-video', 'loop')!.getText(tree), 'loop={false}');
  assert.match(attr('customer-media-video', 'onEnded')!.getText(tree), /handleVideoFinish\(event.currentTarget\)/);
  assert.notEqual(attr('customer-promo-video', 'key')!.getText(tree),
    attr('customer-media-video', 'key')!.getText(tree));
  assert.match(source, /player\.loop = false/);
  assert.match(source, /player\.removeAttribute\('loop'\)/);
  assert.match(source, /onClick=\{\(\) => handleVideoFinish\(videoRef\.current\)\}/);
  assert.match(source, /state.viewMode === 'IDLE'/);
  assert.doesNotMatch(source, /customerVideoPath\('value'/);
  assert.doesNotMatch(source, /returnToPromo/);
});
test('all four manual guides end once and the same stale command cannot restart playback', () => {
  for (const video of ['process', 'value', 'water', 'sneakers'] as const) {
    const command = { id: `guide-${video}`, video };
    const playing = customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'manual', command });
    assert.equal(playing.activeGuideVideo, video);
    assert.equal(playing.viewMode, 'GUIDE_VIDEO');
    const ended = customerMediaReducer(playing, { type: 'ended' });
    assert.equal(ended.viewMode, 'RECEIPT');
    assert.equal(ended.activeGuideVideo, null);
    assert.deepEqual(customerMediaReducer(ended, { type: 'manual', command }), ended);
    assert.equal(customerMediaReducer(ended, {
      type: 'manual', command: { id: `${command.id}-again`, video },
    }).activeGuideVideo, video);
    assert.equal(customerMediaReducer(ended, { type: 'receipt' }).viewMode, 'RECEIPT');
    assert.deepEqual(customerMediaReducer(playing, { type: 'playback-failed' }), playing);
  }
});
test('guide disposal stops decoding and clears source, while receipt snapshots do not interrupt a guide', () => {
  const calls: string[] = [];
  releaseCustomerGuide({
    pause: () => { calls.push('pause'); },
    removeAttribute: name => { calls.push(`remove:${name}`); },
    load: () => { calls.push('load'); },
  });
  assert.deepEqual(calls, ['pause', 'remove:src', 'load']);
  const guide = customerMediaReducer(INITIAL_CUSTOMER_MEDIA, {
    type: 'manual', command: { id: 'test', video: 'value' },
  });
  assert.deepEqual(customerMediaReducer(guide, { type: 'receipt' }), guide);
  assert.equal(customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'receipt' }).viewMode, 'IDLE');
});
test('explicit idle command exits any mode, survives snapshots and late ended; guide can reopen receipt', () => {
  for (const mode of ['IDLE', 'GUIDE_VIDEO', 'RECEIPT'] as const) {
    const state = { ...INITIAL_CUSTOMER_MEDIA, viewMode: mode, activeGuideVideo: mode === 'GUIDE_VIDEO' ? 'value' as const : null };
    const idle = customerMediaReducer(state, { type: 'manual', command: { id: 'idle-now', video: 'idle' } });
    assert.equal(idle.viewMode, 'IDLE');
    assert.equal(idle.activeGuideVideo, null);
    assert.equal(idle.idleRequested, true);
    assert.deepEqual(customerMediaReducer(idle, { type: 'receipt' }), idle);
    assert.deepEqual(customerMediaReducer(idle, { type: 'ended' }), idle);
    assert.equal(customerMediaReducer(idle, { type: 'intake-input' }).viewMode, 'RECEIPT');
    const guide = customerMediaReducer(idle, { type: 'manual', command: { id: 'next-guide', video: 'process' } });
    assert.equal(guide.viewMode, 'GUIDE_VIDEO');
    assert.equal(customerMediaReducer(guide, { type: 'ended' }).viewMode, 'RECEIPT');
  }
  assert.equal(isMediaCommand({ id: 'idle', video: 'idle', issuedAt: Date.now() }), true);
  assert.equal(isMediaCommand({ id: 'invalid', video: 'promo/../../bad' }), false);
});
test('initial snapshots never leave idle; live input leaves idle but never interrupts a manual guide', () => {
  assert.equal(INITIAL_CUSTOMER_MEDIA.viewMode, 'IDLE');
  assert.equal(INITIAL_CUSTOMER_MEDIA.activeGuideVideo, null);
  assert.deepEqual(customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'receipt' }), INITIAL_CUSTOMER_MEDIA);
  const receipt = customerMediaReducer(INITIAL_CUSTOMER_MEDIA, { type: 'intake-input' });
  assert.equal(receipt.viewMode, 'RECEIPT');
  const guide = customerMediaReducer(receipt, { type: 'manual', command: { id: 'value-once', video: 'value' } });
  assert.deepEqual(customerMediaReducer(guide, { type: 'intake-input' }), guide);
  assert.equal(customerMediaReducer(guide, { type: 'ended' }).viewMode, 'RECEIPT');
  assert.match(source, /useReducer\(customerMediaReducer, INITIAL_CUSTOMER_MEDIA\)/);
  assert.doesNotMatch(source, /receiptRevision|idle \? 'IDLE'/);
});
