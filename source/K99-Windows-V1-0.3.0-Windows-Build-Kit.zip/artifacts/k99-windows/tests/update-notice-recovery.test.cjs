'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createUpdateNotice}=require('../electron/update-notice.cjs');
function fixture({load=()=>Promise.resolve(),paint=()=>Promise.resolve()}={}){
  const windows=[],dialogs=[],timers=[];
  class Window extends EventEmitter{
    constructor(){super();windows.push(this);this.webContents=new EventEmitter();
      this.webContents.setWindowOpenHandler=()=>{};this.webContents.executeJavaScript=paint;}
    center(){}showInactive(){}isDestroyed(){return !!this.dead;}
    destroy(){this.dead=true;this.emit('closed');}loadURL(){return load();}
  }
  const n=createUpdateNotice({BrowserWindow:Window,warn:()=>{},
    dialog:{showMessageBox:(...args)=>{dialogs.push(args);return new Promise(()=>{});}},
    later:(fn,ms)=>{const t={fn,ms,cleared:false};timers.push(t);return t;},
    cancel:t=>{if(t)t.cleared=true;}});
  n.show({phase:'downloading',percent:10});
  return {n,windows,dialogs,timers};
}
for(const kind of ['load-rejection','did-fail-load','render-process-gone','unresponsive','load-timeout','paint-rejection','paint-timeout']){
  test(`native nonblocking fallback: ${kind}`,async()=>{
    const f=fixture({load:kind==='load-rejection'?()=>Promise.reject(Error('실패')):undefined,
      paint:kind==='paint-rejection'?()=>Promise.reject(Error('실패')):kind==='paint-timeout'?()=>new Promise(()=>{}):undefined});
    const w=f.windows[0];
    if(kind==='did-fail-load')w.webContents.emit(kind,{},-105,'','',true);
    if(kind==='render-process-gone')w.webContents.emit(kind,{});
    if(kind==='unresponsive')w.emit(kind);
    if(kind==='load-timeout')f.timers.find(t=>t.ms===4000).fn();
    if(kind.startsWith('paint-'))w.webContents.emit('did-finish-load');
    if(kind==='paint-timeout')f.timers.find(t=>t.ms===2000).fn();
    await new Promise(r=>setImmediate(r));
    assert.equal(f.dialogs.length,1); assert.equal(f.dialogs[0].length,1,'no modal POS parent argument');
    assert.deepEqual(f.dialogs[0][0].buttons,['확인']); assert.equal(w.dead,true);
    // The native dialog promise is intentionally unresolved: progress and
    // capture remain callable; no duplicate windows/dialogs.
    for(let percent=15;percent<=90;percent+=5)f.n.show({phase:'downloading',percent});
    assert.equal(f.windows.length,1); assert.equal(f.dialogs.length,1);
    f.n.dispose(); assert.ok(f.timers.every(t=>t.cleared));
  });
}
test('closing normally cancels watchdogs and must not create a false failure dialog',()=>{
  const f=fixture();f.n.close();
  f.timers.forEach(t=>t.fn());assert.equal(f.dialogs.length,0);
});
