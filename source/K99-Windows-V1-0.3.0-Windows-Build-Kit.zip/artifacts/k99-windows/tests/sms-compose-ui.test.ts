import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import fs from 'node:fs';
import {SmsModeSettings,KDE_SMS_WARNING} from '../src/SmsModeSettings';
const read = (name: string) => fs.readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
test('문자 방식 선택은 MS·KDE 두 개 라디오만 제공하고 기존 중간 문자는 제거한다', () => {
  const html=renderToStaticMarkup(createElement(SmsModeSettings));
  assert.equal((html.match(/role="radio"/g)||[]).length,2);
  assert.match(html,/>MS</);assert.match(html,/>KDE</);
  assert.doesNotMatch(html,/connect|QR|발송 완료 확인/i);
  assert.equal(KDE_SMS_WARNING,"⚠️ 주의: [휴대폰으로 문자 보내기]를 누르면 중간 확인 창 없이 고객에게 문자가 즉시 발송됩니다. 위의 '보낼 글' 내용과 금액을 먼저 확인한 후 눌러 주세요.");
  const source=read('LocalNoticeDialogs.tsx');
  assert.match(source,/smsMode\.mode==='KDE'&&<p[^>]*>\{KDE_SMS_WARNING\}/);
  assert.match(source,/접수 사진 보내기/);assert.match(source,/사진 파일 선택/);
});
test('문자·카카오톡은 중간 팝업 없이 최신 원문 전체와 클릭 기준 기록을 전달한다', () => {
  const source = read('LocalNoticeDialogs.tsx');
  assert.match(source, /savedLocalNotice\(orderId, fullBody, templateId, prepared\)/);
  assert.match(source, /action:kind==='sms'\?'sms-compose':'kakao-compose'/);
  assert.match(source, /body:fullBody,recipient:phone/);
  assert.match(source, /kind==='sms'\?'full-clipboard':'kakao-clipboard'/);
  assert.doesNotMatch(source, /FastSmsQr|SmsQrContents|summarizeSmsBody|sms-qr/);
  const actions=source.slice(source.indexOf('export function AccountlessNoticeActions'),source.indexOf('const won'));
  assert.doesNotMatch(actions, /<NoticeDialog|SmsComposeContents|setSms|setKakao|setChoosing|onConfirm=/);
  assert.match(actions,/confirmLocalDelivery\(attemptId,'button-click'\)/);
  assert.match(actions,/busyRef\.current = true/);
  assert.match(actions,/result\.copied!==true/);
  assert(actions.indexOf("confirmLocalDelivery(attemptId,'button-click')")<actions.indexOf('const result=await native'));
});
test('불필요한 문자·카톡 연결 설정과 안내는 제거하고 촬영 USB 안내는 유지한다', () => {
  const source = read('NoticeCenter.tsx');
  assert.doesNotMatch(source,/ConnectHelperBody|휴대폰과 연결 바로 열기|기존 개인 Microsoft 계정|button-phone-message|문자 · 카톡 휴대폰/);
  assert.doesNotMatch(source,/phone-message|QrCanvas|휴대폰으로 글 입력하기|\/mobile\/start/);
  const camera = source.slice(source.indexOf('function CameraPhoneBody'), source.indexOf('const DISCOUNT_FIELDS'));
  assert.match(camera, /<IriunUsbGuide \/>/); assert.match(camera, /USB 표준 7단계/);
});
