import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import fs from 'node:fs';
import { SmsComposeContents } from '../src/SmsComposeContents';
const read = (name: string) => fs.readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
test('문자 화면은 QR·54자 요약 없이 편집 가능한 전체 원문과 입력·실제 발송 확인만 제공한다', () => {
  const body = '수정한 고객 안내 원문\n금액 12,300원 & 확인해 주세요.';
  const html = renderToStaticMarkup(createElement(SmsComposeContents, {
    recipient: '01000000001', body, onChange() {}, onInput() {}, onConfirm() {},
    copied: true, canConfirm: false, confirmed: false, busy: false,
  }));
  assert.match(html, /sms-compose-body/); assert.match(html, /수정한 고객 안내 원문/);
  assert.match(html, /12,300원 &amp;/); assert.match(html, />입력</);
  assert.doesNotMatch(html, /readonly|QR|54자|요약|<svg[^>]*qrcode/);
  assert.match(html, /문자 앱에서 발송 완료 확인/); assert.match(html, /Ctrl\+V/);
});
test('문자 수정은 이전 준비·완료 상태를 무효화하고 수정 원문 자체를 저장·전달한다', () => {
  const source = read('LocalNoticeDialogs.tsx');
  assert.match(source, /body:value,copied:false,confirmed:false,attemptId:undefined/);
  assert.match(source, /savedLocalNotice\(orderId, sms\.body, templateId\)/);
  assert.match(source, /action:'sms-compose',recipient:sms\.recipient,body:sms\.body/);
  assert.match(source, /prepareLocalDelivery\(notice, sms\.recipient, 'full-clipboard', sms\.body\)/);
  assert.doesNotMatch(source, /FastSmsQr|SmsQrContents|summarizeSmsBody|sms-qr/);
  const input = source.slice(source.indexOf('const inputSms'), source.indexOf('const confirmSms'));
  assert.doesNotMatch(input, /confirmLocalDelivery/);
  assert.match(input, /result\.copied !== true/);
});
test('문자·카톡 휴대폰 안내만 3단계로 정리하고 촬영 USB 안내는 그대로 유지한다', () => {
  const source = read('NoticeCenter.tsx');
  const helper = source.slice(source.indexOf('function ConnectHelperBody'), source.indexOf('function CameraPhoneBody'));
  assert.equal((helper.match(/<li>/g) || []).length, 3);
  for (const text of ['기존 개인 Microsoft 계정', 'QR코드', '케이블 없이', '실제 화면', '휴대폰과 연결 바로 열기']) assert(helper.includes(text));
  assert.doesNotMatch(helper, /ADB|개발자 옵션|4자리/);
  const camera = source.slice(source.indexOf('function CameraPhoneBody'), source.indexOf('const DISCOUNT_FIELDS'));
  assert.match(camera, /<IriunUsbGuide \/>/); assert.match(camera, /USB 표준 7단계/);
});
