import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import fs from 'node:fs';
import { SmsComposeContents } from '../src/SmsComposeContents';
const read = (name: string) => fs.readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
test('문자 화면은 QR·54자 요약 없이 편집 가능한 전체 원문과 입력·실제 발송 확인만 제공한다', () => {
  const body = '수정한 고객 안내 원문\n금액 12,300원 & 확인해 주세요.';
  const html = renderToStaticMarkup(createElement(SmsComposeContents, {
    recipient: '01000000001', body, onChange() {}, onInput() {}, onConfirm() {},
    copied: true, canConfirm: false, confirmed: false, busy: false,
  }));
  assert.match(html, /sms-compose-body/); assert.match(html, /수정한 고객 안내 원문/);
  assert.match(html, /12,300원 &amp;/); assert.match(html, />입력</);
  assert.doesNotMatch(html, /readonly|QR|54자|요약|<svg[^>]*qrcode/);
  assert.match(html, /문자 앱에서 발송 완료 확인/); assert.match(html, /Ctrl\+V/);
});
test('문자·카카오톡은 중간 팝업 없이 최신 원문 전체와 클릭 기준 기록을 전달한다', () => {
  const source = read('LocalNoticeDialogs.tsx');
  assert.match(source, /savedLocalNotice\(orderId, fullBody, templateId, prepared\)/);
  assert.match(source, /action:kind==='sms'\?'sms-compose':'kakao-compose'/);
  assert.match(source, /body:fullBody,recipient:phone/);
  assert.match(source, /kind==='sms'\?'full-clipboard':'kakao-clipboard'/);
  assert.doesNotMatch(source, /FastSmsQr|SmsQrContents|summarizeSmsBody|sms-qr/);
  const actions=source.slice(source.indexOf('export function AccountlessNoticeActions'),source.indexOf('const won'));
  assert.doesNotMatch(actions, /<NoticeDialog|SmsComposeContents|setSms|setKakao|setChoosing|onConfirm=/);
  assert.match(actions,/confirmLocalDelivery\(attemptId,'button-click'\)/);
  assert.match(actions,/busyRef\.current = true/);
  assert.match(actions,/result\.copied!==true/);
  assert(actions.indexOf("confirmLocalDelivery(attemptId,'button-click')")<actions.indexOf('const result=await native'));
});
test('불필요한 문자·카톡 연결 설정과 안내는 제거하고 촬영 USB 안내는 유지한다', () => {
  const source = read('NoticeCenter.tsx');
  assert.doesNotMatch(source,/ConnectHelperBody|휴대폰과 연결 바로 열기|기존 개인 Microsoft 계정|button-phone-message|문자 · 카톡 휴대폰/);
  assert.match(source,/initialView==='phone-message'\?'home':initialView/);
  const camera = source.slice(source.indexOf('function CameraPhoneBody'), source.indexOf('const DISCOUNT_FIELDS'));
  assert.match(camera, /<IriunUsbGuide \/>/); assert.match(camera, /USB 표준 7단계/);
});
