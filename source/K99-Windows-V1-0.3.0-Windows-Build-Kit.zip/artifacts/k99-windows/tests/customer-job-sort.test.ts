import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {createConfirmedOrder} from '../src/order-record';
import {listGarments} from '../src/garment-scanner';
import {reviseInspectionPayment} from '../src/inspection-payment';
import {customerJobTimestamp, isUnpaidCustomerJob, manualJobTags, sortCustomerJobs} from '../src/customer-job-sort';
import {CustomerJobSortControls} from '../src/CustomerJobSortControls';

function order(id:string,name:string,date:string){
  const base=createConfirmedOrder({id,customerName:name,customerPhone:'01000000000',customerAddress:'',
    items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
    {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,
      requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''},new Date(date));
  return {...base,garments:listGarments(base)};
}
test('검수 날짜순 기본은 접수 최신순이며 원본 배열·주문을 변경하지 않는다',()=>{
  const a=order('a','강가람','2026-11-01T01:00:00Z');
  const b=order('b','하도윤','2026-11-03T01:00:00Z');
  const c=order('c','나하늘','2026-11-02T01:00:00Z');
  const input=Object.freeze([a,b,c]),before=JSON.stringify(input);
  assert.deepEqual(sortCustomerJobs(input).map(x=>x.id),['b','c','a']);
  assert.equal(JSON.stringify(input),before);
});
test('이름순은 가나다순이며 같은 이름은 최신순, 동일 일시는 주문번호로 확정한다',()=>{
  const input=[order('3','홍길동','2026-11-01Z'),order('2','강가람','2026-11-02Z'),
    order('1','강가람','2026-11-02Z'),order('4','강가람','2026-11-03Z')];
  assert.deepEqual(sortCustomerJobs(input,'name').map(x=>x.id),['4','1','2','3']);
});
test('출고 날짜순은 실제 의류 완료일을 사용하고 나중 결제 수정 시각에 흔들리지 않는다',()=>{
  const a=order('a','강가람','2026-11-01Z'),b=order('b','하도윤','2026-11-02Z');
  a.garments![0].completedAt='2026-11-03T03:00:00Z';
  b.garments![0].completedAt='2026-11-04T03:00:00Z';
  a.operations={stage:'세탁완료',updatedAt:'2026-11-20T03:00:00Z'} as NonNullable<typeof a.operations>;
  assert.deepEqual(sortCustomerJobs([a,b],'date','release').map(x=>x.id),['b','a']);
});
test('과거 주문의 완료일 누락·잘못된 날짜에도 안정적으로 정렬된다',()=>{
  const a=order('a','강가람','2026-11-01Z'),b=order('b','나하늘','2026-11-02Z');
  a.operations={stage:'세탁완료',updatedAt:'2026-11-10T01:00:00Z'} as NonNullable<typeof a.operations>;
  assert.equal(customerJobTimestamp(a,'release'),Date.parse('2026-11-10T01:00:00Z'));
  b.intakeAt='날짜 없음';
  assert.deepEqual(sortCustomerJobs([b,a],'date','release').map(x=>x.id),['a','b']);
});
test('수기 태그만 표시하고 프린터 태그·빈 번호는 표시하지 않는다',()=>{
  const a=order('a','강가람','2026-11-01Z'),g=a.garments![0];
  a.garments=[{...g,tagMode:'roll',tagNumber:'1-12'},{...g,tagMode:'roll',tagNumber:'1-12'},
    {...g,tagMode:'printer',tagNumber:'프린터 번호'},{...g,tagMode:'none'},{...g,tagMode:'roll',tagNumber:'1-13'}];
  assert.deepEqual(manualJobTags(a),['1-12','1-13']);
});
test('정렬 도구는 이름순·날짜순을 제공하고 선택 상태를 보조기술에 알린다',()=>{
  for(const value of ['date','name'] as const){
    const html=renderToStaticMarkup(createElement(CustomerJobSortControls,{value,onChange:()=>{}}));
    assert.match(html,/고객 카드 정렬/);
    assert.match(html,/이름순/);assert.match(html,/날짜순/);
    assert.equal((html.match(/aria-pressed="true"/g)||[]).length,1);
    assert.match(html,new RegExp(`aria-pressed="true" data-testid="job-sort-${value}"`));
  }
});
test('미결제 후불만 경고하고 선불 전환 시 즉시 해제하며 실제 결제 완료 기록을 보존한다',()=>{
  const a=order('a','강가람','2026-11-01Z');
  const deferred=reviseInspectionPayment(a,'POSTPAID');
  assert.equal(isUnpaidCustomerJob(a),false);
  assert.equal(isUnpaidCustomerJob(deferred),true);
  assert.equal(isUnpaidCustomerJob(reviseInspectionPayment(deferred,'PREPAID')),false);
  assert.equal(isUnpaidCustomerJob({...deferred,payment_status:'PAID'}),false);
  const paid={...deferred,operations:{stage:'접수',paymentStatus:'결제완료',paidAmount:5000,updatedAt:a.intakeAt}} as typeof a;
  assert.equal(isUnpaidCustomerJob(paid),false);
  assert.equal(isUnpaidCustomerJob(reviseInspectionPayment(paid,'POSTPAID')),false);
});
test('구버전 choices의 후불과 결제상태 누락도 안전하게 해석한다',()=>{
  const a=order('a','강가람','2026-11-01Z');
  const legacy={...a,payment_type:undefined,payment_status:undefined,choices:{...a.choices,paymentType:'POSTPAID' as const}};
  assert.equal(isUnpaidCustomerJob(legacy),true);
});
