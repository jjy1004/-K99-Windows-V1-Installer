'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const css = fs.readFileSync(path.join(__dirname, '../src/program-launchers.css'), 'utf8');
const header = fs.readFileSync(path.join(__dirname, '../src/intake-blueprint.css'), 'utf8');

test('three program launchers stay in one equal-width grid without a diary second row', () => {
  assert.match(css, /\.pgl-grid\s*\{[^}]*grid-template-columns:\s*repeat\(3,\s*minmax\(0,\s*1fr\)\)/);
  assert.doesNotMatch(css, /\.pgl-diary\s*\{[^}]*grid-column/);
  assert.equal((css.match(/grid-template-columns:/g) || []).length, 1);
});

test('launcher titles remain complete on one line and buttons share a common height', () => {
  assert.match(css, /\.pgl-txt\s*\{[^}]*white-space:\s*nowrap/);
  assert.match(css, /\.pgl-btn\s*\{[^}]*flex-direction:\s*column/);
  assert.match(css, /\.pgl-btn\s*\{[^}]*min-height:\s*76px/);
});

test('the intake header reserves an entire row for the three program launchers', () => {
  assert.match(header, /\.k99-bp-top \.pgl-wrap\s*\{[^}]*order:2;flex:1 1 100%;min-width:0;/);
  assert.match(header, /\.k99-bp-top \.staff-heading\s*\{[^}]*order:1;/);
});
