'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createLegacyObsCleanup,ownedCommand,SHORTCUT,VALUES}=require('../electron/legacy-obs-cleanup.cjs');
const command='"C:\\Program Files\\obs-studio\\bin\\64bit\\obs64.exe" --startvirtualcam --minimize-to-tray';
test('only reserved K99 name AND direct OBS command qualify; personal entries, wrappers and malformed values survive',()=>{
  assert.equal(ownedCommand(VALUES[0],command),true);
  for(const [name,value] of [['OBS Studio',command],['My OBS',command],['K99 personal OBS',command],
    [VALUES[0],'"C:\\Windows\\cmd.exe" /c obs64.exe --startvirtualcam'],
    [VALUES[0],'"C:\\Program Files\\obs-studio\\bin\\64bit\\obs64.exe"'],
    [VALUES[0],command+'\nanything']])assert.equal(ownedCommand(name,value),false);
});
test('non-Windows skips everything, and policy/timeouts never reject startup',async()=>{
  let calls=0;
  const options={execute:async()=>{calls++;throw Error('방화벽/백신 차단');},stat:async()=>{throw Error('없음');}};
  assert.deepEqual(await createLegacyObsCleanup({...options,platform:'linux'})(),{shortcutsRemoved:0,registryRemoved:0,skipped:0});
  assert.equal(calls,0);
  const result=await createLegacyObsCleanup({...options,platform:'win32',env:{}})();
  assert.equal(result.registryRemoved,0); assert.equal(result.shortcutsRemoved,0);
});
test('cleanup never launches OBS or deletes generic entries; shortcut target and file identity must match',async()=>{
  const commands=[],removed=[];
  const result=await createLegacyObsCleanup({platform:'win32',env:{APPDATA:'C:\\Users\\shop\\AppData\\Roaming'},
    stat:async()=>({isFile:()=>true,isSymbolicLink:()=>false,size:200,mtimeMs:11}),
    unlink:async file=>removed.push(file),
    execute:async(file,args)=>{
      commands.push({file,args});
      if(/powershell\.exe$/i.test(file))return JSON.stringify({target:'C:\\Program Files\\obs-studio\\bin\\64bit\\obs64.exe',arguments:'--startvirtualcam --minimize-to-tray'});
      if(args[0]==='query')return `  ${args[3]}    REG_SZ    ${command}\r\n`;
      return '';
    }})();
  assert.equal(result.registryRemoved,8); assert.equal(result.shortcutsRemoved,1);
  assert.ok(removed[0].endsWith('\\'+SHORTCUT));
  assert.ok(commands.every(x=>/\\(?:reg|powershell)\.exe$/i.test(x.file)));
  assert.ok(commands.filter(x=>x.args[0]==='delete').every(x=>VALUES.includes(x.args[3])));
});
test('replaced registry command and unrelated shortcut are never removed',async()=>{
  let queries=0,deleted=0;
  await createLegacyObsCleanup({platform:'win32',env:{APPDATA:'C:\\Users\\shop'},
    stat:async()=>({isFile:()=>true,isSymbolicLink:()=>false,size:200,mtimeMs:11}),
    unlink:async()=>{deleted++;},
    execute:async(file,args)=>{
      if(/powershell/.test(file))return JSON.stringify({target:'C:\\Personal\\camera.exe',arguments:''});
      if(args[0]==='delete'){deleted++;return '';}
      return ' REG_SZ '+(++queries%2?command:'C:\\Personal\\app.exe');
    }})();
  assert.equal(deleted,0);
});
