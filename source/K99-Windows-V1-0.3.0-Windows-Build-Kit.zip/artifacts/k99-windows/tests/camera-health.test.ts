import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {cameraHealth,checkCameraEnvironment} from '../src/camera-health';
import {renderToStaticMarkup} from 'react-dom/server';
import {createElement} from 'react';
import {CameraConnectionBadge,CameraSetupGuide} from '../src/CameraSetupGuide';

test('permission notice is deduplicated, settings failures are friendly, return from settings clears denial',async()=>{
  const original=globalThis.window;
  let state='denied',reject=false,calls=0;
  Object.assign(globalThis,{window:{k99Desktop:{cameraCheck:async(input:{action:string})=>{
    calls++;
    if(input.action==='open-settings'){if(reject)throw Error('Windows 설정 차단');return {opened:true};}
    return {checkedAt:Date.now(),permission:{state,blocked:[],checked:1},network:{state:'offline',note:'USB는 계속 연결'}};
  }}}});
  try{
    await checkCameraEnvironment();assert.equal(cameraHealth.state().dialogOpen,true);
    cameraHealth.close();await checkCameraEnvironment();assert.equal(cameraHealth.state().dialogOpen,false);
    reject=true;await cameraHealth.settings();assert.match(cameraHealth.state().error,/설정 차단/);
    assert.equal(cameraHealth.state().opening,false);
    state='not-denied';await checkCameraEnvironment();
    state='denied';await checkCameraEnvironment();assert.equal(cameraHealth.state().dialogOpen,true);
    state='not-denied';await checkCameraEnvironment();assert.equal(cameraHealth.state().dialogOpen,false);
    assert(calls>=6);
  }finally{Object.assign(globalThis,{window:original});}
});
test('offline or failed diagnostics never throw and never indicate permission denied',async()=>{
  const original=globalThis.window;
  Object.assign(globalThis,{window:{k99Desktop:{cameraCheck:async()=>{throw Error('읽기 거절');}}}});
  try{await checkCameraEnvironment();assert.equal(cameraHealth.state().report,null);}
  finally{Object.assign(globalThis,{window:original});}
});
test('status badge distinguishes actual live video, missing signal and mock preview',()=>{
  const good=renderToStaticMarkup(createElement(CameraConnectionBadge,{connected:true}));
  const bad=renderToStaticMarkup(createElement(CameraConnectionBadge,{connected:false,connecting:true}));
  const mock=renderToStaticMarkup(createElement(CameraConnectionBadge,{connected:true,mock:true}));
  assert.match(good,/카메라 정상 연결됨/);assert.match(bad,/휴대폰 Iriun 앱 확인 필요/);
  assert.match(mock,/실제 연결 아님/);assert.doesNotMatch(mock,/카메라 정상 연결됨/);
});
test('both capture surfaces expose the guide without changing the camera manager',()=>{
  for(const name of ['NativeDraftCamera','EquipmentWorkspace']){
    const text=readFileSync(new URL(`../src/${name}.tsx`,import.meta.url),'utf8');
    assert.match(text,/<CameraCareControls/);assert.match(text,/connected=\{realMode&&/);
  }
  const hook=readFileSync(new URL('../src/use-iriun-camera.ts',import.meta.url),'utf8');
  assert.match(hook,/if\(active\)void checkCameraEnvironment\(\)/);
  const controls=readFileSync(new URL('../src/CameraCareControls.tsx',import.meta.url),'utf8');
  assert.match(controls,/촬영 준비 그림 안내 \(딱 1번만\)/);
  assert.match(controls,/permission\.state==='denied'/);
  assert.match(controls,/onClick=\{\(\)=>\{cameraHealth\.show\(\);void cameraHealth\.settings\(\);\}\}>카메라 권한 켜기/);
  const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
  assert.match(app,/<CameraHealthNotice\/>/);
});
test('setup guide uses the USB seven-step shared guide, a large confirmation and no connection guarantee',()=>{
  const source=readFileSync(new URL('../src/CameraSetupGuide.tsx',import.meta.url),'utf8');
  assert.match(source,/USB 표준 7단계/);
  assert.match(source,/<IriunUsbGuide slides/);
  assert.match(source,/확인 \(닫기\)/);
  assert.match(source,/종일 연결이 보장되지는 않습니다/);
  assert.doesNotMatch(source,/ArtWifi|영업 내내 끊기지 않습니다/);
  assert.equal(renderToStaticMarkup(createElement(CameraSetupGuide,{open:false,onClose:()=>{}})),'');
});
