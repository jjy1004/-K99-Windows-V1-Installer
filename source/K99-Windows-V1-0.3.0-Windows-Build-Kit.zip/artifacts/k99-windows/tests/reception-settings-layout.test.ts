import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=(name:string)=>fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
test('reception has one final-confirm location and groups customer window controls under idle',()=>{
  const app=source('App.tsx'),sidebar=source('ReceptionSidebar.tsx');
  assert.doesNotMatch(app,/button-confirm-combined-order|button-confirm-initial-estimate|button-reconnect-customer-display|button-configure-customer-monitor/);
  assert.equal((app.match(/data-testid="button-open-customer-display"/g)||[]).length,1);
  assert(app.indexOf('data-testid="button-open-customer-display"')>app.indexOf('data-testid="button-customer-idle"'));
  assert.match(sidebar,/onClick=\{onFinalConfirm\}/);
  assert.match(sidebar,/PhotoStorageHint/);
  assert.doesNotMatch(source('SimpleStatisticsCenter.tsx'),/StorageLayoutSettings/);
});
test('hardware settings remain reachable if profile load fails and move tag selection out of reception',()=>{
  const notice=source('NoticeCenter.tsx'),camera=source('NativeDraftCamera.tsx'),controls=source('V2TagControls.tsx');
  assert.match(notice,/<HardwareSettings\s*\/>/);
  assert.match(camera,/<V2TagControls numberOnly/);
  assert.match(controls,/if\(numberOnly&&!roll\)return null/);
  const hw=source('HardwareSettings.tsx');
  for(const text of ['라벨 프린터 선택','영수증 프린터 선택','카메라 선택','Windows 디스플레이 설정 열기','하드웨어 설정 저장'])assert(hw.includes(text),text);
  assert.match(hw,/k99-hardware-settings-changed/);
  assert.match(source('intake-compact.css'),/font-size:19px;font-weight:800;min-height:52px/);
});
