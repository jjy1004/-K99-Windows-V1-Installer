import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {storeDiscount,DiscountNotice,StoreBenefits} from '../src/StoreDiscount';
import {createConfirmedOrder,type FinalIntakeChoices} from '../src/order-record';
import type {StoreProfile} from '../src/notice-api';
import fs from 'node:fs';

const profile:StoreProfile={storeName:'검증매장',introduction:'',staff:[],defaultStaff:'',ownerPhone:'',
  discounts:{firstThreshold:100000,firstRate:10,secondThreshold:200000,secondRate:15,reviewThreshold:50000,reviewDiscount:5000}};
for(const [subtotal,rate,total] of [[49999,0,49999],[50000,0,50000],[99999,0,99999],
  [100000,10,90000],[199999,10,180000],[200000,15,170000],[300000,15,255000]]){
  test(`${subtotal}원 구간은 ${rate}% 하나만 적용해 ${total}원으로 접수된다`,()=>{
    const q=storeDiscount(subtotal,profile);
    assert.equal(q.rate,rate);assert.equal(q.total,total);
    const choices:FinalIntakeChoices={serviceLevel:'general',technicalFee:0,discount:q.discount,
      discountMode:'auto',tierDiscountAmount:q.discount,tierDiscountRate:q.rate,tierDiscountThreshold:q.threshold,
      pickupRequested:false,deliveryRequested:false,directPickup:true,requestedPickupDate:'',
      waiver:'declined',luxuryItem:false,customerRequests:'없음',paymentType:'PREPAID'};
    const order=createConfirmedOrder({id:`discount-${subtotal}`,customerName:'할인검증',customerPhone:'01000001234',
      customerAddress:'',items:[{itemId:'shirt',displayNameKo:'검증품목',quantity:1,generalPrice:subtotal,premiumPrice:subtotal,isSneaker:false}]},choices);
    assert.equal(order.estimatedTotal,total);
    assert.equal(order.laundryTotal,subtotal);
    assert.equal(order.accountingVersion,2);
    const persisted=JSON.parse(JSON.stringify(order));
    profile.discounts.firstRate=12;
    assert.equal(persisted.estimatedTotal,total,'저장된 주문을 현재 정책으로 소급 계산하지 않는다');
    profile.discounts.firstRate=10;
  });
}
test('점주가 바꾼 기준·소수 할인율·0 비활성화와 리뷰 확인을 동일 계산에 반영한다',()=>{
  const changed={...profile,discounts:{...profile.discounts,firstThreshold:80000,firstRate:12.5,secondThreshold:160000,secondRate:20}};
  assert.deepEqual([storeDiscount(80000,changed).total,storeDiscount(160000,changed).total],[70000,128000]);
  assert.equal(storeDiscount(50000,profile).total,50000);
  assert.equal(storeDiscount(50000,profile,true).total,45000);
  assert.equal(storeDiscount(100000,profile,true).total,85000);
  assert.equal(storeDiscount(200000,{...profile,discounts:{...profile.discounts,firstRate:0,secondThreshold:0}}).total,200000);
});
test('직원 할인 배지와 고객 특대 배너에는 저장 금액·할인율·정상가 취소선을 함께 표시한다',()=>{
  const q=storeDiscount(200000,profile);
  const staff=renderToStaticMarkup(createElement(DiscountNotice,{quote:q}));
  const customer=renderToStaticMarkup(createElement(DiscountNotice,{quote:q,customer:true}));
  for(const text of ['20만 원','15%','30,000원'])assert.ok(staff.includes(text),text);
  for(const text of ['store-discount--customer','<del>정상가 200,000원</del>','170,000원','혜택 적용!'])
    assert.ok(customer.includes(text),text);
  assert.equal(renderToStaticMarkup(createElement(DiscountNotice,{quote:storeDiscount(99999,profile)})),'');
});
test('일반 방문 접수도 자동 할인을 적용하고 할인 스냅샷과 홍보 문구 설정은 실제 출력에 전달된다',()=>{
  const read=(file:string)=>fs.readFileSync(new URL(`../src/${file}`,import.meta.url),'utf8');
  const final=read('FinalIntakeConfirmation.tsx'),app=read('App.tsx'),hardware=read('HardwareSettings.tsx');
  assert.ok(!final.includes('if(confirmedOrder||!pickupRequested)return'));
  for(const key of ['discountMode','tierDiscountRate','tierDiscountAmount','tierDiscountThreshold'])
    assert.ok(final.includes(key)&&app.includes(key),key);
  assert.ok(app.includes('discountAmount:confirmedOrder?.choices.discount'));
  assert.ok(app.includes('savedItemTotal(item,confirmedOrder.choices,i)'));
  assert.ok(hardware.includes('접수증 최상단 홍보 문구 (최대 2줄)'));
  assert.ok(hardware.indexOf('id="hw-promo"')>hardware.indexOf('</div>}'),'미사용 상태여도 홍보 문구는 숨기지 않는다');
});
test('고객 할인 배너는 긴 품목 목록보다 먼저 표시하고 안내 혜택도 저장된 구간만 사용한다',()=>{
  const app=fs.readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
  const customer=app.slice(app.indexOf('function CustomerDisplay('));
  assert.ok(customer.indexOf('<DiscountNotice quote={payload.discountSummary} customer/>')<customer.indexOf('isMixedOrder ?'));
  assert.ok(customer.includes('<StoreBenefits policy={payload.discountPolicy}/>'));
  const html=renderToStaticMarkup(createElement(StoreBenefits,{policy:{
    ...profile.discounts,firstThreshold:80000,firstRate:12.5,secondThreshold:160000,secondRate:20,
  }}));
  for(const s of ['8만 원','12.5% 할인','16만 원','20% 할인'])assert.ok(html.includes(s),s);
  assert.ok(!html.includes('10% 할인'));
  assert.equal(renderToStaticMarkup(createElement(StoreBenefits,{policy:{
    ...profile.discounts,firstThreshold:0,secondRate:0,reviewDiscount:0,
  }})),'');
});
