import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(s:string)=>fs.readFileSync(new URL(`../src/${s}`,import.meta.url),'utf8');
test('두 업무 목록은 6열·4행 공통 규격과 정렬 도구를 공유한다',()=>{
  const css=read('customer-job-cards.css');
  assert.match(css,/--job-cols:\s*6/);
  assert.match(css,/grid-template-columns:\s*repeat\(var\(--job-cols\),\s*minmax\(0,\s*1fr\)\)/);
  assert.match(css,/grid-auto-rows:/);
  assert.match(css,/overflow-y:\s*auto/);
  assert.match(css,/scroll-behavior:\s*smooth/);
  assert.doesNotMatch(css,/(?:transform:\s*scale|zoom:)/);
  for(const file of ['LaundryDesk.tsx','GarmentScannerWorkspace.tsx']){
    const s=read(file);
    assert.ok(s.includes("import './customer-job-cards.css'"));
    assert.ok(s.includes('customer-job-grid'));
    assert.ok(s.includes('customer-job-card'));
    assert.ok(s.includes('NoticeQuickActions'));
    assert.ok(s.includes('CustomerJobSortControls'));
    assert.ok(s.includes('sortCustomerJobs'));
    assert.ok(s.includes('manualJobTags'));
    assert.ok(s.includes('data-unpaid='));
    assert.ok(s.includes('isUnpaidCustomerJob'));
  }
  assert.match(css,/border:\s*3px solid hsl\(0 74% 46%\)/);
  assert.match(css,/background:\s*hsl\(0 85% 96%\)/);
  assert.match(css,/\.jc-row\s*\{[^}]*flex-direction:\s*row/);
});
test('5대 설정 및 4개 하위 장비는 선택해야 세부 화면으로 이동한다',()=>{
  const s=read('NoticeCenter.tsx'),h=read('HardwareSettings.tsx');
  for(const label of ['매장 정보','가격 정책','매장 점주·관리자','하드웨어 설정','촬영용 휴대폰'])assert.ok(s.includes(label),label);
  for(const label of ['세탁물 태그(라벨)','카드 단말기·영수증 출력기','촬영 카메라','고객용 보조 모니터'])assert.ok(h.includes(label),label);
  assert.ok(s.includes("view === 'home'"));
  assert.ok(s.includes("view === 'phone'"));
  assert.ok(s.includes("openGuide('setup','usb')"));
  assert.ok(h.includes("openGuide('setup', topic)"));
});
