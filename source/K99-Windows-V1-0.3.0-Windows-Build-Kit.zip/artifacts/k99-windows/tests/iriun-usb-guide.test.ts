import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { IriunDownloads, IriunUsbGuide, usbGuideCard } from '../src/IriunUsbGuide';
import { IRIUN_OFFICIAL_URL, IRIUN_PLAY_URL, USB_CAMERA_STANDARD, USB_CAMERA_STEPS } from '../src/iriun-usb-guide';
import { GUIDE_THEMES } from '../src/guide-data';
import { PhoneGuideScene } from '../src/PhoneGuideScene';

const source = (file: string) => fs.readFileSync(new URL('../src/' + file, import.meta.url), 'utf8');
test('USB 표준 7단계는 지정한 순서와 필수 설정·신뢰하는 PC 승인 문구를 모두 포함한다', () => {
  assert.equal(USB_CAMERA_STEPS.length, 7);
  for (const [i, pattern] of [
    /빌드번호.*7번/, /USB 디버깅.*충전 중 화면 켜짐 유지/,
    /파일 전송 \/ Android Auto/, /맨 왼쪽.*절전 모드.*끄/,
    /Dim screen\(화면 어둡게\)/, /Wi-Fi\(와이파이\).*끄.*본체 뒷면.*항상 허용/,
    /매일 아침.*Iriun Webcam.*한 번/,
  ].entries()) assert.match(USB_CAMERA_STEPS[i].body, pattern);
  assert.match(USB_CAMERA_STANDARD, /Wi-Fi를 끄고.*USB 데이터 케이블.*PC 본체 뒷면/);
  assert.match(USB_CAMERA_STEPS[5].body, /우리 매장 PC가 맞을 때만/);
  assert.match(USB_CAMERA_STEPS[4].body, /메뉴가 다르거나 없을 수/);
});
test('설정과 촬영 도움말은 같은 USB 안내를 사용하며 무선 선택·수동 장치 선택을 안내하지 않는다', () => {
  assert.match(source('NoticeCenter.tsx'), /<IriunUsbGuide \/>/);
  for (const file of ['SmartphoneCameraHelp.tsx', 'CameraSetupGuide.tsx'])
    assert.match(source(file), /<IriunUsbGuide slides \/>/);
  assert.doesNotMatch(source('SmartphoneCameraHelp.tsx'), /tab-camera-help-wifi|setTab|DroidCam|같은 매장 와이파이|QR만으로/);
  assert.doesNotMatch(source('HardwareSettings.tsx'), /USB·Wi-Fi 모두|최대 15회 다시 시도/);
});
test('그림 설명서는 공통 7단계를 그대로 쓰며 과거 테더링 연결 카드를 노출하지 않는다', () => {
  const topic = GUIDE_THEMES.find(t => t.id === 'setup')!.topics.find(t => t.id === 'usb')!;
  assert.equal(topic.cards.length, 7);
  topic.cards.forEach((card, i) => {
    assert.equal(card.body, USB_CAMERA_STEPS[i].body);
    assert.equal(card.title, usbGuideCard(i).title);
    assert.ok(card.diagram);
    assert.match(renderToStaticMarkup(React.createElement(PhoneGuideScene, { card })), /pg-finger/);
  });
  assert.doesNotMatch(topic.cards.map(card => card.title + card.body).join('\n'), /같은.*공유기|와이파이에 연결|USB 테더링.*켜/);
});
test('공식 설치 QR·주소는 Play 패키지와 공식 홈페이지만 사용하며 APK를 약속하지 않는다', () => {
  assert.equal(IRIUN_PLAY_URL, 'https://play.google.com/store/apps/details?id=com.jacksoftw.webcam');
  assert.equal(IRIUN_OFFICIAL_URL, 'https://iriun.com');
  const html = renderToStaticMarkup(React.createElement(IriunDownloads));
  assert.ok(html.includes(`data-qr-url="${IRIUN_PLAY_URL}"`));
  assert.ok(html.includes(`data-qr-url="${IRIUN_OFFICIAL_URL}"`));
  assert.match(html, /별도 APK 다운로드는 확인되지 않았습니다/);
  assert.doesNotMatch(html, /\[Download APK\]|\.apk"/);
  assert.match(source('IriunUsbGuide.tsx'), /eclevel: 'L'/);
});
test('일곱 그림·번호와 한 장 넘기기 제어를 실제 React로 렌더링한다', () => {
  const all = renderToStaticMarkup(React.createElement(IriunUsbGuide));
  assert.equal((all.match(/data-testid="usb-guide-step-\d"/g) || []).length, 7);
  const slides = renderToStaticMarkup(React.createElement(IriunUsbGuide, { slides: true }));
  assert.equal((slides.match(/data-testid="usb-guide-step-\d"/g) || []).length, 1);
  assert.match(slides, /이전 그림/); assert.match(slides, /다음 그림/);
  assert.match(slides, /1 \/ 7/);
  assert.match(all, /PC 본체 뒷면/);
});
test('공식 주소 클릭 예외는 두 URL만 허용하며 기존 새 창 차단·카메라 시작 코드는 유지한다', () => {
  const main = fs.readFileSync(new URL('../electron/main.cjs', import.meta.url), 'utf8');
  assert.match(main, /https:\/\/iriun\.com\/','https:\/\/play\.google\.com\/store\/apps\/details\?id=com\.jacksoftw\.webcam'\]\.includes\(url\)/);
  assert.match(main, /return \{action:'deny'\}/);
  assert.match(main, /void iriun\.ensureReceiver\(\)/);
});
test('실제 Electron 새 창 처리기는 공식 주소만 외부 브라우저로 넘기며 오류에도 접수창을 탐색하지 않는다', async () => {
  const main = fs.readFileSync(new URL('../electron/main.cjs', import.meta.url), 'utf8');
  const body = main.match(/setWindowOpenHandler\(\(\{url\}\) => \{([\s\S]*?)\n  \}\);/)![1];
  const called: string[] = [], notices: unknown[] = [];
  const handler = new Function('url', 'shell', 'dialog', 'mainWindow', body);
  const shell = { openExternal: async (url: string) => { called.push(url); } };
  const dialog = { showMessageBox: async (data: unknown) => { notices.push(data); } };
  for (const url of [IRIUN_PLAY_URL, IRIUN_OFFICIAL_URL + '/', 'https://iriun.com.evil.test/', 'file:///C:/test.exe', 'https://example.com/'])
    assert.deepEqual(handler(url, shell, dialog, null), { action: 'deny' });
  assert.deepEqual(called, [IRIUN_PLAY_URL, IRIUN_OFFICIAL_URL + '/']);
  handler(IRIUN_PLAY_URL, { openExternal: async () => { throw Error('브라우저 미설치'); } }, dialog, null);
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.equal(notices.length, 1);
});
