'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {createNativeAdapters}=require('../electron/equipment-native.cjs');
test('mock display inventory requires explicit selection, tracks placement and safely handles unplug',async()=>{
  let windows=[],notifications=0;
  class MockWindow extends EventEmitter {
    constructor(options){super();this.options=options;this.bounds=options;this.destroyed=false;
      this.webContents=new EventEmitter();this.webContents.setWindowOpenHandler=fn=>this.openHandler=fn;
      this.webContents.send=()=>notifications++;windows.push(this);}
    async loadURL(url){this.url=url;}
    show(){} isDestroyed(){return this.destroyed;}
    close(){this.destroyed=true;this.emit('closed');}
    setBounds(bounds){this.bounds=bounds;}
  }
  const screen=new EventEmitter();
  let displays=[{id:1,label:'Staff TEST',workArea:{x:0,y:0,width:1280,height:720}},
    {id:2,label:'Customer TEST',workArea:{x:1280,y:0,width:1920,height:1080}}];
  screen.getAllDisplays=()=>displays;screen.getPrimaryDisplay=()=>displays[0];
  const adapters=createNativeAdapters({BrowserWindow:MockWindow,screen,session:{},store:{},preload:'test-only',
    getMain:()=>({webContents:{getPrintersAsync:async()=>[{name:'TSC TEST DOUBLE',displayName:'Test'}]}}),
    changed:()=>notifications++});
  assert.equal(adapters.monitors().length,2);
  await assert.rejects(()=>adapters.openCustomer(undefined),/選択|선택/);
  await adapters.openCustomer('2');
  assert.equal(windows[0].options.x,1280);
  assert.equal(windows[0].url,'k99://app/equipment/customer');
  assert.equal(windows[0].options.webPreferences.nodeIntegration,false);
  assert.equal(adapters.isCustomer(windows[0].webContents),true);
  assert.equal(adapters.displayStatus().connected,true);
  const altered={...displays[1],workArea:{x:1920,y:0,width:1080,height:1920}};
  screen.emit('display-metrics-changed',null,altered);
  assert.deepEqual(windows[0].bounds,altered.workArea);
  displays=[displays[0]];
  screen.emit('display-removed',null,{id:2});
  assert.equal(adapters.displayStatus().connected,false);
  assert.match(adapters.displayStatus().note,/연결 해제/);
  assert.equal(windows.length,1); // Never creates a replacement over the staff screen.
  assert.ok(notifications>0);
});
