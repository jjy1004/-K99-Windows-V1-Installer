import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
import {iriunDevices,openIriunCamera} from '../src/iriun-camera';

const device=(id:string,label:string)=>({deviceId:id,label,kind:'videoinput'}) as MediaDeviceInfo;
const phone=device('phone','Iriun Webcam #2');
function stream(id='phone',label='Iriun Webcam #2'){
  let stopped=false;
  const track={label,getSettings:()=>({deviceId:id}),stop:()=>{stopped=true;}};
  return {value:{getVideoTracks:()=>[track],getTracks:()=>[track]} as unknown as MediaStream,stopped:()=>stopped};
}
test('Iriun 이름만 선택하며 USB·OBS·다른 휴대폰 수신기는 선택하지 않는다',()=>{
  assert.deepEqual(iriunDevices([device('obs','OBS Virtual Camera'),device('usb','USB Webcam'),
    device('droid','DroidCam'),phone,device('p2','Iriun Webcam')]).map(d=>d.deviceId),['phone','p2']);
});
test('Iriun #2를 크기·프레임 제약 없이 현재 ID로만 직접 연다',async()=>{
  const s=stream(),requests:MediaStreamConstraints[]=[];
  const media={enumerateDevices:async()=>[device('old','USB Webcam'),phone],
    getUserMedia:async(c:MediaStreamConstraints)=>{requests.push(c);return s.value;}};
  assert.equal(await openIriunCamera(media,new AbortController().signal,async()=>{}),s.value);
  assert.deepEqual(requests,[{audio:false,video:{deviceId:{exact:'phone'}}}]);
});
test('exact 장치 선택 거부 시 동일 Iriun의 일반 장치 선호로만 재시도한다',async()=>{
  const s=stream(),requests:MediaStreamConstraints[]=[];
  await openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:async c=>{
    requests.push(c);if(requests.length===1)throw new DOMException('해상도 미지원','OverconstrainedError');return s.value;
  }},new AbortController().signal,async()=>{});
  assert.deepEqual(requests[1],{audio:false,video:{deviceId:'phone'}});
});
test('1초 간격 재탐색으로 늦게 등록된 Iriun을 자동 연결한다',async()=>{
  let scans=0,opens=0;const s=stream(),start=Date.now();
  await openIriunCamera({enumerateDevices:async()=>++scans<3?[]:[phone],
    getUserMedia:async()=>{opens++;return s.value;}},new AbortController().signal,async()=>{});
  assert.equal(scans,3);assert.equal(opens,1);assert.ok(Date.now()-start>=1900);
});
test('최대 15회 탐색 후 종료하며 Iriun이 없으면 다른 장치를 절대 열지 않는다',async()=>{
  let scans=0,opens=0;
  await assert.rejects(openIriunCamera({enumerateDevices:async()=>{scans++;return [device('usb','USB Webcam'),device('obs','OBS Virtual Camera')];},
    getUserMedia:async()=>{opens++;return stream().value;}},new AbortController().signal,async()=>{}),/Iriun Webcam/);
  assert.equal(scans,15);assert.equal(opens,0);
});
test('촬영창 닫기 신호가 재시도 대기를 즉시 취소한다',async()=>{
  const abort=new AbortController();let scans=0;
  const pending=openIriunCamera({enumerateDevices:async()=>{scans++;return [];},
    getUserMedia:async()=>stream().value},abort.signal,async()=>{});
  setTimeout(()=>abort.abort(),25);
  await assert.rejects(pending,{name:'AbortError'});assert.equal(scans,1);
});
test('권한 거부는 불필요한 반복 없이 안내하고 종료한다',async()=>{
  let opens=0;
  await assert.rejects(openIriunCamera({enumerateDevices:async()=>[phone],getUserMedia:async()=>{
    opens++;throw new DOMException('거부','NotAllowedError');
  }},new AbortController().signal,async()=>{}),{name:'NotAllowedError'});
  assert.equal(opens,1);
});
test('수동 장치 선택 UI와 저장된 장치 의존이 없고 OBS 실행·연결 코드가 없다',()=>{
  const src=new URL('../src/',import.meta.url);
  const native=fs.readFileSync(new URL('NativeDraftCamera.tsx',src),'utf8');
  assert.doesNotMatch(native,/config\??\.cameraDeviceId|automaticCamera|selectableCameras/);
  const settings=fs.readFileSync(new URL('HardwareSettings.tsx',src),'utf8');
  assert.doesNotMatch(settings,/select-camera|저장된 카메라|button-save-camera/);
  for(const folder of ['../src/','../electron/']){
    for(const file of fs.readdirSync(new URL(folder,import.meta.url),{recursive:true}) as string[]){
      if(!/\.(cjs|js|ts|tsx|bat|vbs|ps1)$/.test(file)||/test/.test(file))continue;
      const full=new URL(file,new URL(folder,import.meta.url));
      if(!fs.statSync(full).isFile())continue;
      const code=fs.readFileSync(full,'utf8');
      if(path.basename(file)==='legacy-obs-cleanup.cjs'){
        // Removal must recognise the old command, but its executable call
        // sites are restricted to Windows registry/shortcut inspection tools.
        const tree=ts.createSourceFile(file,code,ts.ScriptTarget.Latest,true),calls:string[]=[];
        const visit=(node:ts.Node)=>{
          if(ts.isCallExpression(node)){
            const callee=node.expression;
            if(callee.getText(tree)==='execute')calls.push(node.arguments[0].getText(tree));
            const name=ts.isIdentifier(callee)?callee.text:ts.isPropertyAccessExpression(callee)?callee.name.text:'';
            if(['spawn','exec','execSync','spawnSync','execFileSync'].includes(name)){
              const regexLookup=name==='exec'&&ts.isPropertyAccessExpression(callee)&&ts.isRegularExpressionLiteral(callee.expression);
              assert.equal(regexLookup,true,'정규식 조회 외의 추가 프로세스 실행은 금지');
            }
          }
          ts.forEachChild(node,visit);
        };
        visit(tree);assert.equal(calls.length,4);
        for(const target of calls)assert.ok(target==='reg'||target==="path.win32.join(system,'WindowsPowerShell','v1.0','powershell.exe')",target);
      }else assert.doesNotMatch(code,/obs64\.exe|obs32\.exe|obs-websocket|--startvirtualcam/i,path.basename(file));
    }
  }
});
