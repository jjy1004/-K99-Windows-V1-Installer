import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createIriunFreshness} from '../src/iriun-freshness';
import {watchIriunStream} from '../src/iriun-health';
import {createIriunManager} from '../src/iriun-manager';
function fixture(){
  let time=0,colour=80,readable=true,run=()=>{},recoveries=0;
  const track=Object.assign(new EventTarget(),{readyState:'live',muted:false,stops:0,
    getSettings:()=>({deviceId:'current-only'}),stop(){this.readyState='ended';this.stops++;}});
  const stream={getTracks:()=>[track],getVideoTracks:()=>[track]} as unknown as MediaStream;
  const video={srcObject:stream,readyState:2,videoWidth:1920,videoHeight:1080,currentTime:0,
    getVideoPlaybackQuality:()=>({totalVideoFrames:video.currentTime})} as unknown as HTMLVideoElement;
  const freshness=createIriunFreshness({now:()=>time,readPixels:()=>readable?new Uint8ClampedArray([colour,40,90,255]):null});
  return {track,stream,video,freshness,
    time:(t:number)=>{time=t;},colour:(n:number)=>{colour=n;},unreadable:()=>{readable=false;},
    watch:()=>watchIriunStream(video,stream,{freshness,now:()=>time,readFrame:()=>readable?'image':'unavailable',
      isCurrent:()=>true,recover:()=>{recoveries++;},every:fn=>{run=fn;return()=>{};},events:new EventTarget(),page:new EventTarget()}),
    tick:(t:number,progress=true)=>{time=t;if(progress)video.currentTime++;run();},recoveries:()=>recoveries};
}
test('프레임 숫자가 증가해도 같은 픽셀 1.5초면 즉시 복구를 시작한다',()=>{
  const f=fixture();f.watch();
  f.tick(1499);assert.equal(f.recoveries(),0);
  f.tick(1500);assert.equal(f.recoveries(),1);
  f.tick(1750);assert.equal(f.recoveries(),1,'한 스트림당 중복 복구 금지');
});
test('움직임이 적어도 실제 픽셀이 변하면 정상 화면을 강제 종료하지 않는다',()=>{
  const f=fixture();const stop=f.watch();
  for(let i=1;i<40;i++){f.colour(80+i%2);f.tick(i*250);}
  assert.equal(f.recoveries(),0);stop();
});
test('새 스트림이 똑같은 옛 잔상을 반복하면 신선한 사진으로 오인하지 않는다',()=>{
  const f=fixture();f.freshness.sample(f.video,f.stream);f.time(1800);
  const next={getVideoTracks:()=>[f.track]} as unknown as MediaStream;f.video.srcObject=next;
  assert.equal(f.freshness.sample(f.video,next).frozenForMs,1800);
  f.colour(180);assert.equal(f.freshness.sample(f.video,next).frozenForMs,0);
});
test('카메라 muted/ended는 이벤트 즉시 복구하고 이후 이벤트는 중복 처리하지 않는다',()=>{
  for(const event of ['mute','ended']){
    const f=fixture();f.watch();
    if(event==='mute')f.track.muted=true;
    f.track.dispatchEvent(new Event(event));assert.equal(f.recoveries(),1);
    f.track.dispatchEvent(new Event(event));assert.equal(f.recoveries(),1);
  }
});
test('0 크기·읽기 불가·다른 스트림은 촬영 가능한 최신 프레임이 아니다',()=>{
  const f=fixture();f.unreadable();assert.equal(f.freshness.sample(f.video,f.stream).pixelAvailable,false);
  f.video.videoWidth=0;assert.equal(f.freshness.sample(f.video,f.stream).usable,false);
  f.video.srcObject=null;assert.equal(f.freshness.sample(f.video,f.stream).usable,false);
});
test('노출된 검은 중간 프레임은 이전 잔상 기준을 지우지 않는다',()=>{
  let t=0,data=new Uint8ClampedArray([200,20,30,255]);const f=fixture();
  const h=createIriunFreshness({now:()=>t,readPixels:()=>data});
  h.sample(f.video,f.stream);t=1200;data=new Uint8ClampedArray([0,0,0,255]);
  assert.equal(h.sample(f.video,f.stream).pixelAvailable,false);
  t=2000;data=new Uint8ClampedArray([200,20,30,255]);
  assert.equal(h.sample(f.video,f.stream).frozenForMs,2000);
});
test('신선한 스트림만 반환하고 재연결 중인 촬영은 최신 이미지까지 기다린다',async()=>{
  const f=fixture(),owner={},states:string[]=[];let opens=0;
  let stale=false;
  const manager=createIriunManager({events:new EventTarget(),
    freshness:()=>({frame(){},sample:()=>({usable:true,pixelAvailable:true,stalledForMs:0,frozenForMs:stale?1500:0})}),
    context:async()=>({media:{} as MediaDevices,dispose(){}}),
    open:async()=>{opens++;if(opens>1){await new Promise(r=>setTimeout(r,10));stale=false;}return f.stream;},
    show:async v=>{v.srcObject=f.stream;},watch:()=>()=>{}});
  await manager.start(owner,{video:()=>f.video,change:s=>states.push(s.phase)});
  assert.equal(await manager.ensureFresh(owner),f.video);assert.equal(opens,1);
  stale=true;const result=await manager.ensureFresh(owner);
  assert.equal(result,f.video);assert.equal(opens,2);assert.ok(f.track.stops>0);
  manager.stop(owner);
});
test('끊긴 동안 창을 닫으면 촬영 대기가 취소되고 저장 코드로 진행할 수 없다',async()=>{
  const f=fixture(),owner={};let stale=false;
  const manager=createIriunManager({events:new EventTarget(),
    freshness:()=>({frame(){},sample:()=>({usable:true,pixelAvailable:true,stalledForMs:0,frozenForMs:stale?1500:0})}),
    context:async()=>({media:{} as MediaDevices,dispose(){}}),open:async()=>f.stream,
    show:async()=>{},watch:()=>()=>{}});
  await manager.start(owner,{video:()=>f.video,change:()=>{}});
  stale=true;const pending=manager.ensureFresh(owner);
  manager.stop(owner);await assert.rejects(pending);assert.equal(manager.state().phase,'idle');
});
test('15회 이후 탐색도 실패할 때 1초 재탐색을 다음 묶음으로 무한 예약하고 닫으면 해제한다',async()=>{
  const owner={},queue:{fn:()=>void;ms:number;cancelled:boolean}[]=[];let calls=0;
  const manager=createIriunManager({events:new EventTarget(),context:async()=>({media:{} as MediaDevices,dispose(){}}),
    open:async()=>{calls++;throw Error('Wi-Fi 끊김');},delay:async()=>{},
    schedule:(fn,ms)=>{const q={fn,ms,cancelled:false};queue.push(q);return()=>{q.cancelled=true;};}});
  const binding={video:()=>null,change:()=>{}};
  await manager.start(owner,binding);
  assert.equal(calls,15);assert.equal(queue[0].ms,1000);
  queue[0].fn();await manager.start(owner,binding);
  assert.equal(calls,30);assert.equal(queue[1].ms,1000);
  manager.stop(owner);assert.equal(queue[1].cancelled,true);
});
test('두 촬영 저장 경로는 최신 프레임 검증 이후에만 기존 저장 API로 진행한다',()=>{
  for(const name of ['NativeDraftCamera.tsx','EquipmentWorkspace.tsx']){
    const code=fs.readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
    assert.match(code,/await camera\.ensureFresh\(\)/);
    assert.match(code,/if\(captureIdentity\.current!==identity\)throw Error/,'재연결 대기 중 고객·의류 변경 시 저장 취소');
    assert.ok(code.indexOf('await camera.ensureFresh()')<code.indexOf("equipmentRequest",code.indexOf('await camera.ensureFresh()')));
    assert.match(code,/status-.*reconnecting/);
  }
});
