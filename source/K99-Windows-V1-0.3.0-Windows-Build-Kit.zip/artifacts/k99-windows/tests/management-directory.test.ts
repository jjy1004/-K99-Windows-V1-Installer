import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { listCustomerDirectory, type MasterCustomer } from '../src/customer-directory-client';
import { csvCell, customerDirectoryCsv, customerDirectoryFilename, filterCustomerDirectory } from '../src/customer-directory-export';
const require = createRequire(import.meta.url);
const {createStore} = require('../../../lib/k99-local/index.cjs');

test('management directory queries real SQLite: complete list, latest-first, full visits, filters and read-only persistence', async t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'k99-management-'));
  const filename = path.join(root, 'k99.db');
  let store = createStore(filename, 'test-only', {nativeDesktop:true});
  const old = Object.getOwnPropertyDescriptor(globalThis, 'window');
  t.after(() => {
    if (old) Object.defineProperty(globalThis,'window',old); else Reflect.deleteProperty(globalThis,'window');
    store.close(); fs.rmSync(root,{recursive:true,force:true});
  });
  const csv = '고객명,전화번호,주소,방문일,수량,금액,품목\n'+
    '김시험,01011111234,시험주소A,2026-11-01,2,14000,셔츠\n'+
    '김시험,01011111234,시험주소A,2026-11-02,1,9000,남방\n'+
    '이시험,01022221234,시험주소B,2026-10-30,3,21000,코트\n'+
    Array.from({length:12},(_,i)=>`명부${i},0108888${String(i).padStart(4,'0')},시험주소,2026-10-01,1,1000,품목`).join('\n');
  const preview = await store.api('POST','/api/customers/import/preview',{fileName:'fixture.csv',data:Buffer.from(csv).toString('base64')});
  store.api('POST','/api/customers/import/commit',{token:preview.token});
  const order = {id:'MG-LIVE',customerName:'김시험',customerPhone:'01011111234',customerAddress:'시험주소A',
    intakeAt:'2026-11-05T03:04:00Z',status:'접수 완료',totalQuantity:2,estimatedTotal:30000,laundryTotal:30000,
    items:[{displayNameKo:'가죽',quantity:2}]};
  store.storage({op:'set',key:'k99-confirmed-orders-v1',value:JSON.stringify([order]),expected:null});
  Object.defineProperty(globalThis,'window',{configurable:true,value:{k99Desktop:{
    request:async (input:{method:string;path:string;body:unknown}) => {
      try {return {ok:true,result:store.api(input.method,input.path,input.body)};}
      catch(e){return {ok:false,error:(e as Error).message};}
    },
  }}});
  // Only transport substituted; all directory and order values come from a real disposable SQLite file.
  const databaseBytes = () => ['','-wal'].map(suffix => fs.existsSync(filename+suffix) ? fs.readFileSync(filename+suffix).toString('base64') : '');
  const before = databaseBytes();
  const result = await listCustomerDirectory();
  assert.equal(result.customers.length,14, 'not truncated to autocomplete LIMIT 10');
  const c = result.customers[0];
  assert.equal(c.name,'김시험');
  assert.equal(c.lastVisitDate,'2026-11-05');
  assert.equal(c.totalVisits,3); assert.equal(c.totalItems,5); assert.equal(c.totalAmount,53000);
  assert.equal(c.visits.length,3);
  assert.equal(c.visits[0].orderNumber,'MG-LIVE');
  assert.equal(c.visits[0].receiptAt,'2026-11-05T03:04:00Z');
  assert.deepEqual(c.visits[0].items,[{label:'가죽',quantity:2}]);
  assert.equal(c.visits[0].status,'접수 완료');
  assert.equal(c.visits[1].status,'과거 장부 · 상태 미기록');
  assert.equal(filterCustomerDirectory(result.customers,'1234').length,2);
  assert.equal(filterCustomerDirectory(result.customers,'김시').length,1);
  assert.equal(filterCustomerDirectory(result.customers,'없는고객').length,0);
  assert.equal(store.api('GET','/api/customers/directory?q=1234').customers.length,2);
  assert.deepEqual(databaseBytes(),before, 'list and filtering perform no DB/WAL writes');
  const catalog = store.api('GET','/api/price-catalog');
  const modified = catalog.entries.map((e:{id:string;generalPrice:number})=>({...e,generalPrice:e.id==='blouse'?15999:e.generalPrice}));
  store.api('PUT','/api/price-catalog',{entries:modified,revision:catalog.revision,password:''});
  assert.equal(store.api('GET','/api/customers/directory').customers[0].totalAmount,53000,'saved order price snapshots unchanged');
  assert.throws(()=>store.api('PUT','/api/price-catalog',{entries:modified,revision:catalog.revision,password:''}),/가격표가 변경/);
  store.close();store=createStore(filename,'test-only',{nativeDesktop:true});
  assert.equal(store.api('GET','/api/price-catalog').entries.find((e:{id:string})=>e.id==='blouse').generalPrice,15999);
  assert.equal((await listCustomerDirectory()).customers[0].totalAmount,53000);
});

test('CSV preserves Korean BOM, quoted data and all visits, and neutralises spreadsheet formulas', () => {
  const customers:MasterCustomer[]=[{id:'test',name:'=HYPERLINK("x")',phone:'01000001234',address:'과천, "주소"\n2층',
    totalVisits:2,nextVisit:3,lastVisitDate:'2026-11-05',totalItems:3,totalAmount:19000,visits:[
      {id:'a',visitDate:'2026-11-05',receiptAt:'2026-11-05',orderNumber:'a',itemCount:2,totalAmount:14000,status:'세탁 중',source:'local',items:[{label:'셔츠',quantity:2}]},
      {id:'b',visitDate:'2026-11-04',receiptAt:'2026-11-04',orderNumber:'b',itemCount:1,totalAmount:5000,status:'출고 대기',source:'local',items:[]},
    ]}];
  const csv = customerDirectoryCsv(customers);
  assert.equal(csv.charCodeAt(0),0xfeff);
  assert.match(csv,/'=HYPERLINK\(""x""\)/);
  assert.match(csv,/과천, ""주소""\n2층/);
  assert.match(csv,/셔츠 × 2/); assert.match(csv,/"a"/); assert.match(csv,/"b"/);
  assert.equal(csvCell('@SUM(A1)'),'"\'@SUM(A1)"');
  assert.equal(customerDirectoryFilename(new Date('2026-11-05T15:01:00Z')),'K99_고객명부_접수이력_20261106.csv');
  assert.equal(filterCustomerDirectory(customers,'1234')[0].id,'test');
});

test('management UI wiring preserves Zero-Auth, draft price revision and filtered full export', () => {
  const source = (name:string) => fs.readFileSync(new URL(`../src/${name}`,import.meta.url),'utf8');
  const editor = source('ManagementPriceEditor.tsx');
  assert.match(editor,/const rev = loadedRevision/);
  assert.match(editor,/saveSharedCatalog\(CATALOG_DEFAULTS, entries, '', rev\)/);
  assert.doesNotMatch(editor,/<input[^>]+type=["']password/);
  assert.match(source('PickupNoticeActions.tsx'),/title: '세탁비 설정 · 수정'/);
  assert.match(source('SimpleStatisticsCenter.tsx'),/onPrices=/);
  assert.match(source('ManagementCustomerPanel.tsx'),/downloadCustomerDirectory\(filtered\)/);
  assert.match(source('shared-price-catalog.ts'),/dispatchEvent\(new Event\(SHARED_PRICE_EVENT\)\)/);
  assert.match(source('App.tsx'),/addEventListener\(SHARED_PRICE_EVENT, refresh\)/);
});
