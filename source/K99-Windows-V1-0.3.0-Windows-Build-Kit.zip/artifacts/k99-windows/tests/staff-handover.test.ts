import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createConfirmedOrder, type ConfirmedOrder} from '../src/order-record';
import {listGarments} from '../src/garment-scanner';
import {currentOperations} from '../src/order-operations';
import {garmentProcessStatus} from '../src/laundry-process';
import {confirmStaffHandover, finishOrderHandover, handoverBlockers, handoverScanFingerprint,
  isReadyForHandover, staffHandoverBlockers} from '../src/order-handover';

const choices={serviceLevel:'general' as const,pickupRequested:false,deliveryRequested:false,directPickup:true,
  requestedPickupDate:'',waiver:'not-requested' as const,luxuryItem:false,customerRequests:'없음'};
const input={id:'H-1',customerName:'정다온',customerPhone:'010-2741-3816',customerAddress:'',
  items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]};

function ready(delivery=false, status: '출고 대기'|'세탁중'='출고 대기'): ConfirmedOrder {
  const base=createConfirmedOrder({...input,customerAddress:delivery?'경기 과천시 별양로 12':''},{...choices,deliveryRequested:delivery,directPickup:!delivery},new Date('2026-03-02T01:00:00Z'));
  const at='2026-03-04T05:00:00.000Z';
  return {...base,status:'전체 세탁 완료 / 반출 대기',
    operations:{...currentOperations(base),stage:'세탁완료',updatedAt:at},
    garments:listGarments(base).map(g=>({...g,processStatus:status,processUpdatedAt:at,
      ...(status==='출고 대기'?{completionStatus:'complete' as const,completedAt:at}:{})}))} as ConfirmedOrder;
}
const at=new Date('2026-03-05T02:00:00Z');

test('strict scan API still requires every scan', () => {
  const o=ready();
  assert.ok(handoverBlockers(o,{}).some(b=>b.includes('스캔')));
  assert.throws(()=>finishOrderHandover(o,{},at));
});

test('ready order confirms without scans and records staff-confirmed audit', () => {
  const o=ready();
  assert.deepEqual(staffHandoverBlockers(o),[]);
  assert.ok(isReadyForHandover(o));
  const done=confirmStaffHandover(o,{actor:'박주임',at});
  assert.equal(currentOperations(done).stage,'매장수령완료');
  assert.ok(currentOperations(done).completedAt);
  for (const g of listGarments(done)) assert.equal(garmentProcessStatus(done,g),'반출 완료');
  const audit=done.history!.at(-1)!;
  assert.equal(audit.details.action,'handover-confirmed');
  assert.equal(audit.details.method,'staff-confirmed');
  assert.equal(audit.details.actor,'박주임');
  assert.throws(()=>confirmStaffHandover(done,{at}),/이미 인도/);
});

test('full scans are audited as barcode-scan', () => {
  const o=ready();
  const scans=Object.fromEntries(listGarments(o).map(g=>[g.garmentId,handoverScanFingerprint(g)]));
  const done=confirmStaffHandover(o,{scans,at});
  assert.equal(done.history!.at(-1)!.details.method,'barcode-scan');
});

test('delivery orders dispatch without marking delivered', () => {
  const done=confirmStaffHandover(ready(true),{at});
  assert.equal(currentOperations(done).stage,'배달중');
  assert.equal(currentOperations(done).completedAt,undefined);
  assert.equal(done.history!.at(-1)!.details.delivery,true);
});

test('unfinished, held and cancelled orders stay blocked', () => {
  assert.throws(()=>confirmStaffHandover(ready(false,'세탁중'),{at}),/미완료/);
  const held=ready(); held.garments=held.garments!.map((g,i)=>i?g:{...g,qcHoldReason:'얼룩 재확인'});
  assert.throws(()=>confirmStaffHandover(held,{at}),/추가 확인/);
  const c=ready(); c.operations={...c.operations!,cancelledAt:at.toISOString()};
  assert.throws(()=>confirmStaffHandover(c,{at}),/취소/);
});
