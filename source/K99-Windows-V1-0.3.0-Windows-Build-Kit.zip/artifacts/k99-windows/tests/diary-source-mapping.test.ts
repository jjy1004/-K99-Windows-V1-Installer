import { test } from 'node:test';
import assert from 'node:assert/strict';
import { diarySourceSegments, renderMappedDiary, type DiaryMapping } from '../../api-server/src/lib/diary-voice-ai';
import { validateDiaryWav, voiceAuthorized, createVoiceAdmission } from '../../api-server/src/lib/diary-voice';
import { pcmWav } from '../src/diary-recorder';
function entry(id: number, polished: string): DiaryMapping {
  return { id, section: '세정', mode: '실제 작업', polished, review: false };
}
test('머뭇거림·정정 전후와 소수 농도를 자르지 않고 모든 원문 조각을 보존한다', () => {
  const raw = '1.5%를 사용했습니다. 양이온성... 아, 비이온성으로 정정합니다. 자연 건조합니다.';
  const parts = diarySourceSegments(raw);
  assert.equal(parts.length, 3);
  assert.equal(parts.map(p => p.quote).join(''), raw);
  const result = renderMappedDiary(raw, parts.map(p => entry(p.id, p.quote.trim())));
  assert.equal(result.mapping.length, 3);
  assert.equal(result.mapping[1].section, '정정 발화·확인 필요');
  assert.equal(result.mapping[1].review, true);
  assert.ok(result.text.includes('양이온성... 아, 비이온성'));
});
test('중복·누락된 매핑은 실패 처리하고 대안은 완료한 작업에서 분리한다', () => {
  const raw = '물세탁 금지입니다. 가볍게 물세탁해도 됩니다.';
  assert.throws(() => renderMappedDiary(raw, [entry(0, '금지')]), /누락/);
  assert.throws(() => renderMappedDiary(raw, [entry(0, '금지'), entry(0, '중복')]), /형식/);
  const result = renderMappedDiary(raw, [entry(0, '물세탁 금지'), entry(1, '대안 발화')]);
  assert.equal(result.mapping[1].section, '대안 관리 메모');
  assert.equal(result.mapping[1].mode, '대안');
  assert.equal(result.conflict_review, true);
  assert.match(result.text, /별도 확인/);
});
test('여러 작업을 길게 이어 말해도 전처리·세정·탈취·건조·다림질을 나누고 근거를 잃지 않는다', () => {
  const raw = '전처리 후 세정하고 탈취한 다음 자연건조하고 마지막으로 다림질했습니다.';
  const parts = diarySourceSegments(raw);
  const mapped = renderMappedDiary(raw, parts.map(p => entry(p.id, p.quote.trim())));
  assert.deepEqual(mapped.mapping.map(p => p.section), ['전처리', '세정', '탈취', '건조', '다림질']);
  assert.equal(parts.map(p => p.quote).join(''), raw);
});
test('WAV 헤더·용량·인증·동시 실행 보호는 잘못된 요청을 거절한다', () => {
  const wav = Buffer.from(pcmWav(new Float32Array(16000)));
  assert.equal(validateDiaryWav(wav.toString('base64')).length, wav.length);
  const broken = Buffer.from(wav); broken.writeUInt32LE(48000, 24);
  assert.throws(() => validateDiaryWav(broken.toString('base64')));
  assert.throws(() => validateDiaryWav('not-a-wav'));
  assert.equal(voiceAuthorized('Bearer test-only-token-123456789', 'test-only-token-123456789'), true);
  assert.equal(voiceAuthorized('Bearer bad', 'test-only-token-123456789'), false);
  let now = 0; const enter = createVoiceAdmission(() => now), one = enter('test'), two = enter('test');
  assert.ok(one); assert.ok(two); assert.throws(() => enter('other'), /요청/);
  one!(); two!(); now = 61000; assert.ok(enter('test'));
});
