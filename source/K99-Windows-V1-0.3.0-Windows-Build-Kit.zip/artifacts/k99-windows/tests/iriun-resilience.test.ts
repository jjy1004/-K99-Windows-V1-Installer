import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
import {isEmptyBlackFrame,watchIriunStream,inspectIriunStream} from '../src/iriun-health';
import {migrateCameraCache} from '../src/camera-cache';
import {openIriunCamera} from '../src/iriun-camera';
const require=createRequire(import.meta.url);
const {internalCameraPermission}=require('../electron/camera-permissions.cjs');
const {createCameraFirewall}=require('../electron/camera-firewall.cjs');
const pixels=(r:number,g=r,b=r)=>new Uint8ClampedArray([r,g,b,255,r,g,b,255]);

function health(){
  let time=0,scheduled=()=>{},cancelled=0,light:'image'|'black'|'unavailable'='image',current=true;
  const events=new EventTarget(),page=Object.assign(new EventTarget(),{hidden:false});
  const track=Object.assign(new EventTarget(),{readyState:'live',muted:false});
  const stream={getVideoTracks:()=>[track]} as unknown as MediaStream;
  const video={srcObject:stream,readyState:2,videoWidth:1920,videoHeight:1080,currentTime:1,
    getVideoPlaybackQuality:()=>({totalVideoFrames:video.currentTime})} as unknown as HTMLVideoElement;
  const reasons:string[]=[];
  const stop=watchIriunStream(video,stream,{events,page,isCurrent:()=>current,recover:r=>reasons.push(r),
    now:()=>time,readFrame:()=>light,every:(fn,ms)=>{assert.equal(ms,3000);scheduled=fn;return()=>{cancelled++;};}});
  return {track,video,events,page,stop,reasons,
    tick:(advance=true,ms=3000)=>{time+=ms;if(advance)video.currentTime++;scheduled();},
    black:()=>{light='black';},unreadable:()=>{light='unavailable';},
    disown:()=>{current=false;},cancelled:()=>cancelled};
}
test('영 프레임만 검은 화면으로 판별하며 하늘색·흰 바탕·검은 원단을 보정하지 않는다',()=>{
  assert.equal(isEmptyBlackFrame(pixels(0)),true);
  assert.equal(isEmptyBlackFrame(pixels(0,1,0)),true);
  for(const data of [pixels(130,200,240),pixels(248),pixels(12),pixels(0,0,15)])
    assert.equal(isEmptyBlackFrame(data),false);
  assert.equal(isEmptyBlackFrame(new Uint8ClampedArray()),false);
});
test('움직이지 않는 동일한 옷도 디코딩 프레임이 진행하면 연결을 유지한다',()=>{
  const h=health();for(let i=0;i<30;i++)h.tick();assert.equal(h.reasons.length,0);h.stop();
});
test('메타데이터가 정상이어도 디코딩 프레임 진행이 멈추면 한 번만 복구한다',()=>{
  const h=health();for(let i=0;i<8;i++)h.tick(false);
  assert.equal(h.reasons.length,1);assert.equal(h.cancelled(),1);
});
test('검은 화면·캔버스 손실·크기 0·readyState 손실을 각각 자동 복구한다',()=>{
  for(const fault of ['black','unreadable','zero','metadata']){
    const h=health();
    if(fault==='black')h.black();if(fault==='unreadable')h.unreadable();
    if(fault==='zero')Object.assign(h.video,{videoWidth:0});
    if(fault==='metadata')Object.assign(h.video,{readyState:1});
    for(let i=0;i<3;i++)h.tick();
    assert.equal(h.reasons.length,1,fault);h.stop();
  }
});
test('일시적인 한 번의 검은 화면이나 한 번의 프레임 유실로 정상 스트림을 끊지 않는다',()=>{
  const h=health();h.black();h.tick();assert.equal(h.reasons.length,0);h.stop();
  const healthy=health();healthy.tick(false);healthy.tick();assert.equal(healthy.reasons.length,0);healthy.stop();
});
test('PC 절전 시간 도약 및 Electron 절전 복귀 신호를 각각 처리한다',()=>{
  const h=health();h.tick(false,60000);assert.equal(h.reasons.length,1);
  const resumed=health();resumed.events.dispatchEvent(new Event('k99-camera-resume'));assert.equal(resumed.reasons.length,1);
});
test('숨겨진 창의 브라우저 타이머 제한은 프리징으로 오인하지 않는다',()=>{
  const h=health();h.page.hidden=true;
  for(let i=0;i<6;i++)h.tick(false,60000);
  assert.equal(h.reasons.length,0);h.stop();
});
test('종료·지속 mute·unmute 신호와 다른 요청으로 바뀐 srcObject를 처리한다',()=>{
  const ended=health();ended.track.dispatchEvent(new Event('ended'));assert.equal(ended.reasons.length,1);
  const muted=health();muted.track.muted=true;for(let i=0;i<3;i++)muted.tick();assert.equal(muted.reasons.length,1);
  const restored=health();restored.track.muted=true;restored.tick();
  restored.track.muted=false;restored.track.dispatchEvent(new Event('unmute'));restored.tick();assert.equal(restored.reasons.length,0);restored.stop();
  const replaced=health();replaced.video.srcObject={} as MediaStream;
  for(let i=0;i<3;i++)replaced.tick();assert.equal(replaced.reasons.length,1);
});
test('창 닫기·메뉴 이동 후 감시기와 이벤트가 더 이상 카메라를 열지 않는다',()=>{
  const h=health();h.disown();h.tick();
  h.events.dispatchEvent(new Event('k99-camera-resume'));h.track.dispatchEvent(new Event('ended'));
  assert.equal(h.reasons.length,0);assert.equal(h.cancelled(),1);
  const disposed=health();disposed.stop();disposed.events.dispatchEvent(new Event('k99-camera-resume'));
  assert.equal(disposed.reasons.length,0);
});
test('동영상 프레임 콜백이 진행하는 브라우저는 fallback 시계가 고정되어도 정상이다',()=>{
  let time=0,tick=()=>{},frame:(...args:unknown[])=>void=()=>{},cancelled=0;
  const track=Object.assign(new EventTarget(),{readyState:'live',muted:false});
  const stream={getVideoTracks:()=>[track]} as unknown as MediaStream;
  const video={srcObject:stream,readyState:2,videoWidth:1920,videoHeight:1080,currentTime:0,
    requestVideoFrameCallback:(fn:typeof frame)=>{frame=fn;return 123;},cancelVideoFrameCallback:()=>{cancelled++;}} as unknown as HTMLVideoElement;
  const stop=watchIriunStream(video,stream,{now:()=>time,readFrame:()=> 'image',isCurrent:()=>true,
    recover:()=>assert.fail('실제 프레임이 진행 중임'),every:fn=>{tick=fn;return()=>{};},events:new EventTarget(),page:new EventTarget()});
  for(let i=0;i<10;i++){time+=3000;frame();tick();}stop();assert.equal(cancelled,1);
});
test('장치 목록 조회가 응답하지 않아도 무한 대기하지 않고 15회로 제한한다',async()=>{
  let scans=0;
  await assert.rejects(openIriunCamera({enumerateDevices:()=>{scans++;return new Promise(()=>{});},
    getUserMedia:async()=>{throw Error('목록 없이 카메라 열기 금지');}},new AbortController().signal,async()=>{},5,
    {wait:async()=>{}}),{name:'CameraInventoryTimeout'});
  assert.equal(scans,15);
});
test('프리징으로 실패한 현재 장치는 다음 연결에서 뒤로 보내고 다른 살아있는 Iriun부터 확인한다',async()=>{
  const cameras=['one','two'].map(id=>({deviceId:id,label:`Iriun Webcam ${id}`,kind:'videoinput'}) as MediaDeviceInfo);
  let opened='';
  const media={enumerateDevices:async()=>cameras,getUserMedia:async(c:MediaStreamConstraints)=>{
    opened=((c.video as MediaTrackConstraints).deviceId as ConstrainDOMStringParameters).exact as string;
    const track={label:`Iriun Webcam ${opened}`,getSettings:()=>({deviceId:opened}),stop:()=>{}};
    return {getVideoTracks:()=>[track],getTracks:()=>[track]} as unknown as MediaStream;
  }};
  await openIriunCamera(media,new AbortController().signal,async()=>{},6000,{avoidDeviceId:'one'});
  assert.equal(opened,'two');
  await openIriunCamera(media,new AbortController().signal,async()=>{},6000,{avoidDeviceId:'stale-old-id'});
  assert.equal(opened,'one'); // stale ID never becomes an open target
});
test('브라우저가 Error가 아닌 권한 거부 객체를 반환해도 이름을 보존하고 반복하지 않는다',async()=>{
  let calls=0;
  await assert.rejects(openIriunCamera({
    enumerateDevices:async()=>[{deviceId:'one',label:'Iriun Webcam',kind:'videoinput'}] as MediaDeviceInfo[],
    getUserMedia:async()=>{calls++;throw {name:'NotAllowedError',message:'접근 거부'};},
  },new AbortController().signal,async()=>{},6000,{wait:async()=>{}}),{name:'NotAllowedError'});
  assert.equal(calls,1);
});
test('GPU 상태 조회 예외가 발생해도 감시기 자체가 중단되지 않고 복구한다',()=>{
  const h=health();
  h.video.getVideoPlaybackQuality=()=>{throw Error('GPU context lost');};
  h.tick();assert.equal(h.reasons.length,1);assert.equal(h.cancelled(),1);
});
test('첫 수신기가 실제 영 프레임이면 다음 Iriun 수신기에서 다시 첫 프레임을 검증한다',async()=>{
  const original=Object.getOwnPropertyDescriptor(globalThis,'document');let paused=0,hasPicture=false,frames=0;
  Object.defineProperty(globalThis,'document',{configurable:true,value:{createElement:(tag:string)=>tag==='video'?
    {readyState:2,videoWidth:1920,videoHeight:1080,play:async()=>{},pause:()=>{paused++;},
      getVideoPlaybackQuality:()=>({totalVideoFrames:++frames})}:
    {getContext:()=>({drawImage:()=>{},getImageData:()=>({data:pixels(hasPicture?248:0)})})}}});
  const tracks=[Object.assign(new EventTarget(),{readyState:'live'})];
  const stream={getVideoTracks:()=>tracks} as unknown as MediaStream;
  try{
    await assert.rejects(inspectIriunStream(stream),/검은 화면/);
    hasPicture=true;await inspectIriunStream(stream);assert.equal(paused,2);
  }finally{if(original)Object.defineProperty(globalThis,'document',original);else Reflect.deleteProperty(globalThis,'document');}
});
test('첫 영상 대기 중 촬영창을 닫으면 임시 검사 비디오도 즉시 분리한다',async()=>{
  const original=Object.getOwnPropertyDescriptor(globalThis,'document'),abort=new AbortController();
  let removed=0;
  const video={srcObject:null,readyState:1,videoWidth:1920,videoHeight:1080,play:async()=>{},
    pause:()=>{},remove:()=>{removed++;}};
  Object.defineProperty(globalThis,'document',{configurable:true,value:{createElement:()=>video}});
  try{
    const pending=inspectIriunStream({getVideoTracks:()=>[]} as unknown as MediaStream,abort.signal);
    abort.abort();assert.equal(video.srcObject,null);assert(removed>0);
    await assert.rejects(pending,/취소/);
  }finally{if(original)Object.defineProperty(globalThis,'document',original);else Reflect.deleteProperty(globalThis,'document');}
});
test('구버전 장치 ID 캐시만 한 번 제거하고 주문·고객·사진·보안·화질 설정은 보존한다',()=>{
  const data=new Map([['k99-camera-device-id','old-device'],['cameraDeviceId','stale'],['orders','고객 주문'],
    ['k99-camera-color','수동 설정'],['k99.iriun-connection','usb'],['admin','보안 설정']]);
  const storage={getItem:(k:string)=>data.get(k)??null,setItem:(k:string,v:string)=>data.set(k,v),removeItem:(k:string)=>data.delete(k)};
  migrateCameraCache(storage);assert.equal(data.has('cameraDeviceId'),false);
  for(const key of ['orders','k99-camera-color','k99.iriun-connection','admin'])assert.equal(data.has(key),true);
  data.set('cameraDeviceId','unused');migrateCameraCache(storage);assert.equal(data.has('cameraDeviceId'),true);
  assert.doesNotThrow(()=>migrateCameraCache({getItem:()=>{throw Error('읽기 전용');},setItem:()=>{},removeItem:()=>{}}));
});
test('미디어 권한은 K99 내부 주 촬영 화면만 자동 승인한다',()=>{
  const wc={getURL:()=> 'k99://app/'},mainWindow={webContents:wc};
  const base={webContents:wc,mainWindow,permission:'media'};
  assert.equal(internalCameraPermission({...base,details:{mediaTypes:['video','audio']}}),true);
  for(const patch of [{permission:'geolocation'},{webContents:{getURL:()=> 'https://evil.example'}},
    {details:{isMainFrame:false}},{origin:'https://evil.example'},{details:{requestingUrl:'https://evil.example'}},
    {details:{securityOrigin:'k99://other/'}}])assert.equal(internalCameraPermission({...base,...patch}),false);
});
test('촬영 전용 문맥만 카메라 권한을 받고 외부·다른 내부 문맥·마이크 요청은 거부된다',()=>{
  const wc={getURL:()=> 'k99://app/'},base={webContents:wc,mainWindow:{webContents:wc},permission:'media'};
  const details={isMainFrame:false,requestingUrl:'k99://app/camera-context.html',mediaTypes:['video']};
  assert.equal(internalCameraPermission({...base,details}),true);
  for(const patch of [{requestingUrl:'k99://app/other.html'},{requestingUrl:'https://evil.example/camera-context.html'},
    {requestingUrl:'k99://app/camera-context.html?foreign=1'},{mediaTypes:['audio']}])
    assert.equal(internalCameraPermission({...base,details:{...details,...patch}}),false);
});
test('방화벽 규칙은 실행 파일·개인 네트워크·동일 LAN으로만 제한하며 중복 등록하지 않는다',async()=>{
  const calls:string[][]=[],exe='C:\\Program Files\\K99\\K99.exe',iriun='C:\\Program Files (x86)\\Iriun Webcam\\IriunWebcam.exe';
  const fw=createCameraFirewall({platform:'win32',appExecutable:exe,env:{},
    stat:async(file:string)=>({isFile:()=>[exe,iriun].includes(file)}),
    execute:async(file:string,args:string[])=>{assert.match(file,/System32\\netsh\.exe$/);calls.push(args);return 'OK';}});
  const [a,b]=await Promise.all([fw.ensure(),fw.ensure()]);assert.equal(a.applied,true);assert.equal(b.applied,true);
  assert.equal(calls.filter(x=>x.includes('set')).length,4);
  for(const args of calls.filter(x=>x.includes('set'))){
    assert(args.includes('profile=private'));assert(args.includes('remoteip=localsubnet'));assert(args.includes('action=allow'));
    assert(!args.includes('allprofiles'));assert(!args.includes('delete'));
  }
  await fw.ensure();assert.equal(calls.length,8);
});
test('방화벽 권한 거부·미설치·다른 OS에서도 접수 시작을 막거나 관리자 승격하지 않는다',async()=>{
  const exe='C:\\K99\\K99.exe';let launches=0;
  const fw=createCameraFirewall({platform:'win32',appExecutable:exe,env:{},stat:async()=>({isFile:()=>true}),
    execute:async()=>{launches++;throw Error('관리자 권한 없음');}});
  assert.equal((await fw.ensure()).applied,false);assert.match((await fw.ensure()).warning,/관리자/);assert.equal(launches,2);
  assert.equal((await createCameraFirewall({platform:'linux',execute:()=>assert.fail('다른 OS 실행 금지')}).ensure()).skipped,true);
  const missing=createCameraFirewall({platform:'win32',stat:async()=>{throw Error('없음');},execute:()=>assert.fail('파일 없음')});
  assert.equal((await missing.ensure()).skipped,true);
});
test('방화벽 신규 규칙 등록은 허용한 두 프로그램에 대해서만 수행한다',async()=>{
  const adds:string[][]=[];
  const fw=createCameraFirewall({platform:'win32',appExecutable:'C:\\K99\\K99.exe',env:{},
    stat:async(file:string)=>({isFile:()=>file.includes('K99.exe')||file.includes('Iriun Webcam\\')}),
    execute:async(_file:string,args:string[])=>{if(args.includes('show'))throw Error('규칙 없음');adds.push(args);return 'OK';}});
  assert.equal((await fw.ensure()).rules,4);assert.equal(adds.length,4);
  assert(adds.every(args=>args.includes('add')&&args.includes('profile=private')));
});
test('절전 신호·캐시 정리·감시기는 실제 촬영창 두 곳에 연결되고 업무 저장 로직은 유지한다',()=>{
  const read=(name:string)=>fs.readFileSync(new URL(name,import.meta.url),'utf8');
  for(const name of ['../src/NativeDraftCamera.tsx','../src/EquipmentWorkspace.tsx']){
    const code=read(name);assert.match(code,/useIriunCamera\(videoRef,streamRef,/);
    assert.doesNotMatch(code,/openIriunCamera\(|watchIriunStream\(/,'화면별 중복 연결 엔진을 다시 만들지 않는다');
  }
  assert.match(read('../src/use-iriun-camera.ts'),/migrateCameraCache\(localStorage\)/);
  const manager=read('../src/iriun-manager.ts');
  for(const required of ['watchIriunStream','openIriunCamera','k99-camera-resume','30000','createIriunContext'])
    assert.ok(manager.includes(required),required);
  assert.match(read('../electron/main.cjs'),/powerMonitor\?\.on\?\.\('resume'/);
  assert.match(read('../electron/preload.cjs'),/dispatchEvent\(new Event\('k99-camera-resume'\)\)/);
});
