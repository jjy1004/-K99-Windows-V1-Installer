import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { ImeTextInput } from '../src/ImeTextInput';
import { installKoreanInputs } from '../src/korean-inputs';
import '../src/desktop-runtime';

const calls: {korean:boolean}[] = [];
Object.assign(window, { imeCalls: calls, k99Desktop: {
  forceKorean: async (input:{korean:boolean}) => { calls.push(input); return {state:'requested'}; },
} });
installKoreanInputs();
function Demo() {
  const [name,setName] = useState(''), [memo,setMemo] = useState(''), [saved,setSaved] = useState('');
  return <main style={{maxWidth:1050,margin:'60px auto',padding:36,fontFamily:'sans-serif',fontSize:24,background:'#f4f6f4'}}>
    <h1>한글 우선 입력 · 공통 컴포넌트 검증</h1>
    <p>Windows 입력기 요청 + 두벌식 보완 변환 · 숫자/암호 예외 · 입력창별 한/영 전환</p>
    <label style={{display:'block',margin:'30px 0'}}>고객 이름 검색
      <ImeTextInput id="customer-name" value={name} onValue={setName} koreanFirst="search"
        style={{display:'block',width:'90%',fontSize:30,padding:14}} /></label>
    <output id="search-result">{name === '강하늘' ? '검색 결과: 강하늘 고객' : name}</output>
    <label style={{display:'block',margin:'30px 0'}}>일기 내용 · 특이사항 메모
      <textarea id="diary-memo" value={memo} onChange={e=>setMemo(e.target.value)}
        style={{display:'block',width:'90%',height:110,fontSize:28,padding:14}} /></label>
    <div id="editable" contentEditable suppressContentEditableWarning aria-label="소재·색상 직접 입력"
      style={{background:'#fff',border:'2px solid #718178',padding:16,minHeight:40,whiteSpace:'pre-wrap'}}>소재: </div>
    <div style={{display:'flex',gap:20,margin:'30px 0'}}>
      <label>전화번호<input id="phone" type="tel" style={{display:'block',fontSize:22}} /></label>
      <label>비밀번호<input id="secret" type="password" style={{display:'block',fontSize:22}} /></label>
    </div>
    <button id="save" style={{fontSize:26,padding:16}} onClick={()=>setSaved(memo)}>검사값 보관</button>
    <output id="saved" style={{display:'block',marginTop:20}}>{saved}</output>
  </main>;
}
createRoot(document.getElementById('root')!).render(<Demo />);
