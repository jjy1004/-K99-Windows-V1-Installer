import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createConfirmedOrder, readConfirmedOrders, updateSavedOrder, type ConfirmedOrder } from '../src/order-record';
import { inspectionPaymentLabel, reviseInspectionPayment } from '../src/inspection-payment';
import { currentOperations } from '../src/order-operations';

const choices = { serviceLevel: 'general' as const, pickupRequested: false, deliveryRequested: false,
  directPickup: true, requestedPickupDate: '', waiver: 'not-requested' as const, luxuryItem: false, customerRequests: '보존' };
const input = { id: 'payment-terms-test', customerName: '결제구분시험', customerPhone: '01000004321', customerAddress: '시험 주소',
  items: [{ itemId: 'shirt_dress', displayNameKo: '와이셔츠', quantity: 1, generalPrice: 5000, premiumPrice: 9000, isSneaker: false }] };
const order = () => createConfirmedOrder(input, choices, new Date('2026-11-20T01:00:00Z'));

test('inspection labels distinguish unset, prepaid, postpaid and read-only legacy COD', () => {
  assert.equal(inspectionPaymentLabel(order()), '선불');
  assert.equal(inspectionPaymentLabel(reviseInspectionPayment(order(), 'POSTPAID')), '후불');
  assert.equal(inspectionPaymentLabel({ ...order(), payment_type: undefined, choices: { ...choices } }), '미지정');
  assert.equal(inspectionPaymentLabel({ ...order(), payment_type: 'COD' } as unknown as ConfirmedOrder), '착불');
  assert.equal(inspectionPaymentLabel({ ...order(), payment_type: '착불' } as unknown as ConfirmedOrder), '착불');
});

test('terms update both representations, preserve garment/photo/tag data and never mutate the input', () => {
  const original = order(), before = JSON.stringify(original);
  const post = reviseInspectionPayment(original, 'POSTPAID');
  assert.equal(post.payment_type, 'POSTPAID'); assert.equal(post.choices.paymentType, 'POSTPAID');
  assert.equal(post.payment_status, 'UNPAID'); assert.equal(inspectionPaymentLabel(post), '후불');
  assert.equal(post.garments, original.garments); assert.equal(post.items, original.items);
  assert.equal(post.customerFolderName, original.customerFolderName);
  assert.equal(post.estimatedTotal, original.estimatedTotal);
  assert.equal(JSON.stringify(original), before);
  assert.equal(post.history!.at(-1)!.details.action, 'payment-terms-update');
  const pre = reviseInspectionPayment(post, 'PREPAID');
  assert.equal(pre.payment_status, 'PAID'); assert.equal(pre.choices.paymentType, 'PREPAID');
  assert.equal(reviseInspectionPayment(pre, 'PREPAID'), pre);
  assert.throws(() => reviseInspectionPayment(pre, 'COD' as never), /선불 또는 후불/);
});

test('changing terms never clears actual paid amounts, receipt dates, refunds or notification history', () => {
  for (const status of ['결제완료', '환불', '미결제'] as const) {
    const original = order();
    const paid = { ...original, operations: { ...currentOperations(original), paymentStatus: status,
      paidAmount: 2000, paidAt: '2026-11-20T02:00:00Z' } };
    const revised = reviseInspectionPayment(paid, 'POSTPAID');
    assert.equal(revised.operations, paid.operations);
    assert.equal(revised.operations.paidAmount, 2000);
    assert.equal(revised.operations.paidAt, paid.operations.paidAt);
    assert.equal(revised.payment_status, status === '환불' ? 'UNPAID' : 'PAID');
  }
});

test('existing synchronous save commits to real temporary SQLite, survives restart and rejects stale edits', t => {
  const require = createRequire(import.meta.url);
  const { createStore } = require('../../../lib/k99-local/index.cjs');
  const Database = createRequire(require.resolve('../../../lib/k99-local/index.cjs'))('better-sqlite3');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'k99-inspection-payment-'));
  const file = path.join(dir, 'k99.db');
  let store = createStore(file);
  const host = globalThis as unknown as { window?: Window };
  const previous = host.window;
  const key = 'k99-confirmed-orders-v1', original = order();
  store.storage({ op: 'set', key, value: JSON.stringify([original]), expected: null });
  host.window = { localStorage: {
    getItem: (k: string) => store.storage({ op: 'get', key: k }),
    setItem: (k: string, value: string) => store.storage({ op: 'set', key: k, value, expected: store.storage({ op: 'get', key: k }) }),
  } } as unknown as Window;
  t.after(() => { host.window = previous; store.close(); fs.rmSync(dir, { recursive: true, force: true }); });
  const saved = readConfirmedOrders()[0], revised = reviseInspectionPayment(saved, 'POSTPAID');
  updateSavedOrder(revised, saved);
  store.close(); store = createStore(file);
  const reopened = readConfirmedOrders()[0];
  assert.equal(reopened.payment_type, 'POSTPAID'); assert.equal(reopened.choices.paymentType, 'POSTPAID');
  const db = new Database(file, { readonly: true });
  try {
    const row = db.prepare('SELECT payment_type,payment_status,body FROM orders WHERE id=?').get(original.id);
    assert.equal(row.payment_type, 'POSTPAID'); assert.equal(row.payment_status, 'UNPAID');
    assert.equal(JSON.parse(row.body).choices.paymentType, 'POSTPAID');
    assert.throws(() => updateSavedOrder(reviseInspectionPayment(saved, 'PREPAID'), saved), /다른 화면/);
    assert.equal(readConfirmedOrders()[0].payment_type, 'POSTPAID');
  } finally { db.close(); }
});

test('reception payment controls live only in the right column after the sneakers panel', () => {
  const app = fs.readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const left = app.slice(app.indexOf('<section className="k99-intake-left">'), app.indexOf('<section className="k99-intake-right"'));
  const right = app.slice(app.indexOf('<section className="k99-intake-right"'), app.indexOf('function CustomerDisplayRoute'));
  assert.doesNotMatch(left, /intake-tag-payment/);
  assert.equal((right.match(/name="intake-tag-payment"/g) ?? []).length, 2);
  assert(right.indexOf('intake-payment-panel') > right.indexOf('sneaker-intake-panel'));
  assert.match(right, /setFinalChoices\(v=>\(\{\.\.\.v,paymentType:'POSTPAID'\}\)\)/);
});
