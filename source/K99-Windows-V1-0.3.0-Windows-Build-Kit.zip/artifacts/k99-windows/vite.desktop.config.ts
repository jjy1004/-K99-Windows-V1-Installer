import path from 'node:path';
import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// No Replit plugins, service ports, cloud URLs or external fonts in desktop.
export default defineConfig({
  root:import.meta.dirname,
  base:'/',
  plugins:[react(),tailwindcss()],
  resolve:{alias:{'@':path.resolve(import.meta.dirname,'src')},dedupe:['react','react-dom']},
  build:{outDir:'dist/desktop',emptyOutDir:true},
});
