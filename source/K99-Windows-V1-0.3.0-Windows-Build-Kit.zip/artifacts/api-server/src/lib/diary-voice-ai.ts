import { contextPrompt, TRANSCRIPTION_HINT, ORGANIZE_RULE, type VoiceContext } from './diary-voice';
import type { OpenAI } from '@workspace/integrations-openai-ai-server';

/** HTTP 경로와 음성 파일 검증 하네스가 같은 AI 처리 함수를 사용한다. */
export async function transcribeDiaryAudio(client: OpenAI, bytes: Buffer, context: VoiceContext) {
  const { toFile } = await import('@workspace/integrations-openai-ai-server');
  const result = await client.audio.transcriptions.create({
    model: 'gpt-4o-mini-transcribe', file: await toFile(bytes, 'diary.wav', { type: 'audio/wav' }),
    language: 'ko', response_format: 'json',
    prompt: `${TRANSCRIPTION_HINT}\n정정 발화는 앞선 말과 정정한 말을 모두 기록합니다. 요약하지 않습니다.\n매장 용어 참고: ${context.glossary.map(g => g.target).join(', ').slice(0, 1200)}`,
  }, { timeout: 90000, maxRetries: 1 });
  if (!result.text?.trim() || result.text.length > 20000) throw Error('전사 결과 형식 오류');
  return result.text.trim();
}
export const DIARY_SECTIONS = ['의류·소재·색상', '케어라벨·금지사항', '전처리', '세정', '탈취', '건조', '다림질', '대안 관리 메모', '특이사항·주의사항', '정정 발화·확인 필요'] as const;
export function diarySourceSegments(raw: string) {
  // 모든 조각은 원문의 연속 부분 문자열이다. 원문 자체를 고치거나 단어를 버리지 않는다.
  const segments: { id: number; quote: string }[] = []; let start = 0;
  for (let i = 0; i < raw.length; i++) {
    if (!/[.!?。！？]/.test(raw[i])) continue;
    if (raw[i] === '.') {
      let end = i + 1; while (raw[end] === '.') end++;
      if (end - i > 1) { i = end - 1; continue; } // 말머뭇거림·정정을 문장 분리로 잃지 않는다.
      if (/\d/.test(raw[i - 1] || '') && /\d/.test(raw[i + 1] || '')) continue;
    }
    let end = i + 1; while (/\s/.test(raw[end] || '') && end < raw.length) end++;
    segments.push({ id: segments.length, quote: raw.slice(start, end) }); start = end; i = end - 1;
  }
  if (start < raw.length) segments.push({ id: segments.length, quote: raw.slice(start) });
  const clauses: { id: number; quote: string }[] = [];
  for (const sentence of segments.length ? segments : [{ id: 0, quote: raw }]) {
    if (/해도\s*(?:됩|된)|대안|대신|아[,\s]+(?:아니|비이온)|아니[,\s]+|정정/.test(sentence.quote)) {
      clauses.push({ id: clauses.length, quote: sentence.quote }); continue;
    }
    let start = 0;
    for (const match of sentence.quote.matchAll(/(?:인데\s+|후에\s+|전처리\s*후\s+|세정하고\s+|탈취한\s*다음\s+|자연건조하고\s+|때문에\s+|닦아내고\s+)/g)) {
      const end = match.index! + match[0].length;
      clauses.push({ id: clauses.length, quote: sentence.quote.slice(start, end) }); start = end;
    }
    if (start < sentence.quote.length) clauses.push({ id: clauses.length, quote: sentence.quote.slice(start) });
  }
  return clauses;
}
export type DiaryMapping = { id: number; section: typeof DIARY_SECTIONS[number]; mode: '실제 작업' | '대안' | '금지사항' | '확인 필요'; polished: string; review: boolean };
export function renderMappedDiary(raw: string, entries: DiaryMapping[]) {
  const source = diarySourceSegments(raw);
  if (source.map(s => s.quote).join('') !== raw || entries.length !== source.length) throw Error('원문 매핑 누락');
  const seen = new Set<number>();
  for (const entry of entries) {
    if (!Number.isInteger(entry.id) || entry.id < 0 || entry.id >= source.length || seen.has(entry.id) ||
        !DIARY_SECTIONS.includes(entry.section) || !['실제 작업', '대안', '금지사항', '확인 필요'].includes(entry.mode) ||
        typeof entry.polished !== 'string' || !entry.polished.trim() || entry.polished.length > 4000)
      throw Error('원문 매핑 형식 오류');
    seen.add(entry.id);
    const quote = source[entry.id].quote;
    // 허용·대안 발화를 완료된 작업으로 바꿔 적지 않는다.
    if (/해도\s*(?:됩|된)|대안|대신/.test(quote)) { entry.mode = '대안'; entry.section = '대안 관리 메모'; }
    else if (/아[,\s]+(?:아니|비이온)|아니[,\s]+|정정/.test(quote)) { entry.review = true; entry.section = '정정 발화·확인 필요'; }
    else if (/금지/.test(quote)) { entry.mode = '금지사항'; entry.section = '케어라벨·금지사항'; }
    else if (/다림질|다리는\s*온도|스팀/.test(quote)) entry.section = '다림질';
    else if (/탈취/.test(quote)) entry.section = '탈취';
    else if (/자연건조|건조를\s*(?:실시|했)|말렸/.test(quote)) entry.section = '건조';
    else if (/닦아|수건|물티슈|전처리/.test(quote)) entry.section = '전처리';
    else if (/왁스|소재|재킷|자켓|외피는/.test(quote)) entry.section = '의류·소재·색상';
  }
  const mapping = entries.map(entry => ({ ...entry, evidence: source[entry.id].quote.trim() }));
  const body = DIARY_SECTIONS.map(section => {
    const matches = mapping.filter(entry => entry.section === section).sort((a, b) => a.id - b.id);
    const reviewRefs = section === '정정 발화·확인 필요' ? mapping.filter(entry => entry.review && entry.section !== section).map(entry => `원문 근거 ${entry.id + 1}의 색상·용어·작업 조건을 원음과 대조해 주세요.`) : [];
    const lines = matches.map(entry => `- ${entry.polished}${entry.review ? ' (원음 확인 필요)' : ''}\n  원문 근거 ${entry.id + 1}: ${entry.evidence}`);
    lines.push(...reviewRefs.map(line => `- ${line}`));
    return `[${section}]\n${lines.join('\n') || '미언급'}`;
  }).join('\n\n');
  const conflict = /금지/.test(raw) && /해도\s*(?:됩|된)|대안|대신/.test(raw);
  const text = body + (conflict ? '\n\n[충돌 확인]\n케어라벨의 금지 표기와 대안 방법에 관한 발화가 함께 있습니다. 대안이 허용된다는 뜻으로 확정하지 말고 실제 적용 전에 별도 확인하세요.' : '') +
    '\n\n※ 구술 내용의 기록입니다. 세탁 방법의 안전성이나 실제 작업 허용 여부를 검증한 결과가 아닙니다.';
  if (text.length > 20000) throw Error('정리 결과가 길어 2만 자를 초과했습니다. 원문을 보존한 채 나누어 기록해 주세요.');
  return { text, mapping, source_segments: source.length, evidence_segments: seen.size, conflict_review: conflict };
}
export async function organizeDiaryDetailed(client: OpenAI, raw: string, context: VoiceContext) {
  const segments = diarySourceSegments(raw);
  const result = await client.chat.completions.create({
    model: 'gpt-5.4-mini', max_completion_tokens: 8192,
    response_format: { type: 'json_schema', json_schema: { name: 'diary_mapping', strict: true, schema: {
      type: 'object', additionalProperties: false, required: ['entries'], properties: { entries: {
        type: 'array', items: { type: 'object', additionalProperties: false,
          required: ['id', 'section', 'mode', 'polished', 'review'], properties: {
            id: { type: 'integer' }, section: { type: 'string', enum: [...DIARY_SECTIONS] },
            mode: { type: 'string', enum: ['실제 작업', '대안', '금지사항', '확인 필요'] },
            polished: { type: 'string' }, review: { type: 'boolean' },
          } },
      } },
    } } },
    messages: [
      { role: 'system', content: ORGANIZE_RULE + '\nJSON만 반환합니다. 입력 조각 각각에 entries를 정확히 한 번씩 반환하고 id를 보존하세요. section은 조각의 주된 항목입니다. 여러 작업이 한 조각에 있으면 polished에 그 세부 작업을 모두 남기세요. 실제 작업과 대안을 섞지 마세요. 대안은 대안 관리 메모에만 넣습니다. 상품명·횟수·농도·금지사항·순서·정정 전후 표현을 빼지 마세요. 명확하지 않은 색상·약제·장비 이름은 그대로 인용하고 review=true로 남기세요. 이상한 발음을 추측해 정상 용어로 치환하지 마세요. 정정 발화는 앞 표현을 실제 사용한 것으로 기록하지 말고 정정 전→후를 보존하세요. polished는 원문에 충실한 일기 문장으로만 다듬으세요.' },
      { role: 'user', content: JSON.stringify({ segments, store_style: contextPrompt(context) }) },
    ],
  }, { timeout: 90000, maxRetries: 1 });
  const json = result.choices[0]?.message.content;
  if (!json) throw Error('문장 정리 결과 없음');
  const parsed = JSON.parse(json) as { entries: DiaryMapping[] };
  return renderMappedDiary(raw, parsed.entries);
}
export async function organizeDiaryText(client: OpenAI, raw: string, context: VoiceContext) {
  return (await organizeDiaryDetailed(client, raw, context)).text;
}
