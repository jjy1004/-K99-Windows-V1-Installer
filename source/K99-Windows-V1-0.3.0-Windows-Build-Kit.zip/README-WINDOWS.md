# K99 Laundry V2 2.4.20 GitHub 빌드 키트

이 ZIP은 압축을 풀지 말고 저장소의 source/K99-Windows-V1-0.3.0-Windows-Build-Kit.zip에 업로드합니다.
기존 경로와 호환되도록 파일명에만 0.3.0을 유지했습니다. 실제 앱 버전은 2.4.20입니다.
source/K99-Windows-V1-0.3.0-Windows-Build-Kit.zip.sha256 파일도 반드시 함께 교체합니다.
저장소 루트의 .github/workflows/windows-installer.yml도 함께 교체해야
요청한 K99-Smart-Laundry-V2-Setup.exe가 Actions 결과물에 포함됩니다.

ZIP 내부의 워크플로는 소스 보관본이며 GitHub가 자동으로 적용하지 않습니다.
함께 제공한 업로드 도우미 HTML에서 해시·워크플로·업로드 정보 파일을
압축 해제 없이 각각 내려받을 수 있습니다.

기존 source/customer-videos.upload.json, source/customer-videos.release.json 및
scripts/download-release-media.cjs는 유지합니다. 바깥쪽 워크플로가 승인된
빌드용 GitHub 릴리스에서 원본 분할 영상 7개를 내려받아 크기·해시를 검사합니다.
4종 원본 안내 영상은 기존 분할 파일을 사용하고, 별도 promo.mp4가 없으면
현재의 기존 스테이징 정책대로 value.mp4를 대기 영상으로 복사합니다.

Actions → Build K99 Windows Installer → Run workflow에서
사용량·저장 공간을 확인하고 usage_approved 항목을 선택하여 실행합니다.
검증을 통과하면 정식 Releases에 K99-Smart-Laundry-V2-Setup.exe, SHA-256, installer-release.json을 게시합니다.
고정 최신 주소: https://github.com/jjy1004/-K99-Windows-V1-Installer/releases/latest/download/K99-Smart-Laundry-V2-Setup.exe
Artifacts에는 이전 요청명 Setup.2.exe도 유지합니다. Artifact 저장 한도가 초과되어도
정식 Release의 최신 설치 파일 링크에는 영향을 주지 않도록 별도로 처리합니다.

운영 DB·고객 장부·사진·설정 파일·Secrets·node_modules는 포함하지 않습니다.
이것은 빌드 소스이며 설치 EXE가 아닙니다.
이 키트로 실제 GitHub Windows 빌드를 실행하거나 실장비를 검사하지 않았습니다.
