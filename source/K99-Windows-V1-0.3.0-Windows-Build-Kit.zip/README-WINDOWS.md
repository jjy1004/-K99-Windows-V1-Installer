# K99 V2 조건부 자동 소재 태그 발행 수정 소스

최신 정책: 최초 사진은 원래 태그 작업을 예약하고, 라벨 성공은 소재, 분석 실패는 일반, 라벨 생략은 다음 의류 촬영 또는 마감 시 불명확으로 같은 작업을 1회 자동 제출합니다. 수동 소재 출력 버튼은 제거했습니다.

TypeScript/React desktop 빌드 및 자동검사 182개 통과. 실제 Gemini 호출·Windows EXE·TSC 실물 출력은 미검증입니다. submitted는 스풀러 제출이며 실물 인쇄 보장이 아닙니다. failed/unknown은 무조건 재시도하지 않습니다.

DB 스키마·HTML 인쇄 템플릿·Gemini 서비스·3.5초 BasketPopup·의존성 버전은 이번 수정에서 유지했습니다. equipment-api.cjs의 제출 트리거만 선택적으로 확장합니다.

상세: docs/windows-automatic-material-tags.md
키 설정: docs/windows-care-label-ai.md (매장 Windows GEMINI_API_KEY, 소스에 키 미포함)
증거: audit/automatic-tag-verification.json

기존 비공개 GitHub Windows workflow로 새 설치본을 빌드하세요. 이 ZIP은 실행 EXE/app.asar 또는 바로 덮어쓰는 app.zip이 아닙니다. 기존 영상 조각은 그대로 유지하세요.
