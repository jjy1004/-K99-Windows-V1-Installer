# K99 Laundry V2 2.4.6 GitHub 빌드 키트

이 ZIP은 압축을 풀지 말고 저장소의 source/K99-Windows-V1-0.3.0-Windows-Build-Kit.zip에 업로드합니다.
기존 경로와 호환되도록 파일명에만 0.3.0을 유지했습니다. 실제 앱 버전은 2.4.6입니다.
source/K99-Windows-V1-0.3.0-Windows-Build-Kit.zip.sha256 파일도 반드시 함께 교체합니다.
저장소 루트의 .github/workflows/windows-installer.yml도 함께 교체해야
요청한 K99-Smart-Laundry-V2-Setup.2.exe가 Actions 결과물에 포함됩니다.

ZIP 내부의 워크플로는 소스 보관본이며 GitHub가 자동으로 적용하지 않습니다.
함께 제공한 업로드 도우미 HTML에서 해시·워크플로·업로드 정보 파일을
압축 해제 없이 각각 내려받을 수 있습니다.

기존 source/customer-videos.upload.json 및 customer-videos.zip.part001~007
영상 분할 파일을 유지합니다. 위 파일이 없다면 영상 복원 단계에서 빌드가 중단됩니다.
영상 분할 파일이 저장소에 있는지는 이 작업에서 원격으로 확인하지 못했습니다.
4종 원본 안내 영상은 기존 분할 파일을 사용하고, 별도 promo.mp4가 없으면
현재의 기존 스테이징 정책대로 value.mp4를 대기 영상으로 복사합니다.

Actions → Build K99 Windows Installer → Run workflow에서
사용량·저장 공간을 확인하고 usage_approved 항목을 선택하여 실행합니다.
성공한 실행의 Artifacts에서 K99-Laundry-V2-2.4.6-Windows-x64를 내려받습니다.
안에는 K99-Smart-Laundry-V2-Setup.2.exe, SHA-256, installer-release.json 등이 들어갑니다.
GitHub의 기존 Artifact 저장 한도가 초과되어 있으면 업로드가 실패할 수 있습니다.

운영 DB·고객 장부·사진·설정 파일·Secrets·node_modules는 포함하지 않습니다.
이것은 빌드 소스이며 설치 EXE가 아닙니다.
이 키트로 실제 GitHub Windows 빌드를 실행하거나 실장비를 검사하지 않았습니다.
