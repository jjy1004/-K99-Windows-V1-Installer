'use strict';
// Self-contained documentation only: no changes to the app, installer or data.
const fs=require('node:fs'),path=require('node:path');
const dir=path.resolve('generated-artifacts/manual-v2');
const out=path.join(dir,'K99-V2-매장PC-그림설명서.html');
const download='https://k-99-windows-v-1.replit.app/api/dev-downloads/K99-Smart-Laundry-V2-Setup.exe';
const xml=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const data=(mime,bytes)=>`data:${mime};base64,${Buffer.from(bytes).toString('base64')}`;
const png=name=>data('image/png',fs.readFileSync(path.join(dir,name+'.png')));
const badge=(n,x,y)=>`<circle cx="${x}" cy="${y}" r="29" fill="#dc2626" stroke="white" stroke-width="5"/><text x="${x}" y="${y+12}" text-anchor="middle" fill="white" font-size="36" font-weight="900">${n}</text>`;
const arrow=(x,y,tx,ty)=>`<path d="M${x},${y} L${tx},${ty}" fill="none" stroke="white" stroke-width="11"/><path d="M${x},${y} L${tx},${ty}" fill="none" stroke="#dc2626" stroke-width="6" marker-end="url(#arrow)"/>`;
const defs=`<defs><marker id="arrow" markerWidth="12" markerHeight="12" refX="8" refY="5" orient="auto" markerUnits="userSpaceOnUse" viewBox="0 0 10 10"><path d="M0 0 L10 5 L0 10Z" fill="#dc2626"/></marker></defs>`;
function actual(name,{crop=[0,0,1440,1000],marks=[]}={}){
  const [x,y,w,h]=crop,rail=320,total=w+rail;
  return data('image/svg+xml',`<svg xmlns="http://www.w3.org/2000/svg" width="${total}" height="${h}" viewBox="0 0 ${total} ${h}" font-family="sans-serif">
    ${defs}<rect width="${total}" height="${h}" fill="#fff7ed"/><svg width="${w}" height="${h}" viewBox="${x} ${y} ${w} ${h}">
    <image href="${png(name)}" width="1440" height="1000"/></svg>
    <line x1="${w}" y1="0" x2="${w}" y2="${h}" stroke="#fed7aa" stroke-width="3"/>
    ${marks.map((m,i)=>{
      const by=m.labelY??(75+i*155),start=w+40,tx=m.target[0]-x,ty=m.target[1]-y;
      return `${arrow(start,by,tx,ty)}${badge(m.n,start,by)}
      ${m.lines.map((line,j)=>`<text x="${w+85}" y="${by+11+j*44}" fill="#991b1b" font-size="35" font-weight="800">${xml(line)}</text>`).join('')}`;
    }).join('')}</svg>`);
}
function diagram(kind){
  const common=`<rect width="1280" height="800" rx="24" fill="#fff7ed"/><rect x="22" y="20" width="1236" height="68" rx="12" fill="#fff" stroke="#dc2626" stroke-width="3"/>
    <text x="640" y="65" text-anchor="middle" font-size="30" font-weight="900" fill="#991b1b">순서 설명용 그림 · 실제 Windows 캡처가 아닙니다</text>`;
  let content;
  if(kind==='protection'){
    content=`<rect x="55" y="125" width="735" height="600" rx="16" fill="#0758b6"/>
      <text x="90" y="185" fill="white" font-size="43" font-weight="900">Windows의 PC 보호</text>
      <text x="90" y="242" fill="white" font-size="27">이 파란 창이 나타나는 경우에만 아래 순서로 진행</text>
      <text x="105" y="340" fill="white" font-size="37" text-decoration="underline">추가 정보</text>
      <text x="90" y="445" fill="white" font-size="27">앱 이름을 확인하세요.</text>
      <text x="90" y="490" fill="white" font-size="27" font-weight="bold">K99-Smart-Laundry-V2-Setup.exe</text>
      <rect x="105" y="565" width="220" height="75" rx="5" fill="#f8fafc"/><text x="215" y="615" text-anchor="middle" font-size="34" font-weight="900">실행</text>
      ${arrow(870,310,310,328)}${badge(1,875,310)}<text x="925" y="320" font-size="34" font-weight="800">추가 정보</text>
      <text x="925" y="365" font-size="30">먼저 누르기</text>
      ${arrow(870,580,340,600)}${badge(2,875,580)}<text x="925" y="590" font-size="34" font-weight="800">실행</text>
      <text x="925" y="635" font-size="30">그다음 누르기</text>
      <text x="55" y="775" font-size="27" fill="#7c2d12">실제 창은 두 화면으로 나뉘거나 Windows 버전에 따라 다르게 보일 수 있습니다.</text>`;
  }else{
    content=`<rect x="48" y="120" width="1184" height="610" rx="16" fill="white" stroke="#cbd5e1" stroke-width="3"/>
      <rect x="75" y="157" width="290" height="225" rx="14" fill="#0f2942"/>
      <rect x="166" y="179" width="105" height="87" rx="18" fill="#eab308"/><text x="218" y="239" text-anchor="middle" font-size="43" font-weight="900">K99</text>
      <text x="220" y="315" fill="white" font-size="28" font-weight="800" text-anchor="middle">K99 스마트 접수 시스템</text>
      <text x="220" y="359" fill="white" font-size="27" text-anchor="middle">바탕화면 바로가기</text>
      ${badge(1,85,415)}${arrow(120,415,220,383)}
      <text x="135" y="465" font-size="30" font-weight="800">아이콘을 두 번 클릭</text>
      <text x="440" y="172" font-size="31" font-weight="900">자동 연결되는 저장 폴더</text>
      <text x="440" y="224" font-size="28">예: D:\\K99_스마트접수</text>
      ${['00_프로그램 / K99_명품세탁비','01_고객세탁사진','02_세탁전후사진','03_고객모니터영상'].map((name,i)=>`<rect x="444" y="${255+i*88}" width="725" height="66" rx="9" fill="${i%2?'#eff6ff':'#f1f5f9'}"/>
        <path d="M460 ${275+i*88} h18 l6 7 h20 v24 h-44Z" fill="#eab308"/><text x="520" y="${298+i*88}" font-size="30" font-weight="800">${xml(name)}</text>`).join('')}
      ${badge(2,405,630)}${arrow(438,630,530,607)}
      <text x="465" y="675" font-size="28">기존 매장 폴더가 있으면 그대로 사용합니다.</text>
      <text x="70" y="775" font-size="27" fill="#7c2d12">C:·D:·E: 등 드라이브 문자는 PC마다 다릅니다. 기존 폴더를 삭제하지 마세요.</text>`;
  }
  return data('image/svg+xml',`<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="800" font-family="sans-serif">${defs}${common}${content}</svg>`);
}
const picture=(src,alt,caption)=>`<figure><img src="${src}" alt="${alt}" loading="eager"><figcaption>${caption}</figcaption></figure>`;
const line=(n,text)=>`<li><span class="num">${n}</span><div>${text}</div></li>`;
const website=actual('01-public-browser',{crop:[445,0,550,870],marks:[
  {n:1,target:[720,170],labelY:210,lines:['현재 공개','로그인 화면']},
  {n:2,target:[720,700],labelY:565,lines:['로그인 단추','내려받기 아님']},
]});
const customers=actual('04a-customer-search',{crop:[15,90,540,545],marks:[
  {n:1,target:[224,190],labelY:75,lines:['전화번호','끝 4자리']},
  {n:2,target:[345,468],labelY:300,lines:['고객 이름','골라 누르기']},
]});
const camera=actual('04b-camera-controls',{crop:[15,90,1040,875],marks:[
  {n:1,target:[168,913],labelY:570,lines:['촬영','A / F7']},
  {n:2,target:[420,913],labelY:675,lines:['누르면 확대','B / F8']},
  {n:3,target:[915,913],labelY:785,lines:['다음 옷','C / F9']},
]});
const management=actual('05a-management',{crop:[145,85,1130,475],marks:[
  {n:1,target:[970,357],labelY:215,lines:['고객 엑셀','일괄 업로드']},
]});
const excel=actual('05b-excel-import',{crop:[160,595,1110,345],marks:[
  {n:2,target:[270,784],labelY:70,lines:['처음이면','샘플 양식']},
  {n:3,target:[268,847],labelY:235,lines:['내 엑셀','파일 선택']},
]});
const launchers=actual('05c-launchers',{crop:[8,180,545,170],marks:[
  {n:4,target:[137,255],labelY:45,lines:['명품 세탁비']},
  {n:5,target:[413,255],labelY:125,lines:['AI 세탁 처방']},
]});
const html=`<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="큰 글씨와 화면 그림으로 설명하는 K99 스마트 접수 시스템 V2 매장 PC 설치·사용 안내">
<title>매장 PC용 스마트 접수 시스템 V2 그림 설치·사용 설명서</title>
<style>
:root{color-scheme:light;--ink:#132d43;--red:#b91c1c;--teal:#12675e}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#eef3f4;color:var(--ink);font:24px/1.65 "Malgun Gothic","Noto Sans CJK KR",sans-serif}
button,a,input{font:inherit}a{color:#075f9c;text-underline-offset:5px}a:focus-visible,button:focus-visible{outline:5px solid #eab308;outline-offset:5px}
.toolbar{position:sticky;top:0;z-index:10;display:flex;justify-content:space-between;align-items:center;gap:16px;background:#0f2942;color:white;padding:14px max(24px,calc((100vw - 1280px)/2));box-shadow:0 4px 12px #0002}
.toolbar strong{font-size:22px}.print{border:0;border-radius:12px;background:#facc15;color:#152536;font-weight:900;cursor:pointer;padding:13px 24px;font-size:23px;white-space:nowrap}
main{max-width:1320px;margin:34px auto 60px;padding:0 24px}.sheet{scroll-margin-top:112px;background:white;border:1px solid #cbd9de;border-radius:22px;padding:38px 42px;margin:0 0 30px;box-shadow:0 8px 30px #102b4310}
h1{font-size:44px;line-height:1.35;letter-spacing:-1px;margin:18px 0}h2{font-size:34px;line-height:1.4;margin:8px 0 25px}h3{font-size:27px;margin:28px 0 15px}
p{margin:15px 0}.eyebrow{color:var(--teal);font-weight:900;font-size:22px}.lead{font-size:27px;font-weight:700}.pill{display:inline-block;background:#e5f4ed;color:#0b5c46;border-radius:30px;padding:6px 16px;font-size:20px;font-weight:800}
.notice{border-left:7px solid #eab308;background:#fffbeb;border-radius:0 12px 12px 0;padding:18px 22px;margin:24px 0;font-size:22px}
.warning{border-left-color:#dc2626;background:#fff1f2;color:#7f1d1d}.download{display:inline-block;background:#12675e;color:white;padding:19px 26px;border-radius:14px;text-decoration:none;font-size:26px;font-weight:900}
.filename{overflow-wrap:anywhere;font-weight:800}.steps-nav{display:flex;flex-wrap:wrap;gap:12px;margin-top:24px}.steps-nav a{padding:10px 16px;background:#edf4f6;border-radius:10px;font-weight:800;font-size:22px}
.step-head{display:flex;align-items:center;gap:18px;margin-bottom:10px}.step-number{width:76px;height:76px;display:grid;place-items:center;flex-shrink:0;border-radius:20px;background:#0f2942;color:#facc15;font-size:40px;font-weight:900}
.step-head h2{margin:0}.tag{display:block;color:#546875;font-size:20px;font-weight:700;margin-top:6px}.tag.pending{color:#9f3412}
figure{margin:25px 0 30px;border:2px solid #d7e1e7;border-radius:16px;overflow:hidden;background:#fff7ed}figure img{display:block;width:100%;height:auto}figcaption{background:#f0f5f7;padding:14px 20px;font-size:20px;line-height:1.6;border-top:2px solid #d7e1e7}
.instruction{list-style:none;padding:0;margin:20px 0}.instruction li{display:flex;align-items:flex-start;gap:17px;margin:19px 0}.num{display:inline-grid;place-items:center;flex-shrink:0;width:43px;height:43px;border-radius:50%;background:#dc2626;color:white;font-size:25px;font-weight:900;line-height:1}
.note{background:#eaf6f2;padding:18px 22px;border-radius:12px;font-size:22px}.keys{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:25px 0}.key{padding:22px;border:2px solid #c7d9de;border-radius:14px;background:#f7fafb}.key b{display:block;font-size:28px;color:#0b5950}.key p{font-size:22px}.key code{font-size:26px}
code{font:inherit;font-weight:800;background:#edf3f6;padding:1px 6px;border-radius:5px}table{border-collapse:collapse;width:100%;font-size:22px}th,td{border:2px solid #cfdae0;padding:15px 18px;text-align:left;vertical-align:top}th{background:#eaf2f5}
.checklist{list-style:none;padding:0}.checklist li{padding:9px 0}.checklist li:before{content:"□";font-size:29px;margin-right:14px}.small{font-size:20px;color:#435968}.footer{font-size:20px;border-top:2px solid #cbd9de;margin-top:30px;padding-top:20px}.hash{font-size:20px;overflow-wrap:anywhere;letter-spacing:.2px}
@media(max-width:800px){body{font-size:22px}.toolbar{align-items:flex-start;padding:12px 16px}.toolbar strong{font-size:20px}.print{font-size:20px;padding:12px}main{padding:0 12px;margin-top:16px}.sheet{padding:25px 18px}h1{font-size:34px}h2{font-size:29px}.keys{grid-template-columns:1fr}.step-number{width:60px;height:60px;font-size:32px}}
@page{size:A4 landscape;margin:12mm}
@media print{html{scroll-behavior:auto}body{background:white;font-size:20px;line-height:1.45;-webkit-print-color-adjust:exact;print-color-adjust:exact}.toolbar,.steps-nav,.screen-only{display:none!important}main{max-width:none;margin:0;padding:0}.sheet{box-shadow:none;border:0;border-radius:0;padding:0;margin:0 0 10mm;break-before:page}.sheet:first-child{break-before:auto}h1{font-size:34px}h2{font-size:29px}h3{font-size:24px}p{margin:8px 0}.step-number{width:58px;height:58px;font-size:32px}.step-head{break-after:avoid}figure{break-inside:avoid;margin:4mm 0}figure img{max-height:100mm;object-fit:contain;background:white}figcaption{font-size:20px;padding:8px 12px}.notice,.note{font-size:20px;padding:10px 14px}.lead{font-size:24px}.instruction li{break-inside:avoid;margin:10px 0}.key p,table{font-size:20px}.keys{break-inside:avoid}.pill,.tag,.small,.footer,.hash{font-size:20px}.download{color:#064c42;background:#e5f4ed;border:2px solid #12675e;font-size:23px}.download:after{content:"（인터넷 연결 필요）";font-size:20px}.num{width:35px;height:35px;font-size:23px}a{color:#064c42}.footer{break-inside:avoid}}
</style></head>
<body><header class="toolbar"><strong>K99 V2 · 큰 글씨 그림 설명서</strong><button class="print" type="button" onclick="window.print()">인쇄 / PDF 저장</button></header>
<main>
<section class="sheet" id="start">
  <div class="eyebrow">처음 사용하는 사장님도, 한 단계씩 천천히</div>
  <h1>매장 PC용 스마트 접수 시스템 V2<br>그림 설치·사용 설명서</h1>
  <p class="lead">설치 파일 받기 → 설치하기 → 아이콘 확인 → 고객 접수 → 기존 명단 옮기기</p>
  <span class="pill">설치 파일 2.4.3 기준 · 2026년 11월 20일 화면 확인</span>
  <div class="notice warning"><b>화면 사진 확인 안내</b><br>
  1·4·5단계는 실제로 열린 웹사이트·프로그램 화면을 캡처했습니다. 접수 화면의 고객은 설명용 가상 고객입니다.<br>
  <b>2·3단계의 Windows 화면은 아직 확보하지 못해, 실제 캡처가 아닌 순서 설명용 그림으로 표시했습니다.</b>
  실제 매장 PC 화면 두 장을 받으면 교체할 수 있습니다. 이 문서는 Windows 설치 성공을 확인한 보고서가 아닙니다.</div>
  <h3>시작 전에 세 가지만 확인하세요</h3>
  <ul class="checklist"><li>Windows 11, 64비트 매장 컴퓨터인지 확인합니다.</li><li>사용하던 접수 프로그램은 닫고, 기존 장부와 사진은 백업합니다.</li><li>USB 카메라·프린터·발판은 매장 컴퓨터에 연결합니다.</li></ul>
  <p class="note">사진 촬영과 접수는 매장 PC에 저장합니다. 설치 파일 다운로드와 AI 처방·웹 계산기는 인터넷이 필요합니다. 원래 쓰던 장부·사진 폴더를 지우지 마세요.</p>
  <nav class="steps-nav" aria-label="설명서 단계"><a href="#step-1">1. 내려받기</a><a href="#step-2">2. 설치하기</a><a href="#step-3">3. 아이콘·폴더</a><a href="#step-4">4. 고객 접수</a><a href="#step-5">5. 엑셀·외부 프로그램</a></nav>
  <p class="small">인쇄하려면 오른쪽 위 <b>[인쇄 / PDF 저장]</b>을 누르세요. 프린터 대신 <b>[PDF로 저장]</b>을 선택하면 파일로 보관할 수 있습니다. 용지는 A4 가로를 권장합니다.</p>
</section>
<section class="sheet" id="step-1">
  <div class="step-head"><span class="step-number">1</span><h2>공식 사이트를 열고 설치 파일을 받습니다<span class="tag">실제 공개 웹사이트 캡처 · 로그인하지 않은 상태</span></h2></div>
  <p>매장 컴퓨터에서 인터넷 브라우저를 열고 아래 주소로 접속하세요.</p>
  <p><a href="https://k-99-washcare-ai.replit.app">https://k-99-washcare-ai.replit.app</a></p>
  ${picture(website,'현재 공개된 K99 AI 세탁 처방 사이트의 실제 로그인 화면. 요청된 상단 다운로드 버튼은 이 화면에 표시되지 않습니다.',
    '빨간 번호 ① 현재 사이트는 로그인 화면입니다. ② 이 공개 화면에는 “매장 PC용 스마트 접수 시스템 다운로드” 버튼이 보이지 않아, 아래의 확인된 공식 설치 파일 링크를 사용합니다. 사이트에 없는 버튼을 합성하지 않았습니다.')}
  <div class="notice"><b>다운로드 버튼이 안 보여도 당황하지 마세요.</b><br>아래 초록색 단추를 한 번 누르면 설치 파일을 받을 수 있습니다. AI 처방 사이트 가입·로그인은 이 파일 다운로드의 필수 조건이 아닙니다.</div>
  <p><a class="download" href="${download}">매장 PC용 스마트 접수 시스템 다운로드</a></p>
  <ol class="instruction">${line(1,'위의 <b>초록색 다운로드 단추</b>를 한 번 누릅니다.')}${line(2,'파일 이름이 <span class="filename">K99-Smart-Laundry-V2-Setup.exe</span>인지 확인합니다.')}${line(3,'다운로드가 끝날 때까지 기다립니다. 파일이 안 보이면 키보드 <b>Ctrl + J</b>를 눌러 다운로드 목록을 엽니다.')}</ol>
  <p class="note">내려받기만으로 설치되지는 않습니다. 다음 2단계에서 받은 파일을 두 번 클릭하세요.</p>
</section>
<section class="sheet" id="step-2">
  <div class="step-head"><span class="step-number">2</span><h2>받은 파일을 두 번 클릭해 설치합니다<span class="tag pending">Windows 실제 캡처 미확보 · 아래는 버튼 순서 설명용 그림</span></h2></div>
  <p>다운로드 목록이나 <b>[다운로드]</b> 폴더에서 <span class="filename">K99-Smart-Laundry-V2-Setup.exe</span>를 <b>빠르게 두 번 클릭</b>합니다.</p>
  ${picture(diagram('protection'),'실제 캡처가 아닌 설명 그림. 파란 Windows PC 보호 창에서 추가 정보, 실행 순서로 누르는 방법.',
    '이 그림은 실제 Windows 화면이 아닙니다. [추가 정보]를 누른 다음 화면에 [실행]이 나타나는 순서를 한 장에 모아 설명했습니다. 실제 창 모양·문구는 PC마다 다를 수 있습니다.')}
  <ol class="instruction">${line(1,'파란 <b>“Windows의 PC 보호”</b> 창이 나타나면, 공식 파일이 맞는지 확인하고 <b>[추가 정보]</b>를 누릅니다.')}${line(2,'앱 이름을 다시 확인한 뒤 <b>[실행]</b>을 누릅니다. 이 파란 창이 나오지 않으면 이 과정은 건너뜁니다.')}${line(3,'설치 창의 안내에 따라 진행하고 완료될 때까지 기다립니다. 바로가기 선택 항목이 보이면 <b>바탕화면·시작 메뉴 바로가기</b>를 선택합니다.')}</ol>
  <div class="notice warning"><b>보안 기능은 끄지 마세요.</b><br>
  공식 주소에서 받은 파일이 맞을 때만 진행하세요. “위험한 앱”, “조직에서 차단”, “바이러스 발견” 안내가 나오거나 [실행] 단추가 없으면 억지로 진행하지 말고 본사에 문의하세요. 전자서명이 없어 게시자 확인 경고가 나올 수 있으며, 경고 자체가 파일의 안전을 보장하지는 않습니다.</div>
</section>
<section class="sheet" id="step-3">
  <div class="step-head"><span class="step-number">3</span><h2>바탕화면 아이콘과 저장 폴더를 확인합니다<span class="tag pending">Windows 실제 캡처 미확보 · 아래는 확인할 위치를 정리한 그림</span></h2></div>
  ${picture(diagram('desktop'),'실제 바탕화면 캡처가 아닌 구성 안내 그림. K99 스마트 접수 시스템 바로가기와 네 가지 표준 폴더.',
    '기본 설치 설정에 따른 확인 안내입니다. 실제 바탕화면과 자동 생성된 폴더는 매장 Windows PC에서 확인해야 합니다. 이미 있던 매장 폴더는 삭제하거나 이름을 바꾸지 마세요.')}
  <ol class="instruction">${line(1,'바탕화면의 <b>[K99 스마트 접수 시스템]</b> 아이콘을 두 번 클릭합니다. 별도의 명령어 입력이나 브라우저 접속은 필요 없습니다.')}${line(2,'바탕화면에 아이콘이 없으면 Windows <b>시작 메뉴</b>에서 “K99 스마트 접수 시스템”을 검색합니다.')}${line(3,'프로그램의 <b>[통합관리센터]</b>에서 현재 저장 경로와 폴더 상태를 확인합니다. 기존 과천 매장은 <b>D:&#92;K99과천매장</b>을 계속 사용할 수 있습니다.')}</ol>
  <table><thead><tr><th>폴더 이름</th><th>이곳에 저장합니다</th></tr></thead><tbody>
    <tr><td>00_프로그램 &#92; K99_명품세탁비</td><td>명품 세탁비 계산기 실행 파일</td></tr>
    <tr><td>01_고객세탁사진</td><td>접수할 때 찍은 고객 의류 사진</td></tr>
    <tr><td>02_세탁전후사진</td><td>완성해 저장한 세탁 전·후 비교 사진</td></tr>
    <tr><td>03_고객모니터영상</td><td>고객 모니터에서 보여 줄 대기 영상</td></tr>
  </tbody></table>
  <p class="note">컴퓨터마다 C:·D:·E: 드라이브 문자가 다릅니다. 기존 매장 폴더가 있으면 우선 연결하고, 없으면 사용할 수 있는 데이터 드라이브에 새 폴더를 만듭니다. <b>DB_백업</b> 폴더는 장부 백업용으로 별도 사용합니다.</p>
</section>
<section class="sheet" id="step-4">
  <div class="step-head"><span class="step-number">4</span><h2>전화번호 끝 네 자리로 찾고, 발판으로 촬영합니다<span class="tag">실제 접수 화면 캡처 · 고객 자료와 카메라는 설명·검사용</span></h2></div>
  <h3>먼저 단골 고객을 찾습니다</h3>
  ${picture(customers,'실제 접수 화면에서 전화번호 끝 1234를 입력하자 설명용 고객 두 명이 추천 목록에 나타난 모습.',
    '실제 React 접수 화면을 실행해 캡처했습니다. 고객명·전화번호는 격리된 임시 SQLite에 넣은 설명용 자료이며 실제 매장 고객이 아닙니다. 입력칸과 추천 목록을 크게 보이도록 원본 화면 일부를 확대한 그림입니다.')}
  <ol class="instruction">${line(1,'<b>[휴대전화번호]</b> 칸에 전화번호의 <b>끝 네 자리</b>를 입력합니다. 예: 1234')}${line(2,'목록이 나오면 고객 이름을 골라 누릅니다. 한 명만 일치하면 자동으로 선택될 수 있습니다. <b>이름·전체 전화번호·주소가 맞는지 꼭 확인</b>하세요.')}${line(3,'찾는 고객이 없으면 신규 고객으로 이름·전화번호를 직접 입력합니다. <b>[품목 추가]</b>로 의류를 넣고, 오른쪽에서 소재·색상을 고른 다음 <b>[촬영 창 열기]</b>를 누릅니다.')}</ol>
  <h3>촬영 창에서는 발판과 마우스가 똑같이 동작합니다</h3>
  ${picture(camera,'실제 촬영창에 사진 촬영 A F7, 확대 B F8, 1.0배 복귀, 다음 세탁물 C F9 버튼이 나란히 보이는 화면.',
    '실제 촬영창 캡처입니다. 녹색 영상은 Chromium의 카메라 검사 영상으로, 실물 USB 카메라를 검증한 사진이 아닙니다. 사진 속 QR은 설명용이므로 스캔하지 말고 실제 매장 앱의 QR을 사용하세요.')}
  <div class="keys"><div class="key"><b>① 왼쪽 발판</b><p><code>A / F7</code><br><b>사진 촬영</b></p><p>한 번 밟으면 현재 보이는 화면을 찍습니다.</p></div>
    <div class="key"><b>② 가운데 발판</b><p><code>B / F8</code><br><b>길게 누르면 확대</b></p><p>발을 떼면 배율 고정.<br>확대 중 짧게 톡 누르면 1.0배 복귀.</p></div>
    <div class="key"><b>③ 오른쪽 발판</b><p><code>C / F9</code><br><b>다음 세탁물</b></p><p>다음 옷으로 이동하며 배율이 1.0배로 돌아옵니다.</p></div></div>
  <p class="note"><b>발판이 없으면 아래 화면 버튼을 마우스로 누르세요.</b> 마우스 휠로 확대·축소하고, 확대된 화면은 드래그해 위치를 옮길 수 있습니다.</p>
  <div class="notice warning"><b>F9는 “접수 완료”가 아닙니다.</b><br>촬영이 끝나면 <b>[접수 내용 최종 확인]</b>을 마우스로 눌러 금액·선불/후불·품목을 확인하고 접수를 확정하세요. 라벨 프린터 모드에서는 같은 옷의 첫 컷에만 태그를 한 번 출력합니다. 롤태그 모드에서는 종이 출력 없이 번호를 부여합니다.</div>
  <p class="small">텍스트 입력 중에는 일반 글자 A·B·C가 발판 명령으로 처리되지 않습니다. 발판이 반응하지 않으면 촬영 화면을 클릭한 뒤 다시 사용하거나 F7·F8·F9 설정을 확인하세요.</p>
</section>
<section class="sheet" id="step-5">
  <div class="step-head"><span class="step-number">5</span><h2>기존 고객 명단을 옮기고 두 프로그램을 엽니다<span class="tag">실제 통합관리센터·가져오기·프로그램 버튼 캡처</span></h2></div>
  <h3>기존 명단은 한 번에 가져옵니다</h3>
  <p>화면 위의 <b>[통합관리센터]</b>를 누른 다음 <b>[고객 엑셀 일괄 업로드]</b>를 누릅니다.</p>
  ${picture(management,'실제 통합관리센터 상단의 고객 엑셀 일괄 업로드 단추 위치.',
    '빨간 번호 ① 통합관리센터 안의 [고객 엑셀 일괄 업로드] 단추입니다. 누르면 아래쪽의 가져오기 영역으로 이동합니다.')}
  ${picture(excel,'실제 고객 엑셀 가져오기 영역의 샘플 양식 다운로드와 고객 엑셀 일괄 업로드 단추.',
    '빨간 번호 ② 샘플 양식 다운로드, ③ 고객 엑셀 일괄 업로드입니다. 실제 Windows에서는 ③을 누르면 PC의 파일 선택 창이 열립니다. 여기서는 Windows 파일 선택 창을 실행하지 않았습니다.')}
  <ol class="instruction">${line(1,'엑셀 파일이 없으면 <b>[샘플 양식 다운로드]</b>를 눌러 양식을 받고 고객 정보를 적습니다.')}${line(2,'기존 파일이 있으면 <b>[고객 엑셀 일괄 업로드]</b>를 눌러 <b>.xlsx / .csv</b> 파일을 고릅니다. 이름과 <b>전체 전화번호</b>를 준비하세요. 주소·메모도 함께 가져올 수 있습니다.')}${line(3,'<b>“고객 N명 등록 완료”</b> 알림을 확인합니다. 같은 이름과 전체 전화번호는 중복 생성하지 않고 병합합니다. 고객 명단만 가져온 경우 <b>“주문 0건”</b>이 나와도 정상입니다.')}${line(4,'<b>[접수]</b>로 돌아가 이름 두 글자 이상 또는 전화번호 끝 네 자리로 검색해 확인합니다.')}</ol>
  <p class="note">가져오기 전 원본 엑셀을 별도 보관하세요. 오류 안내가 나오면 파일을 고쳐 다시 시도하고, 실제 고객 정보가 들어 있는 파일을 임의의 인터넷 사이트에 올리지 마세요.</p>
  <h3>명품 계산기와 AI 처방은 접수 화면 위쪽에 있습니다</h3>
  ${picture(launchers,'실제 접수 화면 상단에 나란히 놓인 명품 세탁비 산정과 AI 세탁 처방 버튼.',
    '빨간 번호 ④ 명품 세탁비 산정, ⑤ AI 세탁 처방입니다. 버튼 위치를 보여 주는 실제 화면 캡처이며 외부 프로그램의 실제 회원 로그인을 검증한 화면은 아닙니다.')}
  <table><thead><tr><th>누를 버튼</th><th>사용 방법</th></tr></thead><tbody>
    <tr><td><b>④ 명품 세탁비 산정</b></td><td>로컬 계산기가 있으면 먼저 실행합니다. 없으면 기본 웹 계산기를 엽니다. 산출한 품목명·금액은 직원이 확인한 뒤 접수에 반영합니다.</td></tr>
    <tr><td><b>⑤ AI 세탁 처방</b></td><td>현재 고른 소재·색상을 함께 전달해 처방 프로그램을 엽니다. 처음에는 해당 프로그램 로그인이 필요할 수 있으며 인터넷 연결이 필요합니다.</td></tr>
  </tbody></table>
  <div class="notice"><b>접수가 멈추면 안 됩니다.</b><br>인터넷이나 AI 처방 연결이 안 되더라도 소재·색상을 직접 고르고 접수·촬영·태그 작업을 진행하세요. 외부 프로그램 로그인과 장비 설치는 매장 PC에서 별도로 확인해야 합니다.</div>
</section>
<section class="sheet" id="finish">
  <h2>설치 후 마지막으로 확인하세요</h2>
  <ul class="checklist"><li>바탕화면 아이콘으로 프로그램이 열립니다.</li><li>내 매장 저장 경로와 사진 폴더가 맞습니다.</li><li>기존 고객을 끝 네 자리로 찾을 수 있습니다.</li><li>카메라 화면이 나오고 사진이 저장됩니다.</li><li>선택한 프린터 또는 롤태그 방식이 맞습니다.</li><li>고객 모니터와 두 외부 프로그램을 확인했습니다.</li></ul>
  <p class="note"><b>문제가 있으면 기존 프로그램·장부·사진을 지우지 마세요.</b><br>문제가 나온 화면을 휴대폰으로 찍고, 어느 단계를 진행했는지 본사에 알려 주세요.</p>
  <h3>파일 확인 정보 — 관리자·기술지원용</h3>
  <p>설치 파일: <span class="filename">K99-Smart-Laundry-V2-Setup.exe</span><br>버전: 2.4.3 / 크기: 256,795,575바이트</p>
  <p class="hash">SHA-256: 35acb436f879ab3e1f2d5599fd526da2a7b4b6bc53733af3607bdbe5240abe1b</p>
  <p><a href="${download}.sha256">공식 설치 파일의 체크섬 보기</a></p>
  <div class="footer"><b>캡처 출처와 확인 범위</b><br>
  공개 사이트: https://k-99-washcare-ai.replit.app (미로그인 실제 화면).<br>
  접수·촬영·관리센터: 현재 프로젝트의 실제 React 화면을 Chromium에서 실행해 캡처. 고객 자료는 임시 SQLite의 설명용 자료이며 Electron IPC·카메라 입력은 검사용 연결입니다.<br>
  Windows 보호 창·바탕화면·실제 폴더 생성·실물 카메라·발판·프린터·외부 프로그램 실계정 로그인은 이 설명서 제작 과정에서 직접 검증하지 않았습니다. 2·3단계는 실제 Windows 캡처를 확보하면 교체해야 합니다.<br>
  모든 그림은 문서 안에 포함되어 있어 HTML 파일 하나만 보관해도 그림이 사라지지 않습니다. 다운로드·외부 사이트 링크는 인터넷이 필요합니다.</div>
</section>
</main></body></html>`;
fs.writeFileSync(out,html);
fs.writeFileSync(path.join(dir,'manual-evidence.json'),JSON.stringify({
  version:'2.4.3',generatedAt:new Date().toISOString(),source:'actual running React / public website',
  actualScreenshots:['01-public-browser.png','04a-customer-search.png','04b-camera-controls.png','05a-management.png','05b-excel-import.png','05c-launchers.png'],
  windowsScreenshotsMissing:['Windows PC protection dialog','Installed Windows desktop and real auto-created folders'],
  diagramSteps:[2,3],downloadButtonMissingOnPublicLogin:true,syntheticCustomers:true,physicalHardwareTested:false,
  appOrInstallerModified:false,officialDownloadObservedHTTP:200,htmlBytes:Buffer.byteLength(html),
},null,2));
console.log(JSON.stringify({file:out,bytes:Buffer.byteLength(html),figures:(html.match(/<figure>/g)||[]).length,externalImages:/<img[^>]+src=\"https?:/.test(html)},null,2));
