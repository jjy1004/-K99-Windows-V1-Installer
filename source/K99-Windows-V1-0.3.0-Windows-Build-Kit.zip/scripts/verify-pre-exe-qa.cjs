'use strict';
// Read-only toward operational data: isolated fixtures only. Never stages an app,
// packages Electron/NSIS, uploads a release or publishes a service.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),out=path.join(root,'generated-artifacts/pre-exe-qa');
const setup=path.join(root,'generated-artifacts/K99-Smart-Laundry-V2-Setup.exe');
const digest=file=>fs.existsSync(file)?crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'):null;
fs.mkdirSync(out,{recursive:true});
const original=digest(setup),temp=fs.mkdtempSync(path.join(os.tmpdir(),'k99-pre-exe-qa-'));
const report={source:'Current source and freshly compiled desktop renderer, NOT a new EXE or final ZIP',
  windowsExecuted:false,physicalDevicesTested:false,externalLoginTested:false,published:false,exeBuilt:false,
  originalInstallerSHA256:original,checks:[]};
function run(name,command,args,env=process.env){
  const r=spawnSync(command,args,{cwd:root,env,encoding:'utf8',timeout:240000,maxBuffer:12*1024*1024});
  const text=(r.stdout||'')+(r.stderr||'')+(r.error?'\n'+r.error.message:'');
  fs.writeFileSync(path.join(out,name+'.log'),text);
  report.checks.push({name,passed:r.status===0&&!r.error,assertions:(text.match(/^PASS /gm)||[]).length,
    ...(name==='unit'?{summary:text.split('\n').filter(s=>/^ℹ (tests|pass|fail|skipped)/.test(s))}:{})});
  fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(report,null,2));
  if(r.status!==0||r.error)throw Error(`${name}: ${text.slice(-4000)}`);
  console.log(`PASS ${name} (${report.checks.at(-1).assertions} UI assertions)`);
}
try{
  require('./stage-windows-app.cjs').assertCleanStage(path.join(root,'generated-artifacts/windows-app'));
  const tests=['lib/k99-local','artifacts/k99-windows/electron','artifacts/k99-windows/tests','scripts/tests']
    .flatMap(dir=>fs.readdirSync(path.join(root,dir)).filter(f=>f.endsWith('.test.cjs')).map(f=>path.join(dir,f)));
  run('unit',process.execPath,['--test',...tests]);
  run('react-types','pnpm',['--filter','@workspace/k99-windows','run','typecheck']);
  run('api-types','pnpm',['--filter','@workspace/api-server','run','typecheck']);
  run('web-renderer','pnpm',['--filter','@workspace/k99-windows','run','build'],
    {...process.env,PORT:process.env.PORT||'22537',BASE_PATH:'/'});
  run('desktop-renderer','pnpm',['--filter','@workspace/k99-windows','run','desktop:build']);
  fs.cpSync(path.join(root,'artifacts/k99-windows/dist/desktop'),path.join(temp,'renderer'),{recursive:true});
  fs.cpSync(path.join(root,'generated-artifacts/windows-app/videos'),path.join(temp,'videos'),{recursive:true});
  for(const [name,flag]of [['launchers','--program-launchers-only'],['member-upload','--member-upload-only'],
    ['camera-sidebar','--reception-sidebar-only'],['full-regression',null]])
    run(name,process.execPath,['scripts/verify-native-customer-browser.cjs','--packaged-root',temp,...flag?[flag]:[]]);
  report.success=true;
}catch(error){
  report.success=false;report.error=error.message;process.exitCode=1;console.error(error.message);
}finally{
  report.installerUnchanged=digest(setup)===original;
  if(!report.installerUnchanged){report.success=false;process.exitCode=1;}
  fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(report,null,2));
  fs.rmSync(temp,{recursive:true,force:true});
}
