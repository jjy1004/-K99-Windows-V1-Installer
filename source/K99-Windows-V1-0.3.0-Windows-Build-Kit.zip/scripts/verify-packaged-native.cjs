'use strict';
// Hosted Windows ABI check only. Does not launch the app, install it, or open
// any customer database, camera, printer or production endpoint.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
if(process.platform!=='win32'||process.arch!=='x64')throw Error('Windows x64 검사 전용입니다.');
const root=path.resolve(__dirname,'..'),folder=path.join(root,'generated-artifacts/windows-installer/win-unpacked');
const exe=path.join(folder,'K99-Windows-V1.exe'),pe=fs.readFileSync(exe);
if(pe.toString('ascii',0,2)!=='MZ'||pe.readUInt16LE(pe.readUInt32LE(0x3c)+4)!==0x8664)
  throw Error('실행 파일이 AMD64 PE가 아닙니다.');
function locate(dir) {
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>{
    const p=path.join(dir,entry.name);return entry.isDirectory()?locate(p):entry.name==='better_sqlite3.node'?[p]:[];
  });
}
const bindings=locate(path.join(folder,'resources/app.asar.unpacked'));
if(bindings.length!==1)throw Error('패키징된 SQLite 네이티브 바이너리를 하나로 특정하지 못했습니다.');
const electron=require(path.join(root,'artifacts/k99-windows/node_modules/electron'));
const code=`const m=require(process.argv[1]);if(typeof m.Database!=='function')throw Error('SQLite binding missing');console.log(JSON.stringify({electron:process.versions.electron,abi:process.versions.modules,sqliteBindingLoaded:true}));`;
const result=spawnSync(electron,['-e',code,bindings[0]],{
  env:{...process.env,ELECTRON_RUN_AS_NODE:'1'},encoding:'utf8',timeout:60000,
});
if(result.error)throw result.error;
if(result.status!==0)throw Error('패키징된 SQLite의 Electron ABI 검사 실패: '+result.stderr);
const report=JSON.parse(result.stdout.trim());
if(!report.electron||!report.sqliteBindingLoaded)throw Error('Electron ABI 검증 결과 누락');
report.windows11InstallationVerified=false;report.physicalDevicesVerified=false;
fs.writeFileSync(path.join(root,'generated-artifacts/windows-installer/electron-abi-result.json'),JSON.stringify(report,null,2));
console.log('Packaged x64 payload / Electron native ABI verified. NOT a Windows 11 installation or hardware test.');
