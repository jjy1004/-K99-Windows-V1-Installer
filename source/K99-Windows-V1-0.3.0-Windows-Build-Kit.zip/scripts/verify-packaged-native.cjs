'use strict';
// Hosted Windows ABI + packaged core startup check. Uses a disposable empty DB;
// does not launch the app UI, install it, or open a store/customer database.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
if(process.platform!=='win32'||process.arch!=='x64')throw Error('Windows x64 검사 전용입니다.');
const root=path.resolve(__dirname,'..'),folder=path.join(root,'generated-artifacts/windows-installer/win-unpacked');
const builder=require('../artifacts/k99-windows/electron-builder.cjs');
const exe=path.join(folder,`${builder.executableName}.exe`),pe=fs.readFileSync(exe);
if(pe.toString('ascii',0,2)!=='MZ'||pe.readUInt16LE(pe.readUInt32LE(0x3c)+4)!==0x8664)
  throw Error('실행 파일이 AMD64 PE가 아닙니다.');
function locate(dir) {
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>{
    const p=path.join(dir,entry.name);return entry.isDirectory()?locate(p):entry.name==='better_sqlite3.node'?[p]:[];
  });
}
const bindings=locate(path.join(folder,'resources/app.asar.unpacked'));
if(bindings.length!==1)throw Error('패키징된 SQLite 네이티브 바이너리를 하나로 특정하지 못했습니다.');
// Test the actual unpacked application runtime, not a separate dev Electron.
const expectedElectron=JSON.parse(fs.readFileSync(path.join(root,'artifacts/k99-windows/node_modules/electron/package.json'))).version;
const appRequire=require('node:module').createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const asar=require('node:module').createRequire(appRequire.resolve('electron-builder'))('@electron/asar');
const archive=path.join(folder,'resources/app.asar');
// The development dependency working is not evidence that the installed app
// contains the updater or the generated provider configuration.
for(const member of ['electron/auto-update.cjs','node_modules/electron-updater/package.json']){
  if(!asar.extractFile(archive,member).length)throw Error('패키징된 자동 업데이트 모듈 누락: '+member);
}
const updateConfig=require(path.join(root,'artifacts/k99-windows/node_modules/yaml')).parse(
  fs.readFileSync(path.join(folder,'resources/app-update.yml'),'utf8'));
if(updateConfig.provider!=='github'||updateConfig.owner!=='jjy1004'||
  updateConfig.repo!=='-K99-Windows-V1-Installer')throw Error('패키징된 업데이트 배포 주소 불일치');
const applicationAudit=require('./packaged-main-audit.cjs').auditPackagedApp(archive,asar);
applicationAudit.packagedAppVersion=JSON.parse(asar.extractFile(archive,'package.json')).version;
if(applicationAudit.packagedAppVersion!==JSON.parse(fs.readFileSync(path.join(root,'artifacts/k99-windows/package.json'))).version)
  throw Error('최종 ASAR 앱 버전이 현재 소스와 다릅니다.');
const code=`
const m=require(process.argv[1]);
if(typeof m.Database!=='function')throw Error('SQLite binding missing');
const core=require(process.argv[2]);
require(process.argv[3]);
const startup=require(process.argv[4]).loadPackagedMain(process.argv[5]);
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'k99-packaged-startup-'));
let store;
try{
  store=core.createStore(path.join(temporary,'smoke.sqlite'),'smoke-only',{nativeDesktop:true});
  const notices=store.api('GET','/api/pickup-notices');
  if(notices.orders.length!==0||notices.recommendedCount!==0)throw Error('Empty pickup notice startup failed');
  const seeded=store.ensurePresentationCustomer();
  const seededCustomer=store.api('GET','/api/customers/'+seeded.customerId+'/history').customer;
  if(!seededCustomer.specialNote||seededCustomer.totalVisits!==0)throw Error('Packaged presentation customer initialization failed');
  console.log(JSON.stringify({electron:process.versions.electron,abi:process.versions.modules,
    sqliteBindingLoaded:true,coreModulesLoaded:true,emptyPickupNoticesVerified:true,presentationCustomerVerified:true,...startup}));
}finally{
  try{store?.close();}finally{fs.rmSync(temporary,{recursive:true,force:true});}
}`;
const core=path.join(folder,'resources/app.asar/electron/core');
const result=spawnSync(exe,['-e',code,bindings[0],path.join(core,'index.cjs'),path.join(core,'desktop-manager.cjs'),
  path.join(root,'scripts/packaged-main-audit.cjs'),archive],{
  env:{...process.env,ELECTRON_RUN_AS_NODE:'1'},encoding:'utf8',timeout:60000,
});
if(result.error)throw result.error;
if(result.status!==0)throw Error('패키징된 SQLite ABI/코어 시작 검사 실패: '+result.stderr);
const report=JSON.parse(result.stdout.trim());
if(!report.electron||!report.sqliteBindingLoaded||!report.coreModulesLoaded||!report.emptyPickupNoticesVerified||
  !report.packagedMainModuleLoaded||!report.packagedServicesLoaded)
  throw Error('Electron ABI/패키징 코어 시작 검증 결과 누락');
if(report.electron!==expectedElectron)throw Error(`패키징된 Electron 버전 불일치: expected ${expectedElectron}, actual ${report.electron}`);
 report.windows11InstallationVerified=false;report.physicalDevicesVerified=false;
Object.assign(report,applicationAudit);
const {VIDEO_FILES}=require('../artifacts/k99-windows/electron/customer-video.cjs');
const videos=path.join(folder,'resources/videos');
report.videos=Object.values(VIDEO_FILES).map(name=>{
  const file=path.join(videos,name);
  if(!fs.existsSync(file)||fs.statSync(file).size<12)throw Error('패키징된 안내 MP4 누락: '+file);
  const fd=fs.openSync(file,'r'),header=Buffer.alloc(12);
  try{fs.readSync(fd,header,0,12,0);}finally{fs.closeSync(fd);}
  if(header.toString('ascii',4,8)!=='ftyp')throw Error('패키징된 안내 MP4 헤더 오류: '+name);
  return {name,bytes:fs.statSync(file).size};
});
const mediaManifest=JSON.parse(fs.readFileSync(path.join(videos,'media-manifest.json'),'utf8'));
const crypto=require('node:crypto');
for(const entry of report.videos){
  const expected=mediaManifest.files[entry.name];
  if(!expected||expected.bytes!==entry.bytes||
    crypto.createHash('sha256').update(fs.readFileSync(path.join(videos,entry.name))).digest('hex')!==expected.sha256)
    throw Error('패키징된 정식 영상 해시 불일치: '+entry.name);
}
report.originalVideosVerified=true;
fs.writeFileSync(path.join(root,'generated-artifacts/windows-installer/electron-abi-result.json'),JSON.stringify(report,null,2));
console.log('Packaged x64 payload / Electron ABI / ASAR main and services imports verified. Electron app API stubbed; NOT a real window, installation or hardware test.');
