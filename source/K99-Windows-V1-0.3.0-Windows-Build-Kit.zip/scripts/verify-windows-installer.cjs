'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
if(process.platform!=='win32'||process.arch!=='x64')throw Error('Windows x64 빌드 결과 검사 전용입니다.');
const root=path.resolve(__dirname,'..'),out=path.join(root,'generated-artifacts/windows-installer');
const name='K99-Windows-V1-Setup-0.3.0-x64.exe',binary=fs.readFileSync(path.join(out,name));
if(binary.length<1024*1024||binary.toString('ascii',0,2)!=='MZ')throw Error('실제 설치 EXE 형식/크기 검사 실패');
const offset=binary.readUInt32LE(0x3c);
if(offset+4>binary.length||binary.toString('binary',offset,offset+4)!=='PE\u0000\u0000')throw Error('PE 헤더 누락');
const sha256=crypto.createHash('sha256').update(binary).digest('hex');
const declared=fs.readFileSync(path.join(out,name+'.sha256'),'utf8').trim().split(/\s+/)[0];
if(sha256!==declared)throw Error('설치 EXE SHA-256 불일치');
const abi=JSON.parse(fs.readFileSync(path.join(out,'electron-abi-result.json'),'utf8'));
if(!abi.sqliteBindingLoaded)throw Error('Electron SQLite ABI 미검증');
const manifest={filename:name,bytes:binary.length,sha256,target:'Windows x64',builtAt:new Date().toISOString(),
  host:process.platform,node:process.version,electron:abi.electron,electronABI:abi.abi,
  codeSigned:false,windows11InstallationVerified:false,physicalDevicesVerified:false};
fs.writeFileSync(path.join(out,'build-manifest.json'),JSON.stringify(manifest,null,2));
console.log(JSON.stringify(manifest,null,2));
