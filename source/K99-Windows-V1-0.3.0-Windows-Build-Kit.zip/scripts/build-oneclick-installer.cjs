'use strict';
// Cross-package an already verified Windows payload. Never rebuild native
// modules for the Linux host or disable the Windows-only source builder guard.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {createRequire}=require('node:module');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const req=createRequire(path.join(app,'package.json'));
async function main(){
  const folder=path.join(root,'generated-artifacts/windows-portable/win-unpacked');
  const verification=JSON.parse(fs.readFileSync(path.join(root,'generated-artifacts/windows-portable/verification.json')));
  const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  if(hash(path.join(folder,'resources/app.asar'))!==verification.appAsarSHA256||
     hash(path.join(folder,'K99-Laundry-V2.exe'))!==verification.exeSHA256)
    throw Error('포터블 원본의 무결성 검사가 실패했습니다.');
  const builder=req('electron-builder');
  const config={...require(path.join(app,'electron-builder.cjs')),npmRebuild:false,buildDependenciesFromSource:false};
  let result;
  const options=()=>({projectDir:path.join(root,'generated-artifacts/windows-app'),
    prepackaged:folder,targets:builder.Platform.WINDOWS.createTarget(['nsis'],builder.Arch.x64),
    config:structuredClone(config)});
  if(process.platform==='win32'){
    result=await builder.build(options());
  }else{
    // Use the builder's unmodified official template and its own PE/NSIS reader
    // in two compile passes. No Windows installer/code is executed on the host.
    // This is an explicitly UNSIGNED cross-build, not a Windows installation test.
    const builderReq=createRequire(req.resolve('electron-builder'));
    const tools=builderReq('app-builder-lib/out/targets/nsis/nsisUtil');
    const uninstaller=path.join(root,'generated-artifacts/windows-installer/cross-uninstaller.exe');
    config.win={...config.win,signAndEditExecutable:false};
    config.nsis={...config.nsis,packElevateHelper:false,
      script:path.join(tools.nsisTemplatesDir,'installer.nsi')};
    fs.mkdirSync(path.dirname(uninstaller),{recursive:true});
    // The first pass emits a generator containing the compiled uninstaller.
    // The placeholder only satisfies builder cleanup; no app data is involved.
    fs.writeFileSync(uninstaller,'temporary cleanup placeholder');
    await builder.build({...options(),effectiveOptionComputed:async([defines])=>{
      defines.BUILD_UNINSTALLER=null;defines.UNINSTALLER_OUT_FILE=uninstaller;return false;
    }});
    const generator=path.join(config.directories.output,'K99-Smart-Laundry-V2-Setup.exe');
    await tools.UninstallerReader.exec(generator,uninstaller);
    if(fs.readFileSync(uninstaller).toString('ascii',0,2)!=='MZ')throw Error('NSIS 제거 프로그램 생성 실패');
    result=await builder.build({...options(),effectiveOptionComputed:async([defines])=>{
      defines.UNINSTALLER_OUT_FILE=uninstaller;return false;
    }});
  }
  const name='K99-Smart-Laundry-V2-Setup.exe';
  const output=result.find(file=>path.basename(file)===name);
  if(!output||fs.statSync(output).size<1024*1024)throw Error('실제 설치 EXE가 생성되지 않았습니다.');
  const bytes=fs.readFileSync(output);
  if(bytes.toString('ascii',0,2)!=='MZ'||bytes.readUInt32LE(bytes.readUInt32LE(0x3c))!==0x4550)
    throw Error('설치 파일 PE 헤더 검증 실패');
  const target=path.join(root,'generated-artifacts',name);
  fs.copyFileSync(output,target);
  fs.writeFileSync(target+'.sha256',`${hash(target)}  ${name}\n`);
  const version=req('./package.json').version;
  const versionedFolder=path.join(root,'generated-artifacts/releases',version);
  fs.mkdirSync(versionedFolder,{recursive:true});
  const versionedFile=path.join(versionedFolder,name);
  fs.copyFileSync(target,versionedFile);
  fs.copyFileSync(target+'.sha256',versionedFile+'.sha256');
  const evidence={filename:name,version,versionedFile,bytes:bytes.length,sha256:hash(target),
    windowsCompatibility:verification.windowsCompatibility,
    payloadSHA256:verification.appAsarSHA256,nsisCompilePassed:true,
    windowsInstallationVerified:false,physicalDevicesVerified:false,externalAiAuthenticationVerified:false,
    codeSigned:false};
  fs.writeFileSync(path.join(root,'generated-artifacts/oneclick-installer-verification.json'),JSON.stringify(evidence,null,2));
  console.log(JSON.stringify(evidence,null,2));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
