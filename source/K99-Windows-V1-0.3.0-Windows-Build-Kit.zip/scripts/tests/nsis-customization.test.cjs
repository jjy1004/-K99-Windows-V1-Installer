'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createProbe,resolveInstallerDir}=require('../verify-nsis-customization.cjs');
test('Windows probe uses the actual installer directory, native paths and an explicit UTF-8 script file',()=>{
  const dir='D:\\a\\-K99 Windows\\과천\\build\\artifacts\\k99-windows\\installer';
  for(const uninstall of [false,true]){
    const p=createProbe({installerDir:dir,resources:'C:\\NSIS resources',out:'D:\\probe output',uninstall,platform:'win32'});
    const source=p.source.toString('utf8');
    assert.equal(p.cwd,dir);
    assert.equal(p.includePath,path.win32.join(dir,'data-preservation.nsh'));
    assert.ok(source.includes(`!addincludedir "${dir}"`));
    assert.match(source,/!include \/CHARSET=UTF8 "data-preservation\.nsh"/);
    assert.ok(!source.includes('D:/a/'));
    assert.deepEqual([...p.source.subarray(0,3)],[239,187,191]);
    assert.deepEqual(p.args,['-WX','-V3','-INPUTCHARSET','UTF8','-NOCD',p.scriptFile]);
    assert.ok(!p.args.includes('-'));
  }
});
test('POSIX probe keeps native include directory and the existing install/uninstall macros',()=>{
  for(const uninstall of [false,true]){
    const p=createProbe({installerDir:'/tmp/k99 app/installer',resources:'/tmp/resources',out:'/tmp/output',uninstall,platform:'linux'});
    assert.equal(p.cwd,'/tmp/k99 app/installer');
    assert.match(p.source.toString(),uninstall?/!insertmacro customUnInstall/:/!insertmacro customInstall/);
    assert.match(p.source.toString(),/!define SHORTCUT_NAME "K99 스마트 접수 시스템"/);
  }
});
test('real include file is required before starting NSIS; missing file gets an exact diagnostic',t=>{
  const app=fs.mkdtempSync(path.join(os.tmpdir(),'k99-nsis-'));
  t.after(()=>fs.rmSync(app,{recursive:true,force:true}));
  assert.throws(()=>resolveInstallerDir(app),/installer.*data-preservation\.nsh/);
  fs.mkdirSync(path.join(app,'installer'));
  fs.writeFileSync(path.join(app,'installer/data-preservation.nsh'),'; fixture');
  assert.equal(resolveInstallerDir(app),fs.realpathSync(path.join(app,'installer')));
});
test('dollar signs in paths stay literal and unsafe path quoting is rejected',()=>{
  const options={installerDir:'D:\\K99 $shop\\installer',resources:'C:\\resources',out:'D:\\output',platform:'win32'};
  assert.match(createProbe(options).source.toString(),/K99 \$\$shop/);
  assert.throws(()=>createProbe({...options,installerDir:'D:\\bad"\\installer'}),/문자/);
  assert.throws(()=>createProbe({...options,out:'relative'}),/절대 경로/);
});
