'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {assertCleanStage}=require('../stage-windows-app.cjs');
const {createStore}=require('../../lib/k99-local/index.cjs');
function temp(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-qa-clean-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return root;
}
test('new local installation database contains no development customers or orders and survives reopen',t=>{
  const root=temp(t),filename=path.join(root,'k99.db');
  for(let n=0;n<2;n++){
    const store=createStore(filename);
    try{
      assert.equal(store.api('GET','/api/customers/directory').customers.length,0);
      const D=require('../../lib/k99-local/node_modules/better-sqlite3'),db=new D(filename,{readonly:true});
      try{assert.equal(db.prepare('SELECT count(*) n FROM orders').get().n,0);}
      finally{db.close();}
    }finally{store.close();}
  }
});
test('distribution guard accepts code but refuses stale DB, ledger, environment and linked inputs without deleting them',t=>{
  const root=temp(t);fs.mkdirSync(path.join(root,'electron/core'),{recursive:true});
  fs.writeFileSync(path.join(root,'package.json'),'{}');
  fs.writeFileSync(path.join(root,'electron/core/catalog.json'),'{}');
  fs.writeFileSync(path.join(root,'electron/main.cjs'),'// code');
  assert.doesNotThrow(()=>assertCleanStage(root));
  for(const name of ['k99.db','k99.db-wal','.env','customers.xlsx','electron/core/k99.sqlite','electron/core/customers.csv']){
    const file=path.join(root,name);fs.writeFileSync(file,'private fixture');
    assert.throws(()=>assertCleanStage(root),/배포|장부/);
    assert.equal(fs.readFileSync(file,'utf8'),'private fixture');fs.unlinkSync(file);
  }
  const external=temp(t);fs.symlinkSync(external,path.join(root,'dist'));
  assert.throws(()=>assertCleanStage(root),/외부 연결/);
});
