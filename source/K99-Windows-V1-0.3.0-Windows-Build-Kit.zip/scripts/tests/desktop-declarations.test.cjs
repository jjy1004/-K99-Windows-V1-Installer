'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const ts = require('typescript');
const {containsInput, canonicalInputPath} = require('../build-desktop-declarations.cjs');
const root = path.resolve(__dirname, '../..');

for (const name of ['api-client-react', 'api-zod']) {
  test(`${name}: actual tsconfig includes entry point on ${process.platform}`, () => {
    const file = path.join(root, 'lib', name, 'tsconfig.json');
    const read = ts.readConfigFile(file, ts.sys.readFile);
    assert.equal(read.error, undefined);
    // Check the real extends/include configuration, not a hand-written file list.
    const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, path.dirname(file), undefined, file);
    assert.deepEqual(parsed.errors, []);
    assert.equal(read.config.extends, '../../tsconfig.base.json');
    assert.deepEqual(read.config.include, ['src']);
    assert.equal(read.config.files, undefined);
    assert.equal(read.config.exclude, undefined);
    assert.equal(parsed.projectReferences, undefined);
    assert.equal(parsed.options.composite, true);
    assert.equal(parsed.options.emitDeclarationOnly, true);
    assert.notEqual(parsed.options.noEmit, true);
    assert.ok(containsInput(parsed.fileNames, path.join(root, 'lib', name, 'src/index.ts')));
    assert.equal(canonicalInputPath(parsed.options.outDir),
      canonicalInputPath(path.join(root, 'lib', name, 'dist')));
  });

  test(`${name}: reproduce Windows mismatch through real TypeScript parser`, () => {
    const base = `D:\\a\\K99\\K99\\build\\lib\\${name}`;
    const expected = path.win32.join(base, 'src/index.ts');
    const normalized = expected.replace(/\\/g, '/');
    // Virtual Windows filesystem so this regression also runs on Linux.
    const host = {useCaseSensitiveFileNames: false, fileExists: () => true,
      readFile: () => undefined, readDirectory: () => [normalized]};
    const parsed = ts.parseJsonConfigFileContent({
      compilerOptions: {composite: true, emitDeclarationOnly: true, outDir: 'dist', rootDir: 'src'},
      include: ['src'],
    }, host, base);
    assert.deepEqual(parsed.errors, []);
    assert.deepEqual(parsed.fileNames, [normalized]);
    assert.equal(parsed.fileNames.includes(expected), false, 'old strict equality must reproduce failure');
    assert.equal(containsInput(parsed.fileNames, expected, 'win32'), true);
  });
}

test('Windows drive case, mixed separators, spaces, Unicode and dot segments', () => {
  const files = ['D:/a/과천 K99/build/lib/api-client-react/src/index.ts'];
  assert.ok(containsInput(files, 'd:\\a\\과천 K99\\build\\lib\\api-client-react\\src\\.\\index.ts', 'win32'));
  assert.ok(containsInput(['//server/share/K99/src/index.ts'], '\\\\SERVER\\share\\K99\\src\\index.ts', 'win32'));
});

test('missing entry, wrong project and wrong drive remain rejected', () => {
  const expected = 'D:\\a\\build\\lib\\api-client-react\\src\\index.ts';
  for (const files of [[], ['D:/a/build/lib/api-client-react/src/other.ts'],
    ['D:/a/build/lib/api-zod/src/index.ts'], ['E:/a/build/lib/api-client-react/src/index.ts']])
    assert.equal(containsInput(files, expected, 'win32'), false);
  assert.equal(containsInput(['/work/src/Index.ts'], '/work/src/index.ts', 'linux'), false);
});

test('actual TypeScript files/include/exclude rules cannot be bypassed by normalization', () => {
  const base = 'D:/a/build/lib/api-client-react';
  const entry = base + '/src/index.ts';
  const host = {useCaseSensitiveFileNames: false, fileExists: () => true, readFile: () => undefined,
    readDirectory: (_root, _extensions, excludes) => excludes?.includes('src/index.ts') ? [] : [entry]};
  const config = {compilerOptions: {composite: true, emitDeclarationOnly: true}, include: ['src'], exclude: ['src/index.ts']};
  const excluded = ts.parseJsonConfigFileContent(config, host, base);
  assert.equal(containsInput(excluded.fileNames, entry, 'win32'), false);
  const filesOnly = ts.parseJsonConfigFileContent({files: ['src/other.ts']}, host, base);
  assert.equal(containsInput(filesOnly.fileNames, entry, 'win32'), false);
});
