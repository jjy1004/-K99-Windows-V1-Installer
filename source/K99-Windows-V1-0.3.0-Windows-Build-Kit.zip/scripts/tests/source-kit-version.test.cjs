'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
test('workflow verifies source manifest instead of pinning an obsolete app version',()=>{
  const source=fs.readFileSync(path.join(__dirname,'../../.github/workflows/windows-installer.yml'),'utf8');
  assert.match(source,/Get-Content "source\/upload\.json" -Raw \| ConvertFrom-Json/);
  assert.match(source,/\$expectedVersion = \$upload\.version/);
  assert.match(source,/\$version -ne \$expectedVersion/);
  assert.match(source,/\$upload\.source\.sha256 -ine \$actual/);
  assert.match(source,/\$upload\.source\.bytes -ne \(Get-Item \$zip\)\.Length/);
  assert.doesNotMatch(source,/\$version -ne "\d+\.\d+\.\d+"/);
});
