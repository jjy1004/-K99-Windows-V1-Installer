'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {runInstallerCommand}=require('../run-installer-command.cjs');
test('capture original stdout, stderr and stage without pnpm error replacement',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-build-command-'));
  try {
    const logPath=path.join(dir,'build.log');
    await runInstallerCommand({command:process.execPath,args:['-e',"console.log('compiler output');console.error('builder warning')"],cwd:dir,label:'Compiler',logPath,tee:false});
    const log=fs.readFileSync(logPath,'utf8');
    assert.match(log,/compiler output/);assert.match(log,/builder warning/);assert.match(log,/PASS Compiler/);
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
test('preserve original native/NSIS error and exit code on a failed stage',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-build-command-'));
  try {
    const logPath=path.join(dir,'build.log');
    await assert.rejects(runInstallerCommand({command:process.execPath,args:['-e',"console.error('NSIS root cause example');process.exit(7)"],cwd:dir,label:'NSIS',logPath,tee:false}),
      error=>error.exitCode===7&&error.message.includes('NSIS'));
    const log=fs.readFileSync(logPath,'utf8');
    assert.match(log,/NSIS root cause example/);assert.match(log,/FAIL NSIS: exit 7/);assert.doesNotMatch(log,/PASS NSIS/);
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
test('missing compiler executable is reported, not treated as successful packaging',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-build-command-'));
  try {
    await assert.rejects(runInstallerCommand({command:path.join(dir,'missing-k99-compiler'),args:[],cwd:dir,label:'Native rebuild',logPath:path.join(dir,'build.log'),tee:false}),
      error=>error.exitCode===1&&error.message.includes('ENOENT'));
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
