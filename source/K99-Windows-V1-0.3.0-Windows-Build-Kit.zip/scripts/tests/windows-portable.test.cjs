'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {productionEndpoint,pe}=require('../build-windows-portable.cjs');
test('portable build requires a published HTTPS endpoint and rejects development/loopback/credential URLs',()=>{
  assert.equal(productionEndpoint('https://proxy.example.com'),'https://proxy.example.com/api/carelabel/analyze');
  for(const u of ['https://private.replit.dev','https://private.replit.dev.','http://proxy.example.com',
    'https://localhost','https://localhost.','https://127.0.0.1','https://[::1]',
    'https://u:p@proxy.example.com','https://proxy.example.com/?token=x','https://proxy.example.com/other'])
    assert.throws(()=>productionEndpoint(u));
});
test('portable binary check rejects Linux, 32-bit and ARM payloads',()=>{
  assert.throws(()=>pe(Buffer.from('ELF')));
  const b=Buffer.alloc(512);b.write('MZ');b.writeUInt32LE(128,0x3c);b.writeUInt32LE(0x4550,128);
  for(const machine of [0x14c,0xaa64]){b.writeUInt16LE(machine,132);assert.throws(()=>pe(b));}
  b.writeUInt16LE(0x8664,132);assert.doesNotThrow(()=>pe(b));
});
test('production exposes health, bounded AI and fixed cloud release, never desktop data APIs',()=>{
  const entry=fs.readFileSync(path.resolve(__dirname,'../../artifacts/api-server/src/carelabel-proxy.ts'),'utf8');
  assert.match(entry,/app\.get\(\[[^\]]*'\/api\/healthz'/);assert.match(entry,/app\.use\('\/api\/carelabel'/);
  assert.doesNotMatch(entry,/from ['"]\.\/routes['"]|createStore|better-sqlite3|express\.static/);
  assert.match(entry,/app\.use\('\/api\/dev-downloads',releaseDownloads\(\)\)/);
  assert.doesNotMatch(entry,/developmentDownloads|generated-artifacts/);
  const run=fs.readFileSync(path.resolve(__dirname,'../../artifacts/api-server/.replit-artifact/artifact.toml'),'utf8');
  assert.match(run,/dist\/carelabel-proxy\.mjs/);
});
test('offline server never passes readiness and requires explicit packaging consent in evidence',async()=>{
  const {probeProxy}=require('../build-windows-portable.cjs'),previous=global.fetch;
  global.fetch=async()=>new Response('<html>not live</html>',{status:404});
  try{
    const result=await probeProxy('https://proxy.example.com/api/carelabel/analyze');
    assert.equal(result.verified,false);assert.equal(result.healthStatus,404);
    assert.equal(result.analyzeValidationStatus,404);
    const builder=fs.readFileSync(path.resolve(__dirname,'../build-windows-portable.cjs'),'utf8');
    assert.match(builder,/!proxyProbe\.verified&&!allowOfflineProxy/);
    assert.match(builder,/proxyHealthVerified:proxyProbe\.verified/);
    assert.match(builder,/offlineProxyExplicitlyAllowed:allowOfflineProxy/);
  }finally{global.fetch=previous;}
});
