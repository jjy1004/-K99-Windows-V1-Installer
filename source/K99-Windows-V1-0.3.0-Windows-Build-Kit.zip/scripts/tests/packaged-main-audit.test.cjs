'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'../..');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const builderRequire=createRequire(appRequire.resolve('electron-builder'));
const asar=builderRequire('@electron/asar');
const {FileMatcher}=builderRequire('app-builder-lib/out/fileMatcher');
const {auditPackagedApp,loadPackagedMain}=require('../packaged-main-audit.cjs');
const config=require('../../artifacts/k99-windows/electron-builder.cjs');
async function fixture(t,patterns=config.files,main="require('./services/autoMessenger.js');",extra={}){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'k99-services-asar-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const stage=path.join(dir,'stage'),payload=path.join(dir,'payload'),archive=path.join(dir,'app.asar');
  const entries={'package.json':'{"type":"commonjs"}','electron/main.cjs':main,'electron/preload.cjs':"'use strict';",
    'electron/services/package.json':fs.readFileSync(path.join(root,'artifacts/k99-windows/electron/services/package.json')),
    'electron/services/autoMessenger.js':fs.readFileSync(path.join(root,'artifacts/k99-windows/electron/services/autoMessenger.js')),
    'electron/services/labelService.cjs':fs.readFileSync(path.join(root,'artifacts/k99-windows/electron/services/labelService.cjs')),
    ...extra};
  const filter=new FileMatcher(stage,payload,x=>x,patterns).createFilter();
  for(const [name,body]of Object.entries(entries)){
    const input=path.join(stage,name);fs.mkdirSync(path.dirname(input),{recursive:true});fs.writeFileSync(input,body);
    if(filter(input,fs.statSync(input))){const output=path.join(payload,name);fs.mkdirSync(path.dirname(output),{recursive:true});fs.copyFileSync(input,output);}
  }
  await asar.createPackage(payload,archive);
  return {archive,payload};
}
test('previous final builder filter reproduces missing messenger despite successful stage copy',async t=>{
  const {archive}=await fixture(t,config.files.filter(x=>x!=='electron/services/**/*'));
  assert.throws(()=>auditPackagedApp(archive,asar),/ASAR runtime file missing: electron\/services\/autoMessenger\.js/);
});
test('real builder filter preserves JavaScript and CommonJS scope in final ASAR; actual services load',async t=>{
  const {archive,payload}=await fixture(t);
  const audit=auditPackagedApp(archive,asar);
  assert(audit.requiredServiceFiles.includes('electron/services/autoMessenger.js'));
  assert(audit.asarRelativeRequires>=1);
  const env=process.env.LOCALAPPDATA;
  const loaded=loadPackagedMain(payload);
  assert.equal(loaded.packagedMainModuleLoaded,true);assert.equal(loaded.packagedServicesLoaded,true);
  assert.equal(loaded.electronAppApiStubbed,true);assert.equal(process.env.LOCALAPPDATA,env);
});
test('exact reported legacy smsMessenger reference cannot silently pass with a missing services directory',async t=>{
  const {archive}=await fixture(t,config.files,"require('../services/smsMessenger.js');");
  assert.throws(()=>auditPackagedApp(archive,asar),/electron\/main\.cjs -> \.\.\/services\/smsMessenger\.js/);
});
test('missing deferred nested local dependencies fail before installer publication',async t=>{
  const {archive}=await fixture(t,config.files,"exports.later=()=>require('./services/not-shipped.js');");
  assert.throws(()=>auditPackagedApp(archive,asar),/not-shipped\.js/);
});
test('actual service imports fail on missing external packages rather than stubbing service modules',async t=>{
  const {payload}=await fixture(t,config.files,undefined,{'electron/services/autoMessenger.js':"require('k99-intentionally-absent-package');"});
  assert.throws(()=>loadPackagedMain(payload),/k99-intentionally-absent-package/);
});
test('Windows packaged ABI gate requires actual main/services load, not only database core',()=>{
  const source=fs.readFileSync(path.join(root,'scripts/verify-packaged-native.cjs'),'utf8');
  for(const name of ['auditPackagedApp','loadPackagedMain','packagedMainModuleLoaded','packagedServicesLoaded'])assert(source.includes(name));
});
