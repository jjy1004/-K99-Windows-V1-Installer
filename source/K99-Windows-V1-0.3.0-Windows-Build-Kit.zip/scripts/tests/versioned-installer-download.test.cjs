'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),Module=require('node:module');
const {pathToFileURL}=require('node:url');
const root=path.resolve(__dirname,'../..'),req=Module.createRequire(path.join(root,'artifacts/api-server/package.json'));
const source=path.join(root,'artifacts/api-server/src/routes/development-downloads.ts');
const m=new Module(source,module);m.filename=source;m.paths=Module._nodeModulePaths(path.dirname(source));
m._compile(req('esbuild').transformSync(fs.readFileSync(source,'utf8'),{loader:'ts',format:'cjs'}).code,source);
test('new Windows installer link serves pinned release bytes only in development with no GET buffering',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'k99-download-'));
  const old=process.env.NODE_ENV;
  const name='K99-Smart-Laundry-V2-Setup.exe',relative='/windows-10-11-2.4.4/'+name;
  const bytes=Buffer.concat([Buffer.from('MZ'),Buffer.alloc(1024*1024,37)]);
  fs.mkdirSync(path.join(directory,'releases/2.4.4'),{recursive:true});
  fs.writeFileSync(path.join(directory,'releases/2.4.4',name),bytes);
  fs.writeFileSync(path.join(directory,name),'old build must not be served');
  async function serve(mode,check){
    process.env.NODE_ENV=mode;
    const app=req('express')();
    app.use((request,_response,next)=>{request.log={warn(){}};next();});
    app.use(m.exports.default(pathToFileURL(directory+path.sep)));
    const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
    try{await check('http://127.0.0.1:'+server.address().port);}
    finally{await new Promise(resolve=>server.close(resolve));}
  }
  try{
    await serve('development',async base=>{
      const response=await fetch(base+relative);
      assert.equal(response.status,200);assert.equal(response.headers.get('content-length'),null);
      assert.equal(response.headers.get('content-disposition'),`attachment; filename="${name}"`);
      assert.deepEqual(Buffer.from(await response.arrayBuffer()),bytes);
      const head=await fetch(base+relative,{method:'HEAD'});
      assert.equal(head.status,200);assert.equal(head.headers.get('content-length'),String(bytes.length));
      fs.unlinkSync(path.join(directory,'releases/2.4.4',name));
      assert.equal((await fetch(base+relative)).status,503);
    });
    await serve('production',async base=>assert.equal((await fetch(base+relative)).status,404));
  }finally{
    if(old===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=old;
    fs.rmSync(directory,{recursive:true,force:true});
  }
});
