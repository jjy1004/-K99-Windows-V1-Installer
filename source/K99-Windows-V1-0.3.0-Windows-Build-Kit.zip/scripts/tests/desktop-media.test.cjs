'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {restoreParts}=require('../restore-desktop-media.cjs');
test('original media parts join in verified order; missing/corrupt/out-of-order files fail closed',t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-parts-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
  const a=Buffer.from('first original video bytes'),b=Buffer.from('second original video bytes');
  const parts=[a,b].map((data,i)=>({name:`customer-videos.zip.part00${i+1}`,bytes:data.length,sha256:hash(data)}));
  for(const [i,p] of parts.entries())fs.writeFileSync(path.join(root,p.name),[a,b][i]);
  const m={parts,bytes:a.length+b.length,sha256:hash(Buffer.concat([a,b]))};
  const save=()=>fs.writeFileSync(path.join(root,'customer-videos.upload.json'),JSON.stringify(m));save();
  assert.deepEqual(fs.readFileSync(restoreParts(root,path.join(root,'result'))),Buffer.concat([a,b]));
  fs.writeFileSync(path.join(root,parts[0].name),Buffer.alloc(a.length));
  assert.throws(()=>restoreParts(root,path.join(root,'result')),/SHA-256/);
  fs.rmSync(path.join(root,parts[0].name));
  assert.throws(()=>restoreParts(root,path.join(root,'result')),/누락/);
  m.parts[0].name='../escape';save();
  assert.throws(()=>restoreParts(root,path.join(root,'result')),/순서/);
});
