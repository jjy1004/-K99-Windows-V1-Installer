'use strict';
const fs = require('node:fs');
const {spawn} = require('node:child_process');
// Keep the original compiler output both in Actions and in the failure artifact.
function runInstallerCommand({command, args, cwd, label, logPath, tee = true}) {
  fs.appendFileSync(logPath, `\nSTART ${label}\n`);
  if (tee) console.log(`::group::${label}`);
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {cwd, shell: false, stdio: ['ignore', 'pipe', 'pipe']});
    for (const [stream, destination] of [[child.stdout, process.stdout], [child.stderr, process.stderr]]) {
      stream.on('data', bytes => {
        fs.appendFileSync(logPath, bytes);
        if (tee) destination.write(bytes);
      });
    }
    let spawnError;
    child.on('error', error => { spawnError = error; });
    child.on('close', (code, signal) => {
      if (tee) console.log('::endgroup::');
      if (spawnError || code !== 0) {
        const error = new Error(`${label}: ${spawnError?.message || `exit ${code}, signal ${signal || 'none'}`}. Original output: packaging-console.log`);
        error.exitCode = Number.isInteger(code) && code > 0 ? code : 1;
        fs.appendFileSync(logPath, `\nFAIL ${error.message}\n`);
        reject(error);
      } else {
        fs.appendFileSync(logPath, `\nPASS ${label}\n`);
        resolve();
      }
    });
  });
}
module.exports = {runInstallerCommand};
