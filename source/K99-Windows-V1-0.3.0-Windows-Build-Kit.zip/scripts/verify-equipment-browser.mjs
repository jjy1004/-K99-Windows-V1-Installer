// Replit-only browser check. Creates ONE labelled fixture in the independent
// preview DB. Never use this against a shop or production server.
import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const profile=await fs.mkdtemp(path.join(os.tmpdir(),'k99-mock-browser-'));
const chrome=spawn('/repl/tools/bin/chromium',[
  '--headless','--no-sandbox','--disable-dev-shm-usage','--no-first-run',
  '--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank',
],{stdio:['ignore','ignore','pipe']});
let socket,seq=0;
const pending=new Map();
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const fixtureId=process.argv[2]||`TEST-EQ-${crypto.randomUUID().slice(0,8)}`;
assert.ok(/^TEST-EQ-[a-zA-Z0-9-]+$/.test(fixtureId),'Only explicitly marked test fixtures are allowed');
const output={fixtureId,deviceMode:'mock',physicalDevicesTested:false,checks:[]};
async function check(name,fn){await fn();output.checks.push(name);console.log(`PASS ${name}`);}
try {
  const endpoint=await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('Chromium debug endpoint timeout')),20000);
    chrome.stderr.on('data',chunk=>{
      const found=String(chunk).match(/DevTools listening on (ws:\/\/\S+)/);
      if(found){clearTimeout(timer);resolve(found[1]);}
    });
    chrome.on('error',reject);
    chrome.on('exit',code=>reject(new Error(`Chromium stopped: ${code}`)));
  });
  socket=new WebSocket(endpoint);
  await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
  socket.onmessage=message=>{
    const result=JSON.parse(message.data),wait=pending.get(result.id);
    if(!wait)return;
    pending.delete(result.id);clearTimeout(wait.timer);
    result.error?wait.reject(new Error(JSON.stringify(result.error))):wait.resolve(result.result);
  };
  const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
    const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(new Error(`CDP timeout ${method}`));},20000);
    pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));
  });
  async function page(url) {
    const {targetId}=await send('Target.createTarget',{url:'about:blank'});
    const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
    await send('Page.enable',{},sessionId);
    await send('Runtime.enable',{},sessionId);
    await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false},sessionId);
    await send('Page.navigate',{url},sessionId);
    const evaluate=async expression=>{
      const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId);
      if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));
      return r.result.value;
    };
    return {sessionId,evaluate};
  }
  const staff=await page('http://127.0.0.1:80/equipment');
  const wait=async (tab,expression)=>{
    for(let i=0;i<100;i++){if(await tab.evaluate(expression))return;await delay(100);}
    const diagnostics=await tab.evaluate(`({
      barcode:document.querySelector('[data-testid="input-equipment-barcode"]')?.value,
      scan:document.querySelector('[data-testid="text-scan-result"]')?.textContent,
      alerts:[...document.querySelectorAll('[role="alert"]')].map(n=>n.textContent)
    })`);
    throw new Error(`DOM condition timeout: ${expression} ${JSON.stringify(diagnostics)}`);
  };
  const selector=id=>`[data-testid="${id}"]`;
  const click=async id=>{
    const s=selector(id);
    await wait(staff,`!!document.querySelector(${JSON.stringify(s)})&&!document.querySelector(${JSON.stringify(s)}).disabled`);
    await staff.evaluate(`document.querySelector(${JSON.stringify(s)}).click()`);
    await delay(80);
  };
  const setInput=async(id,value)=>{
    await staff.evaluate(`(()=>{const el=document.querySelector(${JSON.stringify(selector(id))});el.focus();el.select();})()`);
    await send('Input.insertText',{text:value},staff.sessionId);
    await delay(80);
  };
  const ownState=()=>staff.evaluate(`fetch('/api/equipment/state').then(r=>r.json())`);
  await wait(staff,`!!document.querySelector('[data-testid="input-equipment-barcode"]')`);
  const seeded=await staff.evaluate(`(async()=>{
    const {createConfirmedOrder,insertConfirmedOrder,readConfirmedOrders}=await import('/src/order-record.ts');
    let order=readConfirmedOrders().find(o=>o.id===${JSON.stringify(fixtureId)});
    if(order&&(order.customerName!=='모의장비검증'||order.choices.customerRequests!=='자동검증용 · 매장 접수 아님'))throw Error('Not this test fixture');
    if(!order){order=createConfirmedOrder({id:${JSON.stringify(fixtureId)},customerName:'모의장비검증',customerPhone:'01000000000',customerAddress:'',
      items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:14000,isSneaker:false}]},
      {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,requestedPickupDate:'',
       waiver:'not-requested',luxuryItem:false,customerRequests:'자동검증용 · 매장 접수 아님'},new Date());
    insertConfirmedOrder(order);}
    order=readConfirmedOrders().find(o=>o.id===order.id);
    window.dispatchEvent(new Event('k99-equipment-changed'));
    return {id:order.id,garmentId:order.garments[0].garmentId};
  })()`);
  output.garmentId=seeded.garmentId;
  await click(`button-equipment-order-${seeded.id}`);
  await click(`button-equipment-garment-${seeded.garmentId}`);
  const initialState=await ownState();
  const originalPhotos=initialState.photos.filter(p=>p.orderId===seeded.id).length;
  const originalJobs=initialState.jobs.filter(j=>j.orderId===seeded.id);
  async function photo() {
    await click('button-capture');
    await click('checkbox-confirm-garment');
    await click('button-save-photo');
    await wait(staff,`!document.querySelector('[data-testid="button-save-photo"]')`);
  }
  await check('mock capture saves decoded PNG and exactly one simulated tag',async()=>{
    await photo();
    const state=await ownState(),photos=state.photos.filter(p=>p.orderId===seeded.id);
    assert.equal(photos.length,originalPhotos+1);assert.equal(photos[0].mode,'mock');
    const jobs=state.jobs.filter(j=>j.orderId===seeded.id);
    assert.equal(jobs.filter(j=>j.kind==='auto').length,1);assert.equal(jobs[0].status,'simulated');
    const decoded=await staff.evaluate(`new Promise(resolve=>{
      const img=new Image();img.onload=()=>resolve({width:img.naturalWidth,height:img.naturalHeight});
      img.onerror=()=>resolve(null);img.src=${JSON.stringify(photos[0].url)};
    })`);
    assert.ok(decoded?.width>0);
  });
  await check('recapture appends photo without duplicate auto print',async()=>{
    await photo();
    const state=await ownState();
    assert.equal(state.photos.filter(p=>p.orderId===seeded.id).length,originalPhotos+2);
    assert.equal(state.jobs.filter(j=>j.orderId===seeded.id&&j.kind==='auto').length,1);
  });
  await check('keyboard Enter looks up exact garment without workflow change',async()=>{
    await setInput('input-equipment-barcode',seeded.garmentId);
    await staff.evaluate(`document.querySelector('[data-testid="input-equipment-barcode"]').focus()`);
    await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r',unmodifiedText:'\r'},staff.sessionId);
    await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},staff.sessionId);
    await wait(staff,`document.querySelector('[data-testid="text-scan-result"]')?.textContent.includes('조회 완료')`);
  });
  await check('unknown tag is rejected without creating an order',async()=>{
    const before=(await ownState()).orders.length;
    await setInput('input-equipment-barcode',`UNKNOWN-${fixtureId}`);
    await click('button-equipment-scan');
    await wait(staff,`document.querySelector('[data-testid="text-scan-result"]')?.textContent.includes('없는 태그')`);
    assert.equal((await ownState()).orders.length,before);
  });
  await check('reasoned reprint creates a separate simulated history row',async()=>{
    await setInput('input-reprint-reason','자동검증 재출력');
    await click('button-reprint');
    await wait(staff,`document.querySelector('[data-testid="input-reprint-reason"]').value===''`);
    const jobs=(await ownState()).jobs.filter(j=>j.orderId===seeded.id);
    assert.equal(jobs.filter(j=>j.kind==='reprint').length,originalJobs.filter(j=>j.kind==='reprint').length+1);
    assert.ok(jobs.some(j=>j.kind==='reprint'&&j.status==='simulated'));
  });
  await check('customer view is synchronized, masked and read-only',async()=>{
    await click('button-equipment-publish');
    const customer=await page('http://127.0.0.1:80/equipment/customer');
    await wait(customer,`document.querySelector('[data-testid="text-customer-total"]')?.textContent.includes('5,000')`);
    const result=await customer.evaluate(`({
      text:document.body.innerText,buttons:document.querySelectorAll('button,input,select').length,
      name:document.querySelector('[data-testid="text-customer-name"]')?.textContent
    })`);
    assert.ok(result.text.includes('와이셔츠'));assert.ok(result.name.includes('*'));
    assert.equal(result.buttons,0);assert.ok(!result.text.includes('01000000000'));
    await fs.mkdir('generated-artifacts',{recursive:true});
  });
  await fs.writeFile('generated-artifacts/stage2-browser-result.json',JSON.stringify(output,null,2));
  console.log(JSON.stringify(output,null,2));
}finally{
  socket?.close();chrome.kill('SIGTERM');
  await delay(500);await fs.rm(profile,{recursive:true,force:true});
}
