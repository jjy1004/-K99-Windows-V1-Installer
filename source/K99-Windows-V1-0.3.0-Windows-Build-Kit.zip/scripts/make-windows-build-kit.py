"""Offline source delivery only. No node_modules, user data, keys or cloud DB."""
from pathlib import Path
import hashlib
import zipfile
import json

root = Path(__file__).resolve().parent.parent
out = root / "generated-artifacts/K99-Windows-V1-0.3.0-Windows-Build-Kit.zip"
out.parent.mkdir(exist_ok=True)
files = [
    "package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml", "tsconfig.base.json",
    ".github/workflows/windows-installer.yml",
    "scripts/check-package-manager.cjs", "scripts/stage-windows-app.cjs",
    "scripts/build-windows-installer.cjs", "docs/windows-stage1.md",
    "scripts/build-desktop-declarations.cjs",
    "scripts/tests/desktop-declarations.test.cjs",
    "scripts/run-installer-command.cjs", "scripts/verify-nsis-customization.cjs",
    "scripts/verify-desktop-media.cjs",
    "scripts/restore-desktop-media.cjs", "scripts/tests/desktop-media.test.cjs",
    "scripts/verify-native-customer-browser.cjs",
    "scripts/test-desktop-field-ui.cjs",
    "scripts/tests/installer-command.test.cjs",
    "scripts/verify-packaged-native.cjs", "scripts/verify-windows-installer.cjs",
    "docs/windows-automatic-build.md",
    "docs/windows-stage2.md", "docs/windows-stage3.md", "docs/windows11-acceptance.md",
    "docs/windows-field-operations.md",
    "docs/windows-care-label-ai.md", "docs/windows-hybrid-photo-update.md", "docs/windows-automatic-material-tags.md",
    "docs/windows-ui-ux-update.md",
    "docs/windows-customer-directory.md",
    "docs/windows-unified-orders.md",
    "docs/windows-native-ledger.md", "docs/windows-v2-store-audit.md", "docs/windows-customer-autofill.md", "docs/windows-today-ime.md", "scripts/verify-real-native-ledger.cjs",
    "scripts/import-local-ledger.cjs",
]
folders = [
    "artifacts/k99-windows", "lib/k99-local", "lib/api-client-react",
    "lib/api-zod", "lib/api-spec",
]
skip = {"node_modules", ".git", ".local", "dist", "build", "generated-artifacts", "local-data", "__pycache__"}
seen = set()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
    def add(p):
        rel = p.relative_to(root)
        if rel.as_posix() in seen or any(part in skip for part in rel.parts):
            return
        if p.is_symlink() or p.name.startswith(".env") or p.suffix in {".sqlite", ".db", ".k99backup", ".tsbuildinfo", ".pem", ".key"}:
            return
        if p.suffix.lower() == ".mp4" or p.name in {"media-manifest.json", "placeholder-manifest.json"}:
            return  # Original videos are shipped in upload-safe companion parts.
        seen.add(rel.as_posix())
        archive.write(p, rel.as_posix())
    for name in files:
        add(root / name)
    for folder in folders:
        for p in (root / folder).rglob("*"):
            if p.is_file():
                add(p)
    # The offline kit has no PostgreSQL package or API server.
    config = json.loads((root / "tsconfig.json").read_text())
    config["references"] = [r for r in config["references"] if r["path"] != "./lib/db"]
    archive.writestr("tsconfig.json", json.dumps(config, indent=2))
    archive.writestr("README-WINDOWS.md", (root / "docs/windows-today-ime.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-customer-autofill.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-v2-store-audit.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-stage3.md").read_text())
    archive.writestr(".gitignore", "node_modules/\ngenerated-artifacts/\nlocal-data/\n")
checksum = hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix(".zip.sha256").write_text(checksum + "  " + out.name + "\n")
print(f"{out.relative_to(root)} ({out.stat().st_size} bytes)")

media = root / "generated-artifacts/customer-videos.zip"
with zipfile.ZipFile(media, "w", zipfile.ZIP_DEFLATED) as archive:
    for name in ("value.mp4", "process.mp4", "water.mp4", "sneakers.mp4", "media-manifest.json"):
        file = root / "generated-artifacts/customer-videos" / name
        if not file.is_file():
            raise RuntimeError(f"Original video input missing: {file}")
        archive.write(file, "artifacts/k99-windows/media/videos/" + name)
parts = []
upload = {"bytes": media.stat().st_size, "sha256": hashlib.sha256(media.read_bytes()).hexdigest(), "parts": []}
with media.open("rb") as source:
    for n in range(1, 33):
        data = source.read(20 * 1024 * 1024)
        if not data:
            break
        part = root / f"generated-artifacts/customer-videos.zip.part{n:03}"
        part.write_bytes(data)
        parts.append(part)
        upload["parts"].append({"name": part.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
upload_manifest = root / "generated-artifacts/customer-videos.upload.json"
upload_manifest.write_text(json.dumps(upload, indent=2))

# A separate, already-approved private repository upload package. Never put
# the developer workspace, .git history, DB, photos, keys or env files in it.
repo = root / "generated-artifacts/K99-Windows-V1-0.3.0-Field-Operations-Upload.zip"
with zipfile.ZipFile(repo, "w", zipfile.ZIP_DEFLATED) as archive:
    archive.write(root / ".github/workflows/windows-installer.yml", ".github/workflows/windows-installer.yml")
    archive.write(out, "source/" + out.name)
    archive.write(out.with_suffix(".zip.sha256"), "source/" + out.name + ".sha256")
    for part in parts:
        archive.write(part, "source/" + part.name)
    archive.write(upload_manifest, "source/" + upload_manifest.name)
    archive.writestr("source/upload.json", json.dumps({
        "patchId": "V2-PICKUP-STARTUP-20261105", "version": "0.3.0",
        "source": {"name": out.name, "bytes": out.stat().st_size,
                   "sha256": hashlib.sha256(out.read_bytes()).hexdigest()},
        "installer": "K99-Windows-V1-Setup-0.3.0-x64.exe",
        "windowsVerified": False,
    }, ensure_ascii=False, indent=2))
    archive.writestr("README.md", (root / "docs/windows-today-ime.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-customer-autofill.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-v2-store-audit.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-field-operations.md").read_text()
                      + "\n\n---\n\n" + (root / "docs/windows-automatic-build.md").read_text())
repo.with_suffix(".zip.sha256").write_text(hashlib.sha256(repo.read_bytes()).hexdigest() + "  " + repo.name + "\n")
print(f"{repo.relative_to(root)} ({repo.stat().st_size} bytes)")
with zipfile.ZipFile(repo) as full:
    groups = [
        ("Source-Upload", [n for n in full.namelist() if ".zip.part" not in n]),
        ("Videos-1-of-2", ["source/" + p.name for p in parts[:4]]),
        ("Videos-2-of-2", ["source/" + p.name for p in parts[4:]]),
    ]
    for label, names in groups:
        target = root / f"generated-artifacts/K99-Windows-V1-0.3.0-{label}.zip"
        with zipfile.ZipFile(target, "w", zipfile.ZIP_STORED) as delivered:
            for name in names:
                delivered.writestr(name, full.read(name))
        if target.stat().st_size > 100 * 1024 * 1024:
            raise RuntimeError(f"Delivery exceeds asset upload limit: {target.name}")
        checksum = hashlib.sha256(target.read_bytes()).hexdigest()
        target.with_suffix(".zip.sha256").write_text(f"{checksum}  {target.name}\n")
        print(f"{target.name}: {target.stat().st_size} bytes; SHA256 {checksum}")
