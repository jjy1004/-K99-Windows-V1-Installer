'use strict';
// Cross-package only with official, checksum-verified Windows binaries.
// Does not bypass build-windows-installer.cjs or claim Windows runtime verification.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {Readable}=require('node:stream'),{pipeline}=require('node:stream/promises');
const {spawnSync}=require('node:child_process'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'..'),generated=path.join(root,'generated-artifacts');
const cache=path.join(generated,'windows-portable-vendor');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const rebuildRequire=createRequire(appRequire.resolve('@electron/rebuild'));
const builderRequire=createRequire(appRequire.resolve('electron-builder'));
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const sha=file=>digest(fs.readFileSync(file));
const pe=bytes=>{
  if(bytes.length<256||bytes.toString('ascii',0,2)!=='MZ')throw Error('Not a Windows PE binary');
  const offset=bytes.readUInt32LE(0x3c);
  if(offset+6>bytes.length||bytes.readUInt32LE(offset)!==0x4550||bytes.readUInt16LE(offset+4)!==0x8664)
    throw Error('Not an AMD64 Windows PE binary');
};
function productionEndpoint(value){
  const u=new URL(value);
  const hostname=u.hostname.replace(/\.$/,'');
  if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.port||
    hostname.endsWith('.replit.dev')||hostname==='localhost'||hostname.includes(':')||/^[\d.]+$/.test(hostname)||
    !['/','/api/carelabel/analyze'].includes(u.pathname))throw Error('A verified, published HTTPS domain is required; development URLs are not allowed');
  u.pathname='/api/carelabel/analyze';return u.href;
}
async function getJson(url){
  const r=await fetch(url,{headers:{'User-Agent':'K99-Windows-portable-build'},signal:AbortSignal.timeout(30000)});
  if(!r.ok)throw Error(`Vendor metadata HTTP ${r.status}`);return r.json();
}
async function download(url,file,expected){
  if(!/^[a-f0-9]{64}$/.test(expected))throw Error('Missing vendor SHA-256');
  if(fs.existsSync(file)&&sha(file)===expected)return;
  const temporary=file+'.part';
  try{
    const r=await fetch(url,{headers:{'User-Agent':'K99-Windows-portable-build'},signal:AbortSignal.timeout(240000)});
    if(!r.ok||!r.body)throw Error(`Vendor download HTTP ${r.status}`);
    await pipeline(Readable.fromWeb(r.body),fs.createWriteStream(temporary));
    if(sha(temporary)!==expected)throw Error('Vendor SHA-256 mismatch');
    fs.renameSync(temporary,file);
  }finally{fs.rmSync(temporary,{force:true});}
}
async function prepare(){
  fs.mkdirSync(cache,{recursive:true});
  const electron=appRequire('electron/package.json').version;
  const sqlite=createRequire(path.join(root,'lib/k99-local/package.json'))('better-sqlite3/package.json').version;
  const abi=rebuildRequire('node-abi').getAbi(electron,'electron');
  const electronName=`electron-v${electron}-win32-x64.zip`;
  const electronBase=`https://github.com/electron/electron/releases/download/v${electron}/`;
  const sums=await fetch(electronBase+'SHASUMS256.txt',{signal:AbortSignal.timeout(30000)});
  if(!sums.ok)throw Error('Electron checksum manifest unavailable');
  const line=(await sums.text()).split('\n').find(s=>s.trim().split(/\s+/).at(-1)?.replace(/^\*/,'')===electronName);
  if(!line)throw Error('Exact Windows Electron checksum missing');
  const electronHash=line.trim().split(/\s+/)[0];
  const release=await getJson(`https://api.github.com/repos/WiseLibs/better-sqlite3/releases/tags/v${sqlite}`);
  const sqliteName=`better-sqlite3-v${sqlite}-electron-v${abi}-win32-x64.tar.gz`;
  const asset=release.assets?.find(a=>a.name===sqliteName);
  if(!asset||!/^sha256:[a-f0-9]{64}$/.test(asset.digest||''))throw Error('Exact Windows Electron SQLite prebuild with vendor digest is unavailable; Windows build is required');
  const electronZip=path.join(cache,electronName),sqliteTar=path.join(cache,sqliteName);
  await Promise.all([download(electronBase+electronName,electronZip,electronHash),
    download(asset.browser_download_url,sqliteTar,asset.digest.slice(7))]);
  const extract=path.join(cache,'sqlite');fs.mkdirSync(extract,{recursive:true});
  await rebuildRequire('tar').x({file:sqliteTar,cwd:extract,strict:true,
    filter:p=>p.replace(/^\.\//,'')==='build/Release/better_sqlite3.node'});
  const binding=path.join(extract,'build/Release/better_sqlite3.node'),bytes=fs.readFileSync(binding);pe(bytes);
  if(!bytes.includes(Buffer.from(`node_register_module_v${abi}`)))throw Error('Actual SQLite binary does not export the selected Electron ABI');
  const result={electron,sqlite,abi,electronZip,sqliteTar,binding,electronHash,sqliteHash:asset.digest.slice(7),
    bindingHash:sha(binding),sqliteMachine:'AMD64',sqliteAbiExport:`node_register_module_v${abi}`,
    windowsRuntimeVerified:false};
  fs.writeFileSync(path.join(cache,'verified-vendors.json'),JSON.stringify(result,null,2));
  console.log(`Verified official Windows x64 vendors: Electron ${electron}; SQLite ${sqlite}; ABI ${abi}`);
  return result;
}
function run(command,args,cwd){
  const result=spawnSync(command,args,{cwd,stdio:'inherit',timeout:180000});
  if(result.error)throw result.error;
  if(result.status!==0)throw Error(`${command} failed with exit ${result.status}`);
}
function allFiles(dir){
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{
    const file=path.join(dir,e.name);
    if(e.isSymbolicLink())throw Error('Unexpected symbolic link in portable payload');
    return e.isDirectory()?allFiles(file):[file];
  });
}
async function probeProxy(endpoint){
  const report={verified:false,healthStatus:null,analyzeValidationStatus:null,error:''};
  try{
    const health=await fetch(new URL('/api/healthz',endpoint),{signal:AbortSignal.timeout(20000)});
    report.healthStatus=health.status;
    let body;try{body=JSON.parse(await health.text());}catch{}
    const rejected=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(20000)});
    report.analyzeValidationStatus=rejected.status;
    report.verified=health.ok&&body?.service==='k99-carelabel-proxy'&&rejected.status===400;
    if(!report.verified)report.error='Published proxy is not ready or does not expose the expected AI-only API';
  }catch(error){report.error=error.name==='TimeoutError'?'Published proxy probe timed out':'Published proxy is unreachable';}
  return report;
}
async function build(proxyUrl,{allowOfflineProxy=false,offline=false}={}){
  const endpoint=productionEndpoint(proxyUrl),vendor=await prepare();
  const proxyProbe=offline?{verified:false,healthStatus:null,analyzeValidationStatus:null,skipped:true,error:'Offline build: optional AI only'}:await probeProxy(endpoint);
  if(!proxyProbe.verified&&!allowOfflineProxy&&!offline)throw Error('Published AI-only proxy health check failed. Offline packaging requires explicit --allow-offline-proxy and records AI as unavailable.');
  if(offline)console.log('Offline reception: mandatory proxy check skipped. AI is optional and not verified.');
  else if(!proxyProbe.verified)console.warn('WARNING: AI proxy is NOT ready. Packaging the configured domain without claiming AI availability:',JSON.stringify(proxyProbe));
  require('./verify-desktop-media.cjs').mediaFiles();
  // Never package a stale renderer left by an earlier source revision.
  run('pnpm',['--filter','@workspace/k99-windows','run','desktop:build'],root);
  const stage=require('./stage-windows-app.cjs').stage();
  const manifest=JSON.parse(fs.readFileSync(path.join(stage,'package.json')));
  manifest.k99CareLabelProxyUrl=endpoint;
  manifest.k99OfflineReception=true;
  fs.writeFileSync(path.join(stage,'package.json'),JSON.stringify(manifest,null,2));
  run('pnpm',['--dir',stage,'--ignore-workspace','install','--prod','--ignore-scripts','--frozen-lockfile','--config.node-linker=hoisted'],root);
  // pnpm's Linux-only command shims are not application runtime files.
  require('./stage-windows-app.cjs').assertCleanStage(stage);
  // Remove only .bin; keep every installed runtime package and reject any other symlink.
  fs.rmSync(path.join(stage,'node_modules/.bin'),{recursive:true,force:true});
  const installed=JSON.parse(fs.readFileSync(path.join(stage,'node_modules/better-sqlite3/package.json')));
  if(installed.version!==vendor.sqlite)throw Error('Runtime SQLite version mismatch');
  const nativeTarget=path.join(stage,'node_modules/better-sqlite3/build/Release/better_sqlite3.node');
  fs.mkdirSync(path.dirname(nativeTarget),{recursive:true});fs.copyFileSync(vendor.binding,nativeTarget);
  const natives=allFiles(stage).filter(f=>f.endsWith('.node'));
  if(natives.length!==1||sha(natives[0])!==vendor.bindingHash)throw Error('Unexpected or non-Windows native module in payload');
  const folder=path.join(generated,'windows-portable/win-unpacked');
  fs.rmSync(folder,{recursive:true,force:true});fs.mkdirSync(folder,{recursive:true});
  run('python',['-c',`import zipfile,sys,pathlib
with zipfile.ZipFile(sys.argv[1]) as z:
 for n in z.namelist():
  p=pathlib.PurePosixPath(n)
  if p.is_absolute() or '..' in p.parts: raise ValueError('Unsafe vendor archive')
 z.extractall(sys.argv[2])
`,vendor.electronZip,folder],root);
  const exe=path.join(folder,'K99-Laundry-V2.exe');
  fs.renameSync(path.join(folder,'electron.exe'),exe);pe(fs.readFileSync(exe));
  const resedit=builderRequire('resedit');
  const executable=resedit.NtExecutable.from(fs.readFileSync(exe));
  const resource=resedit.NtExecutableResource.from(executable);
  const icons=resedit.Data.IconFile.from(fs.readFileSync(path.join(root,'artifacts/k99-windows/installer/k99-reception.ico')));
  resedit.Resource.IconGroupEntry.replaceIconsForResource(resource.entries,1,1033,icons.icons.map(icon=>icon.data));
  resource.outputResource(executable);fs.writeFileSync(exe,Buffer.from(executable.generate()));pe(fs.readFileSync(exe));
  const manifests=resource.entries.filter(entry=>entry.type===24).map(entry=>Buffer.from(entry.bin).toString('utf8')).join('\n');
  if(!/requestedExecutionLevel\s+level="asInvoker"/.test(manifests)||
    !manifests.toLowerCase().includes('{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}'))
    throw Error('Windows x64 application manifest must declare asInvoker and Windows 10/11 compatibility');
  const resources=path.join(folder,'resources');fs.mkdirSync(resources,{recursive:true});
  fs.rmSync(path.join(resources,'default_app.asar'),{force:true});
  await builderRequire('@electron/asar').createPackageWithOptions(stage,path.join(resources,'app.asar'),{
    unpack:'**/*.node',globOptions:{dot:true,ignore:[path.join(stage,'videos/**')]}});
  fs.cpSync(path.join(stage,'videos'),path.join(resources,'videos'),{recursive:true});
  const unpacked=path.join(resources,'app.asar.unpacked/node_modules/better-sqlite3/build/Release/better_sqlite3.node');
  if(sha(unpacked)!==vendor.bindingHash)throw Error('Packaged native binding checksum mismatch');
  const packedManifest=JSON.parse(builderRequire('@electron/asar').extractFile(path.join(resources,'app.asar'),'package.json').toString());
  if(packedManifest.k99CareLabelProxyUrl!==endpoint)throw Error('Packaged proxy URL mismatch');
  const evidence={format:'win-unpacked',appVersion:packedManifest.version,electron:vendor.electron,sqlite:vendor.sqlite,abi:vendor.abi,
    windowsCompatibility:{minimum:'Windows 10',architecture:'x64',windows11Supported:true,
      applicationManifestVerified:true,executionLevel:'asInvoker',hardwareAcceleration:false,
      windows10ExecutionVerified:false,windows11ExecutionVerified:false},
    proxy:endpoint,proxyHealthVerified:proxyProbe.verified,proxyProbe,offlineProxyExplicitlyAllowed:allowOfflineProxy||offline,
    offlineReception:true,automaticAI:false,optionalAIOnly:true,
    vendorChecksumsVerified:true,sqliteAbiExport:vendor.sqliteAbiExport,
    nativeBindingSHA256:vendor.bindingHash,exeSHA256:sha(exe),appAsarSHA256:sha(path.join(resources,'app.asar')),
    windowsExecutionVerified:false,windowsInstallationVerified:false,physicalDevicesVerified:false,
    signing:'Unsigned application',dataLocation:'Existing K99-Windows-V1 userData; not this portable folder'};
  fs.writeFileSync(path.join(folder,'portable-verification.json'),JSON.stringify(evidence,null,2));
  fs.copyFileSync(path.join(root,'artifacts/k99-windows/PROGRAM-INTEGRATIONS.md'),path.join(folder,'외부프로그램-연동안내.md'));
  fs.writeFileSync(path.join(folder,'사용안내.txt'),
    'ZIP을 완전히 풀고 K99-Laundry-V2.exe를 더블클릭하세요. PowerShell/브라우저 실행은 필요 없습니다.\r\n'+
    '기존 앱을 먼저 종료하고 DB/사진을 백업하세요. 기존 K99 사용자 데이터는 이 폴더에 포함되지 않습니다.\r\n'+
    '공식 Windows x64 바이너리의 해시/ABI/패키지 구성을 검사했으나 실제 Windows 실행·매장 장비 검증은 아직 하지 않았습니다.\r\n'+
    '서명되지 않은 시험용 포터블입니다. 접수·촬영·태그 출력·이력·영상은 인터넷 없이 실행됩니다.\r\n'+
    '2.4.0: 기존 저장 루트 우선 보존 후 D/외장 로컬 데이터 드라이브/C를 자동 탐색합니다. 신규 루트는 K99_스마트접수이며 계산기·사진·비교·영상·DB_백업 폴더를 만듭니다. 저장 드라이브 변경은 기존 파일을 이동하지 않고 접수가 없을 때 확인 후 다시 시작합니다. 계산기 표준 폴더의 exe를 우선 실행하고 A/B/C와 F7/F8/F9, 마우스 촬영·확대·복귀·다음을 지원합니다. 전후 사진은 프레임을 채우며 가장자리가 일부 잘릴 수 있습니다. USB 장치 이름 기반 선택·모의 재연결은 검사했지만 실제 Windows 장치 감지 0.5초와 장비 실행은 별도 현장 검증입니다.\r\n'+
    '2.3.7: AI 처방은 persist:k99-ai 영구 세션을 사용하며 기존 처방 세션 폴더를 원본 보존 상태로 한 번 승계합니다. 통합관리센터 · 외부 프로그램 연동의 연결 계정은 같은 Windows 사용자의 DPAPI로 암호화해 설치 폴더 밖에 저장합니다. 비밀번호는 영문 1자+숫자 4자이며 공식 처방 사이트에만 HTTPS POST로 전달합니다. 계정을 비우면 브라우저 기기 인증·쿠키만 사용하며 사이트 로그아웃과는 별개입니다. 서버의 이용 기간·기기 승인·인증 취소는 우회하지 않습니다. Windows 사용자 변경/저장소 삭제/서버 만료 시 재인증이 필요할 수 있습니다. 실제 매장 계정의 자동 로그인은 별도 검증입니다.\r\n'+
    '2.3.6: F7/왼쪽 버튼 촬영, F8/가운데 버튼은 0.2초 이상 누르면 1~3.5배 연속 디지털 확대, 짧게 누르면 1배 복귀합니다. 휠 확대·축소와 드래그 이동을 지원하며 화면과 같은 영역을 저장합니다. F9/오른쪽 버튼은 다음 세탁물로 이동하면서 1배 중앙으로 복귀합니다. 접수 최종 확인은 화면 버튼으로만 진행합니다.\r\n'+
    '2.3.5: 카메라 선택 시 지정한 장치만 연결합니다. 가상 카메라는 직접 선택하기 전 자동 선택하지 않습니다. 선택 변경 즉시 미리보기를 다시 연결하며 실패 사유를 중앙에 표시합니다. 실제 Windows USB/OBS 장비 검증은 별도입니다.\r\n'+
    'AI 라벨 분석 버튼만 선택형 온라인 기능이며 3초 내 결과가 없으면 조용히 종료합니다. 인쇄는 상단 소재·색상 선택값만 사용합니다.\r\n'+
    '2.2.0: 기존 D:\\K99과천매장이 있으면 유지하고, 신규 PC는 D:\\K99스마트접수 또는 D: 미존재 시 C:\\K99스마트접수에 사진·DB_백업·03_고객모니터영상 폴더를 만듭니다.\r\n'+
    '접수 상단 2열 런처와 외부프로그램-연동안내.md를 추가했습니다. 명품 계산기 실행 파일 또는 URL은 관리자가 별도 설정합니다. AI 처방 URL은 공란이면 준비 중입니다.\r\n'+
    '2.3.0: 출고 대기 카드의 품목명을 확대하고 사진 폴더 바로 열기를 추가했습니다. 세탁 전후 사진에서는 원·사각형 표시, 빨강·파랑, 설명 글자 크기를 바꿔 합성 JPEG로 저장합니다. 원본 사진은 수정하지 않습니다.\r\n'+
    '2.3.1: 통합관리센터의 설정 · 출고 완료 접수 사진 자동 삭제에서 30/60/90일 또는 사용 안 함을 선택합니다(기본 60일). 최종 출고 완료일 기준으로 하루 1회 정리하며, 설정 저장 후 지금 즉시 정리 실행도 가능합니다.\r\n'+
    '2.3.4: 출고 검색은 조회만 수행하며 명시적 버튼으로만 출고·출고 대기 복구합니다. 직전 출고 취소는 결제·환불·기존 알림·사진을 변경하지 않습니다. 복구 후 재출고한 최종 출고일부터 사진 정리 기간을 계산합니다. AI 세탁 처방 기본 주소와 영구 웹 세션을 내장했습니다. 실제 Windows 로그인·모니터·IME·장비 검증은 별도입니다.\r\n'+
    '정리는 01_고객세탁사진의 해당 폴더를 휴지통 없이 영구 삭제합니다. 출고 대기·배달 중·미확정 사진·공유 폴더의 미도래 주문은 보존합니다. 고객/주문 DB·02_세탁전후사진·내부 사진 보존 사본·기존 백업은 삭제하지 않습니다. 보존 사본을 다시 열거나 복구하면 접수 사진 폴더가 다시 생성될 수 있습니다.\r\n'+
    'After 휴대폰 QR은 같은 내부망의 별도 임시 포트 5051을 사용합니다(기존 접수 QR 5050 유지). Windows 방화벽은 개인 네트워크에서만 허용하고, 공유기 클라이언트 격리를 해제해야 연결됩니다. 여러 장을 보내면 마지막 사진이 After에 표시됩니다.\r\n'+
    'SQLite 장부는 기존 Windows 사용자 K99WindowsV1\\data 위치 그대로입니다. 앱과 사진 폴더를 임의 이동·삭제하지 마세요.\r\n'+
    '첫 실행 시 Windows 로그인 자동 실행을 등록합니다. 데이터 보존·복구 화면의 스위치와 저장 버튼으로 끌 수 있습니다. 포터블 폴더를 옮겼다면 한 번 직접 실행해 등록 경로를 갱신하세요.\r\n'+
    'TSC/Xprinter 선택 후 장비 설정에서 실제 30mm 용지 및 출력 확인을 완료하세요. 드라이버는 제조사에서 설치해야 하며 자동으로 설치하지 않습니다.\r\n'+
    'V1 DB 가져오기는 현재 장부와 병합하지 않습니다. 안전 백업 후 선택한 V1 DB로 전환합니다. 원본 DB와 같은 폴더의 photos를 함께 준비하세요.\r\n'+
    '고객 엑셀은 통합관리센터에서 업로드·샘플 CSV 저장이 가능합니다. 누적금액은 고객 요약으로 보존하며 임의 매출·주문을 만들지 않습니다.\r\n'+
    '처음 카메라 권한 요청은 허용해야 합니다. USB 미연결 시 QR 촬영을 사용하세요. 모바일은 같은 내부망과 방화벽 허용이 필요합니다.\r\n');
  run(process.execPath,[path.join(__dirname,'verify-windows-portable.cjs')],root);
  const version=JSON.parse(fs.readFileSync(path.join(root,'artifacts/k99-windows/package.json'),'utf8')).version;
  const zip=path.join(generated,`K99-Laundry-V2-${version}-win-unpacked.zip`);
  run('python',['-c',`import zipfile,sys,pathlib
folder=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(sys.argv[2],'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(folder.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(folder.parent))
with zipfile.ZipFile(sys.argv[2]) as z:
 assert z.testzip() is None
`,folder,zip],root);
  const report={...evidence,zip,bytes:fs.statSync(zip).size,sha256:sha(zip)};
  fs.writeFileSync(zip+'.sha256',report.sha256+'  '+path.basename(zip)+'\n');
  fs.writeFileSync(path.join(generated,'windows-portable/verification.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
  return report;
}
module.exports={prepare,build,productionEndpoint,pe,probeProxy};
if(require.main===module){
  const args=process.argv.slice(2);
  const operation=args[0]==='--prepare'?prepare():args[0]==='--proxy-url'&&args[1]
    ?build(args[1],{allowOfflineProxy:args.includes('--allow-offline-proxy'),offline:args.includes('--offline')})
    :Promise.reject(Error('Use --prepare or --proxy-url https://published-domain [--allow-offline-proxy]'));
  operation.catch(error=>{console.error('Portable build stopped:',error.message);process.exitCode=1;});
}
