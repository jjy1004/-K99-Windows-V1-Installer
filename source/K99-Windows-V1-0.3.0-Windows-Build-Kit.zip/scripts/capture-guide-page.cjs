'use strict';
// Documentation-only captures. No login, installation, or database access.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {spawn}=require('node:child_process');
async function main(){
  const url=process.argv[2],out=path.resolve(process.argv[3]);
  if(!url||!out)throw Error('URL and output prefix required');
  fs.mkdirSync(path.dirname(out),{recursive:true});
  const profile=fs.mkdtempSync(path.join(os.tmpdir(),'k99-guide-'));
  const chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage',
    '--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{stdio:['ignore','ignore','pipe']});
  let socket,seq=0;const pending=new Map();
  try{
    const endpoint=await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('Browser startup timeout')),20000);
      chrome.stderr.on('data',b=>{const m=String(b).match(/DevTools listening on (ws:\/\/\S+)/);if(m){clearTimeout(t);resolve(m[1]);}});
      chrome.on('error',reject);});
    socket=new WebSocket(endpoint);await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j;});
    socket.onmessage=e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.t);
      m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);};
    const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=++seq,t=setTimeout(()=>{pending.delete(id);reject(Error(method));},30000);
      pending.set(id,{resolve,reject,t});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));});
    const {targetId}=await send('Target.createTarget',{url:'about:blank'});
    const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
    const call=(m,p)=>send(m,p,sessionId);
    const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
      if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
    await call('Page.enable');await call('Runtime.enable');
    await call('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
    await call('Page.navigate',{url});
    await new Promise(r=>setTimeout(r,5000));
    await evaluate(`document.fonts.ready.then(()=>Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))))`);
    const info=await evaluate(`({url:location.href,title:document.title,text:document.body.innerText,
      links:[...document.querySelectorAll('a,button')].map(e=>({text:e.textContent.trim(),href:e.href||'',rect:(()=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()})),
      imageCount:document.images.length,imagesDecoded:[...document.images].every(i=>i.complete&&i.naturalWidth>0),
      smallestTextPixels:Math.min(...[...document.querySelectorAll('body *')].filter(e=>
        e.getBoundingClientRect().width&&[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim()))
        .map(e=>parseFloat(getComputedStyle(e).fontSize))),
      steps:[1,2,3,4,5].every(i=>!!document.querySelector('#step-'+i)),
      overflow:document.documentElement.scrollWidth>innerWidth})`);
    fs.writeFileSync(out+'.json',JSON.stringify(info,null,2));
    fs.writeFileSync(out+'.png',Buffer.from((await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'));
    if(process.argv.includes('--pdf')){
      info.printButtonWorks=await evaluate(`(()=>{let n=0;const original=window.print;window.print=()=>n++;
        document.querySelector('.print').click();window.print=original;return n===1;})()`);
      await call('Emulation.setEmulatedMedia',{media:'print'});
      info.printSmallestTextPixels=await evaluate(`Math.min(...[...document.querySelectorAll('body *')].filter(e=>
        e.getBoundingClientRect().width&&[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim()))
        .map(e=>parseFloat(getComputedStyle(e).fontSize)))`);
      const pdf=await call('Page.printToPDF',{printBackground:true,preferCSSPageSize:true,displayHeaderFooter:false});
      fs.writeFileSync(out+'.pdf',Buffer.from(pdf.data,'base64'));
      await call('Emulation.setEmulatedMedia',{media:''});
      await evaluate('document.querySelector("#step-4").scrollIntoView()');
      await new Promise(r=>setTimeout(r,300));
      fs.writeFileSync(out+'-step4.png',Buffer.from((await call('Page.captureScreenshot',{format:'png'})).data,'base64'));
    }
    fs.writeFileSync(out+'.json',JSON.stringify(info,null,2));
    console.log(JSON.stringify(process.argv.includes('--pdf')?{...info,text:undefined,links:undefined}:info,null,2).slice(0,14000));
  }finally{
    for(const p of pending.values()){clearTimeout(p.t);p.reject(Error('Capture complete'));}pending.clear();
    socket?.close();chrome.kill('SIGTERM');await new Promise(r=>setTimeout(r,250));fs.rmSync(profile,{recursive:true,force:true});
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
