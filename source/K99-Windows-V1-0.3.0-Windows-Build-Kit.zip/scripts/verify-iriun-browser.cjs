'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),http=require('node:http');
const {spawn}=require('node:child_process'),{createRequire}=require('node:module'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows'),req=createRequire(path.join(app,'package.json'));
const out=path.join(root,'generated-artifacts/iriun-camera-audit');fs.mkdirSync(out,{recursive:true});
createRequire(req.resolve('vite'))('esbuild').buildSync({entryPoints:[path.join(app,'tests/iriun-camera-browser.tsx')],
  outfile:path.join(out,'index.js'),bundle:true,platform:'browser',format:'iife',target:'chrome120',jsx:'automatic',
  define:{'process.env.NODE_ENV':'"production"'},logLevel:'warning'});
fs.writeFileSync(path.join(out,'index.html'),'<!doctype html><html lang="ko"><meta charset="UTF-8"><link rel="stylesheet" href="index.css"><style>*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;--border:210 20% 85%;--card:0 0% 100%;--background:0 0% 100%;--muted:210 20% 90%;--primary:200 70% 35%}</style><body><div id="root"></div><script src="index.js"></script></body></html>');
async function main(){
  const profile=fs.mkdtempSync(path.join(os.tmpdir(),'k99-iriun-ui-'));
  const server=http.createServer((r,s)=>{
    const name=new URL(r.url,'http://localhost').pathname.split('/').pop()||'index.html';
    if(!['index.html','index.js','index.css'].includes(name)){s.writeHead(404);s.end();return;}
    s.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html; charset=utf-8');
    fs.createReadStream(path.join(out,name)).pipe(s);
  });
  let chrome,ws;const pending=new Map(),errors=[];let seq=0;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const wait=async fn=>{const end=Date.now()+18000;while(Date.now()<end){const value=await fn();if(value)return value;await sleep(60);}throw Error('Iriun 화면 검사 대기 시간 초과');};
  try{
    await new Promise(r=>server.listen(0,'127.0.0.1',r));
    const url=`http://127.0.0.1:${server.address().port}/`;
    chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage',
      '--no-first-run','--autoplay-policy=no-user-gesture-required','--remote-debugging-port=0',`--user-data-dir=${profile}`,url],{stdio:'ignore'});
    const port=await wait(()=>{try{return fs.readFileSync(path.join(profile,'DevToolsActivePort'),'utf8').split('\n')[0];}catch{return false;}});
    const target=await wait(async()=>{const list=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();return list.find(x=>x.type==='page'&&x.url===url);});
    ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.addEventListener('open',r,{once:true}));
    ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}
      else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);});
    const command=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
    const evaluate=async expression=>{const r=await command('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
    const click=selector=>evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`);
    await command('Runtime.enable');await command('Page.enable');
    await wait(()=>evaluate('!!window.iriunAudit'));
    await evaluate(`window.dispatchEvent(new Event('k99:open-intake-camera'))`);
    await wait(()=>evaluate(`document.querySelector('[data-testid="button-ndc-shoot"]')?.disabled===false`));
    const layouts=[];
    for(const [width,height]of [[1366,768],[1024,600],[1920,1080]]){
      await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});await sleep(100);
      const layout=await evaluate(`(()=>{const m=document.querySelector('.ndc-modal'),v=document.querySelector('.ndc__stage');return {overflow:m.scrollHeight-m.clientHeight,stageHeight:v.getBoundingClientRect().height,stageRatio:v.getBoundingClientRect().width/v.getBoundingClientRect().height,buttons:[...document.querySelectorAll('.ndc__actions button,.ndc__final button,.ndc__connection button,.ndc-modal-close')].map(b=>({text:b.textContent,bottom:b.getBoundingClientRect().bottom,top:b.getBoundingClientRect().top})),guideBottom:document.querySelector('.ndc__connection-guide').getBoundingClientRect().bottom,manual:!!document.querySelector('.camera-manual'),deviceSelect:!!document.querySelector('[data-testid="select-ndc-device"]')}})()`);
      assert(layout.overflow<=1,JSON.stringify(layout));assert(layout.stageHeight>=70,JSON.stringify(layout));
      assert(layout.buttons.every(b=>b.top>=0&&b.bottom<=height),JSON.stringify(layout));assert(layout.guideBottom<=height);
      assert(!layout.manual&&!layout.deviceSelect);
      assert(Math.abs(layout.stageRatio-16/9)<0.03,'원본 16:9 프레임 보존');
      await click('.ndc__connection button:nth-child(2)');await sleep(70);
      assert(await evaluate(`document.querySelector('.ndc__connection-guide').getBoundingClientRect().bottom<=innerHeight&&document.querySelector('.ndc-modal').scrollHeight<=document.querySelector('.ndc-modal').clientHeight+1`),'USB 안내도 화면 안에 배치');
      await click('.ndc__connection button:nth-child(1)');await sleep(70);
      layouts.push({width,height,stageHeight:layout.stageHeight,overflow:layout.overflow});
      if(width===1366)fs.writeFileSync(path.join(out,'iriun-1366x768.png'),Buffer.from((await command('Page.captureScreenshot',{format:'png'})).data,'base64'));
    }
    await click('.ndc__connection button:nth-child(2)');
    assert.equal(await evaluate(`localStorage.getItem('k99.iriun-connection')`),'usb');
    assert(await evaluate(`document.querySelector('.ndc__connection-guide').textContent.includes('USB 테더링')`));
    await click('[data-testid="button-ndc-shoot"]');await wait(()=>evaluate('window.iriunAudit.captures.length===1'));
    const key=async(key,code,duration=50)=>{
      await command('Input.dispatchKeyEvent',{type:'keyDown',key,code});await sleep(duration);
      await command('Input.dispatchKeyEvent',{type:'keyUp',key,code});await sleep(70);
    };
    await key('a','KeyA');await wait(()=>evaluate('window.iriunAudit.captures.length===2'));
    await key('b','KeyB',500);
    assert(parseFloat(await evaluate(`document.querySelector('[data-testid="camera-zoom"]').textContent`))>1);
    await key('b','KeyB');
    assert.equal(parseFloat(await evaluate(`document.querySelector('[data-testid="camera-zoom"]').textContent`)),1);
    await key('c','KeyC');
    assert(await evaluate(`document.querySelector('.ndc__count').textContent.includes('코트')`));
    await click('[data-testid="button-camera-final"]');
    await wait(()=>evaluate(`!document.querySelector('[data-testid="dialog-intake-camera"]')&&window.iriunAudit.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))`));
    assert.equal(await evaluate('window.iriunAudit.final'),1);
    await evaluate(`window.dispatchEvent(new Event('k99:open-intake-camera'))`);
    await wait(()=>evaluate(`document.querySelector('[data-testid="button-ndc-shoot"]')?.disabled===false`));
    await key('Escape','Escape');
    await wait(()=>evaluate(`window.iriunAudit.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))`));
    const capturePayload=await evaluate(`window.iriunAudit.captures.map(c=>({photo_type:c.photo_type,expectedMode:c.expectedMode,unitKey:c.unitKey,jpeg:c.imageDataUrl.startsWith('data:image/jpeg')}))`);
    await command('Page.reload');
    await wait(()=>evaluate(`window.iriunAudit?.final===0&&document.querySelector('[data-testid="button-ndc-shoot"]')?.disabled===false`));
    assert(await evaluate(`document.querySelector('.ndc__connection button:nth-child(2)').getAttribute('aria-pressed')==='true'`));
    await click('.ndc-modal-close');
    await wait(()=>evaluate(`window.iriunAudit.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))`));
    assert.equal(errors.length,0,errors.join('\n'));
    const result={pass:true,syntheticStream:true,operationalDatabaseAccess:false,actualIriunVerified:false,
      layouts,cameraControls:true,abcPedals:true,modeSaved:true,finalAndEscapeRelease:true,
      capturePayload};
    fs.writeFileSync(path.join(out,'browser-result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
  }finally{ws?.close();chrome?.kill();await new Promise(r=>server.close(r));fs.rmSync(profile,{recursive:true,force:true,maxRetries:10,retryDelay:100});}
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
