'use strict';
// Only creates an explicitly isolated QA database; never opens store/production data.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const {createStore}=require('../lib/k99-local/index.cjs');
const D=require(require.resolve('better-sqlite3',{paths:[path.resolve(__dirname,'../lib/k99-local')]}));
const output=path.resolve(__dirname,'../generated-artifacts/v249-demo-audit');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-presentation-notices-')),file=path.join(root,'k99.db');
const s=createStore(file,'isolated-presentation-audit',{nativeDesktop:true});
const evidence={realMessagesSent:false,productionAccessed:false,source:'실제 로컬 SQLite 저장·공지 생성 API (격리 검사)',orders:[]};
try{
  s.ensurePresentationCustomer();
  const customer=s.api('GET','/api/customers/search?q=6905').customers.find(c=>c.name==='정재윤');
  assert(customer?.specialNote);evidence.customer={id:customer.id,name:customer.name,phone:customer.phone,specialNote:customer.specialNote};
  const profile=s.api('GET','/api/notices/profile');
  profile.profile.bankAccount='검증용 은행 000-000-000000 (시연 테스트 계좌, 입금 금지)';
  s.api('PUT','/api/notices/profile',profile);
  const orders=[50000,100000,200000].map(amount=>({
    id:`presentation-audit-${amount}`,customerName:customer.name,customerPhone:customer.phone,
    customerAddress:'',intakeAt:new Date().toISOString(),status:'confirmed',
    estimatedTotal:amount,payment_type:'PREPAID',payment_status:'PAID',
    choices:{serviceLevel:'general',pickupRequested:true,discount:0,noticeReviewConfirmed:false},
    items:[{id:`item-${amount}`,catalogId:'demo-only',displayNameKo:'시연용 가상 의류',quantity:1,generalPrice:amount,premiumPrice:amount}],
  }));
  s.storage({op:'set',key:'k99-confirmed-orders-v1',expected:null,value:JSON.stringify(orders)});
  const expected=['5만 원 이상 이용 시 네이버 영수증 리뷰를 작성해 주시면 5,000원 정액 할인이 적용됩니다.',
    '10만 원 이상 이용 고객님께 적용되는 10% 할인 혜택 대상입니다.',
    '20만 원 이상 이용 고객님께 적용되는 15% 할인 혜택 대상입니다.'];
  orders.forEach((order,i)=>{
    const messages={};
    for(const kind of ['pickup-quote','complete-pickup','complete-delivery']){
      messages[kind]=s.api('POST','/api/notices/preview',{orderId:order.id,templateId:kind}).body;
      assert(!messages[kind].includes(customer.specialNote),'직원 전용 특이사항 노출');
    }
    assert(messages['pickup-quote'].includes(expected[i]));
    assert(messages['pickup-quote'].includes(`총 세탁비 ${order.estimatedTotal.toLocaleString('ko-KR')}원입니다.`));
    for(const t of ['평일 10:00~19:00 / 토요일 11:00~16:00','일요일·공휴일 휴무','4벌 이상 세탁 시 무료 수거·배달'])
      assert(messages['complete-pickup'].includes(t),t);
    assert(messages['complete-delivery'].includes('평일 오후 4시~5시(16:00~17:00)'));
    assert(messages['complete-delivery'].includes('수령을 원하시는 날짜(몇 월 며칠)를 회신'));
    evidence.orders.push({id:order.id,amount:order.estimatedTotal,messages});
  });
  const db=new D(file);db.pragma('foreign_keys=ON');
  db.transaction(()=>{
    for(const o of orders)db.prepare('DELETE FROM orders WHERE id=?').run(o.id);
    db.prepare('DELETE FROM state WHERE key=?').run('k99-confirmed-orders-v1');
  })();
  evidence.remainingOrders=db.prepare('SELECT count(*) n FROM orders').get().n;
  evidence.remainingCustomers=db.prepare('SELECT count(*) n FROM customers').get().n;
  evidence.remainingNoticeSends=db.prepare('SELECT count(*) n FROM notice_deliveries').get().n;
  assert.equal(evidence.remainingOrders,0);assert.equal(evidence.remainingCustomers,1);assert.equal(evidence.remainingNoticeSends,0);
  db.close();
  fs.mkdirSync(output,{recursive:true});
  s.snapshot(path.join(output,'clean-presentation-k99.db'));
  fs.writeFileSync(path.join(output,'generated-messages.json'),JSON.stringify(evidence,null,2));
  console.log(JSON.stringify(evidence,null,2));
}finally{s.close();fs.rmSync(root,{recursive:true,force:true});}
