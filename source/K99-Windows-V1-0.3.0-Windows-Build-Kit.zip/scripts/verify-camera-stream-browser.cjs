'use strict';
// Isolated real Chromium media/canvas smoke test with a SYNTHETIC camera.
// No product server, orders, shop DB, real USB device or production endpoint.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const http=require('node:http'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const {createRequire}=require('node:module');
const app=path.join(__dirname,'../artifacts/k99-windows'),req=createRequire(path.join(app,'package.json'));
const ts=req('typescript'),modules={};
for(const name of ['camera-device','camera-capture-controls','camera-color','use-camera-color-preview']){
  modules[name]=ts.transpileModule(fs.readFileSync(path.join(app,'src',name+'.ts'),'utf8'),{
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
}
async function browserTest(sources){
  const check=(value,message)=>{if(!value)throw Error(message);};
  const wait=async predicate=>{const start=performance.now();while(!predicate()){
    if(performance.now()-start>5000)throw Error('브라우저 검사 대기 시간 초과');await new Promise(r=>setTimeout(r,20));
  }};
  const effects=[],states=[];let hookIndex=0;
  const react={useRef:value=>({current:value}),useEffect:effect=>effects.push(effect),
    useState:value=>{const index=hookIndex++;states[index]=value;return [value,next=>{states[index]=next;}];}};
  const cache={};
  function load(name){
    if(cache[name])return cache[name];
    const exports={};new Function('exports','require',sources[name])(exports,id=>
      id==='react'?react:sources[id.slice(2)]?load(id.slice(2)):{});
    return cache[name]=exports;
  }
  const controls=load('camera-capture-controls'),color=load('camera-color');
  const calls=[],media=navigator.mediaDevices,original=media.getUserMedia.bind(media);
  let rejectPreferred=true;
  media.getUserMedia=async constraints=>{
    calls.push(constraints);
    if(rejectPreferred&&constraints.video?.deviceId&&constraints.video?.width){
      rejectPreferred=false;throw new DOMException('검사용 1080p 요청 거절','OverconstrainedError');
    }
    return original(constraints);
  };
  const stream=await controls.openPreferredCamera();
  try{
    const video=document.querySelector('video');video.hidden=true;
    await controls.playCameraVideo(video,stream);
    check(!video.hidden&&video.readyState>=2&&video.videoWidth>0,'첫 프레임 전 원본 영상 표시 실패');
    check(calls.some(c=>c.video.deviceId&&!c.video.width),'동일 장치 기본 스트림 재시도 누락');
    check(!calls.some(c=>/"(?:exact|min|frameRate|whiteBalanceMode|exposureMode)"/.test(JSON.stringify(c))),'불필요한 장치 제약');
    video.pause(); // Freeze only this test video so pixel comparisons use the same frame.
    const canvas=document.querySelector('canvas'),checks=[];
    for(const change of [{},{brightnessAdjustment:20},{temperatureAdjustment:40},{contrastAdjustment:25}]){
      effects.length=0;states.length=0;hookIndex=0;
      const profile={...color.DEFAULT_CAMERA_COLOR,...change};
      const hook=load('use-camera-color-preview').useCameraColorPreview({current:video},true,profile);
      hook.canvas.current=canvas;const cleanup=effects[0]();
      try{
        await wait(()=>states[1]===true);
        const shown=canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height);
        const saved=document.createElement('canvas');saved.width=canvas.width;saved.height=canvas.height;
        const context=saved.getContext('2d',{willReadFrequently:true});
        context.drawImage(video,0,0,saved.width,saved.height);color.correctCameraCanvas(context,hook.effective.current);
        const pixels=context.getImageData(0,0,saved.width,saved.height).data;
        check(pixels.every((value,i)=>value===shown.data[i]),'미리보기와 저장 픽셀 불일치');
        check(saved.toDataURL('image/jpeg',.95).startsWith('data:image/jpeg;base64,'),'JPEG 캡처 실패');
        checks.push({change,checksum:pixels.reduce((sum,v,i)=>sum+(i%4===3?0:v),0)});
      }finally{cleanup();}
    }
    check(new Set(checks.map(c=>c.checksum)).size===4,'밝기·색온도·대비 조절 반영 실패');
    return {success:true,syntheticCamera:true,dimensions:[video.videoWidth,video.videoHeight],
      rawVideoVisible:!video.hidden,basicFallback:true,previewMatchesCapture:true,checks};
  }finally{controls.releaseCameraStreams();}
}
async function main(){
  let resolveResult,chrome,timer;
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-camera-browser-'));
  const done=new Promise(resolve=>{resolveResult=resolve;});
  const page=`<!doctype html><html lang="ko"><meta charset="utf-8"><body>
    <video width="640" height="360"></video><canvas></canvas><script>
    (${browserTest.toString()})(${JSON.stringify(modules).replace(/</g,'\\u003c')})
      .then(result=>fetch('/result',{method:'POST',body:JSON.stringify(result)}))
      .catch(error=>fetch('/result',{method:'POST',body:JSON.stringify({success:false,error:error.stack})}));
    </script></body></html>`;
  const server=http.createServer((request,response)=>{
    if(request.url==='/result'&&request.method==='POST'){
      let body='';request.on('data',chunk=>{body+=chunk;});
      request.on('end',()=>{response.end('ok');try{resolveResult(JSON.parse(body));}catch{resolveResult({success:false,error:body});}});
    }else{response.setHeader('Content-Type','text/html; charset=utf-8');response.end(page);}
  });
  try{
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage',
      '--remote-debugging-port=0','--no-first-run','--no-default-browser-check',
      '--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream',
      '--autoplay-policy=no-user-gesture-required',`--user-data-dir=${root}`,`http://127.0.0.1:${server.address().port}/`],
      {stdio:['ignore','ignore','ignore']});
    chrome.on('error',error=>resolveResult({success:false,error:error.message}));
    const result=await Promise.race([done,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('브라우저 검사 20초 시간 초과')),20000);})]);
    assert.equal(result.success,true,JSON.stringify(result));console.log(JSON.stringify(result,null,2));
  }finally{
    clearTimeout(timer);
    if(chrome&&chrome.exitCode===null){chrome.kill('SIGTERM');await new Promise(resolve=>chrome.once('exit',resolve));}
    await new Promise(resolve=>server.close(resolve));fs.rmSync(root,{recursive:true,force:true});
  }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
