'use strict';
// Actual React/Chromium controls, synthetic MediaStreams, isolated storage.
// No operational DB, API, OBS, external service or physical camera is used.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),http=require('node:http');
const {spawn}=require('node:child_process'),{createRequire}=require('node:module'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const req=createRequire(path.join(app,'package.json'));
const esbuild=createRequire(req.resolve('vite'))('esbuild');
const out=path.join(root,'generated-artifacts/manual-camera-246/browser');
function prepare(){
  fs.mkdirSync(out,{recursive:true});
  esbuild.buildSync({entryPoints:[path.join(app,'tests/manual-camera-browser.tsx')],outfile:path.join(out,'index.js'),
    bundle:true,platform:'browser',format:'iife',target:'chrome120',minify:true,jsx:'automatic',
    define:{'process.env.NODE_ENV':'"production"'},logLevel:'warning'});
  fs.writeFileSync(path.join(out,'index.html'),'<!doctype html><html lang="ko"><meta charset="UTF-8"><title>카메라 수동 화질 검사</title><link rel="stylesheet" href="index.css"><body style="margin:0;background:#101c24"><div id="root"></div><script src="index.js"></script></body></html>');
}
async function main(){
  prepare();
  if(process.argv.includes('--bundle-only')){console.log(out);return;}
  if(process.argv.includes('--prepare')){
    const publicDir=path.join(app,'public');fs.mkdirSync(publicDir,{recursive:true});
    const link=path.join(publicDir,'__camera_manual_audit');
    if(fs.existsSync(link)){if(!fs.lstatSync(link).isSymbolicLink())throw Error('검사 경로가 이미 사용 중입니다.');}
    else fs.symlinkSync(out,link,'dir');
    console.log('/__camera_manual_audit/index.html');return;
  }
  const profile=fs.mkdtempSync(path.join(os.tmpdir(),'k99-manual-browser-'));
  const server=http.createServer((r,s)=>{
    const name=new URL(r.url,'http://localhost').pathname.split('/').pop()||'index.html';
    if(!['index.html','index.js','index.css'].includes(name)){s.statusCode=404;s.end();return;}
    s.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html; charset=utf-8');
    fs.createReadStream(path.join(out,name)).pipe(s);
  });
  let chrome,ws,seq=0;const waiting=new Map(),errors=[];
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const wait=async(fn,ms=15000)=>{
    const start=Date.now();while(Date.now()-start<ms){const value=await fn();if(value)return value;await sleep(60);}throw Error('브라우저 검사 대기 시간 초과');
  };
  try{
    await new Promise(r=>server.listen(0,'127.0.0.1',r));
    const url=`http://127.0.0.1:${server.address().port}/`;
    chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage',
      '--no-first-run','--no-default-browser-check','--autoplay-policy=no-user-gesture-required',
      '--remote-debugging-port=0',`--user-data-dir=${profile}`,url],{stdio:'ignore'});
    chrome.on('error',e=>errors.push(e.message));
    const port=await wait(()=>{try{return fs.readFileSync(path.join(profile,'DevToolsActivePort'),'utf8').split('\n')[0];}catch{return false;}});
    const target=await wait(async()=>{const list=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();return list.find(t=>t.type==='page'&&t.url.startsWith(url));});
    ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
    ws.addEventListener('message',event=>{
      const m=JSON.parse(event.data);
      if(m.id){const p=waiting.get(m.id);if(!p)return;waiting.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}
      else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text+': '+(m.params.exceptionDetails.exception?.description||''));
    });
    const command=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;waiting.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
    const evaluate=async expression=>{
      const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
      if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
      return r.result.value;
    };
    await command('Runtime.enable');await command('Page.enable');
    await command('Emulation.setDeviceMetricsOverride',{width:1440,height:1200,deviceScaleFactor:1,mobile:false});
    const state=()=>evaluate('window.k99CameraAudit?.state()');
    try{await wait(async()=>{const s=await state();return s?.ready&&!s.changing;});}
    catch(error){console.error(JSON.stringify({state:await state(),errors}));throw error;}
    const click=async selector=>{
      const rect=await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw Error('버튼 없음');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2};})()`);
      await command('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...rect});
      await command('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...rect});
      await sleep(70);
    };
    let s=await state();assert.equal(s.width,1920);assert.equal(s.height,1080);assert.equal(s.profile.resolution,'FHD');
    const results=[{check:'OBS 없는 직접 FHD 초기화',pass:true,synthetic:true}];
    for(const label of ['밝기','명암 / 대비','색온도 / 화이트밸런스','채도','선명도']){
      const key={'밝기':'brightness','명암 / 대비':'contrast','색온도 / 화이트밸런스':'temperature','채도':'saturation','선명도':'sharpness'}[label];
      await click(`button[aria-label="${label} 늘리기"]`);assert.equal((await state()).profile[key],1);
      await click(`button[aria-label="${label} 줄이기"]`);assert.equal((await state()).profile[key],0);
      const slider=`input[aria-label="${label}"]`;
      await click(slider);
      await command('Input.dispatchKeyEvent',{type:'keyDown',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
      await command('Input.dispatchKeyEvent',{type:'keyUp',key:'ArrowRight',code:'ArrowRight',windowsVirtualKeyCode:39});
      await sleep(100);assert.ok((await state()).profile[key]>0,`${label} 실제 슬라이더 입력`);
      results.push({check:`${label} +/- 및 슬라이더`,pass:true});
    }
    await sleep(400);
    const parity=await evaluate('window.k99CameraAudit.parity()');assert.equal(parity.maxDifference,0);assert.equal(parity.jpeg,true);
    results.push({check:'보정 미리보기·저장 JPEG 픽셀 일치',pass:true,...parity});
    for(const [name,width,height]of [['HD',1280,720],['FHD',1920,1080],['2K',2560,1440]]){
      await click(`.camera-manual__resolution button:nth-child(${name==='HD'?1:name==='FHD'?2:3})`);
      await wait(async()=>{const x=await state();return !x.changing&&x.width===width&&x.height===height;});
      assert.equal((await state()).profile.resolution,name);results.push({check:`${name} 실제 브라우저 프레임 전환`,pass:true});
    }
    await click('[data-testid="force-resolution-failure"]');
    await click('.camera-manual__resolution button:nth-child(2)');
    await wait(async()=>{const x=await state();return !x.changing&&x.note.includes('지원하지');});
    s=await state();assert.equal(s.width,2560);assert.equal(s.live,'live');assert.equal(s.profile.resolution,'2K');
    results.push({check:'미지원 해상도 거절·기존 영상 보존',pass:true});
    const saved=s.profile;
    await command('Page.reload',{ignoreCache:true});
    await wait(async()=>{const x=await state();return x?.ready&&!x.changing&&x.width===2560;});
    assert.deepEqual((await state()).profile,saved);results.push({check:'다시 열기 후 6개 수동 설정 복원',pass:true});
    await click('[data-testid="camera-standard-reset"]');
    await wait(async()=>{const x=await state();return !x.changing&&x.width===1920&&x.profile.resolution==='FHD';});
    s=await state();
    for(const key of ['brightness','contrast','temperature','saturation','sharpness'])assert.equal(s.profile[key],0);
    results.push({check:'표준 복원·FHD 및 중립값 0 저장',pass:true});
    await wait(async()=>{const x=await state();return x.hardware?.controls.exposureTime?.enabled&&!x.hardwareBusy;});
    for(const [field,label] of [['exposureTime','센서 노출 시간'],['gain','센서 게인']]){
      const before=(await state()).hardware.controls[field].value;
      await click(`button[aria-label="${label} 늘리기"]`);
      await wait(async()=>{const x=await state();return !x.hardwareBusy&&x.profile.hardware?.[field]===before+1;})
        .catch(async error=>{console.error('하드웨어 검사 실패 상태:',JSON.stringify(await state()));throw error;});
      assert.equal((await state()).hardware.modes.exposureMode,'manual');
      results.push({check:`${label} 실제 UI → 모의 UVC 적용값 확인 → 영구 저장`,pass:true,syntheticHardware:true});
    }
    const manualHardware=(await state()).profile;
    await command('Page.reload',{ignoreCache:true});
    await wait(async()=>{const x=await state();return x?.ready&&!x.hardwareBusy&&x.hardware?.modes.exposureMode==='manual';});
    assert.deepEqual((await state()).profile,manualHardware);
    for(const field of ['exposureTime','gain'])assert.equal((await state()).hardware.controls[field].value,manualHardware.hardware[field]);
    results.push({check:'수동 센서 노출·게인 재시작 복원',pass:true,syntheticHardware:true});
    await click('[data-testid="camera-natural-calibrate"]');
    await wait(async()=>{const x=await state();return !x.calibrating&&x.profile.calibrationMode==='natural'&&!!x.profile.reference;});
    s=await state();assert.equal(s.profile.sharpness,12);assert.equal(s.hardware.modes.exposureMode,'continuous');
    await sleep(400);
    const naturalParity=await evaluate('window.k99CameraAudit.parity()');assert.equal(naturalParity.maxDifference,0);
    results.push({check:'원클릭 흰 배경 보정·자동 노출·미리보기/저장 일치',pass:true,syntheticHardware:true,...naturalParity});
    const naturalSaved=(await state()).profile;
    await command('Page.reload',{ignoreCache:true});
    await wait(async()=>{const x=await state();return x?.ready&&!x.hardwareBusy&&x.hardware?.modes.exposureMode==='continuous'&&x.profile.reference;});
    assert.deepEqual((await state()).profile,naturalSaved);
    results.push({check:'자연색 계수·하드웨어 선택 재시작 복원',pass:true,syntheticHardware:true});
    const beforePhoneCalls=(await state()).hardwareCalls.length;
    await click('[data-testid="audit-phone-mode"]');
    await wait(async()=>{const x=await state();return x.passthrough&&!x.calibrating;});
    await sleep(1200);
    const phoneState=await state();assert.equal(phoneState.hardwareCalls.length,beforePhoneCalls);
    for(const k of ['brightness','contrast','temperature','saturation','sharpness'])assert.equal(phoneState.profile[k],0);
    assert.equal(await evaluate('!!document.querySelector("[data-testid= camera-natural-calibrate]")'),false);
    const rawParity=await evaluate('window.k99CameraAudit.parity()');assert.equal(rawParity.maxDifference,0);
    results.push({check:'Iriun 모드 센서 제어 없음·원본 미리보기/저장',pass:true,syntheticHardware:true});
    await click('[data-testid="audit-phone-mode"]');
    await wait(async()=>{const x=await state();return !x.passthrough&&!x.hardwareBusy;});
    assert.deepEqual((await state()).profile,naturalSaved);
    results.push({check:'USB 복귀 시 기존 수동·자연색 설정 보존',pass:true});
    await click('[data-testid="audit-open-phone-help"]');
    const helpTabs=await evaluate(`Array.from(document.querySelectorAll('[role="tab"]')).map(el=>({
      font:parseFloat(getComputedStyle(el).fontSize),height:el.getBoundingClientRect().height
    }))`);
    assert.equal(helpTabs.length,2);assert(helpTabs.every(t=>t.font>=20&&t.height>=64),'연결 방법 탭의 큰 글씨·터치 높이 유지');
    assert.equal(await evaluate('document.querySelector("[role=tab][aria-selected=true]").textContent.includes("와이파이")'),true);
    await click('[data-testid="button-camera-help-iriun"]');
    assert.equal(await evaluate('document.querySelector("[data-testid=status-camera-help]").textContent.includes("실제 프로그램 실행·설치 없음")'),true);
    await click('#sch-tab-usb');
    assert.equal(await evaluate('document.querySelector("[data-testid=img-camera-help-qr]").width>0'),true);
    await click('[data-testid="button-camera-help-driver"]');
    assert.equal(await evaluate('document.querySelector("[data-testid=status-camera-help]").textContent.includes("driver")'),true);
    results.push({check:'연결 도우미 탭·QR·원클릭 요청·닫기',pass:true,syntheticHardware:true});
    await click('[data-testid="button-camera-help-close"]');
    assert.equal(await evaluate('!!document.querySelector("[data-testid=smartphone-camera-help]")'),false);
    assert.equal(s.error,'');assert.deepEqual(errors,[]);
    const screenshot=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
    fs.writeFileSync(path.join(out,'manual-controls.png'),Buffer.from(screenshot.data,'base64'));
    const report={success:true,browser:'Chromium',syntheticCamera:true,physicalWindowsCameraVerified:false,results,errors};
    fs.writeFileSync(path.join(out,'browser-verification.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
  }finally{
    ws?.close();if(chrome&&chrome.exitCode===null){chrome.kill('SIGTERM');await new Promise(r=>chrome.once('exit',r));}
    await new Promise(r=>server.close(r));fs.rmSync(profile,{recursive:true,force:true});
  }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
