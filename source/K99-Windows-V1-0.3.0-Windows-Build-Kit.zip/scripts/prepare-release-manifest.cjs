'use strict';
// Generate a candidate only. Commit installer-release.json AFTER both uploads
// and remote SHA-256 verification succeed; never replace a live object in place.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),generated=path.join(root,'generated-artifacts');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const version=read(path.join(root,'artifacts/k99-windows/package.json')).version;
const previous=read(path.join(root,'artifacts/api-server/src/installer-release.json'));
const installer=read(path.join(generated,'oneclick-installer-verification.json'));
const portable=read(path.join(generated,'windows-portable/verification.json'));
const audit=read(path.join(generated,`K99-Laundry-V2-${version}-final-audit.json`));
if(installer.version!==version||portable.appVersion!==version||!installer.nsisCompilePassed||
  !audit.zipCrcVerified||!audit.packagedFilesVerified||!audit.compiledRendererVerified||
  audit.sha256!==portable.sha256||installer.payloadSHA256!==portable.appAsarSHA256||
  !installer.installerPayloadVerified||!installer.allPortableFilesMatch||installer.portableSHA256!==portable.sha256)
  throw Error('최신 EXE·ZIP 또는 최종 패키지 검증이 완료되지 않았습니다.');
function asset(filename,expected){
  const file=path.join(generated,filename);
  const sha256=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  const bytes=fs.statSync(file).size;
  if(sha256!==expected.sha256||bytes!==expected.bytes)throw Error('릴리스 파일 무결성 불일치: '+filename);
  return {filename,bytes,sha256,objectName:`releases/${sha256}/${filename}`};
}
const release={...asset(installer.filename,installer),version,bucketId:previous.bucketId,
  portable:asset(path.basename(portable.zip),portable)};
const file=path.join(generated,'candidate-installer-release.json');
fs.writeFileSync(file,JSON.stringify(release,null,2)+'\n');
console.log(JSON.stringify({candidate:file,version,installer:release.filename,portable:release.portable.filename},null,2));
