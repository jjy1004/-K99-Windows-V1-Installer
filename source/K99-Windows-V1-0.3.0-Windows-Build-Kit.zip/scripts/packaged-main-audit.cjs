'use strict';
// Release-only checks. No customer data, network connection or desktop launch.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const crypto=require('node:crypto');

function auditPackagedApp(archive,asar){
  const ts=require('typescript');
  const files=new Set(asar.listPackage(archive).map(n=>n.replace(/\\/g,'/').replace(/^\//,''))
    .filter(n=>!asar.statFile(archive,n).files));
  const read=name=>asar.extractFile(archive,name).toString('utf8');
  const required=['electron/main.cjs','electron/preload.cjs',
    'electron/services/autoMessenger.js','electron/services/labelService.cjs','electron/services/package.json'];
  for(const name of required)if(!files.has(name))throw Error('ASAR runtime file missing: '+name);
  if(JSON.parse(read('electron/services/package.json')).type!=='commonjs')throw Error('Service CommonJS scope missing');
  function resolve(name,seen=new Set()){
    if(name==='..'||name.startsWith('../'))return null;
    if(seen.has(name))return null;
    seen.add(name);
    for(const candidate of [name,name+'.js',name+'.json',name+'.node'])if(files.has(candidate)&&!candidate.endsWith('/'))return candidate;
    if(files.has(name+'/package.json')){
      const main=JSON.parse(read(name+'/package.json')).main;
      if(main){const found=resolve(path.posix.join(name,main),seen);if(found)return found;}
    }
    for(const suffix of ['/index.js','/index.json','/index.node'])if(files.has(name+suffix))return name+suffix;
    return null;
  }
  let modules=0,relativeRequires=0;
  for(const file of files){
    if(!/^(?:electron|services)\/.*\.(?:cjs|js)$/.test(file))continue;
    modules++;
    const source=ts.createSourceFile(file,read(file),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
    function visit(node){
      if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='require'&&
        node.arguments.length===1&&ts.isStringLiteralLike(node.arguments[0])){
        const target=node.arguments[0].text;
        if(target.startsWith('.')){
          relativeRequires++;
          if(!resolve(path.posix.normalize(path.posix.join(path.posix.dirname(file),target))))
            throw Error(`ASAR unresolved local require: ${file} -> ${target}`);
        }
        if(target.startsWith('@workspace/'))throw Error(`ASAR unresolved workspace dependency: ${file} -> ${target}`);
      }
      ts.forEachChild(node,visit);
    }
    visit(source);
  }
  const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
  return {asarApplicationModules:modules,asarRelativeRequires:relativeRequires,requiredServiceFiles:required,
    asarSHA256:hash(fs.readFileSync(archive)),
    serviceSHA256:Object.fromEntries(required.map(name=>[name,hash(asar.extractFile(archive,name))]))};
}

function loadPackagedMain(archive){
  // Electron's Node mode has ASAR support but no app API. Stub only that OS/UI
  // boundary; load the actual main, services, core and dependencies from ASAR.
  const Module=require('node:module'),original=Module._load;
  const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'k99-main-import-'));
  const before={APPDATA:process.env.APPDATA,LOCALAPPDATA:process.env.LOCALAPPDATA};
  const neverReady=new Promise(()=>{});
  const noop=()=>{};
  const app={isPackaged:true,commandLine:{appendSwitch:noop},disableHardwareAcceleration:noop,
    setName:noop,setAppUserModelId:noop,getPath:()=>temporary,setPath:noop,
    requestSingleInstanceLock:()=>true,quit:noop,on:noop,whenReady:()=>neverReady};
  process.env.APPDATA=temporary;process.env.LOCALAPPDATA=temporary;
  const electron={app,protocol:{registerSchemesAsPrivileged:noop}};
  Module._load=function(request,parent,isMain){
    return request==='electron'?electron:original.call(this,request,parent,isMain);
  };
  try{
    const mainRequire=Module.createRequire(path.join(archive,'electron/main.cjs'));
    const messenger=mainRequire('./services/autoMessenger.js');
    if(typeof messenger.createAutoMessenger!=='function')throw Error('Packaged messenger export missing');
    const label=mainRequire('./services/labelService.cjs');
    if(typeof label.classifyCareLabel!=='function')throw Error('Packaged label service export missing');
    mainRequire('./main.cjs');
    return {packagedMainModuleLoaded:true,packagedServicesLoaded:true,electronAppApiStubbed:true,
      actualWindowBootVerified:false};
  }finally{
    Module._load=original;
    for(const [name,value]of Object.entries(before)){
      if(value===undefined)delete process.env[name];else process.env[name]=value;
    }
    fs.rmSync(temporary,{recursive:true,force:true});
  }
}
module.exports={auditPackagedApp,loadPackagedMain};
