'use strict';
// Compile only synthetic NSIS probes. Never install or launch these probes.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {createRequire}=require('node:module');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
async function main() {
  const appRequire=createRequire(path.join(app,'package.json'));
  const builderRequire=createRequire(appRequire.resolve('electron-builder/package.json'));
  const tools=builderRequire('app-builder-lib/out/targets/nsis/nsisUtil');
  tools.NsisTargetOptions.resolve({});
  const [nsis,resources]=await Promise.all([tools.NSIS_PATH(),tools.NSIS_RESOURCES_PATH()]);
  const command=path.join(nsis,process.platform==='win32'?'Bin':process.platform==='darwin'?'mac':'linux',process.platform==='win32'?'makensis.exe':'makensis');
  const out=path.join(root,'generated-artifacts/nsis-customization-check');
  fs.mkdirSync(out,{recursive:true});
  const quoted=p=>p.replace(/\\/g,'/');
  const results=[];
  for(const uninstall of [false,true]) {
    const name=uninstall?'uninstaller':'installer';
    const header=`Unicode true
!addplugindir /x86-unicode "${quoted(path.join(resources,'plugins/x86-unicode'))}"
!define APP_ID "com.k99.windows.v1"
!define SHORTCUT_NAME "K99 스마트 접수 시스템"
!define APP_EXECUTABLE_FILENAME "K99-Windows-V1.exe"
${uninstall?'!define BUILD_UNINSTALLER':'Var launchLink'}
OutFile "${quoted(path.join(out,name+'-probe-only.exe'))}"
!include "${quoted(path.join(app,'installer/data-preservation.nsh'))}"
!include MUI2.nsh
`;
    const installer=`!insertmacro customPageAfterChangeDir
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"
Function .onInit
!insertmacro customInit
FunctionEnd
Section
!insertmacro customInstall
SectionEnd
`;
    const uninstaller=`!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"
Section
WriteUninstaller "${quoted(path.join(out,'uninstall-probe-only.exe'))}"
SectionEnd
Section "Uninstall"
!insertmacro customUnInstall
SectionEnd
`;
    const result=spawnSync(command,['-WX','-V3','-'],{
      input:header+(uninstall?uninstaller:installer),encoding:'utf8',maxBuffer:8*1024*1024,
      env:{...process.env,NSISDIR:nsis},
    });
    const log=(result.stdout||'')+(result.stderr||'');
    fs.writeFileSync(path.join(out,name+'.log'),log);
    console.log(log);
    if(result.error)throw result.error;
    if(result.status!==0)throw Error(`${name} NSIS customization compile failed (${result.status}); see ${name}.log`);
    results.push({phase:name,compilePassed:true,warningsAsErrors:true});
  }
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({
    platform:process.platform,scope:'Synthetic NSIS header probes only; NOT the K99 application installer',
    results,windowsApplicationPackagingVerified:false,windows11InstallationVerified:false,
  },null,2));
}
main().catch(error=>{console.error(`::error title=K99 NSIS customization failed::${error.message}`);process.exitCode=1;});
