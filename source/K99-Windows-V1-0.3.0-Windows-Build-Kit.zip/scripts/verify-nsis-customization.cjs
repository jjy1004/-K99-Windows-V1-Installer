'use strict';
// Compile only synthetic NSIS probes. Never install or launch these probes.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {createRequire}=require('node:module');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const literal=value=>{
  if(/["\r\n]/.test(value))throw Error('NSIS 파일 경로에 허용되지 않는 문자가 있습니다.');
  return value.replace(/\$/g,()=> '$$');
};
function createProbe({installerDir,resources,out,uninstall=false,platform=process.platform}){
  const p=platform==='win32'?path.win32:path.posix;
  for(const folder of [installerDir,resources,out])if(!p.isAbsolute(folder))throw Error('NSIS 경로는 절대 경로여야 합니다.');
  const name=uninstall?'uninstaller':'installer',includePath=p.join(installerDir,'data-preservation.nsh');
  const scriptFile=p.join(out,name+'-probe.nsi');
  const header=`Unicode true
!addincludedir "${literal(installerDir)}"
!addplugindir /x86-unicode "${literal(p.join(resources,'plugins','x86-unicode'))}"
!define APP_ID "com.k99.windows.v1"
!define SHORTCUT_NAME "K99 스마트 접수 시스템"
!define APP_EXECUTABLE_FILENAME "K99-Windows-V1.exe"
${uninstall?'!define BUILD_UNINSTALLER':''}
OutFile "${literal(p.join(out,name+'-probe-only.exe'))}"
!include /CHARSET=UTF8 "data-preservation.nsh"
!include MUI2.nsh
`;
  const installer=`!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"
Function .onInit
!insertmacro customInit
FunctionEnd
Section
!insertmacro customInstall
SectionEnd
`;
  const uninstaller=`!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"
Section
WriteUninstaller "${literal(p.join(out,'uninstall-probe-only.exe'))}"
SectionEnd
Section "Uninstall"
!insertmacro customUnInstall
SectionEnd
`;
  return {name,includePath,scriptFile,cwd:installerDir,
    source:Buffer.from('\uFEFF'+header+(uninstall?uninstaller:installer),'utf8'),
    args:['-WX','-V3','-INPUTCHARSET','UTF8','-NOCD',scriptFile]};
}
function resolveInstallerDir(appRoot){
  const requested=path.join(appRoot,'installer');
  if(!fs.existsSync(path.join(requested,'data-preservation.nsh')))
    throw Error('필수 NSIS include 파일이 없습니다: '+path.join(requested,'data-preservation.nsh')+
      ' (소스 ZIP의 artifacts/k99-windows/installer 폴더를 확인하세요.)');
  const dir=fs.realpathSync(requested);
  fs.accessSync(path.join(dir,'data-preservation.nsh'),fs.constants.R_OK);
  return dir;
}
async function main() {
  const installerDir=resolveInstallerDir(app);
  const appRequire=createRequire(path.join(app,'package.json'));
  const builderRequire=createRequire(appRequire.resolve('electron-builder/package.json'));
  const tools=builderRequire('app-builder-lib/out/targets/nsis/nsisUtil');
  tools.NsisTargetOptions.resolve({});
  const [nsis,resources]=await Promise.all([tools.NSIS_PATH(),tools.NSIS_RESOURCES_PATH()]);
  const command=path.join(nsis,process.platform==='win32'?'Bin':process.platform==='darwin'?'mac':'linux',process.platform==='win32'?'makensis.exe':'makensis');
  const out=path.join(root,'generated-artifacts/nsis-customization-check');
  fs.mkdirSync(out,{recursive:true});
  const results=[];
  for(const uninstall of [false,true]) {
    const probe=createProbe({installerDir,resources,out,uninstall}),name=probe.name;
    fs.writeFileSync(probe.scriptFile,probe.source);
    console.log(`[K99 NSIS] include=${probe.includePath}; cwd=${probe.cwd}; script=${probe.scriptFile}`);
    const result=spawnSync(command,probe.args,{
      cwd:probe.cwd,encoding:'utf8',maxBuffer:8*1024*1024,timeout:120000,
      env:{...process.env,NSISDIR:nsis},
    });
    const log=(result.stdout||'')+(result.stderr||'');
    fs.writeFileSync(path.join(out,name+'.log'),log);
    console.log(log);
    if(result.error)throw result.error;
    if(result.status!==0)throw Error(`${name} NSIS customization compile failed (${result.status}); see ${name}.log`);
    results.push({phase:name,compilePassed:true,warningsAsErrors:true,includePath:probe.includePath,script:probe.scriptFile});
  }
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({
    platform:process.platform,scope:'Synthetic NSIS header probes only; NOT the K99 application installer',
    results,windowsApplicationPackagingVerified:false,windows11InstallationVerified:false,
  },null,2));
}
if(require.main===module)main().catch(error=>{console.error(`::error title=K99 NSIS customization failed::${error.message}`);process.exitCode=1;});
module.exports={createProbe,resolveInstallerDir};
