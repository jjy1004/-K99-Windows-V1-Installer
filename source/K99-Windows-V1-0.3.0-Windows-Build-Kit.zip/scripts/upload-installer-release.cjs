'use strict';
// Maintainer-only release upload. No HTTP upload endpoint and no user data.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {createRequire}=require('node:module');
const root=path.resolve(__dirname,'..');
const req=createRequire(path.join(root,'artifacts/api-server/package.json'));
const {Client}=req('@replit/object-storage');
async function main(){
  const index=process.argv.indexOf('--manifest');
  const release=index<0?req('./src/installer-release.json'):
    JSON.parse(fs.readFileSync(path.resolve(root,process.argv[index+1]||''),'utf8'));
  const client=new Client({bucketId:release.bucketId});
  for(const asset of [release,...release.portable?[release.portable]:[]]){
  if(path.basename(asset.filename)!==asset.filename)throw Error('잘못된 배포 파일명');
  const file=path.join(root,'generated-artifacts',asset.filename);
  if(fs.statSync(file).size!==asset.bytes)throw Error('배포 파일 크기 불일치');
  const digest=crypto.createHash('sha256');
  for await(const chunk of fs.createReadStream(file))digest.update(chunk);
  if(digest.digest('hex')!==asset.sha256)throw Error('배포 파일 SHA-256 불일치');
  const existing=await client.exists(asset.objectName);
  if(!existing.ok)throw Error('영구 저장소 연결 실패');
  if(!existing.value){
    const upload=await client.uploadFromFilename(asset.objectName,file,{compress:false});
    if(!upload.ok)throw Error('설치 파일 영구 업로드 실패');
  }
  const remoteDigest=crypto.createHash('sha256');let bytes=0;
  for await(const chunk of client.downloadAsStream(asset.objectName,{decompress:false})){
    remoteDigest.update(chunk);bytes+=chunk.length;
  }
  if(bytes!==asset.bytes||remoteDigest.digest('hex')!==asset.sha256)
    throw Error('영구 저장소 원격 파일 무결성 검사 실패');
  console.log(JSON.stringify({uploaded:!existing.value,remoteIntegrityVerified:true,
    filename:asset.filename,version:release.version,bytes,sha256:asset.sha256},null,2));
  }
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
