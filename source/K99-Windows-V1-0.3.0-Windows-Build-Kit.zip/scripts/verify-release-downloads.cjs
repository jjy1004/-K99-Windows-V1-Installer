'use strict';
// Public release files/health only. No login, database, Gemini inference or upload.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
async function main(){
  const index=process.argv.indexOf('--base');
  if(index<0||!process.argv[index+1])throw Error('--base 다운로드 서버 주소가 필요합니다.');
  const base=new URL(process.argv[index+1]);
  if(base.username||base.password||base.search||base.hash||
    !['http:','https:'].includes(base.protocol)||
    (base.protocol==='http:'&&!['127.0.0.1','localhost'].includes(base.hostname)))
    throw Error('HTTPS 또는 로컬 검증 서버만 허용합니다.');
  const release=JSON.parse(fs.readFileSync(path.join(root,'artifacts/api-server/src/installer-release.json')));
  const health=await fetch(new URL('/api/healthz',base),{signal:AbortSignal.timeout(30000)});
  const development=process.argv.includes('--development');
  if(development&&!base.hostname.endsWith('.replit.dev')&&!['127.0.0.1','localhost'].includes(base.hostname))
    throw Error('개발 모드는 개발 도메인에서만 허용합니다.');
  const body=await health.json();
  if(!health.ok||(development?body.status!=='ok':body.service!=='k99-carelabel-proxy'))
    throw Error('API 건강 검사 실패');
  const results=[];
  for(const file of [release,...release.portable?[release.portable]:[]]){
    const url=new URL('/api/dev-downloads/'+file.filename,base);
    const head=await fetch(url,{method:'HEAD',signal:AbortSignal.timeout(30000)});
    if(!head.ok||head.headers.get('content-length')!==String(file.bytes)||
      head.headers.get('x-checksum-sha256')!==file.sha256||!head.headers.get('cache-control')?.includes('no-store'))
      throw Error('다운로드 HEAD/릴리스 정보 불일치: '+file.filename);
    const checksum=await fetch(url.href+'.sha256',{signal:AbortSignal.timeout(30000)});
    if(!checksum.ok||(await checksum.text()).trim()!==`${file.sha256}  ${file.filename}`)
      throw Error('다운로드 체크섬 파일 불일치: '+file.filename);
    const fullGETVerified=!process.argv.includes('--head-only');
    if(fullGETVerified){
      const response=await fetch(url,{signal:AbortSignal.timeout(240000)});
      if(!response.ok||!response.body)throw Error('다운로드 GET 실패: '+file.filename);
      if(response.headers.has('content-length'))throw Error('대용량 GET에 고정 Content-Length가 남아 있습니다: '+file.filename);
      const hash=crypto.createHash('sha256');let bytes=0;
      for await(const chunk of response.body){bytes+=chunk.length;hash.update(chunk);}
      if(bytes!==file.bytes||hash.digest('hex')!==file.sha256)throw Error('HTTP 전체 파일 무결성 불일치: '+file.filename);
    }
    results.push({filename:file.filename,bytes:file.bytes,sha256:file.sha256,headVerified:true,checksumVerified:true,fullGETVerified});
  }
  console.log(JSON.stringify({base:base.origin,serverMode:development?'development':'production',version:release.version,files:results},null,2));
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
