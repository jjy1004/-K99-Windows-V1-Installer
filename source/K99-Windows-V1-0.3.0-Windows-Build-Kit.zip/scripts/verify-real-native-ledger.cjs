'use strict';
// Explicitly supplied REAL customer workbook only; no browser or synthetic ledger.
// All customer-bearing test output stays in a disposable private SQLite directory.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const base=path.resolve(__dirname,'../lib/k99-local');
const XLSX=require(path.join(base,'node_modules/xlsx')),D=require(path.join(base,'node_modules/better-sqlite3'));
const {createDesktopManager}=require(path.join(base,'desktop-manager.cjs'));
const {readWorkbookPlan}=require(path.join(base,'native-ledger-file.cjs'));
async function run(){
  if(!process.argv[2])throw Error('실제 장부 파일 경로를 인자로 지정하세요. 기본값/Mock 파일은 사용하지 않습니다.');
  const source=path.resolve(process.argv[2]),root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-real-ledger-'));
  const digest=()=>crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex');
  const before=digest(),password=crypto.randomUUID()+crypto.randomUUID();let manager;
  try{
    const plan=readWorkbookPlan(source);
    manager=createDesktopManager(root,{dbName:'k99.db',nativeDesktop:true});
    manager.store.api('POST','/api/desktop/admin/setup',{password});
    const first=await manager.importLedger(source,password);
    assert.equal(first.success,true);assert.equal(first.customerCount,plan.customers.length);
    const again=await manager.importLedger(source,password);assert.equal(again.orderCount,0);
    await assert.rejects(()=>manager.importLedger(source,'incorrect'),/비밀번호/);
    manager.close();manager=null;
    const db=new D(path.join(root,'data','k99.db'),{readonly:true});
    assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.equal(db.pragma('foreign_key_check').length,0);
    const totals=db.prepare("SELECT count(*) orders,sum(item_count) items,sum(total_amount) amount FROM orders WHERE record_kind='history' AND excluded=0").get();
    const c=db.prepare('SELECT * FROM customers WHERE length(phone)>=8 ORDER BY id LIMIT 1').get();db.close();
    manager=createDesktopManager(root,{dbName:'k99.db',nativeDesktop:true});
    if(c){
      const found=manager.store.api('GET','/api/customers/search?q='+c.phone.slice(-4)).customers;
      assert.ok(found.length<=10);
      const h=manager.store.api('GET','/api/customers/'+c.id+'/history');
      assert.equal(new Set(h.recentVisits.map(v=>v.visitDate)).size,h.recentYear.visitCount);
      assert.equal(h.recentVisits.reduce((n,v)=>n+v.itemCount,0),h.recentYear.itemCount);
      assert.equal(h.recentVisits.reduce((n,v)=>n+v.totalAmount,0),h.recentYear.totalAmount);
    }
    const config=manager.store.equipment.getConfig();
    assert.equal(config.footSwitchKey,'Enter');assert.equal(config.printerName,'TSC TE210');
    assert.equal(config.photoArchiveRoot,'D:\\고객 세탁 사진');assert.equal(config.mode,'real');
    assert.equal(manager.store.status().orderCount,0);manager.close();manager=null;
    const book=XLSX.readFile(source,{cellDates:true}),xls=path.join(root,'actual-conversion.xls');
    XLSX.writeFile(book,xls,{bookType:'biff8'});
    const converted=readWorkbookPlan(xls);
    assert.equal(converted.customers.length,plan.customers.length);assert.equal(converted.visits.length,plan.visits.length);
    if(book.Sheets['통합접수']){
      const rows=XLSX.utils.sheet_to_json(book.Sheets['통합접수'],{header:1,raw:true,defval:''});
      const headers=rows[0],cols=['고객명','연락처','접수일','품목/비고','가격'].map(h=>headers.indexOf(h));
      const actualRows=rows.slice(1).filter(r=>String(r[cols[1]]).replace(/\D/g,'').length>=8&&r[cols[3]]&&r[cols[4]])
        .slice(0,5).map(r=>cols.map(i=>r[i]));
      const csv=path.join(root,'actual-csv.csv');
      fs.writeFileSync(csv,'\ufeff'+XLSX.utils.sheet_to_csv(XLSX.utils.aoa_to_sheet([['고객','휴대폰','날짜','의류','금액'],...actualRows],{dateNF:'yyyy-mm-dd'})));
      const csvPlan=readWorkbookPlan(csv);
      assert.equal(csvPlan.visits.length,actualRows.length);
      assert.equal(csvPlan.visits.reduce((n,v)=>n+v.itemCount,0),actualRows.length);
    }
    assert.equal(digest(),before);
    console.log('REAL FILE / PERSISTENT SQLITE / REOPEN / DUPLICATE / ADMIN / SQL SEARCH / 365-DAY / XLS / CSV: PASS');
    console.log(JSON.stringify({customers:first.customerCount,...totals,integrity:'ok',foreignKeyErrors:0,sourceUnchanged:true,windowsTested:false}));
  }finally{manager?.close();fs.rmSync(root,{recursive:true,force:true});}
}
run().catch(e=>{console.error(e.message);process.exitCode=1;});
