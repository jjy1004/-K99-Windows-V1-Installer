'use strict';
// Chromium UI test against an OS-temporary manager. CDP intercepts EVERY /api/
// request: neither the existing preview DB nor any shop system is modified.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {spawn}=require('node:child_process'),assert=require('node:assert/strict');
const {createDesktopManager}=require('../lib/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('../lib/k99-local/equipment-api.cjs');
async function main() {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-stage3-browser-'));
  const manager=createDesktopManager(path.join(root,'store'),{nativeDesktop:true}),equipment=createEquipmentApi(manager.store);
  const chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage',
    '--remote-debugging-port=0',`--user-data-dir=${path.join(root,'browser')}`,'about:blank'],{stdio:['ignore','ignore','pipe']});
  let socket,seq=0;const pending=new Map(),checks=[];
  const delay=ms=>new Promise(r=>setTimeout(r,ms));
  const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
    const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(`CDP timeout ${method}`));},20000);
    pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));
  });
  try {
    const endpoint=await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('Chromium startup timeout')),20000);
      chrome.stderr.on('data',chunk=>{const m=String(chunk).match(/DevTools listening on (ws:\/\/\S+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
      chrome.on('error',reject);
    });
    socket=new WebSocket(endpoint);await new Promise((res,rej)=>{socket.onopen=res;socket.onerror=rej;});
    socket.onmessage=async event=>{
      const msg=JSON.parse(event.data);
      if(msg.method==='Fetch.requestPaused') {
        const req=msg.params.request,url=new URL(req.url),input=req.postData?JSON.parse(req.postData):{};
        let result,code=200,bytes,type='application/json';
        try {
          if(url.pathname==='/api/local/storage')result={ok:true,result:manager.store.storage(input)};
          else if(url.pathname.startsWith('/api/maintenance/'))result=await manager.api(req.method,url.pathname,input,{native:true,packaged:false});
          else if(url.pathname.startsWith('/api/equipment/photos/')) {
            const photo=manager.store.equipment.photoFile(url.pathname.split('/').at(-1));bytes=photo.bytes;type=photo.contentType;
          }else if(url.pathname.startsWith('/api/equipment/'))result=await equipment.api(req.method,url.pathname,input);
          else result=manager.store.api(req.method,url.pathname,input);
        }catch(e){code=e.status||500;result={error:e.message};}
        await send('Fetch.fulfillRequest',{requestId:msg.params.requestId,responseCode:code,
          responseHeaders:[{name:'Content-Type',value:type},{name:'Cache-Control',value:'no-store'}],
          body:(bytes||Buffer.from(JSON.stringify(result))).toString('base64')},msg.sessionId);
        return;
      }
      const item=pending.get(msg.id);if(!item)return;pending.delete(msg.id);clearTimeout(item.timer);
      msg.error?item.reject(Error(JSON.stringify(msg.error))):item.resolve(msg.result);
    };
    const {targetId}=await send('Target.createTarget',{url:'about:blank'});
    const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
    await send('Runtime.enable',{},sessionId);
    await send('Page.enable',{},sessionId);
    // Chrome normalizes away the default :80 port in request URLs.
    await send('Fetch.enable',{patterns:[{urlPattern:'*/api/*',requestStage:'Request'}]},sessionId);
    // Isolate legacy synchronous storage before bootstrap. Async API calls use
    // the temporary manager above, never the running preview's data.
    await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
      const fetchNative=window.fetch.bind(window),NativeXHR=window.XMLHttpRequest;
      window.k99Desktop={
        storage:input=>{
          const r=new NativeXHR();r.open('POST','/api/local/storage',false);
          r.setRequestHeader('Content-Type','application/json');r.send(JSON.stringify(input));
          return JSON.parse(r.responseText);
        },
        request:async input=>{
          const r=await fetchNative(input.path,{method:input.method,headers:{'Content-Type':'application/json'},
            ...(input.method==='GET'?{}:{body:JSON.stringify(input.body||{})})});
          const data=await r.json();return r.ok?{ok:true,result:data}:{ok:false,error:data.error,status:r.status};
        }
      };
    })()`},sessionId);
    await send('Page.navigate',{url:'http://127.0.0.1:80/maintenance'},sessionId);
    const evaluate=async expression=>{
      const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},sessionId);
      if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;
    };
    const selector=id=>`[data-testid="${id}"]`;
    async function wait(expression) {
      for(let i=0;i<120;i++){if(await evaluate(expression))return;await delay(100);}
      const errors=await evaluate(`Array.from(document.querySelectorAll('[role="alert"]')).map(n=>n.textContent)`);
      const startup=await evaluate(`(document.getElementById('root')?.textContent||'').slice(0,120)`);
      throw Error(`UI timeout ${expression} ${JSON.stringify(errors)} ${startup}`);
    }
    async function click(id) {
      const s=JSON.stringify(selector(id));
      await wait(`!!document.querySelector(${s})&&!document.querySelector(${s}).disabled`);
      await evaluate(`document.querySelector(${s}).click()`);await delay(100);
    }
    async function input(id,text) {
      await evaluate(`(()=>{const el=document.querySelector(${JSON.stringify(selector(id))});el.focus();el.select();})()`);
      await send('Input.insertText',{text},sessionId);await delay(80);
    }
    const passed=name=>{checks.push(name);console.log('PASS '+name);};
    await wait(`!!document.querySelector('[data-testid="backup-create"]')&&!document.querySelector('[data-testid="backup-create"]').disabled`);
    assert.equal(await evaluate(`!!document.querySelector('[data-testid="maintenance-password"]')`),false);
    assert.equal(await evaluate(`!!document.querySelector('[data-testid="button-v1-import"]')`),true);
    passed('current passwordless desktop opens backup and V1 transition controls without an administrator password');
    manager.store.storage({op:'set',key:'k99-confirmed-orders-v1',expected:null,value:JSON.stringify([{
      id:'STAGE3-UI-A',customerName:'임시검증고객',customerPhone:'01000000000',customerAddress:'',
      items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:14000,isSneaker:false}],
      choices:{serviceLevel:'general'},estimatedTotal:5000,
      garments:[{orderId:'STAGE3-UI-A',garmentId:'STAGE3-UI-A-01',barcodeValue:'STAGE3-UI-A-01',itemName:'와이셔츠',serviceType:'general'}],
    }])});
    const garments=manager.store.equipment.state().orders[0].garments;
    manager.store.equipment.capture({orderId:'STAGE3-UI-A',garmentId:garments[0].garmentId,role:'intake',requestId:'stage3-photo-0001',
      imageDataUrl:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jVioAAAAASUVORK5CYII='});
    await click('backup-create');
    await wait(`document.querySelector('[data-testid="text-maintenance-message"]')?.textContent.includes('백업')&&!document.querySelector('[data-testid="backup-create"]').disabled`);
    const backupId=manager.status().backups.find(b=>b.reason==='manual').id;
    await click(`option-backup-${backupId}`);await click('backup-verify');
    await wait(`document.querySelector('[data-testid="text-maintenance-message"]')?.textContent.includes('통과')`);
    passed('integrated manual backup and verification show real success');
    await click('backup-key-show');
    await wait(`!!document.querySelector('[data-testid="text-backup-key"]')`);
    assert.equal(manager.store.status().orderCount,1);
    passed('backup-key display leaves the order and photo intact without reinstating removed password gates');
    const previous=manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),orders=JSON.parse(previous);
    orders.push({...orders[0],id:'STAGE3-UI-B',garments:[]});
    manager.store.storage({op:'set',key:'k99-confirmed-orders-v1',value:JSON.stringify(orders),expected:previous});
    await click(`option-backup-${backupId}`);
    await input('backup-confirmation','K99 복구');await click('backup-restore-check');await click('backup-restore');
    await wait(`document.querySelector('[data-testid="text-maintenance-message"]')?.textContent.includes('복원')`);
    assert.equal(manager.store.status().orderCount,1);
    assert.equal(manager.store.equipment.state().photos.length,1);
    assert.equal(manager.store.equipment.state().jobs[0].status,'unknown');
    passed('explicit restore returns the chosen dataset and keeps a safety backup');
    await wait(`window.location.pathname==='/'`);
    passed('restore discards stale renderer state and returns to reception');
    fs.mkdirSync('generated-artifacts',{recursive:true});
    fs.writeFileSync('generated-artifacts/stage3-browser-result.json',JSON.stringify({
      checks,temporaryDatabase:true,windowsTested:false,physicalDevicesTested:false,
    },null,2));
  }finally {
    socket?.close();chrome.kill('SIGTERM');await delay(300);manager.close();
    await fsp.rm(root,{recursive:true,force:true});
  }
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
