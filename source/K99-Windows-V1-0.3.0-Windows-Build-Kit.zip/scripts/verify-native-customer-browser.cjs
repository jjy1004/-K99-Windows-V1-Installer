'use strict';
// Chromium + real display coordinator + virtual screen/IPC, NOT Windows Electron.
// All API calls use an OS-temporary SQLite; all storage uses a fresh browser profile.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawn}=require('node:child_process'),{EventEmitter}=require('node:events'),assert=require('node:assert/strict');
const {createRequire}=require('node:module');
const {createDesktopManager}=require('../lib/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('../lib/k99-local/equipment-api.cjs');
const {createCustomerDisplay}=require('../artifacts/k99-windows/electron/customer-display.cjs');
const {videoResponse}=require('../artifacts/k99-windows/electron/customer-video.cjs');
const {createPhotoArchive}=require('../artifacts/k99-windows/electron/photo-archive.cjs');
async function main(){
  const packagedArg=process.argv.indexOf('--packaged-root');
  const packagedRoot=packagedArg<0?null:path.resolve(process.argv[packagedArg+1]);
  const fixtureModules=new Map();
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-native-browser-')),manager=createDesktopManager(path.join(root,'store'));
  // Native IPC/vault fixture uses a temporary cipher, not a real Windows DPAPI claim.
  const accountKey=crypto.randomBytes(32);
  const accountVault=require('../artifacts/k99-windows/electron/ai-account-vault.cjs').createAiAccountVault({
    userData:root,platform:'win32',safeStorage:{isEncryptionAvailable:()=>true,
      encryptString(text){const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',accountKey,iv);
        const bytes=Buffer.concat([cipher.update(text,'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),bytes]);},
      decryptString(bytes){const d=crypto.createDecipheriv('aes-256-gcm',accountKey,bytes.subarray(0,12));d.setAuthTag(bytes.subarray(12,28));
        return Buffer.concat([d.update(bytes.subarray(28)),d.final()]).toString('utf8');},
    }});
  const videos=packagedRoot?path.join(packagedRoot,'videos'):path.resolve(__dirname,'../generated-artifacts/windows-app/videos'),checks=[],sessions={};
  const idleFolder=path.join(root,'03_고객모니터영상');fs.mkdirSync(idleFolder);
  let idleFolderOpened=false;
  const programLaunches=[];
  let memberImportFile=null;
  const idleVideos=require('../artifacts/k99-windows/electron/idle-videos.cjs').createIdleVideos({
    folder:idleFolder,openPath:async()=>{idleFolderOpened=true;return '';}});
  let capturedOrderId=null,lastComparisonSession=null,photoRetention,automaticTags,comparisonGallery,comparisonGalleryApi,singleMonitor=false;
  const chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage',
    ...(process.argv.includes('--reception-sidebar-only')?['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']:[]),
    '--autoplay-policy=no-user-gesture-required','--remote-debugging-port=0',`--user-data-dir=${path.join(root,'browser')}`,'about:blank'],
    {stdio:['ignore','ignore','pipe']});
  let socket,seq=0,display,customerWindow,closing=false,asyncError,mobile,comparisonMobile;const pending=new Map();
  const delay=ms=>new Promise(r=>setTimeout(r,ms));
  const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
    if(closing){reject(Error('Browser verification shutdown'));return;}
    const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(`CDP timeout ${method}`));},20000);
    pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));
  });
  const evaluate=async(role,expression)=>{
    const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessions[role]);
    if(r.exceptionDetails)throw Error(r.exceptionDetails.text+': '+r.exceptionDetails.exception?.description);
    return r.result?.value;
  };
  const deliver=(role,channel,data)=>{void evaluate(role,`window.__nativeDeliver?.(${JSON.stringify(channel)},${JSON.stringify(data)})`).catch(()=>{});};
  async function wait(role,expression){
    const end=Date.now()+15000;
    while(Date.now()<end){if(await evaluate(role,expression))return;await delay(80);}
    const diagnostic=await evaluate(role,`JSON.stringify({url:location.href,title:document.title,
      ready:document.readyState,camera:{zoom:document.querySelector('[data-testid="camera-zoom"]')?.textContent,
        foot:!!document.querySelector('[data-testid="status-ndc-foot"]'),hidden:document.hidden,
        focus:document.activeElement?.tagName,field:document.activeElement?.getAttribute('data-testid')},
      connection:document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent,
      editor:[...document.querySelectorAll('.bam__stage')].map(e=>({w:e.clientWidth,h:e.clientHeight,html:e.innerHTML.slice(0,500)})),
      images:[...document.querySelectorAll('.bam__stage img')].map(e=>({src:e.src,complete:e.complete,w:e.naturalWidth,h:e.naturalHeight})),
      editorError:document.querySelector('[data-testid="status-render-error"]')?.textContent,
      media:[...document.querySelectorAll('video')].map(v=>({src:v.currentSrc,ready:v.readyState,error:v.error?.code})),
      finalError:document.querySelector('[data-testid="status-final-intake-error"]')?.textContent,
      validation:document.querySelector('[data-testid="status-final-intake-validation"]')?.textContent,
      text:document.body.innerText.slice(0,700),tail:document.body.innerText.slice(-700)})`).catch(()=>null);
    throw Error(`UI timeout (${role}): ${expression}\n${diagnostic}`);
  }
  const pass=message=>{checks.push(message);console.log('PASS',message);};
  try{
    const endpoint=await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('Chromium startup timeout')),20000);
      chrome.stderr.on('data',b=>{const m=String(b).match(/DevTools listening on (ws:\/\/\S+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
      chrome.on('error',reject);
    });
    socket=new WebSocket(endpoint);await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
    const handleMessage=async event=>{
      const msg=JSON.parse(event.data);
      if(msg.method==='Runtime.exceptionThrown')console.error('Renderer exception:',msg.params.exceptionDetails?.exception?.description||msg.params.exceptionDetails?.text);
      if(msg.method==='Runtime.bindingCalled'){
        const role=Object.keys(sessions).find(k=>sessions[k]===msg.sessionId),call=JSON.parse(msg.params.payload);
        try{
          let value;
          if(call.op==='action'){assert.equal(role,'staff');display.action(call.args);}
          else if(call.op==='ai-account'){
            assert.equal(role,'staff');
            value={success:true,...(call.args.action==='save'?accountVault.save(call.args):call.args.action==='clear'?accountVault.clear():accountVault.status())};
          }
          else if(call.op==='storage-layout'){
            assert.equal(role,'staff');
            value=call.args.action==='change'?{success:false,cancelled:true}:{success:true,root:'E:\\K99_스마트접수',
              folders:['program','intake','compare','backup','videos'].map(key=>({key,path:'E:\\K99_스마트접수\\'+key,ready:true}))};
          }
          else if(call.op==='open-program'){
            assert.equal(role,'staff');
            const api=require('../artifacts/k99-windows/electron/program-integrations.cjs');
            const settings=api.settingsWithDefaults(JSON.parse(manager.store.storage({op:'get',key:api.SETTINGS_KEY})||'null'));
            const url=call.args.kind==='prescription'?api.prescriptionUrl(settings.prescriptionUrl,call.args):settings.luxuryTarget;
            programLaunches.push({kind:call.args.kind,url});value={success:true};
          }
          else if(call.op==='import-ledger'){
            assert.equal(role,'staff');assert.ok(memberImportFile);
            value=await manager.importLedger(memberImportFile);
            deliver('staff','k99:changed');
          }
          else if(call.op==='idle-videos'){
            if(call.args!=='list')assert.equal(role,'staff');
            value=call.args==='open'?await idleVideos.open():idleVideos.list();
            if(value.files)value.files=value.files.map(f=>({...f,url:f.url.replace('k99://app','http://localhost')}));
            if(call.args==='refresh')for(const target of ['staff','customer'])deliver(target,'k99:idle-videos-changed');
          }
          else if(call.op==='event'){assert.equal(role,'customer');display.customerEvent(customerWindow.webContents,call.args);}
          else if(call.op==='status')value=display.displayStatus();
          else if(call.op==='request'){
            const p=call.args;
            if(p.body?.action==='capture-draft')capturedOrderId=p.body.orderId;
            value=p.path.startsWith('/api/comparison-gallery/')&&comparisonGalleryApi?await comparisonGalleryApi(p.method,p.path,p.body):
              p.path.startsWith('/api/photo-retention/')&&photoRetention?await photoRetention.api(p.method,p.path,p.body):
              p.method==='POST'&&p.path==='/api/care-label/finalize'?await automaticTags.finalize(p.body?.orderId):
              p.path.startsWith('/api/comparison-mobile/')&&comparisonMobile?await comparisonMobile.api(p.method,p.path,p.body):
              p.path.startsWith('/api/mobile-photo/')&&mobile?await mobile.api(p.method,p.path,p.body):
              p.path.startsWith('/api/equipment/')?await equipment.api(p.method,p.path,p.body):
              p.path.startsWith('/api/maintenance/')?await manager.api(p.method,p.path,p.body):await manager.store.api(p.method,p.path,p.body);
            if(p.path==='/api/comparison-mobile/start')lastComparisonSession=value;
            value={ok:true,result:value};
          }else throw Error('Unsupported mock IPC');
          if(call.id)await evaluate(role,`window.__nativeReply(${JSON.stringify(call.id)},${JSON.stringify(value)},null)`);
        }catch(error){if(call.id)await evaluate(role,`window.__nativeReply(${JSON.stringify(call.id)},null,${JSON.stringify(error.message)})`);}
        return;
      }
      if(msg.method==='Fetch.requestPaused'){
        const {request,requestId}=msg.params;
        if(new URL(request.url).pathname==='/api/local/storage'){
          let reply;
          try{reply={ok:true,result:manager.store.storage(JSON.parse(request.postData))};}
          catch(error){reply={ok:false,error:error.message,status:error.status||500};}
          await send('Fetch.fulfillRequest',{requestId,responseCode:200,
            responseHeaders:[{name:'Content-Type',value:'application/json'}],
            body:Buffer.from(JSON.stringify(reply)).toString('base64')},msg.sessionId);return;
        }
        if(new URL(request.url).pathname.startsWith('/comparison-photos/')){
          const reply=comparisonGallery.response(new Request(request.url,{method:request.method}));
          await send('Fetch.fulfillRequest',{requestId,responseCode:reply.status,
            responseHeaders:[...reply.headers].map(([name,value])=>({name,value})),
            body:Buffer.from(await reply.arrayBuffer()).toString('base64')},msg.sessionId);return;
        }
        if(new URL(request.url).pathname.startsWith('/api/equipment/photos/')){
          const photo=manager.store.equipment.photoFile(new URL(request.url).pathname.split('/').at(-1));
          await send('Fetch.fulfillRequest',{requestId,responseCode:200,
            responseHeaders:[{name:'Content-Type',value:photo.contentType}],
            body:photo.bytes.toString('base64')},msg.sessionId);return;
        }
        if(new URL(request.url).pathname.startsWith('/api/'))throw Error('Unexpected API escaped mock IPC');
        if(packagedRoot&&!/^\/(?:videos|idle-videos)\//.test(new URL(request.url).pathname)){
          const pathname=decodeURIComponent(new URL(request.url).pathname);
          // These two test-only helpers seed/read synthetic orders; they are not
          // UI entrypoints. Production UI/assets below still come only from ZIP.
          if(['/src/order-record.ts','/src/garment-record.ts'].includes(pathname)){
            if(!fixtureModules.has(pathname)){
              const appRequire=createRequire(path.resolve(__dirname,'../artifacts/k99-windows/package.json'));
              const esbuild=createRequire(appRequire.resolve('vite'))('esbuild');
              fixtureModules.set(pathname,esbuild.buildSync({
                entryPoints:[path.resolve(__dirname,'../artifacts/k99-windows',pathname.slice(1))],
                bundle:true,write:false,platform:'browser',format:'esm',
              }).outputFiles[0].contents);
            }
            await send('Fetch.fulfillRequest',{requestId,responseCode:200,
              responseHeaders:[{name:'Content-Type',value:'text/javascript'}],
              body:Buffer.from(fixtureModules.get(pathname)).toString('base64')},msg.sessionId);
            return;
          }
          const base=path.join(packagedRoot,'renderer');
          let file=path.resolve(base,'.'+pathname);
          if(!file.startsWith(base+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile())
            file=path.join(base,'index.html');
          const contentType={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml',
            '.png':'image/png','.ico':'image/x-icon','.woff2':'font/woff2'}[path.extname(file)]||'application/octet-stream';
          await send('Fetch.fulfillRequest',{requestId,responseCode:200,
            responseHeaders:[{name:'Content-Type',value:contentType},{name:'Cache-Control',value:'no-store'}],
            body:fs.readFileSync(file).toString('base64')},msg.sessionId);
          return;
        }
        const response=new URL(request.url).pathname.startsWith('/idle-videos/')?
          await idleVideos.response(new Request(request.url,{headers:request.headers})):
          await videoResponse(new Request(request.url,{headers:request.headers}),videos);
        try{
          await send('Fetch.fulfillRequest',{requestId,responseCode:response.status,responseHeaders:[...response.headers].map(([name,value])=>({name,value})),
            body:Buffer.from(await response.arrayBuffer()).toString('base64')},msg.sessionId);
        }catch(error){
          // Seeking/ending video legitimately cancels an in-flight Range request.
          if(!/Invalid InterceptionId/.test(error.message))throw error;
        }
        return;
      }
      const item=pending.get(msg.id);if(!item)return;pending.delete(msg.id);clearTimeout(item.timer);
      msg.error?item.reject(Error(JSON.stringify(msg.error))):item.resolve(msg.result);
    };
    socket.onmessage=event=>{void handleMessage(event).catch(error=>{
      // Navigating/closing an image can cancel its paused request before fulfillment.
      if(!closing&&!/Invalid InterceptionId/.test(error.message)){asyncError=error;console.error('Browser event failed:',error.message);}
    });};
    for(const role of ['staff','customer']){
      const {targetId}=await send('Target.createTarget',{url:'about:blank'});
      sessions[role]=(await send('Target.attachToTarget',{targetId,flatten:true})).sessionId;
      const id=sessions[role];await send('Page.enable',{},id);await send('Runtime.enable',{},id);
      await send('Runtime.addBinding',{name:'__nativeCall'},id);
      await send('Fetch.enable',{patterns:[{urlPattern:'*/videos/*'},{urlPattern:'*/idle-videos/*'},{urlPattern:'*/comparison-photos/*'},{urlPattern:'*/api/*'},
        ...(packagedRoot?[{urlPattern:'http://localhost/*'}]:[])]},id);
      await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
        const cameraStreams=[];
        const getMedia=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
        navigator.mediaDevices.getUserMedia=async options=>{const stream=await getMedia(options);cameraStreams.push(stream);return stream;};
        window.__disconnectTestCameras=()=>cameraStreams.forEach(s=>s.getTracks().forEach(t=>t.stop()));
        const raw=window.localStorage,NativeXHR=window.XMLHttpRequest,listeners={},pending=new Map();
        const call=(op,args)=>new Promise((resolve,reject)=>{const id=crypto.randomUUID();pending.set(id,{resolve,reject});__nativeCall(JSON.stringify({op,args,id}));});
        window.__nativeReply=(id,value,error)=>{const p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(Error(error)):p.resolve(value);};
        window.__nativeDeliver=(channel,data)=>(listeners[channel]||[]).forEach(fn=>fn(data));
        const on=(channel,fn)=>{(listeners[channel]||=[]).push(fn);return ()=>{listeners[channel]=listeners[channel].filter(f=>f!==fn);};};
        window.k99Desktop={storage:i=>{
          const x=new NativeXHR();x.open('POST','/api/local/storage',false);
          x.setRequestHeader('Content-Type','application/json');x.send(JSON.stringify(i));return JSON.parse(x.responseText);
        },request:p=>call('request',p),customerStatus:()=>call('status'),
          idleVideos:action=>call('idle-videos',action),
          openProgram:input=>call('open-program',input),
          importCustomerLedger:()=>call('import-ledger'),
          aiAccount:input=>call('ai-account',input),
          storageLayout:input=>call('storage-layout',input),
          onLuxuryResult:fn=>on('k99:luxury-result',fn),
          onIdleVideosChanged:fn=>on('k99:idle-videos-changed',fn),
          customerAction:args=>__nativeCall(JSON.stringify({op:'action',args})),
          customerEvent:args=>__nativeCall(JSON.stringify({op:'event',args})),
          onChanged:fn=>on('k99:changed',fn),onCustomerUpdate:fn=>on('customer-update',fn),
          onCustomerConnection:fn=>on('customer-connection',fn)};
      })();`},id);
    }
    class Window extends EventEmitter{
      constructor(options){super();this.options=options;this.webContents=new EventEmitter();this.dead=false;
        this.webContents.setWindowOpenHandler=()=>{};this.webContents.send=(channel,data)=>deliver('customer',channel,data);customerWindow=this;}
      async loadURL(){await send('Page.navigate',{url:'http://localhost/customer'},sessions.customer);}
      show(){}isDestroyed(){return this.dead;}close(){this.emit('close');this.dead=true;this.emit('closed');}setBounds(){}
      isMinimized(){return !!this.minimized;}restore(){this.minimized=false;}
      focus(){this.focused=true;}setAlwaysOnTop(value){this.top=value;}setFullScreen(value){this.fullscreen=value;}
    }
    const screen=new EventEmitter();
    screen.getAllDisplays=()=>[{id:1,label:'Staff',bounds:{x:0,y:0,width:1440,height:900}},
      ...singleMonitor?[]:[{id:2,label:'LG FULL HD mock',bounds:{x:1440,y:0,width:1920,height:1080}}]];
    screen.getPrimaryDisplay=()=>screen.getAllDisplays()[0];
    display=createCustomerDisplay({BrowserWindow:Window,screen,preload:'mock',changed:()=>{},
      onComparisonClosed:id=>comparisonGallery?.revoke(id),
      preferencesFile:path.join(root,'display.json'),
      getMain:()=>({isDestroyed:()=>false,webContents:{send:(channel,data)=>deliver('staff',channel,data)}})});
    const archive=createPhotoArchive({getRoot:()=>path.join(root,'mock-D'),openPath:async()=>'',encodeJpeg:()=>{throw Error('Test expects JPEG canvas');}});
    const printed=[],adapters={native:true,...display,print:async job=>{printed.push(job);},
      archivePhoto:archive.photo,archiveComparison:archive.comparison,openPhotoFolder:archive.open};
    const equipment=createEquipmentApi(manager.store,adapters);
    const galleryModule=require('../lib/k99-local/comparison-gallery.cjs');
    comparisonGallery=galleryModule.createComparisonGallery({store:manager.store,
      filename:path.join(manager.status().dataLocation,'k99.sqlite'),compareRoot:path.join(root,'mock-D/02_세탁전후사진')});
    comparisonGalleryApi=galleryModule.createComparisonGalleryApi({gallery:comparisonGallery,getDisplay:()=>display});
    automaticTags=require('../artifacts/k99-windows/electron/automatic-tag-controller.cjs').createAutomaticTags({
      store:manager.store,equipmentApi:equipment,labels:{enrichDraft:value=>value},offline:true});
    const intakeRoot=path.join(root,'mock-D/01_고객세탁사진');
    fs.mkdirSync(intakeRoot,{recursive:true});
    photoRetention=require('../lib/k99-local/photo-retention.cjs').createPhotoRetention({
      store:manager.store,filename:path.join(manager.status().dataLocation,'k99.sqlite'),intakeRoot,native:true});
    comparisonMobile=require('../artifacts/k99-windows/electron/comparison-mobile-photo.cjs').createComparisonMobilePhotos({
      store:manager.store,equipmentApi:equipment,native:true,port:0,host:'127.0.0.1',addresses:()=>['127.0.0.1'],
      nativeImage:{createFromBuffer:()=>({isEmpty:()=>false,getSize:()=>({width:800,height:600})})}});
    if(process.argv.includes('--reception-sidebar-only')){
      // A real focused camera window is required: Chromium suspends RAF in background tabs.
      await send('Page.bringToFront',{},sessions.staff);
      manager.store.equipment.configure({mode:'real',printerName:'VIRTUAL_TEST_PRINTER',labelWidthMm:30,
        labelHeightMm:40,labelVerified:true,cameraDeviceId:'',hardwareConfirmed:true},true);
      mobile=require('../artifacts/k99-windows/electron/mobile-photo-controller.cjs').createMobilePhotoController({
        store:manager.store,equipmentApi:equipment,archivePhoto:archive.photo,native:true,
        host:'127.0.0.1',port:0,addresses:()=>['127.0.0.1'],
      });
      adapters.archivePhoto=mobile.archivePhoto;
    }
    await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
    await display.restore();
    await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('[연결됨]')`);
    pass('CUSTOMER_READY connects staff/customer through the real coordinator and mock IPC');
    if(process.argv.includes('--manual-capture')){
      // Documentation captures of the real React UI. Only synthetic profiles
      // enter the already-isolated temporary SQLite. No production data.
      const output=path.resolve('generated-artifacts/manual-v2');
      fs.mkdirSync(output,{recursive:true});
      await send('Page.bringToFront',{},sessions.staff);
      await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false},sessions.staff);
      const captures=[];
      async function shot(name,selectors){
        await delay(500);
        const boxes=await evaluate('staff',`(${JSON.stringify(selectors)}).map(s=>{const e=document.querySelector(s);if(!e)return {selector:s,missing:true};
          const r=e.getBoundingClientRect();return {selector:s,text:e.textContent?.trim().slice(0,100),x:r.x,y:r.y,w:r.width,h:r.height};})`);
        fs.writeFileSync(path.join(output,name+'.png'),Buffer.from((await send('Page.captureScreenshot',{format:'png'},sessions.staff)).data,'base64'));
        captures.push({name,boxes});
      }
      memberImportFile=path.join(root,'설명서용-가상고객.xlsx');
      const ExcelJS=createRequire(path.resolve(__dirname,'../lib/k99-local/package.json'))('exceljs');
      const book=new ExcelJS.Workbook();
      book.addWorksheet('고객명단').addRows([['고객명','전화번호','주소','메모'],
        ['연습고객가','01000001234','설명용 주소','실제 고객 아님'],['연습고객나','01011111234','설명용 주소','실제 고객 아님']]);
      await book.xlsx.writeFile(memberImportFile);
      await manager.importLedger(memberImportFile);
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-phone"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'1234'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===2`);
      await evaluate('staff',`document.querySelector('.cdir-list').scrollIntoView({block:'center'})`);
      await shot('04a-customer-search',['[data-testid="input-customer-phone"]','.cdir-list','[data-testid="input-customer-name"]','[data-testid="input-customer-address"]']);
      await evaluate('staff',`document.querySelector('.cdir-list li button').click()`);
      await evaluate('staff',`document.querySelector('[data-testid="button-add-item"]').click()`);
      await wait('staff',`!!document.querySelector('.rcs-camera')`);
      await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
      await wait('staff',`!!document.querySelector('[data-testid="button-ndc-shoot"]')`);
      await shot('04b-camera-controls',['[data-testid="button-ndc-shoot"]','[data-testid="button-camera-zoom"]','[data-testid="button-camera-next"]',
        '[data-testid="button-camera-reset"]','[data-testid="dialog-intake-camera"]','[data-testid="camera-zoom"]']);
      await send('Page.navigate',{url:'http://localhost/management'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="button-management-import-customers"]')`);
      await shot('05a-management',['[data-testid="button-management-import-customers"]']);
      await evaluate('staff',`document.querySelector('[data-testid="button-management-import-customers"]').click()`);
      await wait('staff',`document.activeElement.id==='customer-ledger-import'`);
      await shot('05b-excel-import',['#customer-ledger-import','[data-testid="button-native-ledger-import"]']);
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-phone"]')`);
      await shot('05c-launchers',['[data-testid="button-luxury-launch"]','[data-testid="button-ai-prescription"]','[data-testid="program-launchers"]']);
      fs.writeFileSync(path.join(output,'app-captures.json'),JSON.stringify({capturedAt:new Date().toISOString(),
        realReactUI:true,temporarySqlite:true,syntheticCustomerProfiles:true,electronIpcSimulated:true,
        windowsScreensCaptured:false,physicalDevicesTested:false,captures},null,2));
      return;
    }
    if(process.argv.includes('--comparison-gallery-only')){
      await evaluate('staff',`(async()=>{
        const r=await import('/src/order-record.ts'),g=await import('/src/garment-record.ts');
        for(const [id,name] of [['GALLERY-READY','비교완성'],['GALLERY-EMPTY','사진없음'],['GALLERY-MISSING','파일없음'],['GALLERY-RAW','미완성']]){
          const o=r.createConfirmedOrder({id,customerName:name,customerPhone:'01012345678',customerAddress:'',
            items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
            {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,
              requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''});
          const saved={...o,operations:{...o.operations,stage:'세탁완료',updatedAt:new Date().toISOString()},
            garments:g.createGarmentRecords(o).map(p=>({...p,completionStatus:'complete',processStatus:'출고 대기',
              status:'LAUNDRY_COMPLETED_READY_FOR_HANDOVER'}))};
          r.insertConfirmedOrder(saved);
        }
      })()`);
      const image=await evaluate('staff',`(()=>{const c=document.createElement('canvas');c.width=800;c.height=500;
        const x=c.getContext('2d');x.fillStyle='#facc15';x.fillRect(0,0,400,500);x.fillStyle='#16a34a';x.fillRect(400,0,400,500);
        x.fillStyle='#000';x.font='40px sans-serif';x.fillText('Before',80,250);x.fillText('After',490,250);return c.toDataURL('image/jpeg',.9)})()`);
      const make=async(id,request)=>equipment.api('POST','/api/equipment/command',{action:'save-comparison',orderId:id,requestId:request,imageDataUrl:image});
      await make('GALLERY-READY','gallery-ready-1');await make('GALLERY-READY','gallery-ready-2');
      const missing=await make('GALLERY-MISSING','gallery-missing');
      const dbRequire=createRequire(path.resolve(__dirname,'../lib/k99-local/package.json')),Database=dbRequire('better-sqlite3');
      const db=new Database(path.join(manager.status().dataLocation,'k99.sqlite'),{readonly:true});
      const missingFile=db.prepare('SELECT file FROM equipment_photos WHERE id=?').get(missing.photo.id).file;db.close();
      fs.unlinkSync(path.join(manager.status().dataLocation,'photos',missingFile));
      fs.unlinkSync(path.join(missing.archive.folder,missing.archive.fileName));
      const raw=manager.store.equipment.getOrder('GALLERY-RAW');
      manager.store.equipment.capture({orderId:raw.id,garmentId:raw.garments[0].garmentId,role:'completion',requestId:'raw-unfinished',imageDataUrl:image});
      const baseline=manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'});
      await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
      await wait('staff',`document.querySelectorAll('[data-testid^="card-ready-order-GALLERY-"]').length===4`);
      await wait('staff',`!!document.querySelector('[data-testid="button-card-comparison-GALLERY-READY"]')`);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[data-testid^="button-card-comparison-"]').length`),1);
      pass('only the order with finished, physically present comparison files has an icon; empty, missing-file and unfinished orders do not');
      await evaluate('staff',`document.querySelector('[data-testid="button-card-comparison-GALLERY-READY"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="comparison-image"]')?.naturalWidth===800`);
      await wait('staff',`document.querySelector('[data-testid="comparison-gallery"]')?.dataset.compact==='true'`);
      await wait('staff',`document.querySelector('[data-testid="comparison-gallery"]').textContent.includes('이미지 표시 확인')`);
      assert.equal(customerWindow.fullscreen,true);assert.equal(customerWindow.top,true);
      const full=await evaluate('customer',`(()=>{const r=document.querySelector('[data-testid="comparison-gallery"]').getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,vw:innerWidth,vh:innerHeight}})()`);
      assert.equal(full.x,0);assert.equal(full.y,0);assert.equal(full.w,full.vw);assert.equal(full.h,full.vh);
      pass('customer image decodes at its real dimensions, fills the viewport and acknowledges display; native mock window is foreground/fullscreen');
      await evaluate('staff',`document.querySelector('[data-testid="button-comparison-next"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="comparison-position"]').textContent==='2 / 2'`);
      await evaluate('customer',`document.querySelector('[data-testid="button-comparison-previous"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="comparison-position"]').textContent==='1 / 2'`);
      pass('staff and customer arrows stay synchronized through the real main-process coordinator');
      await evaluate('staff',`document.querySelector('[data-testid="button-close-comparison"]').click()`);
      await wait('customer',`!document.querySelector('[data-testid="comparison-gallery"]')&&[...document.querySelectorAll('video')].some(v=>v.loop&&v.muted)`);
      await wait('customer',`[...document.querySelectorAll('video')].some(v=>v.loop&&v.muted&&!v.paused&&v.videoWidth>0)`);
      assert.equal(customerWindow.top,false);assert.equal(customerWindow.fullscreen,true);
      pass('close removes both image overlays, releases always-on-top and restores the playing idle loop');
      await send('Page.navigate',{url:'http://localhost/management'},sessions.staff);
      await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="button-card-comparison-GALLERY-READY"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-card-comparison-GALLERY-READY"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="comparison-image"]')?.naturalWidth===800`);
      await evaluate('customer',`document.querySelector('[data-testid="button-close-comparison"]').click()`);
      await wait('staff',`!document.querySelector('[data-testid="comparison-gallery"]')`);
      pass('management/release tab round-trip retains IPC; customer-side close also dismisses the staff controller');
      singleMonitor=true;display.closeCustomer(false);
      await send('Page.bringToFront',{},sessions.staff);
      await evaluate('staff',`document.querySelector('[data-testid="button-card-comparison-GALLERY-READY"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="comparison-gallery"]')?.dataset.compact==='false'&&document.querySelector('[data-testid="comparison-image"]')?.naturalWidth===800`);
      const staffFull=await evaluate('staff',`(()=>{const r=document.querySelector('[data-testid="comparison-gallery"]').getBoundingClientRect();return [r.width,r.height,innerWidth,innerHeight]})()`);
      if(staffFull[0]!==staffFull[2]||staffFull[1]!==staffFull[3])console.log('GALLERY LAYOUT',await evaluate('staff',`(()=>{
        const e=document.querySelector('[data-testid="comparison-gallery"]'),parents=[];let p=e;
        while(p){const c=getComputedStyle(p),r=p.getBoundingClientRect();parents.push({tag:p.tagName,cls:p.className,
          w:r.width,h:r.height,position:c.position,overflow:c.overflow,transform:c.transform,filter:c.filter,contain:c.contain});p=p.parentElement;}
        return JSON.stringify({inner:[innerWidth,innerHeight],rootClient:[document.documentElement.clientWidth,document.documentElement.clientHeight],
          bodyStyle:document.body.getAttribute('style'),rootStyle:document.documentElement.getAttribute('style'),parents});
      })()`));
      assert.equal(staffFull[0],staffFull[2]);assert.equal(staffFull[1],staffFull[3]);
      await evaluate('staff',`document.querySelector('[data-testid="button-comparison-next"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="comparison-position"]').textContent==='2 / 2'`);
      await send('Page.bringToFront',{},sessions.staff);
      await evaluate('staff',`document.querySelector('[data-testid="button-close-comparison"]').focus()`);
      for(const key of 'GALLERY-READY'){
        await send('Input.dispatchKeyEvent',{type:'keyDown',key},sessions.staff);
        await send('Input.dispatchKeyEvent',{type:'keyUp',key},sessions.staff);
      }
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,text:'\r',unmodifiedText:'\r'},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
      await wait('staff',`!document.querySelector('[data-testid="comparison-gallery"]')`);
      assert.equal(display.displayStatus().open,false);
      pass('single-monitor mode uses the full staff viewport, supports arrows/Enter-close, isolates scanner keys and never creates a customer window');
      await delay(250);
      assert.equal(manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),baseline);
      pass('viewing, navigation, tab changes and closing leave SQLite orders and outgoing state byte-for-byte unchanged');
      fs.writeFileSync('generated-artifacts/comparison-gallery-browser-result.json',JSON.stringify({
        checks,realTemporarySqlite:true,realJpegDecode:true,electronIpcMock:true,windowsHardwareTested:false},null,2));return;
    }
    if(process.argv.includes('--korean-ime-only')){
      await send('Page.bringToFront',{},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-address"]')`);
      const selector=id=>`[data-testid="${id}"]`;
      async function focus(css,clear=true){
        await evaluate('staff',`(()=>{const e=document.querySelector(${JSON.stringify(css)});e.focus();${clear?'e.select();':''}})()`);
        if(clear)await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Backspace',code:'Backspace',windowsVirtualKeyCode:8},sessions.staff);
      }
      async function type(css,text){
        await focus(css);
        for(const ch of text)await send('Input.insertText',{text:ch},sessions.staff);
      }
      async function ime(css,text){
        await focus(css);
        for(const part of ['ㄱ','과',text])await send('Input.imeSetComposition',{
          text:part,selectionStart:part.length,selectionEnd:part.length},sessions.staff);
        assert.equal(await evaluate('staff',`document.querySelector(${JSON.stringify(css)}).value`),text);
        await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:229},sessions.staff);
        assert.equal(await evaluate('staff',`document.activeElement===document.querySelector(${JSON.stringify(css)})`),true);
        await send('Input.insertText',{text},sessions.staff);
        assert.equal(await evaluate('staff',`document.querySelector(${JSON.stringify(css)}).value`),text);
      }
      await type(selector('input-customer-name'),'한글검증');
      await type(selector('input-customer-phone'),'01012345678');
      await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="input-customer-address"]');
        e.lang='en';e.setAttribute('inputmode','latin');})()`);
      await type(selector('input-customer-address'),'rhkcjstl qufdidfh 123');
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'과천시 별양로 123');
      assert.deepEqual(await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="input-customer-address"]');return [e.lang,e.inputMode]})()`),['ko','text']);
      pass('address English-key keystrokes compose 과천시 별양로 123 without an OS IME toggle');
      const address='과천시 별양로 123 한글아파트 101동';
      await ime(selector('input-customer-address'),address);
      pass('Chromium IME composition/commit preserves the exact Korean address and Enter does not move focus');
      await evaluate('staff',`document.querySelector('[data-testid="button-add-item"]').click()`);
      await wait('staff',`!!document.querySelector('[data-testid^="select-item-"]')`);
      await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid^="select-item-"]');e.value='other';e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
      await wait('staff',`!!document.querySelector('[data-testid^="custom-item-name-"]')`);
      const custom='[data-testid^="custom-item-name-"]';
      await type(custom,'gksqhr wjrhfl');
      assert.equal(await evaluate('staff',`document.querySelector('${custom}').value`),'한복 저고리');
      const item='한복 저고리 수선';await ime(custom,item);
      pass('custom garment English-key and native Chromium IME paths both preserve a composed Korean item name');
      await evaluate('staff',`(()=>{const e=document.querySelector('.custom-item-fields input[type="number"]');
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,'15000');
        e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
      await evaluate('staff',`[...document.querySelectorAll('button')].find(e=>e.textContent.includes('접수 내용 최종 확인')).click()`);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-requests"]')`);
      await evaluate('staff',`[...document.querySelectorAll('button')].find(e=>e.textContent==='고객정보 수정').click()`);
      await wait('staff',`!!document.querySelector('[aria-label="수정 주소"]')`);
      await type('[aria-label="수정 주소"]','rhkcjstl qufdidfh 123');
      assert.equal(await evaluate('staff',`document.querySelector('[aria-label="수정 주소"]').value`),'과천시 별양로 123');
      await ime('[aria-label="수정 주소"]',address);
      await evaluate('staff',`[...document.querySelectorAll('button')].find(e=>e.textContent==='고객정보 저장').click()`);
      await wait('staff',`!document.querySelector('[aria-label="수정 주소"]')`);
      pass('customer identity edit dialog also preserves Korean address entry, composition and save');
      await type(selector('input-customer-requests'),'ahr qnqns wndml');
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-requests"]').value`),'목 부분 주의');
      assert.deepEqual(await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="input-customer-requests"]');return [e.lang,e.inputMode]})()`),['ko','text']);
      pass('ordinary controlled Korean memo textarea uses the same live keyboard fallback');
      await evaluate('staff',`document.querySelector('[data-testid="button-final-intake-confirm"]').click()`);
      await wait('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().some(o=>o.customerName==='한글검증');})()`);
      const snapshot=require('../lib/k99-local/photo-retention.cjs').snapshot(path.join(manager.status().dataLocation,'k99.sqlite'));
      const saved=snapshot.orders.find(o=>o.customerName==='한글검증');
      assert.equal(saved.customerAddress,address);assert.ok(JSON.stringify(saved.items).includes(item));
      assert.ok(JSON.stringify(saved).includes('목 부분 주의'));
      assert.equal(saved.customerPhone.replace(/\D/g,''),'01012345678');
      assert.equal(saved.items[0].generalPrice,15000);
      pass('real reception confirmation commits exact Korean address, custom garment and customer memo to temporary on-disk SQLite');
      await send('Page.navigate',{url:'http://localhost/maintenance#program-integrations'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-luxury-target"]')`);
      const literal='C:\\K99\\LuxuryCalc.exe';
      await type(selector('input-luxury-target'),literal);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-luxury-target"]').value`),literal);
      await type(selector('input-prescription-url'),'https://example.com/care?mode=1');
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-prescription-url"]').value`),'https://example.com/care?mode=1');
      pass('program paths and HTTPS URLs remain byte-for-byte literal');
      fs.writeFileSync('generated-artifacts/korean-ime-browser-result.json',JSON.stringify({
        checks,address,item,realChromiumComposition:true,realTemporarySqlite:true,windowsImeTested:false},null,2));return;
    }
    if(process.argv.includes('--photo-retention-only')){
      await evaluate('staff',`(async()=>{
        const r=await import('/src/order-record.ts'),g=await import('/src/garment-record.ts');
        for(const [id,name,stage] of [['RET-OLD','정리대상','매장수령완료'],['RET-WAIT','출고대기','세탁완료']]){
          const o=r.createConfirmedOrder({id,customerName:name,customerPhone:'01000001234',customerAddress:'',
            items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:1,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
            {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,
              requestedPickupDate:'',waiver:'not-requested',luxuryItem:false,customerRequests:''});
          const at=new Date(Date.now()-120*86400000).toISOString();
          const saved={...o,createdAt:'2026-01-01T03:00:00Z',
            operations:{...o.operations,stage,completedAt:at,updatedAt:at},garments:g.createGarmentRecords(o)};
          r.insertConfirmedOrder(saved);
        }
      })()`);
      const expired=path.join(intakeRoot,'20260101_정리대상_1234'),waiting=path.join(intakeRoot,'20260101_출고대기_1234');
      const compare=path.join(root,'mock-D/02_세탁전후사진');
      for(const dir of [expired,waiting,compare]){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'keep.jpg'),'test photo');}
      const original=manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'});
      await send('Page.navigate',{url:'http://localhost/management'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="settings-photo-retention"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="settings-photo-retention"]').open=true`);
      await send('Page.bringToFront',{},sessions.staff);
      await wait('staff',`!document.querySelector('[data-testid="select-photo-retention"]').disabled`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="select-photo-retention"]').value`),'60');
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="select-photo-retention"]').options.length`),4);
      pass('management settings expose all four retention choices with persisted default 60 days');
      async function select(value){
        await evaluate('staff',`(()=>{
          const s=document.querySelector('[data-testid="select-photo-retention"]');s.value=${JSON.stringify(value)};
          s.dispatchEvent(new Event('change',{bubbles:true}));
        })()`);
      }
      await select('30');
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="button-run-photo-retention"]').disabled`),true);
      await evaluate('staff',`document.querySelector('[data-testid="button-save-photo-retention"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="status-photo-retention-message"]')?.textContent.includes('저장했습니다')`);
      await evaluate('staff','window.__retentionBeforeReload=true');
      await send('Page.reload',{},sessions.staff);
      await wait('staff',`!window.__retentionBeforeReload&&document.querySelector('[data-testid="select-photo-retention"]')?.value==='30'`);
      await evaluate('staff',`document.querySelector('[data-testid="settings-photo-retention"]').open=true`);
      pass('changing period requires saving first; SQLite choice survives full reload');
      await evaluate('staff',`window.__cleanupAsked=0;window.confirm=()=>{window.__cleanupAsked++;return false;};document.querySelector('[data-testid="button-run-photo-retention"]').click()`);
      assert.ok(fs.existsSync(expired));assert.equal(await evaluate('staff','window.__cleanupAsked'),1);
      pass('cancelling permanent-delete confirmation leaves every intake photo intact');
      await evaluate('staff',`window.confirm=()=>true;document.querySelector('[data-testid="button-run-photo-retention"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="status-photo-retention-result"]')?.textContent.includes('삭제된 폴더 1개')`);
      assert.equal(fs.existsSync(expired),false);assert.ok(fs.existsSync(path.join(waiting,'keep.jpg')));
      assert.ok(fs.existsSync(path.join(compare,'keep.jpg')));
      assert.equal(manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),original);
      pass('manual UI command deletes only the old departed intake folder; pending/comparison photos and ledger stay identical');
      await select('off');await evaluate('staff',`document.querySelector('[data-testid="button-save-photo-retention"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="status-photo-retention-message"]')?.textContent.includes('저장했습니다')`);
      assert.equal(photoRetention.status().days,null);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="button-run-photo-retention"]').disabled`),true);
      pass('disabled setting persists and prevents manual cleanup');
      fs.writeFileSync('generated-artifacts/photo-retention-browser-result.json',JSON.stringify({
        checks,realTemporarySqlite:true,realTemporaryFilesystem:true,electronIpcMocked:true,windowsTested:false},null,2));
      return;
    }
    if(process.argv.includes('--program-launchers-only')){
      await wait('staff',`!!document.querySelector('[data-testid="button-luxury-launch"]')`);
      assert.ok(await evaluate('staff',`(()=>{
        const a=document.querySelector('[data-testid="button-luxury-launch"]').getBoundingClientRect();
        const b=document.querySelector('[data-testid="button-ai-prescription"]').getBoundingClientRect();
        const side=document.querySelector('[data-testid="reception-sidebar"]');
        return a.width===b.width&&a.height===b.height&&a.y===b.y&&side.scrollHeight===side.clientHeight;
      })()`));
      pass('launcher buttons have identical dimensions and preserve the zero-scroll sidebar');
      await evaluate('staff',`document.querySelector('[data-testid="button-ai-prescription"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="button-ai-prescription"]')?.getAttribute('aria-disabled')==='false'`);
      await delay(150);
      assert.equal(new URL(programLaunches.at(-1).url).origin,'https://k-99-washcare-ai.replit.app');
      pass('fresh installation opens the built-in AI prescription address without prior configuration');
      programLaunches.length=0;
      await send('Page.navigate',{url:'http://localhost/maintenance#program-integrations'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="ai-account-settings"]')`);
      await wait('staff',`document.querySelector('[data-testid="storage-layout-root"]').textContent.startsWith('E:')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-change-storage-drive"]').click()`);
      await wait('staff',`!document.querySelector('[data-testid="button-change-storage-drive"]').disabled`);
      assert.ok(await evaluate('staff',`document.querySelector('[data-testid="storage-layout-root"]').textContent.includes('K99_스마트접수')`));
      pass('compiled storage settings display native root/five folder statuses and preserve path after cancelled drive selection');
      assert.ok(await evaluate('staff',`(()=>{const s=getComputedStyle(document.querySelector('[data-testid="storage-layout-settings"]'));return s.backgroundColor==='rgb(23, 52, 61)'&&s.color==='rgb(243, 237, 227)'})()`));
      pass('storage root and folder status use readable light text on their scoped dark background');
      await wait('staff',`document.querySelector('[data-testid="button-save-ai-account"]')?.disabled===false`);
      await evaluate('staff',`(()=>{
        const set=(id,value)=>{const e=document.querySelector('[data-testid="'+id+'"]');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,value);e.dispatchEvent(new Event('input',{bubbles:true}));};
        set('input-ai-account-phone','01000001234');set('input-ai-account-password','a1234');
      })()`);
      await evaluate('staff',`document.querySelector('[data-testid="button-save-ai-account"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="ai-account-status"]').textContent.includes('저장됨')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-ai-account-password"]').value`),'');
      const accountFile=fs.readFileSync(path.join(root,'integrations/ai-account.dpapi.json'),'utf8');
      assert.ok(!accountFile.includes('01000001234')&&!accountFile.includes('a1234'));
      assert.ok(!manager.store.storage({op:'keys'}).some(key=>String(manager.store.storage({op:'get',key})).includes('a1234')));
      pass('compiled settings save through native-only account IPC; encrypted fixture file and SQLite contain no plaintext password');
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="button-ai-prescription"]')`);
      await send('Page.navigate',{url:'http://localhost/maintenance#program-integrations'},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="input-ai-account-phone"]')?.value==='01000001234'`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-ai-account-password"]').value`),'');
      await evaluate('staff',`document.querySelector('[data-testid="button-clear-ai-account"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="ai-account-status"]').textContent.includes('토큰')`);
      assert.equal(accountVault.account(),null);
      pass('account settings survive screen remount without revealing password; clearing reverts to browser device authentication');
      await send('Page.navigate',{url:'http://localhost/maintenance'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-luxury-target"]')`);
      await evaluate('staff',`(()=>{
        const set=(id,value)=>{const el=document.querySelector('[data-testid="'+id+'"]');
          Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,value);
          el.dispatchEvent(new Event('input',{bubbles:true}));};
        set('input-luxury-target','https://calculator.example.test/app');
        set('input-prescription-url','https://prescription.example.test/?mode=shop');
      })()`);
      await evaluate('staff',`document.querySelector('[data-testid="button-save-integrations"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="text-integration-message"]')?.textContent.includes('저장했습니다')`);
      const settings=JSON.parse(manager.store.storage({op:'get',key:'k99-program-integrations-v1'}));
      assert.equal(settings.luxuryTarget,'https://calculator.example.test/app');
      pass('administrator saves both integration targets in actual temporary SQLite');
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="button-ai-prescription"]')?.getAttribute('aria-disabled')==='false'`);
      await evaluate('staff',`[...document.querySelectorAll('[data-label-choice="material"]')].find(b=>b.textContent==='울/실크').click()`);
      await evaluate('staff',`[...document.querySelectorAll('[data-label-choice="color"]')].find(b=>b.textContent==='흰색').click()`);
      await evaluate('staff',`document.querySelector('[data-testid="button-ai-prescription"]').click()`);
      await wait('staff',`!document.querySelector('[data-testid="text-launcher-notice"]')?.textContent.includes('실패')`);
      await delay(150);
      const prescription=new URL(programLaunches.find(p=>p.kind==='prescription').url);
      assert.equal(prescription.searchParams.get('material'),'울/실크');assert.equal(prescription.searchParams.get('color'),'흰색');
      assert.equal(prescription.searchParams.get('mode'),'shop');
      pass('configured AI launcher passes current material/color and preserves existing URL arguments');
      await evaluate('staff',`document.querySelector('[data-testid="button-luxury-launch"]').click()`);
      await delay(150);assert.equal(programLaunches.at(-1).kind,'luxury');
      await evaluate('staff',`window.__nativeDeliver('k99:luxury-result',{itemName:'명품 코트',finalPrice:88000})`);
      await wait('staff',`!!document.querySelector('[data-testid="dialog-luxury-confirm"]')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-luxury-price"]').value`),'88000');
      await evaluate('staff',`document.querySelector('[data-testid="button-luxury-apply"]').click()`);
      await wait('staff',`[...document.querySelectorAll('input')].some(el=>el.value==='명품 코트')`);
      pass('calculator result requires staff confirmation then adds its item name and exact final price');
      await delay(700);
      await send('Page.reload',{},sessions.staff);
      await wait('staff',`[...document.querySelectorAll('input')].some(el=>el.value==='명품 코트')`);
      assert.ok(await evaluate('staff',`[...document.querySelectorAll('input')].some(el=>el.value==='88000')`));
      pass('added item and price survive renderer reload through the existing SQLite draft pipeline');
      fs.writeFileSync(path.resolve(__dirname,'../generated-artifacts/program-launchers-browser-result.json'),
        JSON.stringify({checks,electronIpcMocked:true,externalCalculatorTested:false,windowsTested:false},null,2));
      return;
    }
    if(process.argv.includes('--idle-playlist-only')){
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.videoWidth>0`);
      assert.ok(await evaluate('customer',`document.querySelector('video').src.endsWith('/videos/promo.mp4')`));
      pass('empty user video folder retains the bundled looping promo with a decoded frame');
      fs.copyFileSync(path.join(videos,'promo.mp4'),path.join(idleFolder,'02_second.mp4'));
      fs.copyFileSync(path.join(videos,'promo.mp4'),path.join(idleFolder,'01_first.mp4'));
      await send('Page.navigate',{url:'http://localhost/maintenance'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="button-open-idle-videos"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-open-idle-videos"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="page-maintenance"]').textContent.includes('영상 폴더를 열었습니다')`);
      assert.equal(idleFolderOpened,true);
      await evaluate('staff',`document.querySelector('[data-testid="button-refresh-idle-videos"]').click()`);
      const list=idleVideos.list().files;
      const first=new URL(list[0].url).pathname,second=new URL(list[1].url).pathname;
      await wait('customer',`document.querySelector('video')?.src.endsWith(${JSON.stringify(first)})&&document.querySelector('video').videoWidth>0`);
      assert.ok(await evaluate('customer',`(()=>{const v=document.querySelector('video');return !v.loop&&v.muted&&v.autoplay&&v.playsInline})()`));
      pass('admin folder-open adapter and refresh load the first filename-sorted video into the existing customer window');
      await evaluate('customer',`document.querySelector('video').dispatchEvent(new Event('ended'))`);
      await wait('customer',`document.querySelector('video')?.src.endsWith(${JSON.stringify(second)})&&document.querySelector('video').videoWidth>0`);
      await evaluate('customer',`document.querySelector('video').dispatchEvent(new Event('ended'))`);
      await wait('customer',`document.querySelector('video')?.src.endsWith(${JSON.stringify(first)})&&document.querySelector('video').videoWidth>0`);
      pass('video ended advances first to second and cycles back without leaving idle; both originals decode');
      const poster=await evaluate('customer',`(()=>{const c=document.createElement('canvas');c.width=8;c.height=8;const g=c.getContext('2d');g.fillStyle='#125c69';g.fillRect(0,0,8,8);return c.toDataURL('image/png');})()`);
      fs.writeFileSync(path.join(idleFolder,'00_혜택.png'),Buffer.from(poster.split(',')[1],'base64'));
      await evaluate('staff',`document.querySelector('[data-testid="button-refresh-idle-videos"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-image"]')?.naturalWidth===8`);
      await wait('customer',`document.querySelector('video')?.src.endsWith(${JSON.stringify(first)})&&document.querySelector('video').videoWidth>0`);
      pass('filename-sorted PNG decodes as an image and advances after its 10-second display time to the next actual video');
      fs.unlinkSync(path.join(idleFolder,'00_혜택.png'));
      fs.writeFileSync(path.join(idleFolder,'00_broken.mp4'),'not a real video');
      await evaluate('staff',`document.querySelector('[data-testid="button-refresh-idle-videos"]').click()`);
      await wait('customer',`document.querySelector('video')?.src.endsWith(${JSON.stringify(first)})&&document.querySelector('video').videoWidth>0`);
      pass('an undecodable user clip is skipped instead of leaving a black customer screen');
      for(const name of fs.readdirSync(idleFolder))fs.unlinkSync(path.join(idleFolder,name));
      await evaluate('staff',`document.querySelector('[data-testid="button-refresh-idle-videos"]').click()`);
      await wait('customer',`document.querySelector('video')?.src.endsWith('/videos/promo.mp4')&&document.querySelector('video').videoWidth>0`);
      assert.equal(await evaluate('customer',`document.querySelector('video').loop`),true);
      pass('removing custom videos and refreshing restores the packaged muted infinite loop');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/idle-playlist-browser-result.json',JSON.stringify({
        checks,temporarySqlite:true,electronIpcMocked:true,endedEventSimulated:true,windowsTested:false},null,2));
      return;
    }
    if(process.argv.includes('--reception-sidebar-only')){
      for(const [width,height] of [[1366,768],[1440,900]]){
        await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false},sessions.staff);
        await wait('staff',`!!document.querySelector('[data-testid="reception-sidebar"]')`);
        assert.equal(await evaluate('staff',`(()=>{const p=document.querySelector('[data-testid="reception-sidebar"]'),r=p.getBoundingClientRect(),f=p.querySelector('.rcs-final').getBoundingClientRect();
          return r.top>=0&&r.bottom<=innerHeight&&f.bottom<=innerHeight&&p.scrollHeight<=p.clientHeight&&p.querySelectorAll('[data-label-choice]').length===6
          &&!document.querySelector('[data-testid="offline-label-controls"]');})()`),true);
      }
      pass('independent sidebar fits without scrolling at 1366x768 and 1440x900; former in-form box absent');
      await evaluate('staff',`[...document.querySelectorAll('[data-label-choice=material]')].find(b=>b.textContent==='울/실크').click()`);
      await evaluate('staff',`[...document.querySelectorAll('[data-label-choice=color]')].find(b=>b.textContent==='흰색').click()`);
      for(const [id,value] of [['input-customer-name','촬영시험'],['input-customer-phone','01011112222']]){
        await evaluate('staff',`document.querySelector('[data-testid="${id}"]').focus()`);
        await send('Input.insertText',{text:value},sessions.staff);
      }
      await evaluate('staff',`document.querySelector('[data-testid="button-add-item"]').click()`);
      await wait('staff',`!!document.querySelector('[data-testid="img-mobile-qr"]')`);
      assert.deepEqual(await evaluate('staff',`(()=>{const r=document.querySelector('[data-testid="img-mobile-qr"]').getBoundingClientRect();return [r.width,r.height]})()`),[130,130]);
      pass('real local mobile session produces a persistent 130x130 QR for the selected garment');
      await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
      await wait('staff',`document.querySelector('[data-testid="dialog-intake-camera"] video')?.videoWidth>0`);
      assert.ok(await evaluate('staff',`!!document.querySelector('[data-testid="dialog-intake-camera"] [role=option]')`));
      // Real compiled React controls + mocked device catalog; actual Windows USB is not tested.
      await evaluate('staff',`(()=>{
        const media=navigator.mediaDevices,enumerate=media.enumerateDevices.bind(media),open=media.getUserMedia.bind(media);
        window.__cameraOriginalOpen=open;
        window.__cameraCalls=[];
        media.enumerateDevices=async()=>[...(await enumerate()),
          {kind:'videoinput',deviceId:'physical-switch',label:'Insta360 Link 2C'},
          {kind:'videoinput',deviceId:'physical-busy',label:'usb-webcam (2bc5:0529)'},
          {kind:'videoinput',deviceId:'virtual-explicit',label:'OBS Virtual Camera'}].filter(d=>d.deviceId!==window.__unpluggedId);
        media.getUserMedia=async constraints=>{
          const id=constraints.video.deviceId?.exact;window.__cameraCalls.push(id);
          window.__lastCameraOpenAt=performance.now();
          if(id==='physical-busy')throw new DOMException('USB busy','NotReadableError');
          if(id==='physical-switch'||id==='virtual-explicit'){
            const stream=await open({video:true,audio:false});
            stream.getVideoTracks()[0].getSettings=()=>({deviceId:id});return stream;
          }
          return open(constraints);
        };
        document.querySelector('[data-testid="button-ndc-preview"]').click();
      })()`);
      await wait('staff',`document.querySelector('[data-testid="button-ndc-preview"]').textContent.includes('켜기')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-preview"]').click()`);
      await wait('staff',`!!document.querySelector('[data-testid="select-ndc-device"] option[value="physical-switch"]')`);
      await evaluate('staff',`(()=>{const s=document.querySelector('[data-testid="select-ndc-device"]');s.value='physical-switch';s.dispatchEvent(new Event('change',{bubbles:true}));})()`);
      await wait('staff',`document.querySelector('[data-testid="select-ndc-device"]').value==='physical-switch'&&!document.querySelector('[data-testid="dialog-intake-camera"] video').hidden`);
      pass('physical camera dropdown immediately reconnects the compiled preview without a separate start click');
      await evaluate('staff',`window.__cameraCalls=[];(()=>{const s=document.querySelector('[data-testid="select-ndc-device"]');s.value='physical-busy';s.dispatchEvent(new Event('change',{bubbles:true}));})()`);
      await wait('staff',`document.querySelector('[data-testid="error-ndc-camera"]')?.textContent.includes('PC 본체 USB 포트')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="select-ndc-device"]').value`),'physical-busy');
      assert.deepEqual(await evaluate('staff',`window.__cameraCalls`),['physical-busy']);
      assert.ok(await evaluate('staff',`!!document.querySelector('[data-testid="img-mobile-qr"]')`));
      pass('busy selected camera stays selected and shows central USB error without opening OBS; mobile QR survives');
      await evaluate('staff',`(()=>{const s=document.querySelector('[data-testid="select-ndc-device"]');s.value='physical-switch';s.dispatchEvent(new Event('change',{bubbles:true}));})()`);
      await wait('staff',`!document.querySelector('[data-testid="error-ndc-camera"]')&&!document.querySelector('[data-testid="dialog-intake-camera"] video').hidden`);
      pass('choosing another physical camera after failure restores live preview and clears the error');
      await evaluate('staff',`(()=>{
        document.querySelector('[data-testid="dialog-intake-camera"] video').srcObject.getTracks().forEach(t=>t.stop());
        window.__cameraCalls=[];navigator.mediaDevices.dispatchEvent(new Event('devicechange'));
      })()`);
      await wait('staff',`window.__cameraCalls.includes('physical-switch')&&document.querySelector('[data-testid="dialog-intake-camera"] video')?.srcObject?.getVideoTracks()[0]?.readyState==='live'`);
      assert.deepEqual(await evaluate('staff','window.__cameraCalls'),['physical-switch']);
      pass('same device IDs with ended track recover without silently switching to a virtual camera');
      // A stationary, full-HD test pattern makes saved crop pixels independently measurable.
      await evaluate('staff',`(async()=>{
        const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;
        const ctx=canvas.getContext('2d');
        for(let y=0;y<1080;y+=120)for(let x=0;x<1920;x+=120){
          ctx.fillStyle='rgb('+Math.round(x/1920*220)+','+Math.round(y/1080*220)+',80)';
          ctx.fillRect(x,y,120,120);
        }
        const video=document.querySelector('[data-testid="camera-viewport"] video');
        video.srcObject=canvas.captureStream(10);await video.play();window.__zoomPattern=canvas;
      })()`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F8',code:'F8',windowsVirtualKeyCode:119},sessions.staff);
      await delay(550);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F8',code:'F8',windowsVirtualKeyCode:119},sessions.staff);
      const heldZoom=await evaluate('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent`);
      assert.ok(parseFloat(heldZoom)>1,JSON.stringify(await evaluate('staff',`({
        heldZoom:${JSON.stringify(heldZoom)},hidden:document.hidden,focused:document.hasFocus(),
        ready:!document.querySelector('[data-testid="button-camera-zoom"]').disabled
      })`)));
      await delay(200);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent`),heldZoom);
      pass('one F8 keydown continuously zooms after 200ms without OS repeats; keyup fixes magnification');
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F8',code:'F8',windowsVirtualKeyCode:119},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F8',code:'F8',windowsVirtualKeyCode:119},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent==='1.0x'`);
      const zoomButton=await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="button-camera-zoom"]');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
      await send('Input.dispatchMouseEvent',{type:'mousePressed',...zoomButton,button:'left',buttons:1,clickCount:1},sessions.staff);
      await delay(550);
      await send('Input.dispatchMouseEvent',{type:'mouseReleased',...zoomButton,button:'left',buttons:0,clickCount:1},sessions.staff);
      assert.ok(parseFloat(await evaluate('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent`))>1);
      pass('short F8 resets and holding the mouse zoom button drives the same continuous zoom state');
      await evaluate('staff',`document.querySelector('[data-testid="button-camera-reset"]').click()`);
      const stagePoint=await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="camera-viewport"]');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
      await send('Input.dispatchMouseEvent',{type:'mouseWheel',...stagePoint,deltaX:0,deltaY:-500},sessions.staff);
      await wait('staff',`parseFloat(document.querySelector('[data-testid="camera-zoom"]').textContent)>=1.9`);
      const beforePan=await evaluate('staff',`document.querySelector('[data-testid="camera-viewport"] video').style.left`);
      await send('Input.dispatchMouseEvent',{type:'mousePressed',...stagePoint,button:'left',buttons:1,clickCount:1},sessions.staff);
      await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:stagePoint.x+90,y:stagePoint.y-45,button:'left',buttons:1},sessions.staff);
      await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:stagePoint.x+90,y:stagePoint.y-45,button:'left',buttons:0,clickCount:1},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="camera-viewport"] video').style.left!==${JSON.stringify(beforePan)}`);
      pass('wheel zoom and mouse drag pan change the visible video crop without scrolling the page');
      await evaluate('staff',`(()=>{
        const v=document.querySelector('[data-testid="camera-viewport"] video'),c=document.createElement('canvas');
        const width=100/parseFloat(v.style.width)*v.videoWidth,height=100/parseFloat(v.style.height)*v.videoHeight;
        const x=-parseFloat(v.style.left)/100*width,y=-parseFloat(v.style.top)/100*height;
        const rect=v.parentElement.getBoundingClientRect(),aspect=rect.width/rect.height;
        c.width=Math.round(Math.min(v.videoWidth,v.videoHeight*aspect));c.height=Math.round(c.width/aspect);
        const ctx=c.getContext('2d');ctx.imageSmoothingQuality='high';
        ctx.drawImage(v,x,y,width,height,0,0,c.width,c.height);
        window.__expectedZoomCanvas=c;
      })()`);
      const location=await evaluate('staff','location.href');
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-shoot"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('1컷')`);
      assert.equal(printed.length,1);
      assert.equal(printed[0].payload.manualMaterial,'울/실크');assert.equal(printed[0].payload.manualColor,'흰색');
      const unit=manager.store.equipment.drafts.state(capturedOrderId).units[0];
      assert.equal(unit.garment.photoHistory.length,1);
      assert.ok(manager.store.equipment.photoFile(unit.garment.photoHistory[0].sourcePhotoId).bytes.length>100);
      assert.ok(fs.readdirSync(path.join(root,'mock-D'),{recursive:true}).some(name=>name.endsWith('.jpg')));
      const pixelError=await evaluate('staff',`(async()=>{
        const image=new Image();image.src=document.querySelector('[data-testid="img-ndc-last"]').src;await image.decode();
        const expected=window.__expectedZoomCanvas,actual=document.createElement('canvas');actual.width=image.width;actual.height=image.height;
        actual.getContext('2d').drawImage(image,0,0);
        if(actual.width!==expected.width||actual.height!==expected.height)throw Error('Crop dimensions differ');
        let max=0;
        for(const [nx,ny] of [[.17,.23],[.43,.47],[.73,.67],[.89,.85]]){
          const x=Math.floor(nx*actual.width),y=Math.floor(ny*actual.height);
          const a=actual.getContext('2d').getImageData(x,y,1,1).data,b=expected.getContext('2d').getImageData(x,y,1,1).data;
          for(let i=0;i<3;i++)max=Math.max(max,Math.abs(a[i]-b[i]));
        }return max;
      })()`);
      assert.ok(pixelError<=12,`Saved JPEG pixels must match zoomed/panned preview (error ${pixelError})`);
      const savedUrl=await evaluate('staff',`document.querySelector('[data-testid="img-ndc-last"]').src`);
      assert.deepEqual(manager.store.equipment.photoFile(unit.garment.photoHistory[0].sourcePhotoId).bytes,Buffer.from(savedUrl.split(',')[1],'base64'));
      pass('zoomed and panned full-HD preview pixels match the JPEG stored in temporary SQLite and archive; first tag submitted once');
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-shoot"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('2컷')`);
      await delay(250);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F7',code:'F7',windowsVirtualKeyCode:118},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F7',code:'F7',windowsVirtualKeyCode:118},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('3컷')`);
      assert.equal(printed.length,1);assert.equal(await evaluate('staff','location.href'),location);
      pass('second click and F7 footswitch save extra frames without duplicate tags, external navigation or whiteout');
      await evaluate('staff',`document.querySelector('.ndc-modal-close').click()`);
      await wait('staff',`!document.querySelector('[data-testid="dialog-intake-camera"]')`);
      assert.equal(await evaluate('staff',`!!document.querySelector('[data-testid="img-mobile-qr"]')`),true);
      await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
      await wait('staff',`document.querySelector('[data-testid="dialog-intake-camera"] video')?.videoWidth>0`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27},sessions.staff);
      await wait('staff',`!document.querySelector('[data-testid="dialog-intake-camera"]')`);
      pass('in-app close/reopen and Escape preserve receipt, three photo records, QR and selection state');
      await evaluate('staff',`document.querySelector('[data-testid^="button-increase-quantity-"]').click()`);
      await evaluate('staff',`document.querySelector('[aria-label="기성 롤태그 표시"]').click()`);
      await wait('staff',`!!document.querySelector('[aria-label="현재 품목 롤태그 번호"]')`);
      // The already printed first garment cannot be changed to a roll tag.
      await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
      await wait('staff',`document.querySelectorAll('[data-testid="dialog-intake-camera"] [role=option]').length===2`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F9',code:'F9',windowsVirtualKeyCode:120},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F9',code:'F9',windowsVirtualKeyCode:120},sessions.staff);
      await wait('staff',`document.querySelectorAll('[data-testid="dialog-intake-camera"] [role=option]')[1]?.getAttribute('aria-selected')==='true'`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent`),'1.0x');
      assert.equal(await evaluate('staff',`location.search.includes('stage=final')`),false);
      await evaluate('staff',`(()=>{const e=document.querySelector('[aria-label="현재 품목 롤태그 번호"]');e.focus();e.select();})()`);
      await send('Input.insertText',{text:'2-101'},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
      await wait('staff',`document.querySelector('.v2t-hint')?.textContent.includes('2-101')`);
      await wait('staff',`document.querySelector('[data-testid="dialog-intake-camera"] video')?.videoWidth>0`);
      await wait('staff',`document.querySelector('[data-testid="button-ndc-shoot"]')?.disabled===false`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F7',code:'F7',windowsVirtualKeyCode:118},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F7',code:'F7',windowsVirtualKeyCode:118},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('1컷')`);
      assert.equal(printed.length,1);
      const roll=manager.store.equipment.drafts.state(capturedOrderId).units.find(u=>u.unitKey==='1:2');
      assert.equal(roll.garment.tagNumber,'2-101');assert.equal(roll.garment.tagMode,'roll');assert.ok(!roll.job);
      pass('F9 moves to next garment and resets centered 1x without finalizing; manual roll number and F7 capture persist');
      await send('Page.bringToFront',{},sessions.staff);
      await wait('staff',`!document.hidden&&!!document.querySelector('[data-testid="status-ndc-foot"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-camera-reset"]').focus()`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'b',code:'KeyB',windowsVirtualKeyCode:66},sessions.staff);
      await delay(450);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'b',code:'KeyB',windowsVirtualKeyCode:66},sessions.staff);
      await wait('staff',`parseFloat(document.querySelector('[data-testid="camera-zoom"]').textContent)>1`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'B',code:'KeyB',windowsVirtualKeyCode:66},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'B',code:'KeyB',windowsVirtualKeyCode:66},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="camera-zoom"]').textContent==='1.0x'`);
      const cutsBeforeTyping=await evaluate('staff',`document.querySelector('[data-testid="text-ndc-count"]').textContent`);
      await evaluate('staff',`(()=>{const e=document.createElement('input');e.type='url';e.id='pedal-edit-fixture';document.querySelector('[data-testid="dialog-intake-camera"]').appendChild(e);e.focus();})()`);
      for(const [key,vk]of [['a',65],['b',66],['c',67]]){
        await send('Input.dispatchKeyEvent',{type:'keyDown',key,code:'Key'+key.toUpperCase(),text:key,windowsVirtualKeyCode:vk},sessions.staff);
        await send('Input.dispatchKeyEvent',{type:'keyUp',key,code:'Key'+key.toUpperCase(),windowsVirtualKeyCode:vk},sessions.staff);
      }
      await wait('staff',`document.getElementById('pedal-edit-fixture').value==='abc'`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="text-ndc-count"]').textContent`),cutsBeforeTyping);
      await evaluate('staff',`document.getElementById('pedal-edit-fixture').remove();document.querySelector('[data-testid="button-camera-reset"]').focus()`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'A',code:'KeyA',windowsVirtualKeyCode:65},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'A',code:'KeyA',windowsVirtualKeyCode:65},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]').textContent.includes('2컷')`);
      assert.equal(printed.length,1);
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-unit-1:1"]').click();document.activeElement?.blur()`);
      await wait('staff',`document.querySelector('[data-testid="button-ndc-unit-1:1"]').getAttribute('aria-selected')==='true'`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'c',code:'KeyC',windowsVirtualKeyCode:67},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'c',code:'KeyC',windowsVirtualKeyCode:67},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="button-ndc-unit-1:2"]').getAttribute('aria-selected')==='true'`);
      pass('A/B/C pedals capture, hold zoom, tap reset and move without extra first-shot tag; editable abc remains ordinary text');
      await evaluate('staff',`window.__unpluggedId=document.querySelector('[data-testid="select-ndc-device"]').value;navigator.mediaDevices.dispatchEvent(new Event('devicechange'))`);
      await wait('staff',`!!document.querySelector('[data-testid="error-ndc-camera"]')&&!document.querySelector('[data-testid="camera-viewport"] video').srcObject`);
      await evaluate('staff',`window.__unpluggedId='';window.__deviceChangeAt=performance.now();navigator.mediaDevices.dispatchEvent(new Event('devicechange'))`);
      await wait('staff',`!document.querySelector('[data-testid="camera-viewport"] video').hidden`);
      assert.ok(await evaluate('staff',`window.__lastCameraOpenAt-window.__deviceChangeAt>=0&&window.__lastCameraOpenAt-window.__deviceChangeAt<500`));
      const reopenedCalls=await evaluate('staff',`window.__cameraCalls.length`);
      await evaluate('staff',`navigator.mediaDevices.dispatchEvent(new Event('devicechange'));navigator.mediaDevices.dispatchEvent(new Event('devicechange'))`);
      await delay(150);
      assert.equal(await evaluate('staff',`window.__cameraCalls.length`),reopenedCalls);
      pass('devicechange unplug retains explicit selection/QR and reconnect starts within 500ms in the controlled fixture');
      for(const [width,height]of [[1366,768],[1440,900]]){
        await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false},sessions.staff);
        assert.equal(await evaluate('staff',`(()=>{const p=document.querySelector('[data-testid="reception-sidebar"]');return p.scrollHeight<=p.clientHeight&&p.querySelector('.rcs-final').getBoundingClientRect().bottom<=innerHeight})()`),true);
      }
      pass('active 130px QR and roll-number controls still fit zero-scroll sidebar');
      await evaluate('staff',`document.querySelector('.ndc-modal-close').click()`);
      await wait('staff',`!document.querySelector('[data-testid="dialog-intake-camera"]')`);
      await evaluate('staff',`window.__disconnectTestCameras();navigator.mediaDevices.getUserMedia=()=>Promise.reject(new DOMException('No USB camera','NotFoundError'));document.querySelector('.rcs-camera').click()`);
      await wait('staff',`document.querySelector('[data-testid="error-ndc-camera"]')?.textContent.includes('선택한 카메라가 연결되어 있는지')`);
      assert.ok(await evaluate('staff',`!!document.querySelector('[data-testid="img-mobile-qr"]')`));
      pass('USB camera absence keeps in-app dialog, receipt and live mobile QR available without a crash');
      await evaluate('staff',`window.__finalClicks=0;document.querySelector('.rcs-final').addEventListener('click',()=>window.__finalClicks++)`);
      // F9 on the final garment cannot finalize; only an explicit screen button may.
      const photosBefore=manager.store.equipment.drafts.state(capturedOrderId).units.find(u=>u.unitKey==='1:2').garment.photoHistory.length;
      assert.equal(photosBefore,2); // F7 first shot plus the new A-pedal extra shot.
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F9',code:'F9',windowsVirtualKeyCode:120},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F9',code:'F9',windowsVirtualKeyCode:120},sessions.staff);
      await delay(100);assert.equal(await evaluate('staff',`location.search.includes('stage=final')`),false);
      await evaluate('staff',`document.querySelector('[data-testid="button-camera-final"]').click()`);
      await wait('staff',`location.search.includes('stage=final')`);
      assert.equal(manager.store.equipment.drafts.state(capturedOrderId).units.find(u=>u.unitKey==='1:2').garment.photoHistory.length,photosBefore);
      assert.equal(printed.length,1);
      pass('only the screen final-confirm button advances reception; F9 never confirms or prints a duplicate');
      fs.writeFileSync('generated-artifacts/reception-sidebar-browser-result.json',JSON.stringify({
        checks,temporarySQLite:true,virtualCamera:true,printerMocked:true,electronIpcMocked:true,windowsTested:false,
      },null,2));
      return;
    }
    if(process.argv.includes('--simple-pipeline-only')){
      const password='synthetic-simple-pipeline-password-12345';
      manager.store.api('POST','/api/desktop/admin/setup',{password});
      const {bytes}=await require('../lib/k99-local/tests/ledger-fixture.cjs')();
      const plan=await manager.store.api('POST','/api/customers/import/preview',{fileName:'ledger.xlsx',data:bytes.toString('base64'),password});
      await manager.store.api('POST','/api/customers/import/commit',{token:plan.token,password});
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-phone"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'5678'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===2`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-list li button')].find(b=>b.textContent.includes('C001')).click()`);
      await wait('staff',`document.querySelector('[data-testid="text-last-visit"]')?.textContent.includes('2026-01-03')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'시험 주소');
      assert.ok(await evaluate('staff',`document.querySelector('.cdir-mini').textContent.includes('3번째 방문')&&document.querySelector('.cdir-mini').textContent.includes('8,000')`));
      pass('unified customer selection fills identity/address and mini card shows next visit and previous-date quantity/amount');
      await evaluate('staff',`document.querySelector('[data-testid="button-open-history"]').click()`);
      await wait('staff',`document.querySelector('[role=dialog] table tbody tr')!==null`);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[role=dialog] th').length`),3);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[role=dialog] tbody tr').length`),2);
      pass('history modal uses only date, garment count and laundry amount from unified orders');
      await send('Page.navigate',{url:'http://localhost/management'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="tab-statistics-year"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="tab-statistics-year"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="management-center"]').textContent.includes('23,000')`);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[data-testid="management-center"] tbody tr').length`),12);
      pass('year statistics show all 12 months and reconciled laundry totals');
      const period=async(mode,value)=>{
        await evaluate('staff',`document.querySelector('[data-testid="tab-statistics-${mode}"]').click()`);
        await wait('staff',`!!document.querySelector('[data-testid="input-period-${mode}"]')`);
        await evaluate('staff',`(()=>{const i=document.querySelector('[data-testid="input-period-${mode}"]');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(i,${JSON.stringify(value)});i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}))})()`);
      };
      await period('month','2026-01');
      await wait('staff',`document.querySelector('[data-testid="management-center"]').textContent.includes('23,000')`);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[data-testid="management-center"] tbody tr').length`),2);
      pass('month statistics aggregate each date without duplicating garment rows');
      await period('day','2026-01-01');
      await wait('staff',`document.querySelector('[data-testid="management-center"]').textContent.includes('15,000')`);
      assert.equal(await evaluate('staff',`document.querySelectorAll('[data-testid="management-center"] tbody tr').length`),3);
      pass('day statistics show customer/contact, quantity and amount with matching summary');
      await evaluate('staff',`document.querySelector('[data-testid="button-back-management"]').click()`);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-name"]')`);
      await evaluate('staff',`(()=>{const i=document.querySelector('[data-testid="input-customer-name"]');i.focus();i.select()})()`);
      await send('Input.insertText',{text:'짧은번호시험'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===1`);
      await evaluate('staff',`document.querySelector('.cdir-list li button').click()`);
      await wait('staff',`document.querySelector('[data-testid="input-customer-phone"]').value.replace(/\\D/g,'')==='1234'`);
      pass('name-first autocomplete replaces the previous phone/address without inventing missing digits');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/simple-pipeline-browser-result.json',JSON.stringify({checks,syntheticData:true,temporarySqlite:true,electronIpcMocked:true,windowsTested:false},null,2));
      return;
    }
    if(process.argv.includes('--ledger-only')||process.argv.includes('--ledger-reception-only')){
      const password='isolated-ledger-browser-password-12345';
      manager.store.api('POST','/api/desktop/admin/setup',{password});
      const {bytes}=await require('../lib/k99-local/tests/ledger-fixture.cjs')();
      if(process.argv.includes('--ledger-reception-only')){
        const plan=await manager.store.api('POST','/api/customers/import/preview',{fileName:'ledger.xlsx',data:bytes.toString('base64'),password});
        await manager.store.api('POST','/api/customers/import/commit',{token:plan.token,password});
        pass('isolated synthetic ledger seeded for focused reception verification');
      }else{
      await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
      await wait('staff',`!!document.querySelector('.cdir-import')`);
      await evaluate('staff',`(()=>{
        const input=document.querySelector('.cdir-import input[type=file]'),files=new DataTransfer();
        files.items.add(new File([Uint8Array.from(atob(${JSON.stringify(bytes.toString('base64'))}),c=>c.charCodeAt(0))],'ledger.xlsx'));
        input.files=files.files;input.dispatchEvent(new Event('change',{bubbles:true}));
        const p=document.querySelector('.cdir-import input[type=password]');
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(p,${JSON.stringify(password)});
        p.dispatchEvent(new Event('input',{bubbles:true}));
      })()`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-import button')].find(b=>b.textContent==='미리보기').click()`);
      await wait('staff',`document.querySelector('.cdir-stats')?.textContent.includes('고객 4명')`);
      assert.equal(manager.store.api('GET','/api/customers/search?q=5678').customers.length,0);
      pass('multi-sheet XLSX file input recognizes V5 and previews without writing');
      await evaluate('staff',`document.querySelector('.cdir-import input[type=checkbox]').click()`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-import button')].find(b=>b.textContent==='가져오기 확정').click()`);
      await wait('staff',`document.querySelector('[data-testid="ledger-import-status"]')?.textContent.includes('17행')`);
      pass('confirmed XLSX import refreshes preserved-source status');
      }
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-phone"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'5678'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===2`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-list li button')].find(b=>b.textContent.includes('C001')).click()`);
      await wait('staff',`document.querySelector('.cdir-badge')?.textContent.includes('3번째 방문')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'시험 주소');
      pass('phone suffix keeps duplicate original IDs separate; chosen ID fills identity/address and visit badge');
      await send('Page.reload',{},sessions.staff);
      await wait('staff',`document.querySelector('.cdir-badge')?.textContent.includes('3번째 방문')`);
      pass('selected source customer and visit badge survive a full reload');
      await wait('staff',`[...document.querySelectorAll('.cdir-lookup button')].some(b=>b.textContent.includes('방문 이력'))`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-lookup button')].find(b=>b.textContent.includes('방문 이력')).click()`);
      await wait('staff',`document.querySelector('[role=dialog]')?.textContent.includes('11,000')`);
      assert.ok(await evaluate('staff',`document.querySelector('[role=dialog]').textContent.includes('미확인')&&document.querySelector('[role=dialog]').textContent.includes('취소')`));
      await evaluate('staff',`document.querySelector('[role=dialog] details').open=true`);
      assert.ok(await evaluate('staff',`document.querySelector('[role=dialog]').textContent.includes('셔츠')`));
      pass('history dialog shows dates, garments, laundry amounts, cancellation and unknown payment separately');
      await evaluate('staff',`[...document.querySelectorAll('[role=dialog] button')].find(b=>b.textContent==='닫기').click()`);
      await evaluate('staff',`(()=>{const input=document.querySelector('[data-testid="input-customer-name"]');input.focus();input.select()})()`);
      await send('Input.insertText',{text:'짧은번호시험'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===1`);
      await evaluate('staff',`document.querySelector('.cdir-list li button').click()`);
      await wait('staff',`document.querySelector('[data-testid="input-customer-phone"]').value.replace(/\\D/g,'')==='1234'`);
      pass('name search works independently of the existing phone field and preserves short source numbers without invention');
      await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="ledger-import-status"]')`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-import button')].find(b=>b.textContent.includes('확인 필요 행 보기')).click()`);
      await wait('staff',`document.querySelector('[data-testid="ledger-import-status"] details')?.textContent.includes('접수입력')`);
      pass('review UI exposes original sheet/row references including unconfirmed input');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/ledger-browser-result.json',JSON.stringify({
        checks,temporaryData:true,syntheticWorkbook:true,electronIpcMocked:true,windowsTested:false,
      },null,2));return;
    }
    if(process.argv.includes('--camera-controls-only')){
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-name"]')`);
      for(const [id,value] of [['input-customer-name','촬영시험'],['input-customer-phone','01011112222']]){
        await evaluate('staff',`document.querySelector('[data-testid="${id}"]').focus()`);
        await send('Input.insertText',{text:value},sessions.staff);
      }
      await evaluate('staff',`document.querySelector('[data-testid="button-add-item"]').click()`);
      await wait('staff',`!!document.querySelector('[data-testid="button-ndc-preview"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-preview"]').click()`);
      await wait('staff',`!document.querySelector('[data-testid="button-ndc-shoot"]').disabled`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').focus()`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F12',code:'F12',windowsVirtualKeyCode:123},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F12',code:'F12',windowsVirtualKeyCode:123},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('1컷')`);
      pass('actual F12 keydown captures a mock photo while customer-name input has focus');
      await delay(250);
      await evaluate('staff',`document.activeElement.blur()`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'F12',code:'F12',windowsVirtualKeyCode:123},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'F12',code:'F12',windowsVirtualKeyCode:123},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('2컷')`);
      assert.equal(manager.store.equipment.drafts.state(capturedOrderId).units[0].garment.photoHistory.length,2);
      pass('actual F12 keydown without input focus captures again and persists two draft photos, not fake orders');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/camera-controls-browser-result.json',JSON.stringify({
        checks,temporaryData:true,cameraMocked:true,electronIpcMocked:true,windowsTested:false,
      },null,2));return;
    }
    if(process.argv.includes('--member-upload-only')){
      memberImportFile=path.join(root,'가맹점-고객.xlsx');
      const ExcelJS=createRequire(path.resolve(__dirname,'../lib/k99-local/package.json'))('exceljs');
      const book=new ExcelJS.Workbook();
      book.addWorksheet('회원명단').addRows([['성함','전화번호','주소','비고'],
        ['가맹검증가','01012345678','검증로 1','보존 메모'],['가맹검증나','01023454321','검증로 2','다른 메모']]);
      await book.xlsx.writeFile(memberImportFile);
      await send('Page.navigate',{url:'http://localhost/management'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="button-management-import-customers"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-management-import-customers"]').click()`);
      await wait('staff',`document.activeElement.id==='customer-ledger-import'`);
      await evaluate('staff',`document.querySelector('[data-testid="button-native-ledger-import"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="status-native-ledger-import"]')?.textContent.includes('고객 2명, 주문 0건 등록 완료')`);
      assert.equal(manager.store.api('GET','/api/customers/search?q=5678').customers[0].memo,'보존 메모');
      pass('management shortcut opens native import panel; real XLSX persists profile and memo without inventing orders');
      await evaluate('staff',`document.querySelector('[data-testid="button-native-ledger-import"]').click()`);
      await wait('staff',`!document.querySelector('[data-testid="button-native-ledger-import"]').disabled`);
      assert.equal(manager.store.api('GET','/api/customers/directory').customers.length,2);
      pass('repeated native import merges name/full-phone matches rather than duplicating customers');
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-name"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').focus()`);
      await send('Input.insertText',{text:'가맹'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===2`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-list li button')].find(b=>b.textContent.includes('가맹검증가')).click()`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'검증로 1');
      assert.equal((await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').value`)).replace(/\D/g,''),'01012345678');
      pass('two-character name search immediately finds imported customers and selection fills complete phone/address');
      await evaluate('staff',`document.querySelector('[data-testid="button-new-intake"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="input-customer-phone"]').value===''`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'4321'},sessions.staff);
      await wait('staff',`document.querySelector('[data-testid="input-customer-name"]').value==='가맹검증나'`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'검증로 2');
      pass('unique four-digit phone suffix auto-fills imported customer without any extra selection');
      fs.writeFileSync('generated-artifacts/member-upload-browser-result.json',JSON.stringify({
        checks,realTemporaryXlsx:true,realTemporarySqlite:true,electronDialogSimulated:true,windowsTested:false},null,2));return;
    }
    if(process.argv.includes('--customers-only')){
      const password='isolated-customer-browser-12345';
      manager.store.api('POST','/api/desktop/admin/setup',{password});
      const csv='고객명,전화번호,주소,누적방문횟수,방문일자,접수건수,결제금액,메모,주문번호\n김시험,01012345678,과천,2,2026-11-01,3,15000,셔츠,test-1\n김시험,01012345678,과천,2,2026-11-02,2,20000,운동화,test-2\n이시험,01099995678,서울,1,2026-10-01,1,8000,,test-3';
      await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
      await wait('staff',`!!document.querySelector('.cdir-import')`);
      await evaluate('staff',`(()=>{
        const input=document.querySelector('.cdir-import input[type=file]'),files=new DataTransfer();
        files.items.add(new File([${JSON.stringify(csv)}],'customers.csv',{type:'text/csv'}));
        input.files=files.files;input.dispatchEvent(new Event('change',{bubbles:true}));
        const pass=document.querySelector('.cdir-import input[type=password]');
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(pass,${JSON.stringify(password)});
        pass.dispatchEvent(new Event('input',{bubbles:true}));
      })()`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-import button')].find(b=>b.textContent==='미리보기').click()`);
      await wait('staff',`document.querySelector('.cdir-stats')?.textContent.includes('고객 2명')`);
      assert.equal(manager.store.api('GET','/api/customers/search?q=5678').customers.length,0);
      pass('CSV file picker and authenticated preview show 2 customers/3 histories without DB writes');
      await evaluate('staff',`document.querySelector('.cdir-import input[type=checkbox]').click()`);
      await evaluate('staff',`[...document.querySelectorAll('.cdir-import button')].find(b=>b.textContent==='가져오기 확정').click()`);
      await wait('staff',`document.querySelector('.cdir-ok')?.textContent.includes('방문 이력 3건')`);
      assert.equal(manager.store.api('GET','/api/customers/search?q=5678').customers.length,2);
      assert.ok(fs.existsSync(await evaluate('staff',`document.querySelector('.cdir-ok').textContent.split('백업 파일: ')[1].trim()`)));
      pass('explicit commit writes customer histories and produces an existing pre-import backup');
      await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
      await wait('staff',`!!document.querySelector('[data-testid="input-customer-phone"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'5678'},sessions.staff);
      await wait('staff',`document.querySelectorAll('.cdir-list li button').length===2`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').value`),'');
      pass('four-digit suffix lists both customers and does not silently select either');
      await evaluate('staff',`[...document.querySelectorAll('.cdir-list li button')].find(b=>b.textContent.includes('김시험')).click()`);
      await wait('staff',`document.querySelector('.cdir-badge')?.textContent.includes('3번째 방문')`);
      assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-address"]').value`),'과천');
      assert.equal((await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').value`)).replace(/\D/g,''),'01012345678');
      pass('explicit selection populates name/phone/address and displays previous visits plus one');
      await evaluate('staff',`[...document.querySelectorAll('.cdir-lookup button')].find(b=>b.textContent.includes('방문 이력')).click()`);
      await wait('staff',`document.querySelector('[role=dialog]')?.textContent.includes('35,000')`);
      assert.equal(await evaluate('staff',`document.querySelector('[role=dialog]').textContent.includes('5')`),true);
      pass('history dialog shows both dates, item quantities and correct paid-amount totals');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/customer-directory-browser-result.json',JSON.stringify({
        checks,temporaryData:true,syntheticCsv:true,electronIpcMocked:true,windowsTested:false,
      },null,2));return;
    }
    if(!process.argv.includes('--photo-ux-only')){
    await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0`);
    assert.equal(await evaluate('customer',`(()=>{const v=document.querySelector('[data-testid="customer-promo-video"]');return v.loop&&v.muted&&v.autoplay&&v.playsInline;})()`),true);
    await evaluate('customer',`(()=>{const v=document.querySelector('[data-testid="customer-promo-video"]');window.__promoNode=v;v.currentTime=v.duration-0.2;})()`);
    await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')===window.__promoNode&&window.__promoNode.currentTime<2`);
    pass('idle original 18s promo survives end on same video element with loop/muted/autoplay/playsInline');
    for(const [key,selector] of [['value','price'],['process','water'],['water','dry'],['sneakers','sneakers']]){
      customerWindow.minimized=true;customerWindow.focused=false;
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-${selector}-video"]').click()`);
      await wait('customer',`document.querySelector('video[data-video="${key}"]')?.currentTime>0`);
      assert.equal(await evaluate('customer',`document.querySelector('video[data-video="${key}"]').loop`),false);
      assert.equal(customerWindow.minimized,false);assert.equal(customerWindow.focused,true);
      assert.equal(customerWindow.top,true);assert.equal(customerWindow.fullscreen,true);
      assert.equal(await evaluate('customer',`document.querySelector('video').controls`),false);
      await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('재생 중')`);
      await evaluate('customer',`window.__finishedGuide=document.querySelector('video');window.__finishedGuide.currentTime=window.__finishedGuide.duration-0.25`);
      await wait('customer',`!!document.querySelector('[data-testid="customer-display-screen"]')&&!document.querySelector('video')`);
      assert.equal(await evaluate('customer',`!window.__finishedGuide.isConnected&&window.__finishedGuide.paused&&!window.__finishedGuide.hasAttribute('src')`),true);
      assert.equal(customerWindow.top,false);assert.equal(customerWindow.fullscreen,true);
      pass(`${key}: first frame, one-shot ended unmounts/clears guide and shows receipt, never promo`);
      if(process.argv.includes('--media-only')){
        await evaluate('staff',`document.querySelector('[data-testid="button-customer-${selector}-video"]').click()`);
        await wait('customer',`document.querySelector('video[data-video="${key}"]')?.currentTime>0`);
        await evaluate('customer',`window.__finishedGuide=document.querySelector('video');document.querySelector('[data-testid="button-customer-video-close"]').click()`);
        await wait('customer',`!!document.querySelector('[data-testid="customer-display-screen"]')&&!document.querySelector('video')`);
        assert.equal(await evaluate('customer',`!window.__finishedGuide.isConnected&&window.__finishedGuide.paused&&!window.__finishedGuide.hasAttribute('src')`),true);
        assert.equal(customerWindow.top,false);assert.equal(customerWindow.fullscreen,true);
        pass(`${key}: manual close unmounts/clears guide and shows receipt, never promo`);
      }
    }
    if(process.argv.includes('--media-only')){
      // Empty/idle snapshot updates must not override the receipt selected by guide end.
      await display.action({type:'snapshot',payload:{sourceId:'media-test',revision:Date.now(),
        customerName:'',customerPhone:'',customerAddress:'',rows:[],totalQuantity:0,normalTotal:0,premiumTotal:0,intakeActive:false}});
      await delay(400);
      assert.equal(await evaluate('customer',`!!document.querySelector('[data-testid="customer-display-screen"]')&&!document.querySelector('video')`),true);
      pass('idle snapshot cannot revive promo after guide finish');
      await wait('customer',`document.querySelector('[data-testid="panel-customer-receipt"]')?.dataset.mode==='normal'`);
      await evaluate('customer',`document.querySelector('[data-testid="button-receipt-size"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="panel-customer-receipt"]')?.dataset.mode==='expanded'`);
      await delay(400);
      assert.equal(await evaluate('customer',`Math.abs(document.querySelector('.crp-frame').getBoundingClientRect().width-innerWidth)<2`),true);
      await evaluate('customer',`document.querySelector('[data-testid="button-receipt-size"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="panel-customer-receipt"]')?.dataset.mode==='normal'`);
      pass('receipt expands to viewport and returns to centered normal panel');
      await evaluate('customer',`document.querySelector('[data-testid="button-receipt-collapse"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="panel-customer-receipt"]')?.dataset.mode==='collapsed'`);
      await delay(500);
      assert.equal(await evaluate('customer',`document.querySelector('.crp-frame').inert&&document.querySelector('.crp-frame').getBoundingClientRect().top>=innerHeight&&!document.querySelector('[data-testid="button-receipt-expand"]').hidden`),true);
      await evaluate('customer',`document.querySelector('[data-testid="button-receipt-expand"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="panel-customer-receipt"]')?.dataset.mode==='normal'`);
      pass('receipt slides below viewport, leaves bottom restore bar, restores without losing content');
      await evaluate('customer',`document.querySelector('[data-testid="button-receipt-idle"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0&&!document.querySelector('[data-testid="panel-customer-receipt"]')`);
      pass('customer receipt idle button unmounts receipt and plays muted looping promo');
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-price-video"]').click()`);
      await wait('customer',`document.querySelector('video[data-video="value"]')?.currentTime>0`);
      await evaluate('staff',`window.__idleInterruptedGuide=null;document.querySelector('[data-testid="button-customer-idle"]').click()`);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0&&!document.querySelector('[data-testid="customer-media-video"]')`);
      assert.equal(customerWindow.top,false);
      pass('staff idle button interrupts an actively playing guide through native coordinator');
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-price-video"]').click()`);
      await wait('customer',`document.querySelector('video[data-video="value"]')?.currentTime>0`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Escape',code:'Escape',windowsVirtualKeyCode:27},sessions.staff);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0`);
      pass('real ESC keyboard input in staff intake uses the same idle action');
      await display.action({type:'snapshot',payload:{sourceId:'media-test',revision:Date.now()+1,
        customerName:'새 접수',customerPhone:'',customerAddress:'',rows:[],totalQuantity:0,normalTotal:0,premiumTotal:0,intakeActive:true}});
      await delay(400);
      assert.equal(await evaluate('customer',`!!document.querySelector('[data-testid="customer-promo-video"]')&&!document.querySelector('[data-testid="panel-customer-receipt"]')`),true);
      pass('new snapshots do not undo explicit idle selection');
      // Live input, unlike restored/saved snapshots, must override explicit idle.
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').focus()`);
      await send('Input.insertText',{text:'김'},sessions.staff);
      await wait('customer',`!!document.querySelector('[data-testid="panel-customer-receipt"]')&&!document.querySelector('[data-testid="customer-promo-video"]')`);
      pass('typing customer name switches explicit idle to receipt through SWITCH_TO_RECEIPT');
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-idle"]').click()`);
      await wait('customer',`!!document.querySelector('[data-testid="customer-promo-video"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'010'},sessions.staff);
      await wait('customer',`!!document.querySelector('[data-testid="panel-customer-receipt"]')&&!document.querySelector('[data-testid="customer-promo-video"]')`);
      pass('typing phone switches explicit idle to receipt through SWITCH_TO_RECEIPT');
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-idle"]').click()`);
      await wait('customer',`!!document.querySelector('[data-testid="customer-promo-video"]')`);
      await evaluate('staff',`document.querySelector('[data-testid="button-add-item"]').click()`);
      await wait('customer',`!!document.querySelector('[data-testid="panel-customer-receipt"]')&&!document.querySelector('[data-testid="customer-promo-video"]')`);
      pass('adding a laundry item switches explicit idle to receipt');
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-price-video"]').click()`);
      await wait('customer',`document.querySelector('video[data-video="value"]')?.currentTime>0`);
      await evaluate('staff',`document.querySelector('[data-testid="input-customer-phone"]').focus()`);
      await send('Input.insertText',{text:'1234'},sessions.staff);
      await delay(200);
      assert.equal(await evaluate('customer',`!!document.querySelector('video[data-video="value"]')`),true);
      pass('input during guide updates data without interrupting one-shot guide');
      await evaluate('customer',`document.querySelector('[data-testid="button-customer-video-close"]').click()`);
      await wait('customer',`!!document.querySelector('[data-testid="panel-customer-receipt"]')`);
      await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
      await wait('staff',`!!document.querySelector('#root')?.textContent.includes('장비')`);
      await display.action({type:'video',command:{id:crypto.randomUUID(),video:'process',issuedAt:Date.now()}});
      await wait('customer',`document.querySelector('video[data-video="process"]')?.currentTime>0`);
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27},sessions.staff);
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Escape',code:'Escape',windowsVirtualKeyCode:27},sessions.staff);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0`);
      pass('global staff ESC still works after intake unmounts on equipment route');
      if(asyncError)throw asyncError;
      fs.writeFileSync('generated-artifacts/customer-media-receipt-result.json',JSON.stringify({
        checks,temporaryData:true,originalVideos:true,electronIpcMocked:true,physicalDisplaysMocked:true,windowsTested:false,
      },null,2));
      return;
    }
    await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').focus()`);
    for(const ch of 'rlarntn')await send('Input.insertText',{text:ch},sessions.staff);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').value`),'김구수');
    pass('real browser ASCII keystrokes compose 김구수 without a Windows IME or external dependency');
    await evaluate('staff',`(() => {
      const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      for(const [id,value] of [['input-customer-name','모의현장시험'],['input-customer-phone','1234']]){
        const e=document.querySelector('[data-testid="'+id+'"]');set.call(e,value);e.dispatchEvent(new Event('input',{bubbles:true}));
      }
      document.querySelector('[data-testid="button-add-item"]').click();
    })()`);
    await wait('customer',`!!document.querySelector('[data-testid="customer-event-banner"]')`);
    const banner=await evaluate('customer',`document.querySelector('[data-testid="customer-event-banner"]').textContent`);
    for(const text of ['🎉 세탁할수록 커지는 혜택','10만 원 이상 결제 시:','10% 할인','20만 원 이상 결제 시:','15% 할인','5만 원 이상 고객 영수증 리뷰 작성 시:','5,000원 즉시 할인'])assert.ok(banner.includes(text),text);
    pass('new active intake exits promo and preserves the receipt benefit banner');
    await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
    await wait('staff',`document.querySelector('[data-testid="button-ndc-shoot"]')?.disabled===false`);
    for(let n=1;n<=12;n++){
      await wait('staff',`!document.querySelector('[data-testid="button-ndc-shoot"]').disabled`);
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-shoot"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('${n}컷')`);
    }
    assert.equal(manager.store.status().orderCount,0);
    const draft=await equipment.api('POST','/api/equipment/command',{action:'draft-state',orderId:capturedOrderId});
    const unit=draft.units[0];
    assert.equal(unit.photos.length,12);assert.equal(Object.values(unit.jobsByMode).length,1);
    for(const photo of unit.photos)assert.equal(manager.store.equipment.photoFile(photo.id).bytes[0],255);
    pass('real React intake saves 12 mock JPEG shots to temporary SQLite/D archive, one mock tag, no fake orders');
    await evaluate('staff',`document.querySelector('.ndc-modal-close').click()`);
    await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="select-customer-monitor"]')?.value==='2'`);
    await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('[연결됨]')`);
    await evaluate('staff',`document.querySelector('.rcs-camera').click()`);
    await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('12컷')`);
    await evaluate('staff',`document.querySelector('.ndc-modal-close').click()`);
    assert.equal(display.displayStatus().displayId,'2');
    pass('equipment/reception navigation retains native monitor ID and live connection');
    }
    // New field workflow uses only this test's temporary SQLite via the real renderer bridge.
    await evaluate('staff',`(async()=>{
      const r=await import('/src/order-record.ts'),g=await import('/src/garment-record.ts');
      const o=r.createConfirmedOrder({id:'UI-FIELD-QC',customerName:'검증고객',customerPhone:'6789',customerAddress:'',
        items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
        {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,requestedPickupDate:'',
          waiver:'not-requested',luxuryItem:false,customerRequests:'없음'});
      r.insertConfirmedOrder({...o,garments:g.createGarmentRecords(o)});
    })()`);
    await send('Page.navigate',{url:'http://localhost/?orderId=UI-FIELD-QC&inspection=1'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="toggle-review-confirmed-0"]')?.getAttribute('aria-checked')==='true'`);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="toggle-review-method-0-물세탁"]').getAttribute('aria-checked')`),'true');
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="toggle-review-result-0-이상 없음"]').getAttribute('aria-checked')`),'true');
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-notice-waiver"]')`);
    for(const kind of ['waiver','fee','both']){
      await evaluate('staff',`document.querySelector('[data-testid="button-notice-${kind}"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="input-notice-message"]')?.value.includes('[K99 세탁의 품격 |')`);
      const text=await evaluate('staff',`document.querySelector('[data-testid="input-notice-message"]').value`);
      assert.ok(text.includes('검증고객 고객님'));assert.ok(text.includes('[와이셔츠 2점]'));
      if(kind!=='waiver')assert.ok(text.includes('00,000원'));
    }
    await evaluate('staff',`Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__copiedNotice=text;}}});document.querySelector('[data-testid="button-notice-copy"]').click()`);
    await wait('staff',`window.__copiedNotice===document.querySelector('[data-testid="input-notice-message"]').value`);
    assert.deepEqual(await evaluate('staff',`(()=>{
      const human=[...document.querySelectorAll('input,textarea')].filter(i=>
        !i.readOnly&&['text','search','textarea'].includes(i.type)&&
        !['numeric','decimal','tel','url','email'].includes(i.inputMode)&&
        !/barcode|바코드|번호|url|경로|프린터|키 코드/i.test([i.id,i.name,i.placeholder,i.getAttribute('aria-label'),i.getAttribute('data-testid'),i.closest('label')?.textContent].join(' ')));
      return human.filter(i=>i.lang!=='ko'||i.inputMode!=='text')
        .map(i=>({id:i.getAttribute('data-testid'),label:i.placeholder,lang:i.lang,mode:i.inputMode}));
    })()`),[]);
    pass('inspection defaults wet/normal/confirmed, Korean input attributes and all three official messages; clipboard adapter receives exact text');
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-isd-before-after"]')`);
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-isd-finish-all"]')`);
    await evaluate('staff',`document.querySelector('[data-testid^="button-isd-qc-"]').click()`);
    await wait('staff',`[...document.querySelectorAll('[data-testid^="row-isd-garment-"]')].some(e=>e.textContent.includes('검수 완료'))`);
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-finish-all"]').click()`);
    // Completion may immediately navigate away via onCompleted; inspect the
    // committed order, not a success message on the now-unmounted screen.
    await wait('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC')?.operations?.stage==='세탁완료';})()`);
    const qc=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC');})()`);
    assert.equal(qc.operations.stage,'세탁완료');assert.ok(qc.garments.every(g=>g.completionStatus==='complete'&&!g.completionPhoto));
    pass('individual final QC then bulk release persists without comparison photos or any completion scan');
    await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
    await wait('staff',`!!document.querySelector('[data-testid="card-ready-order-UI-FIELD-QC"]')`);
    // The new photo editor flow uses real HTTP + temporary SQLite/files.
    // Only nativeImage, Explorer and Electron IPC are substituted in Linux.
    await evaluate('staff',`document.querySelector('[data-testid="button-card-photo-folder-UI-FIELD-QC"]').click()`);
    await wait('staff',`document.body.innerText.includes('탐색기에서 열었습니다')`);
    assert.equal(manager.store.equipment.getOrder('UI-FIELD-QC').operations.stage,'세탁완료');
    assert.ok(await evaluate('staff',`(()=>{
      const s=getComputedStyle(document.querySelector('.handover-card__items'));
      return parseFloat(s.fontSize)>=16&&+s.fontWeight>=700;
    })()`));
    pass('release card shows large bright item names; folder button opens order intake archive without handover');
    await evaluate('staff',`document.querySelector('[data-testid="button-select-order-UI-FIELD-QC"]').click()`);
    const sampleJpeg=await evaluate('staff',`(()=>{
      const c=document.createElement('canvas');c.width=800;c.height=600;
      const g=c.getContext('2d');g.fillStyle='#eee8dc';g.fillRect(0,0,800,600);
      g.fillStyle='#333';g.fillRect(250,220,120,80);return c.toDataURL('image/jpeg',.92);
    })()`);
    await equipment.api('POST','/api/equipment/command',{action:'capture',orderId:qc.id,
      garmentId:qc.garments[0].garmentId,role:'intake',requestId:'photo-ux-intake-001',imageDataUrl:sampleJpeg});
    const priorConfig=manager.store.equipment.getConfig();
    manager.store.equipment.configure({...priorConfig,mode:'real',labelVerified:true,hardwareConfirmed:true},true);
    await send('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false},sessions.staff);
    await send('Page.bringToFront',{},sessions.staff);
    await evaluate('staff',`document.querySelector('[data-testid="button-scanner-before-after"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="editor-before"] svg')`);
    assert.ok(await evaluate('staff',`(()=>{
      const selectors=['.ba2-tools','[data-testid="panel-mobile-after"]','.ba2-side [aria-label="설명 글자 크기"]','.ba2-side .ba-text','[data-testid="button-save-before-after"]'];
      const els=selectors.map(s=>document.querySelector(s));const stage=document.querySelector('[data-testid="editor-before"]');
      return els.every(Boolean)&&els.slice(1).every((e,i)=>!!(els[i].compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING))&&
        getComputedStyle(stage.querySelector('img')).objectFit==='cover'&&Math.abs(stage.clientWidth-stage.clientHeight)<=1;
    })()`));
    pass('comparison tools, QR, text size, description and save follow requested order; cover editors match square export frames');
    await evaluate('staff',`(()=>{const e=document.querySelector('[data-testid="input-before-after-text"]');e.focus();e.select();})()`);
    for(const text of 'djffnr wprj dhksfy')await send('Input.insertText',{text},sessions.staff);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-before-after-text"]').value`),'얼룩 제거 완료');
    const description='얼룩 제거 완료 · 손세탁';
    await evaluate('staff',`document.querySelector('[data-testid="input-before-after-text"]').select()`);
    await send('Input.imeSetComposition',{text:description,selectionStart:description.length,selectionEnd:description.length},sessions.staff);
    await send('Input.insertText',{text:description},sessions.staff);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-before-after-text"]').value`),description);
    pass('before/after process description preserves Korean keyboard fallback and genuine Chromium composition before preview/JPEG save');
    await evaluate('staff',`document.querySelector('[data-testid="button-after-mobile-qr"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="img-comparison-qr"]')`);
    // Use the real controller's start reply observed at the IPC boundary.
    // No fabricated QR session or browser-only mock upload.
    const qrTarget=lastComparisonSession?.urls?.[0];
    assert.ok(qrTarget,'Actual QR session URL required');
    const uploadUrl=new URL(qrTarget);
    const jobsBefore=manager.store.equipment.state().jobs.length;
    for(const id of ['photo-ux-after-001','photo-ux-after-002']){
      const response=await fetch(uploadUrl.origin+'/api/upload-mobile-photo',{method:'POST',headers:{
        'Content-Type':'image/jpeg','X-K99-Session-Token':uploadUrl.searchParams.get('token'),'X-K99-Upload-Id':id},
        body:Buffer.from(sampleJpeg.split(',')[1],'base64')});
      assert.equal(response.status,200,await response.text());
    }
    await wait('staff',`document.querySelector('[data-testid="text-mobile-status"]')?.textContent.includes('2장')`);
    await wait('staff',`!document.querySelector('[data-testid="button-save-before-after"]').disabled`);
    const status=await comparisonMobile.api('GET',`/api/comparison-mobile/status?id=${lastComparisonSession.id}`);
    assert.ok(await evaluate('staff',`document.querySelector('[data-testid="editor-after"] img').src.endsWith(${JSON.stringify(status.lastResult.photo.url)})`));
    assert.equal(manager.store.equipment.state().jobs.length,jobsBefore);
    pass('actual LAN QR uploads update After to latest of two photos and create no additional tag');
    // Pointer drag on rendered SVG: create, move by border, resize by corner.
    async function drag(selector,from,to){
      await evaluate('staff',`document.querySelector(${JSON.stringify(selector)}).scrollIntoView({block:'center'})`);
      const box=await evaluate('staff',`(()=>{let e=document.querySelector(${JSON.stringify(selector)});if(e.tagName.toLowerCase()==='svg')e=e.closest('.bam__stage');const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height};})()`);
      const a={x:box.x+box.w*from[0],y:box.y+box.h*from[1]},b={x:box.x+box.w*to[0],y:box.y+box.h*to[1]};
      await send('Input.dispatchMouseEvent',{type:'mousePressed',...a,button:'left',clickCount:1},sessions.staff);
      await send('Input.dispatchMouseEvent',{type:'mouseMoved',...b,button:'left',buttons:1},sessions.staff);
      await send('Input.dispatchMouseEvent',{type:'mouseReleased',...b,button:'left',clickCount:1},sessions.staff);
    }
    await drag('[data-testid="editor-before"] svg',[.2,.2],[.6,.6]);
    await wait('staff',`document.querySelectorAll('[data-testid^="mark-before-"]').length===1`);
    await evaluate('staff',`document.querySelector('[data-testid="button-tool-rect"]').click();document.querySelector('[data-testid="button-color-blue"]').click()`);
    await drag('[data-testid="editor-after"] svg',[.2,.2],[.6,.6]);
    await wait('staff',`document.querySelectorAll('[data-testid^="mark-after-"]').length===1`);
    const oldX=await evaluate('staff',`+document.querySelector('[data-testid^="mark-after-"] rect').getAttribute('x')`);
    await drag('[data-testid^="mark-after-"] rect',[0,.5],[.1,.6]);
    assert.ok(await evaluate('staff',`+document.querySelector('[data-testid^="mark-after-"] rect').getAttribute('x')>${oldX}`));
    await drag('[data-testid="editor-after"] [data-corner="se"]',[.5,.5],[1.5,1.5]);
    await wait('staff',`!document.querySelector('[data-testid="button-save-before-after"]').disabled`);
    pass('Before red circle / After blue rectangle support pointer drawing, border movement and corner resizing');
    const beforeTextHash=await evaluate('staff',`document.querySelector('[data-testid="canvas-before-after"]').toDataURL()`);
    await evaluate('staff',`document.querySelector('[data-testid="button-text-size-xlarge"]').click()`);
    await wait('staff',`!document.querySelector('[data-testid="button-save-before-after"]').disabled&&document.querySelector('[data-testid="button-text-size-xlarge"]').getAttribute('aria-pressed')==='true'`);
    assert.notEqual(await evaluate('staff',`document.querySelector('[data-testid="canvas-before-after"]').toDataURL()`),beforeTextHash);
    const savedJpeg=await evaluate('staff',`document.querySelector('[data-testid="canvas-before-after"]').toDataURL('image/jpeg',.92)`);
    await evaluate('staff',`document.querySelector('[data-testid="button-save-before-after"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-before-after"]')?.textContent.includes('저장했습니다')`);
    const savedPhoto=manager.store.equipment.state().photos.find(p=>!['photo-ux-after-001','photo-ux-after-002'].includes(p.id)&&p.role==='completion');
    assert.ok(savedPhoto);
    const match=manager.store.equipment.state().photos.filter(p=>p.role==='completion')
      .find(p=>manager.store.equipment.photoFile(p.id).bytes.equals(Buffer.from(savedJpeg.split(',')[1],'base64')));
    assert.ok(match,'Saved JPEG must exactly match annotated preview and selected font size');
    pass('larger text updates canvas; saved Before-After JPEG exactly matches annotated preview bytes');
    await evaluate('staff',`document.querySelector('.ba2-body').scrollTop=0;document.querySelector('dialog.ba2').scrollTop=0`);
    fs.writeFileSync('generated-artifacts/v230-photo-editor.png',Buffer.from((await send('Page.captureScreenshot',{format:'png'},sessions.staff)).data,'base64'));
    await evaluate('staff',`document.querySelector('[data-testid="button-close-before-after"]').click()`);
    await wait('staff',`!document.querySelector('[data-testid="dialog-before-after"]')`);
    await assert.rejects(()=>comparisonMobile.api('GET',`/api/comparison-mobile/status?id=${lastComparisonSession.id}`));
    manager.store.equipment.configure(priorConfig,true);
    pass('closing editor revokes its QR session; original order and reception configuration remain intact');
    await evaluate('staff',`(()=>{
      const el=document.querySelector('[data-testid="input-scanner-barcode"]');
      el.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,'6789');
      el.dispatchEvent(new Event('input',{bubbles:true}));
    })()`);
    await wait('staff',`document.querySelector('[data-testid="panel-selected-order"]')?.textContent.includes('검증고객')`);
    await wait('staff',`!document.querySelector('[data-testid="button-scanner-handover"]').disabled`);
    assert.equal(await evaluate('staff',`document.activeElement===document.querySelector('[data-testid="input-scanner-barcode"]')`),true);
    const notYetHanded=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC').operations.stage;})()`);
    assert.equal(notYetHanded,'세탁완료');
    await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await wait('staff',`!!document.querySelector('[data-testid="button-choice-handover-UI-FIELD-QC"]')`);
    assert.equal(await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC').operations.stage;})()`),'세탁완료');
    await evaluate('staff',`document.querySelector('[data-testid="button-choice-handover-UI-FIELD-QC"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-scanner-feedback"]')?.textContent.includes('인도했습니다')`);
    const handed=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC');})()`);
    assert.equal(handed.operations.stage,'매장수령완료');
    assert.equal(handed.history.at(-1).details.method,'staff-confirmed');
    assert.ok(handed.garments.every(g=>g.handoverStatus==='complete'));
    pass('outgoing lookup Enter is read-only; only the explicit departure button persists staff handover');
    const shippedRaw=manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'});
    for(const keyword of [handed.id,handed.customerName,handed.customerPhone.replace(/\D/g,'').slice(-4),handed.garments[0].barcodeValue]){
      await evaluate('staff',`(()=>{
        const el=document.querySelector('[data-testid="input-scanner-barcode"]');
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,${JSON.stringify(keyword)});
        el.dispatchEvent(new Event('input',{bubbles:true}));el.form.requestSubmit();
      })()`);
      await wait('staff',`!!document.querySelector('[data-testid="button-choice-restore-UI-FIELD-QC"]')`);
    }
    assert.equal(manager.store.storage({op:'get',key:'k99-confirmed-orders-v1'}),shippedRaw);
    pass('departed order is searchable by order code, name, phone suffix and garment barcode without any SQLite mutation');
    await evaluate('staff',`document.querySelector('[data-testid="button-undo-handover"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-scanner-feedback"]')?.textContent.includes('복구했습니다')`);
    assert.equal(await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');const o=r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC');return o.operations.completedAt===undefined&&o.garments.every(g=>g.handoverStatus==='pending')})()`),true);
    pass('latest departure undo restores ready garments, clears final departure date and persists in temporary SQLite');
    await evaluate('staff',`document.querySelector('[data-testid="button-card-handover-UI-FIELD-QC"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-scanner-feedback"]')?.textContent.includes('인도했습니다')`);
    await evaluate('staff',`(()=>{
      const el=document.querySelector('[data-testid="input-scanner-barcode"]');
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,'UI-FIELD-QC');
      el.dispatchEvent(new Event('input',{bubbles:true}));el.form.requestSubmit();
    })()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-choice-restore-UI-FIELD-QC"]')`);
    assert.equal(await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC').operations.stage;})()`),'매장수령완료');
    await evaluate('staff',`document.querySelector('[data-testid="button-choice-restore-UI-FIELD-QC"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-scanner-feedback"]')?.textContent.includes('복구했습니다')`);
    pass('historical departed order is searchable without mutation and explicitly restored from its result card');
    await evaluate('staff',`(async()=>{
      const r=await import('/src/order-record.ts');
      for(const suffix of ['A','B']){
        const copy=${JSON.stringify(qc)};copy.id='UI-AMBIGUOUS-'+suffix;copy.customerName='중복시험'+suffix;copy.customerPhone='01055558888';
        copy.scanAuditEvents=[];copy.history=[];
        copy.garments=copy.garments.map((g,i)=>({...g,orderId:copy.id,garmentId:copy.id+'-G'+i,barcodeValue:copy.id+'-G'+i,
          auditEvents:[],beforePhoto:undefined,completionPhoto:undefined,photoHistory:[]}));
        r.insertConfirmedOrder(copy);
      }
    })()`);
    await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
    await wait('staff',`document.querySelectorAll('[data-testid^="card-ready-order-UI-AMBIGUOUS-"]').length===2`);
    await evaluate('staff',`(()=>{
      const el=document.querySelector('[data-testid="input-scanner-barcode"]');el.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,'8888');
      el.dispatchEvent(new Event('input',{bubbles:true}));
    })()`);
    await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await wait('staff',`!!document.querySelector('[data-testid="panel-lookup-choices"]')`);
    assert.equal(await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().filter(o=>o.id.startsWith('UI-AMBIGUOUS-')).every(o=>o.operations.stage==='세탁완료');})()`),true);
    await evaluate('staff',`document.querySelector('[data-testid="button-card-handover-UI-AMBIGUOUS-A"]').click()`);
    await wait('staff',`!document.querySelector('[data-testid="card-ready-order-UI-AMBIGUOUS-A"]')`);
    assert.equal(await evaluate('staff',`!!document.querySelector('[data-testid="card-ready-order-UI-AMBIGUOUS-B"]')`),true);
    pass('ambiguous phone suffix never hands over automatically; explicit card departure changes only the selected order');
    fs.mkdirSync('generated-artifacts',{recursive:true});
    // Functional evidence is saved independently of background-tab screenshot capture.
    // Visual review uses the app preview screenshot tool instead.
    fs.writeFileSync('generated-artifacts/customer-ipc-browser-result.json',JSON.stringify({
      checks,temporaryData:true,originalVideos:true,electronIpcMocked:true,physicalDisplaysMocked:true,windowsTested:false,
    },null,2));
  }finally{
    closing=true;
    for(const item of pending.values()){clearTimeout(item.timer);item.reject(Error('Browser verification shutdown'));}
    pending.clear();
    socket?.close();chrome.kill('SIGTERM');await delay(250);mobile?.close();comparisonMobile?.close();manager.close();await fsp.rm(root,{recursive:true,force:true});
  }
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
