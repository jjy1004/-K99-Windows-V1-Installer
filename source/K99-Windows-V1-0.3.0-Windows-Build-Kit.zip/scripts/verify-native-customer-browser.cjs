'use strict';
// Chromium + real display coordinator + virtual screen/IPC, NOT Windows Electron.
// All API calls use an OS-temporary SQLite; all storage uses a fresh browser profile.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {spawn}=require('node:child_process'),{EventEmitter}=require('node:events'),assert=require('node:assert/strict');
const {createDesktopManager}=require('../lib/k99-local/desktop-manager.cjs');
const {createEquipmentApi}=require('../lib/k99-local/equipment-api.cjs');
const {createCustomerDisplay}=require('../artifacts/k99-windows/electron/customer-display.cjs');
const {videoResponse}=require('../artifacts/k99-windows/electron/customer-video.cjs');
const {createPhotoArchive}=require('../artifacts/k99-windows/electron/photo-archive.cjs');
async function main(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'k99-native-browser-')),manager=createDesktopManager(path.join(root,'store'));
  const videos=path.resolve(__dirname,'../generated-artifacts/customer-videos'),checks=[],sessions={};
  let capturedOrderId=null;
  const chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage',
    '--autoplay-policy=no-user-gesture-required','--remote-debugging-port=0',`--user-data-dir=${path.join(root,'browser')}`,'about:blank'],
    {stdio:['ignore','ignore','pipe']});
  let socket,seq=0,display,customerWindow;const pending=new Map();
  const delay=ms=>new Promise(r=>setTimeout(r,ms));
  const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
    const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(`CDP timeout ${method}`));},20000);
    pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));
  });
  const evaluate=async(role,expression)=>{
    const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessions[role]);
    if(r.exceptionDetails)throw Error(r.exceptionDetails.text+': '+r.exceptionDetails.exception?.description);
    return r.result?.value;
  };
  const deliver=(role,channel,data)=>{void evaluate(role,`window.__nativeDeliver?.(${JSON.stringify(channel)},${JSON.stringify(data)})`).catch(()=>{});};
  async function wait(role,expression){
    const end=Date.now()+15000;
    while(Date.now()<end){if(await evaluate(role,expression))return;await delay(80);}
    throw Error(`UI timeout (${role}): ${expression}`);
  }
  const pass=message=>{checks.push(message);console.log('PASS',message);};
  try{
    const endpoint=await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('Chromium startup timeout')),20000);
      chrome.stderr.on('data',b=>{const m=String(b).match(/DevTools listening on (ws:\/\/\S+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
      chrome.on('error',reject);
    });
    socket=new WebSocket(endpoint);await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
    socket.onmessage=async event=>{
      const msg=JSON.parse(event.data);
      if(msg.method==='Runtime.bindingCalled'){
        const role=Object.keys(sessions).find(k=>sessions[k]===msg.sessionId),call=JSON.parse(msg.params.payload);
        try{
          let value;
          if(call.op==='action'){assert.equal(role,'staff');display.action(call.args);}
          else if(call.op==='event'){assert.equal(role,'customer');display.customerEvent(customerWindow.webContents,call.args);}
          else if(call.op==='status')value=display.displayStatus();
          else if(call.op==='request'){
            const p=call.args;
            if(p.body?.action==='capture-draft')capturedOrderId=p.body.orderId;
            value=p.path.startsWith('/api/equipment/')?await equipment.api(p.method,p.path,p.body):manager.store.api(p.method,p.path,p.body);
            value={ok:true,result:value};
          }else throw Error('Unsupported mock IPC');
          if(call.id)await evaluate(role,`window.__nativeReply(${JSON.stringify(call.id)},${JSON.stringify(value)},null)`);
        }catch(error){if(call.id)await evaluate(role,`window.__nativeReply(${JSON.stringify(call.id)},null,${JSON.stringify(error.message)})`);}
        return;
      }
      if(msg.method==='Fetch.requestPaused'){
        const {request,requestId}=msg.params;
        if(new URL(request.url).pathname==='/api/local/storage'){
          let reply;
          try{reply={ok:true,result:manager.store.storage(JSON.parse(request.postData))};}
          catch(error){reply={ok:false,error:error.message,status:error.status||500};}
          await send('Fetch.fulfillRequest',{requestId,responseCode:200,
            responseHeaders:[{name:'Content-Type',value:'application/json'}],
            body:Buffer.from(JSON.stringify(reply)).toString('base64')},msg.sessionId);return;
        }
        if(new URL(request.url).pathname.startsWith('/api/'))throw Error('Unexpected API escaped mock IPC');
        const response=await videoResponse(new Request(request.url,{headers:request.headers}),videos);
        try{
          await send('Fetch.fulfillRequest',{requestId,responseCode:response.status,responseHeaders:[...response.headers].map(([name,value])=>({name,value})),
            body:Buffer.from(await response.arrayBuffer()).toString('base64')},msg.sessionId);
        }catch(error){
          // Seeking/ending video legitimately cancels an in-flight Range request.
          if(!/Invalid InterceptionId/.test(error.message))throw error;
        }
        return;
      }
      const item=pending.get(msg.id);if(!item)return;pending.delete(msg.id);clearTimeout(item.timer);
      msg.error?item.reject(Error(JSON.stringify(msg.error))):item.resolve(msg.result);
    };
    for(const role of ['staff','customer']){
      const {targetId}=await send('Target.createTarget',{url:'about:blank'});
      sessions[role]=(await send('Target.attachToTarget',{targetId,flatten:true})).sessionId;
      const id=sessions[role];await send('Page.enable',{},id);await send('Runtime.enable',{},id);
      await send('Runtime.addBinding',{name:'__nativeCall'},id);
      await send('Fetch.enable',{patterns:[{urlPattern:'*/videos/*'},{urlPattern:'*/api/*'}]},id);
      await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
        const raw=window.localStorage,NativeXHR=window.XMLHttpRequest,listeners={},pending=new Map();
        const call=(op,args)=>new Promise((resolve,reject)=>{const id=crypto.randomUUID();pending.set(id,{resolve,reject});__nativeCall(JSON.stringify({op,args,id}));});
        window.__nativeReply=(id,value,error)=>{const p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(Error(error)):p.resolve(value);};
        window.__nativeDeliver=(channel,data)=>(listeners[channel]||[]).forEach(fn=>fn(data));
        const on=(channel,fn)=>{(listeners[channel]||=[]).push(fn);return ()=>{listeners[channel]=listeners[channel].filter(f=>f!==fn);};};
        window.k99Desktop={storage:i=>{
          const x=new NativeXHR();x.open('POST','/api/local/storage',false);
          x.setRequestHeader('Content-Type','application/json');x.send(JSON.stringify(i));return JSON.parse(x.responseText);
        },request:p=>call('request',p),customerStatus:()=>call('status'),
          customerAction:args=>__nativeCall(JSON.stringify({op:'action',args})),
          customerEvent:args=>__nativeCall(JSON.stringify({op:'event',args})),
          onChanged:fn=>on('k99:changed',fn),onCustomerUpdate:fn=>on('customer-update',fn),
          onCustomerConnection:fn=>on('customer-connection',fn)};
      })();`},id);
    }
    class Window extends EventEmitter{
      constructor(options){super();this.options=options;this.webContents=new EventEmitter();this.dead=false;
        this.webContents.setWindowOpenHandler=()=>{};this.webContents.send=(channel,data)=>deliver('customer',channel,data);customerWindow=this;}
      async loadURL(){await send('Page.navigate',{url:'http://localhost/customer'},sessions.customer);}
      show(){}isDestroyed(){return this.dead;}close(){this.emit('close');this.dead=true;this.emit('closed');}setBounds(){}
      isMinimized(){return !!this.minimized;}restore(){this.minimized=false;}
      focus(){this.focused=true;}setAlwaysOnTop(value){this.top=value;}setFullScreen(value){this.fullscreen=value;}
    }
    const screen=new EventEmitter();
    screen.getAllDisplays=()=>[{id:1,label:'Staff',bounds:{x:0,y:0,width:1440,height:900}},
      {id:2,label:'LG FULL HD mock',bounds:{x:1440,y:0,width:1920,height:1080}}];
    screen.getPrimaryDisplay=()=>screen.getAllDisplays()[0];
    display=createCustomerDisplay({BrowserWindow:Window,screen,preload:'mock',changed:()=>{},
      preferencesFile:path.join(root,'display.json'),
      getMain:()=>({isDestroyed:()=>false,webContents:{send:(channel,data)=>deliver('staff',channel,data)}})});
    const archive=createPhotoArchive({getRoot:()=>path.join(root,'mock-D'),openPath:async()=>'',encodeJpeg:()=>{throw Error('Test expects JPEG canvas');}});
    const equipment=createEquipmentApi(manager.store,{native:true,...display,
      archivePhoto:archive.photo,archiveComparison:archive.comparison,openPhotoFolder:archive.open});
    await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
    await display.restore();
    await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('[연결됨]')`);
    pass('CUSTOMER_READY connects staff/customer through the real coordinator and mock IPC');
    await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0`);
    assert.equal(await evaluate('customer',`(()=>{const v=document.querySelector('[data-testid="customer-promo-video"]');return v.loop&&v.muted&&v.autoplay&&v.playsInline;})()`),true);
    await evaluate('customer',`(()=>{const v=document.querySelector('[data-testid="customer-promo-video"]');window.__promoNode=v;v.currentTime=v.duration-0.2;})()`);
    await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')===window.__promoNode&&window.__promoNode.currentTime<2`);
    pass('idle original 18s promo survives end on same video element with loop/muted/autoplay/playsInline');
    for(const [key,selector] of [['value','price'],['process','water'],['water','dry'],['sneakers','sneakers']]){
      customerWindow.minimized=true;customerWindow.focused=false;
      await evaluate('staff',`document.querySelector('[data-testid="button-customer-${selector}-video"]').click()`);
      await wait('customer',`document.querySelector('video[data-video="${key}"]')?.currentTime>0`);
      assert.equal(customerWindow.minimized,false);assert.equal(customerWindow.focused,true);
      assert.equal(customerWindow.top,true);assert.equal(customerWindow.fullscreen,true);
      assert.equal(await evaluate('customer',`document.querySelector('video').controls`),false);
      await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('재생 중')`);
      await evaluate('customer',`document.querySelector('video').currentTime=document.querySelector('video').duration-0.25`);
      await wait('customer',`document.querySelector('[data-testid="customer-promo-video"]')?.currentTime>0`);
      assert.equal(customerWindow.top,false);assert.equal(customerWindow.fullscreen,true);
      pass(`${key}: original 1080p MP4 first frames and seek-to-end restore the endless muted promo`);
    }
    await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').focus()`);
    for(const ch of 'rlarntn')await send('Input.insertText',{text:ch},sessions.staff);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="input-customer-name"]').value`),'김구수');
    pass('real browser ASCII keystrokes compose 김구수 without a Windows IME or external dependency');
    await evaluate('staff',`(() => {
      const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      for(const [id,value] of [['input-customer-name','모의현장시험'],['input-customer-phone','1234']]){
        const e=document.querySelector('[data-testid="'+id+'"]');set.call(e,value);e.dispatchEvent(new Event('input',{bubbles:true}));
      }
      document.querySelector('[data-testid="button-add-item"]').click();
    })()`);
    await wait('customer',`!!document.querySelector('[data-testid="customer-event-banner"]')`);
    const banner=await evaluate('customer',`document.querySelector('[data-testid="customer-event-banner"]').textContent`);
    for(const text of ['🎉 세탁할수록 커지는 혜택','10만 원 이상 결제 시:','10% 할인','20만 원 이상 결제 시:','15% 할인','5만 원 이상 고객 영수증 리뷰 작성 시:','5,000원 즉시 할인'])assert.ok(banner.includes(text),text);
    pass('new active intake exits promo and preserves the receipt benefit banner');
    await wait('staff',`document.querySelector('[data-testid="button-ndc-preview"]')&&!document.querySelector('[data-testid="button-ndc-preview"]').disabled`);
    await evaluate('staff',`document.querySelector('[data-testid="button-ndc-preview"]').click()`);
    for(let n=1;n<=12;n++){
      await wait('staff',`!document.querySelector('[data-testid="button-ndc-shoot"]').disabled`);
      await evaluate('staff',`document.querySelector('[data-testid="button-ndc-shoot"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('${n}컷')`);
    }
    assert.equal(manager.store.status().orderCount,0);
    const draft=await equipment.api('POST','/api/equipment/command',{action:'draft-state',orderId:capturedOrderId});
    const unit=draft.units[0];
    assert.equal(unit.photos.length,12);assert.equal(Object.values(unit.jobsByMode).length,1);
    for(const photo of unit.photos)assert.equal(manager.store.equipment.photoFile(photo.id).bytes[0],255);
    pass('real React intake saves 12 mock JPEG shots to temporary SQLite/D archive, one mock tag, no fake orders');
    await send('Page.navigate',{url:'http://localhost/equipment'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="select-customer-monitor"]')?.value==='2'`);
    await send('Page.navigate',{url:'http://localhost/'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="staff-customer-video-connection"]')?.textContent.includes('[연결됨]')`);
    await wait('staff',`document.querySelector('[data-testid="text-ndc-count"]')?.textContent.includes('12컷')`);
    assert.equal(display.displayStatus().displayId,'2');
    pass('equipment/reception navigation retains native monitor ID and live connection');
    // New field workflow uses only this test's temporary SQLite via the real renderer bridge.
    await evaluate('staff',`(async()=>{
      const r=await import('/src/order-record.ts'),g=await import('/src/garment-record.ts');
      const o=r.createConfirmedOrder({id:'UI-FIELD-QC',customerName:'검증고객',customerPhone:'6789',customerAddress:'',
        items:[{itemId:'shirt_dress',displayNameKo:'와이셔츠',quantity:2,generalPrice:5000,premiumPrice:9000,isSneaker:false}]},
        {serviceLevel:'general',pickupRequested:false,deliveryRequested:false,directPickup:true,requestedPickupDate:'',
          waiver:'not-requested',luxuryItem:false,customerRequests:'없음'});
      r.insertConfirmedOrder({...o,garments:g.createGarmentRecords(o)});
    })()`);
    await send('Page.navigate',{url:'http://localhost/?orderId=UI-FIELD-QC&inspection=1'},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="toggle-review-confirmed-0"]')?.getAttribute('aria-checked')==='true'`);
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="toggle-review-method-0-물세탁"]').getAttribute('aria-checked')`),'true');
    assert.equal(await evaluate('staff',`document.querySelector('[data-testid="toggle-review-result-0-이상 없음"]').getAttribute('aria-checked')`),'true');
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-notice-waiver"]')`);
    for(const kind of ['waiver','fee','both']){
      await evaluate('staff',`document.querySelector('[data-testid="button-notice-${kind}"]').click()`);
      await wait('staff',`document.querySelector('[data-testid="input-notice-message"]')?.value.includes('[K99 세탁의 품격 |')`);
      const text=await evaluate('staff',`document.querySelector('[data-testid="input-notice-message"]').value`);
      assert.ok(text.includes('검증고객 고객님'));assert.ok(text.includes('[와이셔츠 2점]'));
      if(kind!=='waiver')assert.ok(text.includes('00,000원'));
    }
    await evaluate('staff',`Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__copiedNotice=text;}}});document.querySelector('[data-testid="button-notice-copy"]').click()`);
    await wait('staff',`window.__copiedNotice===document.querySelector('[data-testid="input-notice-message"]').value`);
    assert.equal(await evaluate('staff',`[...document.querySelectorAll('input,textarea')].every(i=>i.lang==='ko')`),true);
    pass('inspection defaults wet/normal/confirmed, Korean input attributes and all three official messages; clipboard adapter receives exact text');
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-isd-before-after"]')`);
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-next"]').click()`);
    await wait('staff',`!!document.querySelector('[data-testid="button-isd-finish-all"]')`);
    await evaluate('staff',`document.querySelector('[data-testid^="button-isd-qc-"]').click()`);
    await wait('staff',`[...document.querySelectorAll('[data-testid^="row-isd-garment-"]')].some(e=>e.textContent.includes('검수 완료'))`);
    await evaluate('staff',`document.querySelector('[data-testid="button-isd-finish-all"]').click()`);
    await wait('staff',`document.querySelector('[data-testid="status-isd"]')?.textContent.includes('출고 대기')`);
    const qc=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC');})()`);
    assert.equal(qc.operations.stage,'세탁완료');assert.ok(qc.garments.every(g=>g.completionStatus==='complete'&&!g.completionPhoto));
    pass('individual final QC then bulk release persists without comparison photos or any completion scan');
    await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
    await wait('staff',`!!document.querySelector('[data-testid="card-ready-order-UI-FIELD-QC"]')`);
    await evaluate('staff',`(()=>{
      const el=document.querySelector('[data-testid="input-scanner-barcode"]');
      el.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,'6789');
      el.dispatchEvent(new Event('input',{bubbles:true}));
    })()`);
    await wait('staff',`document.querySelector('[data-testid="panel-selected-order"]')?.textContent.includes('검증고객')`);
    await wait('staff',`!document.querySelector('[data-testid="button-scanner-handover"]').disabled`);
    assert.equal(await evaluate('staff',`document.activeElement===document.querySelector('[data-testid="input-scanner-barcode"]')`),true);
    const notYetHanded=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC').operations.stage;})()`);
    assert.equal(notYetHanded,'세탁완료');
    await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await wait('staff',`document.querySelector('[data-testid="status-scanner-feedback"]')?.textContent.includes('인도했습니다')`);
    const handed=await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().find(o=>o.id==='UI-FIELD-QC');})()`);
    assert.equal(handed.operations.stage,'매장수령완료');
    assert.equal(handed.history.at(-1).details.method,'staff-confirmed');
    assert.ok(handed.garments.every(g=>g.handoverStatus==='complete'));
    pass('outgoing top card: pause selects without handover/focus theft; real Enter persists unscanned staff handover');
    await evaluate('staff',`(async()=>{
      const r=await import('/src/order-record.ts');
      for(const suffix of ['A','B']){
        const copy=${JSON.stringify(qc)};copy.id='UI-AMBIGUOUS-'+suffix;copy.customerName='중복시험'+suffix;copy.customerPhone='01055558888';
        copy.scanAuditEvents=[];copy.history=[];
        copy.garments=copy.garments.map((g,i)=>({...g,orderId:copy.id,garmentId:copy.id+'-G'+i,barcodeValue:copy.id+'-G'+i,
          auditEvents:[],beforePhoto:undefined,completionPhoto:undefined,photoHistory:[]}));
        r.insertConfirmedOrder(copy);
      }
    })()`);
    await send('Page.navigate',{url:'http://localhost/?scanner=1'},sessions.staff);
    await wait('staff',`document.querySelectorAll('[data-testid^="card-ready-order-UI-AMBIGUOUS-"]').length===2`);
    await evaluate('staff',`(()=>{
      const el=document.querySelector('[data-testid="input-scanner-barcode"]');el.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,'8888');
      el.dispatchEvent(new Event('input',{bubbles:true}));
    })()`);
    await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13},sessions.staff);
    await wait('staff',`!!document.querySelector('[data-testid="panel-lookup-choices"]')`);
    assert.equal(await evaluate('staff',`(async()=>{const r=await import('/src/order-record.ts');return r.readConfirmedOrders().filter(o=>o.id.startsWith('UI-AMBIGUOUS-')).every(o=>o.operations.stage==='세탁완료');})()`),true);
    await evaluate('staff',`document.querySelector('[data-testid="button-card-handover-UI-AMBIGUOUS-A"]').click()`);
    await wait('staff',`!document.querySelector('[data-testid="card-ready-order-UI-AMBIGUOUS-A"]')`);
    assert.equal(await evaluate('staff',`!!document.querySelector('[data-testid="card-ready-order-UI-AMBIGUOUS-B"]')`),true);
    pass('ambiguous phone suffix never hands over automatically; explicit card departure changes only the selected order');
    fs.mkdirSync('generated-artifacts',{recursive:true});
    // Functional evidence is saved independently of background-tab screenshot capture.
    // Visual review uses the app preview screenshot tool instead.
    fs.writeFileSync('generated-artifacts/customer-ipc-browser-result.json',JSON.stringify({
      checks,temporaryData:true,originalVideos:true,electronIpcMocked:true,physicalDisplaysMocked:true,windowsTested:false,
    },null,2));
  }finally{socket?.close();chrome.kill('SIGTERM');await delay(250);manager.close();await fsp.rm(root,{recursive:true,force:true});}
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
