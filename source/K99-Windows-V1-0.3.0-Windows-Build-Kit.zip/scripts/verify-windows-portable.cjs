'use strict';
// Inspect the actual final portable payload. Does NOT execute Windows code.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const {pe,productionEndpoint}=require('./build-windows-portable.cjs');
const root=path.resolve(__dirname,'..'),folder=path.join(root,'generated-artifacts/windows-portable/win-unpacked');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const asar=createRequire(appRequire.resolve('electron-builder'))('@electron/asar');
const archive=path.join(folder,'resources/app.asar'),files=new Set(asar.listPackage(archive).map(n=>n.replace(/^\//,'')));
const read=name=>asar.extractFile(archive,name);
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const manifest=JSON.parse(read('package.json')),report=JSON.parse(fs.readFileSync(path.join(folder,'portable-verification.json')));
const vendor=JSON.parse(fs.readFileSync(path.join(root,'generated-artifacts/windows-portable-vendor/verified-vendors.json')));
const required=['electron/main.cjs','electron/local-startup.cjs','electron/windows-compatibility.cjs','electron/preload.cjs','electron/local-photo-gateway.cjs',
  'electron/program-integrations.cjs','electron/ai-account-vault.cjs','electron/ai-session.cjs','electron/calculator-preload.cjs','electron/idle-videos.cjs','electron/storage-layout.cjs','electron/comparison-mobile-photo.cjs',
  'electron/care-label-controller.cjs','electron/automatic-tag-controller.cjs','electron/services/labelService.cjs',
  'electron/tag-template.cjs','electron/core/index.cjs','electron/core/desktop-manager.cjs',
  'electron/core/pickup-notices.cjs','electron/core/customer-notices.cjs','electron/notice-mobile.cjs','electron/notice-mobile-page.cjs','electron/services/autoMessenger.js','electron/services/package.json','electron/core/order-payment.cjs','electron/core/photo-retention.cjs','dist/desktop/index.html'];
for(const name of required)if(!files.has(name))throw Error('Missing packaged runtime: '+name);
for(const name of ['local-startup.cjs','windows-compatibility.cjs','program-integrations.cjs','ai-account-vault.cjs','ai-session.cjs','calculator-preload.cjs','idle-videos.cjs','storage-layout.cjs','comparison-mobile-photo.cjs','mobile-photo-bridge.cjs']){
  if(sha(read('electron/'+name))!==sha(fs.readFileSync(path.join(root,'artifacts/k99-windows/electron',name))))
    throw Error('Packaged program/video runtime differs from latest source: '+name);
}
for(const name of files){
  if(name.startsWith('electron/')&&name.endsWith('.cjs')){
    const text=read(name).toString();
    for(const [,dependency]of text.matchAll(/require\(['"](\.[^'"]+)['"]\)/g)){
      const relative=path.posix.normalize(path.posix.join(path.posix.dirname(name),dependency));
      if(![relative,relative+'.cjs',relative+'.js',relative+'.json',relative+'/index.cjs',relative+'/index.js'].some(n=>files.has(n)))
        throw Error('Unresolved packaged core reference: '+name+' -> '+dependency);
    }
  }
  if(/(?:^|\/)\.env(?:$|\.)/.test(name)||/\.(?:db|sqlite|sqlite3|pem|key)$/i.test(name))
    throw Error('Unexpected private/runtime data in ASAR: '+name);
}
for(const dependency of ['better-sqlite3','bwip-js','xlsx','exceljs']){
  const p=JSON.parse(read(`node_modules/${dependency}/package.json`));
  const main=path.posix.normalize(`node_modules/${dependency}/${p.main||'index.js'}`).replace(/\/\.\//g,'/');
  if(![main,main+'.js'].some(n=>files.has(n)))throw Error('Runtime package main missing: '+dependency);
}
const nativeName='node_modules/better-sqlite3/build/Release/better_sqlite3.node';
const binary=fs.readFileSync(path.join(folder,'resources/app.asar.unpacked',nativeName));
pe(binary);
if(sha(binary)!==vendor.bindingHash||!binary.includes(Buffer.from(`node_register_module_v${vendor.abi}`)))throw Error('Packaged SQLite ABI/hash mismatch');
if(sha(read(nativeName))!==vendor.bindingHash)throw Error('ASAR native redirection mismatch');
if(manifest.main!=='electron/main.cjs'||manifest.k99CareLabelProxyUrl!==report.proxy||
  productionEndpoint(report.proxy)!==report.proxy)throw Error('Packaged entry/proxy mismatch');
if(manifest.k99OfflineReception!==true||report.offlineReception!==true)
  throw Error('Offline reception marker missing from final Windows package');
for(const name of ['main.cjs','equipment-native.cjs','tag-template.cjs','local-photo-gateway.cjs','care-label-controller.cjs','automatic-tag-controller.cjs','optional-label.cjs','notice-mobile.cjs','notice-mobile-page.cjs','services/autoMessenger.js','services/package.json','services/labelService.cjs']){
  const expected=fs.readFileSync(path.join(root,'artifacts/k99-windows/electron',name),'utf8')
    .replace(/require\('@workspace\/k99-local(?:\/([^']+))?'\)/g,
      (_m,file)=>`require('./core/${file||'index.cjs'}')`);
  if(read('electron/'+name).toString()!==expected)
    throw Error('Stale packaged code: '+name);
}
const main=read('electron/main.cjs').toString(),preload=read('electron/preload.cjs').toString();
const tagModule={exports:{}};
require('node:vm').runInNewContext(read('electron/tag-template.cjs').toString(),{module:tagModule});
const sample={payload:{labelWidthMm:60,labelHeightMm:40,material_group:'폴리에스테르',
  wash_method:'물세탁',color:'블랙',payment_type:'POSTPAID'}};
if(!tagModule.exports.tagHTML(sample,Buffer.from('test')).includes('@page{size:30mm 40mm')||
   !tagModule.exports.tagTSPLFooter(sample).startsWith('SIZE 30 mm,40 mm'))
  throw Error('Final package tag width is not fixed at 30mm');
if(tagModule.exports.tagHTML(sample,Buffer.from('test')).includes('[결제]')||
   tagModule.exports.tagTSPLFooter(sample).includes('[결제]'))
  throw Error('Final tag footer must contain material and color only');
const offlineSample={payload:{...sample.payload,manualMaterial:'울/실크',manualColor:'흰색'}};
const offlineHTML=tagModule.exports.tagHTML(offlineSample,Buffer.from('test'));
if(!offlineHTML.includes('[소재] 울/실크</span>')||!offlineHTML.includes('[색상] 흰색</span>')||
    offlineHTML.includes('확인 필요'))throw Error('Offline manual selections are not wired to final tag footer');
for(const name of ['equipment.cjs','equipment-api.cjs','draft-equipment.cjs','manual-label.cjs','order-payment.cjs','unified-orders.cjs','pickup-notices.cjs','customer-notices.cjs']){
  if(!read('electron/core/'+name).equals(fs.readFileSync(path.join(root,'lib/k99-local',name))))
    throw Error('Stale packaged payment core: '+name);
}
const desktopFiles=[...files].filter(n=>n.startsWith('dist/desktop/')&&!n.endsWith('/'));
for(const text of ['접수 보조 패널','AI 라벨 분석','촬영 창 열기']){
  if(!desktopFiles.some(n=>n.endsWith('.js')&&read(n).toString().includes(text)))
    throw Error('Offline reception controls missing in compiled React bundle: '+text);
}
for(const name of desktopFiles){
  const local=path.join(root,'artifacts/k99-windows',name);
  if(fs.existsSync(local)&&fs.statSync(local).isFile()&&!read(name).equals(fs.readFileSync(local)))
    throw Error('Stale packaged React bundle: '+name);
}
const scripts=desktopFiles.filter(n=>n.endsWith('.js')).map(n=>read(n).toString()).join('\n');
for(const text of ['선불 완료','후불 · 결제필요','수령 시 결제 부탁드립니다.','payment_type','POSTPAID']){
  if(!scripts.includes(text))throw Error('Missing payment UI/message in compiled bundle: '+text);
}
if(!main.includes("'K99WindowsV1'")||!main.includes('localPhotos.response(request)')||!preload.includes('photoSource:'))
  throw Error('Native photo or existing userData configuration missing');
const videos=path.join(folder,'resources/videos'),media=JSON.parse(fs.readFileSync(path.join(videos,'media-manifest.json')));
for(const name of ['promo.mp4','process.mp4','value.mp4','water.mp4','sneakers.mp4']){
  const bytes=fs.readFileSync(path.join(videos,name)),expected=media.files[name];
  if(bytes.toString('ascii',4,8)!=='ftyp'||!expected||expected.bytes!==bytes.length||expected.sha256!==sha(bytes))
    throw Error('Video integrity failure: '+name);
}
let peCount=0;
function inspect(dir){
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const f=path.join(dir,entry.name);
    if(entry.isDirectory())inspect(f);
    else if(/\.(?:exe|dll|node)$/i.test(entry.name)){pe(fs.readFileSync(f));peCount++;}
  }
}
inspect(folder);
const result={packagedCoreReferences:true,latestPhotoAndCareLabelCode:true,runtimeDependencies:true,
  fixed30mmTagWidth:true,offlineReception:true,manualMaterialAndColor:true,
  latestTagLayoutAndPrintValidation:true,
  latestPaymentCoreAndReactBundle:true,
  existingUserDataPath:true,sqliteVendorHashAndAbi:true,originalVideosVerified:5,windowsX64Binaries:peCount,
  latestProgramLauncherRuntime:true,latestDynamicVideoRuntime:true,
  proxy:report.proxy,proxyHealthVerified:report.proxyHealthVerified,windowsExecutionVerified:false};
fs.writeFileSync(path.join(root,'generated-artifacts/windows-portable/static-verification.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(folder,'static-verification.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
