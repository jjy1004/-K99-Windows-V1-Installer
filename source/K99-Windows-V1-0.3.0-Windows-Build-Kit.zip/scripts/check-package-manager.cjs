'use strict';
if (!(process.env.npm_config_user_agent || '').startsWith('pnpm/')) {
  process.stderr.write('Use pnpm for this workspace.\n');
  process.exit(1);
}
