"""Create the upload-as-is source ZIP, keeping the established repository path."""
from pathlib import Path
import base64
import hashlib
import html
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = json.loads((ROOT / "artifacts/k99-windows/package.json").read_text())["version"]
if VERSION != "2.4.6":
    raise RuntimeError("이 배포 키트는 2.4.6 소스만 허용합니다.")
OUT = ROOT / "generated-artifacts/build-kits" / VERSION
OUT.mkdir(parents=True, exist_ok=True)
NAME = "K99-Windows-V1-0.3.0-Windows-Build-Kit.zip"
INSTALLER = "K99-Smart-Laundry-V2-Setup.2.exe"
WORKFLOW = ROOT / ".github/workflows/windows-installer.yml"
SKIP = {"node_modules", ".git", ".local", "dist", "build", "generated-artifacts",
        "local-data", "__pycache__", ".cache", "backups", "photos"}
SUFFIXES = {".db", ".sqlite", ".sqlite3", ".tsbuildinfo", ".k99backup",
            ".pem", ".key", ".xlsx", ".xls", ".csv", ".mp4", ".webm", ".exe"}


def sha(file):
    result = hashlib.sha256()
    with file.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(part)
    return result.hexdigest()


media = json.loads((ROOT / "generated-artifacts/customer-videos.upload.json").read_text())
joined = hashlib.sha256()
total = 0
for index, part in enumerate(media["parts"], 1):
    if part["name"] != f"customer-videos.zip.part{index:03}":
        raise RuntimeError("영상 분할 파일 순서 오류")
    file = ROOT / "generated-artifacts" / part["name"]
    if file.stat().st_size != part["bytes"] or sha(file) != part["sha256"]:
        raise RuntimeError("기존 영상 분할 파일 무결성 오류")
    with file.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            joined.update(block)
            total += len(block)
if total != media["bytes"] or joined.hexdigest() != media["sha256"]:
    raise RuntimeError("영상 분할 합산 크기/해시 불일치")

entries = {}


def add(file):
    rel = file.relative_to(ROOT)
    if (file.is_symlink() or set(rel.parts) & SKIP or file.suffix.lower() in SUFFIXES
            or file.name.startswith(".env") or re.search(r"\.(db|sqlite3?)-(wal|shm)$", file.name)
            or file.name in {"media-manifest.json", "placeholder-manifest.json"}):
        return
    entries[rel.as_posix()] = file.read_bytes()


for name in ("package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml", "tsconfig.base.json",
             ".github/workflows/windows-installer.yml"):
    add(ROOT / name)
for folder in ("artifacts/k99-windows", "lib/k99-local", "lib/api-client-react",
               "lib/api-zod", "lib/api-spec", "scripts", "docs"):
    for file in sorted((ROOT / folder).rglob("*")):
        if file.is_file():
            add(file)
config = json.loads((ROOT / "tsconfig.json").read_text())
config["references"] = [item for item in config["references"] if item["path"] != "./lib/db"]
entries["tsconfig.json"] = json.dumps(config, indent=2).encode()
entries[".gitignore"] = b"node_modules/\ngenerated-artifacts/\nlocal-data/\n.env*\n*.sqlite*\n*.db*\n"
readme = f"""# K99 Laundry V2 {VERSION} GitHub 빌드 키트

이 ZIP은 압축을 풀지 말고 저장소의 source/{NAME}에 업로드합니다.
기존 경로와 호환되도록 파일명에만 0.3.0을 유지했습니다. 실제 앱 버전은 {VERSION}입니다.
source/{NAME}.sha256 파일도 반드시 함께 교체합니다.
저장소 루트의 .github/workflows/windows-installer.yml도 함께 교체해야
요청한 {INSTALLER}가 Actions 결과물에 포함됩니다.

ZIP 내부의 워크플로는 소스 보관본이며 GitHub가 자동으로 적용하지 않습니다.
함께 제공한 업로드 도우미 HTML에서 해시·워크플로·업로드 정보 파일을
압축 해제 없이 각각 내려받을 수 있습니다.

기존 source/customer-videos.upload.json 및 customer-videos.zip.part001~{len(media["parts"]):03}
영상 분할 파일을 유지합니다. 위 파일이 없다면 영상 복원 단계에서 빌드가 중단됩니다.
영상 분할 파일이 저장소에 있는지는 이 작업에서 원격으로 확인하지 못했습니다.
4종 원본 안내 영상은 기존 분할 파일을 사용하고, 별도 promo.mp4가 없으면
현재의 기존 스테이징 정책대로 value.mp4를 대기 영상으로 복사합니다.

Actions → Build K99 Windows Installer → Run workflow에서
사용량·저장 공간을 확인하고 usage_approved 항목을 선택하여 실행합니다.
성공한 실행의 Artifacts에서 K99-Laundry-V2-{VERSION}-Windows-x64를 내려받습니다.
안에는 {INSTALLER}, SHA-256, installer-release.json 등이 들어갑니다.
GitHub의 기존 Artifact 저장 한도가 초과되어 있으면 업로드가 실패할 수 있습니다.

운영 DB·고객 장부·사진·설정 파일·Secrets·node_modules는 포함하지 않습니다.
이것은 빌드 소스이며 설치 EXE가 아닙니다.
이 키트로 실제 GitHub Windows 빌드를 실행하거나 실장비를 검사하지 않았습니다.
"""
entries["README-WINDOWS.md"] = readme.encode()
entries["build-kit.json"] = json.dumps({
    "version": VERSION, "installer": INSTALLER, "windowsBuildVerified": False,
    "physicalCameraVerified": False, "media": media,
}, ensure_ascii=False, indent=2).encode()
target = OUT / NAME
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, content in sorted(entries.items()):
        # Fixed archive timestamps make identical source inputs reproducible.
        info = zipfile.ZipInfo(name, (2026, 11, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, content)
if target.stat().st_size >= 25 * 1024 * 1024:
    raise RuntimeError("GitHub 브라우저 업로드 한도를 넘었습니다.")
checksum = sha(target)
sidecar = OUT / (NAME + ".sha256")
sidecar.write_text(f"{checksum}  {NAME}\n")
upload = {
    "version": VERSION, "source": {"name": NAME, "bytes": target.stat().st_size, "sha256": checksum},
    "installer": INSTALLER, "windowsBuildVerified": False, "physicalCameraVerified": False,
    "workflowSHA256": sha(WORKFLOW), "mediaSHA256": media["sha256"],
}
(OUT / "upload.json").write_text(json.dumps(upload, ensure_ascii=False, indent=2))
(OUT / "windows-installer.yml").write_bytes(WORKFLOW.read_bytes())
(OUT / "customer-videos.upload.json").write_text(json.dumps(media, indent=2))
(OUT / "업로드-안내.md").write_text(readme)

buttons = []
for filename, label in (
    (NAME + ".sha256", "필수 ② 해시 파일 저장"),
    ("windows-installer.yml", "필수 ③ 워크플로 파일 저장"),
    ("upload.json", "업로드 정보 파일 저장"),
    ("customer-videos.upload.json", "기존 영상 목록 확인용 파일 저장"),
):
    content = base64.b64encode((OUT / filename).read_bytes()).decode()
    buttons.append(f'<a download="{html.escape(filename)}" href="data:application/octet-stream;base64,{content}">{label}</a>')
page = f"""<!doctype html><html lang="ko"><meta charset="utf-8">
<title>K99 2.4.6 GitHub 업로드 안내</title>
<style>body{{max-width:1050px;margin:35px auto;padding:20px;font:20px/1.7 sans-serif;color:#102a35}}
h1{{font-size:30px}}a{{display:block;padding:16px;margin:12px 0;background:#17343d;color:white;border-radius:9px;text-decoration:none}}
pre{{white-space:pre-wrap;font:18px/1.7 sans-serif;padding:20px;background:#f2f5f7}}
code{{overflow-wrap:anywhere}}.warn{{padding:20px;background:#fff3d5;border:2px solid #b65c00}}
</style><h1>K99 Laundry V2 2.4.6 — 압축 해제 없이 업로드</h1>
<p>① 대화의 다운로드 카드에서 <b>{NAME}</b>을 먼저 저장하세요.</p>
{''.join(buttons[:2])}
<h2>GitHub에서 교체할 위치</h2>
<ol><li>저장소 <b>source</b> 폴더에서 ZIP과 SHA-256 파일을 함께 업로드하고 변경 사항을 저장합니다.</li>
<li>저장소 <b>.github/workflows</b> 폴더에서 위의 <b>windows-installer.yml</b>을 업로드하여 기존 파일을 교체하고 저장합니다.</li>
<li>기존 영상 분할 파일 7개와 <b>customer-videos.upload.json</b>은 삭제하지 않습니다.</li>
<li><b>Actions → Build K99 Windows Installer → Run workflow</b>에서 실행합니다.</li>
<li>성공한 실행 아래 <b>Artifacts → K99-Laundry-V2-2.4.6-Windows-x64</b>에서
<b>{INSTALLER}</b>가 포함된 결과물을 받습니다.</li></ol>
<p class="warn">ZIP만 업로드해도 ZIP 안의 워크플로가 적용되지는 않습니다.
② 해시와 ③ 워크플로도 반드시 교체해야 합니다. 이 안내에서는 파일 저장만 하며 GitHub에 자동 업로드하거나 비용을 발생시키지 않습니다.</p>
<p>소스 ZIP SHA-256: <code>{checksum}</code></p>
<h2>추가 정보</h2>{''.join(buttons[2:])}<pre>{html.escape(readme)}</pre></html>"""
(OUT / "GitHub-업로드-도우미.html").write_text(page)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert json.loads(archive.read("artifacts/k99-windows/package.json"))["version"] == VERSION
    assert archive.read(".github/workflows/windows-installer.yml") == WORKFLOW.read_bytes()
    for required in ("tsconfig.base.json", "pnpm-lock.yaml", "scripts/verify-packaged-native.cjs",
                     "artifacts/k99-windows/src/NativeDraftCamera.tsx",
                     "artifacts/k99-windows/src/CameraColorSliders.tsx",
                     "scripts/verify-camera-stream-browser.cjs"):
        assert archive.read(required) == (ROOT / required).read_bytes()
print(json.dumps({**upload, "entries": len(entries), "path": str(target.relative_to(ROOT))},
                 ensure_ascii=False, indent=2))
