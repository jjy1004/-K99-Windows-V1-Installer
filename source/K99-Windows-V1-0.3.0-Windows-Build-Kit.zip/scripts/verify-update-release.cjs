'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');

// Run BEFORE publishing the draft. Reject metadata pointing at a different
// installer, stale version, missing blockmap or a changed installer payload.
function verifyUpdateRelease(folder,{version,parse}) {
  const info=parse(fs.readFileSync(path.join(folder,'latest.yml'),'utf8'));
  const name='K99-Smart-Laundry-V2-Setup.exe';
  if(info.version!==version)throw Error('자동 업데이트 버전이 소스와 다릅니다.');
  if(info.path!==name||info.files?.length!==1||info.files[0].url!==name)
    throw Error('자동 업데이트 설치 파일 경로가 올바르지 않습니다.');
  const item=info.files[0],file=path.join(folder,name),stat=fs.statSync(file);
  const hash=crypto.createHash('sha512').update(fs.readFileSync(file)).digest('base64');
  if(item.size!==stat.size||item.sha512!==hash||info.sha512!==hash)
    throw Error('자동 업데이트 설치 파일 크기·SHA-512 불일치');
  const blockmap=path.join(folder,name+'.blockmap');
  if(!fs.statSync(blockmap).isFile()||fs.statSync(blockmap).size<1)
    throw Error('자동 업데이트 blockmap 파일 누락');
  return {version,filename:name,bytes:stat.size,sha512:hash,
    assets:[name,'latest.yml',name+'.blockmap']};
}
if(require.main===module) {
  const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
  const version=JSON.parse(fs.readFileSync(path.join(app,'package.json'))).version;
  if(!/^\d+\.\d+\.\d+$/.test(version))throw Error('자동 업데이트는 정식 숫자 버전만 게시합니다.');
  console.log(JSON.stringify(verifyUpdateRelease(path.join(root,'generated-artifacts/windows-installer'),
    {version,parse:require(path.join(app,'node_modules/yaml')).parse}),null,2));
}
module.exports={verifyUpdateRelease};
