'use strict';
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const target=path.join(root,'generated-artifacts/windows-app');
function stage() {
  const videos=require('./verify-desktop-media.cjs').mediaFiles();
  if(!fs.existsSync(path.join(app,'dist/desktop/index.html')))throw Error('먼저 desktop:build를 실행하세요.');
  fs.mkdirSync(target,{recursive:true});
  // Only the disposable staging folder is cleared. User data is never here.
  for(const name of ['electron','dist','videos'])fs.rmSync(path.join(target,name),{recursive:true,force:true});
  fs.mkdirSync(path.join(target,'videos'),{recursive:true});
  for(const [name,file] of Object.entries(videos))fs.copyFileSync(file,path.join(target,'videos',name));
  const customPromo=path.join(app,'media/videos/promo.mp4');
  if(fs.existsSync(customPromo))require('./verify-desktop-media.cjs').validateLocalVideo(customPromo);
  fs.copyFileSync(fs.existsSync(customPromo)?customPromo:videos['value.mp4'],path.join(target,'videos/promo.mp4'));
  fs.writeFileSync(path.join(target,'videos/media-manifest.json'),
    JSON.stringify(require('./verify-desktop-media.cjs').mediaManifest({
      ...videos,'promo.mp4':path.join(target,'videos/promo.mp4'),
    }),null,2));
  fs.mkdirSync(path.join(target,'electron/core'),{recursive:true});
  fs.mkdirSync(path.join(target,'electron/assets'),{recursive:true});
  fs.copyFileSync(path.join(app,'installer/k99-reception.ico'),path.join(target,'electron/assets/k99-reception.ico'));
  for(const name of ['main.cjs','preload.cjs','equipment-native.cjs','customer-display.cjs','customer-video.cjs','photo-archive.cjs','customer-photo-library.cjs','foot-switch.cjs',
    'mobile-photo-controller.cjs','mobile-photo-bridge.cjs','mobile-upload-page.cjs','customer-directory-export.cjs','care-label-controller.cjs','automatic-tag-controller.cjs','tag-template.cjs','local-photo-gateway.cjs']) {
    let text=fs.readFileSync(path.join(app,'electron',name),'utf8');
    text=text.replace(/require\('@workspace\/k99-local(?:\/([^']+))?'\)/g,
      (_m,file)=>`require('./core/${file||'index.cjs'}')`);
    if(text.includes("require('@workspace/"))throw Error('런타임 workspace 참조가 남아 있습니다.');
    fs.writeFileSync(path.join(target,'electron',name),text);
  }
  fs.cpSync(path.join(app,'electron/services'),path.join(target,'electron/services'),{recursive:true});
  for(const name of ['index.cjs','customer-directory.cjs','native-ledger-file.cjs','unified-orders.cjs','ledger-workbook.cjs','ledger-storage.cjs','equipment.cjs','equipment-api.cjs','draft-equipment.cjs','desktop-manager.cjs','backup-bundle.cjs','pickup-notices.cjs','pickup-templates.json','catalog.json'])
    fs.copyFileSync(path.join(root,'lib/k99-local',name),path.join(target,'electron/core',name));
  fs.cpSync(path.join(app,'dist/desktop'),path.join(target,'dist/desktop'),{recursive:true});
  const version=JSON.parse(fs.readFileSync(path.join(app,'package.json'))).version;
  const packageVersion=(folder,name)=>JSON.parse(fs.readFileSync(path.join(folder,'node_modules',name,'package.json'))).version;
  const pkg={name:'k99-windows-v1',version,description:'K99 Windows 11 independent laundry desk — trial',
    k99CareLabelProxyUrl:JSON.parse(fs.readFileSync(path.join(app,'package.json'))).k99CareLabelProxyUrl,
    author:'K99',private:true,main:'electron/main.cjs',
    dependencies:{'xlsx':JSON.parse(fs.readFileSync(path.join(root,'lib/k99-local/package.json'))).dependencies.xlsx,
      'exceljs':packageVersion(path.join(root,'lib/k99-local'),'exceljs'),
      'better-sqlite3':packageVersion(path.join(root,'lib/k99-local'),'better-sqlite3'),
      'bwip-js':packageVersion(app,'bwip-js'),'@google/genai':packageVersion(app,'@google/genai')},
    devDependencies:{electron:packageVersion(app,'electron')}};
  fs.writeFileSync(path.join(target,'package.json'),JSON.stringify(pkg,null,2));
  const YAML=require(path.join(app,'node_modules/yaml'));
  const lock=YAML.parse(fs.readFileSync(path.join(root,'pnpm-lock.yaml'),'utf8'));
  pkg.pnpm={overrides:lock.overrides||{}};
  fs.writeFileSync(path.join(target,'package.json'),JSON.stringify(pkg,null,2));
  const source=lock.importers['artifacts/k99-windows'],core=lock.importers['lib/k99-local'];
  lock.importers={'.':{dependencies:{
    'xlsx':{...core.dependencies.xlsx,specifier:pkg.dependencies.xlsx},
    'exceljs':{...core.dependencies.exceljs,specifier:pkg.dependencies.exceljs},
    'better-sqlite3':{...core.dependencies['better-sqlite3'],specifier:pkg.dependencies['better-sqlite3']},
    'bwip-js':{...source.dependencies['bwip-js'],specifier:pkg.dependencies['bwip-js']},
    '@google/genai':{...source.dependencies['@google/genai'],specifier:pkg.dependencies['@google/genai']},
  },devDependencies:{electron:{...source.devDependencies.electron,specifier:pkg.devDependencies.electron}}}};
  // Every staged specifier is concrete; monorepo catalogs are not available in
  // this deliberately isolated runtime package.
  delete lock.catalogs;
  fs.writeFileSync(path.join(target,'.npmrc'),Object.entries(lock.settings||{})
    .map(([name,value])=>`${name.replace(/[A-Z]/g,c=>'-'+c.toLowerCase())}=${value}`).join('\n')+
    '\nnode-linker=hoisted\nminimum-release-age=1440\n');
  // Preserve the exact transitive resolutions, not just top-level versions.
  fs.writeFileSync(path.join(target,'pnpm-lock.yaml'),YAML.stringify(lock));
  return target;
}
if(require.main===module)console.log(stage());
module.exports={stage};
