'use strict';
const path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
// Native SQLite must be compiled for the selected Windows/Electron ABI.
// Do not accidentally package the Linux .node binary as a "Windows success".
if(process.platform!=='win32'||process.arch!=='x64') {
  console.error('Windows 11 x64 빌드 PC가 필요합니다. Linux 바이너리를 포함한 EXE를 생성하지 않습니다. docs/windows-stage3.md를 확인하세요.');
  process.exit(2);
}
function run(args,cwd=root) {
  const cli=process.env.npm_execpath;
  if(!cli||!fs.existsSync(cli))throw Error('pnpm --filter @workspace/k99-windows run desktop:dist 로 실행하세요.');
  const javascript=/\.c?js$/i.test(cli);
  const r=spawnSync(javascript?process.execPath:cli,javascript?[cli,...args]:args,{cwd,stdio:'inherit',shell:false});
  if(r.error)throw r.error;if(r.status!==0)process.exit(r.status||1);
}
run(['--filter','@workspace/k99-windows','run','desktop:build']);
const target=require('./stage-windows-app.cjs').stage();
run(['--dir',target,'--ignore-workspace','install','--prod','--ignore-scripts','--frozen-lockfile','--config.node-linker=hoisted']);
const config=path.join(root,'artifacts/k99-windows/electron-builder.cjs');
run(['--filter','@workspace/k99-windows','exec','electron-builder',
  '--projectDir',target,'--config',config,'--win','nsis','--x64']);
const output=path.join(root,'generated-artifacts/windows-installer');
for(const file of fs.readdirSync(output).filter(n=>n.endsWith('.exe'))) {
  const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(output,file))).digest('hex');
  fs.writeFileSync(path.join(output,file+'.sha256'),`${hash}  ${file}\n`);
}
console.log('설치본 위치: generated-artifacts/windows-installer (실제 Windows 실행·장비 검증은 별도)');
