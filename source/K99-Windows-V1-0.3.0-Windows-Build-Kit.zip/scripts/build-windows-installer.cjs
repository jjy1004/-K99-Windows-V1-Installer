'use strict';
const path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto');
const {createRequire}=require('node:module');
const {runInstallerCommand}=require('./run-installer-command.cjs');
const root=path.resolve(__dirname,'..');
const output=path.join(root,'generated-artifacts/windows-installer');
// Native SQLite must be compiled for the selected Windows/Electron ABI.
// Do not accidentally package the Linux .node binary as a "Windows success".
if(process.platform!=='win32'||process.arch!=='x64') {
  console.error('Windows 11 x64 빌드 PC가 필요합니다. Linux 바이너리를 포함한 EXE를 생성하지 않습니다. docs/windows-stage3.md를 확인하세요.');
  process.exit(2);
}
fs.mkdirSync(output,{recursive:true});
const stageLog=path.join(output,'packaging-stages.log');
const consoleLog=path.join(output,'packaging-console.log');
fs.writeFileSync(stageLog,'K99 installer build stages (no customer data)\n');
fs.writeFileSync(consoleLog,'K99 compiler/builder output (no customer data)\n');
async function run(label,args,cwd=root,commandOverride) {
  fs.appendFileSync(stageLog,`START ${label}\n`);
  const cli=process.env.npm_execpath;
  if(!cli||!fs.existsSync(cli))throw Error('pnpm --filter @workspace/k99-windows run desktop:dist 로 실행하세요.');
  const javascript=/\.c?js$/i.test(cli);
  try {
    await runInstallerCommand({label,cwd,logPath:consoleLog,
      command:commandOverride|| (javascript?process.execPath:cli),
      args:commandOverride?args:javascript?[cli,...args]:args});
  } catch(error) {
    fs.appendFileSync(stageLog,`FAIL ${label}: ${error.message}\n`);
    throw error;
  }
  fs.appendFileSync(stageLog,`PASS ${label}\n`);
}
async function main() {
// Also protect manual Windows builds from missing composite declarations.
require('./build-desktop-declarations.cjs').runCli();
if(process.exitCode)throw Error('Internal declaration build failed before packaging.');
require('./verify-desktop-media.cjs').mediaFiles();
await run('React TypeScript check',['--filter','@workspace/k99-windows','run','typecheck']);
await run('React desktop bundle',['--filter','@workspace/k99-windows','run','desktop:build']);
const target=require('./stage-windows-app.cjs').stage();
await run('Isolated runtime dependencies',['--dir',target,'--ignore-workspace','install','--prod','--ignore-scripts','--frozen-lockfile','--config.node-linker=hoisted']);
const config=path.join(root,'artifacts/k99-windows/electron-builder.cjs');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const builderCli=path.join(path.dirname(appRequire.resolve('electron-builder/package.json')),'cli.js');
// npmRebuild:true + buildDependenciesFromSource:true in the builder config
// compile better-sqlite3 for the staged exact Electron version, not host Node.
// Call the resolved builder directly so its error is not only a pnpm wrapper.
await run('Windows x64 Electron native rebuild, packaging and NSIS installer',[builderCli,
  '--projectDir',target,'--config',config,'--win','nsis','--x64','--publish','never'],root,process.execPath);
for(const file of fs.readdirSync(output).filter(n=>n.endsWith('.exe'))) {
  const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(output,file))).digest('hex');
  fs.writeFileSync(path.join(output,file+'.sha256'),`${hash}  ${file}\n`);
}
console.log('설치본 위치: generated-artifacts/windows-installer (실제 Windows 실행·장비 검증은 별도)');
}
main().catch(error=>{
  console.error(`::error title=K99 packaging failed::${error.message}`);
  process.exitCode=error.exitCode||1;
});
