'use strict';
const fs=require('node:fs'),path=require('node:path');
const {VIDEO_FILES}=require('../artifacts/k99-windows/electron/customer-video.cjs');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
function validateLocalVideo(file,entry){
  const fd=fs.openSync(file,'r'),header=Buffer.alloc(12);
  try{fs.readSync(fd,header,0,12,0);}finally{fs.closeSync(fd);}
  const bytes=fs.statSync(file).size;
  if(bytes<12||header.toString('ascii',4,8)!=='ftyp')throw Error(`MP4 컨테이너 헤더가 올바르지 않습니다: ${file}`);
  const sha256=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  if(!entry||entry.bytes!==bytes||entry.sha256!==sha256)
    console.warn(`LOCAL MEDIA REPLACEMENT: ${path.basename(file)}: 이전 manifest와 다르지만 로컬 MP4 헤더가 유효합니다. 현재 해시를 기록합니다.`);
  return {bytes,sha256};
}
function mediaFiles() {
  const files={},missing=[];
  const manifest=readMediaManifest();
  for(const [key,name] of Object.entries(VIDEO_FILES)){
    const file=[path.join(app,'media/videos',name),path.join(app,'public/media/web',`${key}-v1.mp4`),
      path.join(root,'generated-artifacts/customer-videos',name)]
      .find(p=>fs.existsSync(p));
    if(!file){missing.push(`artifacts/k99-windows/media/videos/${name}`);continue;}
    validateLocalVideo(file,manifest.files?.[name]);
    files[name]=file;
  }
  if(missing.length)throw Error('고객 안내 영상이 누락되었습니다. 가짜 영상이나 원격 주소로 대체하지 않습니다.\n'+missing.join('\n'));
  return files;
}
if(require.main===module){
  try{for(const [name,file] of Object.entries(mediaFiles())){
    console.log(`ORIGINAL VIDEO VERIFIED ${name} (${fs.statSync(file).size} bytes)`);
  }}
  catch(error){console.error(error.message);process.exitCode=1;}
}
function readMediaManifest(){
  const file=[path.join(app,'media/videos/media-manifest.json'),path.join(root,'generated-artifacts/customer-videos/media-manifest.json')]
    .find(p=>fs.existsSync(p));
  if(!file)return {};
  try{return JSON.parse(fs.readFileSync(file,'utf8'));}
  catch{console.warn('이전 media-manifest.json이 올바르지 않습니다. 로컬 MP4를 검사하여 다시 생성합니다.');return {};}
}
function mediaManifest(files=mediaFiles()){
  return {...readMediaManifest(),files:Object.fromEntries(Object.entries(files).map(([name,file])=>[name,{
    bytes:fs.statSync(file).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),
  }]))};
}
module.exports={mediaFiles,mediaManifest,validateLocalVideo};
