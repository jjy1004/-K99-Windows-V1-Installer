'use strict';
const fs=require('node:fs'),path=require('node:path');
const {VIDEO_FILES}=require('../artifacts/k99-windows/electron/customer-video.cjs');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
function mediaFiles() {
  const files={},missing=[];
  for(const [key,name] of Object.entries(VIDEO_FILES)){
    const file=[path.join(app,'media/videos',name),path.join(app,'public/media/web',`${key}-v1.mp4`),
      path.join(root,'generated-artifacts/customer-videos',name)]
      .find(p=>fs.existsSync(p));
    if(!file){missing.push(`artifacts/k99-windows/media/videos/${name}`);continue;}
    const fd=fs.openSync(file,'r'),header=Buffer.alloc(12);
    try{fs.readSync(fd,header,0,12,0);}finally{fs.closeSync(fd);}
    if(fs.statSync(file).size<12||header.toString('ascii',4,8)!=='ftyp')throw Error(`MP4 컨테이너 헤더가 올바르지 않습니다: ${file}`);
    const manifest=mediaManifest(),entry=manifest.files?.[name];
    if(!entry||entry.bytes!==fs.statSync(file).size||
      crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==entry.sha256)
      throw Error(`정식 영상 SHA-256/크기 검증 실패: ${name}. media-manifest.json을 확인하세요.`);
    files[name]=file;
  }
  if(missing.length)throw Error('고객 안내 영상이 누락되었습니다. 가짜 영상이나 원격 주소로 대체하지 않습니다.\n'+missing.join('\n'));
  return files;
}
if(require.main===module){
  try{for(const [name,file] of Object.entries(mediaFiles())){
    console.log(`ORIGINAL VIDEO VERIFIED ${name} (${fs.statSync(file).size} bytes)`);
  }}
  catch(error){console.error(error.message);process.exitCode=1;}
}
function mediaManifest(){
  const file=[path.join(app,'media/videos/media-manifest.json'),path.join(root,'generated-artifacts/customer-videos/media-manifest.json')]
    .find(p=>fs.existsSync(p));
  if(!file)throw Error('정식 영상 media-manifest.json이 없습니다. 임시 영상으로 대체하지 않습니다.');
  return JSON.parse(fs.readFileSync(file,'utf8'));
}
module.exports={mediaFiles,mediaManifest};
