'use strict';
// Operator-authorized one-time seed of THIS project's independent development
// SQLite only. No arbitrary DB option, URL, credential, network, or boot import.
const fs=require('node:fs'),path=require('node:path');
const {createStore}=require('../lib/k99-local/index.cjs');
async function main(){
  const args=process.argv.slice(2),i=args.indexOf('--file');
  if(!args.includes('--confirm-isolated-import')||i<0||!args[i+1])
    throw Error('사용자 승인 후 --file <xlsx> --confirm-isolated-import가 필요합니다.');
  const file=path.resolve(args[i+1]),stat=fs.lstatSync(file);
  if(!stat.isFile()||stat.isSymbolicLink()||stat.size>8*1024*1024)throw Error('일반 XLSX 파일 8MB 이하가 필요합니다.');
  const root=path.resolve(__dirname,'../local-data');
  if(fs.existsSync(root)&&fs.lstatSync(root).isSymbolicLink())throw Error('local-data 심볼릭 링크는 허용하지 않습니다.');
  const database=path.join(root,'preview.sqlite');
  if(fs.existsSync(database)&&fs.lstatSync(database).isSymbolicLink())throw Error('DB 심볼릭 링크는 허용하지 않습니다.');
  const store=createStore(database);
  try{
    const result=await store.importCustomerFile({fileName:path.basename(file),data:fs.readFileSync(file).toString('base64')});
    console.log(JSON.stringify({target:'독립 개발본 local-data/preview.sqlite',customers:result.customers,
      histories:result.histories,duplicates:result.duplicates,summary:result.summary,backupCreated:fs.existsSync(result.backup)},null,2));
  }finally{store.close();}
}
if(require.main===module)main().catch(error=>{console.error(error.message);process.exitCode=1;});
