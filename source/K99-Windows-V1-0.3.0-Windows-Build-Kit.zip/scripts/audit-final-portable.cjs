'use strict';
// Audits ZIP bytes and its actual compiled renderer. No production connection.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawnSync,spawn}=require('node:child_process'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'..');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const asar=createRequire(appRequire.resolve('electron-builder'))('@electron/asar');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
async function main(){
  const version=JSON.parse(fs.readFileSync(path.join(root,'artifacts/k99-windows/package.json'))).version;
  const zip=path.join(root,`generated-artifacts/K99-Laundry-V2-${version}-win-unpacked.zip`);
  const expected=JSON.parse(fs.readFileSync(path.join(root,'generated-artifacts/windows-portable/verification.json')));
  if(sha(zip)!==expected.sha256||fs.statSync(zip).size!==expected.bytes)throw Error('ZIP hash/size mismatch');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'k99-final-zip-audit-'));
  const report={zip:path.basename(zip),bytes:expected.bytes,sha256:expected.sha256,
    source:'Final downloadable ZIP, not development Vite renderer',zipCrcVerified:false,
    packagedFilesVerified:false,compiledRendererVerified:false,windowsExecutionVerified:false,
    physicalDevicesVerified:false,externalCalculatorVerified:false,runs:[]};
  const reportPath=path.join(root,`generated-artifacts/K99-Laundry-V2-${version}-final-audit.json`);
  if(fs.existsSync(reportPath)){
    const prior=JSON.parse(fs.readFileSync(reportPath));
    if(prior.sha256===report.sha256)report.runs=prior.runs.filter(run=>run.passed);
  }
  try{
    const extracted=spawnSync('python',['-c',`import zipfile,sys,pathlib
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 for name in z.namelist():
  p=pathlib.PurePosixPath(name)
  assert not p.is_absolute() and '..' not in p.parts
 z.extractall(sys.argv[2])
`,zip,temp],{encoding:'utf8',timeout:90000});
    if(extracted.status!==0)throw Error(extracted.stderr||'ZIP extraction failed');
    report.zipCrcVerified=true;
    const folder=path.join(temp,'win-unpacked'),resources=path.join(folder,'resources');
    for(const name of ['K99-Laundry-V2.exe','외부프로그램-연동안내.md',
      'resources/app.asar','resources/app.asar.unpacked/node_modules/better-sqlite3/build/Release/better_sqlite3.node'])
      if(!fs.statSync(path.join(folder,name)).isFile())throw Error('Missing ZIP file: '+name);
    if(sha(path.join(resources,'app.asar'))!==expected.appAsarSHA256||
      sha(path.join(folder,'K99-Laundry-V2.exe'))!==expected.exeSHA256||
      sha(path.join(resources,'app.asar.unpacked/node_modules/better-sqlite3/build/Release/better_sqlite3.node'))!==expected.nativeBindingSHA256)
      throw Error('ZIP runtime binary differs from build evidence');
    const archive=path.join(resources,'app.asar');
    const files=asar.listPackage(archive).map(name=>name.replace(/^\//,''));
    for(const name of ['electron/idle-videos.cjs','electron/program-integrations.cjs','electron/calculator-preload.cjs',
      'electron/ai-account-vault.cjs','electron/ai-session.cjs',
      'electron/main.cjs','electron/preload.cjs','electron/core/index.cjs'])
      if(!files.includes(name))throw Error('Missing ASAR runtime: '+name);
    const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
    let coreCount=0,rendererCount=0,electronCount=0;
    for(const name of files){
      if(name.startsWith('electron/')&&!name.startsWith('electron/core/')&&name.endsWith('.cjs')){
        const source=path.join(root,'artifacts/k99-windows',name);
        const normalized=fs.readFileSync(source,'utf8').replace(/require\('@workspace\/k99-local(?:\/([^']+))?'\)/g,
          (_m,file)=>`require('./core/${file||'index.cjs'}')`);
        if(digest(Buffer.from(normalized))!==digest(asar.extractFile(archive,name)))
          throw Error('Electron source mismatch: '+name);
        electronCount++;
      }
      if(name.startsWith('electron/core/')&&/\.(cjs|json)$/.test(name)){
        const source=path.join(root,'lib/k99-local',path.basename(name));
        if(!fs.existsSync(source)||sha(source)!==digest(asar.extractFile(archive,name)))throw Error('Core source mismatch: '+name);
        coreCount++;
      }
      if(name.startsWith('dist/desktop/')){
        const relative=name.slice('dist/desktop/'.length);
        const source=path.join(root,'artifacts/k99-windows/dist/desktop',relative);
        if(!fs.existsSync(source)||!fs.statSync(source).isFile())continue;
        const content=asar.extractFile(archive,name);
        if(sha(source)!==digest(content))throw Error('Compiled renderer mismatch: '+name);
        const output=path.join(resources,'renderer',relative);
        fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,content);rendererCount++;
      }
    }
    report.packagedFilesVerified=true;report.matchingCoreFiles=coreCount;report.matchingRendererFiles=rendererCount;
    console.log('ZIP CRC, EXE/ASAR/SQLite hashes, '+coreCount+' core files, '+electronCount+' Electron files and '+rendererCount+' compiled UI files verified');
    report.currentSourceFilesVerified={core:coreCount,electron:electronCount,renderer:rendererCount};
    const modes=[['런처','--program-launchers-only'],['고객 엑셀·자동완성','--member-upload-only'],['촬영·사이드바','--reception-sidebar-only'],
      ['동적 영상','--idle-playlist-only'],['고객·통계','--simple-pipeline-only'],
      ['사진 자동 정리','--photo-retention-only'],['한글 입력·저장','--korean-ime-only'],
      ['전후 사진 송출','--comparison-gallery-only'],['접수·검수·출고',null]];
    const only=process.argv.indexOf('--only');
    const selected=modes.filter(([label,flag])=>
      (!process.argv.includes('--remaining')||!report.runs.some(run=>run.label===label&&run.passed))&&
      (only<0||flag===process.argv[only+1]||(!flag&&process.argv[only+1]==='full')));
    if(!selected.length)throw Error('Unknown audit mode');
    for(const [label,flag]of selected){
      await new Promise((resolve,reject)=>{
      const args=[path.join(__dirname,'verify-native-customer-browser.cjs'),'--packaged-root',resources,...flag?[flag]:[]];
      const logFile=path.join(root,'generated-artifacts','v'+version.replace(/\./g,'')+'-final-audit-'+(flag||'full').replace(/^--/,'')+'.log');
      const stream=fs.createWriteStream(logFile),child=spawn(process.execPath,args,{cwd:root,stdio:['ignore','pipe','pipe']});
      const timer=setTimeout(()=>child.kill('SIGTERM'),180000);let output='';
      child.stdout.on('data',b=>{stream.write(b);output+=b;});child.stderr.on('data',b=>{stream.write(b);output+=b;});
      child.on('error',reject);child.on('close',code=>{
        clearTimeout(timer);stream.end();
        const checks=output.split('\n').filter(s=>s.startsWith('PASS '));
        report.runs=report.runs.filter(run=>run.label!==label);
        report.runs.push({label,passed:code===0,checks,log:path.relative(root,logFile)});
        console.log(label+': '+(code===0?'PASS':'FAIL')+' ('+checks.length+')');
        code===0?resolve():reject(Error(label+': '+output.slice(-2500)));
      });
      });
    }
    report.compiledRendererVerified=modes.every(([label])=>report.runs.some(run=>run.label===label&&run.passed));
  }finally{
    fs.writeFileSync(reportPath,JSON.stringify(report,null,2));
    await fs.promises.rm(temp,{recursive:true,force:true});
  }
  console.log('Final ZIP compiled-renderer audit passed; actual Windows and physical hardware NOT executed.');
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
