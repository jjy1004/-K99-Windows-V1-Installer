"""Verify the delivered ZIP, using existing dependencies but isolated workspace links."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = json.loads((ROOT / "artifacts/k99-windows/package.json").read_text())["version"]
OUT = ROOT / "generated-artifacts/build-kits" / VERSION
NAME = "K99-Windows-V1-0.3.0-Windows-Build-Kit.zip"
SOURCE = Path(tempfile.mkdtemp(prefix="verified-source-", dir=OUT))
with zipfile.ZipFile(OUT / NAME) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        p = Path(name)
        assert not p.is_absolute() and ".." not in p.parts
        assert not set(p.parts) & {"node_modules", ".git", ".agents", "attached_assets", "local-data"}
        assert not p.name.startswith(".env")
        assert p.suffix.lower() not in {".db", ".sqlite", ".sqlite3", ".xlsx", ".xls", ".csv", ".pem", ".key"}
        original = ROOT / name
        if name not in {"tsconfig.json", ".gitignore", "README-WINDOWS.md", "build-kit.json"}:
            assert archive.read(name) == original.read_bytes(), f"최신 소스 불일치: {name}"
    archive.extractall(SOURCE)

expected = (OUT / (NAME + ".sha256")).read_text().split()[0]
assert hashlib.sha256((OUT / NAME).read_bytes()).hexdigest() == expected
assert json.loads((SOURCE / "artifacts/k99-windows/package.json").read_text())["version"] == VERSION


def link(item, destination):
    resolved = item.resolve()
    try:
        relative = resolved.relative_to(ROOT)
        replacement = SOURCE / relative
        if "node_modules" not in relative.parts and replacement.exists():
            resolved = replacement
    except ValueError:
        pass
    destination.symlink_to(resolved, target_is_directory=resolved.is_dir())


def dependencies(project):
    original = ROOT / project / "node_modules"
    target = SOURCE / project / "node_modules"
    if not original.is_dir():
        return
    target.mkdir(exist_ok=True)
    for item in original.iterdir():
        if item.name.startswith(".") and item.name not in {".pnpm", ".bin"}:
            continue
        destination = target / item.name
        if item.name.startswith("@"):
            destination.mkdir(exist_ok=True)
            for package in item.iterdir():
                link(package, destination / package.name)
        else:
            link(item, destination)


for project in ("", "artifacts/k99-windows", "lib/api-client-react", "lib/api-zod", "lib/api-spec"):
    dependencies(project)
app = SOURCE / "artifacts/k99-windows"
assert (app / "node_modules/@workspace/api-client-react").resolve() == SOURCE / "lib/api-client-react"
assert not (SOURCE / "lib/api-client-react/dist/index.d.ts").exists()
assert not (SOURCE / "lib/api-zod/dist/index.d.ts").exists()


def run(args, name, success=True):
    result = subprocess.run(args, cwd=SOURCE, capture_output=True, text=True)
    output = result.stdout + result.stderr
    (OUT / (name + ".log")).write_text(output)
    if success and result.returncode != 0:
        print(output[-10000:])
        raise RuntimeError(f"{name} 실패: {result.returncode}")
    return result.returncode, output


status, output = run(["pnpm", "--filter", "@workspace/k99-windows", "run", "typecheck"], "before-declarations", False)
assert status != 0 and "TS6305" in output, "선언 파일 없는 초기 상태의 TS6305 대조 검사 실패"
run(["node", "scripts/build-desktop-declarations.cjs"], "library-declarations")
for project in ("lib/api-client-react", "lib/api-zod"):
    assert (SOURCE / project / "dist/index.d.ts").stat().st_size > 0
run(["pnpm", "--filter", "@workspace/k99-windows", "run", "typecheck"], "after-declarations")
run(["pnpm", "--filter", "@workspace/k99-windows", "run", "desktop:build"], "archive-desktop-build")
assert (app / "dist/desktop/index.html").stat().st_size > 0
report = {"zipSHA256": expected, "crcVerified": True, "currentSourcesMatch": True,
          "workspaceLinksIsolated": True, "beforeDeclarationTS6305Reproduced": True,
          "declarationsEmitted": True, "reactTypecheckPassed": True, "desktopBundleBuilt": True,
          "dependenciesReused": True, "windowsBuildVerified": False, "physicalCameraVerified": False}
(OUT / "source-verification.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
