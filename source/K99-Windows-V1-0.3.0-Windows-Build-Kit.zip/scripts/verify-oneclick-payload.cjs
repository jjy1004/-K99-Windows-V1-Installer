'use strict';
// Read/extract only: this NEVER runs the installer or installed application.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
const {createRequire}=require('node:module');
const root=path.resolve(__dirname,'..');
const appRequire=createRequire(path.join(root,'artifacts/k99-windows/package.json'));
const resedit=createRequire(appRequire.resolve('electron-builder'))('resedit');
// electron-builder's bundled 7za lacks the NSIS decoder. Full 7z is needed
// for the outer installer; bundled 7za remains suitable for the inner payload.
const seven=process.env.K99_FULL_7Z||'7z';
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const installer=path.join(root,'generated-artifacts/K99-Smart-Laundry-V2-Setup.exe');
const evidenceFile=path.join(root,'generated-artifacts/oneclick-installer-verification.json');
const report=JSON.parse(fs.readFileSync(evidenceFile));
if(hash(installer)!==report.sha256)throw Error('설치본 해시 불일치');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'k99-nsis-payload-'));
function unpack(file,directory,nsis=false){
  const p=spawnSync(seven,['x',...(nsis?['-tNsis']:[]),'-y','-o'+directory,file],{encoding:'utf8',maxBuffer:4e6});
  if(p.status!==0)throw Error(p.stderr||p.stdout||'설치본 압축 검증 실패');
}
function find(dir,name){
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    const file=path.join(dir,e.name);
    if(e.isFile()&&e.name===name)return file;
    if(e.isDirectory()){const value=find(file,name);if(value)return value;}
  }
}
function files(dir){
  return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{
    if(e.isSymbolicLink())throw Error('설치 파일에 외부 링크가 있습니다.');
    const p=path.join(dir,e.name);return e.isDirectory()?files(p):[p];
  });
}
try{
  const executable=resedit.NtExecutable.from(fs.readFileSync(installer));
  const resources=resedit.NtExecutableResource.from(executable);
  const manifests=resources.entries.filter(entry=>entry.type===24).map(entry=>Buffer.from(entry.bin).toString('utf8')).join('\n');
  if(!/requestedExecutionLevel[^>]*level=["']asInvoker["']/.test(manifests))
    throw Error('설치 프로그램의 일반 사용자 실행 권한(asInvoker) 매니페스트가 없습니다.');
  unpack(installer,path.join(temp,'installer'),true);
  const payload=find(path.join(temp,'installer'),'app-64.7z')||find(path.join(temp,'installer'),'app-64.zip');
  if(!payload)throw Error('Windows x64 설치 페이로드가 없습니다.');
  const out=path.join(temp,'app');unpack(payload,out);
  const original=path.join(root,'generated-artifacts/windows-portable/win-unpacked');
  const names=files(original).map(f=>path.relative(original,f));
  for(const name of names){
    // NSIS copies large extraResources separately from app-64.7z.
    const inner=path.join(out,name),outer=path.join(temp,'installer',name);
    const actual=fs.existsSync(inner)?inner:outer;
    if(hash(actual)!==hash(path.join(original,name)))throw Error('설치본 내부 파일 불일치: '+name);
  }
  report.installerPayloadVerified=true;report.matchingPayloadFiles=names;
  report.installerExecutionLevelVerified='asInvoker';
  report.allPortableFilesMatch=true;report.filesCompared=names.length;
  report.portableSHA256=JSON.parse(fs.readFileSync(path.join(root,'generated-artifacts/windows-portable/verification.json'))).sha256;
  report.scope='NSIS compile and extracted Windows x64 payload; NOT Windows installation or physical hardware';
  fs.writeFileSync(evidenceFile,JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
}finally{fs.rmSync(temp,{recursive:true,force:true});}
