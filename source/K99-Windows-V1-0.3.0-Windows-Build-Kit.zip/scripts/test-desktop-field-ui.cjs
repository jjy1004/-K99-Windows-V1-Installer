'use strict';
// Use the installed Vite dependency graph, not a missing pnpm build/tsx script.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const esbuild=createRequire(require.resolve('vite',{paths:[app]}))('esbuild');
const folder=fs.mkdtempSync(path.join(os.tmpdir(),'k99-field-ui-tests-'));
try{
  // Keep TypeScript's own runtime intact. Bundling it while redefining
  // import.meta.url for each test also rewrites the compiler's internal URL.
  const modules=path.join(folder,'node_modules');fs.mkdirSync(modules);
  fs.symlinkSync(path.dirname(require.resolve('typescript/package.json')),path.join(modules,'typescript'),
    process.platform==='win32'?'junction':'dir');
  const files=fs.readdirSync(path.join(app,'tests')).filter(n=>n.endsWith('.test.ts'));
  const built=[];
  for(const name of files){
    const entry=path.join(app,'tests',name),outfile=path.join(folder,name.replace(/\.ts$/,'.cjs'));
    esbuild.buildSync({entryPoints:[entry],outfile,bundle:true,platform:'node',format:'cjs',logLevel:'warning',
      external:['typescript'],
      define:{'import.meta.url':JSON.stringify(pathToFileURL(entry).href)}});
    built.push(outfile);
  }
  // Hosted Windows runners have limited RAM. Do not load a bundled TypeScript
  // compiler in every test worker at once, or leave a stuck test unbounded.
  const result=spawnSync(process.execPath,['--max-old-space-size=256','--test','--test-concurrency=1','--test-timeout=30000',...built],
    {cwd:root,stdio:'inherit',timeout:180000});
  if(result.error)throw result.error;
  process.exitCode=result.status??1;
}finally{fs.rmSync(folder,{recursive:true,force:true});}
