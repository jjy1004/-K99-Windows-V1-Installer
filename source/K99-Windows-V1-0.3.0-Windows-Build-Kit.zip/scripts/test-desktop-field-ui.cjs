'use strict';
// Use the installed Vite dependency graph, not a missing pnpm build/tsx script.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),app=path.join(root,'artifacts/k99-windows');
const esbuild=createRequire(require.resolve('vite',{paths:[app]}))('esbuild');
const folder=fs.mkdtempSync(path.join(os.tmpdir(),'k99-field-ui-tests-'));
try{
  const files=fs.readdirSync(path.join(app,'tests')).filter(n=>n.endsWith('.test.ts'));
  const built=[];
  for(const name of files){
    const entry=path.join(app,'tests',name),outfile=path.join(folder,name.replace(/\.ts$/,'.cjs'));
    esbuild.buildSync({entryPoints:[entry],outfile,bundle:true,platform:'node',format:'cjs',logLevel:'warning',
      define:{'import.meta.url':JSON.stringify(pathToFileURL(entry).href)}});
    built.push(outfile);
  }
  const result=spawnSync(process.execPath,['--test',...built],{cwd:root,stdio:'inherit'});
  if(result.error)throw result.error;
  process.exitCode=result.status??1;
}finally{fs.rmSync(folder,{recursive:true,force:true});}
