'use strict';
// Real Chromium HTML geometry, not Windows spooler or physical printer verification.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{createRequire}=require('node:module');
const {tagHTML,tagLayout,validateRenderedTag}=require('../artifacts/k99-windows/electron/tag-template.cjs');
const appRequire=createRequire(path.resolve(__dirname,'../artifacts/k99-windows/package.json'));
async function main(){
  const profile=fs.mkdtempSync(path.join(os.tmpdir(),'k99-tag-geometry-'));
  const chrome=spawn('/repl/tools/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage',
    '--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{stdio:['ignore','ignore','pipe']});
  let socket,seq=0;const pending=new Map();
  try{
    const endpoint=await new Promise((resolve,reject)=>{
      let log='';const timer=setTimeout(()=>reject(Error('Chromium startup timeout')),20000);
      chrome.stderr.on('data',chunk=>{log+=chunk;const m=log.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
      chrome.once('error',reject);
    });
    socket=new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
    socket.onmessage=e=>{const msg=JSON.parse(e.data),p=pending.get(msg.id);if(p){pending.delete(msg.id);clearTimeout(p.timer);msg.error?p.reject(Error(msg.error.message)):p.resolve(msg.result);}};
    const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
      const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method));},20000);
      pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));
    });
    const {targetId}=await send('Target.createTarget',{url:'about:blank'});
    const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
    await send('Page.enable',{},sessionId);
    const {frameTree}=await send('Page.getFrameTree',{},sessionId);
    const reports=[];
    const barcode=await appRequire('bwip-js').toBuffer({bcid:'code128',text:'k99-test-garment-0001',height:9,scale:3,includetext:false});
    for(const [w,h] of [[30,40],[30,32]])for(const material of ['폴리에스테르','식물성 섬유','울/실크','나일론'])for(const color of ['유색','흰색'])for(const payment_type of ['PREPAID','POSTPAID']){
      const html=tagHTML({payload:{labelWidthMm:w,labelHeightMm:h,garmentId:'k99-test-garment-0001',
        customerName:'인쇄검증',itemName:'와이셔츠',manualMaterial:material,manualColor:color,payment_type,orderNumber:'TEST12345678'}},barcode);
      await send('Page.setDocumentContent',{frameId:frameTree.frame.id,html},sessionId);
      const r=await send('Runtime.evaluate',{awaitPromise:true,returnByValue:true,
        expression:`(async()=>{await (${validateRenderedTag.toString()})();return [...document.querySelectorAll('.row')].map(e=>{const b=e.getBoundingClientRect();return {text:e.textContent,yMm:b.y*25.4/96,heightMm:b.height*25.4/96};});})()`},sessionId);
      if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
      const rows=r.result.value,l=tagLayout(w,h);
      assert.equal(rows[4].text,`[소재] ${material}`);assert.equal(rows[5].text,`[색상] ${color}`);
      assert.ok(Math.abs(rows[4].yMm-l.materialY)<.05);
      assert.ok(Math.abs(rows[5].yMm-l.colorY)<.05);
      assert.ok((rows[4].yMm-rows[3].yMm-rows[3].heightMm)*8>=7.9);
      assert.ok((rows[5].yMm-rows[4].yMm)*8>=21.9);
      reports.push({sizeMm:[w,h],material,payment_type,barcodeEndMm:rows[3].yMm+rows[3].heightMm,
        materialYmm:rows[4].yMm,colorYmm:rows[5].yMm,footerEndMm:rows[5].yMm+rows[5].heightMm});
    }
    const out=path.resolve(__dirname,'../generated-artifacts/tag-layout-verification.json');
    fs.mkdirSync(path.dirname(out),{recursive:true});
    fs.writeFileSync(out,JSON.stringify({engine:'Linux Chromium HTML',cases:reports,windowsPrintingVerified:false},null,2));
    console.log(JSON.stringify({passed:reports.length,example:reports[0],windowsPrintingVerified:false,report:out},null,2));
  }finally{
    socket?.close();for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('CDP closed'));}pending.clear();
    chrome.kill();await new Promise(r=>{if(chrome.exitCode!==null)r();else{chrome.once('exit',r);setTimeout(r,3000).unref();}});
    fs.rmSync(profile,{recursive:true,force:true});
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
