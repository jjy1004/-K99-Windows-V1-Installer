'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function restoreParts(source,output){
  const manifest=JSON.parse(fs.readFileSync(path.join(source,'customer-videos.upload.json'),'utf8'));
  if(!Array.isArray(manifest.parts)||!manifest.parts.length||manifest.parts.length>32)throw Error('영상 분할 목록 오류');
  fs.mkdirSync(output,{recursive:true});
  const target=path.join(output,'customer-videos.zip'),hash=crypto.createHash('sha256'),buffer=Buffer.alloc(1024*1024);
  let total=0;const fd=fs.openSync(target,'w');
  try{
    for(const [i,p] of manifest.parts.entries()){
      if(p.name!==`customer-videos.zip.part${String(i+1).padStart(3,'0')}`)throw Error('영상 분할 파일 순서/이름 오류');
      const file=path.join(source,p.name);
      if(!fs.existsSync(file)||fs.statSync(file).size!==p.bytes)throw Error(`영상 분할 파일 누락/크기 불일치: source/${p.name}`);
      const part=crypto.createHash('sha256'),input=fs.openSync(file,'r');
      try{for(let n;(n=fs.readSync(input,buffer,0,buffer.length,null));){
        const bytes=buffer.subarray(0,n);fs.writeSync(fd,bytes);hash.update(bytes);part.update(bytes);total+=n;
      }}finally{fs.closeSync(input);}
      if(part.digest('hex')!==p.sha256)throw Error('영상 분할 파일 SHA-256 불일치: '+p.name);
    }
    fs.fsyncSync(fd);
    if(total!==manifest.bytes||hash.digest('hex')!==manifest.sha256)throw Error('원본 영상 ZIP 조합 무결성 오류');
  }catch(error){fs.closeSync(fd);fs.rmSync(target,{force:true});throw error;}
  fs.closeSync(fd);return target;
}
if(require.main===module){
  try{console.log('Verified original media ZIP: '+restoreParts(path.resolve(process.argv[2]||'source'),
    path.resolve(process.argv[3]||'generated-artifacts/media-import')));}
  catch(error){console.error('[K99 ORIGINAL MEDIA IMPORT] '+error.message);process.exitCode=1;}
}
module.exports={restoreParts};
