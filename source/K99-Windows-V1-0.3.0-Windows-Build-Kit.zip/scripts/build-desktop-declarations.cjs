'use strict';
// Shared by CI and manual Windows packaging. No package "build" script is used.
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const root = path.resolve(__dirname, '..');
const projects = ['lib/api-client-react', 'lib/api-zod'];
function canonicalInputPath(file, platform = process.platform) {
  // TypeScript returns forward slashes even on Windows. path.join does not.
  // Compare complete normalized paths; never match only a basename/suffix.
  const windows = platform === 'win32';
  const resolved = (windows ? path.win32 : path.posix).resolve(file);
  return windows ? resolved.replace(/\\/g, '/').toLowerCase() : resolved;
}
function containsInput(fileNames, expected, platform = process.platform) {
  const canonical = canonicalInputPath(expected, platform);
  return fileNames.some(file => canonicalInputPath(file, platform) === canonical);
}
function main() {
  console.log('[K99 DIRECT-TSC WINDOWS-PATH-FIX] No pnpm filtered build script is required.');
  const ts = require('typescript');
  const tsc = require.resolve('typescript/bin/tsc');
  const expected = [];
  for (const project of projects) {
    const file = path.join(root, project, 'tsconfig.json');
    const read = ts.readConfigFile(file, ts.sys.readFile);
    if (read.error) throw Error(`${project}: ${ts.flattenDiagnosticMessageText(read.error.messageText, '\n')}`);
    const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, path.dirname(file), undefined, file);
    if (parsed.errors.length) throw Error(`${project}: ${parsed.errors.map(e => ts.flattenDiagnosticMessageText(e.messageText, '\n')).join('\n')}`);
    if (!parsed.options.composite || !parsed.options.emitDeclarationOnly || parsed.options.noEmit)
      throw Error(`${project}/tsconfig.json must enable composite + emitDeclarationOnly and allow emit.`);
    const output = path.join(parsed.options.outDir, 'index.d.ts');
    const input = path.join(root, project, 'src/index.ts');
    if (!containsInput(parsed.fileNames, input))
      throw Error(`${project}: src/index.ts is missing from tsconfig inputs. Expected canonical path: ${canonicalInputPath(input)}; parsed.fileNames: ${JSON.stringify(parsed.fileNames)}`);
    console.log(`INPUT VERIFIED ${project}: ${canonicalInputPath(input)} (${parsed.fileNames.length} TypeScript inputs)`);
    expected.push(output);
  }
  if (!process.argv.includes('--verify-only')) {
    const args = [tsc, '--build', ...projects, '--force', '--verbose'];
    console.log(`TypeScript ${ts.version}: node ${args.join(' ')}`);
    const result = spawnSync(process.execPath, args, {cwd: root, stdio: 'inherit', shell: false});
    if (result.error) throw result.error;
    if (result.status !== 0) throw Error(`TypeScript declaration emit failed (exit ${result.status}); inspect the file/line diagnostics above.`);
  }
  for (const file of expected) {
    if (!fs.existsSync(file) || fs.statSync(file).size === 0)
      throw Error(`Required declaration not generated: ${path.relative(root, file)}. React typecheck must not start.`);
    console.log(`VERIFIED ${path.relative(root, file)} (${fs.statSync(file).size} bytes)`);
  }
}
function runCli() {
  try { main(); } catch (error) {
    console.error(`::error title=K99 library declarations failed::${error.message}`);
    process.exitCode = 1;
  }
}
module.exports = {canonicalInputPath, containsInput, runCli};
if (require.main === module) runCli();
