'use strict';
// Shared by CI and manual Windows packaging. No package "build" script is used.
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const root = path.resolve(__dirname, '..');
const projects = ['lib/api-client-react', 'lib/api-zod'];
function main() {
  console.log('[K99 DIRECT-TSC DECLARATIONS v1] No pnpm filtered build script is required.');
  const ts = require('typescript');
  const tsc = require.resolve('typescript/bin/tsc');
  const expected = [];
  for (const project of projects) {
    const file = path.join(root, project, 'tsconfig.json');
    const read = ts.readConfigFile(file, ts.sys.readFile);
    if (read.error) throw Error(`${project}: ${ts.flattenDiagnosticMessageText(read.error.messageText, '\n')}`);
    const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, path.dirname(file));
    if (parsed.errors.length) throw Error(`${project}: ${parsed.errors.map(e => ts.flattenDiagnosticMessageText(e.messageText, '\n')).join('\n')}`);
    if (!parsed.options.composite || !parsed.options.emitDeclarationOnly || parsed.options.noEmit)
      throw Error(`${project}/tsconfig.json must enable composite + emitDeclarationOnly and allow emit.`);
    const output = path.join(parsed.options.outDir, 'index.d.ts');
    if (!parsed.fileNames.some(f => f === path.join(root, project, 'src/index.ts')))
      throw Error(`${project}: src/index.ts is missing from tsconfig inputs.`);
    expected.push(output);
  }
  if (!process.argv.includes('--verify-only')) {
    const args = [tsc, '--build', ...projects, '--force', '--verbose'];
    console.log(`TypeScript ${ts.version}: node ${args.join(' ')}`);
    const result = spawnSync(process.execPath, args, {cwd: root, stdio: 'inherit', shell: false});
    if (result.error) throw result.error;
    if (result.status !== 0) throw Error(`TypeScript declaration emit failed (exit ${result.status}); inspect the file/line diagnostics above.`);
  }
  for (const file of expected) {
    if (!fs.existsSync(file) || fs.statSync(file).size === 0)
      throw Error(`Required declaration not generated: ${path.relative(root, file)}. React typecheck must not start.`);
    console.log(`VERIFIED ${path.relative(root, file)} (${fs.statSync(file).size} bytes)`);
  }
}
try { main(); } catch (error) {
  console.error(`::error title=K99 library declarations failed::${error.message}`);
  process.exitCode = 1;
}
