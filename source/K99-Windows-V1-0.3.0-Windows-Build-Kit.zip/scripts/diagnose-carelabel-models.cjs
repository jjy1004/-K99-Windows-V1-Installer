'use strict';
// Server-side operator diagnostic. Prints model capabilities, never keys or image data.
async function main(){
  if(!process.env.GEMINI_API_KEY)throw Error('SERVER_NOT_READY');
  const models=[];
  let token='';
  for(let page=0;page<5;page++){
    const url=new URL('https://generativelanguage.googleapis.com/v1beta/models');
    url.searchParams.set('pageSize','100');
    if(token)url.searchParams.set('pageToken',token);
    const response=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(15000),
      headers:{'x-goog-api-key':process.env.GEMINI_API_KEY}});
    if(!response.ok)throw Error(`MODEL_LIST_HTTP_${response.status}`);
    const body=await response.json();
    for(const model of body.models||[])
      if(/^models\/gemini-[a-z0-9.-]+$/.test(model.name)&&model.supportedGenerationMethods?.includes('generateContent'))
        models.push({name:model.name.slice(7),displayName:String(model.displayName||'').slice(0,100)});
    token=body.nextPageToken||'';
    if(!token)break;
  }
  console.log(JSON.stringify({generateContentModels:models},null,2));
}
if(require.main===module)main().catch(error=>{console.error(String(error.message).slice(0,120));process.exitCode=1;});
