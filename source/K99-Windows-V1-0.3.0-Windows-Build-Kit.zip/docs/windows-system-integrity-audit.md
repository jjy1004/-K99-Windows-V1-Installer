# K99 Windows V1 최종 소스 무결성 감사

검사일: 2026-11-06 · 버전: 0.3.0

## 1. 결론 및 검증 범위

**코드·타입·React 번들·로컬 자동 검사·설치본 스테이징은 통과했습니다.**
이번 감사에서 Windows CSV 다운로드 차단 결함 1건을 발견하고 수정했습니다.

**이 보고서는 실제 Windows 설치 및 매장 장비·스마트폰 검증 완료 보고서가 아닙니다.**
검사는 Linux 개발 환경의 실제 임시 SQLite, 로컬 HTTP 서버, 임시 파일시스템과 일부 장치/대화상자 검사 대역으로 수행했습니다.
QR을 실제 휴대폰으로 스캔하거나, 실물 D: 드라이브·TSC·OBS·풋스위치를 사용한 결과로 해석하면 안 됩니다.
요청한 ZIP 파일명에 `verified`가 포함되지만 검증 범위는 위 개발 환경 검사에 한정됩니다.

기존 Replit 운영 프로젝트·운영 DB·배포·서비스에는 접속하거나 변경하지 않았습니다.
가상 브라우저 고객 데이터를 실제 고객 적재 성공으로 제시하지 않았습니다.

## 2. 발견한 결함과 수정

### Windows 고객 명부 CSV 저장 차단
- 기존 `src/customer-directory-export.ts`는 Blob 링크의 `anchor.click()`으로 다운로드를 요청했습니다.
- Electron Main의 기존 `will-download` 정책은 모든 브라우저 다운로드를 차단합니다.
- 따라서 CSV 문자열이 정상이어도 실제 설치본에서는 파일 저장이 막힐 수 있었고, UI는 다운로드 요청 문구만 표시했습니다.

수정:
1. 기존 `k99:request` 채널 안에 직원 전용 `/api/customer-directory/export` 요청을 추가했습니다.
2. `dialog.showSaveDialog`로 저장 위치를 선택하고 Node에서 UTF-8-BOM CSV를 실제 기록합니다.
3. 임시 파일 쓰기·파일 동기화 후 교체합니다. 쓰기 실패 시 임시 파일을 정리합니다.
4. 저장 취소·저장 실패·실제 저장 완료를 구분하고, 완료 응답을 기다린 뒤 저장 경로를 표시합니다.
5. CSV 확장자만 허용하고 DB 파일 경로, 잘못된 파일명/BOM, 32MB 초과를 거부합니다.
6. 저장 중 대상 파일이 변경되면 덮어쓰지 않습니다.

**기존 네트워크 차단·브라우저 다운로드 차단을 해제하지 않았습니다.**
기존 SQLite 스키마·주문 저장·관리자 인증 정책은 변경하지 않았습니다.

## 3. 아키텍처·원본 보존 검증

| 항목 | 결과·근거 |
|---|---|
| Electron 메인 프로세스 | 기존 구조 유지. 이번 감사 변경은 CSV 저장 모듈 연결 및 기존 요청 경로의 분기 추가입니다. Main 파일 자체가 완전히 무변경인 것은 아닙니다. |
| SQLite·사진 승격·백업 코어 | `lib/k99-local`은 이번 감사 시작 기준과 파일 차이 없음. 임시 SQLite 저장·재개방·사진 승격·백업 검사가 통과했습니다. |
| IPC | 기존 `k99:request`, `k99:changed`, 저장/풋스위치/고객 창 채널 유지. preload 변경 없음. |
| OBS·카메라·풋스위치·TSC | `equipment-native.cjs`, `foot-switch.cjs`, 기존 촬영 API·출력 코어 변경 없음. 실제 장비 동작은 미검증입니다. |
| 설치 설정·의존성 | `electron-builder.cjs`, NSIS 포함 파일, workflow, package.json, pnpm-lock 변경 없음. |
| 설치본 포함 | 기존 스테이징 복사 목록에 새 CSV CJS 모듈을 추가했습니다. 모바일 모듈 3개도 포함되어 있습니다. 실제 EXE/ASAR 검증은 별도입니다. |
| 저장 폴더 | 기존 `photo-archive.cjs` 변경 없음. 기본 루트 `D:\K99과천매장`, `01_고객세탁사진`, `02_세탁전후사진` 유지. |
| 고객 폴더 규칙 | 한국 날짜 `YYYYMMDD_고객명_전화뒷4자리`, 파일명 금지 문자 정리, 기존 폴더 식별값 우선 사용 규칙 유지. |

무변경 여부는 **이번 감사 시작 시점의 Git 기준**과 비교한 결과입니다.
과거 모든 버전의 모든 기능을 물리적 장비까지 100% 보증한다는 의미는 아닙니다.
보호 대상 파일의 비교 해시는 패키지의 감사 증빙 JSON에 포함합니다.

## 4. 핵심: 휴대폰 연동·듀얼 촬영 검증

| 체크 항목 | 구현 위치 | 확인한 내용 | 미검증/조건 |
|---|---|---|---|
| PC·휴대폰 영역 분리 | `NativeDraftCamera.tsx`, `native-draft-camera.css`, `MobileDraftCapture.tsx`, `mobile-draft-capture.css` | PC 안내 제목, 스마트폰 아이콘·강조 버튼·케어라벨 안내 문구와 독립 영역 존재. 타입·빌드·소스 계약 검사 통과. | Windows 화면의 실제 시인성·클릭 동작은 미검증. |
| QR 모달 | `MobileDraftCapture.tsx`, `mobile-photo-client.ts` | 기존 QR 라이브러리 사용. 고객·전화뒷자리·품목·폴더 식별값·선택 가능한 내부 IP 주소 표시. | QR 스캔 및 실제 모달 렌더링은 휴대폰/Windows 실기 확인 필요. |
| QR 주소·대상 고정 | `mobile-photo-bridge.cjs`, `mobile-photo-controller.cjs` | URL에 내부 IP·포트·접수 ID·임시 토큰 포함. 폴더는 토큰에 묶인 서버 측 대상에서 결정. | 보안을 위해 임의의 `targetPath`를 URL로 받지 않습니다. |
| 모바일 페이지 접속 | `mobile-photo-bridge.cjs`, `mobile-upload-page.cjs` | 실제 루프백 HTTP 요청으로 `/mobile-upload` 응답과 촬영 파일 입력 존재 확인. | 매장 Wi-Fi·공유기 단말 격리·Windows 방화벽은 미검증. |
| 카메라·앨범·다중 선택 | `mobile-upload-page.cjs` | `accept="image/*"`, `capture="environment"`, `multiple` 및 별도 앨범 입력, 순차 전송·실패 재시도 구현. | 휴대폰 기본 카메라 실행·연속 촬영 방식은 기종별 확인 필요. |
| 동일 고객 폴더 저장 | 기존 `photo-archive.cjs`를 사용하는 모바일 경계 어댑터 | 실제 임시 디렉터리에서 PC·모바일의 동일 폴더와 바이트 저장 확인. 모바일 선촬영의 폴더 자동 생성 확인. | 임시 `test-D` 검사이며 실제 Windows D: 검사는 아님. |
| 파일명·충돌 방지 | `mobile-photo-bridge.cjs` | `MOBILE_YYYYMMDD_HHmmss_001_짧은해시.jpg`. 시각·순번 및 충돌 방지 해시 사용. PC 파일명은 유지. | 예시의 `XX.jpg`에 순번 3자리·해시를 확장한 형식이며 문자 그대로 같은 형식은 아닙니다. |
| 실시간 IPC·컷 수 | Main의 기존 `k99:changed`, `MobileDraftCapture.tsx`, `App.tsx` | 저장 후 이벤트 전송, 모달 상태 및 읽기 전용 초안 복구로 최신 사진 반영. 수신 누락 대비 2초 폴링 있음. | 실제 Electron 이벤트→화면→썸네일 갱신은 현장 검증 필요. 알림 문구는 “휴대폰 사진 n장이 성공적으로 동기화되었습니다.”입니다. |
| 태그 중복 방지 | 기존 직렬 촬영·태그 경로 재사용 | PC 추가 사진과 모바일 사진에 최초 태그가 중복되지 않음. 같은 이미지 동시 전송에도 파일명 분리 확인. | 출력기는 검사 대역. 모바일 첫 촬영 시 기존 첫 사진 태그 정책 적용. |
| SQLite·주문·백업 | 기존 초안·확정 승격·통합 백업 | 가짜 확정 주문 없이 초안 저장, DB 재개방, 주문 확정 후 정식 사진 연결, 암호화 백업 추출 검사 통과. | 실제 Windows에서 백업 복구 및 D: 보관본 재생성은 미검증. |

### 안전 동작 조건
- Windows 앱의 실제 장비 모드, 고객명·전화번호·유효한 촬영 대상 의류가 필요합니다.
- 휴대폰과 PC는 통신 가능한 같은 매장 내부망이어야 합니다. PC는 같은 공유기에 유선 연결되어도 됩니다.
- TCP 5050이 점유된 경우 **EADDRINUSE를 명시적으로 표시하고**, 다른 프로그램이나 포트를 변경하지 않습니다. 실제 점유 서버를 둔 자동 검사로 확인했습니다.
- QR은 10분 유효, 닫기/앱 재로딩/종료 시 폐기합니다. 고객·품목이 바뀌면 전송을 거부합니다.
- 사진은 8MB 이하 JPEG/PNG, 최대 가로·세로 8192픽셀. HEIC는 JPEG 변환/카메라 포맷 변경이 필요합니다.
- JPEG는 추가 재압축하지 않습니다. PNG 보관본은 기존 JPEG 변환 규칙을 사용합니다.
- 저장 경로는 휴대폰이 지정할 수 없고, 잘못된 토큰·Host·Origin·손상/지원하지 않는 파일은 거부합니다.
- 매장 HTTP는 TLS 암호화가 아닙니다. 신뢰할 수 있는 개인 네트워크에서만 사용하며 외부 포트포워딩은 금지합니다.
- QR 모달이 열린 동안 Enter가 뒤쪽 촬영을 오작동시키지 않도록 촬영 준비 상태를 잠시 내립니다. 풋스위치 모듈 자체는 변경하지 않았습니다.

## 5. UI 단계별 유도·전진

| 항목 | 구현·증빙 | 결과·조건 |
|---|---|---|
| 1단계 시인성·동적 강조 | `NativeDraftCamera.tsx`, `native-draft-camera.css`, `App.tsx`, `intake-ui-guidance.test.ts` | 품목/컷 수 18px, 미리보기 OFF 강조, ON 시 촬영 가능, 저장 사진 존재 시 추가 촬영 안내·최종 확인 강조가 코드에 존재. 고객/품목 등 기존 유효성 조건은 유지. |
| 2~5단계 메인 버튼 규격 | `InspectionStageDesk.tsx`, `inspection-stage-desk.css` | 메인 액션에 52px 이상 높이·12px 둥근 모서리·강조색 적용, 뒤로 가기와 구분. CSS·소스 계약 확인이며 실제 Windows 육안 확인은 아님. |
| 4단계 붉은 제목 | 위 두 파일 | `이상 세탁물 고객 안내`에 붉은색 `#dc2626`, 굵기 900 적용 확인. |
| 6단계 일괄 완료·출고 이동 | `InspectionStageDesk.tsx`, `field-quality.ts`, `OrderWorkspace.tsx`, `field-ux-update.test.ts` | 개별 완성 검수를 누르지 않은 유효 주문도 일괄 처리. 기존 동기 저장 성공 후 `/scan`으로 이동. 자동 함수 검사와 소스 연결 검사 통과. |

실제 세탁 미완료·보류·취소 등은 보호 조건으로 거부합니다.
이 상태를 무조건 완료로 위조하거나 저장 실패를 화면 전진으로 숨기지 않습니다.

## 6. 출고 삭제·관리 기능

| 항목 | 구현·증빙 | 결과·조건 |
|---|---|---|
| 출고 카드 삭제 | `GarmentScannerWorkspace.tsx`, `OrderDeletionDialog.tsx`, `order-deletion.ts`, `release-deletion.test.ts` | 확인 후 기존 논리 삭제 저장. 임시 SQLite에서 재개방 후 출고·바코드·기간 통계·고객 집계·미출고 안내 제외 확인. 원본 사진·태그·감사 기록 보존. |
| 삭제 보호 조건 | 기존 삭제 경로 | 저장 실패·동시 변경·기존 결제/환불 등 보호 조건은 거부할 수 있습니다. DB에서 물리 삭제한다는 의미는 아닙니다. |
| 가격표 5번째 카드 | `PickupNoticeActions.tsx`의 카드 배열 → `SimpleStatisticsCenter.tsx` → `ManagementPriceEditor.tsx` | 5번째 가격표 카드 연결과 비밀번호 없는 모달 존재 확인. `ManagementCenter.tsx`가 아니라 실제 이 경로에 구현되어 있습니다. |
| 가격표 저장·접수 반영 | `ManagementPriceEditor.tsx`, `shared-price-catalog.ts`, `App.tsx` | 리비전 충돌 검사를 유지해 저장하고 공유 가격 이벤트로 접수 화면을 다시 읽음. 기존 확정 주문 가격을 소급 변경하지 않음. 실제 Windows 입력 조작은 미검증. |
| 고객 명부·검색·상세 | `ManagementCustomerPanel.tsx`, `customer-directory-export.ts`, `management-directory.test.ts` | 전체 명부 조회, 고객명/전화 끝자리 필터, 페이지 이동·상세 이력과 실제 임시 SQLite 읽기 전용 조회 검사 통과. |
| UTF-8-BOM CSV | 위 UI/변환기 및 새 `electron/customer-directory-export.cjs` | 이번 차단 결함 수정. 실제 임시 파일의 BOM·한글·수식 방어·파일 바이트·취소·실패·확장자·기존 파일 교체 검사 통과. Windows 저장 대화상자 자체는 검사 대역. |

## 7. 실행한 검사와 결과

| 검사 | 결과 |
|---|---|
| `pnpm --filter @workspace/k99-windows run typecheck` | 통과 |
| `pnpm --filter @workspace/k99-windows run desktop:build` | 통과. 기존 500kB 초과 번들 크기 경고는 남아 있으며 빌드 오류가 아님. |
| `node scripts/test-desktop-field-ui.cjs` | 53개 통과, 실패/스킵 0 |
| `node --test lib/k99-local/*.test.cjs artifacts/k99-windows/electron/*.test.cjs artifacts/k99-windows/tests/*.test.cjs scripts/tests/*.test.cjs` | 113개 통과, 실패/스킵 0 |
| `node scripts/stage-windows-app.cjs` | 통과. 새 런타임 모듈 포함 확인 |
| `git diff --check` | 통과 |
| 보호 파일 Git 비교·SHA-256, 소스 ZIP CRC·현재 파일 일치·업로드 명세 해시 | 생성 단계에서 증빙 JSON 및 SHA 파일에 기록 |

총 **166개 자동 검사 통과**입니다. UI 관련 일부 검사는 코드 연결·스타일·함수 계약 검사이며 실제 브라우저 클릭 검사가 아닙니다.
모바일 검사에서 HTTP·SQLite·파일 저장은 실제 임시 자원을 사용했지만 프린터·Electron 이미지 디코더는 검사 대역입니다.

## 8. 이번 감사 수정·추가 파일
- 수정: `artifacts/k99-windows/electron/main.cjs`
- 수정: `artifacts/k99-windows/src/customer-directory-export.ts`
- 수정: `artifacts/k99-windows/src/ManagementCustomerPanel.tsx`
- 수정: `scripts/stage-windows-app.cjs`
- 추가: `artifacts/k99-windows/electron/customer-directory-export.cjs`
- 추가: `artifacts/k99-windows/tests/system-integrity-audit.test.ts`
- 추가: 본 보고서 `docs/windows-system-integrity-audit.md`

모바일·기존 UI·관리 기능 전체 관련 파일은 함께 포함한 `windows-photo-dual-sync.md`, `windows-ui-guidance-update.md`, `windows-management-update.md`, `windows-release-delete-update.md`에 정리되어 있습니다.

## 9. 전달 및 현장 확인
- `k99-system-final-verified.zip`: 독립 Windows 앱 전체 재빌드 소스·보고서·검사 코드.
- GitHub 업로드 ZIP: 기존 `.github/workflows`, `source`, `README.md`에 덮어쓰는 구조 유지. 소스 ZIP·SHA-256·upload.json 포함.
- 운영 DB·고객 엑셀·키·node_modules·컴파일 산출물은 소스 전달에서 제외합니다.
- 기존 원본 영상은 변경하지 않았습니다. 기존 GitHub 영상 파트 2개는 그대로 유지하세요.
- 이 파일은 EXE가 아닙니다. 기존 Windows Actions에서 재빌드한 뒤 별도 시험 PC에서 검증하세요.
- 실제 Windows 설치/기동·SQLite ABI·LAN QR·Android/iPhone·D: 장애·OBS/풋스위치/TSC·고객 모니터·Windows 복원을 확인하기 전 **현장 전체 검증 완료로 간주하거나 운영 시스템을 교체하지 마세요.**
