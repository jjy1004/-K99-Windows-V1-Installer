# Actions 미사용 Windows 포터블 제작

## 현재 확보한 구성

- 기존 NSIS/Windows 네이티브 빌드 경로는 유지한다.
- 별도 `scripts/build-windows-portable.cjs`는 공식 Windows x64 Electron ZIP과 현재 SQLite 버전에 맞는 Electron ABI 전용 Windows 사전 빌드 모듈만 사용한다.
- Electron 공식 SHASUMS256와 SQLite 릴리스의 SHA-256을 검사한다. SQLite의 실제 PE AMD64 헤더와 `node_register_module_v143` export도 검사한다.
- 준비 검증: Electron 40.10.6, better-sqlite3 12.11.1, Electron ABI 143.
- Linux 네이티브 모듈을 Windows 폴더에 넣지 않는다. Windows 실제 로드·실행·장비 검증을 대신한 검사는 아니다.

## 서버 게시

- 개발 preview는 상시 운영 주소가 아니다. `getDeploymentInfo`로 확인한 실제 게시 도메인이 필요하다.
- 운영 API 진입점은 `carelabel-proxy.mjs`이며 건강 확인과 `/api/carelabel/analyze`만 제공한다.
- 개발 환경의 원래 서버/SQLite 기능은 유지하며, 운영 프록시에서는 고객·주문·가격표·파일 API를 열지 않는다.
- 사용자가 Publishing에서 상시 구동 Reserved VM의 비용·공개 접근·서버 Secret을 확인한 후 직접 게시한다. 에이전트가 임의로 게시하지 않는다.
- 서버 Secret은 `GEMINI_API_KEY`이며 클라이언트 ZIP에 넣지 않는다.

## 제작 순서

1. `node scripts/build-windows-portable.cjs --prepare` — 공식 바이너리 확보/검사.
2. 사용자 게시 후 실제 도메인과 `/api/healthz` 응답을 확인한다.
3. 최신 React desktop bundle 준비 후 `node scripts/build-windows-portable.cjs --proxy-url https://실제-게시-도메인` 실행.
4. 격리 runtime 의존성 설치, 해당 ABI Windows SQLite 배치, K99 아이콘 반영, app.asar 생성, 기존 검증 영상 포함.
5. PE·패키징 URL·SQLite 해시·ZIP CRC·최종 SHA-256을 확인한다.

출력: `generated-artifacts/K99-Windows-V1-0.3.0-win-unpacked.zip`.
아직 실제 게시 주소가 없으면 최종 ZIP을 만들거나 개발 주소를 상시 주소처럼 넣어 배포하지 않는다.
공식 배포 메타데이터에 도메인은 있으나 서버가 아직 정상 기동되지 않은 경우, 준비되지 않았다는 사실을 알리고 `--allow-offline-proxy`로만 연결 대기 포터블을 만들 수 있다. 기본 건강 검사 통과 조건은 유지하며 검증 JSON·사용안내에 AI 사용 불가를 명시한다. 이는 서버 배포 성공이나 상시 구동 검증이 아니다.

## 사용 및 제한

완성 ZIP은 전체 압축 해제 후 `win-unpacked/K99-Windows-V1.exe`를 더블클릭한다.
PowerShell이나 브라우저를 직접 열 필요는 없다. 포터블이므로 설치 마법사·바탕화면 바로가기 자동 생성은 제공하지 않는다.
기존 데이터는 앱의 기존 userData 및 매장 사진 경로를 유지한다. 기존 앱을 먼저 종료하고 백업한 뒤 시험한다.
실제 Windows 11 실행, 보안 경고, 사진 표시, AI 결과, 태그 출력, 카메라/스캐너/듀얼 모니터는 현장 검증이 필요하다.

## 대용량 다운로드

완성 ZIP은 원본 영상과 Windows 런타임 때문에 100MiB를 넘을 수 있다. Library 등록이 거절되면 파일을 줄이지 않고 개발 전용 `/api/dev-downloads/K99-Windows-V1-0.3.0-win-unpacked.zip` 및 같은 URL의 `.sha256` 파일을 사용한다.
이 경로는 고정된 두 산출물만 내려주며 HEAD/Range를 지원한다. 개발 워크스페이스가 실행 중이어야 한다. AI 전용 정식 배포 진입점에는 포함되지 않는다.
