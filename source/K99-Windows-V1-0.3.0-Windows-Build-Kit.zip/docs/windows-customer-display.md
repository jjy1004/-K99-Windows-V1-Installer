# Windows 고객 모니터 및 로컬 영상

최신 정식 영상·현장 기능 통합본의 업로드/검증 절차는
[windows-field-operations.md](windows-field-operations.md)를 기준으로 합니다.

- Electron main의 `screen.getAllDisplays()`와 별도 `BrowserWindow`를 사용합니다.
- 선택한 디스플레이는 네이티브 설정 파일로 보존하고 전체 화면 좌표를 적용합니다.
- READY, heartbeat, 명령 ACK 및 실제 첫 프레임 확인을 구분합니다.
- Electron에서는 IPC만 사용하며 웹 화면의 BroadcastChannel을 통신 대안으로 사용하지 않습니다.
- 정식 원본 MP4를 `extraResources`로 포함하고 범위 요청을 지원하는 로컬 프로토콜로 재생합니다.
- 영상 종료/닫기는 최신 접수 화면으로 복귀합니다. 대기 중에도 고객 접수 데이터가 동기화됩니다.

Chromium 검사는 모의 Electron IPC 및 화면 API를 사용합니다.
실제 Windows 설치, TSC 출력, 발판, OBS 및 물리적 듀얼 모니터 검증과 구분해야 합니다.
