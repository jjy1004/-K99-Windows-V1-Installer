# K99 케어라벨 중앙 분석 프록시

## 배치

`휴대폰 사진 → 기존 Electron 사진/SQLite 커밋 → Electron Main → 현재 Replit /api/carelabel/analyze → Google Gemini`

- Windows 앱에는 키 입력/환경변수 검사/Google SDK 호출이 없다.
- 서버 프로세스만 Replit Secrets의 `process.env.GEMINI_API_KEY`를 읽는다. 키는 단 한 곳에 등록한다.
- 모델은 사용 가능한 모델로 전환 승인을 받은 뒤 적용한 **gemini-3.1-flash-lite**다. 기존 gemini-2.5-flash의 실제 요청은 404를 반환했다. 모델 목록에 나오는 것만으로 호출 성공을 보장하지 않는다.
- Gemini 3용 `thinkingLevel:LOW`를 사용하며, 2.5 전용 thinkingBudget와 temperature를 해당 요청에 넣지 않는다.
- 기존 사진 저장·파일 해시 확인·고객/의류 ID·태그 claim/finish·마감 동기 커밋은 유지한다.
- 클라이언트는 `{dataBase64,mimeType}`만 보낸다. 이름·전화·주소·주문 번호나 API 키를 전송하지 않는다.
- MIME은 image/jpeg 또는 image/png. Base64 왕복·헤더·최대 8MiB를 서버가 검사한다.
- JSON Schema와 서버 후처리로 4대 소재·2대 세탁법을 검증한다. 물세탁 허용이면 드라이도 허용돼도 물세탁 우선이다.
- 울/실크 포함 > PT 90% 이상 > 나일론 포함 > 식물성/혼방 순으로 겹치는 분류의 우선순위를 정한다.
- 사진에서 의류 색을 모르면 `확인 필요`로 남긴다. 라벨 종이 색으로 추측하지 않는다. 색 미확인만으로 정상 소재·세탁법 분석을 일반으로 버리지 않는다.
- 판독 불가·두 세탁법 모두 금지·불완전 혼용률은 성공으로 위장하지 않는다. review/failed 및 일반 태그로 업무를 계속하며 직원 확인이 필요하다.

## 서버 준비 — 배포자가 1회 수행

1. 현재 Replit 프로젝트 Secrets에 GEMINI_API_KEY를 안전하게 등록한다. 채팅·GitHub·설치 ZIP에 키를 넣지 않는다.
2. API Server workflow를 실행한다. 서버 키가 없으면 503 SERVER_NOT_READY이며 Google 호출을 하지 않는다.
3. 매장 앱은 package.json의 k99CareLabelProxyUrl을 읽는다. 현재 사용자가 지정한 Replit 웹뷰의 HTTPS `/api/carelabel/analyze`가 기본값이다. 스테이징이 이 비밀 아닌 URL을 설치 패키지에 복사한다.
4. 상대 URL은 file:// Electron에서 중앙 서버를 가리키지 않으므로 절대 HTTPS URL을 빌드에 포함한다.
5. localhost 개발 테스트는 `endpoint`와 `allowLoopback:true`를 명시한 시험 코드에서만 가능하다. 실제 설치본은 HTTPS로 동작한다. 별도 Windows 사용자 환경변수가 필요하지 않다.

현재 `.replit.dev` 주소는 사용자 요청에 따른 **개발 웹뷰 주소**이며 24시간 운영용 게시 주소가 아니다. 프로젝트 중지·주소 변경 시 분석을 사용할 수 없다. 지속 운영 전에는 게시된 HTTPS 주소로 package.json 한 곳을 바꾸어 다시 배포해야 한다. 이번 작업은 기존 운영 배포를 수정하거나 새로 게시하지 않는다.

## 로그·한도

- 서버는 `CareLabel AI Error:`와 오류 message/stack/code를 구조화 로그로 남긴다. 이미지/Base64/키/인증 헤더는 로그에 남기지 않는다.
- HTTP 400/413/429/502/503, 모델 404, 잘못된 AI JSON을 구분한다.
- 서버에서 동시 분석 2건, 분당 60건, 일당 1,000건의 **프로세스 단위** 진입 한도를 둔다. 여러 인스턴스/재시작에 걸친 영구 과금 상한은 아니다.
- 점주 무설정 요구에 따라 공개 엔드포인트다. 대규모 서비스에서는 배포자의 API 할당량·예산 제한과 중앙 게이트웨이의 공유 한도/등록 장치 인증이 별도로 필요하다. 설치본에 공통 비밀 키를 넣는 방식은 보안 대책이 아니다.

## 태그 바인딩

- 성공 결과의 material_group / wash_method / color와 원문 혼용률을 SQLite의 기존 JSON 상태 및 주문 의류 스냅샷에 연결한다. 테이블/컬럼을 바꾸지 않는다.
- 자동 제출 결정 시 분석 필드도 작업 ID에 고정하여 이후 재분석으로 이미 제출된 태그의 내용이 바뀌지 않게 한다.
- 출력 하단: `[소재] 나일론 (물세탁) / [색상] 검정`.
- 긴 UUID의 가시 텍스트와 바코드 자동 문자를 제거했다. 바코드에 인코딩되는 실제 의류 ID는 유지한다.
- 접수번호 끝 8자리는 사람용 보조 표기이며 유일 식별자가 아니다.
- 절대 좌표 하단 텍스트를 없애고 그리드 행·간격·줄바꿈으로 배치한다.
- 실제 출력 경로는 기존 HTML/Electron → Windows 드라이버다. XP-TT434B는 해당 Windows 드라이버를 설치하고 선택해야 한다. **원시 TSPL 스풀 전송을 새로 구현했다고 주장하지 않는다.**
- 종이 폭/높이는 기존 검증 설정을 유지한다. XP-TT434B/TSC 실물 인쇄·DPI·바코드 판독·줄바꿈은 Windows 현장에서 확인해야 한다.

검증: docs/windows-central-carelabel-verification.md
