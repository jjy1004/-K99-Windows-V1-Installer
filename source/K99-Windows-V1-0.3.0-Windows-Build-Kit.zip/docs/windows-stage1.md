# K99-Windows-V1 — 1단계 구현 및 개발 실행

## 운영 격리

이 프로젝트는 첨부 소스의 독립 사본이다. 원본 Replit 프로젝트·배포·DB·서비스와 연결하지 않는다.
기존 고객/주문 이력, 브라우저 저장소, 운영 비밀번호, 사진·태그 장부, 도우미 설정을 가져오지 않는다.
현재 단계에서 매장 운영용으로 사용하거나 이 미리보기를 공개 배포하지 않는다.

## 현재 구현

- 첨부 React 접수/가격계산/의류 식별/조회/업무 화면을 재사용한다.
- Electron 메인과 sandbox preload가 제한된 IPC만 공개한다. 렌더러에는 Node/SQL/파일시스템을 노출하지 않는다.
- 기존 동기식 localStorage 호출의 계약을 유지하되 저장 대상은 SQLite다. 기존 브라우저 저장값은 읽지 않는다.
- 원래 주문 스냅샷과 의류/이력은 손실 없이 JSON으로 보관하며 주문별 인덱스를 같은 트랜잭션으로 갱신한다.
  조회 전에 읽은 값과 저장 시점의 값을 비교하여 다른 창의 변경을 덮어쓰지 않는다.
- WAL/FULL 동기화, DB 버전 확인, 무결성 검사 및 저장 실패 전파를 적용한다.
- 소스 가격 34개를 임시 기준으로 사용한다. 기존 기타 직접입력·프리미엄 파생 규칙을 유지한다.
  관리자 가격 수정은 revision을 검증하며 기존 접수 금액을 재계산하지 않는다.
- 상단에서 새 로컬 관리자 비밀번호를 최초 설정한다. 운영 관리자 비밀번호/인증키는 복사하지 않는다.
  변경 기능은 기존 관리 화면을 재사용하며 오프라인 암호 복구와 관리자 이력 삭제는 아직 지원하지 않는다.
- 주문 쓰기 전 하루 첫 백업과 내부 수동 백업 함수가 있다. 백업은 SQLite 일관 스냅샷으로 생성하고
  quick_check로 검증한다. 자동 백업 정리/복구 UI/사진 동시 백업은 다음 단계다.

## 파일 및 데이터 위치

- React: `artifacts/k99-windows/src/`
- Electron: `artifacts/k99-windows/electron/`
- 공용 SQLite 저장: `lib/k99-local/`
- Windows 데이터: `%LOCALAPPDATA%\K99WindowsV1\data\k99.sqlite`
- Windows 백업: `%LOCALAPPDATA%\K99WindowsV1\data\backups\`
- 개발 미리보기 DB: 이 독립 프로젝트의 `local-data/preview.sqlite`
- 첨부 원본 설정 보관: `reference-config/`

프로그램 설치 위치와 데이터 위치를 분리한다. 삭제·업데이트 프로그램은 데이터 폴더를 삭제하면 안 된다.
아직 설치 프로그램 및 재설치 보존 시험은 완료하지 않았다. 백업에는 개인정보가 있으므로 외부 반출을 제한한다.
일별 백업은 앱 사용 중 주문 저장 시 실행되며, 앱이 꺼진 동안 실행하는 예약 백업은 아직 없다.

## Windows 개발 PC 실행 절차 (이 문서는 매장 PC 실행 지시가 아님)

Node.js 24와 pnpm 10.26.1이 있는 별도 Windows 11 개발 PC에서 전체 독립 사본을 사용한다.
원본 `reference-config`는 보관용이며 현재 개발용 workspace/lockfile을 덮어쓰지 않는다.

```powershell
pnpm install --frozen-lockfile
pnpm --filter @workspace/k99-windows run desktop:prepare
pnpm --filter @workspace/k99-windows run desktop:build
pnpm --filter @workspace/k99-windows run desktop:start
```

`desktop:prepare`는 better-sqlite3를 Electron ABI에 맞춘다. 사전 빌드 바이너리가 없으면
Windows C++ 빌드 도구가 필요할 수 있다. 실행 전 개발 PC에서 이 호환성을 확인해야 한다.
Electron용으로 재빌드한 바이너리를 Node 미리보기와 함께 쓰면 ABI가 다르므로 개발환경을 분리하거나 재설치한다.
Windows 버전에서 별도 Express/Replit 서버를 실행할 필요가 없다.
메인 프로세스가 번들 화면을 `k99://app/`로 제공하고 API 요청을 IPC로 처리한다.

## 검증 명령

```text
node --test lib/k99-local/storage.test.cjs
pnpm --filter @workspace/scripts exec tsx --test ../artifacts/k99-windows/tests/order-persistence.test.ts
pnpm --filter @workspace/k99-windows run typecheck
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/k99-windows run desktop:build
```

브라우저 미리보기는 별도 개발 SQLite를 쓰는 호환 확인용이다. 동기식 HTTP 저장 경로는 미리보기에만 있고
Windows 제품은 동기식 IPC를 사용한다. 실제 고객 자료를 미리보기에 입력하지 않는다.

## 완료로 주장하지 않는 범위

- Windows에서 Electron 실제 실행/네이티브 ABI 검증 및 전체 접수 화면 조작 시험
- 카메라·풋스위치·사진 파일 저장/연결·프린터·실물 바코드·고객 모니터 현장 시험
- 원본 영상 복원: 이번 단계에는 대형 영상 및 운영 도우미 실행파일을 복사하지 않았다.
- EXE 설치·바탕화면 바로가기·자동 시작·안전 업데이트·재설치/롤백 시험
- 사진과 태그 파일을 포함한 백업/복구 UI 및 정전·디스크 장애 현장 시험

다음 단계는 독립 개발 PC에서 Electron 동작을 검증한 뒤, 기존 운영 프로그램을 건드리지 않는
장치 어댑터와 고객 모니터를 연결하는 것이다. 그 후 설치·업데이트·완전 복구를 검증한다.
