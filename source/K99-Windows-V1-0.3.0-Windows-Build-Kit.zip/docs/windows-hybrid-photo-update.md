# K99 V2 단일 의류 하이브리드 촬영 수정

## 수정 범위

- PC 촬영 응답, 모바일 촬영 응답, 백엔드 재조회 결과를 같은 `mergeDraftCapture`로 반영한다.
- 같은 의류의 이전 사진 ID가 누락된 지연 응답은 무시한다. 의류/품목 식별자는 재할당하지 않는다.
- 기존 원본 저장 큐, 초안 메타데이터의 `photos`, 렌더러의 `photoHistory`, 주문 확정 시 사진 승격은 변경하지 않는다.
- QR 종료는 모바일 세션만 종료한다. PC 미리보기와 현재 접수는 유지한다.
- 실제 촬영 모드에서 같은 의류의 PC/모바일 사진을 기존 사진 조회 경로로 순서대로 표시한다.
- 카메라 상단 배지는 #0f172a 배경, 흰색 굵은 품목명, #facc15 컷 수를 사용한다.
- 통합관리센터 기본 화면에서 고객 명부를 마운트하지 않는다. 4번째 고객 이력 관리 카드에서만 기존 명부 컴포넌트를 모달로 열고, 닫기/돌아가기/ESC로 복귀한다.
- 기존 파일명은 호환성을 위해 유지한다. PC는 기존 주문·의류 식별자 기반 이름이며, 모바일은 MOBILE_날짜_시각_순번_해시.jpg이다. CAM_001/MOBILE_002는 예시로 해석하며 기존 사진 이름을 변경하지 않는다.

## 보존 범위

`lib/k99-local` 전체, Electron 메인·preload·사진 저장·모바일 브리지·TSC 출력, 가격표 수정, 출고 삭제, 앱 package.json, pnpm-lock.yaml, Electron 빌더 및 인스톨러 설정은 이번 수정에서 변경하지 않았다.
SQLite 스키마·고객/주문 데이터·사진 원본·기존 폴더를 수정하거나 이전하지 않았다.
운영 Replit 프로젝트/DB/서비스에는 연결하지 않았다.

## 개발 환경 검증

- TypeScript 검사 통과.
- React desktop 번들 빌드 통과. 500kB 초과 청크 경고는 기존 비차단 경고다.
- TypeScript 기반 자동검사 56개, CJS 회귀검사 113개 통과.
- 실제 임시 SQLite, 파일 시스템, 루프백 HTTP에서 PC → 모바일 2컷 → QR 종료 → PC 추가 촬영: 같은 의류 4컷, 같은 고객 폴더, 순서 유지, 첫 태그 요청 1회, DB 재시작 후 4컷 유지 확인.
- 프린터/이미지 OS 디코더는 명시적 시험 어댑터다. 실제 TSC 인쇄 및 Windows 사진 디코딩 성공을 뜻하지 않는다.
- 역순 응답, 누락 사진 ID, 의류 ID 변경, 다른 품목 분리 보존 검사 통과.
- 관리센터 초기 React 서버 렌더에서 고객 명부 미노출 확인. 카드/조건부 모달/닫기 연결은 소스 검사이며 실제 Windows 클릭 검증은 아니다.

## app.zip 적용 범위와 한계

이 ZIP은 **기존 unpacked resources/app용 코드 오버레이**이며 독립 실행 완제품이 아니다.
`app/dist/desktop` 및 `app/electron`을 포함한다. 기존 package.json, node_modules, Windows 네이티브 바이너리, resources/videos는 포함하거나 교체하지 않는다.
Linux better-sqlite3 바이너리를 Windows 패키지에 넣지 않았다.

다음 조건을 확인하기 전에는 매장 설치본에 적용하지 않는다.

1. 실제 설치본이 resources/app/electron/main.cjs를 엔트리로 사용하는 unpacked 구조일 것. resources/app.asar 방식 설치본에는 적용하지 않는다.
2. 기존 app/package.json과 Windows용 node_modules가 존재하고, 의존성이 현재 0.3.0 구조와 일치할 것. 기준은 Electron 40.10.6, better-sqlite3 12.11.1, bwip-js 4.11.4, exceljs 4.4.0, xlsx 0.20.3이다. 네이티브 바이너리는 Windows x64 및 실제 Electron ABI와 일치해야 한다.
3. 기존 resources/videos의 검증된 원본 영상은 그대로 유지할 것.
4. 기존 프로그램의 통합 백업을 만들고 종료한 뒤, resources/app 폴더 전체를 별도 백업할 것. 사용자 데이터 폴더와 D: 사진 폴더는 덮어쓰기 대상이 아니다.
5. ZIP을 임시 폴더에서 먼저 풀어 확인하고, app/dist/desktop과 app/electron만 기존 resources/app의 같은 하위 폴더로 병합 복사한다. 기존 app 폴더 자체를 삭제하거나 빈 폴더로 교체하지 않는다.
6. 테스트 PC에서 시작, 기존 주문 조회, PC/휴대폰 촬영, 첫 태그, 재시작 보존을 확인한다. 오류 시 앱을 종료하고 백업한 코드 폴더 전체로 원복한다.

이 환경에는 최종 Windows app.asar/EXE가 없다. Windows 빌드·설치·실물 장비 검증은 수행하지 않았다.
현재 설치본 구조·ABI가 미확인인 경우 바로 교체 가능한 완제품은 제공할 수 없으며, 기존 GitHub Windows 빌드에서 새 설치본을 생성하는 방식이 권장된다.
