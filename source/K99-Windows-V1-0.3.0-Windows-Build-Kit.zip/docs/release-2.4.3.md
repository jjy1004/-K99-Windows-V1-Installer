# K99 Laundry V2 2.4.3 최종 배포 준비 결과

2026-11-18. 전수 검수 보완분을 포함한 새 Windows x64 교차 패키징 결과다.

## 생성 파일

| 파일 | 바이트 | SHA-256 |
|---|---:|---|
| K99-Smart-Laundry-V2-Setup.exe | 256795575 | `35acb436f879ab3e1f2d5599fd526da2a7b4b6bc53733af3607bdbe5240abe1b` |
| K99-Laundry-V2-2.4.3-win-unpacked.zip | 328020828 | `412d11318ba062c73e53fc45d15036997ab78cebbf329d542e50e41349c49d93` |

실제 Windows 설치·실행·장비·실계정 인증은 검증하지 않았다. 코드서명은 미적용이다.

## 검증 완료

- 자동 검사 304건 통과, 실패·건너뜀 0건. API TypeScript 검사 통과.
- 공식 Windows Electron 40.10.6 및 better-sqlite3 12.11.1의 공급자 체크섬, AMD64 PE, Electron ABI 143 export 확인.
- 최신 React 화면 번들을 새로 컴파일한 후 포장했다.
- 최종 ZIP의 CRC, 실행 파일·ASAR·SQLite 해시, 현재 코어 18개·Electron 코드 27개·화면 파일 10개 일치 확인.
- 최종 ZIP에서 추출한 번들로 9개 업무 영역 95항목 모의 회귀 통과: 런처 11, 고객 엑셀 5, 촬영/사이드바 19, 동적 영상 7, 고객/통계 7, 사진 정리 6, 한글 입력 8, 비교 사진 송출 8, 접수/검수/출고 24.
- NSIS 컴파일 통과. 실제 설치 EXE를 실행하지 않고 압축 해제하여 포함된 86개 파일이 포터블 원본과 모두 일치함을 확인했다.
- 원본 안내 영상 5종과 미디어 명세 포함. 기존 자료 저장 위치·DB·태그·결제·프린터 설정을 초기화하지 않는다.
- 두 파일 모두 새 SHA 경로의 영구 App Storage에 업로드하고, 원격 전체 바이트 수·SHA-256을 다시 검증했다. 이전 릴리스 객체는 덮어쓰거나 삭제하지 않았다.
- 개발 공개 URL을 통한 실제 HEAD·체크섬·전체 GET 다운로드의 바이트 수·SHA-256 검사 통과.
- 게시용 `carelabel-proxy.mjs`를 별도 임시 포트에서 실행하여 건강 검사 및 두 파일 HEAD·체크섬 확인. 개발용 장부 API는 404임을 확인했다.
- 운영 DB 접속·운영 데이터 변경·GitHub Actions 실행·실제 Publish는 수행하지 않았다.

## 릴리스 갱신

- 앱 버전과 기본 중앙 프록시 주소 갱신.
- `artifacts/api-server/src/installer-release.json`을 원격 검증을 마친 2.4.3 EXE·포터블 객체로 갱신.
- 정식 서버에서는 명세의 두 파일과 각 체크섬만 공개한다. 개발 파일 서버 전체나 장부·설정은 노출하지 않는다.
- 배포 설정의 게시용 진입점과 `/api/healthz` 시작 검사는 유지했다. 생성 파일을 게시 파일시스템에 의존하지 않는다.

## 지금 다운로드

개발 워크스페이스가 실행 중일 때 사용할 수 있다.

- [설치 EXE](https://94e12ca0-fb49-4b2d-8aa2-c7826c494a63-00-3c6lmvrct35yf.pike.replit.dev/api/dev-downloads/K99-Smart-Laundry-V2-Setup.exe)
- [포터블 ZIP](https://94e12ca0-fb49-4b2d-8aa2-c7826c494a63-00-3c6lmvrct35yf.pike.replit.dev/api/dev-downloads/K99-Laundry-V2-2.4.3-win-unpacked.zip)

## 사용자 Publish 후 정식 주소

- `https://k-99-windows-v-1.replit.app/api/dev-downloads/K99-Smart-Laundry-V2-Setup.exe`
- `https://k-99-windows-v-1.replit.app/api/dev-downloads/K99-Laundry-V2-2.4.3-win-unpacked.zip`

각 주소 뒤 `.sha256`으로 체크섬을 받는다. 응답은 캐시하지 않으며 바이트 범위 이어받기는 제공하지 않는다.

현재 정식 서버는 이전 게시본이다. 새 설치 EXE 경로의 HEAD 응답은 404로 확인했다. 준비 완료와 실제 Publish 완료를 혼동하지 말아야 한다. 사용자가 Publish한 뒤 정식 URL에서 다시 확인해야 한다.

## 사용 시 주의

기존 앱을 종료하고 DB와 사진을 백업한 후 설치하거나 포터블 전체를 새 폴더에 풀어 실행한다. 포터블은 내부 EXE 하나만 이동하지 않는다. 기존 사용자 데이터 폴더나 사진 폴더를 삭제하지 않는다. 설치본은 바탕화면·시작 메뉴 바로가기를 생성하도록 구성되어 있으나 실제 Windows 설치 결과는 미검증이다. 서명되지 않은 시험 빌드이므로 Windows에서 게시자 경고가 표시될 수 있다.

## 재현·검증 도구

- `build-windows-portable.cjs`: 최신 화면 컴파일 후 공식 Windows 바이너리로 포터블 구성
- `audit-final-portable.cjs`: 최종 ZIP의 실제 내용 및 9개 업무 흐름 검사
- `build-oneclick-installer.cjs`: 검증한 동일 포터블로 NSIS 생성
- `verify-oneclick-payload.cjs`: 설치 EXE를 실행하지 않고 실제 내장 파일 비교
- `prepare-release-manifest.cjs`: 검증 완료 파일로 릴리스 후보 생성
- `upload-installer-release.cjs --manifest …`: 영구 업로드 및 원격 전체 무결성 검사
- `verify-release-downloads.cjs --base …`: 고정 다운로드의 HEAD·체크섬·전체 GET 검증

검증 기록은 `generated-artifacts/v243-*`, 최종 ZIP 감사 기록 및 `oneclick-installer-verification.json`에 있다.
