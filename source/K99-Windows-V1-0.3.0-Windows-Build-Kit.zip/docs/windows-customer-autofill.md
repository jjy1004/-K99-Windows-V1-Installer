# 고객 양방향 자동 기입 패치 — V2-AUTOFILL-20261105

기존 Zero-Auth·사진 조회·장비 기본값·저장 구조를 유지한다. 실행 화면 상단의 패치 ID로 이전 설치본과 구분한다.
EXE 버전/파일명은 0.3.0을 유지하며, 데이터 폴더 이름도 변경하지 않는다.

## 확인된 미비점
- 기존 SQLite 고객 검색과 클릭 자동 기입은 있었지만 끝4자리 단일 결과의 자동 선택이 없었다.
- 접수 인풋에서 방향키/Enter를 눌러 추천을 확정하는 처리가 없었다.
- 이름 한 글자부터 조회되었고, 연락처 입력 중 이전 이름으로 조회될 수 있었다.
- 검색 결과에 최근 방문일/최근365일 통계가 함께 반환되지 않았다.

## 적용
- 실제 변경 파일: App.tsx, CustomerDirectory.tsx, ManagementCustomerPanel.tsx, customer-autofill.ts,
  customer-directory-client.ts, desktop-runtime.ts, electron/main.cjs·preload.cjs,
  lib/k99-local/customer-directory.cjs 및 검사 파일.
- Electron searchCustomers(keyword) → 직원 창 전용 IPC → 기존 로컬 SQLite customers/orders.
- 숫자 끝4자리 또는 구분자 포함 번호는 정규화 후 전화 끝자리 조회. 한글/영문은 이름 LIKE 부분 조회.
- LIKE 특수문자는 이스케이프하고 SQL 바인딩을 사용한다. 최대 10명, 원본 고객 ID는 유지한다.
- 검색 결과는 id/name/phone/address/lastVisitDate/recentYear를 반환한다.
- 이름 2글자 이상 추천. 클릭 또는 방향키 후 Enter로 확정한다.
- 전화 끝4자리 일치 결과가 1명일 때만 이름·전체 전화·주소를 함께 자동 기입한다.
- 여러 명은 자동 선택/병합하지 않는다. 같은 이름/같은 번호라도 다른 고객 ID를 임의 병합하지 않는다.
- 저장된 전체 번호는 010-XXXX-XXXX로 표시한다. 원본에 없는 번호를 만들어 채우지 않는다.
- 접수와 통합관리센터 모두 같은 검색/선택 규칙을 사용한다. 선택 직후 기존365일 카드/표 및 사진 조회가 이어진다.
- 신규 고객/검색 0명은 수동 입력 상태를 유지한다. 조회만으로 고객/주문을 생성하거나 저장하지 않는다.
- IME 조합 중 조회·Enter 선택을 멈추며 오래된 응답과 바뀐 입력의 추천을 무시한다.
- 직원이 주소 등 다른 필드로 이동해 입력 중이면 늦은 결과로 강제 자동 기입하지 않고 추천만 제공한다.
- 촬영 중 Enter는 기존 풋스위치 촬영이 우선이다. 단, 고객 추천을 방향키로 명시적으로 탐색한 직후 Enter는 선택에 사용한다.
  추천 확정/닫기/입력 변경 시 선택 예약을 해제한다. 오래된 추천이 풋스위치 Enter를 가로채지 않는다.

## 검증 및 현장 확인
SQLite 실제 파일 검사와 브라우저 Mock 데이터 검사를 구분한다.
제공된 실제 Excel을 임시 SQLite에 가져와 검색/이력/중복/재열기를 검증한다.
새 UI 규칙·키보드 우선순위와 독립 SQLite 테스트가 GitHub Actions 검사에 포함된다.
TypeScript/Vite 검사와 Node 단위검사는 실제 Windows 설치/장비/입력 조작 검증을 대신하지 않는다.
매장 PC에서 원장 가져오기 후 단일 끝4자리, 중복 끝4자리, 이름2글자, 방향키/Enter, 신규 고객 입력을 확인한다.

## 업로드
패키지의 .github/workflows, source, README.md를 기존 비공개 저장소에 교체한다.
Build-Kit.zip / .zip.sha256 / source/upload.json은 반드시 같은 묶음으로 교체한다.
기존 영상 조각은 유지한다. 소스/영상 해시를 확인한 다음 GitHub Actions를 실행해 EXE를 새로 만든다.
소스 업로드만으로 설치된 프로그램은 바뀌지 않는다. 새 EXE 설치 후 상단 V2-AUTOFILL-20261105 표시를 확인한다.
실제 고객 Excel/DB/사진/인증키는 납품 ZIP에 포함하지 않는다. 기존 Replit 운영 시스템에 접근하지 않는다.
