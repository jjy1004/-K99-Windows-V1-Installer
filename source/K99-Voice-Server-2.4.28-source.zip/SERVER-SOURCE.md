이 파일은 Windows 소스 ZIP과 함께 보관하는 서버 소스입니다.
Windows 설치본에는 서버 SDK나 API 키를 넣지 않습니다.
서버 게시 및 K99_DIARY_VOICE_ACCESS_TOKEN 보안 설정은 별도입니다.
