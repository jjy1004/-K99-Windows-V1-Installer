# K99 Windows 0.3.0 — 통합 UI·업무 개선 내역

## 반영 결과

1. **접수·세탁 전 검수**: 새 입력을 물세탁·이상 없음·실물 확인함으로 초기화합니다. 기존 지정 세탁 방법과 과거 검수 기록은 유지하고, 직원이 드라이세탁·주의 필요로 변경할 수 있습니다. 고객 동의는 자동 선택하지 않습니다.
2. **한국어 입력**: 초기·동적 생성되는 모든 `input`/`textarea`에 `lang="ko"`를 적용하고 전역 `ime-mode: active`를 설정합니다. 키보드·한글 조합 이벤트를 가로채지 않습니다. Chromium은 해당 CSS로 OS IME를 강제 전환하지 않으므로 실제 한/영 상태는 Windows 현장 확인 대상입니다.
3. **공식 안내 3종**: 요청된 면책동의·추가 기술료·통합 문안을 공통 템플릿으로 연결했습니다. 고객명·품목·추가비용과 미입력 비용 예시를 치환하며 편집·복사·저장할 수 있습니다. 기존 문안·동의 이력은 소급 교체하지 않습니다.
4. **완료 검수**: 개별 완성 검수와 전체 출고 대기 전환 버튼을 제공합니다. 전후 사진 만들기·폴더 열기·완성 사진·새 스캔을 선행조건으로 요구하지 않습니다. 실제 미세탁·취소·보류·이미 인도된 주문은 차단하고, 전체 확정은 중간 저장 없이 한 번에 처리합니다.
5. **완성 의류·출고**: 상단 대기 카드, 중간 선택 주문, 하단 단일 입력창으로 재구성했습니다. 중복 주문 검색 카드를 제거하고 연락처 끝 4자리·등록 바코드는 짧은 입력 대기 후 자동 선택합니다. Enter 스캔도 유지합니다. 직원 확정 인도는 스캔 체크리스트 없이 가능하며, 실제 스캔과 구분해 감사 이력을 남깁니다. 실제 배달 출고는 배달 중으로만 전환합니다.
6. **오늘의 업무센터**: 완료일을 0일로 하여 한국 날짜 +9일·+13일 안내를 계산합니다. 접수일 기준 기존 보관료 계산은 유지합니다. 완료·9일·13일 문안은 K99 세탁의 품격 브랜드로 표시하고, 복사만으로 발송 완료를 기록하지 않습니다.

## 이번 요청에서 변경·추가한 파일

아래 `src/`, `tests/`는 `artifacts/k99-windows/` 기준입니다.

| 파일 | 역할 |
|---|---|
| `src/field-inspection.ts` | 신규 검수 기본값과 직원 수정 반영 |
| `src/InspectionStageDesk.tsx` | 기본 선택 UI, 개별·전체 완성 검수 버튼 |
| `src/field-quality.ts` (신규) | 사진·스캔과 독립된 원자적 완료 검수 |
| `src/care-notice-templates.ts` (신규) | 공식 안내문 3종 |
| `src/process-stage.ts`, `src/inspection-guidance.ts` | 공통 공식 템플릿 연결 |
| `src/korean-inputs.ts` (신규), `src/main.tsx`, `src/index.css` | 전역 한국어 입력 힌트 |
| `src/GarmentScannerWorkspace.tsx`, `src/garment-scanner.css` | 출고 카드·단일 입력·직원 인도 확정 UI |
| `src/order-handover.ts` | 명시적 직원 확인 인도와 감사 이력; 기존 엄격 스캔 API 유지 |
| `src/customer-pickup-notices.ts` | 완료 후 0·9·13일 기준 및 브랜드 문안 |
| `src/customer-notice-text.ts` | 완료 안내 문안 공통화 |
| `tests/field-inspection.test.ts` | 변경된 검수 기본값 회귀 검사 |
| `tests/field-ux-update.test.ts` (신규) | 완료 검수·일차 경계·문안 검사 |
| `tests/korean-inputs.test.ts` (신규) | 초기·동적 입력란·포커스 언어 힌트 검사 |
| `tests/staff-handover.test.ts` (신규) | 직원 인도·배달·차단 조건 검사 |
| `scripts/test-desktop-field-ui.cjs` (신규) | 설치된 Vite/esbuild로 TS 업무 테스트 실행 |
| `scripts/verify-native-customer-browser.cjs` | 임시 SQLite를 사용하는 통합 화면 시나리오 확장 |
| `.github/workflows/windows-installer.yml` | Windows 패키징 전에 새 업무 테스트 실행 |
| `scripts/make-windows-build-kit.py` | 새 테스트 실행기·문서 납품 구성 |
| `docs/windows-field-operations.md`, 본 문서 | 사용·검증·변경 안내 |

## 실제 검증

- Node 자동 테스트 77개 + TypeScript 업무 테스트 20개 통과.
- React 타입 검사, Vite 데스크톱 화면 빌드, Windows 패키징용 파일 배치 통과.
- Chromium 통합 시나리오 11개 통과: 기존 원본 영상 4종·고객 IPC·사진 12장·탭 왕복에 더해 검수 기본값/안내문/언어 속성, 개별·전체 완료 검수, 연락처 자동 선택·무스캔 직원 인도 확정 저장을 확인했습니다.
- 클립보드는 모의 어댑터에 전달된 문자열이 편집 문안과 정확히 같은지 검사했습니다. 실제 Windows 클립보드·IME·장비 검증은 아닙니다.
- 브라우저 테스트는 OS 임시 SQLite·모의 Electron IPC/모니터·모의 장비만 사용합니다. 실제 운영 DB나 배포에 연결하지 않습니다.
- 화면 빌드에는 기존 대형 번들 경고가 있으며 빌드 차단 오류는 없습니다.
- 실제 Windows NSIS EXE 생성·설치·장비·OS IME 검증은 이번 환경에서 수행하지 않았습니다.

## GitHub 교체와 데이터

새 소스 업로드 ZIP을 해제해 기존 비공개 저장소의 동일 경로를 교체합니다. 내부 소스 ZIP은 해제하지 않습니다. 영상 조각·해시는 기존 묶음과 동일하므로 영상 2개 ZIP을 다시 업로드할 필요가 없습니다.

기존 Windows SQLite·사진·태그·설정의 스키마 및 저장 경로는 변경하지 않았으며 마이그레이션이나 데이터 삭제를 실행하지 않았습니다. 원본 Replit 운영 프로젝트·운영 DB·운영 배포 및 현장 도우미는 수정하지 않았습니다.
